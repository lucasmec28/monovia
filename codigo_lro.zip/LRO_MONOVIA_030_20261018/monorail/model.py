"""Entradas físicas estritas; a capacidade nominal nunca define uma classe."""
from __future__ import annotations

from dataclasses import asdict, dataclass, field, fields, is_dataclass
from hashlib import sha256
import json
import math
import types
from typing import get_args, get_origin, get_type_hints, Union

from lro_beams.model import Material, Section
from lro_beams.autonomous_actions import HoistDynamics, compute_hoist_dynamic
from lro_beams.geometry import section_properties
from lro_beams.document_metadata import validate_xml_text

FORMAT = "LRO_MONORAIL_STRAIGHT"


def _typed(value, annotation, label):
    origin=get_origin(annotation)
    args=get_args(annotation)
    if origin in (Union,types.UnionType):
        for typ in args:
            try:_typed(value,typ,label);return
            except ValueError:pass
        raise ValueError(label+": tipo de dado inválido.")
    if annotation is type(None):
        if value is not None:raise ValueError(label+": esperado valor nulo.")
    elif annotation is str:
        if not isinstance(value,str):raise ValueError(label+": texto obrigatório.")
        validate_xml_text(value,label,max_length=10000)
    elif annotation is bool:
        if type(value) is not bool:raise ValueError(label+": booleano obrigatório.")
    elif annotation is int:
        if type(value) is not int:raise ValueError(label+": inteiro obrigatório.")
    elif annotation is float:
        finite(value,label)
    elif origin is list:
        if not isinstance(value,list):raise ValueError(label+": lista obrigatória.")
        for index,item in enumerate(value):_typed(item,args[0],f"{label}[{index}]")
    elif origin is dict:
        if not isinstance(value,dict):raise ValueError(label+": objeto obrigatório.")
        for key,item in value.items():_typed(key,args[0],label+".chave");_typed(item,args[1],label+"."+str(key))
    elif is_dataclass(annotation):
        if not isinstance(value,annotation):raise ValueError(label+": objeto tipado obrigatório.")
        hints=get_type_hints(annotation)
        for f in fields(value):_typed(getattr(value,f.name),hints[f.name],label+"."+f.name)
    else:raise ValueError(label+": tipo não suportado.")


def finite(value, label, *, minimum=None, positive=False):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or abs(value) > 1e12:
        raise ValueError(f"{label}: informe número finito, sem booleano.")
    if positive and value <= 0 or minimum is not None and value < minimum:
        raise ValueError(f"{label}: valor fora do domínio.")
    return float(value)


@dataclass
class Station:
    """Um eixo longitudinal com DUAS rodas opostas, iguais por hipótese explícita."""
    id: str = "E1"
    offset_m: float = 0.0
    equipment_share: float = 0.5
    suspended_share: float = 0.5
    longitudinal_kn: float = 0.0
    transverse_kn: float = 0.0


@dataclass
class MonorailProject:
    format: str = FORMAT
    schema_version: int = 1
    project_name: str = "Exemplo ilustrativo de monovia"
    member_name: str = "MV-01"
    responsible: str = ""
    demonstration: bool = True
    span_m: float = 6.0
    section: Section = field(default_factory=lambda: Section(
        name="I ilustrativo 400 × 200 × 10 × 16", fabrication="rolled", d_mm=400.,
        bf_mm=200., tw_mm=10., tf_mm=16., root_radius_mm=16.,
        property_source="Geometria ilustrativa, sem fabricante; rigidez por três retângulos, sem crédito de raios."))
    material: Material = field(default_factory=lambda: Material(fy_mpa=250., fu_mpa=400., specification="Material ilustrativo; confirmar certificado e espessura."))
    section_mass_kg_per_m: float | None = None
    section_mass_source: str = ""
    weld_throat_mm: float = 0.0
    capacity_t: float = 2.0
    operating_payload_t: float = 2.0
    trolley_hoist_mass_kg: float = 200.0
    retained_suspended_mass_kg: float = 50.0
    equipment_source: str = "Exemplo, não corresponde a catálogo de talha/trole."
    equal_opposite_wheels: bool = True
    wheel_distribution_source: str = "Hipótese ilustrativa explícita: dois eixos iguais, duas rodas iguais por eixo."
    stations: list[Station] = field(default_factory=lambda: [Station(), Station(id="E2", offset_m=0.8)])
    edge_to_contact_mm: float = 30.0
    travel_min_m: float = 0.45
    travel_max_m: float = 4.75
    travel_source: str = "Limites ilustrativos medidos pela posição do primeiro eixo."
    extra_dead_kn_per_m: float = 0.0
    extra_dead_source: str = "Zero adotado explicitamente no exemplo."
    hoist_class: str = "HC2"
    drive_class: str = "HD1"
    hoist_speed_m_s: float = 0.1
    creep_speed_m_s: float | None = None
    equipment_group: str = "A5"
    classification_source: str = "Classes ilustrativas; não inferidas da capacidade."
    dynamic_mode: str = "nbr8400_hc_hd"
    dynamic_psi_manual: float = 1.25
    dynamic_source: str = "Coeficiente específico deve ser fundamentado pelo responsável."
    cmaa_class: str = "não informada"
    en_classification: str = "não informada"
    horizontal_action_source: str = "Exemplo vertical apenas: ações horizontais zero, a validar no equipamento real."
    end_forks_confirmed: bool = True
    restraint_mode: str = "full_span"
    nominal_restraints_adopted: bool = False
    upper_braces_m: list[float] = field(default_factory=list)
    lower_braces_m: list[float] = field(default_factory=list)
    lateral_axis_braces_m: list[float] = field(default_factory=list)
    restraint_source: str = "Garfo ideal nas extremidades; rigidez e ligações reais não dimensionadas."
    high_ratio_material_confirmed: bool = False
    fatigue_group: str = "não informado"
    fatigue_category: str = "não selecionada"
    fatigue_cycles: int = 100000
    fatigue_source: str = ""
    fatigue_material_grade: str = "ASTM A36"
    fatigue_kappa_minus_one_adopted: bool = False
    fatigue_fabrication_declared: bool = False
    fatigue_detail_confirmed: bool = False
    fatigue_constant_amplitude: bool = False
    corrosion_protected: bool = False
    notes: str = "Um equipamento. Sem curva, desvios, juntas, enrijecedores, múltiplos vãos, batentes ou ligações dimensionados."
    numerical_tolerance: float = 0.005
    max_refinements: int = 6

    def validate(self):
        _typed(self,type(self),"projeto")
        if self.format != FORMAT or type(self.schema_version) is not int or self.schema_version != 1:
            raise ValueError("Formato/versão de projeto de monovia não suportado. Não renomeie JSON de ponte para monovia.")
        for f in fields(self):
            v = getattr(self, f.name)
            if isinstance(v, str): validate_xml_text(v, f.name, max_length=10000)
        for n in ("demonstration", "equal_opposite_wheels", "end_forks_confirmed", "high_ratio_material_confirmed", "fatigue_detail_confirmed", "fatigue_constant_amplitude", "corrosion_protected", "fatigue_kappa_minus_one_adopted", "fatigue_fabrication_declared"):
            if type(getattr(self, n)) is not bool: raise ValueError(n+": booleano obrigatório.")
        for n in ("span_m", "capacity_t", "edge_to_contact_mm", "hoist_speed_m_s"):
            finite(getattr(self,n), n, positive=True)
        for n in ("operating_payload_t", "trolley_hoist_mass_kg", "retained_suspended_mass_kg", "extra_dead_kn_per_m", "weld_throat_mm"):
            finite(getattr(self,n),n,minimum=0.)
        if self.operating_payload_t > self.capacity_t:
            raise ValueError("Carga operacional excede a capacidade nominal informada. Ensaio/sobrecarga requer caso próprio, não esta operação normal.")
        if not self.equal_opposite_wheels:
            raise ValueError("Primeiro domínio exige pares opostos simétricos com forças iguais. Não se divide uma reação desigual automaticamente.")
        if not isinstance(self.section,Section) or not isinstance(self.material,Material):
            raise ValueError("Seção e material tipados são obrigatórios.")
        s,m=self.section,self.material
        for n in ("d_mm", "bf_mm", "tw_mm", "tf_mm"):
            finite(getattr(s,n),n,positive=True)
        finite(s.root_radius_mm,"raio",minimum=0.)
        if not s.doubly_symmetric or s.d_mm <= 2*s.tf_mm or s.bf_mm <= s.tw_mm:
            raise ValueError("Domínio: I duplamente simétrico com dimensões positivas e alma livre.")
        if s.fabrication not in ("rolled", "welded"):
            raise ValueError("Escolha seção laminada ou soldada.")
        if s.property_basis != "rectangles" or s.catalog:
            raise ValueError("Este adaptador usa propriedades uniformes de três retângulos. Importe dimensões do catálogo, não propriedades mistas.")
        root=s.root_radius_mm if s.fabrication=="rolled" else math.sqrt(2)*self.weld_throat_mm
        if s.fabrication=="rolled" and (s.root_radius_mm<=0 or self.weld_throat_mm):
            raise ValueError("Perfil laminado exige raio físico/equivalente positivo e garganta de solda zero.")
        if s.fabrication=="welded" and (s.root_radius_mm or self.weld_throat_mm<=0):
            raise ValueError("Perfil soldado exige garganta explícita e raio zero. Sua fadiga de raiz permanece separada.")
        if 2*root >= s.d_mm-2*s.tf_mm or s.bf_mm/2-self.edge_to_contact_mm <= s.tw_mm/2+root:
            raise ValueError("Contato invade a raiz/solda ou geometria interna inválida.")
        for n in ("fy_mpa","fu_mpa","E_mpa","G_mpa","gamma_a1"):
            finite(getattr(m,n),n,positive=True)
        if m.fu_mpa<m.fy_mpa or m.gamma_a1<1:
            raise ValueError("Material exige fu≥fy e gamma_a1≥1.")
        if self.section_mass_kg_per_m is not None:
            finite(self.section_mass_kg_per_m,"massa do perfil",positive=True)
            if not self.section_mass_source.strip(): raise ValueError("Identifique a fonte da massa do perfil.")
        elif s.fabrication=="welded":
            raise ValueError("Perfil soldado exige massa completa, inclusive soldas, com fonte.")
        if not isinstance(self.stations,list) or not 1<=len(self.stations)<=8 or any(not isinstance(x,Station) for x in self.stations):
            raise ValueError("Informe de 1 a 8 eixos, com duas rodas por eixo.")
        ids=[];offsets=[]
        for a in self.stations:
            validate_xml_text(a.id,"identificação de eixo")
            if not a.id.strip():raise ValueError("Identifique cada eixo.")
            ids.append(a.id);offsets.append(a.offset_m)
            for n in ("offset_m","equipment_share","suspended_share"):
                finite(getattr(a,n),n,minimum=0.)
            for n in ("longitudinal_kn","transverse_kn"):
                finite(getattr(a,n),n)
        if len(set(ids))!=len(ids) or len(set(offsets))!=len(offsets):
            raise ValueError("Eixos exigem identificações e posições longitudinais distintas.")
        if offsets[0]!=0. or offsets!=sorted(offsets):raise ValueError("O primeiro eixo deve definir offset zero; os demais devem crescer em ordem longitudinal.")
        for n in ("equipment_share","suspended_share"):
            if not math.isclose(sum(getattr(a,n) for a in self.stations),1.,abs_tol=1e-10):
                raise ValueError(f"As frações {n} dos eixos devem somar 1. Não haverá normalização silenciosa.")
        finite(self.travel_min_m,"limite inicial",minimum=0.)
        finite(self.travel_max_m,"limite final",minimum=0.)
        if not self.travel_min_m<self.travel_max_m or self.travel_max_m+max(offsets)>self.span_m:
            raise ValueError("Limites físicos de viagem devem manter todas as rodas dentro do vão, com intervalo positivo.")
        for n in ("equipment_source","wheel_distribution_source","travel_source","extra_dead_source","classification_source","horizontal_action_source","restraint_source"):
            if not getattr(self,n).strip():raise ValueError("Registre a fonte/hipótese de "+n+", inclusive quando zero.")
        for name in ("upper_braces_m","lower_braces_m","lateral_axis_braces_m"):
            arr=getattr(self,name)
            if not isinstance(arr,list):raise ValueError("Lista de travamentos inválida: "+name)
            for x in arr:
                finite(x,name,minimum=0.)
                if x>self.span_m:raise ValueError("Travamento fora do vão.")
        if self.restraint_mode not in ("full_span","resistance_lengths_only"):
            raise ValueError("Modo de travamentos desconhecido.")
        if self.restraint_mode=="resistance_lengths_only":
            if not self.nominal_restraints_adopted:raise ValueError("Adote explicitamente a hipótese de comprimentos resistentes sem redistribuição.")
            self.resistance_plan()
        if self.equipment_group not in tuple("A"+str(i) for i in range(1,9)):
            raise ValueError("Grupo A1–A8 explícito obrigatório; CMAA e EN não são conversões automáticas.")
        if self.dynamic_mode not in ("nbr8400_hc_hd","manual"):
            raise ValueError("Modo dinâmico não suportado.")
        self.dynamics()
        if self.fatigue_group not in ("não informado",)+tuple("E"+str(i) for i in range(1,9)):
            raise ValueError("Grupo de fadiga do componente deve ser E1–E8 ou não informado.")
        if self.fatigue_category not in ("não selecionada","A","B","B'","C","D","E","E'"):
            raise ValueError("Categoria de fadiga inválida. Grupos E1–E8 não são categorias do Anexo H.")
        if type(self.fatigue_cycles) is not int or not 1<=self.fatigue_cycles<=10**12:
            raise ValueError("Ciclos de fadiga devem ser inteiros positivos.")
        finite(self.numerical_tolerance,"tolerância",positive=True)
        if not .0001<=self.numerical_tolerance<=.02 or type(self.max_refinements) is not int or not 0<=self.max_refinements<=8:
            raise ValueError("Tolerância deve ser 0,0001…0,02 e refinamentos 0…8.")
        g=section_properties(s)
        if g.Ix_mm4<=g.Iy_mm4:raise ValueError("Orientação exige eixo forte vertical (Ix>Iy).")
        return self

    def dynamics(self):
        if self.dynamic_mode=="manual":
            finite(self.dynamic_psi_manual,"Psi",minimum=1.)
            if not self.dynamic_source.strip():raise ValueError("Psi específico exige justificativa/fonte.")
            return dict(psi=self.dynamic_psi_manual,source=self.dynamic_source,method="Coeficiente específico informado, não equivalência de classes.")
        return compute_hoist_dynamic(HoistDynamics(self.hoist_class,self.drive_class,self.hoist_speed_m_s,self.creep_speed_m_s,self.classification_source))

    def self_weight_kn_m(self):
        if self.section_mass_kg_per_m is not None:return self.section_mass_kg_per_m*9.80665/1000
        s=self.section;area=section_properties(s).A_mm2+(4-math.pi)*s.root_radius_mm**2
        return area*1e-6*7850*9.80665/1000

    def resistance_plan(self):
        if self.restraint_mode=="full_span":return None
        from types import SimpleNamespace
        from lro_beams.autonomous_nominal_lengths import resolve_nominal_lengths
        proxy=SimpleNamespace(span_m=self.span_m,restraint_application="resistance_lengths_only",
            upper_braces_m=self.upper_braces_m,lower_braces_m=self.lower_braces_m,
            lateral_only_braces_m=self.lateral_axis_braces_m,lateral_only_brace_level="shear_center",
            lateral_only_brace_model="rigid_discrete")
        return resolve_nominal_lengths(proxy)

    def to_dict(self):return asdict(self)
    def to_json(self):return json.dumps(self.to_dict(),ensure_ascii=False,indent=2,allow_nan=False)
    def signature(self):return sha256(json.dumps(self.to_dict(),sort_keys=True,separators=(",",":"),ensure_ascii=False,allow_nan=False).encode()).hexdigest()

    @classmethod
    def from_json(cls,payload):
        if isinstance(payload,bytes):payload=payload.decode("utf-8-sig")
        def reject(value):raise ValueError("Número não finito proibido: "+value)
        def no_duplicates(pairs):
            out={}
            for k,v in pairs:
                if k in out:raise ValueError("Campo JSON duplicado: "+k)
                out[k]=v
            return out
        raw=json.loads(payload,parse_constant=reject,object_pairs_hook=no_duplicates)
        if not isinstance(raw,dict) or set(raw)!={f.name for f in fields(cls)}:
            raise ValueError("JSON truncado, desconhecido ou de outra aplicação. Todos os campos do formato 1 são exigidos.")
        def obj(t,v):
            if not isinstance(v,dict) or set(v)!={f.name for f in fields(t)}:raise ValueError("Campos inválidos em "+t.__name__)
            return t(**v)
        raw["section"]=obj(Section,raw["section"]);raw["material"]=obj(Material,raw["material"])
        if not isinstance(raw["stations"],list):raise ValueError("Eixos devem ser lista.")
        raw["stations"]=[obj(Station,x) for x in raw["stations"]]
        return cls(**raw).validate()


def demo_project():
    return MonorailProject().validate()
