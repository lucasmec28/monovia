"""Deterministic engineering schematics and plots from the actual inputs."""
from io import BytesIO
from .labels import family_label
import math
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle,Circle,Polygon


def figure_bytes(fig,format="png"):
    data=BytesIO();fig.savefig(data,format=format,dpi=180,bbox_inches="tight",facecolor="white",
        metadata={"Date":None} if format=="svg" else {"Software":"LRO Monovia"})
    plt.close(fig);return data.getvalue()


def schematic(p,format="png"):
    s=p.section;fig,(ax,cs)=plt.subplots(1,2,figsize=(11,4.5),gridspec_kw={"width_ratios":[1.7,1.]},layout="constrained")
    blue="#24556b";orange="#b46a18"
    L=p.span_m;a=(p.travel_min_m+p.travel_max_m)/2
    ax.add_patch(Rectangle((0,0),L,.34,fc="#eff4f6",ec=blue,lw=.8))
    ax.plot([0,L],[0,0],color=blue,lw=4,solid_capstyle="butt")
    ax.plot([0,L],[.34,.34],color=blue,lw=3,solid_capstyle="butt")
    for x in (0,L):
        ax.add_patch(Polygon([[x,0],[x-.09,-.2],[x+.09,-.2]],closed=True,fc="#d3e1e7",ec=blue))
    for st in p.stations:
        x=a+st.offset_m
        ax.add_patch(Circle((x,.055),.055,fc=orange,ec="black",lw=.7))
        ax.annotate("",xy=(x,-.45),xytext=(x,-.12),arrowprops=dict(arrowstyle="->",color=orange,lw=1.5))
        ax.text(x,.45,f"{st.id}\n2 rodas",ha="center",fontsize=8)
        ax.text(x,-.60,f"o={st.offset_m:g} m",ha="center",fontsize=8)
    for i,(left,right) in enumerate(zip(p.stations,p.stations[1:])):
        ax.annotate("",xy=(a+left.offset_m,-.82),xytext=(a+right.offset_m,-.82),arrowprops=dict(arrowstyle="<->",lw=.7))
        ax.text(a+(left.offset_m+right.offset_m)/2,-.98,f"e{i+1}={right.offset_m-left.offset_m:g} m",ha="center",fontsize=8)
    ax.annotate("",xy=(0,-1.18),xytext=(L,-1.18),arrowprops=dict(arrowstyle="<->",color="black"))
    ax.text(L/2,-1.16,f"L = {L:g} m",ha="center",va="bottom",fontsize=10)
    ax.annotate("",xy=(p.travel_min_m,.82),xytext=(p.travel_max_m,.82),arrowprops=dict(arrowstyle="<->",color=blue))
    ax.text((p.travel_min_m+p.travel_max_m)/2,.88,f"a = {p.travel_min_m:g} a {p.travel_max_m:g} m",ha="center",fontsize=9)
    ax.text(0,-1.5,f"Capacidade útil: {p.capacity_t:g} t  |  carga operacional: {p.operating_payload_t:g} t\n"
        f"Talha/trole: {p.trolley_hoist_mass_kg:g} kg  |  bloco/acessórios retidos: {p.retained_suspended_mass_kg:g} kg",
        fontsize=9,va="top")
    ax.text(L,-.32,"s →",ha="right",fontsize=10)
    ax.set_title(f"Elevação: contato inferior; posição desenhada a={a:g} m",loc="left",fontsize=11)
    ax.set_xlim(-.3,L+.3);ax.set_ylim(-1.95,1.2);ax.axis("off")
    b,d,tf,tw=s.bf_mm,s.d_mm,s.tf_mm,s.tw_mm
    for rect in ((-b/2,0,b,tf),(-tw/2,tf,tw,d-2*tf),(-b/2,d-tf,b,tf)):
        cs.add_patch(Rectangle(rect[:2],rect[2],rect[3],fc="#d3e1e7",ec=blue,lw=1.2))
    contact=b/2-p.edge_to_contact_mm
    root=s.root_radius_mm if s.fabrication=="rolled" else math.sqrt(2)*p.weld_throat_mm
    clearance=contact-(tw/2+root)
    radius=max(2.,min(12.,p.edge_to_contact_mm*.45,clearance*.45))
    for sign in (-1,1):
        y=sign*contact
        cs.add_patch(Circle((y,tf+radius),radius,fc=orange,ec="black",lw=.7))
        cs.plot(y,tf,"o",color="black",ms=2)
        cs.annotate("",xy=(y,tf),xytext=(y,tf+2*radius+45),arrowprops=dict(arrowstyle="->",color=orange))
    cs.annotate("",xy=(contact,-23),xytext=(b/2,-23),arrowprops=dict(arrowstyle="<->"))
    cs.text((contact+b/2)/2,-38,f"n={p.edge_to_contact_mm:g} mm",ha="center",fontsize=8)
    cs.annotate("",xy=(tw/2,-64),xytext=(contact,-64),arrowprops=dict(arrowstyle="<->"))
    cs.text((contact+tw/2)/2,-82,f"à face da alma={contact-tw/2:g} mm",ha="center",fontsize=8)
    cs.text(-b/2,d+20,f"d={d:g}; bf={b:g}; tw={tw:g}; tf={tf:g} mm",fontsize=8)
    cs.annotate("",xy=(b/2+38,d/2),xytext=(0,d/2),arrowprops=dict(arrowstyle="->"))
    cs.text(b/2+40,d/2+3,"y",fontsize=9)
    cs.annotate("",xy=(0,d/2+60),xytext=(0,d/2),arrowprops=dict(arrowstyle="->"))
    cs.text(7,d/2+60,"z",fontsize=9)
    cs.text(0,-122,"Rodas simbólicas, sem banda/diâmetro de catálogo.\nContato na face superior da mesa inferior; s fora do plano.",ha="center",fontsize=8)
    cs.set_title("Seção e contatos inferiores",loc="left",fontsize=11)
    cs.set_aspect("equal");cs.set_xlim(-b/2-25,b/2+55);cs.set_ylim(-145,d+60);cs.axis("off")
    return figure_bytes(fig,format)


def diagram_figure(case,format="png"):
    data=case["diagram"];rows=data["rows"]
    fig,axes=plt.subplots(3,2,figsize=(10,7),layout="constrained")
    items=(("Mx_knm","Momento forte Mx (kN·m)"),("My_knm","Momento fraco My (kN·m)"),
        ("Vy_kn","Cortante vertical Vy (kN)"),("Vx_kn","Cortante horizontal Vx (kN)"),
        ("N_kn","Normal N (kN), tração positiva"),("T_knm","Torção T (kN·m), convenção LRO"))
    for ax,(key,label) in zip(axes.flat,items):
        ax.plot([r["position_m"] for r in rows],[r[key] for r in rows],color="#24556b",lw=1.6)
        ax.axhline(0,color="#999999",lw=.5);ax.set_title(label,fontsize=10,loc="left");ax.set_xlabel("s (m)",fontsize=9);ax.grid(alpha=.2);ax.tick_params(labelsize=8)
    fig.suptitle(f"Estado concomitante  |  {family_label(case['case']['family'])}  |  a = {data['translation_m']:.4f} m",fontsize=12)
    return figure_bytes(fig,format)


def deflection_figure(case,format="png"):
    data=case["deflection_diagram"];rows=data["rows"]
    fig,axes=plt.subplots(1,2,figsize=(10,3),layout="constrained")
    for ax,key,label in zip(axes,("vertical_mm","horizontal_mm"),("Flecha vertical (mm), positiva para baixo","Deslocamento lateral (mm), positivo +y")):
        ax.plot([r["position_m"] for r in rows],[r[key] for r in rows],color="#24556b",lw=1.8)
        ax.set_title(label,fontsize=10,loc="left");ax.set_xlabel("s (m)");ax.grid(alpha=.2);ax.axhline(0,color="#999",lw=.5)
    fig.suptitle(f"{family_label(case['case']['family'])}  |  a = {data['translation_m']:.4f} m",fontsize=11)
    return figure_bytes(fig,format)


def envelope_figure(case,format="png"):
    data=case['spatial_envelope'];rows=data['rows']
    fig,axes=plt.subplots(3,1,figsize=(10,7),layout='constrained')
    for ax,key,label in zip(axes,('Mx_knm','Vy_kn','vertical_mm'),('Momento forte Mx (kN·m)','Cortante vertical Vy (kN)','Flecha vertical (mm)')):
        xs=[r['position_m'] for r in rows];lo=[r[key]['min'] for r in rows];hi=[r[key]['max'] for r in rows]
        ax.fill_between(xs,lo,hi,color='#d3e1e7',alpha=.8)
        ax.plot(xs,hi,color='#24556b',lw=1.4,label='Máximo amostrado');ax.plot(xs,lo,color='#6d8793',lw=1.1,label='Mínimo amostrado')
        ax.set_title(label,loc='left',fontsize=10);ax.set_xlabel('s (m)');ax.grid(alpha=.2)
    axes[0].legend(fontsize=8,loc='upper right')
    fig.suptitle('Envoltória espacial amostrada | '+family_label(case['case']['family']),fontsize=12)
    return figure_bytes(fig,format)


def torsion_figure(case,format="png"):
    rows=case['diagram']['rows']
    fig,axes=plt.subplots(2,2,figsize=(10,5.5),layout='constrained')
    for key,label in (('T_knm','T total'),('Tsv_knm','Saint-Venant'),('Tw_knm','Empenamento')):
        axes[0,0].plot([r['position_m'] for r in rows],[r[key] for r in rows],lw=1.3,label=label)
    axes[0,0].set_title('Torques (kN·m)',loc='left',fontsize=10);axes[0,0].legend(fontsize=8)
    for ax,key,label in ((axes[0,1],'B_knm2','Bimomento B (kN·m²)'),(axes[1,0],'theta_mrad','Rotação θ (mrad)')):
        ax.plot([r['position_m'] for r in rows],[r[key] for r in rows],color='#24556b',lw=1.4);ax.set_title(label,loc='left',fontsize=10)
    for ax in (axes[0,0],axes[0,1],axes[1,0]):ax.set_xlabel('s (m)');ax.grid(alpha=.2);ax.axhline(0,color='#999',lw=.5)
    axes[1,1].axis('off');axes[1,1].text(0,.9,'Resposta diagnóstica concomitante.\nNão é envoltória nem verificação resistente de torção.\nGarfos extremos; empenamento livre.\nConvenção LRO: θ positivo de +z para +y.',va='top',fontsize=10,linespacing=1.7)
    fig.suptitle(f"Torção elástica | a={case['diagram']['translation_m']:.4f} m",fontsize=12)
    return figure_bytes(fig,format)
