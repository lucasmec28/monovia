"""Human labels only; persisted technical identifiers remain unchanged."""
FAMILIES={
    'nominal_deflection':'Flecha nominal L/500',
    'NBR_I':'Operação NBR 10084/8400',
    'FAT8400':'Fadiga NBR 8400',
    'ULS8800':'ELU NBR 8800',
    'operating_service':'Operação sem impacto',
}
REGIONS={'top_flange':'mesa superior','bottom_flange':'mesa inferior','web':'alma',
    'upper_flange':'mesa superior','lower_flange':'mesa inferior',
    'left':'esquerda','right':'direita','bottom':'face inferior','top':'face superior'}

def family_label(value):return FAMILIES.get(value,value)
def region_label(value):
    for raw,label in REGIONS.items():value=value.replace(raw,label)
    return value
