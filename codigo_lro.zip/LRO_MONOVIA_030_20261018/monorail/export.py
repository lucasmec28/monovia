"""Word and JSON exports: failed criteria are exportable; stale results are not."""
from io import BytesIO
import json
from docx import Document
from docx.shared import Inches,Pt,RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.enum.table import WD_TABLE_ALIGNMENT,WD_CELL_VERTICAL_ALIGNMENT
from .analysis import assert_current_result
from .figures import schematic,diagram_figure,deflection_figure
from .labels import family_label,region_label

LABELS={"PASS":"Atende no domínio","FAIL":"Não atende","BOUND_EXCEEDED":"Limite conservador excedido","PENDING":"Pendente","OUT_OF_SCOPE":"Fora do escopo"}


def number(v,digits=4):
    return "—" if v is None else f"{v:.{digits}g}"


def _table(doc,headers,rows,widths=None):
    table=doc.add_table(rows=1,cols=len(headers));table.alignment=WD_TABLE_ALIGNMENT.CENTER;table.autofit=False
    for i,h in enumerate(headers):table.rows[0].cells[i].text=str(h)
    for row in rows:
        cells=table.add_row().cells
        for cell,value in zip(cells,row):cell.text=str(value)
    for ri,row in enumerate(table.rows):
        trPr=row._tr.get_or_add_trPr()
        if ri==0:
            repeat=OxmlElement('w:tblHeader');trPr.append(repeat)
        cant=OxmlElement('w:cantSplit');trPr.append(cant)
        for ci,cell in enumerate(row.cells):
            if widths:cell.width=Inches(widths[ci])
            cell.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
            tcPr=cell._tc.get_or_add_tcPr();borders=OxmlElement('w:tcBorders')
            for tag in ('top','left','bottom','right'):
                el=OxmlElement('w:'+tag);el.set(qn('w:val'),'single');el.set(qn('w:sz'),'4');el.set(qn('w:color'),'D9D9D9');borders.append(el)
            tcPr.append(borders)
            shade=OxmlElement('w:shd');shade.set(qn('w:fill'),'1F4D60' if ri==0 else ('F2F5F7' if ri%2==0 else 'FFFFFF'));tcPr.append(shade)
            margins=OxmlElement('w:tcMar')
            for edge in ('top','left','bottom','right'):
                el=OxmlElement('w:'+edge);el.set(qn('w:w'),'85');el.set(qn('w:type'),'dxa');margins.append(el)
            tcPr.append(margins)
            for paragraph in cell.paragraphs:
                paragraph.paragraph_format.space_after=Pt(2);paragraph.paragraph_format.space_before=Pt(2)
                for run in paragraph.runs:
                    run.font.size=Pt(9)
                    if ri==0:run.font.bold=True;run.font.color.rgb=RGBColor(255,255,255)
    doc.add_paragraph().paragraph_format.space_after=Pt(2)
    return table


def export_json(project,result):
    assert_current_result(project,result)
    return json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False).encode('utf-8')


def export_docx(project,result):
    assert_current_result(project,result)
    p=project;r=result;doc=Document();sec=doc.sections[0]
    sec.page_width=Inches(8.5);sec.page_height=Inches(11)
    sec.top_margin=sec.bottom_margin=Inches(.65);sec.left_margin=sec.right_margin=Inches(.7)
    for name in ('Normal','Title','Subtitle','Heading 1','Heading 2','Heading 3'):
        style=doc.styles[name];style.font.name='Arial';style.font.color.rgb=RGBColor(0,0,0)
        ppr=style.element.find(qn('w:pPr'))
        if ppr is not None:
            for border in list(ppr.findall(qn('w:pBdr'))):ppr.remove(border)
    doc.styles['Normal'].font.size=Pt(10)
    doc.styles['Normal'].paragraph_format.space_after=Pt(6)
    doc.styles['Title'].font.size=Pt(22);doc.styles['Heading 1'].font.size=Pt(15);doc.styles['Heading 2'].font.size=Pt(11)
    doc.core_properties.title='Memória de cálculo de monovia reta';doc.core_properties.author=p.responsible or 'LRO Monovia'
    doc.add_paragraph('Memória de cálculo de monovia reta','Title')
    doc.add_paragraph(f'{p.project_name} | {p.member_name}','Subtitle')
    doc.add_paragraph(('EXEMPLO ILUSTRATIVO. ' if p.demonstration else '')+r['summary']+'. Os critérios calculados não equivalem à aprovação integral da instalação. As pendências e os limites de aplicação estão discriminados nesta memória.')
    doc.add_paragraph(f"Responsável informado: {p.responsible or 'não informado'}. Cálculo UTC: {r['calculated_at_utc'][:19]}. Revisão 0.1.0.")
    doc.add_paragraph('Modelo físico e dados principais','Heading 1')
    doc.add_picture(BytesIO(schematic(p)),width=Inches(7.05))
    _table(doc,['Entrada','Valor','Origem ou regra'],[
        ('Vão e apoios',f'{p.span_m:g} m; biapoiada, garfos extremos',p.restraint_source),
        ('Perfil',p.section.name,p.section.property_source),
        ('Material',f'fy {p.material.fy_mpa:g}; fu {p.material.fu_mpa:g}; E {p.material.E_mpa:g} MPa',p.material.specification),
        ('Peso próprio',f"{r['self_weight_kn_m']:.5f} kN/m",p.section_mass_source or 'Três retângulos + quatro raios circulares para massa; sem crédito de raio na rigidez'),
        ('Capacidade e operação',f'{p.capacity_t:g} t nominal; {p.operating_payload_t:g} t operante',p.equipment_source),
        ('Massas separadas',f'Talha/trole {p.trolley_hoist_mass_kg:g} kg; retida {p.retained_suspended_mass_kg:g} kg','Massa retida não é somada ao peso do equipamento nem duplicada na carga útil'),
        ('Viagem do primeiro eixo',f'{p.travel_min_m:g} a {p.travel_max_m:g} m',p.travel_source),
        ('Ação permanente extra',f'{p.extra_dead_kn_per_m:g} kN/m',p.extra_dead_source)],widths=[1.25,2.15,3.65])
    doc.add_paragraph('Eixos longitudinais e ações características nos contatos','Heading 2')
    _table(doc,['Eixo','Offset m','Fração G','Fração Q e B','Hx kN','Hy kN'],[(s.id,number(s.offset_m),number(s.equipment_share),number(s.suspended_share),number(s.longitudinal_kn),number(s.transverse_kn)) for s in p.stations],widths=[1.,1.,1.,1.4,1.3,1.35])
    doc.add_paragraph('Cada eixo representa duas rodas opostas. As forças verticais individuais são metade da força do par somente pela hipótese de simetria explicitamente adotada. Hx e Hy da tabela são totais por par e já devem conter a dinâmica horizontal pertinente. Fonte: '+p.wheel_distribution_source+'; '+p.horizontal_action_source)
    doc.add_paragraph('Hipóteses e classificação','Heading 1')
    for note in r['limitations']:doc.add_paragraph(note,style='List Bullet')
    doc.add_paragraph(f"Grupo do equipamento: {p.equipment_group}. HC/HD: {p.hoist_class}/{p.drive_class}. Ψ = {r['dynamics']['psi']:.5g}. Fonte: {p.classification_source}. {r['dynamics']['source']}")
    doc.add_paragraph(f"CMAA: {p.cmaa_class}; EN: {p.en_classification}; componente para fadiga: {p.fatigue_group}. Não há equivalência automática entre essas classificações. Categoria de fadiga 8800 registrada: {p.fatigue_category}; não usada para converter grupo E.")
    plan=r.get('resistance_lengths')
    plan_text=(f"FLT adota comprimento máximo {plan['lateral_torsional_mm']/1000:g} m entre garfos nominais em {[x/1000 for x in plan['fork_positions_mm']]} m; Cb=1. Comprimentos forte e torsional permanecem integrais. Contenções inferiores e superiores sem coincidência central não recebem crédito."
        if plan else 'Lb integral do vão, Cb=1; contenções cadastradas não recebem crédito neste modo.')
    if plan:plan_text+=' Os garfos nominais exigem duas restrições independentes em alturas distintas, centro de cisalhamento e mesa superior, na mesma posição longitudinal. Rigidez, resistência e ligação efetivas são requisitos do detalhe, não verificações deste módulo.'
    doc.add_paragraph(f"Travamentos declarados: superior {p.upper_braces_m}; inferior {p.lower_braces_m}; centro de cisalhamento {p.lateral_axis_braces_m}. A resposta global não recebe apoios adicionais. "+plan_text)
    doc.add_paragraph('Bases de ação e combinações','Heading 1')
    doc.add_paragraph('A resistência nominal NBR 10084 e NBR 8400 usa o caso I próprio. O complemento NBR 8800 usa ELU distinto. Fadiga usa caso I sem o coeficiente de amplificação Mₓ do grupo A; isso não remove o momento fletor forte. A flecha L/500 usa exclusivamente a capacidade nominal útil, sem G nem impacto. Nenhuma base é reutilizada como outra.')
    case_index={case['case']['id']:f'C{i+1:02}' for i,case in enumerate(r['cases'])}
    _table(doc,['Caso','Família','Estado','G suporte','G talha','Q útil','B retida','H'],[
        (case_index[c['case']['id']],family_label(c['case']['family']),'carga' if c['case']['loaded'] else 'vazia',*[number(c['case'][k],3) for k in ('support_factor','equipment_factor','payload_factor','retained_factor','horizontal_factor')]) for c in r['cases']],widths=[.55,1.2,.65,.85,.85,.85,.85,1.25])
    sources=list(dict.fromkeys(c['case']['source'] for c in r['cases']))
    for source in sources:doc.add_paragraph(source,style='List Bullet')
    doc.add_paragraph('Resultados e equilíbrio','Heading 1')
    _table(doc,['Caso','Mx majorante kN m','Vy majorante kN','Flecha amostrada mm','Erro flecha mm','Convergiu'],[
        (case_index[c['case']['id']],number(next(x['upper_bound'] for x in c['maxima'] if x['metric']=='Mx_knm')),
         number(next(x['upper_bound'] for x in c['maxima'] if x['metric']=='Vy_kn')),
         number(next(x['absolute_value'] for x in c['maxima'] if x['metric']=='vertical_mm')),
         number(next(x['discretization_error_bound'] for x in c['maxima'] if x['metric']=='vertical_mm')),
         'sim' if c['converged'] else 'não') for c in r['cases']],widths=[.55,1.3,1.2,1.4,1.5,1.2])
    doc.add_paragraph(f"Resíduo máximo de equilíbrio: {max(c['max_equilibrium_residual'] for c in r['cases']):.3g} nas respectivas unidades de força/momento. O controle numérico atingiu a tolerância em todos os casos: {'sim' if r['numerical_converged'] else 'não; majorantes de discretização permanecem disponíveis'}. Um resíduo pequeno não certifica resistência.")
    governing=max((c for c in r['cases'] if c['case']['family']=='ULS8800'),key=lambda c:next(x['upper_bound'] for x in c['maxima'] if x['metric']=='Mx_knm'))
    doc.add_picture(BytesIO(diagram_figure(governing)),width=Inches(7.05))
    doc.add_paragraph('Eixos físicos: s longitudinal, y lateral, z para cima. Nos aliases legados, Mx é o momento forte em torno de y, My o momento fraco em torno de z, Vy o cortante vertical z e Vx o cortante lateral y. Esses nomes técnicos não redefinem os eixos físicos. Convenções internas: Mx positivo comprime a mesa superior, My positivo traciona sua borda direita; N positivo em tração. O módulo torsional LRO define θ positivo movendo +z para +y, oposto à regra da mão direita em +s. T e B dos diagramas seguem essa mesma convenção, sem conversão implícita para outro solver.')
    nominal=next(c for c in r['cases'] if c['case']['family']=='nominal_deflection')
    doc.add_picture(BytesIO(deflection_figure(nominal)),width=Inches(7.05))
    doc.add_paragraph('Reações físicas nos apoios','Heading 2')
    rrows=[]
    for side in ('left','right'):
        key='R_z_'+side+'_kn'
        item=max(((c['physical_reaction_extrema'][key]['max'],c) for c in r['cases'] if c['case']['family']=='ULS8800'),key=lambda pair:pair[0]['value'])
        witness,c=item;co=witness['support_on_beam']
        rrows.append(('Esquerdo' if side=='left' else 'Direito',case_index[c['case']['id']],number(witness['translation_m']),number(co['R_z_left_kn']),number(co['R_z_right_kn']),number(co['R_s_left_kn'])))
    _table(doc,['Apoio governante','Caso','a m','Rz esquerdo kN','Rz direito kN','Rs esquerdo kN'],rrows,widths=[1.4,.55,.7,1.5,1.5,1.5])
    doc.add_paragraph('Valores físicos da ação do apoio SOBRE a viga, nos eixos s/y/z: Rz é positivo para cima e Rs para a direita. Cada linha preserva o mesmo caso e posição. A carga transmitida pela viga à estrutura receptora é o NEGATIVO desse vetor. Não somar extremos de linhas diferentes.')
    doc.add_paragraph('Os oito componentes físicos concomitantes, seus extremos e posições estão na interface e no JSON. A auditoria conserva também as ordenadas do kernel: Ry físico é o negativo de horizontal; o momento físico em +s pela mão direita é o negativo do torque LRO. As ordenadas legadas não são reutilizadas silenciosamente como vetores físicos.')
    doc.add_paragraph('Quadro de verificação','Heading 1')
    _table(doc,['Critério','Resultado','Demanda','Resistência','Utilização'],[(region_label(c['title']),LABELS[c['status']],number(c['demand'])+' '+c['unit'],number(c['capacity'])+' '+c['unit'],number(c['utilization'])) for c in r['checks']],widths=[2.25,1.6,1.15,1.15,.8])
    doc.add_paragraph('“Limite conservador excedido” exige refinamento ou alteração, mas não prova falha física. “Não atende” decorre de estado testemunhado no domínio do critério. “Pendente” e “fora do escopo” significam ausência de conclusão, não aprovação nem reprovação do perfil.')
    doc.add_paragraph('Desenvolvimento e referência dos critérios','Heading 1')
    refmap={source:f'R{i+1}' for i,source in enumerate(dict.fromkeys(c['source'] for c in r['checks'] if c['source']))}
    methods={}
    for c in r['checks']:
        methods.setdefault((c['source'],c['formula'],c['reason']),[]).append(c)
    for (source,formula,reason),group in methods.items():
        doc.add_paragraph(' / '.join(region_label(c['title']) for c in group),'Heading 2')
        if formula:doc.add_paragraph(formula)
        if reason:doc.add_paragraph(reason)
        if source:doc.add_paragraph('Referência '+refmap[source]+'. Resultados e utilizações constam do quadro de verificação.')
    doc.add_paragraph('Referências por mecanismo','Heading 2')
    for source,reference in refmap.items():doc.add_paragraph(reference+'  '+source)
    doc.add_paragraph('Encaminhamento','Heading 1')
    doc.add_paragraph(r['summary']+'. O atendimento parcial não libera a instalação. Conferir dados do fabricante, ações/eventos, detalhe de fadiga, contato/desgaste, apoios e ligações, além de todas as pendências identificadas, com o responsável técnico.')
    if p.notes:doc.add_paragraph('Notas do projeto: '+p.notes)
    doc.add_page_break()
    doc.add_paragraph('Apêndice técnico: rastreabilidade','Heading 1')
    doc.add_paragraph('Núcleo reaproveitado da revisão LRO de 17 de outubro de 2026. Os códigos internos e todos os recibos de cada critério são preservados no JSON de resultados.')
    for label,value in [('ZIP de origem SHA-256',r['source']['original_zip_sha256']),('Assinatura das entradas',r['project_signature']),('Assinatura do código',r['source']['fingerprint'])]:
        doc.add_paragraph(label,'Heading 2');paragraph=doc.add_paragraph(value)
        for run in paragraph.runs:run.font.size=Pt(9)
    data=BytesIO();doc.save(data);return data.getvalue()
