"""Monovia reta: adaptador do núcleo LRO de 17/10/2026, sem catálogo inventado."""
__version__ = "0.1.0"

