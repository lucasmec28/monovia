"""Bounded resistance adapters for a straight, unstiffened monorail beam.

No legacy equation is replaced. Forces have already been combined by the
caller. Axes follow lro_beams: Mx>0 compresses the upper flange, My>0 tensions
its right edge, dMx/dx=Vy. The inherited recovery uses x along the member,
y lateral and z upward, hence My_recovery=-Mx, Mz_recovery=-My, Fz=-Vy.

PASS always means the named conditional criterion, never whole-design approval.
A failed upper bound is BOUND_EXCEEDED, not evidence of physical failure.
CMAA70/74 are not a direct certification route for a fixed monorail.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
from itertools import product
import math
from typing import Any, Mapping, Sequence

from lro_beams.model import Material, Section
from lro_beams.geometry import section_properties
from lro_beams.engine import (ltb_resistance, vertical_shear_resistance,
    horizontal_shear_resistance, SOURCE_BENDING, SOURCE_SHEAR)
from lro_beams.stress_8400 import (Fatigue8400Input, calculate_fatigue_8400,
    elastic_allowables_8400, equivalent_plane_stress)
from underslung_runway_candidate.local_flange.kernel import (
    Geometry, Action, local_stresses, close_wheel_stresses, DomainError)
from underslung_runway_candidate.section_stress.recovery import (
    ISection, Resultants, bottom_flange_points, recover_bottom_flange,
    combine_local)

STATUSES = frozenset({'PASS', 'FAIL', 'BOUND_EXCEEDED', 'PENDING', 'OUT_OF_SCOPE'})
LOCAL_SOURCE = ('ABNT NBR 10084:2020 §9.1.4, Tabela 2; '
    'ABNT NBR 8400-2:2019 corrigida 2022 §5.2.1.1–3; '
    'modelo nominal correspondente EN 1993-6:2007+AC:2009 §5.8')
FATIGUE_SOURCE = 'ABNT NBR 8400-2:2019 corrigida 2022 §5.6 e Anexo D'
COMPONENTS = ('N_kn', 'Mx_knm', 'My_knm', 'Vy_kn', 'Vx_kn', 'T_knm')


@dataclass
class Check:
    id: str
    title: str
    status: str
    demand: float | None = None
    capacity: float | None = None
    utilization: float | None = None
    unit: str = ''
    reason: str = ''
    source: str = ''
    formula: str = ''
    values: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self):
        if self.status not in STATUSES:
            raise ValueError('Unknown check status: ' + str(self.status))

    def to_dict(self):
        return asdict(self)


def _number(value, name, *, positive=False, nonnegative=False):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        raise ValueError(name + ': número finito obrigatório')
    if positive and value <= 0 or nonnegative and value < 0:
        raise ValueError(name + ': valor fora do domínio')
    return float(value)


def _section(section, material):
    if not isinstance(section, Section) or not isinstance(material, Material):
        raise ValueError('Section e Material legados são obrigatórios')
    for name in ('d_mm', 'bf_mm', 'tw_mm', 'tf_mm'):
        _number(getattr(section, name), name, positive=True)
    for name in ('root_radius_mm', 'bottom_bf_mm', 'bottom_tf_mm'):
        _number(getattr(section, name), name, nonnegative=True)
    for name in ('fy_mpa', 'fu_mpa', 'E_mpa', 'gamma_a1'):
        _number(getattr(material, name), name, positive=True)
    if material.fu_mpa < material.fy_mpa:
        raise ValueError('fu inferior a fy')
    if not section.doubly_symmetric:
        raise ValueError('Domínio inicial exige I duplamente simétrico')
    if section.d_mm <= 2 * (section.tf_mm + section.root_radius_mm) or section.bf_mm <= section.tw_mm:
        raise ValueError('Geometria I degenerada')
    if section.property_basis != 'rectangles':
        raise ValueError('Propriedades de catálogo não validadas por este adaptador; usar retângulos explícitos')
    g = section_properties(section)
    if any(not math.isfinite(v) or v <= 0 for v in g.to_dict().values()):
        raise ValueError('Propriedades derivadas inválidas')
    if g.Ix_mm4 <= g.Iy_mm4:
        raise ValueError('Eixo forte exige Ix > Iy')
    return g


def _state(state):
    if not isinstance(state, Mapping):
        raise ValueError('Estado deve ser um mapping')
    for name in COMPONENTS:
        if name not in state:
            raise ValueError('Componente ausente não equivale a zero: ' + name)
        _number(state[name], name)
    evidence = state.get('evidence')
    if evidence not in ('sampled_state', 'upper_bound'):
        raise ValueError('Identificar evidence=sampled_state ou upper_bound')
    if evidence == 'upper_bound':
        if any(state[name] < 0 for name in COMPONENTS):
            raise ValueError('Upper bounds de resultantes são magnitudes não negativas')
        if state.get('envelope_qualified') is not True:
            raise ValueError('Cobertura do limite superior ainda não qualificada')
    return evidence


def _ratio(id_, title, demand, capacity, *, evidence, unit, source, formula, reason='', values=None):
    demand = abs(_number(demand, 'demanda'))
    capacity = _number(capacity, 'capacidade', positive=True)
    ratio = demand / capacity
    ok = demand <= capacity or math.isclose(demand, capacity, rel_tol=1e-12, abs_tol=1e-12)
    status = 'PASS' if ok else ('BOUND_EXCEEDED' if evidence == 'upper_bound' else 'FAIL')
    return Check(id_, title, status, demand, capacity, ratio, unit, reason, source, formula,
        dict(values or {}, evidence=evidence, actual_failure_proven=status == 'FAIL',
             whole_design_approved=False))


def global_checks(section: Section, material: Material, span_m: float,
                  states: Sequence[Mapping[str, Any]], *, forks_confirmed: bool = False,
                  actions_qualified: bool = False,
                  load_application_qualified: bool = False, nominal_plan=None) -> list[Check]:
    """NBR8800 supplement. Cb=1; Lb=span unless a typed legacy plan is given.

    The optional plan affects resistance lengths only. It never changes forces,
    physical supports, reactions or deflections and does not qualify real braces.

    State components are all mandatory. Upper bounds can prove sufficient
    resistance, but their exceedance cannot prove failure. Independent moment
    maxima may enter the conservative biaxial sum ONLY as an upper bound.
    Explicit action_basis='nbr8800_uls' and traceable action_source/factors_source
    are mandatory. Flags are caller/project qualifications, not source evidence.
    """
    try:
        g = _section(section, material)
        _number(span_m, 'span_m', positive=True)
        ltb_span_m = span_m
        nominal_evidence = None
        governing_interval = (0., span_m*1000.)
        if nominal_plan is not None:
            from lro_beams.autonomous_nominal_lengths import NominalResistancePlan
            if type(nominal_plan) is not NominalResistancePlan:
                raise ValueError('Plano nominal resistente tipado obrigatório')
            nominal_plan.__post_init__()
            if not math.isclose(nominal_plan.analysis_span_mm,span_m*1000.,rel_tol=1e-12,abs_tol=1e-9):
                raise ValueError('Plano nominal não pertence ao mesmo vão físico')
            governing_interval = max(nominal_plan.ltb_intervals_mm,key=lambda pair:pair[1]-pair[0])
            ltb_span_m = (governing_interval[1]-governing_interval[0])/1000.
            nominal_evidence = nominal_plan.evidence()
    except (ValueError, ArithmeticError, TypeError) as exc:
        return [Check('global/domain', 'Domínio global', 'OUT_OF_SCOPE', reason=str(exc))]
    if not states:
        return [Check('global/actions', 'Ações globais', 'PENDING', reason='Nenhum estado calculado fornecido.')]
    flange_limit = .38 * math.sqrt(material.E_mpa / material.fy_mpa)
    web_limit = 3.76 * math.sqrt(material.E_mpa / material.fy_mpa)
    compact_f, compact_w = g.flange_lambda <= flange_limit, g.web_lambda <= web_limit
    checks = [
        Check('global/compact_flange', 'Domínio compacto da mesa', 'PASS' if compact_f else 'OUT_OF_SCOPE',
            g.flange_lambda, flange_limit, g.flange_lambda/flange_limit, 'b/t',
            'Excedência exige outro ramo de FLM, não significa ruptura.', SOURCE_BENDING,
            'λf=bf/(2tf); λp=0,38√(E/fy)'),
        Check('global/compact_web', 'Domínio compacto da alma', 'PASS' if compact_w else 'OUT_OF_SCOPE',
            g.web_lambda, web_limit, g.web_lambda/web_limit, 'h/tw',
            'Excedência exige outro ramo de FLA, não significa ruptura.', SOURCE_BENDING,
            'λw=h/tw; λp=3,76√(E/fy)')]
    vertical = vertical_shear_resistance(section, g, material)
    horizontal = horizontal_shear_resistance(section, material)
    minor_capacity = min(material.fy_mpa*g.Zy_mm3, 1.5*material.fy_mpa*g.Wy_mm3)/material.gamma_a1/1e6
    ltb = ltb_resistance(g, material, ltb_span_m, 1.) if compact_f and compact_w else None
    if ltb is not None and nominal_evidence is not None:
        ltb.update(nominal_length_plan=nominal_evidence, governing_interval_mm=governing_interval,
            physical_analysis_span_m=span_m, resistance_only=True)
    for index, state in enumerate(states):
        prefix = 'global/' + str(state.get('id', index))
        try:
            evidence = _state(state)
        except ValueError as exc:
            checks.append(Check(prefix+'/input', 'Estado global', 'PENDING', reason=str(exc)))
            continue
        missing = []
        if not actions_qualified or state.get('action_basis') != 'nbr8800_uls':
            missing.append('Ações ELU NBR8800 ainda não qualificadas; não converter casos NBR8400/CMAA')
        if not state.get('action_source') or not state.get('factors_source'):
            missing.append('Fonte de ações e ledger de fatores obrigatórios')
        if missing:
            checks.append(Check(prefix+'/actions', 'Base de ações globais', 'PENDING', reason='; '.join(missing)))
            continue
        unsupported = abs(state['N_kn']) > 0 or abs(state['T_knm']) > 0
        if unsupported:
            checks.append(Check(prefix+'/axial_torsion', 'Axial, torção e interação', 'OUT_OF_SCOPE',
                reason='N ou T não nulo. As resistências isoladas abaixo não concluem a interação.',
                values={k: state[k] for k in ('N_kn', 'T_knm')}))
        common = dict(evidence=evidence)
        major_evidence = 'upper_bound' if nominal_evidence is not None else evidence
        ltb_ok = ltb is not None and ltb['lambda_r'] > ltb['lambda_p']
        if not compact_f or not compact_w:
            checks.append(Check(prefix+'/major', 'Flexão forte e FLT', 'OUT_OF_SCOPE',
                reason='Seção não compacta fora do ramo herdado; não atribuir capacidade plástica.', source=SOURCE_BENDING))
        elif not forks_confirmed or not load_application_qualified:
            checks.append(Check(prefix+'/major', 'Flexão forte e FLT', 'PENDING',
                reason='Confirmar garfos extremos efetivos e domínio da carga abaixo do centro de cisalhamento; sem crédito estabilizante.',
                source=SOURCE_BENDING, values={'Cb': 1., 'Lb_m': ltb_span_m, 'nominal_length_plan': nominal_evidence}))
        elif not ltb_ok:
            checks.append(Check(prefix+'/major', 'Flexão forte e FLT', 'OUT_OF_SCOPE',
                reason='Sequência λp/λr do kernel não qualificada.', source=SOURCE_BENDING))
        else:
            checks.append(_ratio(prefix+'/major', 'Flexão forte com FLT', state['Mx_knm'], ltb['Mrd_knm'],
                evidence=major_evidence, unit='kN.m', source=SOURCE_BENDING,
                formula='ltb_resistance: MRd=min(Mn,Mpl,1,5Wxfy)/γa1; Cb=1; Lb=max(intervalos nominais)' if nominal_evidence is not None else 'ltb_resistance: MRd=min(Mn,Mpl,1,5Wxfy)/γa1; Cb=1; Lb=L',
                reason=('Plano resistente nominal herdado: centro rígido e mesa superior exatamente coincidentes; hipóteses de projeto, não apoios/reações físicos calculados. Excedência da resistência mínima não prova falha.' if nominal_evidence is not None else 'Garfos nos extremos; sem contenção intermediária nem crédito pela altura estabilizante da carga.'), values=ltb))
        if compact_f:
            checks.append(_ratio(prefix+'/minor', 'Flexão fraca', state['My_knm'], minor_capacity,
                **common, unit='kN.m', source=SOURCE_BENDING,
                formula='MRd,y=min(Zy fy;1,5 Wy fy)/γa1', reason='Capacidade isolada no domínio compacto.'))
        for axis, resistance, component in (('vertical', vertical, 'Vy_kn'), ('horizontal', horizontal, 'Vx_kn')):
            checks.append(_ratio(prefix+'/shear_'+axis, 'Cortante '+axis, state[component], resistance['Vrd_kn'],
                **common, unit='kN', source=SOURCE_SHEAR if axis == 'vertical' else 'ABNT NBR 8800:2024 §5.4.3.5',
                formula='Kernel herdado: VRd=(0,6Aw fy/γa1)×fator(λ,λp,λr)',
                reason='Resistência isolada. Sem crédito de enrijecedor.', values=resistance))
        if state['Vy_kn'] != 0 and state['Vx_kn'] != 0:
            checks.append(Check(prefix+'/biaxial_shear', 'Cisalhamento em duas direções', 'PENDING',
                reason='Dois cortantes não nulos: interação de tensões/estabilidade não encerrada pelas capacidades isoladas.',
                source='ABNT NBR 8800:2024 §5.5.1.3 e §5.5.2.3'))
        if state['Mx_knm'] != 0 and state['My_knm'] != 0 and not unsupported and ltb_ok and forks_confirmed and load_application_qualified:
            eta = abs(state['Mx_knm'])/ltb['Mrd_knm'] + abs(state['My_knm'])/minor_capacity
            checks.append(_ratio(prefix+'/biaxial', 'Flexão biaxial sem N e T', eta, 1.,
                evidence=major_evidence, unit='1', source='ABNT NBR 8800:2024 §5.5.1.2(b), N=0',
                formula='|Mx|/MRd,x + |My|/MRd,y ≤ 1',
                reason='Soma de máximos independentes é apenas limite superior.' if evidence == 'upper_bound' else 'Momentos concomitantes do mesmo estado.'))
    return checks


def _recovery_section(section, weld_throat_mm):
    return ISection(d_mm=section.d_mm, bf_mm=section.bf_mm, tf_mm=section.tf_mm,
        tw_mm=section.tw_mm, construction=section.fabrication,
        bottom_root_radius_mm=section.root_radius_mm,
        bottom_weld_throat_mm=weld_throat_mm)


def _resultants(s, state, *, overrides=None):
    raw = {k: state[k] for k in COMPONENTS}
    raw.update(overrides or {})
    return Resultants(N=raw['N_kn']*1000., My=-raw['Mx_knm']*1e6,
        Mz=-raw['My_knm']*1e6, Fy=raw['Vx_kn']*1000., Fz=-raw['Vy_kn']*1000.,
        B=0., Tsv=0., Tw=0., x=state['x_m']*1000., side=state.get('cut_side', 'right'),
        combination_id=str(state.get('id', 'state')), wheel_translation_mm=state['wheel_translation_m']*1000.,
        section_signature=s.signature, torsion_recovery='equilibrated')


def local_flange_checks(section: Section, material: Material,
        states: Sequence[Mapping[str, Any]], *, edge_to_contact_mm: float,
        weld_throat_mm: float = 0., equal_opposite_wheels_confirmed: bool = False,
        actions_qualified: bool = False, nominal_model_adopted: bool = False,
        base_material_confirmed: bool = False, high_ratio_route_confirmed: bool = False) -> list[Check]:
    """NBR10084+8400 nominal local/global elastic checks at 12 physical points.

    Each row needs all global components, x_m, wheel_translation_m,
    individual_wheel_kn, distance_to_end_mm, nearest_spacing_mm (or None with
    isolated_station_confirmed=True), action_basis='nbr8400_cases', nbr_case,
    action_source and factors_source. Signed concomitant samples can prove an
    exceedance at that position; they cannot establish full travel coverage.
    Qualified upper_bound rows instead enclose every component and wheel load.
    Interior model only; end cases remain PENDING. Close wheels are supported
    only as upper_bound with wheel_cluster_actions_kn, wheel_cluster_spacings_mm,
    cluster_complete_confirmed=True and optional nearest_external_spacing_mm.
    The cluster lists individual same-side wheels, never sums opposed wheels.
    """
    try:
        _section(section, material)
        s = _recovery_section(section, weld_throat_mm)
        geometry = Geometry(section.bf_mm, section.tw_mm, section.tf_mm, edge_to_contact_mm,
            section.fabrication, section.root_radius_mm, weld_throat_mm)
    except (ValueError, TypeError, ArithmeticError) as exc:
        return [Check('local/domain', 'Domínio local', 'OUT_OF_SCOPE', reason=str(exc), source=LOCAL_SOURCE)]
    if not states:
        return [Check('local/actions', 'Mesa inferior', 'PENDING', reason='Nenhum estado local fornecido.', source=LOCAL_SOURCE)]
    checks = []
    for index, state in enumerate(states):
        prefix = 'local/' + str(state.get('id', index))
        try:
            evidence = _state(state)
            for name in ('x_m', 'wheel_translation_m'):
                _number(state[name], name)
            _number(state['individual_wheel_kn'], 'individual_wheel_kn', nonnegative=True)
            _number(state['distance_to_end_mm'], 'distance_to_end_mm', nonnegative=True)
            if state['x_m'] < 0:
                raise ValueError('Seção física negativa')
            if state['N_kn'] != 0 or state['T_knm'] != 0:
                checks.append(Check(prefix+'/axial_torsion', 'Domínio local N=T=0', 'OUT_OF_SCOPE',
                    reason='N/T não nulos não foram removidos. Requer recuperação/estabilidade ampliada.',
                    values={k: state[k] for k in ('N_kn', 'T_knm')}, source=LOCAL_SOURCE))
                continue
            missing = []
            if not actions_qualified or state.get('action_basis') != 'nbr8400_cases':
                missing.append('Caso NBR8400 não qualificado; não converter ELU8800 ou CMAA')
            if not nominal_model_adopted or not base_material_confirmed:
                missing.append('Adotar modelo plano nominal e pontos de material base; contato/solda excluídos')
            if not state.get('action_source') or not state.get('factors_source'):
                missing.append('Fonte das ações/combinações e ledger de fatores ausentes')
            if material.fy_mpa/material.fu_mpa > .70 and not high_ratio_route_confirmed:
                missing.append('Ramo fy/fu>0,70 exige adoção explícita do aço de referência 360/510 MPa')
            if missing:
                checks.append(Check(prefix+'/qualification', 'Qualificação local', 'PENDING', reason='; '.join(missing), source=LOCAL_SOURCE))
                continue
            limits = elastic_allowables_8400(material.fy_mpa, material.fu_mpa, state.get('nbr_case', ''))
            action = Action(state['individual_wheel_kn']*1000., 'mechanical', 'mechanical', str(state['id']))
            cluster_actions = state.get('wheel_cluster_actions_kn')
            cluster_receipt = None
            if cluster_actions is not None:
                if evidence != 'upper_bound':
                    raise ValueError('Rodas próximas: somente caixa conservadora upper_bound; soma local não prova falha física')
                if state.get('cluster_complete_confirmed') is not True:
                    raise ValueError('Confirmar agrupamento completo de rodas longitudinais próximas, sem omissão')
                if not isinstance(cluster_actions,(list,tuple)) or len(cluster_actions)<2:
                    raise ValueError('Grupo próximo exige pelo menos duas cargas de rodas individuais do mesmo lado')
                spacings = state.get('wheel_cluster_spacings_mm')
                if not isinstance(spacings,(list,tuple)):
                    raise ValueError('Espaçamentos consecutivos reais do grupo obrigatórios')
                external = state.get('nearest_external_spacing_mm')
                if external is not None and _number(external,'nearest_external_spacing_mm',positive=True)<1.5*section.bf_mm:
                    raise ValueError('Roda externa próxima omitida do grupo')
                cluster = [Action(_number(load,'individual cluster wheel',nonnegative=True)*1000.,
                    'mechanical','mechanical',str(state['id'])) for load in cluster_actions]
                local = close_wheel_stresses(geometry,cluster,spacings,
                    distance_to_nearest_end_mm=state['distance_to_end_mm'],
                    symmetric_opposite_wheels_confirmed=equal_opposite_wheels_confirmed)
                cluster_receipt = dict(individual_wheel_actions_kn=list(cluster_actions),
                    consecutive_spacings_mm=list(spacings), nearest_external_spacing_mm=external,
                    simultaneous_same_ledger=True, complete_cluster=True,
                    opposite_wheels_double_counted=False, correlated_cancellation_credited=False,
                    source='EN 1993-6:2007+AC:2009 §5.8(8), superposição nominal conservadora de rodas próximas')
            else:
                local = local_stresses(geometry, action,
                    distance_to_nearest_end_mm=state['distance_to_end_mm'],
                    symmetric_opposite_wheels_confirmed=equal_opposite_wheels_confirmed,
                    nearest_longitudinal_spacing_mm=state.get('nearest_spacing_mm'),
                    isolated_longitudinal_station_confirmed=state.get('isolated_station_confirmed', False))
            if evidence == 'sampled_state':
                rows = combine_local(s, _resultants(s, state), edge_to_contact_mm,
                    individual_wheel_N=action.individual_wheel_N, wheel_station_mm=state['x_m']*1000.,
                    distance_to_nearest_end_mm=state['distance_to_end_mm'],
                    symmetric_opposite_wheels_confirmed=equal_opposite_wheels_confirmed,
                    nearest_longitudinal_spacing_mm=state.get('nearest_spacing_mm'),
                    isolated_longitudinal_station_confirmed=state.get('isolated_station_confirmed', False),
                    local_longitudinal_multiplier=.75)
                for row in rows:
                    values = dict(row, limits=limits, scope='Ponto nominal amostrado; não é cobertura contínua da translação.')
                    components = (row['sigma_x_mpa'], row['sigma_y_mpa'], row['tau_xy_mpa'])
                    checks.extend(_local_components(prefix+'/'+row['id'], components, limits, evidence, values))
            else:
                # Extract linear coefficients from the preserved recovery kernel.
                # Independent global/local signed boxes lose favorable correlation;
                # convex plane-stress criteria attain their maxima at box vertices.
                mags = {pt.id: [0., 0., 0.] for pt in bottom_flange_points(s, edge_to_contact_mm)}
                for key in ('Mx_knm', 'My_knm', 'Vy_kn', 'Vx_kn'):
                    overrides = {name: (1. if name == key else 0.) for name in COMPONENTS}
                    for row in recover_bottom_flange(s, _resultants(s, state, overrides=overrides), edge_to_contact_mm):
                        for n, component in enumerate(('global_sigma_x_mpa', 'global_sigma_y_mpa', 'tau_xy_mpa')):
                            mags[row['id']][n] += abs(row[component])*state[key]
                for pt in bottom_flange_points(s, edge_to_contact_mm):
                    lx, ly = local[pt.point]
                    sx, sy, tau = mags[pt.id]
                    sx += .75*abs(lx)
                    sy += abs(ly)
                    corners = list(product((-sx, sx), (-sy, sy), (-tau, tau)))
                    governing = max(corners, key=lambda c: equivalent_plane_stress(*c))
                    values = dict(point=asdict(pt), signed_component_intervals_mpa=[(-sx,sx),(-sy,sy),(-tau,tau)],
                        governing_box_vertex=governing, vertex_is_actual_state=False,
                        local_longitudinal_multiplier=.75, local_transverse_multiplier=1.,
                        close_wheel_cluster=cluster_receipt,
                        opposite_wheels_double_counted=False, actual_3d_tensor_complete=False,
                        scope='Limite nominal dos 12 pontos prescritos e de toda a cobertura declarada, não campo 3D.')
                    checks.extend(_local_components(prefix+'/'+pt.id, governing, limits, evidence, values))
        except (ValueError, KeyError, TypeError, ArithmeticError) as exc:
            checks.append(Check(prefix+'/domain', 'Estado local pendente', 'PENDING', reason=str(exc), source=LOCAL_SOURCE,
                values={'individual_wheel_kn': state.get('individual_wheel_kn'), 'evidence': state.get('evidence')}))
    return checks


def _local_components(prefix, components, limits, evidence, values):
    sx, sy, tau = components
    fd = limits['sigma_a_mpa']
    rows = (('sigma_x', 'Normal longitudinal', abs(sx), fd, 'σcx=σx,global+0,75σx,local; |σcx|≤σa'),
            ('sigma_y', 'Normal transversal', abs(sy), fd, 'σcy=σy,global+σy,local; |σcy|≤σa'),
            ('tau_xy', 'Cisalhamento no plano', abs(tau), limits['tau_a_mpa'], '|τxy|≤σa/√3'),
            ('equivalent', 'Tensão equivalente nominal', equivalent_plane_stress(sx,sy,tau), fd,
             'σeq=√(σcx²+σcy²−σcxσcy+3τxy²)≤σa'))
    return [_ratio(prefix+'/'+key, title, demand, capacity, evidence=evidence, unit='MPa',
        source=LOCAL_SOURCE, formula=formula, reason='Avaliação nominal parcial; contato, ligação e concentração real não cobertos.', values=values)
        for key,title,demand,capacity,formula in rows]


def fatigue_checks(histories: Sequence[Fatigue8400Input | Mapping[str, Any]] = (), *,
                   local_histories: Sequence[Fatigue8400Input | Mapping[str, Any]] = ()) -> list[Check]:
    """Reuse the inherited one-component fatigue route, never static ULS ranges.

    A mapping may additionally contain other_components_nonzero=True and
    evidence='upper_bound'. The former blocks uniaxial approval; the latter
    cannot be called an actual signed fatigue history and is rejected here.
    For supported planar interval envelopes use fatigue_plane_checks instead.
    """
    checks = []
    for scope, supplied in (('global', histories), ('local', local_histories)):
        if not supplied:
            checks.append(Check('fatigue/'+scope, 'Fadiga '+scope, 'PENDING', source=FATIGUE_SOURCE,
                reason='Faltam histórico assinado do mesmo ponto, detalhe, grupo/ciclos e ações de fadiga independentes; ELU não é histórico.'))
        for index, raw in enumerate(supplied):
            prefix = 'fatigue/'+scope+'/'+str(index)
            try:
                if isinstance(raw, Mapping):
                    row = dict(raw)
                    evidence = row.pop('evidence', 'sampled_state')
                    if row.pop('other_components_nonzero', False):
                        raise ValueError('Mais de uma componente relevante; interação de fadiga exige rota planar apropriada')
                    if evidence != 'sampled_state':
                        raise ValueError('Caixa de limites não é histórico temporal; usar fatigue_plane_checks')
                    data = Fatigue8400Input(**row)
                elif isinstance(raw, Fatigue8400Input):
                    data = raw
                else:
                    raise ValueError('Fatigue8400Input ou mapping explícito obrigatório')
                result = calculate_fatigue_8400(data)
                if result.get('checks'):
                    for c in result['checks']:
                        envelope = result['intermediates'].get('kappa', -1.) > 0
                        check = _ratio(prefix+'/'+c['id'], 'Fadiga '+scope+' · '+c['name'], c['demand'], c['capacity'],
                            evidence='upper_bound' if envelope else 'sampled_state', unit='MPa', source=c['source'],
                            formula=c['formula'], reason=c.get('detail', 'Resultado parcial no ponto/componente identificado.'),
                            values=dict(kernel_result=result, point_id=data.point_id))
                        checks.append(check)
                else:
                    checks.append(Check(prefix, 'Fadiga '+scope, 'OUT_OF_SCOPE' if result['status'] == 'FORA DO DOMÍNIO' else 'PENDING',
                        reason='; '.join(result.get('errors', [])+result.get('pending', [])), source=FATIGUE_SOURCE,
                        values={'kernel_result': result}))
            except (ValueError, TypeError, ArithmeticError) as exc:
                checks.append(Check(prefix, 'Fadiga '+scope, 'PENDING', reason=str(exc), source=FATIGUE_SOURCE))
    return checks


def fatigue_plane_checks(planes, *, material, duty, detail, method) -> list[Check]:
    """Thin wrapper around inherited signed, global+local planar fatigue boxes.

    Typed NBRNominalPlane and qualified material/duty/detail/method are required.
    This never generates histories, converts CMAA classes or assumes E8.
    """
    from underslung_runway_candidate.fatigue.nbr_member import evaluate_nbr_member_plane
    out = []
    for index, plane in enumerate(planes):
        result = evaluate_nbr_member_plane(plane, material=material, duty=duty, detail=detail, method=method)
        if result.get('bound'):
            bound = result['bound']
            out.append(_ratio('fatigue/plane/'+str(index), 'Fadiga nominal planar',
                bound['combined_utilization_upper_bound'], 1., evidence='upper_bound', unit='1',
                source=FATIGUE_SOURCE, formula=bound['formula'],
                reason='Envelope suficiente com κ=-1 explicitamente adotado. Excedência não é ruptura.',
                values={'kernel_result': result}))
        else:
            out.append(Check('fatigue/plane/'+str(index), 'Fadiga nominal planar', 'PENDING',
                reason='; '.join(result.get('errors', [])+result.get('pending', [])), source=FATIGUE_SOURCE,
                values={'kernel_result': result}))
    if not out:
        out.append(Check('fatigue/plane', 'Fadiga nominal planar', 'PENDING',
            reason='Nenhum plano nominal com cobertura global/local qualificada.', source=FATIGUE_SOURCE))
    return out


def fatigue_member_bound_checks(section: Section, material: Material, state: Mapping[str, Any], *,
        wheel_stations: Sequence[Mapping[str, Any]], edge_to_contact_mm: float,
        minimum_distance_to_end_mm: float, material_grade: str, duty, detail, method,
        nominal_model_source: str, actions_qualified: bool = False,
        high_ratio_route_confirmed: bool = False) -> list[Check]:
    """Ordinary global walls plus 12 lower local points using legacy producers.

    state: all six resultant absolute bounds, evidence='upper_bound',
    envelope_qualified=True, action_basis='nbr8400_fatigue_case_i_without_mx',
    action_source/factors_source/bounds_source. Each physical wheel station has
    offset_m and an INDIVIDUAL opposite-wheel upper load individual_wheel_kn.
    No actual temporal history, life to failure, contact coverage or whole-beam
    certification follows. This wrapper's initial domain remains N=T=0.
    """
    from underslung_runway_candidate.fatigue.nbr_member import (
        ACTION_BASIS, NBRFatigueMaterial, lower_flange_nominal_planes,
        ordinary_global_wall_nominal_planes)
    from underslung_runway_candidate.section_stress.recovery import bottom_contact
    prefix = 'fatigue/member'
    try:
        _section(section, material)
        if section.fabrication != 'rolled':
            return [Check(prefix+'/domain', 'Fadiga nominal global/local', 'OUT_OF_SCOPE',
                reason='Produtores de fadiga disponíveis exigem I laminado W0 sem entalhes; soldas não são W0.', source=FATIGUE_SOURCE)]
        evidence = _state(state)
        if evidence != 'upper_bound':
            raise ValueError('Este produtor exige limites superiores certificados, não máximos amostrados')
        if state['N_kn'] != 0 or state['T_knm'] != 0:
            return [Check(prefix+'/actions', 'Fadiga nominal global/local', 'OUT_OF_SCOPE',
                reason='N/T não nulos: domínio monovia inicial não remove axial ou torção.', source=FATIGUE_SOURCE)]
        if not actions_qualified or state.get('action_basis') != ACTION_BASIS:
            raise ValueError('Caso I de fadiga sem Mx/omega obrigatório; não relabelar ELU, CMAA ou serviço')
        for key in ('action_source', 'factors_source', 'bounds_source'):
            if not isinstance(state.get(key), str) or not state[key].strip():
                raise ValueError('Fonte explícita obrigatória: '+key)
        if material.fy_mpa/material.fu_mpa > .70 and not high_ratio_route_confirmed:
            raise ValueError('Ramo fy/fu>0,70 requer adoção explícita; não inferida pela classe do aço')
        # Retain the audited ambiguous equality guard instead of bypassing it
        # through the alternate material implementation in nbr_member.
        elastic_allowables_8400(material.fy_mpa, material.fu_mpa, 'I')
        s = _recovery_section(section, 0.)
        mags = dict(N=state['N_kn']*1000., My=state['Mx_knm']*1e6, Mz=state['My_knm']*1e6,
            Fy=state['Vx_kn']*1000., Fz=state['Vy_kn']*1000., B_equilibrated=0., Tsv=0., Tw_equilibrated=0.)
        bounds = {key: {'lower': -value, 'upper': value} for key,value in mags.items()}
        common = dict(resultant_bounds=bounds, action_basis=ACTION_BASIS,
            action_source=state['action_source'], factors_source=state['factors_source'],
            bounds_source=state['bounds_source'], nominal_model_source=nominal_model_source)
        global_produced = ordinary_global_wall_nominal_planes(s, **common)
        out = []
        for index, plane in enumerate(global_produced['planes']):
            # The inherited ordinary web producer is planar xz. Lateral force
            # also creates web tau_xy in the complete nominal recovery; do not
            # silently erase that out-of-plane component for Annex D.5.
            if plane.plane == 'xz' and state['Vx_kn'] != 0:
                out.append(Check(prefix+'/global/'+str(index), 'Fadiga global nominal · '+plane.region_id,
                    'PENDING', reason='Cortante lateral não nulo produz τxy na alma, fora do plano xz de D.5; componente não descartada.',
                    source=FATIGUE_SOURCE, values={'Vx_kn_upper_bound':state['Vx_kn'], 'omitted_component_not_assumed_zero':True}))
                continue
            thickness = section.tw_mm if plane.plane == 'xz' else section.tf_mm
            fat_material = NBRFatigueMaterial(material.fy_mpa, material.fu_mpa, thickness,
                material_grade, material.specification)
            checks = fatigue_plane_checks([plane], material=fat_material, duty=duty, detail=detail, method=method)
            for check in checks:
                check.id = prefix+'/global/'+str(index)
                check.title = 'Fadiga global nominal · '+plane.region_id
                check.values['producer_receipt'] = {k:v for k,v in global_produced.items() if k != 'planes'}
            out.extend(checks)
        wheels = []
        for station in wheel_stations:
            offset = _number(station['offset_m'], 'offset_m', nonnegative=True)*1000.
            load = _number(station['individual_wheel_kn'], 'individual_wheel_kn', nonnegative=True)*1000.
            for side in ('left', 'right'):
                contact = bottom_contact(s, edge_to_contact_mm, side)
                wheels.append(dict(offset_mm=offset, y_mm=contact['y_mm'], z_mm=contact['z_mm'],
                    omega_mm2=contact['omega_mm2'], downward_N={'lower': 0., 'upper': load}))
        try:
            local_produced = lower_flange_nominal_planes(s, **common, wheel_vertical_actions=wheels,
                edge_to_contact_n_mm=edge_to_contact_mm,
                minimum_distance_to_physical_end_mm=minimum_distance_to_end_mm)
            fat_material = NBRFatigueMaterial(material.fy_mpa, material.fu_mpa, section.tf_mm,
                material_grade, material.specification)
            for index, plane in enumerate(local_produced['planes']):
                checks = fatigue_plane_checks([plane], material=fat_material, duty=duty, detail=detail, method=method)
                for check in checks:
                    check.id = prefix+'/local/'+str(index)
                    check.title = 'Fadiga local nominal · '+plane.point_id
                    # Only the matching point receipt, rather than 12 repeated copies.
                    check.values['producer_receipt'] = local_produced['point_receipts'][index]
                out.extend(checks)
        except (ValueError, KeyError, TypeError, ArithmeticError) as exc:
            out.append(Check(prefix+'/local', 'Fadiga local nominal', 'PENDING', reason=str(exc), source=FATIGUE_SOURCE))
        return out
    except (ValueError, KeyError, TypeError, ArithmeticError) as exc:
        return [Check(prefix, 'Fadiga nominal global/local', 'PENDING', reason=str(exc), source=FATIGUE_SOURCE)]


def governing_checks(checks: Sequence[Check]) -> list[Check]:
    """Keep every blocker and the worst numeric witness of each physical mode.

    Caller may use this only for presentation. Full computation/audit rows stay
    available. Real FAIL wins over BOUND_EXCEEDED even at a lower utilization.
    IDs include state identifiers; the stable suffix after /bottom_flange/ is
    the local physical-point identity. Nonlocal rows are not silently merged.
    """
    out, groups = [], {}
    severity = {'PASS': 0, 'BOUND_EXCEEDED': 1, 'FAIL': 2}
    for check in checks:
        marker = '/bottom_flange/'
        if marker not in check.id or check.status not in severity:
            out.append(check)
            continue
        key = 'bottom_flange/' + check.id.split(marker, 1)[1]
        old = groups.get(key)
        rank = (severity[check.status], check.utilization if check.utilization is not None else -1.)
        if old is None or rank > (severity[old.status], old.utilization if old.utilization is not None else -1.):
            groups[key] = check
    return out + list(groups.values())


def global_stress_bound_checks(section: Section, material: Material, states: Sequence[Mapping[str, Any]], *,
        actions_qualified: bool = False, nominal_model_adopted: bool = False,
        high_ratio_route_confirmed: bool = False) -> list[Check]:
    """Primary NBR8400 elastic nominal material bounds, separate from stability.

    Only qualified upper_bound states of nbr8400_cases are admitted. The exact
    inherited section corner recovery bounds sigma_x at all rectangle points.
    The preserved whole_section_shear_bound retains the two shear components,
    including the finite flange/web transfer strip. No static action is ever
    relabeled as fatigue. The material invariant is bounded as
    sqrt(sigma_x_bound**2 + 3*||tau_x*||_bound**2) in this nominal model, which
    has only one normal stress and two longitudinal shear stresses. This is a
    static invariant bound, NOT a fictitious planar fatigue stress/history.

    Local wheel plate bending must be assessed separately. Contact, actual
    roots/joints and 3-D disturbed load introduction remain outside this model.
    The model currently supports only doubly symmetric rolled I and N=T=0.
    """
    from lro_beams.geometry import elastic_extreme_stresses
    from underslung_runway_candidate.section_stress.whole_section_bounds import whole_section_shear_bound
    try:
        g = _section(section, material)
        if section.fabrication != 'rolled':
            return [Check('global8400/domain', 'Tensões globais NBR8400', 'OUT_OF_SCOPE',
                reason='Envelope de cisalhamento nominal herdado qualificado apenas para I laminado.',
                source='ABNT NBR 8400-2:2019 §5.2.1')]
        s = _recovery_section(section, 0.)
    except (ValueError, TypeError, ArithmeticError) as exc:
        return [Check('global8400/domain', 'Tensões globais NBR8400', 'OUT_OF_SCOPE', reason=str(exc))]
    out = []
    for index,state in enumerate(states):
        prefix='global8400/'+str(state.get('id', index))
        try:
            if _state(state) != 'upper_bound':
                raise ValueError('Esta rota avalia somente envelope nominal, não é testemunho físico de falha')
            if not actions_qualified or state.get('action_basis') != 'nbr8400_cases':
                raise ValueError('Ações dos casos NBR8400 obrigatórias; ELU/CMAA não convertidos')
            if not nominal_model_adopted:
                raise ValueError('Modelo nominal de tensões globais ainda não adotado')
            if not state.get('action_source') or not state.get('factors_source'):
                raise ValueError('Fontes de ação e fatores obrigatórias')
            if state['N_kn'] != 0 or state['T_knm'] != 0:
                out.append(Check(prefix+'/axial_torsion', 'Domínio global NBR8400', 'OUT_OF_SCOPE',
                    reason='N/T não nulos: estabilidade e interação não cobertas; nenhum termo foi apagado.',
                    values={k:state[k] for k in ('N_kn','T_knm')}))
                continue
            if material.fy_mpa/material.fu_mpa > .70 and not high_ratio_route_confirmed:
                raise ValueError('Ramo fy/fu>0,70 exige adoção explícita do aço de referência 360/510 MPa')
            limits=elastic_allowables_8400(material.fy_mpa,material.fu_mpa,state.get('nbr_case',''))
            corners=elastic_extreme_stresses(0.,state['Mx_knm'],state['My_knm'],g)
            sigma=max(abs(value) for value in corners.values())
            shear=whole_section_shear_bound(s,abs_Fy_N=state['Vx_kn']*1000.,abs_Fz_N=state['Vy_kn']*1000.,
                abs_Tsv_Nmm=0.,abs_Tw_Nmm=0.)
            for region in ('top_flange','bottom_flange','web'):
                tau=shear['components'][region]['vector_bound_mpa']
                vm=equivalent_plane_stress(sigma,0.,tau)
                values=dict(region=region,sigma_x_abs_bound_mpa=sigma,shear_vector_abs_bound_mpa=tau,
                    shear_receipt=shear,limits=limits,static_invariant_bound=True,
                    physical_planar_tensor_claimed=False,local_wheel_effects_included=False,
                    stability_included=False,actual_3d_tensor_complete=False)
                source='Resistências admissíveis: ABNT NBR 8400-2:2019 corrigida 2022 §5.2.1. Recuperação mecânica nominal preservada do LRO: equilíbrio longitudinal/Jourawski nos três retângulos e majorante vetorial. Não é fórmula normativa de resistência nem solução de concentrações 3D.'
                for key,title,demand,cap,formula in (
                    ('sigma_x','Tensão normal global',sigma,limits['sigma_a_mpa'],'|σx|≤σa'),
                    ('shear','Módulo resultante do cisalhamento',tau,limits['tau_a_mpa'],'||τx*||≤σa/√3'),
                    ('equivalent','Invariante equivalente global',vm,limits['sigma_a_mpa'],
                     'σeq,bound=√(σx,bound²+3||τx*||bound²)≤σa')):
                    out.append(_ratio(prefix+'/'+region+'/'+key,title+' · '+{'top_flange':'mesa superior','bottom_flange':'mesa inferior','web':'alma'}[region],demand,cap,
                        evidence='upper_bound',unit='MPa',source=source,formula=formula,
                        reason='Limite elástico nominal global, sem aprovação de estabilidade ou carga local de roda.',values=values))
        except (ValueError, KeyError, TypeError, ArithmeticError) as exc:
            out.append(Check(prefix+'/pending','Tensões globais NBR8400','PENDING',reason=str(exc),source='ABNT NBR 8400-2:2019 §5.2.1'))
    return out or [Check('global8400/actions','Tensões globais NBR8400','PENDING',reason='Nenhum envelope NBR8400 fornecido.')]
