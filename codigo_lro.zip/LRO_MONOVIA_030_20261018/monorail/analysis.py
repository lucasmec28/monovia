"""Moving-load orchestration only. Structural kernels remain unchanged.

Flexural bounds are the inherited analytical spatial extrema plus certified
translation-discretization bounds. Nonzero torsion is retained, but its new
monorail orchestration is diagnostic sampled response, not qualified resistance.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from copy import deepcopy
from datetime import datetime, timezone
from hashlib import sha256
from itertools import product
from pathlib import Path
import json
import math
import time

from lro_beams.autonomous_actions import factors_10084, factors_8800, variants_8800
from lro_beams.geometry import section_properties
from lro_beams.moving_beam import BeamModel, MovingWheel, UniformLoad, SearchTolerance, scan_moving_train
from lro_beams.beam_torsion import VlasovBeam, TorsionSolution, PointTorque
from .model import MonorailProject

GRAVITY=9.80665
SOURCE_ZIP_SHA256="4a2fca7a44eff3073f50c779eb74ebeb7ad450dae44d61257f41066daf0afdde"


def digest(data):
    return sha256(json.dumps(data,sort_keys=True,separators=(",",":"),ensure_ascii=False,allow_nan=False).encode()).hexdigest()


def source_receipt():
    root=Path(__file__).resolve().parents[1]
    files={str(p.relative_to(root)):sha256(p.read_bytes()).hexdigest()
           for name in ("monorail","lro_beams","underslung_runway_candidate","top_unstiffened_candidate")
           for p in sorted((root/name).rglob("*.py"))}
    return dict(original_zip_sha256=SOURCE_ZIP_SHA256,files=files,fingerprint=digest(files))


@dataclass(frozen=True)
class Case:
    id: str
    family: str
    loaded: bool
    support_factor: float
    equipment_factor: float
    payload_factor: float
    retained_factor: float
    horizontal_factor: float
    extra_factor: float
    longitudinal_sign: int
    transverse_sign: int
    source: str
    formula: str
    nominal_payload_only: bool = False


def generate_cases(p):
    """Independent case ledgers. Payload/retained suspended mass never duplicate."""
    psi=p.dynamics()["psi"]
    hx=any(a.longitudinal_kn for a in p.stations)
    hy=any(a.transverse_kn for a in p.stations)
    sides=tuple(product((-1,1) if hx else (1,),(-1,1) if hy else (1,)))
    cases=[Case("NOMINAL_L500","nominal_deflection",True,0.,0.,1.,0.,0.,0.,1,1,
        "ABNT NBR 10084:2020 §10, Tabela 4(c), monovias para talhas",
        "Somente capacidade nominal de carga útil; sem G, impacto, Mx ou coeficientes ELU.",True)]
    native=factors_10084("I",psi=psi,equipment_group=p.equipment_group)
    fatigue=factors_10084("fatigue_8400",psi=psi)
    uls=variants_8800(psi=psi,extra_dead_kn_per_m=p.extra_dead_kn_per_m)
    # Pure downward gravity: every individual response magnitude of this simple
    # beam is monotone in each positive origin. Keep all vertices nonetheless
    # so the same explicit code path also handles input horizontal actions.
    factors=[("NBR_I",native),("FAT8400",fatigue)]+[("ULS8800",a) for a in uls]
    for family,a in factors:
        for loaded in (True,False):
            for sx,sy in sides:
                cid=f"{family}/{a.code}/{'carregada' if loaded else 'vazia'}/HX{sx:+d}/HY{sy:+d}"
                cases.append(Case(cid,family,loaded,a.dead_support,a.dead_equipment,
                    a.lifted if loaded else 0.,a.lifted,a.longitudinal,a.extra_dead,sx,sy,a.source,
                    "Gsuporte×gs + Gequipamento×ge + Gextra×gx + (Qútil×q + Bretida×b) + H×h; coeficientes aplicados uma vez."))
    # Unfactored dead+moving service is a reference diagram, not the L/500 test.
    cases.append(Case("OPERACAO_SEM_IMPACTO","operating_service",True,1.,1.,1.,1.,1.,1.,1,1,
        "Mecânica elástica: estado operacional sem impacto, referência informativa",
        "Gsuporte + Gextra + Gequipamento + Qútil + Bretida + H"))
    return tuple(cases)


def case_loads(p,case):
    props=section_properties(p.section)
    beam=BeamModel(p.span_m,p.material.E_mpa,props.Ix_mm4,props.Iy_mm4)
    q=p.self_weight_kn_m()*case.support_factor+p.extra_dead_kn_per_m*case.extra_factor
    z=p.section.tf_mm-p.section.d_mm/2  # upper surface of bottom flange, not suspended CG
    payload_kg=(p.capacity_t if case.nominal_payload_only else p.operating_payload_t)*1000
    wheels=[];ledger=[]
    for station in p.stations:
        gd=p.trolley_hoist_mass_kg*GRAVITY/1000*station.equipment_share*case.equipment_factor
        ql=payload_kg*GRAVITY/1000*station.suspended_share*case.payload_factor
        br=p.retained_suspended_mass_kg*GRAVITY/1000*station.suspended_share*case.retained_factor
        hx=station.longitudinal_kn*case.horizontal_factor*case.longitudinal_sign
        hy=station.transverse_kn*case.horizontal_factor*case.transverse_sign
        wheels.append(MovingWheel(station.offset_m,gd+ql+br,hy,station.id,hx,hx*z/1000,0.))
        ledger.append(dict(station_id=station.id,offset_m=station.offset_m,
            pair_dead_kn=gd,pair_payload_kn=ql,pair_retained_kn=br,pair_vertical_kn=gd+ql+br,
            individual_wheel_kn=(gd+ql+br)/2.,pair_longitudinal_kn=hx,pair_transverse_kn=hy,
            height_from_shear_center_mm=z,transport_major_moment_knm=hx*z/1000,
            pair_torque_knm=hy*z/1000,opposite_vertical_torques_cancel=True,
            sharing_basis=p.wheel_distribution_source))
    return beam,tuple(wheels),UniformLoad(q),ledger


def torsion_at(p,train,translation):
    g=section_properties(p.section)
    vb=VlasovBeam(p.span_m*1000,p.material.E_mpa,p.material.G_mpa,g.J_mm4,g.Cw_mm6)
    z=p.section.tf_mm-p.section.d_mm/2
    points=tuple(PointTorque((translation+w.offset_m)*1000,w.horizontal_kn*1000*z,w.name)
        for w in train if w.horizontal_kn and 0<=translation+w.offset_m<=p.span_m)
    return TorsionSolution(vb,points)


def _physical_reactions(raw):
    """Cartesian forces/support torques acting ON the beam; preserve kernel aliases."""
    result={}
    for side in ('left','right'):
        result['R_s_'+side+'_kn']=raw['longitudinal_'+side+'_kn']
        result['R_y_'+side+'_kn']=-raw['horizontal_'+side+'_kn']
        result['R_z_'+side+'_kn']=raw['vertical_'+side+'_kn']
        result['M_s_'+side+'_knm']=-raw.get('torque_'+side+'_knm',0.)
    return result


REACTION_CONVENTION={
    'axes':'s longitudinal da esquerda para direita; y lateral; z para cima; base de mão direita.',
    'support_on_beam':'Vetor físico da força/momento que o apoio exerce SOBRE a viga.',
    'beam_on_support':'Carga física transmitida pela viga à estrutura receptora: negativo do vetor support_on_beam.',
    'kernel_alias_mapping':'Rs=longitudinal; Ry=-horizontal; Rz=vertical; Ms=-torque_LRO. As ordenadas kernel não são automaticamente componentes cartesianas físicas.',
    'section_aliases':'Mx legado=momento forte em torno do eixo lateral y; My=momento fraco em torno de z; Vy=cortante vertical z; Vx=cortante lateral y. Sinais internos seguem as convenções dos diagramas.'}


def _reaction_evidence(p,scan,train,udl):
    extrema={};physical_extrema={};worst=0.
    for sample in scan.samples:
        r=asdict(sample.solution.reactions)
        ts=torsion_at(p,train,sample.translation_m)
        r.update(torque_left_knm=ts.support_torques_nmm[0]/1e6,torque_right_knm=ts.support_torques_nmm[1]/1e6)
        for key,value in r.items():
            if key not in extrema:extrema[key]={}
            for mode in ("min","max"):
                old=extrema[key].get(mode)
                if old is None or (value<old["value"] if mode=="min" else value>old["value"]):
                    extrema[key][mode]=dict(value=value,translation_m=sample.translation_m,coexistent_reactions=dict(r))
        physical=_physical_reactions(r)
        for key,value in physical.items():
            if key not in physical_extrema:physical_extrema[key]={}
            for mode in ('min','max'):
                old=physical_extrema[key].get(mode)
                if old is None or (value<old['value'] if mode=='min' else value>old['value']):
                    physical_extrema[key][mode]=dict(value=value,translation_m=sample.translation_m,
                        support_on_beam=dict(physical),beam_on_support={k:-v for k,v in physical.items()})
        loads=sample.solution.all_loads
        residuals=(r["vertical_left_kn"]+r["vertical_right_kn"]-sum(w.vertical_kn for w in loads)-udl.vertical_kn_per_m*p.span_m,
            r["horizontal_left_kn"]+r["horizontal_right_kn"]-sum(w.horizontal_kn for w in loads),
            r["longitudinal_left_kn"]+sum(w.longitudinal_kn for w in loads),
            r["vertical_right_kn"]*p.span_m-sum(w.vertical_kn*w.position_m+w.major_moment_knm for w in loads)-udl.vertical_kn_per_m*p.span_m**2/2,
            r["torque_left_knm"]+r["torque_right_knm"]+sum(t.torque_nmm for t in ts.point_torques)/1e6)
        worst=max(worst,*map(abs,residuals))
    return extrema,worst,physical_extrema


def _diagram(p,scan,translation,train):
    sample=min(scan.samples,key=lambda x:abs(x.translation_m-translation))
    ts=torsion_at(p,train,sample.translation_m)
    xs=sorted({p.span_m*i/100 for i in range(101)}|{w.position_m for w in sample.solution.all_loads})
    rows=[]
    for x in xs:
        for side in (("left","right") if 0<x<p.span_m and any(w.position_m==x for w in sample.solution.all_loads) else (("left",) if x==p.span_m else ("right",))):
            a=asdict(sample.solution.at(x,side));t=asdict(ts.at(x*1000,side))
            a.update(T_knm=t["total_torque_nmm"]/1e6,B_knm2=t["bimoment_nmm2"]/1e9,
                Tsv_knm=t["saint_venant_torque_nmm"]/1e6,Tw_knm=t["warping_torque_nmm"]/1e6,theta_mrad=t["theta_rad"]*1000)
            rows.append(a)
    raw_reactions=asdict(sample.solution.reactions)
    raw_reactions.update(torque_left_knm=ts.support_torques_nmm[0]/1e6,torque_right_knm=ts.support_torques_nmm[1]/1e6)
    physical=_physical_reactions(raw_reactions)
    return dict(translation_m=sample.translation_m,support_on_beam=physical,beam_on_support={k:-v for k,v in physical.items()},loads=[asdict(w) for w in sample.solution.all_loads],
        reactions=asdict(sample.solution.reactions),rows=rows,kind="Estado concomitante, não mistura de máximos.")


def _spatial_envelope(p,scan):
    metrics=('Mx_knm','My_knm','Vy_kn','Vx_kn','N_kn','vertical_mm','horizontal_mm')
    rows=[]
    for i in range(51):
        x=p.span_m*i/50;values={k:[] for k in metrics}
        for sample in scan.samples:
            state=sample.solution.at(x,'left' if i==50 else 'right')
            for key in metrics:values[key].append(getattr(state,key))
        rows.append(dict(position_m=x,**{key:dict(min=min(v),max=max(v)) for key,v in values.items()}))
    return dict(rows=rows,kind='Envoltórias assinadas amostradas em 51 seções; curvas não são estado concomitante.',
        translation_samples=len(scan.samples),interpolated_plot=True,
        shear_jump_extrema_not_certified_on_plot=True,
        scalar_global_extrema_use_separate_analytical_discretization_bounds=True)


def _state(p,case,scan,train,ledger,*,upper=True,sample=None,x=None,cut="right",station_index=0):
    values={m.metric:m.upper_bound for m in scan.maxima}
    if upper:
        out={k:values[k] for k in ("N_kn","Mx_knm","My_knm","Vy_kn","Vx_kn")}
        # Nonzero torsion is not a certified envelope in this adapter. A positive
        # marker retains the out-of-domain state rather than silently zeroing it.
        out["T_knm"]=sum(abs(r["pair_torque_knm"]) for r in ledger)
        out.update(id=case.id+"/limite",x_m=0.,wheel_translation_m=0.,evidence="upper_bound",
            envelope_qualified=True,individual_wheel_kn=max(r["individual_wheel_kn"] for r in ledger),
            distance_to_end_mm=1000*min(p.travel_min_m,p.span_m-p.travel_max_m-max(s.offset_m for s in p.stations)))
    else:
        a=sample.solution.at(x,cut);out={k:getattr(a,k) for k in ("N_kn","Mx_knm","My_knm","Vy_kn","Vx_kn")}
        t=torsion_at(p,train,sample.translation_m).at(x*1000,cut)
        out.update(T_knm=t.total_torque_nmm/1e6,id=f"{case.id}/a={sample.translation_m:.9g}/x={x:.9g}/{cut}",
            x_m=x,wheel_translation_m=sample.translation_m,evidence="sampled_state",envelope_qualified=False,
            individual_wheel_kn=ledger[station_index]["individual_wheel_kn"],distance_to_end_mm=1000*min(x,p.span_m-x),cut_side=cut)
    offsets=sorted(s.offset_m for s in p.stations)
    out.update(nearest_spacing_mm=1000*min((b-a for a,b in zip(offsets,offsets[1:])),default=math.inf) if len(offsets)>1 else None,
        isolated_station_confirmed=len(offsets)==1,nbr_case="I",
        action_basis="nbr8800_uls" if case.family=="ULS8800" else "nbr8400_fatigue_case_i_without_mx" if case.family=="FAT8400" else "nbr8400_cases",
        action_source=case.source,factors_source=json.dumps(asdict(case),ensure_ascii=False),
        bounds_source="Extremos espaciais analíticos + majorantes de erro de discretização na translação do núcleo LRO; caixa simétrica conservadora.")
    return out


def _reduce_checks(checks):
    """One governing status per criterion; detailed witnesses remain in values."""
    rank={"FAIL":5,"BOUND_EXCEEDED":4,"OUT_OF_SCOPE":3,"PENDING":2,"PASS":1}
    groups={}
    for check in checks:
        row=check.to_dict() if hasattr(check,"to_dict") else check
        key=row["title"]
        old=groups.get(key)
        if old is None or (rank[row["status"]],row.get("utilization") or -1)>(rank[old["status"]],old.get("utilization") or -1):
            groups[key]=row
    return list(groups.values())


def analyze(project:MonorailProject,progress=None):
    """Return complete JSON-compatible calculation, even when criteria fail."""
    from .checks import Check, global_checks,global_stress_bound_checks,local_flange_checks,fatigue_checks
    p=project.validate();started=time.monotonic();source=source_receipt();sig=p.signature()
    cases=generate_cases(p);rows=[];checks=[];global_states=[];local_states=[];fatigue_rows=[]
    for index,case in enumerate(cases):
        if progress:progress(index,len(cases),case.id)
        beam,train,udl,ledger=case_loads(p,case)
        scan=scan_moving_train(beam,train,udl,translation_range_m=(p.travel_min_m,p.travel_max_m),
            tolerance=SearchTolerance(relative=p.numerical_tolerance),max_refinements=p.max_refinements)
        reactions,equilibrium,physical_reactions=_reaction_evidence(p,scan,train,udl)
        row=dict(case=asdict(case),wheel_ledger=ledger,uniform_load=asdict(udl),maxima=[asdict(m) for m in scan.maxima],
            converged=scan.converged,samples=len(scan.samples),refinements=scan.refinements,
            max_translation_gap_m=scan.max_translation_gap_m,translation_range_m=list(scan.translation_range_m),
            method=scan.method,limitations=list(scan.limitations),reaction_extrema=reactions,physical_reaction_extrema=physical_reactions,reaction_convention=deepcopy(REACTION_CONVENTION),max_equilibrium_residual=equilibrium)
        row["diagram"]=_diagram(p,scan,scan.maximum("Mx_knm").translation_m,train)
        row["deflection_diagram"]=_diagram(p,scan,scan.maximum("vertical_mm").translation_m,train)
        row["spatial_envelope"]=_spatial_envelope(p,scan)
        rows.append(row)
        bound=_state(p,case,scan,train,ledger)
        if case.family=="ULS8800":
            global_states.append(bound)
            for metric in ("Mx_knm","My_knm","Vy_kn","Vx_kn"):
                maximum=scan.maximum(metric);sample=min(scan.samples,key=lambda r:abs(r.translation_m-maximum.translation_m))
                global_states.append(_state(p,case,scan,train,ledger,upper=False,sample=sample,x=maximum.section.position_m,cut=maximum.section.side))
        elif case.family=="NBR_I":
            offsets=sorted((r['offset_m'],r['individual_wheel_kn']) for r in ledger)
            clusters=[[offsets[0]]]
            for point in offsets[1:]:
                if point[0]-clusters[-1][-1][0]<1.5*p.section.bf_mm/1000:clusters[-1].append(point)
                else:clusters.append([point])
            for cluster_index,close in enumerate(clusters):
                local_bound=dict(bound,id=bound['id']+f'/grupo{cluster_index+1}',individual_wheel_kn=max(pair[1] for pair in close))
                outsiders=[pair for pair in offsets if pair not in close]
                external_gap=min((abs(a[0]-b[0]) for a in close for b in outsiders),default=None)
                if len(close)>1:
                    local_bound.update(wheel_cluster_actions_kn=[pair[1] for pair in close],
                        wheel_cluster_spacings_mm=[1000*(b[0]-a[0]) for a,b in zip(close,close[1:])],
                        cluster_complete_confirmed=True,
                        nearest_external_spacing_mm=None if external_gap is None else external_gap*1000)
                else:
                    local_bound.update(nearest_spacing_mm=None if external_gap is None else external_gap*1000,
                        isolated_station_confirmed=external_gap is None)
                local_states.append(local_bound)
            # Witnesses at physical wheel cuts, including the maximum-M train.
            translations={p.travel_min_m,p.travel_max_m,scan.maximum("Mx_knm").translation_m}
            for translation in sorted(translations) if not any(len(group)>1 for group in clusters) else ():
                sample=min(scan.samples,key=lambda r:abs(r.translation_m-translation))
                for j,w in enumerate(train):
                    x=sample.translation_m+w.offset_m
                    for cut in ("left","right"):
                        local_states.append(_state(p,case,scan,train,ledger,upper=False,sample=sample,x=x,cut=cut,station_index=j))
        elif case.family=="FAT8400":fatigue_rows.append((bound,ledger))
        elif case.family=="nominal_deflection":
            m=scan.maximum("vertical_mm");capacity=p.span_m*1000/500
            status="FAIL" if m.absolute_value>capacity else "PASS" if m.upper_bound<=capacity else "BOUND_EXCEEDED"
            checks.append(Check("service/nominal","Flecha nominal da monovia L/500",status,m.upper_bound,capacity,m.upper_bound/capacity,"mm",
                "Somente capacidade nominal de carga útil, sem peso próprio, talha/trole, massa retida, impacto ou fatores. Não verifica vibração ou outras condições de serviço.",case.source,
                "δnom ≤ L/500",dict(sampled_maximum_mm=m.absolute_value,upper_bound_mm=m.upper_bound,discretization_bound_mm=m.discretization_error_bound,translation_m=m.translation_m)))
    checks+=global_checks(p.section,p.material,p.span_m,global_states,forks_confirmed=p.end_forks_confirmed,
        actions_qualified=True,load_application_qualified=not any(s.longitudinal_kn or s.transverse_kn for s in p.stations),nominal_plan=p.resistance_plan())
    checks+=global_stress_bound_checks(p.section,p.material,[s for s in local_states if s['evidence']=='upper_bound'],
        actions_qualified=True,nominal_model_adopted=True,high_ratio_route_confirmed=p.high_ratio_material_confirmed)
    checks+=local_flange_checks(p.section,p.material,local_states,edge_to_contact_mm=p.edge_to_contact_mm,
        weld_throat_mm=p.weld_throat_mm,equal_opposite_wheels_confirmed=p.equal_opposite_wheels,
        actions_qualified=True,nominal_model_adopted=True,base_material_confirmed=True,
        high_ratio_route_confirmed=p.high_ratio_material_confirmed)
    if p.fatigue_group in tuple('E'+str(i) for i in range(1,9)) and p.fatigue_detail_confirmed and p.fatigue_kappa_minus_one_adopted and p.fatigue_fabrication_declared and p.fatigue_source.strip():
        from .checks import fatigue_member_bound_checks
        from underslung_runway_candidate.fatigue.nbr_member import NBRFatigueDuty,NBRFatigueDetail,NBRFatigueMethod,KAPPA_POLICY
        for bound,ledger in fatigue_rows:
            checks+=fatigue_member_bound_checks(p.section,p.material,bound,
                wheel_stations=[dict(offset_m=r['offset_m'],individual_wheel_kn=r['individual_wheel_kn']) for r in ledger],
                edge_to_contact_mm=p.edge_to_contact_mm,minimum_distance_to_end_mm=bound['distance_to_end_mm'],
                material_grade=p.fatigue_material_grade,
                duty=NBRFatigueDuty(p.fatigue_group,p.fatigue_source,'manual_code_selection'),
                detail=NBRFatigueDetail('W0_plain_rolled_unnotched',p.fatigue_source,'specified_h6',p.fatigue_source),
                method=NBRFatigueMethod(KAPPA_POLICY,p.fatigue_source),
                nominal_model_source='Núcleo LRO preservado: viga I e recuperação nominal de tensões, caixas de resposta interna.',
                actions_qualified=True,high_ratio_route_confirmed=p.high_ratio_material_confirmed)
    else:checks+=fatigue_checks()
    checks+=[Check("contact","Contato roda–mesa e desgaste","PENDING",reason="Pressão de contato, durezas, geometria da banda e vida de rolamento não são comprovadas pela tensão nominal. O kernel EN13001 herdado não qualificou a mesa inferior fina: nenhum PASS de contato é emitido."),
        Check("connections","Apoios, ligações e estrutura receptora","OUT_OF_SCOPE",reason="Reações concomitantes são fornecidas. Garfos, suspensão, travamentos, soldas/parafusos de apoio e a estrutura receptora precisam realizar os vínculos e ser dimensionados separadamente."),
        Check("special_events","Ensaio, batentes, emergência e vento","OUT_OF_SCOPE",reason="Primeira versão cobre operação normal interna. Não é autorização para omitir eventos aplicáveis. Ensaio de talha produzida em série não é inferido da capacidade."),
        Check("stiffeners","Enrijecedores e regiões perturbadas","OUT_OF_SCOPE",reason="Sem crédito de enrijecedor. Mesas de extremidade, juntas, furos, transferência de apoio e regiões de raiz/contato reais não são concluídas pelo modelo nominal.")]
    if p.upper_braces_m or p.lower_braces_m or p.lateral_axis_braces_m:
        plan=p.resistance_plan()
        checks.append(Check("restraints","Travamentos intermediários declarados","PENDING",reason=(
            "Plano nominal herdado: só duas restrições laterais independentes, uma no centro de cisalhamento e outra na mesa superior, na mesma posição LONGITUDINAL s, delimitam garfo resistente. São alturas físicas distintas. Centro isolado e mesa inferior não recebem crédito FLT. Não gera apoios, reações ou redistribuição; resistência/rigidez e ligações das contenções devem realizar a hipótese."
            if plan else "Modo conservador integral: posições somente registradas, sem uso resistente. Selecione conscientemente o modo nominal e confira suas hipóteses para obter crédito."),values=plan.evidence() if plan else {}))
    if any(s.longitudinal_kn or s.transverse_kn for s in p.stations):
        checks.append(Check("horizontal","Forças horizontais e torção","PENDING",reason="Flexão, axial, momentos de transporte e torção Vlasov são calculados. A envoltória torsional/resistência combinada ainda não está qualificada nesta adaptação. Forças nos contatos são entradas explícitas; não se presume redistribuição por CG/inércia."))
    reduced=_reduce_checks(checks);counts={status:sum(c['status']==status for c in reduced) for status in ('PASS','FAIL','BOUND_EXCEEDED','PENDING','OUT_OF_SCOPE')}
    summary="Critérios não atendidos" if counts['FAIL'] else "Limite conservador excedido; refinar ou redimensionar" if counts['BOUND_EXCEEDED'] else "Critérios calculados atendidos no domínio; pendências separadas"
    if sig!=p.signature() or source['fingerprint']!=source_receipt()['fingerprint']:raise ValueError("Entradas ou fonte mudaram durante cálculo. Calcule novamente.")
    result=dict(format="LRO_MONORAIL_RESULT",version=1,project=p.to_dict(),project_signature=sig,
        calculated_at_utc=datetime.now(timezone.utc).isoformat(),source=source,seconds=time.monotonic()-started,
        properties=section_properties(p.section).to_dict(),self_weight_kn_m=p.self_weight_kn_m(),dynamics=p.dynamics(),
        resistance_lengths=p.resistance_plan().evidence() if p.resistance_plan() else None,
        cases=rows,checks=reduced,check_details=[x.to_dict() for x in checks],counts=counts,summary=summary,
        numerical_converged=all(x['converged'] for x in rows),all_criteria_pass=not any(counts[k] for k in ('FAIL','BOUND_EXCEEDED','PENDING','OUT_OF_SCOPE')),
        whole_design_approved=False,
        scope=dict(straight=True,single_span=True,symmetric_opposite_wheels=True,stiffener_credit=False,
            global_response_source="LRO 17/10: moving_beam + beam_torsion, sem alteração de equações",
            force_envelopes_have_discretization_bounds=True,torsion_envelope_qualified=not any(s.transverse_kn for s in p.stations),
            bracing_changes_response=False,multiple_equipment=False,curve_or_switch=False,
            cmaa_whole_monorail_compliance=False),
        limitations=["Monovia fixa não recebe declaração de conformidade integral CMAA 70/74. CMAA 70 é de pontes múltiplas; CMAA 74 admite correlação limitada da interface. Base local NBR 10084/8400, complemento global NBR 8800 identificado.",
            "Uma viga reta prismática, pequenos deslocamentos, flexão Euler–Bernoulli, apoios simples em ambos eixos, garfos nas extremidades com empenamento livre; axial ancorado apenas à esquerda.",
            "Extremidades físicas coincidem com os apoios nesta versão; prolongamentos/balanços não são introduzidos apenas para ampliar o afastamento local.",
            "Nenhum apoio intermediário nasce de uma lista de travamentos. A deformação por cortante, segunda ordem, vibração e flexibilidade das ligações não são modeladas.",
            "Máximos de componentes podem ocorrer em posições/casos diferentes. Limites superiores são caixas conservadoras, não estados físicos concomitantes.",
            "Fatores e classes são entradas explícitas; não há equivalência automática CMAA, grupos A/E, HC/HD ou EN. Exemplos não são dados de fabricante nem aprovação de uso real.",
            "Critérios não atendidos não impedem salvar projeto, baixar dados ou Word. Falta de cálculo e resultado desatualizado são bloqueios distintos."])
    result['result_signature']=digest(result)
    if progress:progress(len(cases),len(cases),"Concluído")
    return result


def assert_current_result(project,result):
    project.validate()
    if not isinstance(result,dict) or result.get('format')!='LRO_MONORAIL_RESULT':raise ValueError("Calcule o projeto antes de exportar resultados.")
    if result.get('project_signature')!=project.signature():raise ValueError("Entradas mudaram: resultado desatualizado. Calcule novamente antes de exportar.")
    if result.get('result_signature')!=digest({k:v for k,v in result.items() if k!='result_signature'}):raise ValueError("Resultado alterado/importado não é recibo válido de cálculo.")
    if result.get('source',{}).get('fingerprint')!=source_receipt()['fingerprint']:raise ValueError("Código mudou: calcule novamente.")
    return result
