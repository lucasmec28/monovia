# LRO Monovia 0.3

Comece pelo `GUIA_RAPIDO.docx` para escolher uma das três páginas.

Aplicativo para monovia reta, de um vão, com talha/trole na mesa inferior de perfil I/H. Reutiliza os núcleos preservados da revisão LRO de 17/10/2026, sem Robot, chave de API ou serviço remoto de cálculo.

Há três páginas de cálculo, com escopos separados. Não se convertem classificações, fatores, tensões admissíveis ou aprovações entre elas.

- **Página inicial NBR:** mantém os métodos e o domínio da versão 0.1, com as correções de integração documentadas na 0.3, ações NBR 10084/8400, complemento global NBR 8800 e fadiga nominal W0 no domínio declarado. A resistência combinada com torção não é fechada nessa página.
- **Complemento EN:** ações genuínas EN 1991-3 e mecanismos EN específicos, com esforços verticais/horizontais/axiais, torção e empenamento, seção nominal, estabilidade C.2, mesa inferior e serviço. Usa entradas, JSON e relatório próprios. Não transforma uma ação NBR em EN mudando o rótulo.

- **Fadiga nominal NBR ampliada:** usa os casos genuínos FAT8400 e a recuperação elástica com axial, torção e empenamento. Verifica planos nominais identificados pela Equação (D.5), sem alterar as equações resistentes herdadas ou importar fatores EN. Mantém explícitas as regiões não fechadas.

**Critério atendido não significa instalação aprovada.** Falha nominal testemunhada, majorante excedido, cálculo ausente e domínio não atendido são estados diferentes. Os exemplos são sintéticos, não dados de fabricante, aço de catálogo ou projeto real. Ligações/garfos reais, contato/raiz tridimensional e cobertura integral do equipamento continuam fora do fechamento.

## Usar localmente como uma opção

Ambiente de referência: Python 3.12, Linux. Windows/macOS têm scripts de inicialização, mas não foram executados nesses sistemas nesta entrega.

1. Extraia todo o ZIP.
2. No Windows, execute `iniciar_windows.bat`. Em Linux/macOS, execute `sh iniciar_linux_mac.sh`.
3. Abra o endereço local mostrado, normalmente `http://127.0.0.1:8501`.
4. Escolha a rota na navegação lateral. O complemento EN não importa resultados ou aprovações da rota NBR.

Alternativa manual:

```sh
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python -m streamlit run app.py --server.address 127.0.0.1 --browser.gatherUsageStats false
```

A primeira instalação requer internet. Depois, cálculo e Word funcionam com os pacotes locais. Não é necessário Word/LibreOffice para gerar a memória. O servidor fica limitado à própria máquina; não há publicação automática em GitHub ou Streamlit Cloud.

## Preparar GitHub e Streamlit Community Cloud

O pacote também está organizado para hospedagem Streamlit, sem exigir executar Python no computador de trabalho. **A implantação online não foi executada nem validada nesta entrega.** Os testes registrados são do ambiente Linux local em nuvem; limites de memória/tempo e configurações do serviço devem ser conferidos após a hospedagem.

1. Coloque o **conteúdo extraído** do pacote em um repositório GitHub, mantendo a estrutura. Não envie apenas `app.py` nem apenas o ZIP.
2. Preserve todos os arquivos Python da raiz, `requirements.txt`, `pages/`, `monorail/`, `en_actions/`, `lro_beams/` com seus dados de catálogo, `underslung_runway_candidate/` e `top_unstiffened_candidate/`. Mantenha também `examples/` e `docs/` para consulta; não envie `.venv`, caches ou o ZIP opcional de evidências.
3. No Streamlit Community Cloud, selecione repositório, branch e **entrypoint `app.py`**. Se a pasta inteira ficou dentro de outra, informe o caminho relativo completo desse mesmo arquivo, não uma página secundária.
4. Em **Advanced settings**, selecione **Python 3.12**, a versão verificada para o pacote. O serviço admite a escolha da versão no diálogo de implantação. [Documentação oficial de implantação](https://docs.streamlit.io/deploy/streamlit-community-cloud/deploy-your-app/deploy).
5. Use o `requirements.txt` fornecido, junto de `app.py` ou na raiz do repositório. Não o substitua por `requirements-dev.txt`, que serve somente aos testes. [Documentação oficial de dependências](https://docs.streamlit.io/deploy/streamlit-community-cloud/deploy-your-app/app-dependencies).
6. Depois de implantar, confira os logs e execute os exemplos preenchido, reprovado e pendente, incluindo download de JSON e Word nas três páginas. A aprovação dos testes locais não substitui esse ensaio no serviço.

O aplicativo não requer segredo de API, Robot, Word ou LibreOffice para calcular e gerar DOCX. Os programas usados para renderizar os documentos de auditoria não são dependências de operação. Os scripts `.bat`/`.sh` são apenas para a opção local; não são o entrypoint da hospedagem.

Revise a visibilidade do repositório e do aplicativo antes de compartilhar. Mantenha apenas exemplos sintéticos no repositório de demonstração; não publique dados reais de clientes, projetos ou fontes privadas sem a revisão de acesso apropriada. Esta entrega não cria repositório, não transfere arquivos ao GitHub e não publica o app.

## Usar o complemento EN

1. Comece pelo exemplo sintético preenchido. Há também cenários com dados pendentes, critérios não atendidos e seção fora do domínio resistente. Eles testam a operação do programa, não aprovam equipamentos.
2. Informe vão entre apoios, seção, material, distância `n` da borda ao contato, posições das rodas e percurso. Duas rodas opostas por estação, nas posições físicas `y/z` da mesa inferior; alterações da seção não deslocam os contatos silenciosamente.
3. Separe peso móvel da talha/trole `Qc`, carga útil nominal/operacional, acessórios retidos e cordas suspensas. `Qc` é variável móvel; não é peso fixo da viga. O peso próprio `G_beam` deve coincidir com a seção/massa linear adotada; use o botão explícito de atualização após mudar a seção.
4. Declare HC e velocidade real para içamento. Não há equivalência automática com HD, grupos NBR ou CMAA. A hipótese de translação `φ4=1` precisa de uma base declarada; não é assumida quando faltam dados.
5. Forças laterais devem ser fornecidas por roda, com direção, posição, dinâmica e simultaneidade. O fallback longitudinal de 5% não cria uma força transversal de 5%. Conjuntos não são somados nem invertidos sem declaração explícita.
6. O modelo usa garfos extremos e empenamento livre. Não credita travamentos intermediários nem estabilização extra pela carga inferior. Força longitudinal requer a idealização axial explícita: restrição no centro de cisalhamento à esquerda, direita livre e forças iguais no par.
7. Declare material, norma de produto e fontes, coeficientes e adoção das edições. Os valores recomendados EN não significam Anexo Nacional verificado.
8. Calcule e inspecione cada mecanismo, grupo e caso. A busca móvel pode levar alguns minutos, com progresso visível. Grupos sem dados não geram casos numéricos; calcular todos os casos gerados não fecha esses grupos.
9. Salve a **entrada JSON EN** e exporte Word/JSON de evidência. Falhas e pendências não impedem exportar cálculo íntegro. Qualquer edição invalida resultado e Word anteriores.

O resumo principal usa variantes de ações completas. O subconjunto vertical parcial G6, quando gerado como referência diagnóstica, fica em tabela/contagens separadas e permanece nos dados, sem virar PASS nem substituir uma variante completa. Obrigações externas e eventos não cobertos continuam explícitos.

## Usar a fadiga nominal NBR ampliada

1. Abra a página **Fadiga NBR** e escolha um exemplo sintético ou preencha os dados próprios. O exemplo vertical é preenchido; os demais mostram força lateral, axial+torção, majorante excedido, vínculo axial ausente e dados de fadiga ausentes.
2. A importação da entrada NBR 0.1 é um botão separado. Ela copia geometria e ações, mas não preenche ou aprova o novo grupo do componente, detalhe, fontes ou adoção do método. JSON EN e JSON de resultados são recusados.
3. Separe carga útil, massa talha/trole e massa retida; informe ações horizontais por estação. Os dois sentidos prescritos e os estados carregado/vazio são mantidos. O coeficiente de grupo Mₓ não entra na fadiga; os momentos fletores continuam presentes.
4. Declare material, grupo E1–E8 do componente, detalhe W0 em material-base laminado sem entalhe, requisito de fabricação e respectivas fontes. Esses campos não comprovam fabricação/inspeção executadas. Não há equivalência automática com classe CMAA ou grupo EN.
5. Declare explicitamente a adoção conservadora κ=−1 e a tolerância numérica. Não se inventa uma história de ciclos. Força longitudinal requer a idealização axial explícita; sem ela os casos afetados ficam não calculados, nunca zerados.
6. Calcule e examine os resultados por região, ponto e face. Os intervalos de componentes são limites conservadores, não componentes máximas concomitantes. **Majorante excedido não é falha de fadiga demonstrada.**
7. Exporte entrada, evidência e Word mesmo quando existirem pendências ou majorantes excedidos. Uma mudança de entrada exige novo cálculo.

No exemplo vertical remoto, os quinze planos nominais são verificáveis. Com cortante lateral, a alma pode ficar pendente pela componente fora do plano coberto, sem apagar as mesas calculáveis. Não se somam esses resultados para emitir aprovação da seção inteira. A combinação σN+σM+σB+0,75σ0x é uma aplicação conjunta interpretativa das normas NBR e da recuperação elástica, identificada na memória, não uma nova equação literal da NBR 10084.

Esta página não fecha resistência estática NBR com torção, instabilidade, segunda ordem, contato/raiz real, soldas, furos, ligações ou vida em ciclos. Seu resultado não substitui os demais mecanismos do projeto. Veja `docs/BASE_FADIGA_NBR.md` e `docs/ESCOPO_030.md`.

## O que significa cada resultado

- **Atende no domínio:** critério identificado atendido pelas ações e hipóteses registradas.
- **Não atende:** existe um estado nominal concomitante testemunhado que excede aquele critério. Não é previsão de ruptura física.
- **Majorante excedido:** o limite conservador excede a capacidade; isso, sozinho, não demonstra falha testemunhada.
- **Pendente:** falta dado, hipótese qualificada ou fechamento aplicável.
- **Fora do domínio:** a rota não cobre o mecanismo/seção/estado, sem concluir que a seção falha.
- **Não calculado:** resposta ou verificação não pôde ser concluída. O erro fica registrado, não é convertido em resistência atendida.

## Limites importantes

Somente um vão reto, seção uniforme e rodas dentro do vão. Não dimensiona curvas, desvios, continuidade/multivãos, talhas múltiplas, ligações/suspensões, enrijecedores ou instalação completa. A rota EN inicial usa I laminado duplamente simétrico com abas paralelas; rodas verticais desiguais no mesmo par não são promediadas.

A estabilidade C.2 tem guardas próprias, incluindo classe 1–3, bimomento e primeira ordem axial. Compressão com biflexão arbitrária pode ficar pendente sem invalidar automaticamente a seção nominal calculável. A região interior da mesa tem afastamentos estritos das extremidades; não se interpola uma regra de ponta sobre a faixa não coberta.

No ELU local, o resultado publicado para flexão global e o complemento conservador N/M/B aparecem separados. O complemento não é apresentado como texto literal da Eq.6.2 nem como prova integral da interação. As tensões locais de serviço EN entram integralmente, sem o redutor longitudinal NBR 0,75. Flecha da carga útil nominal `L/500` e flecha total sem dinâmica `min(L/600,25 mm)` são verificações distintas.

CMAA 70/74 não cobrem integralmente a monovia fixa e sua estrutura-suporte. Esta entrega não declara conformidade integral CMAA, EN ou NBR, nem dispensa dados e revisão de projeto.

## Documentação e testes

- `docs/GUIA_ROTA_NBR_010.md`: operação e limites da rota NBR preservada.
- `docs/BASE_FADIGA_NBR.md`: aplicação conjunta NBR, hipóteses e limites da fadiga nominal ampliada.
- `docs/BASE_EN.md`: edições, mecanismos, fontes e hipóteses do complemento EN.
- `docs/REUSO_E_PROVENIENCIA.md`: origem preservada do aplicativo de rolamento.
- `examples/`: entradas sintéticas e memórias selecionadas.
- ZIP de evidências separado: testes executáveis e relatórios independentes. Não é necessário para operar o app.

A inspeção funcional foi feita por testes automatizados da interface e a memória Word foi renderizada para revisão. A inspeção visual da interface em navegador permanece distinta e não é alegada quando bloqueada pelo ambiente de teste.
