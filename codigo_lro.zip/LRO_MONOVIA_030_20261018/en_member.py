"""Independent EN nominal-section and Annex C.2 consumer.

No NBR action/resistance conversion is performed. The public entry point only
accepts a regenerated EN action receipt and its own analytical-scan receipt.
The preserved EN2025 kernel supplies ALL resistance/interaction equations.
Independent component extrema form a conservative nominal stress box, not a
concurrent physical state or a mathematically certified translation enclosure.
"""
from __future__ import annotations
from dataclasses import asdict, dataclass, replace
import math
from hashlib import sha256
from pathlib import Path

from monorail.analysis import digest
from lro_beams.document_metadata import validate_xml_text
from lro_beams.beam_stability import StabilitySegment, HeightPointLoad, HeightLineLoad
from lro_beams.runway_stability_en2025 import EN2025C2Input, calculate_supplemental_c2
from underslung_runway_candidate.section_stress.recovery import ISection, geometric_properties
from underslung_runway_candidate.section_stress.whole_section_bounds import whole_section_shear_bound
from underslung_runway_candidate.stability.reference import first_order_axial_gate, transverse_dead_load_radius_guard
from underslung_runway_candidate.autonomous_workflow.model import PhysicalWheel, MovingCase

RESISTANCE_EDITION = 'EN 1993-1-1:2022, adopted through DIN EN 1993-1-1:2025-04'
SUPPORT_EDITION = 'EN 1993-6:2007 + AC:2009'
PROFILE = 'recommended_EN_values_no_verified_national_annex'
SOURCE = 'https://application.wiley-vch.de/books/sample/3433034680_c01.pdf'
MAPPING = {'N':('N_N',1), 'My':('Mstrong_Nmm',-1), 'Mz':('Mweak_Nmm',-1),
    'B':('B_Nmm2',-1), 'Fy':('Flateral_N',1), 'Fz':('Fvertical_N',-1),
    'Tsv':('Tsv_Nmm',-1), 'Tw_equilibrated':('Tw_Nmm',-1)}


def _number(value, name, *, positive=False):
    message=name+' must be finite real, not boolean'
    if isinstance(value,bool) or not isinstance(value,(int,float)):raise ValueError(message)
    try:value=float(value)
    except (OverflowError,ValueError) as exc:raise ValueError(message) from exc
    if not math.isfinite(value):raise ValueError(message)
    if positive and value<=0:raise ValueError(name+' must be positive')
    return value


def _text(value,name):
    validate_xml_text(value,name,max_length=10000)
    if not isinstance(value,str) or not value.strip():raise ValueError(name+' must identify its documentary basis')
    return value


@dataclass(frozen=True)
class ENResistanceBasis:
    """Explicit adopted material and resistance basis, never inferred from NBR.

    Sources are engineering input declarations, not evidence that a mill
    certificate, national annex or physical connection has been independently
    inspected. This initial consumer supports product-standard option a only.
    """
    fy_mpa: float
    fu_mpa: float
    E_mpa: float
    G_mpa: float
    product_standard: str
    material_grade: str
    strength_thickness_source: str
    ductility_source: str
    elasticity_source: str
    gamma_M0: float
    gamma_M1: float
    partial_factor_source: str
    method_adoption_source: str
    physical_model_source: str
    maximum_accepted_numerical_relative_tolerance: float
    numerical_acceptance_source: str
    ductility_basis: str
    toughness_source: str
    elongation_percent: float | None = None
    property_option: str = 'product_standard_option_a'
    resistance_edition: str = RESISTANCE_EDITION
    supporting_structure_edition: str = SUPPORT_EDITION
    national_profile: str = PROFILE
    structural_steel_ambient: bool = True

    def validate(self,project=None):
        for key in ('fy_mpa','fu_mpa','E_mpa','G_mpa','gamma_M0','gamma_M1'):
            _number(getattr(self,key),key,positive=True)
        if not 200<=self.fy_mpa<=700 or self.fu_mpa<self.fy_mpa:
            raise ValueError('EN kernel supports documented structural steel fy 200–700 MPa with fu >= fy')
        if self.fu_mpa/self.fy_mpa<1.05:
            raise ValueError('Elastic EN material ductility requires fu/fy >=1.05')
        if self.E_mpa!=210000. or not math.isclose(self.G_mpa,210000./2.6,rel_tol=1e-12,abs_tol=0):
            raise ValueError('Prescribed EN elasticity requires E=210000 MPa, nu=0.3 and G=E/[2(1+nu)]; recalculate, do not relabel NBR stiffness')
        if self.ductility_basis not in ('listed_product_presumption_5_2_2_2','documented_elastic_elongation'):
            raise ValueError('Explicit elastic ductility basis required')
        if self.elongation_percent is not None:
            _number(self.elongation_percent,'elongation percent',positive=True)
            if self.elongation_percent<12:raise ValueError('Specified elastic elongation cannot contradict the >=12 percent material requirement')
        if self.ductility_basis=='documented_elastic_elongation' and (self.elongation_percent is None or self.elongation_percent<12):
            raise ValueError('Documented elastic elongation must be >=12 percent on base 5.65 sqrt(A0)')
        if min(self.gamma_M0,self.gamma_M1)<1:raise ValueError('Partial resistance factors must be >=1')
        for key in ('product_standard','material_grade','strength_thickness_source','ductility_source',
                    'elasticity_source','partial_factor_source','method_adoption_source','physical_model_source',
                    'numerical_acceptance_source','toughness_source'):_text(getattr(self,key),key)
        if self.property_option!='product_standard_option_a':raise ValueError('Only product-standard material option a is qualified; simplified-table option b is not silently substituted')
        if self.resistance_edition!=RESISTANCE_EDITION or self.supporting_structure_edition!=SUPPORT_EDITION:
            raise ValueError('Only the explicitly audited editions are implemented')
        if self.national_profile!=PROFILE:raise ValueError('No national annex conformity has been established')
        if type(self.structural_steel_ambient) is not bool or not self.structural_steel_ambient:
            raise ValueError('Ambient structural-steel domain must be explicit')
        tol=_number(self.maximum_accepted_numerical_relative_tolerance,'numerical acceptance tolerance',positive=True)
        if not .0001<=tol<=.02:raise ValueError('Acceptance tolerance outside supported numerical domain')
        if project is not None:
            project.validate()
            for key in ('fy_mpa','fu_mpa','E_mpa','G_mpa'):
                if not math.isclose(getattr(project.material,key),getattr(self,key),rel_tol=1e-12,abs_tol=0):
                    raise ValueError('EN material differs from solved project: '+key)
        return self


def _intervals_from_scan(scan):
    out={}
    if set(scan.get('right_hand_resultant_intervals',{}))!=set(MAPPING):
        raise ValueError('All eight signed RH resultant intervals required')
    for name,(component,sign) in MAPPING.items():
        low=_number(scan['extrema'][component]['min']['value'],component+' min')
        high=_number(scan['extrema'][component]['max']['value'],component+' max')
        if low>high:raise ValueError('Unordered numerical extrema')
        lo,hi=(low,high) if sign>0 else (-high,-low)
        expected=dict(lower=lo,upper=hi,source_component=component,sign_multiplier=sign)
        if scan['right_hand_resultant_intervals'][name]!=expected:
            raise ValueError('Signed Green-to-RH conversion differs: '+name)
        out[name]=(lo,hi)
    return out


def _numerical_pending(scan,basis):
    pending=[]
    if scan.get('numerical_converged') is not True or scan.get('evidence_kind')!='analytical_space_nested_translation_converged':
        pending.append('Nested physical-translation refinement has not converged.')
    if scan.get('continuum_upper_bound_claimed') is not False or scan.get('fixed_FE_receipt_claimed') is not False:
        raise ValueError('Analytical numerical scan cannot claim continuum enclosure or an FE receipt')
    c=scan['controls'];history=scan['history']
    if c['stable_passes']<2 or not history or history[-1]['stable_passes']<2:
        pending.append('At least two stable nested-refinement passes are required.')
    if c['relative_tolerance']>basis.maximum_accepted_numerical_relative_tolerance:
        pending.append('Scanner tolerance exceeds the declared engineering acceptance tolerance.')
    return pending


def _section(project):
    s=project.section
    if s.fabrication!='rolled' or not s.doubly_symmetric:
        raise ValueError('Initial whole-nominal-section domain is a parallel doubly symmetric rolled I')
    if not project.end_forks_confirmed:raise ValueError('Explicit end-fork premise required')
    return ISection(s.d_mm,s.bf_mm,s.tf_mm,s.tw_mm,construction='rolled',bottom_root_radius_mm=s.root_radius_mm)


def _reference_from_response(project,response):
    """Actual continuous quadratic pieces, retaining Hx*z moment jumps."""
    edges=sorted({0.,project.span_m,*[w.position_m for w in response.vertical.all_loads]})
    segments=[]
    for a,b in zip(edges,edges[1:]):
        if a==b:continue
        left=response.at(a,'right');mid=response.at((a+b)/2);right=response.at(b,'left')
        segments.append(StabilitySegment(a*1000,b*1000,left['Mx_knm']*1e6,
            mid['Mx_knm']*1e6,right['Mx_knm']*1e6,max(0.,-mid['N_kn']*1000)))
    return tuple(segments)


def _radial_guard(case):
    """Adapt final physical EN forces ONCE to the preserved mechanical guard."""
    wheels=[]
    for w in case.wheel_loads:
        if w.fz_kn>0:raise ValueError('Initial EN monorail consumer does not qualify uplift contact forces')
        wheels.append(PhysicalWheel(w.wheel_id,w.offset_m*1000,w.y_m*1000,w.z_m*1000,
            0.,-w.fz_kn*1000,0.,w.fs_kn*1000,w.fy_kn*1000,
            'Final EN wheel forces already factored; unit multipliers only for radial-work mechanics',True))
    unity=MovingCase(case.id,'EN_final_force_mechanical_guard',1.,1.,1.,1.,1.,1,1,True,
        'No force conversion: final EN forces with exact unit factors')
    parcels=tuple(dict(qy=0.,qz=-q.downward_kn_per_m,y=0.,z=0.) for q in case.fixed_loads)
    return transverse_dead_load_radius_guard(tuple(wheels),unity,distributed_parcels=parcels)


def _format_check(check,*,pending=(),outside=()):
    item=dict(check)
    item['kernel_status']=item.pop('status')
    item['status']='OUT_OF_SCOPE' if outside else 'PENDING' if pending else (
        'PASS' if item['kernel_status']=='ATENDE NO DOMÍNIO' else 'BOUND_EXCEEDED')
    item['reasons']=list(outside or pending)
    item.update(evidence='component_box_over_numerically_converged_scan',
        actual_failure_proven=False,concurrent_state_claimed=False,
        continuum_upper_bound_claimed=False,whole_design_approved=False)
    return item


def _evaluate_kernel_components(project,basis,intervals,segments,*,height_points=(),height_lines=(),radial_guard,numerical_pending=()):
    """Private equation adapter. Its caller must first qualify the action receipt."""
    basis.validate(project);s=_section(project);g=geometric_properties(s)
    mag={k:max(abs(lo),abs(hi)) for k,(lo,hi) in intervals.items()}
    compression=max(0.,-intervals['N'][0])
    axial=first_order_axial_gate(E_mpa=basis.E_mpa,Imajor_mm4=g['Iy_mm4'],Iminor_mm4=g['Iz_mm4'],
        length_mm=project.span_m*1000,compression_upper_n=compression)
    shear=whole_section_shear_bound(s,abs_Fy_N=mag['Fy'],abs_Fz_N=mag['Fz'],
        abs_Tsv_Nmm=mag['Tsv'],abs_Tw_Nmm=mag['Tw_equilibrated'])
    d=EN2025C2Input(span_mm=project.span_m*1000,E_mpa=basis.E_mpa,G_mpa=basis.G_mpa,fy_mpa=basis.fy_mpa,
        depth_mm=s.d_mm,flange_width_mm=s.bf_mm,flange_thickness_mm=s.tf_mm,web_thickness_mm=s.tw_mm,
        area_mm2=g['A_mm2'],major_inertia_mm4=g['Iy_mm4'],minor_inertia_mm4=g['Iz_mm4'],
        major_elastic_modulus_mm3=2*g['Iy_mm4']/s.d_mm,minor_elastic_modulus_mm3=2*g['Iz_mm4']/s.bf_mm,
        axial_abs_max_n=mag['N'],compression_max_n=compression,major_moment_max_nmm=mag['My'],
        minor_moment_max_nmm=mag['Mz'],bimoment_max_nmm2=mag['B'],shear_stress_bound_mpa=shear['tau_bound_mpa'],
        resistance_gamma=basis.gamma_M1,major_segments=segments,height_points=tuple(height_points),height_lines=tuple(height_lines),
        uniform_fork_free_warping_system=True,structural_steel_ambient=True,complete_same_case_envelopes=True,
        method_adoption_source=basis.method_adoption_source,section_resistance_mode='full_section',
        classification_segments=(),use_nbr8800_chi_cap=False)
    member=calculate_supplemental_c2(d)
    section=calculate_supplemental_c2(replace(d,resistance_gamma=basis.gamma_M0))
    if not member['input_valid'] or not section['input_valid']:
        raise ValueError('Preserved EN kernel rejected inputs: '+'; '.join(member['errors']+section['errors']))
    common=list(numerical_pending)
    if not axial['non_sway_flexural_first_order_sufficient']:
        common.append('First-order non-sway axial gate Ncomp <= min(Ncr,y,Ncr,z)/25 not established; no LTB exemption follows.')
    i=member['intermediates'];outside=[]
    if not i['flange_class3_sufficient']:outside.append('Conservative class1–3 flange gate not met; this is not proof that the physical section fails.')
    if not i['web_class3_sufficient']:outside.append('Conservative uniform-compression class1–3 web gate not met; gradient-dependent or effective-section route required.')
    section_checks=[_format_check(c,pending=common,outside=outside) for c in section['checks'] if c['id']=='en2025_c2_global_section_bound']
    member_pending=list(common)
    cm_qualified=not (compression>0 and mag['Mz']>0)
    cm_basis=('No compression: the adopted interaction uses no compression-amplification terms.' if compression==0 else
        'Major-axis-only compression/bending: DIN EN1993-1-1:2025 section8.3.3(14) explicitly permits Cm=1 and kzy=1; inherited k upper bounds are no smaller.' if mag['Mz']==0 else
        'Compression plus arbitrary biaxial moving moments: inherited k upper bounds assume Cm<=1; this general diagram qualification has not been established by the audited source.')
    if not cm_qualified:member_pending.append(cm_basis)
    if not radial_guard['no_destabilizing_transverse_load_radius']:
        member_pending.append('Actual per-contact transverse dead-force radial work is adverse; retained-GJ reference not qualified for this case.')
    member_outside=list(outside)
    if i['bimoment_characteristic_ratio']>.3*(1+1e-12):member_outside.append('C.2 domain BEd/BRk <=0.30 exceeded; section resistance remains separate.')
    member_checks=[_format_check(c,pending=member_pending,outside=member_outside) for c in member['checks'] if c['id']!='en2025_c2_global_section_bound']
    if not member_checks:
        member_checks=[dict(id='en2025_c2_member_domain',status='OUT_OF_SCOPE' if member_outside else 'PENDING',
            reasons=member_outside or member_pending or member['pending'],source=SOURCE,
            actual_failure_proven=False,whole_design_approved=False)]
    # Under the deliberately stronger hw/tw <=38 epsilon gate, the 60 epsilon
    # shear-buckling referral threshold is not reached (eta=1.2 permitted).
    shear_gate=dict(web_plate_height_mm=s.d_mm-2*s.tf_mm,web_height_over_thickness=(s.d_mm-2*s.tf_mm)/s.tw_mm,
        epsilon=math.sqrt(235/basis.fy_mpa),uniform_class3_limit=38*math.sqrt(235/basis.fy_mpa),
        shear_buckling_referral_limit=60*math.sqrt(235/basis.fy_mpa),eta=1.2,
        referral_not_triggered=i['web_class3_sufficient'],
        source='DIN EN1993-1-1:2025 §8.2.6(6), Eq8.27; adopted hw=d-2tf, no root deduction')
    return dict(section_checks=section_checks,member_checks=member_checks,
        axial_first_order_gate=axial,radial_guard=radial_guard,shear_buckling_gate=shear_gate,
        moment_factor_qualification=dict(qualified=cm_qualified,basis=cm_basis,
            conservative_k_not_literal_normative_coefficients=True,compression_upper_n=compression,minor_moment_magnitude_nmm=mag['Mz']),
        Mcr_reference_sources=['SCI P360 Eq2.13 and sections2.4–2.5: https://www.steelconstruction.info/images/0/0e/Sci_p360.pdf',
            'NCCI SN003b sections1–2 Eq3: https://steelconstruction.info/upload/Wiki-Files/0/0f/SN003b.pdf'],
        whole_nominal_shear=shear,kernel_member=member,kernel_section=section,
        gamma_M0=basis.gamma_M0,gamma_M1=basis.gamma_M1,
        nominal_section_only=True,actual_3d_root_contact_tensor_complete=False,
        source=SOURCE,whole_design_approved=False)


def evaluate_en_member_case(project,*,action_input,action_receipt,case_id,scan,basis):
    """Qualified independent EN action -> numerical nominal section and C.2.

    Stale/mutated/foreign receipts raise ValueError. A genuine but unconverged
    scan remains PENDING. A conservative box exceedance is BOUND_EXCEEDED, never
    a physical FAIL. Contact, local wheel stresses, fatigue, service, vibration,
    and connections are deliberately separate from these two mechanisms.
    """
    consumer_identity=sha256(Path(__file__).read_bytes()).hexdigest()
    from en_actions import assert_case_receipt
    from en_analytical_scan import response_factory, assert_en_scan_current
    from analytical_scan import AxialTransfer
    if not isinstance(basis,ENResistanceBasis):raise ValueError('Typed independent ENResistanceBasis required')
    basis.validate(project)
    case=assert_case_receipt(action_input,action_receipt,case_id)
    assert_en_scan_current(project,action_input,action_receipt,case_id,scan)
    if case.family not in ('EN_ULS_STR','EN_TEST_ULS'):raise ValueError('EN_ULS_STR or genuine EN_TEST_ULS action family required for this resistance consumer')
    intervals=_intervals_from_scan(scan)
    pending=_numerical_pending(scan,basis)
    if case.action_generation_complete is not True:
        pending.append('Required components of this EN action group are missing; a vertical subset cannot close the group.')
    for requirement in case.requirements:
        if requirement.category=='missing_input' and requirement.blocking_in_scope:
            pending.append(requirement.code+': '+requirement.detail)
        elif requirement.category=='mechanical_qualification' and requirement.code!='longitudinal_response_and_resistance_require_separate_consumer_qualification':
            pending.append('Unresolved mechanical requirement: '+requirement.code)
    axial_data=scan['metadata'].get('axial_transfer')
    axial_transfer=AxialTransfer(**axial_data) if axial_data is not None else None
    factory,metadata=response_factory(project,action_input,action_receipt,case_id,axial_transfer=axial_transfer)
    longitudinal_resolution=[]
    for requirement in case.mechanical_requirements:
        if requirement.code=='longitudinal_response_and_resistance_require_separate_consumer_qualification':
            if axial_transfer is None:raise ValueError('Longitudinal requirement cannot be resolved without the actual axial-transfer premise')
            longitudinal_resolution.append(dict(requirement=asdict(requirement),mechanical_response_qualified=True,
                evidence='Regenerated EN response factory verifies equal opposed Hs, retains N and Hs*z, cancels only opposite Mz/B, and validates AxialTransfer. Member resistance follows separate Ncr/25 and C.2 domain checks.'))
    if metadata!=scan['metadata']:raise ValueError('Regenerated mechanical metadata differs from scan')
    g=geometric_properties(_section(project));props=metadata['properties']
    for name,value in (('A_mm2',g['A_mm2']),('Ix_mm4',g['Iy_mm4']),('Iy_mm4',g['Iz_mm4']),('J_mm4',g['J_mm4']),('Cw_mm6',g['Cw_mm6'])):
        if not math.isclose(props[name],value,rel_tol=1e-12,abs_tol=0):raise ValueError('Canonical response/recovery stiffness mismatch: '+name)
    witnesses=scan['extrema']['Mstrong_Nmm']
    witness=max(witnesses.values(),key=lambda row:abs(row['value']))
    translation=witness['translation_m'];response=factory(translation)
    segments=_reference_from_response(project,response)
    points=tuple(HeightPointLoad((translation+w.offset_m)*1000,-w.fz_kn*1000,w.z_m*1000) for w in case.wheel_loads)
    lines=tuple(HeightLineLoad(0.,project.span_m*1000,q.downward_kn_per_m,0.) for q in case.fixed_loads)
    result=_evaluate_kernel_components(project,basis,intervals,segments,height_points=points,height_lines=lines,
        radial_guard=_radial_guard(case),numerical_pending=pending)
    # Recheck action/code identities after recovery: no stale receipt gap.
    assert_en_scan_current(project,action_input,action_receipt,case_id,scan)
    if consumer_identity!=sha256(Path(__file__).read_bytes()).hexdigest():raise ValueError('Resistance consumer changed during evaluation')
    result.update(kind='independent_EN_member_mechanisms',case_id=case.id,action_family=case.family,
        consumer_identity=dict(module=Path(__file__).name,sha256=consumer_identity),action_binding=scan['action_binding'],
        producer_pending_preserved=list(case.pending),producer_requirements=[asdict(r) for r in case.requirements],
        external_coverage_limitations=[asdict(r) for r in case.coverage_limitations],
        mechanical_requirement_resolutions=longitudinal_resolution,
        case_action_generation_complete=case.action_generation_complete,equipment_action_coverage_qualified=False,
        basis=asdict(basis),numerical_evidence=dict(kind=scan['evidence_kind'],controls=scan['controls'],history=scan['history'],
            result_signature=scan['result_signature'],source_dependencies=scan['dependencies'],
            root_coordinate_tolerance_mm=scan['spatial_root_coordinate_tolerance_mm'],
            accepted_numerical_model=not pending,continuum_upper_bound_claimed=False),
        reference_translation_m=translation,reference_segments=[asdict(s) for s in segments],
        right_hand_resultant_intervals=scan['right_hand_resultant_intervals'],
        other_mechanisms_pending=['Lower-flange wheel local stress/interaction', 'Fatigue', 'Service and vibration',
            'Physical end-fork/axial connection strength and stiffness', 'Actual contact and rolled-root concentration regions'],
        no_NBR_to_EN_conversion=True,national_conformity_claimed=False,full_design_approval=False,
        limitations=['Adopted EN editions and product-standard material basis must be reviewed for the actual project.',
            'Numerically converged translation extrema are engineering evidence, not a certified continuous-motion enclosure.',
            'The nominal whole-section box includes N, both bending moments, B, both transverse forces, Tsv and Tw; maxima need not coexist.',
            'Independent gammaM0 and gammaM1 calls preserve separate section and instability resistance bases.',
            'Full-span conservative reference; beneficial lower load height and intermediate restraint credit are discarded.',
            'Exceeding a conservative interaction or stress box does not prove physical failure.'])
    result['result_signature']=digest(result)
    return result
