"""Application orchestration for the independent EN monorail complement.

Every generated action case is retained. A missing mechanical premise or an
unsupported mechanism produces an explicit incomplete row, never silent case
omission. This module introduces no structural resistance equation.
"""
from copy import deepcopy
from dataclasses import asdict
from datetime import datetime,timezone
from hashlib import sha256
from pathlib import Path
import json,math,time

from monorail.analysis import digest,source_receipt
from en_actions import generate_actions
from en_actions.generator import generator_fingerprint
from en_project import ENProject
from analytical_scan import Controls,physical_reactions,_state_with_contacts
from en_analytical_scan import scan_case,response_factory
from en_member import evaluate_en_member_case
from en_local_service import evaluate_en_local_case,evaluate_en_deflection_case

VERSION='0.2.0-en-complement'
CORE_FILES=('analytical_scan.py','en_analytical_scan.py','en_member.py','en_local_service.py','en_project.py','en_analysis.py')
STATUS_ORDER={'PASS':0,'BOUND_EXCEEDED':1,'PENDING':2,'OUT_OF_SCOPE':3,'OUT_OF_DOMAIN':3,'NOT_CALCULATED':4,'FAIL':5}
MECHANISM_LABELS={
    'global_section':'Seção nominal global, ELU', 'member_stability':'Estabilidade de barra, EN Anexo C.2',
    'local_published':'Mesa inferior, ELU publicado para flexão global',
    'local_engineering_supplement':'Mesa inferior, complemento conservador N/M/B',
    'local_service':'Tensões locais e globais, serviço', 'global_service':'Tensões nominais globais, serviço',
    'vertical_service':'Flecha vertical, serviço', 'mechanical_response':'Resposta mecânica'}
LIMITATIONS=[
    'Relatório delimitado aos mecanismos explicitamente calculados, sem aprovação integral do equipamento ou da estrutura.',
    'Monovia reta de um vão, seção I laminada duplamente simétrica, abas paralelas, dois contatos opostos por estação e rodas dentro do vão.',
    'Garfos nas extremidades e empenamento livre; travamentos intermediários e estabilização pelo nível inferior não recebem crédito resistente nesta rota EN.',
    'Hs requer distribuição igual no par e vínculo axial explícito no centro de cisalhamento à esquerda, com extremidade direita livre axialmente.',
    'Tensões nominais não constituem solução tridimensional do contato, concordância laminada, soldas, enrijecedores ou ligações.',
    'Fadiga EN, vibrações, acessórios, desvios/curvas, múltiplos vãos, impacto em batentes e cobertura de todos os eventos reais do equipamento não são fechados por esta rota.',
    'Fontes de fabricante, certificados, tenacidade, efetividade dos garfos/vínculos e aplicabilidade das edições/Anexo Nacional dependem de documentação e revisão do projeto.',
    'A busca de posições móveis usa convergência numérica de engenharia; não é um majorante matemático certificado do contínuo.',
    'Exceder um limite conservador exige avaliação adicional; só um estado nominal concomitante testemunhado é classificado como falha do critério calculado.',
    'Eq.6.2 é conservada com tensão de flexão global. Uma avaliação N/M/B adicional, quando necessária, é complemento de engenharia identificado, não generalização normativa literal nem prova completa da interação.',
]


def code_receipt():
    root=Path(__file__).resolve().parent
    files={name:sha256((root/name).read_bytes()).hexdigest() for name in CORE_FILES}
    return dict(core_files=files,legacy=source_receipt(),action_generator_fingerprint=generator_fingerprint(),
        fingerprint=digest(dict(core=files,legacy=source_receipt()['fingerprint'],actions=generator_fingerprint())))


def _status(checks):
    return max((c.get('status','PENDING') for c in checks),key=lambda x:STATUS_ORDER.get(x,3),default='PENDING')


def _tag(check,mechanism):
    return dict(deepcopy(check),mechanism=mechanism,mechanism_label=MECHANISM_LABELS[mechanism])


def _local_checks(local,case,basis):
    if case.family not in ('EN_ULS_STR','EN_TEST_ULS'):
        return [_tag(c,'global_service' if c['id']=='service/global_nominal' else 'local_service') for c in local['checks']]
    out=[]
    for check in local['checks']:
        if 'evaluations' not in check:
            out.append(_tag(check,'local_published'));continue
        mid=check['midflange_stress_bounds']
        # Expose the preserved published result separately from the adopted
        # supplementary global composition. No resistance formula is changed.
        for key,mechanism,bound_key in (
            ('published_bending','local_published','literal_bending_abs_bound_mpa'),
            ('expanded_global','local_engineering_supplement','expanded_N_M_B_abs_bound_mpa')):
            if key=='expanded_global' and math.isclose(mid['expanded_N_M_B_abs_bound_mpa'],mid['literal_bending_abs_bound_mpa'],rel_tol=0.,abs_tol=1e-12):
                continue
            ev=check['evaluations'][key];domain=mid[bound_key]<=basis.fy_mpa/basis.gamma_M0
            status='PENDING' if check['status']=='PENDING' else 'PASS' if domain and ev['capacity_N']>=check['individual_wheel_N'] else 'BOUND_EXCEEDED'
            out.append(_tag(dict(id=check['id']+'/'+key,status=status,utilization=ev['utilization'],
                individual_wheel_N=check['individual_wheel_N'],capacity_N=ev['capacity_N'],
                global_stress_bound_mpa=mid[bound_key],global_domain_sufficient=domain,
                reasons=check['reasons'],source=check['source'],published_kernel_result=deepcopy(ev),
                actual_failure_proven=False,full_interaction_qualification_claimed=False,
                engineering_supplement=key=='expanded_global',
                basis_note='Avaliação publicada com flexão global.' if key=='published_bending' else
                    'Complemento de engenharia adotado para N/M/B; não escrito literalmente na Eq.6.2. Não aumenta a capacidade publicada por cancelamento.'),mechanism))
    return out


def _family_mechanisms(family):
    if family in ('EN_ULS_STR','EN_TEST_ULS'):
        return ('global_section','member_stability','local_published','local_engineering_supplement')
    if family in ('EN_SLS_STRESS','EN_TEST_SLS'):
        return ('global_service','local_service')
    if family=='EN_SLS_DEFLECTION':return ('vertical_service',)
    return ()


def _summaries(rows):
    every_check=[dict(c,case_id=row['id']) for row in rows for c in row['checks']]
    qualified_rows=[row for row in rows if row['action_case']['action_generation_complete']]
    diagnostic_rows=[row for row in rows if not row['action_case']['action_generation_complete']]
    all_checks=[dict(c,case_id=row['id']) for row in qualified_rows for c in row['checks']]
    diagnostic_checks=[c for row in diagnostic_rows for c in row['checks']]
    counts={status:sum(c.get('status')==status for c in all_checks) for status in STATUS_ORDER}
    mechanisms=[]
    for key,title in MECHANISM_LABELS.items():
        checks=[c for c in all_checks if c['mechanism']==key]
        if not checks:continue
        numeric=[c for c in checks if type(c.get('utilization')) in (int,float) and math.isfinite(c['utilization'])]
        worst=max(numeric,key=lambda c:c['utilization'],default=None)
        mechanisms.append(dict(id=key,title=title,status=_status(checks),checks=len(checks),
            counts={s:sum(c['status']==s for c in checks) for s in STATUS_ORDER},
            governing_utilization=worst.get('utilization') if worst else None,
            governing_case_id=worst.get('case_id') if worst else None,
            governing_check_id=worst.get('id') if worst else None,
            calculation_coverage_complete=not any(c['status']=='NOT_CALCULATED' for c in checks),
            not_calculated_case_ids=sorted({c['case_id'] for c in checks if c['status']=='NOT_CALCULATED'})))
    return dict(checks_status=_status(all_checks),counts=counts,mechanisms=mechanisms,
        count_basis='Only generated cases with all components required by that explicit action variant. Partial reference subsets remain separately visible, never converted to PASS.',
        all_case_counts={status:sum(c.get('status')==status for c in every_check) for status in STATUS_ORDER},
        diagnostic_partial_counts={status:sum(c.get('status')==status for c in diagnostic_checks) for status in STATUS_ORDER},
        diagnostic_partial_cases=[row['id'] for row in diagnostic_rows],
        qualified_action_variant_cases=len(qualified_rows),

        generated_cases=len(rows),calculated_cases=sum(r['calculated'] for r in rows),
        converged_cases=sum(r['calculated'] and r['scan']['numerical_converged'] for r in rows),
        whole_design_approved=False,overall_status='RELATORIO_DELIMITADO',
        distinction='PASS é apenas o critério identificado; BOUND_EXCEEDED não comprova falha física; PENDING/NOT_CALCULATED indicam falta de fechamento, não reprovação do perfil.')


def analyze_en(bundle,progress=None):
    if type(bundle) is not ENProject:raise ValueError('Typed ENProject required')
    bundle.validate();input_signature=bundle.signature();sources=code_receipt();started=time.monotonic()
    receipt=generate_actions(bundle.actions);rows=[]
    controls=Controls(relative_tolerance=bundle.resistance.maximum_accepted_numerical_relative_tolerance)
    for index,case in enumerate(receipt.cases):
        if progress:progress(index/len(receipt.cases),case.title)
        row=dict(id=case.id,title=case.title,family=case.family,group_id=case.group_id,
            action_case=asdict(case),calculated=False,error=None,error_type=None,errors=[],
            scan=None,member=None,local=None,service=None,checks=[],completed_consumers=[])
        def record_error(exc,stage,*mechanisms):
            evidence=dict(stage=stage,error_type=type(exc).__name__,message=str(exc),case_id=case.id,affected_mechanisms=list(mechanisms))
            row['errors'].append(evidence)
            row['error']='; '.join(e['stage']+': '+e['error_type']+': '+e['message'] for e in row['errors'])
            row['error_type']=row['errors'][0]['error_type']
            for mechanism in mechanisms:
                row['checks'].append(_tag(dict(id='calculation_incomplete/'+stage+'/'+mechanism,status='NOT_CALCULATED',
                    reasons=[str(exc)],error_evidence=evidence,actual_failure_proven=False,
                    source='Domínio explicitamente suportado pelo consumidor EN'),mechanism))
        try:
            scan=scan_case(bundle.project,bundle.actions,receipt,case.id,controls=controls,axial_transfer=bundle.axial_transfer)
            row['scan']=scan;row['calculated']=True
        except (ValueError,ArithmeticError) as exc:
            record_error(exc,'mechanical_scan','mechanical_response',*_family_mechanisms(case.family))
        if row['calculated']:
            kwargs=dict(action_input=bundle.actions,action_receipt=receipt,case_id=case.id,scan=scan,basis=bundle.resistance)
            # Independent consumers: an unavailable mechanism cannot silently
            # erase another calculable mechanism or manufacture a zero/PASS.
            if case.family in ('EN_ULS_STR','EN_TEST_ULS'):
                try:
                    row['member']=evaluate_en_member_case(bundle.project,**kwargs)
                    row['checks'] += [_tag(c,'global_section') for c in row['member']['section_checks']]
                    row['checks'] += [_tag(c,'member_stability') for c in row['member']['member_checks']]
                    row['completed_consumers'].append('member')
                except (ValueError,ArithmeticError) as exc:record_error(exc,'global_member','global_section','member_stability')
                try:
                    row['local']=evaluate_en_local_case(bundle.project,**kwargs)
                    row['checks'] += _local_checks(row['local'],case,bundle.resistance)
                    row['completed_consumers'].append('local')
                except (ValueError,ArithmeticError) as exc:record_error(exc,'local_ultimate','local_published','local_engineering_supplement')
            elif case.family in ('EN_SLS_STRESS','EN_TEST_SLS'):
                try:
                    row['local']=evaluate_en_local_case(bundle.project,**kwargs)
                    row['checks'] += _local_checks(row['local'],case,bundle.resistance)
                    row['completed_consumers'].append('local_service')
                except (ValueError,ArithmeticError) as exc:record_error(exc,'local_service','local_service','global_service')
            elif case.family=='EN_SLS_DEFLECTION':
                try:
                    row['service']=evaluate_en_deflection_case(bundle.project,**kwargs)
                    row['checks'] += [_tag(c,'vertical_service') for c in row['service']['checks']]
                    row['completed_consumers'].append('deflection')
                except (ValueError,ArithmeticError) as exc:record_error(exc,'vertical_service','vertical_service')
            else:record_error(ValueError('No qualified consumer for generated EN case family '+case.family),'consumer_selection','mechanical_response')
        row['status']=_status(row['checks']);rows.append(row)
    if bundle.signature()!=input_signature or sources!=code_receipt():raise ValueError('EN application inputs or source changed during calculation; discard the stale report')
    summary=_summaries(rows)
    summary['action_groups']=len(receipt.groups)
    summary['pending_input_groups']=[g.id for g in receipt.groups if g.generation_status!='ACTIONS_GENERATED']
    summary['incomplete_generated_cases']=[c.id for c in receipt.cases if not c.action_generation_complete]
    result=dict(format='LRO_MONORAIL_EN_CALCULATION',version=VERSION,created_utc=datetime.now(timezone.utc).isoformat(),
        input_signature=input_signature,input_snapshot=bundle.to_dict(),sources=sources,action_receipt=receipt.to_dict(),
        cases=rows,summary=summary,limitations=deepcopy(LIMITATIONS),demonstration=bundle.demonstration,
        wall_seconds=time.monotonic()-started,whole_design_approved=False,
        coordinate_convention='s longitudinal, y transversal, z para cima; rotações/torções pela mão direita em +s. N positivo em tração. Reações são do apoio SOBRE a viga; cargas na estrutura receptora têm sinal oposto.')
    result['result_signature']=digest(result)
    if progress:progress(1.,'Cálculo delimitado concluído')
    return result


def assert_current_en_result(bundle,result):
    if type(bundle) is not ENProject:raise ValueError('Typed ENProject required')
    bundle.validate()
    if type(result) is not dict or result.get('format')!='LRO_MONORAIL_EN_CALCULATION':raise ValueError('Execute a current EN calculation before export')
    if result.get('input_signature')!=bundle.signature() or digest(result.get('input_snapshot'))!=digest(bundle.to_dict()):raise ValueError('EN inputs changed; calculate again')
    if result.get('sources')!=code_receipt():raise ValueError('EN source changed; calculate again')
    body={k:v for k,v in result.items() if k!='result_signature'}
    if result.get('result_signature')!=digest(body):raise ValueError('EN calculation result was modified or is incomplete')
    receipt=generate_actions(bundle.actions)
    if digest(result['action_receipt'])!=digest(receipt.to_dict()):raise ValueError('EN action receipt no longer matches regenerated inputs')
    if [r['id'] for r in result['cases']]!=[c.id for c in receipt.cases]:raise ValueError('Generated EN cases were omitted or reordered')
    return result


def diagram_en(bundle,result,case_id,translation_m=None):
    assert_current_en_result(bundle,result)
    row=next((r for r in result['cases'] if r['id']==case_id),None)
    if row is None or not row['calculated']:raise ValueError('A calculated EN case is required for a diagram')
    p=bundle.project;receipt=generate_actions(bundle.actions)
    factory,_=response_factory(p,bundle.actions,receipt,case_id,axial_transfer=bundle.axial_transfer)
    if translation_m is None:
        witness=max(row['scan']['extrema']['Mstrong_Nmm'].values(),key=lambda r:abs(r['value']))
        translation_m=witness['translation_m']
    if type(translation_m) not in (int,float) or not math.isfinite(translation_m) or not p.travel_min_m<=translation_m<=p.travel_max_m:
        raise ValueError('Diagram translation outside physical travel')
    response=factory(translation_m);nodes={i*p.span_m/120 for i in range(121)}
    nodes.update(translation_m+s.offset_m for s in p.stations)
    data=[];wheels={translation_m+s.offset_m for s in p.stations}
    for x in sorted(nodes):
        for side in ('left','right') if x in wheels else ('right',):
            st=_state_with_contacts(response,p,x,side);t=st['torsion']
            data.append(dict(s_m=x,side=side,N_kN=st['N_kn'],My_kNm=-st['Mx_knm'],Mz_kNm=-st['My_knm'],
                Vy_kN=st['Vx_kn'],Vz_kN=-st['Vy_kn'],T_kNm=-t['total_torque_nmm']/1e6,
                Tsv_kNm=-t['saint_venant_torque_nmm']/1e6,Tw_kNm=-t['warping_torque_nmm']/1e6,B_kNm2=-t['bimoment_nmm2']/1e9,
                uy_mm=st['horizontal_mm'],uz_mm=-st['vertical_mm'],phi_mrad=-t['theta_rad']*1000,
                contact_uy_mm=st['rail_horizontal_mm'],contact_left_uz_mm=-st['contact_vertical_left_mm'],contact_right_uz_mm=-st['contact_vertical_right_mm']))
    pr=physical_reactions(response)
    assert_current_en_result(bundle,result)
    return dict(case_id=case_id,title=row['title'],family=row['family'],translation_m=translation_m,rows=data,
        support_on_beam=pr,beam_on_support={k:-v for k,v in pr.items()},coordinate_convention=result['coordinate_convention'],
        note='Um estado concomitante, não união de máximos independentes.')
