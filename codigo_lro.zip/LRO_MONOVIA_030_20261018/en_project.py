"""Strict EN application input bundle: geometry, independent actions and basis.

The stable NBR model is reused as a geometry carrier only. Its NBR class/factor
fields do not generate EN actions. Fixed beam gravity is bound to the adopted
section/linear-mass input rather than silently omitted from the EN case ledger.
"""
from dataclasses import asdict,dataclass,replace,fields
from copy import deepcopy
from pathlib import Path
import json,math

from monorail.model import MonorailProject,demo_project
from monorail.analysis import digest,GRAVITY
from en_actions import (ENActionInput,ENWheel,ENFixedGravity,ENHoistDynamics,ENTravelDynamics,
    ENManufacturerWheelForce,ENManufacturerHorizontalSet)
from en_actions.model import number,typed,decode
from en_member import ENResistanceBasis
from analytical_scan import AxialTransfer

FORMAT='LRO_MONORAIL_EN_COMPLEMENT_INPUT'


def _parse(payload):
    if isinstance(payload,bytes):payload=payload.decode('utf-8-sig')
    if not isinstance(payload,str):raise ValueError('JSON text or UTF-8 bytes required')
    def unique(pairs):
        out={}
        for key,value in pairs:
            if key in out:raise ValueError('Duplicate JSON field: '+key)
            out[key]=value
        return out
    def floating(token):
        value=float(token);mantissa=token.lower().split('e')[0]
        if value==0 and any(c in '123456789' for c in mantissa):raise ValueError('Nonzero JSON decimal underflow')
        return number(value,'JSON decimal')
    def constant(token):raise ValueError('Nonfinite JSON constant: '+token)
    try:return json.loads(payload,object_pairs_hook=unique,parse_float=floating,parse_constant=constant)
    except (TypeError,UnicodeError,OverflowError,RecursionError,json.JSONDecodeError) as exc:raise ValueError('Invalid EN bundle JSON') from exc


def _json_domain(value,label='bundle'):
    """The saved input must be finite/XML-safe and roundtrip through its parser."""
    if value is None or type(value) is bool:return
    if type(value) in (int,float):number(value,label);return
    if type(value) is str:typed(value,str,label);return
    if type(value) in (list,tuple):
        for i,item in enumerate(value):_json_domain(item,f'{label}[{i}]')
        return
    if type(value) is dict:
        for key,item in value.items():
            typed(key,str,label+' key');_json_domain(item,label+'.'+key)
        return
    raise ValueError(label+': unsupported input value')


@dataclass
class ENProject:
    project: MonorailProject
    actions: ENActionInput
    resistance: ENResistanceBasis
    axial_transfer: AxialTransfer | None
    demonstration: bool = True
    notes: str = ''
    format: str = FORMAT
    schema_version: int = 1

    def validate(self):
        try:return self._validate()
        except (OverflowError,TypeError,AttributeError,RecursionError,ZeroDivisionError) as exc:
            raise ValueError('EN bundle inputs exceed the supported typed/numerical domain') from exc

    def _validate(self):
        _json_domain(self.to_dict())
        if self.format!=FORMAT or type(self.schema_version) is not int or self.schema_version!=1:
            raise ValueError('Wrong EN application format/version; no silent NBR/bridge/result import')
        if type(self.project) is not MonorailProject or type(self.actions) is not ENActionInput or type(self.resistance) is not ENResistanceBasis:
            raise ValueError('Typed physical geometry, independent EN actions and material basis required')
        self.project.validate();self.actions.validate()
        typed(self.resistance,ENResistanceBasis,'resistance');self.resistance.validate(self.project)
        typed(self.demonstration,bool,'demonstration');typed(self.notes,str,'notes')
        if self.axial_transfer is not None:
            if type(self.axial_transfer) is not AxialTransfer:raise ValueError('Typed axial-transfer input or null required')
            typed(self.axial_transfer,AxialTransfer,'axial_transfer');self.axial_transfer.validate()
        p=self.project;a=self.actions
        if (p.span_m,p.travel_min_m,p.travel_max_m)!=(a.span_m,a.travel_min_m,a.travel_max_m):
            raise ValueError('Span and wheel travel must coincide in geometry and EN actions')
        if sorted({w.offset_m for w in a.wheels})!=[s.offset_m for s in p.stations]:
            raise ValueError('Every EN physical wheel station must match the mechanical geometry')
        expected_y=(p.section.bf_mm/2-p.edge_to_contact_mm)/1000
        expected_z=(p.section.tf_mm-p.section.d_mm/2)/1000
        for station in p.stations:
            pair=sorted((w for w in a.wheels if w.offset_m==station.offset_m),key=lambda w:w.y_m)
            if len(pair)!=2:raise ValueError('Initial EN application requires exactly two opposed lower-flange contacts per station')
            for wheel,y in zip(pair,(-expected_y,expected_y)):
                if not (math.isclose(wheel.y_m,y,rel_tol=0.,abs_tol=1e-12) and math.isclose(wheel.z_m,expected_z,rel_tol=0.,abs_tol=1e-12)):
                    raise ValueError('EN wheel y/z does not match the declared lower-flange contact geometry; edit explicitly, never relocate silently')
            for component in ('qc_fraction','payload_fraction','retained_fraction','ropes_fraction'):
                if not math.isclose(getattr(pair[0],component),getattr(pair[1],component),rel_tol=0.,abs_tol=1e-12):
                    raise ValueError('Initial EN application requires equal opposed vertical shares for '+component)
        beams=[q for q in a.fixed_gravity if q.origin_id=='G_beam']
        if len(beams)!=1:raise ValueError('EN application requires exactly one G_beam self-weight origin')
        actual=p.self_weight_kn_m()
        if not math.isclose(beams[0].downward_kn_per_m,actual,rel_tol=1e-12,abs_tol=0.):
            raise ValueError('G_beam does not equal the adopted section/linear-mass self-weight; update the EN origin after changing section')
        return self

    def to_dict(self):return asdict(self)
    def signature(self):return digest(self.to_dict())
    def to_json(self):
        self.validate();return json.dumps(self.to_dict(),ensure_ascii=False,indent=2,allow_nan=False)

    @classmethod
    def from_json(cls,payload):
        data=_parse(payload)
        expected={f.name for f in fields(cls)}
        if type(data) is not dict or set(data)!=expected:raise ValueError('Missing/unknown EN bundle fields; results are not project inputs')
        try:
            project=MonorailProject.from_json(json.dumps(data['project'],allow_nan=False))
            actions=ENActionInput.from_json(json.dumps(data['actions'],allow_nan=False))
            basis=decode(ENResistanceBasis,data['resistance'],'resistance')
            axial=None if data['axial_transfer'] is None else decode(AxialTransfer,data['axial_transfer'],'axial_transfer')
            return cls(project,actions,basis,axial,data['demonstration'],data['notes'],data['format'],data['schema_version']).validate()
        except (TypeError,KeyError,OverflowError,AttributeError,RecursionError) as exc:
            raise ValueError('Invalid typed EN application bundle') from exc


def synchronize_beam_gravity(bundle):
    """Explicit editor action after changing geometry, never hidden at analysis."""
    p=bundle.project
    source=(p.section_mass_source if p.section_mass_kg_per_m is not None else
        'Peso próprio pela área geométrica com concordâncias de raio r e massa específica de 7850 kg/m³; rigidez/resistência pelo modelo de três retângulos. '+p.section.property_source)
    beam=ENFixedGravity('G_beam',p.self_weight_kn_m(),source)
    others=tuple(q for q in bundle.actions.fixed_gravity if q.origin_id!='G_beam')
    bundle.actions=replace(bundle.actions,fixed_gravity=(beam,)+others)
    return bundle


def demo_en_project():
    p=demo_project();p.project_name='Exemplo sintético de monovia com ações EN';p.material.E_mpa=210000.;p.material.G_mpa=210000/2.6
    p.material.specification='Valores mecânicos sintéticos para demonstrar a rota EN; não constituem certificado ou seleção de aço de catálogo.'
    source='EXEMPLO SINTÉTICO criado para o aplicativo, sem fabricante, certificado ou validação de equipamento real.'
    qc=p.trolley_hoist_mass_kg*GRAVITY/1000;payload=p.capacity_t*GRAVITY;retained=p.retained_suspended_mass_kg*GRAVITY/1000
    y=(p.section.bf_mm/2-p.edge_to_contact_mm)/1000;z=(p.section.tf_mm-p.section.d_mm/2)/1000
    wheels=[]
    for station in p.stations:
        static=(qc*station.equipment_share+(payload+retained)*station.suspended_share)/2
        for side,yy in (('L',-y),('R',y)):
            wheels.append(ENWheel(station.id+'/'+side,station.offset_m,yy,z,
                station.equipment_share/2,station.suspended_share/2,station.suspended_share/2,station.suspended_share/2,static,source))
    horizontals=[]
    for sign in (-1,1):
        forces=tuple(ENManufacturerWheelForce(w.wheel_id,w.offset_m,w.y_m,w.z_m,0.,sign*.1) for w in wheels)
        horizontals.append(ENManufacturerHorizontalSet('SYNTHETIC_HY_'+str(sign),'G6',source,
            source+' Simultaneidade explicitamente adotada apenas no exemplo.',
            'Forças físicas laterais assinadas nas quatro rodas; ambos os sentidos ilustrativos.',source,True,forces))
    actions=ENActionInput(project_name=p.project_name,equipment_name='Talha/trole sintéticos',span_m=p.span_m,
        travel_min_m=p.travel_min_m,travel_max_m=p.travel_max_m,qc_kn=qc,nominal_payload_kn=payload,
        operating_payload_kn=p.operating_payload_t*GRAVITY,retained_lifting_accessories_kn=retained,moving_suspended_ropes_kn=0.,
        component_source=source,hook_offset_m=.4,hook_y_m=0.,hook_z_m=-1.,wheel_distribution_source=source+' Pares opostos iguais explicitamente adotados.',
        fixed_gravity=(ENFixedGravity('G_beam',p.self_weight_kn_m(),source+' Peso da viga calculado da geometria adotada.'),),
        wheels=tuple(wheels),hoist_dynamics=ENHoistDynamics('HC2',.1,source,source),
        travel_dynamics=ENTravelDynamics('class1_documented',1.,source+' Hipótese ilustrativa Classe1; não é comprovação de fabricação.'),
        manufacturer_horizontal_sets=tuple(horizontals),tests=(),crane_absence_admissible=False,crane_absence_source='',
        domain_source=source+' Monovia reta interna, talha de gancho, carga livre para oscilar, sem liberação brusca/ações climáticas.',
        notes='Exemplo para testar operação do aplicativo; todas as fontes e hipóteses devem ser substituídas antes de aplicação real.').validate()
    basis=ENResistanceBasis(p.material.fy_mpa,p.material.fu_mpa,p.material.E_mpa,p.material.G_mpa,
        'Norma de produto EN a declarar no projeto real; exemplo sintético','Aço sintético sem catálogo',source,source,
        'EN1993-1-1:2022 §5.2.5: E=210000 MPa, nu=0,3 e G=E/2,6.',1.,1.,
        'Valores recomendados EN para opção de norma de produto; nenhum Anexo Nacional foi selecionado/verificado.',
        source+' Adoção explícita das edições publicadas nas bases do cálculo.',source,.005,
        source+' Tolerância numérica de engenharia0,5%, duas comparações estáveis.',
        ductility_basis='documented_elastic_elongation',toughness_source=source,elongation_percent=12.)
    axial=AxialTransfer(True,True,True,source+' Modelo: restrição axial no centro de cisalhamento à esquerda; direita livre; Hs igual no par.')
    return ENProject(p,actions,basis,axial,True,source).validate()
