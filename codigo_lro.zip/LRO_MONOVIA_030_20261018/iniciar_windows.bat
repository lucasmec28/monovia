@echo off
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (
  py -3.12 -m venv .venv
  if errorlevel 1 goto erro
)
if not exist .venv\lro_dependencies_ready (
  .venv\Scripts\python.exe -m pip install --disable-pip-version-check -r requirements.txt
  if errorlevel 1 goto erro
  echo ready>.venv\lro_dependencies_ready
)
.venv\Scripts\python.exe -m streamlit run app.py --server.address 127.0.0.1 --browser.gatherUsageStats false
pause
exit /b
:erro
echo Nao foi possivel preparar o ambiente. Confira Python 3.12 e a conexao ao indice Python.
echo A instalacao incompleta sera tentada novamente na proxima execucao.
pause
exit /b 1
