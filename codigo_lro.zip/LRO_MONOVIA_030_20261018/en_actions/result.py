"""Deterministic, inspectable action receipts. No structural approval flag can pass."""
from __future__ import annotations
from dataclasses import asdict, dataclass, field
import json
from .model import digest


class JsonResult:
    @property
    def mechanical_requirements(self):
        return tuple(r for r in getattr(self,"requirements",()) if r.category == "mechanical_qualification")

    @property
    def coverage_limitations(self):
        return tuple(r for r in getattr(self,"requirements",()) if r.category == "coverage_limitation")

    @property
    def missing_action_inputs(self):
        return tuple(r for r in getattr(self,"requirements",()) if r.category == "missing_input")

    def to_dict(self):
        return asdict(self)

    def signature(self):
        return digest(self.to_dict())

    def to_json(self):
        return json.dumps(self.to_dict(), ensure_ascii=False, indent=2, allow_nan=False)


@dataclass(frozen=True)
class ENActionRequirement(JsonResult):
    code: str
    category: str  # missing_input / mechanical_qualification / coverage_limitation
    scopes: tuple[str, ...]
    blocking_in_scope: bool
    detail: str
    resolution: str


@dataclass(frozen=True)
class ENLedgerEntry(JsonResult):
    origin_id: str
    action_category: str  # fixed_G / moving_Q; QC remains moving_Q
    load_kind: str  # point / uniform_gravity
    wheel_id: str
    offset_m: float | None
    y_m: float | None
    z_m: float | None
    reference_fs_kn: float
    reference_fy_kn: float
    reference_fz_kn: float
    reference_downward_kn_per_m: float
    dynamic_factor: float
    characteristic_fs_kn: float
    characteristic_fy_kn: float
    characteristic_fz_kn: float
    characteristic_downward_kn_per_m: float
    partial_factor: float
    combination_factor: float
    final_fs_kn: float
    final_fy_kn: float
    final_fz_kn: float
    final_downward_kn_per_m: float
    source: str
    factor_source: str
    note: str


@dataclass(frozen=True)
class ENWheelLoad(JsonResult):
    wheel_id: str
    offset_m: float
    y_m: float
    z_m: float
    fs_kn: float
    fy_kn: float
    fz_kn: float


@dataclass(frozen=True)
class ENFixedLoad(JsonResult):
    origin_id: str
    downward_kn_per_m: float


@dataclass(frozen=True)
class ENActionGroup(JsonResult):
    id: str
    group_code: str
    title: str
    generation_status: str  # ACTIONS_GENERATED / PENDING_INPUT
    phi1: float | None
    phi2: float | None
    phi4: float | None
    phi6: float | None
    eta: float | None
    horizontal_set_id: str | None
    horizontal_status: str
    ledger: tuple[ENLedgerEntry, ...]  # characteristic action, gamma=psi=1
    pending: tuple[str, ...]
    sources: tuple[str, ...]
    notes: tuple[str, ...]
    requirements: tuple[ENActionRequirement, ...] = ()


@dataclass(frozen=True)
class ENActionCase(JsonResult):
    id: str
    family: str
    group_id: str
    title: str
    gamma_g: float
    gamma_q: float
    psi: float
    action_effect: str
    wheel_loads: tuple[ENWheelLoad, ...]
    fixed_loads: tuple[ENFixedLoad, ...]
    ledger: tuple[ENLedgerEntry, ...]
    initial_scanner_eligible: bool  # historical Hs=0 scanner guard, not a universal EN/structural rule
    pending: tuple[str, ...]
    sources: tuple[str, ...]
    notes: tuple[str, ...]
    excluded_origins: tuple[str, ...] = ()
    requirements: tuple[ENActionRequirement, ...] = ()
    action_generation_complete: bool = True
    criterion_parameters: dict = field(default_factory=dict)

    @property
    def total_moving_downward_kn(self):
        return -sum(w.fz_kn for w in self.wheel_loads)

    @property
    def total_fs_kn(self):
        return sum(w.fs_kn for w in self.wheel_loads)

    @property
    def total_fy_kn(self):
        return sum(w.fy_kn for w in self.wheel_loads)


@dataclass(frozen=True)
class ENActionReceipt(JsonResult):
    input_signature: str
    generator_version: str
    generator_fingerprint: str
    editions: dict
    source_register: dict
    groups: tuple[ENActionGroup, ...]
    cases: tuple[ENActionCase, ...]
    pending: tuple[str, ...]
    input_snapshot: dict
    whole_design_approved: bool = False
    format: str = "LRO_EN_MONORAIL_ACTIONS_RESULT"
    schema_version: int = 1
    requirements: tuple[ENActionRequirement, ...] = ()
