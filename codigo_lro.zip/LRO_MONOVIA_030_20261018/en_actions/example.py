"""Synthetic arithmetic regression from the research report, not vendor data."""
from .model import (ENActionInput, ENWheel, ENFixedGravity, ENHoistDynamics, ENTravelDynamics)


def example_input():
    source = "Synthetic regression specified for this application, not a published standard example or vendor equipment."
    wheels = tuple(ENWheel(f"W{i+1}",x,y,-.184,.25,.25,.25,.25,12.,source)
                   for i,(x,y) in enumerate(((0.,-.07),(0.,.07),(.8,-.07),(.8,.07))))
    return ENActionInput(
        project_name="Exemplo aritmético EN independente",
        equipment_name="Talha sintética, sem fabricante",
        span_m=6.,travel_min_m=.45,travel_max_m=4.75,
        qc_kn=8.,nominal_payload_kn=36.,operating_payload_kn=36.,
        retained_lifting_accessories_kn=3.,moving_suspended_ropes_kn=1.,
        component_source=source,hook_offset_m=.4,hook_y_m=0.,hook_z_m=-1.,
        wheel_distribution_source=source+" Four equal wheels explicitly adopted for every component.",
        fixed_gravity=(ENFixedGravity("G_beam",.5,source+" Fixed beam gravity shown separately."),),
        wheels=wheels,hoist_dynamics=ENHoistDynamics("HC2",.1,source,source),
        travel_dynamics=ENTravelDynamics("class1_documented",1.,source+" Class1 assumption only for this arithmetic regression."),
        manufacturer_horizontal_sets=(),tests=(),crane_absence_admissible=False,crane_absence_source="",
        domain_source=source+" Straight internal fixed-runway hook hoist; freely swinging load; no sudden release or climatic action.",
        notes="Qc=8 kN; Qh=40 kN; no manufacturer Hy supplied; no whole-design approval.",
    ).validate()
