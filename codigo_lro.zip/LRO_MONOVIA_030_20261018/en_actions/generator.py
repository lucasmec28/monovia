"""Generate genuine correlated EN actions, never relabel an NBR case.

This module performs action arithmetic only. A missing action is explicit
metadata, not a manufactured zero or a declaration of complete design coverage.
"""
from __future__ import annotations
from dataclasses import replace
from copy import deepcopy
from hashlib import sha256
from pathlib import Path
import math
from .model import ENActionInput, canonical, digest, number
from .result import ENLedgerEntry, ENWheelLoad, ENFixedLoad, ENActionGroup, ENActionCase, ENActionReceipt, ENActionRequirement
from .sources import HC, SOURCES, SOURCE_EDITION, GENERATOR_VERSION

UNKNOWN_HORIZONTAL = "horizontal_action_coverage_not_demonstrated_no_silent_zero"
LONGITUDINAL_PENDING = "longitudinal_response_and_resistance_require_separate_consumer_qualification"


def _requirements(codes):
    output = []
    for code in codes:
        if code == LONGITUDINAL_PENDING:
            output.append(ENActionRequirement(code,"mechanical_qualification",("mechanical_response","member_resistance"),True,
                "Longitudinal forces remain in the final physical loads. Their axial support transfer and sectorial effects need a qualified downstream consumer; Hs=0 was only the initial scanner scope, not an EN rule.",
                "Consumer may attach explicit axial-transfer, opposite-wheel-pair and sectorial-response qualification. Preserve producer requirement and record its resolution separately."))
        elif code in ("phi4_requires_documented_EN1090_2_class1_or_manufacturer_value", "maximum_static_vertical_wheel_loads_and_sources_required_for_5pct_fallback", "G6_horizontal_characteristic_component_not_provided"):
            output.append(ENActionRequirement(code,"missing_input",("complete_group_actions",),True,
                "A required component of this group has not been supplied; numerical vertical subsets do not provide the missing action.",
                "Supply the stated component and its physical/source basis; regenerate the receipt."))
        else:
            output.append(ENActionRequirement(code,"coverage_limitation",("equipment_coverage",),False,
                "External evidence, other directions/events or equipment-wide completeness are not established by this one action case. This does not by itself invalidate the arithmetic of a fully supplied case.",
                "Retain the limitation in reporting; obtain missing evidence or separate cases without deleting this producer record."))
    return tuple(output)


def generator_fingerprint():
    root = Path(__file__).resolve().parent
    return digest({p.name:sha256(p.read_bytes()).hexdigest() for p in sorted(root.glob("*.py"))})


def hoist_phi2(project):
    project.validate()
    minimum,beta = HC[project.hoist_dynamics.hoist_class]
    # EN corrected Table 2.4 uses steady speed directly. No HD selection, NBR
    # speed reduction or NBR 1.5 m/s cap is imported into this route.
    return minimum + beta * project.hoist_dynamics.steady_speed_m_s


def _product(*values):
    result = math.prod(values)
    if result == 0. and all(value != 0 for value in values):
        raise ValueError("Produto de ações sofreu subfluxo numérico; não substituir por zero.")
    return number(result, "Produto de ações")


def _point(wheel, origin, *, fz=0., fs=0., fy=0., dynamic=1., source, factor_source, note=""):
    cfs,cfy,cfz = (_product(force,dynamic) for force in (fs,fy,fz))
    return ENLedgerEntry(origin, "moving_Q", "point", wheel.wheel_id,
                         wheel.offset_m,wheel.y_m,wheel.z_m,
                         fs,fy,fz,0.,dynamic,cfs,cfy,cfz,0.,1.,1.,
                         cfs,cfy,cfz,0.,source,factor_source,note)


def _fixed(load):
    return ENLedgerEntry(load.origin_id,"fixed_G","uniform_gravity","",None,None,None,
                         0.,0.,0.,load.downward_kn_per_m,1.,0.,0.,0.,load.downward_kn_per_m,
                         1.,1.,0.,0.,0.,load.downward_kn_per_m,load.source,"origins","Fixed supporting structure; not moving Qc.")


def _vertical(p, *, qc_factor, qh_factor, payload=None, qc=None, retained=None, ropes=None):
    values = (
        ("Qc_equipment", p.qc_kn if qc is None else qc, "qc_fraction", qc_factor),
        ("Qh_payload", p.operating_payload_kn if payload is None else payload, "payload_fraction", qh_factor),
        ("Qh_retained_accessories", p.retained_lifting_accessories_kn if retained is None else retained, "retained_fraction", qh_factor),
        ("Qh_moving_suspended_ropes", p.moving_suspended_ropes_kn if ropes is None else ropes, "ropes_fraction", qh_factor),
    )
    return tuple(_point(w,origin,fz=-_product(load,getattr(w,share)),dynamic=factor,source=p.component_source+"; "+p.wheel_distribution_source,
                        factor_source="groups; dynamics",note="Qc is variable crane self-weight; all Qh components remain separate and occur once.")
                 for w in p.wheels for origin,load,share,factor in values)


def _group(id, code, title, ledger, *, phi1=None,phi2=None,phi4=None,phi6=None,eta=None,horizontal_id=None,horizontal_status="NOT_PROVIDED",pending=(UNKNOWN_HORIZONTAL,),sources=("origins","groups","dynamics"),notes=(),status="ACTIONS_GENERATED"):
    return ENActionGroup(id,code,title,status,phi1,phi2,phi4,phi6,eta,horizontal_id,horizontal_status,
                         tuple(ledger),tuple(pending),tuple(sources),tuple(notes),_requirements(pending))


def generate_groups(project):
    p = project.validate()
    phi2 = hoist_phi2(p)
    groups = []
    for phi1 in (.9,1.1):
        groups.append(_group(f"G1/phi1={phi1:.1f}","G1","Içamento · extremos correlacionados de φ1",
            _vertical(p,qc_factor=phi1,qh_factor=phi2),phi1=phi1,phi2=phi2,
            notes=("Whole characteristic group: phi1 Qc + phi2 Qh. No per-wheel selection of favorable factors.",)))
    phi4 = p.travel_dynamics.phi4
    if p.travel_dynamics.basis == "unresolved":
        groups.append(_group("G6/PENDING_PHI4","G6","Translação pendente: φ4 sem fonte",(),status="PENDING_INPUT",
            pending=("phi4_requires_documented_EN1090_2_class1_or_manufacturer_value", UNKNOWN_HORIZONTAL),
            notes=("No phi4=1 default. No numeric G6 load substituted for this unresolved group.",)))
    else:
        vertical = _vertical(p,qc_factor=phi4,qh_factor=phi4)
        groups.append(_group("G6/VERTICAL_ONLY_PARTIAL","G6","Translação vertical · parcela isolada, cobertura horizontal incompleta",
            vertical,phi4=phi4,pending=("G6_horizontal_characteristic_component_not_provided",UNKNOWN_HORIZONTAL),notes=(p.travel_dynamics.source,"Not a complete acceleration/braking group; horizontal actions require separate documented variants.",)))
        if all(w.maximum_static_vertical_kn is not None for w in p.wheels):
            for sign in (-1,1):
                horizontal = tuple(_point(w,"Hlong_5pct_maximum_static",fs=_product(sign,.05,w.maximum_static_vertical_kn),
                    source=w.maximum_static_vertical_source,factor_source="longitudinal",
                    note="5% of documented maximum static wheel force, without phi1/phi2/phi4; coherent direction for all wheels.") for w in p.wheels)
                groups.append(_group(f"G6/HLONG_FALLBACK/{sign:+d}","G6","Translação com fallback longitudinal de 5%",
                    vertical+horizontal,phi4=phi4,horizontal_id=f"fallback_Hs_{sign:+d}",horizontal_status="LONGITUDINAL_FALLBACK_ONLY",
                    pending=(LONGITUDINAL_PENDING,"transverse_action_not_provided_for_this_longitudinal_variant"),
                    sources=("origins","groups","dynamics","longitudinal"),
                    notes=(p.travel_dynamics.source,"Fallback longitudinal and supplier lateral actions are not automatically added together.",)))
        else:
            groups.append(_group("G6/HLONG_PENDING_MAX_WHEEL","G6","Fallback longitudinal pendente: máximo estático de roda não documentado",(),status="PENDING_INPUT",phi4=phi4,
                pending=("maximum_static_vertical_wheel_loads_and_sources_required_for_5pct_fallback",LONGITUDINAL_PENDING),sources=("longitudinal","groups")))
        wheel_map = {w.wheel_id:w for w in p.wheels}
        for supplier in p.manufacturer_horizontal_sets:
            horizontal = tuple(_point(wheel_map[f.wheel_id],"Hmanufacturer/"+supplier.set_id,
                fs=f.fs_kn,fy=f.fy_kn,source=supplier.source+"; "+supplier.application_geometry_source,
                factor_source="manufacturer_horizontal",
                note="Supplier characteristic force with dynamics already included; no added phi5. "+supplier.simultaneity_source)
                for f in supplier.wheel_forces)
            pending = ("manufacturer_action_set_recorded_not_independently_verified_or_proof_of_all_directions",)
            if any(f.fs_kn for f in supplier.wheel_forces):
                pending += (LONGITUDINAL_PENDING,)
            groups.append(_group("G6/MANUFACTURER/"+supplier.set_id,"G6","Translação com conjunto horizontal de fabricante",
                vertical+horizontal,phi4=phi4,horizontal_id=supplier.set_id,horizontal_status="MANUFACTURER_CHARACTERISTIC_EXPLICIT",
                pending=pending,sources=("origins","groups","dynamics","manufacturer_horizontal"),
                notes=(supplier.direction_description,supplier.simultaneity_source,p.travel_dynamics.source,
                       "One documented vector set is one correlated action. No automatic reversal or unapproved superposition with 5% fallback.")))
    retained = p.retained_lifting_accessories_kn+p.moving_suspended_ropes_kn
    groups.append(_group("G7/UNLOADED_RETAINED","G7","Talha sem carga útil, acessórios e cabos retidos presentes",
        _vertical(p,qc_factor=1.,qh_factor=1.,payload=0.),eta=retained/p.nominal_qh_kn,
        sources=("origins","groups"),notes=("eta Qh equals the retained accessories plus suspended ropes; payload is removed, equipment stays Qc.",)))
    for test in p.tests:
        phi6 = (1.+phi2)/2. if test.kind == "dynamic" else 1.
        for phi1 in (.9,1.1):
            ledger = tuple(entry for entry in _vertical(p,qc_factor=phi1,qh_factor=0.) if entry.origin_id == "Qc_equipment")
            ledger += tuple(_point(w,"QT_complete_test_hoist_load",fz=-_product(test.total_hoist_test_kn,share),dynamic=phi6,
                source=test.source,factor_source="test",note="QT replaces all Qh components; retained accessories and ropes are not added again.")
                for w,share in zip(p.wheels,test.wheel_fractions))
            groups.append(_group(f"G8/{test.test_id}/phi1={phi1:.1f}","G8","Ensaio "+test.kind,ledger,phi1=phi1,phi2=phi2,phi6=phi6,
                pending=("test_horizontal_actions_and_positions_require_specific_test_plan",),
                sources=("origins","groups","dynamics","test","test_checks"),
                notes=(test.source,"G8 characteristic: phi1 Qc + phi6 QT, not Qh + QT. No 1.35×1.1 double factoring.")))
    # Criterion-specific load route, not a renamed ordinary group or NBR case.
    payload_ledger = tuple(entry for entry in _vertical(p,qc_factor=0.,qh_factor=1.,payload=p.nominal_payload_kn,retained=0.,ropes=0.,qc=0.) if entry.origin_id == "Qh_payload")
    groups.append(_group("SLS/PAYLOAD_ONLY_NO_DYNAMICS","PAYLOAD_ONLY_SLS","Flecha incremental da monovia · carga útil nominal isolada",
        payload_ledger,horizontal_status="EXCLUDED_BY_THIS_SPECIFIC_VERTICAL_DEFLECTION_CRITERION",pending=(),sources=("deflection",),
        notes=("Only nominal payload; fixed G, moving Qc, retained accessories, ropes and dynamics excluded by this distinct criterion. Limit L/500 relative to supports.",)))
    groups.append(_group("SLS/TOTAL_GRAVITY_NO_DYNAMICS","TOTAL_GRAVITY_SLS","Flecha total vertical característica · sem dinâmica e sem contraflecha",
        _vertical(p,qc_factor=1.,qh_factor=1.,payload=p.nominal_payload_kn),
        horizontal_status="EXCLUDED_BY_THIS_SPECIFIC_VERTICAL_DEFLECTION_CRITERION",pending=(),sources=("deflection_total",),
        notes=("Fixed G plus Qc and nominal Qh, all dynamic/partial factors 1. Zero precamber explicitly adopted; limit min(L/600, 25 mm) relative to supports. Not the payload-only L/500 increment.",)))
    return tuple(groups)


def _factor(entry, gamma_g, gamma_q, psi, source):
    gamma = gamma_g if entry.action_category == "fixed_G" else gamma_q
    coefficient = 1. if entry.action_category == "fixed_G" else psi
    scale = _product(gamma,coefficient)
    return replace(entry,partial_factor=gamma,combination_factor=coefficient,
                   final_fs_kn=_product(entry.characteristic_fs_kn,scale),
                   final_fy_kn=_product(entry.characteristic_fy_kn,scale),
                   final_fz_kn=_product(entry.characteristic_fz_kn,scale),
                   final_downward_kn_per_m=_product(entry.characteristic_downward_kn_per_m,scale),
                   factor_source=entry.factor_source+"; "+source)


def _case(p, group, family, *, gamma_g, gamma_q, psi=1., effect, fixed=True, excluded=(), criterion=None):
    fixed_ledger = tuple(_fixed(a) for a in p.fixed_gravity) if fixed else ()
    if family == "EN_ULS_STR":
        source = "uls"
    elif family == "EN_TEST_ULS":
        source = "test_uls_group"
    elif family == "EN_SLS_DEFLECTION":
        source = "deflection_total" if group.group_code == "TOTAL_GRAVITY_SLS" else "deflection"
    else:
        source = "sls"
    ledger = tuple(_factor(entry,gamma_g,gamma_q,psi,source) for entry in fixed_ledger+group.ledger)
    wheels = tuple(ENWheelLoad(w.wheel_id,w.offset_m,w.y_m,w.z_m,
        math.fsum(x.final_fs_kn for x in ledger if x.wheel_id == w.wheel_id),
        math.fsum(x.final_fy_kn for x in ledger if x.wheel_id == w.wheel_id),
        math.fsum(x.final_fz_kn for x in ledger if x.wheel_id == w.wheel_id)) for w in p.wheels)
    for wheel in wheels:
        for component in (wheel.fs_kn,wheel.fy_kn,wheel.fz_kn):
            number(component,"Resultante física por roda")
    for component in ("fs_kn","fy_kn","fz_kn"):
        number(math.fsum(getattr(w,component) for w in wheels),"Resultante total móvel")
    fixed_loads = tuple(ENFixedLoad(x.origin_id,x.final_downward_kn_per_m) for x in ledger if x.action_category == "fixed_G")
    number(math.fsum(x.downward_kn_per_m for x in fixed_loads),"Resultante distribuída fixa")
    has_longitudinal = any(w.fs_kn != 0. for w in wheels)
    pending = group.pending
    if has_longitudinal and LONGITUDINAL_PENDING not in pending:
        pending += (LONGITUDINAL_PENDING,)
    return ENActionCase(f"{family}/{group.id}/gG={gamma_g:g}/gQ={gamma_q:g}/psi={psi:g}",family,group.id,group.title,
        gamma_g,gamma_q,psi,effect,wheels,fixed_loads,ledger,not has_longitudinal,pending,
        tuple(dict.fromkeys(group.sources+(source,))),
        group.notes+("Same gamma_Q and psi for the entire characteristic crane group, including Qc and all horizontal components; fixed G remains separate.",),tuple(excluded),_requirements(pending),
        not any(req.category=="missing_input" and "complete_group_actions" in req.scopes for req in _requirements(pending)),
        deepcopy(criterion or {}))


def generate_cases(project, groups=None):
    p = project.validate()
    # Do not permit a caller to inject groups and masquerade foreign cases.
    original = generate_groups(p)
    if groups is not None and canonical([g.to_dict() for g in groups]) != canonical([g.to_dict() for g in original]):
        raise ValueError("Grupos externos/alterados não correspondem ao gerador EN destas entradas.")
    cases = []
    for group in original:
        if group.generation_status != "ACTIONS_GENERATED":
            continue
        if group.group_code == "PAYLOAD_ONLY_SLS":
            cases.append(_case(p,group,"EN_SLS_DEFLECTION",gamma_g=0.,gamma_q=1.,effect="nominal_payload_only_L500",fixed=False,
                              excluded=("fixed_G","Qc_equipment","Qh_retained_accessories","Qh_moving_suspended_ropes","dynamic_amplification"),
                              criterion={"vertical_limit_m":_product(p.span_m,1./500.),"span_divisor":500.,"precamber_m":0.,"dynamics_included":False,"load_basis":"nominal_payload_only"}))
        elif group.group_code == "TOTAL_GRAVITY_SLS":
            cases.append(_case(p,group,"EN_SLS_DEFLECTION",gamma_g=1.,gamma_q=1.,effect="total_gravity_no_dynamics_L600_25mm",
                              excluded=("horizontal_actions","dynamic_amplification"),
                              criterion={"vertical_limit_m":min(_product(p.span_m,1./600.),.025),"span_divisor":600.,"absolute_limit_m":.025,"precamber_m":0.,"dynamics_included":False,"load_basis":"fixed_G_plus_Qc_plus_nominal_Qh"}))
        elif group.group_code == "G8":
            cases.append(_case(p,group,"EN_TEST_SLS",gamma_g=1.,gamma_q=1.,effect="test_characteristic_stress"))
            # EN1991-3 2.2.2(6)/A.1(3): one characteristic crane group.
            # EN1993-6 2.8: gamma_F,test=1.1 applies to that whole G8;
            # fixed supporting G keeps its own fundamental gamma_G.
            for gamma_g in (1.,1.35):
                cases.append(_case(p,group,"EN_TEST_ULS",gamma_g=gamma_g,gamma_q=1.1,effect="test_ULS_correlated_group_gamma_F_test"))
        else:
            for gamma_g in (1.,1.35):
                for gamma_q,effect in ((1.,"STR_favorable_crane_present"),(1.35,"STR_unfavorable_crane")):
                    cases.append(_case(p,group,"EN_ULS_STR",gamma_g=gamma_g,gamma_q=gamma_q,effect=effect))
            cases.append(_case(p,group,"EN_SLS_STRESS",gamma_g=1.,gamma_q=1.,effect="characteristic_dynamic_stress"))
    if p.crane_absence_admissible:
        absent = _group("CRANE_ABSENT","CRANE_ABSENT","Talha fisicamente ausente, condição explicitamente permitida",(),
            horizontal_status="CRANE_ABSENT_BY_EXPLICIT_INPUT",pending=(),sources=("uls",),notes=(p.crane_absence_source,))
        for gamma_g in (1.,1.35):
            cases.append(_case(p,absent,"EN_ULS_STR",gamma_g=gamma_g,gamma_q=0.,effect="STR_crane_physically_absent"))
    return tuple(cases)


def generate_actions(project):
    p = project.validate()
    signature = p.signature()
    fingerprint = generator_fingerprint()
    groups = generate_groups(p)
    cases = generate_cases(p, groups)
    pending = ["Action generator only: no material resistance or whole-design approval.",
               "Accidental buffers/tilting, sudden release, fatigue, vibration, connections and physical restraint qualification are not generated or approved.",
               "Frequent and quasi-permanent service criteria are not generated. No psi2 is assigned arbitrarily.",
               "Only fixed uniform vertical gravity and one internal fixed-runway hook hoist in the declared travel/geometry domain."]
    if not p.manufacturer_horizontal_sets:
        pending.append("Transverse manufacturer action set not provided; Hy=0 is not claimed as coverage.")
    if not p.tests:
        pending.append("No test plan supplied; erection test requirements remain unassessed.")
    else:
        pending.append("Test SLS and ULS actions generated for the supplied plan only; other test positions or horizontal actions are not inferred.")
    for group in groups:
        pending.extend(group.pending)
    if signature != p.signature() or fingerprint != generator_fingerprint():
        raise ValueError("Entradas ou gerador alterados durante a geração; gere novamente.")
    return ENActionReceipt(signature,GENERATOR_VERSION,fingerprint,deepcopy(SOURCE_EDITION),deepcopy(SOURCES),groups,cases,
                           tuple(dict.fromkeys(pending)),p.to_dict(),requirements=_requirements(tuple(dict.fromkeys(pending))))


def assert_case_receipt(project, receipt, case_id, case_snapshot=None):
    """Regenerate full EN receipt, then bind an exact case to its physical producer.

    Returns the regenerated case, never the caller's untrusted snapshot. A family
    tag or a source string alone cannot authorize an EN resistance consumer.
    JSON-compatible dict receipts/snapshots are allowed only for exact comparison.
    """
    expected = generate_actions(project)
    supplied = receipt.to_dict() if type(receipt) is ENActionReceipt else receipt
    if type(supplied) is not dict or canonical(supplied) != canonical(expected.to_dict()):
        raise ValueError("Recibo EN externo, alterado ou desatualizado; gere ações EN novamente a partir das entradas.")
    found = next((case for case in expected.cases if case.id == case_id), None)
    if found is None:
        raise ValueError("Caso ausente do recibo EN regenerado.")
    if case_snapshot is not None:
        snapshot = case_snapshot.to_dict() if type(case_snapshot) is ENActionCase else case_snapshot
        if type(snapshot) is not dict or canonical(snapshot) != canonical(found.to_dict()):
            raise ValueError("Caso aplicado ao solver não coincide com o caso EN regenerado.")
    return found


def assert_current_receipt(project, receipt):
    expected = generate_actions(project)
    supplied = receipt.to_dict() if type(receipt) is ENActionReceipt else receipt
    if type(supplied) is not dict or canonical(supplied) != canonical(expected.to_dict()):
        raise ValueError("Recibo EN externo, alterado ou desatualizado.")
    return expected
