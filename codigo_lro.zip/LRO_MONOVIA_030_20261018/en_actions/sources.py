"""Declared source editions, not a national-conformity claim."""
SOURCE_EDITION = {
    "actions": "EN 1991-3:2006 + AC:2012",
    "combinations": "EN 1990:2002 + A1:2005",
    "supporting_structure": "EN 1993-6:2007 + AC:2009",
    "profile": "Recommended EN values, declared editions; no national annex selected or verified",
    "new_editions": "EN 1991-3:2026 and EN 1990-1:2023+A1:2026 are not implemented or claimed verified",
}
SOURCES = {
    "origins": {"edition": SOURCE_EDITION["actions"], "clause": "1.4.1.2–3; 2.2.2", "url": "https://www.phd.eng.br/wp-content/uploads/2015/12/en.1991.3.2006.pdf"},
    "groups": {"edition": SOURCE_EDITION["actions"], "clause": "2.2.2(6), Table 2.2, printed pp.15–16", "url": "https://www.phd.eng.br/wp-content/uploads/2015/12/en.1991.3.2006.pdf"},
    "dynamics": {"edition": SOURCE_EDITION["actions"], "clause": "2.6, Tables 2.4/2.5; AC:2012 p.4 corrected Table 2.4", "url": "https://cms.sia.ch/sites/default/files/2024-03/1991-3_2006_AC_2012_e.pdf"},
    "longitudinal": {"edition": SOURCE_EDITION["actions"], "clause": "2.5.1.2(1), fixed monorail, 5% maximum static vertical wheel load without dynamic factor", "url": "https://www.phd.eng.br/wp-content/uploads/2015/12/en.1991.3.2006.pdf"},
    "manufacturer_horizontal": {"edition": SOURCE_EDITION["actions"], "clause": "2.7.1; correlated group Table 2.2", "url": "https://www.phd.eng.br/wp-content/uploads/2015/12/en.1991.3.2006.pdf"},
    "uls": {"edition": SOURCE_EDITION["combinations"], "clause": "6.4.3.2, expression 6.10; EN1991-3 A.2.2 Table A.1; gamma_G=1.00/1.35, gamma_Q=1.00/1.35 with whole-group correlation", "url": "https://www.phd.eng.br/wp-content/uploads/2015/12/en.1990.2002.pdf"},
    "sls": {"edition": SOURCE_EDITION["combinations"], "clause": "6.5.3 characteristic combination; EN1991-3 A.3.1–2 action factors 1.00", "url": "https://www.phd.eng.br/wp-content/uploads/2015/12/en.1990.2002.pdf"},
    "deflection": {"edition": SOURCE_EDITION["supporting_structure"], "clause": "7.3, Table 7.2(c), monorail hoist-load increment, L/500 without dynamics; payload-only criterion adopted as independently identified route", "url": "https://www.phd.eng.br/wp-content/uploads/2015/12/en.1993.6.2007.pdf"},
    "deflection_total": {"edition": SOURCE_EDITION["supporting_structure"], "clause": "7.3, Table 7.2(a), total characteristic vertical deflection without dynamics less precamber <= min(L/600,25 mm); explicit zero precamber in this implementation", "url": "https://www.phd.eng.br/wp-content/uploads/2015/12/en.1993.6.2007.pdf"},
    "test": {"edition": SOURCE_EDITION["actions"], "clause": "2.10, Table 2.2 group8; dynamic QT>=1.10Qh, phi6=(1+phi2)/2; static QT>=1.25Qh, phi6=1", "url": "https://www.phd.eng.br/wp-content/uploads/2015/12/en.1991.3.2006.pdf"},
    "test_uls_group": {"edition": SOURCE_EDITION["supporting_structure"] + "; " + SOURCE_EDITION["actions"], "clause": "Derived combination, not a transcribed equation: EN1991-3 2.2.2(6), A.1(3), Table 2.2 G8 and EN1993-6 2.8(2)P: gamma_G Gfixed + gamma_F,test [phi1 Qc + phi6 QT], recommended gamma_F,test=1.1; gamma_G=1.00/1.35 separately. No 1.35 times 1.1 on the crane group.", "url": "https://www.phd.eng.br/wp-content/uploads/2015/12/en.1993.6.2007.pdf", "group_source_url": "https://www.phd.eng.br/wp-content/uploads/2015/12/en.1991.3.2006.pdf"},
    "test_checks": {"edition": SOURCE_EDITION["supporting_structure"], "clause": "2.8; SLS stress and ULS checks required; recommended gamma_F,test=1.1", "url": "https://www.phd.eng.br/wp-content/uploads/2015/12/en.1993.6.2007.pdf"},
}
HC = {"HC1": (1.05, .17), "HC2": (1.10, .34), "HC3": (1.15, .51), "HC4": (1.20, .68)}
GENERATOR_VERSION = "0.1.1-en-actions-independent"
