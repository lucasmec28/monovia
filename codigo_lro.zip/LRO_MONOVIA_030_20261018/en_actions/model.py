"""Strict, independent EN action inputs. No NBR classes or result import route."""
from __future__ import annotations
from dataclasses import asdict, dataclass, fields, is_dataclass
from hashlib import sha256
import json
import math
import types
import sys
from typing import get_args, get_origin, get_type_hints, Union

INPUT_FORMAT = "LRO_EN_MONORAIL_ACTIONS_INPUT"
PROFILE = "recommended_EN_declared_editions_not_nationally_verified"


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)


def digest(value):
    return sha256(canonical(value).encode("utf-8")).hexdigest()


def number(value, label, *, minimum=None, positive=False):
    if type(value) not in (int, float) or abs(value) > 1e12 or not math.isfinite(value):
        raise ValueError(label + ": número finito obrigatório, sem booleanos.")
    if value != 0 and abs(value) < sys.float_info.min:
        raise ValueError(label + ": subnormal fora do domínio numérico; não substituir por zero.")
    if (minimum is not None and value < minimum) or (positive and value <= 0):
        raise ValueError(label + ": valor fora do domínio.")
    return float(value)


def valid_text(value):
    # XML 1.0 / UTF-8 safe text for signed JSON and Word exports. Python str
    # can contain isolated UTF-16 surrogates; do not pass them to encoding.
    return type(value) is str and len(value) <= 20000 and all(
        c in "\n\r\t" or 0x20 <= ord(c) <= 0xD7FF or
        0xE000 <= ord(c) <= 0xFFFD or 0x10000 <= ord(c) <= 0x10FFFF
        for c in value)


def required(value, label):
    if not valid_text(value) or not value.strip():
        raise ValueError(label + ": identificação ou fonte explícita obrigatória.")


def typed(value, annotation, label):
    origin, args = get_origin(annotation), get_args(annotation)
    if origin in (Union, types.UnionType):
        for option in args:
            try:
                typed(value, option, label)
                return
            except ValueError:
                pass
        raise ValueError(label + ": tipo inválido.")
    if annotation is type(None):
        if value is not None:
            raise ValueError(label + ": esperado nulo.")
    elif annotation is bool:
        if type(value) is not bool:
            raise ValueError(label + ": booleano obrigatório.")
    elif annotation is int:
        if type(value) is not int:
            raise ValueError(label + ": inteiro obrigatório.")
    elif annotation is float:
        number(value, label)
    elif annotation is str:
        if not valid_text(value):
            raise ValueError(label + ": texto válido obrigatório.")
    elif origin is tuple:
        if type(value) is not tuple:
            raise ValueError(label + ": sequência tipada obrigatória.")
        for i,item in enumerate(value):
            typed(item, args[0], f"{label}[{i}]")
    elif is_dataclass(annotation):
        if type(value) is not annotation:
            raise ValueError(label + ": objeto tipado obrigatório.")
        hints = get_type_hints(annotation)
        for field in fields(annotation):
            typed(getattr(value, field.name), hints[field.name], label + "." + field.name)
    else:
        raise ValueError(label + ": tipo não suportado.")


def decode(annotation, value, label):
    origin, args = get_origin(annotation), get_args(annotation)
    if origin in (Union, types.UnionType):
        for option in args:
            try:
                return decode(option, value, label)
            except (ValueError, TypeError):
                pass
        raise ValueError(label + ": tipo inválido.")
    if is_dataclass(annotation):
        if type(value) is not dict or set(value) != {f.name for f in fields(annotation)}:
            raise ValueError(label + ": campos desconhecidos, ausentes ou formato de outra rota.")
        hints = get_type_hints(annotation)
        return annotation(**{k:decode(hints[k], v, label + "." + k) for k,v in value.items()})
    if origin is tuple:
        if type(value) is not list:
            raise ValueError(label + ": lista JSON obrigatória.")
        return tuple(decode(args[0], v, label + f"[{i}]") for i,v in enumerate(value))
    typed(value, annotation, label)
    return value


class JsonInput:
    def to_dict(self):
        return asdict(self)

    def signature(self):
        return digest(self.to_dict())

    def to_json(self):
        self.validate()
        return json.dumps(self.to_dict(), ensure_ascii=False, indent=2, allow_nan=False)

    @classmethod
    def from_json(cls, payload):
        if isinstance(payload, bytes):
            payload = payload.decode("utf-8-sig")
        def reject_constant(value):
            raise ValueError("Constante JSON não finita: " + value)
        def finite_decimal(token):
            value = float(token)
            # json.loads normally erases the magnitude of 1e-9999 before
            # validation. Reject lexical nonzero values rounded to zero.
            mantissa = token.lower().split("e", 1)[0]
            if value == 0. and any(c in "123456789" for c in mantissa):
                raise ValueError("Decimal JSON sofreu subfluxo numérico; não substituir por zero.")
            return number(value, "Decimal JSON")
        def unique(pairs):
            result = {}
            for key,value in pairs:
                if key in result:
                    raise ValueError("Campo JSON duplicado: " + key)
                result[key] = value
            return result
        raw = json.loads(payload, parse_constant=reject_constant, parse_float=finite_decimal, object_pairs_hook=unique)
        return decode(cls, raw, "entrada EN").validate()


@dataclass(frozen=True)
class ENWheel:
    wheel_id: str
    offset_m: float
    y_m: float
    z_m: float
    qc_fraction: float
    payload_fraction: float
    retained_fraction: float
    ropes_fraction: float
    maximum_static_vertical_kn: float | None
    maximum_static_vertical_source: str


@dataclass(frozen=True)
class ENFixedGravity:
    origin_id: str
    downward_kn_per_m: float
    source: str


@dataclass(frozen=True)
class ENHoistDynamics:
    hoist_class: str
    steady_speed_m_s: float
    classification_source: str
    speed_source: str


@dataclass(frozen=True)
class ENTravelDynamics:
    basis: str  # unresolved, class1_documented, manufacturer
    phi4: float | None
    source: str


@dataclass(frozen=True)
class ENManufacturerWheelForce:
    wheel_id: str
    offset_m: float
    y_m: float
    z_m: float
    fs_kn: float
    fy_kn: float


@dataclass(frozen=True)
class ENManufacturerHorizontalSet:
    set_id: str
    group_code: str
    source: str
    simultaneity_source: str
    direction_description: str
    application_geometry_source: str
    characteristic_dynamic_included: bool
    wheel_forces: tuple[ENManufacturerWheelForce, ...]


@dataclass(frozen=True)
class ENTestRequest:
    test_id: str
    kind: str  # dynamic or static
    total_hoist_test_kn: float
    wheel_fractions: tuple[float, ...]  # same order as wheels; no hidden equal split
    source: str


@dataclass(frozen=True)
class ENActionInput(JsonInput):
    project_name: str
    equipment_name: str
    span_m: float
    travel_min_m: float
    travel_max_m: float
    qc_kn: float
    nominal_payload_kn: float
    operating_payload_kn: float
    retained_lifting_accessories_kn: float
    moving_suspended_ropes_kn: float
    component_source: str
    hook_offset_m: float
    hook_y_m: float
    hook_z_m: float
    wheel_distribution_source: str
    fixed_gravity: tuple[ENFixedGravity, ...]
    wheels: tuple[ENWheel, ...]
    hoist_dynamics: ENHoistDynamics
    travel_dynamics: ENTravelDynamics
    manufacturer_horizontal_sets: tuple[ENManufacturerHorizontalSet, ...]
    tests: tuple[ENTestRequest, ...]
    crane_absence_admissible: bool
    crane_absence_source: str
    domain_source: str
    notes: str
    edition_profile: str = PROFILE
    format: str = INPUT_FORMAT
    schema_version: int = 1

    @property
    def nominal_qh_kn(self):
        return self.nominal_payload_kn + self.retained_lifting_accessories_kn + self.moving_suspended_ropes_kn

    @property
    def operating_qh_kn(self):
        return self.operating_payload_kn + self.retained_lifting_accessories_kn + self.moving_suspended_ropes_kn

    def validate(self):
        typed(self, ENActionInput, "entrada EN")
        if self.format != INPUT_FORMAT or self.schema_version != 1 or self.edition_profile != PROFILE:
            raise ValueError("Formato/edições EN incompatíveis. Não converter JSON NBR/CMAA nem resultado em entrada EN.")
        for field in ("project_name", "equipment_name", "component_source", "wheel_distribution_source", "domain_source"):
            required(getattr(self, field), field)
        number(self.span_m, "Vão", positive=True)
        for field in ("qc_kn", "operating_payload_kn", "retained_lifting_accessories_kn", "moving_suspended_ropes_kn", "travel_min_m", "travel_max_m"):
            number(getattr(self, field), field, minimum=0)
        number(self.nominal_payload_kn, "Carga útil nominal", positive=True)
        if self.operating_payload_kn > self.nominal_payload_kn:
            raise ValueError("Carga útil operacional excede a nominal; ensaio tem entrada própria.")
        if not 1 <= len(self.wheels) <= 32:
            raise ValueError("Informe de 1 a 32 rodas físicas, sem divisão implícita por pares.")
        if len({w.wheel_id for w in self.wheels}) != len(self.wheels):
            raise ValueError("Identificações de rodas repetidas.")
        if len({(w.offset_m,w.y_m,w.z_m) for w in self.wheels}) != len(self.wheels):
            raise ValueError("Duas rodas não podem ocupar o mesmo ponto físico.")
        for wheel in self.wheels:
            required(wheel.wheel_id, "Roda")
            number(wheel.offset_m, "Offset", minimum=0)
            for field in ("qc_fraction", "payload_fraction", "retained_fraction", "ropes_fraction"):
                number(getattr(wheel, field), field, minimum=0)
            if wheel.maximum_static_vertical_kn is not None:
                number(wheel.maximum_static_vertical_kn, "Máximo vertical estático por roda", minimum=0)
                current = (self.qc_kn*wheel.qc_fraction + self.nominal_payload_kn*wheel.payload_fraction + self.retained_lifting_accessories_kn*wheel.retained_fraction + self.moving_suspended_ropes_kn*wheel.ropes_fraction)
                if wheel.maximum_static_vertical_kn + 1e-12 < current:
                    raise ValueError("Máximo estático declarado por roda é menor que sua carga nominal neste arranjo.")
                required(wheel.maximum_static_vertical_source, "Fonte do máximo estático por roda")
        for field in ("qc_fraction", "payload_fraction", "retained_fraction", "ropes_fraction"):
            if not math.isclose(math.fsum(getattr(w, field) for w in self.wheels), 1., rel_tol=0., abs_tol=1e-10):
                raise ValueError(field + ": as frações devem somar 1; não há normalização silenciosa.")
        if min(w.offset_m for w in self.wheels) != 0. or not self.travel_min_m < self.travel_max_m or self.travel_max_m + max(w.offset_m for w in self.wheels) > self.span_m:
            raise ValueError("Viagem deve ter intervalo positivo e manter todas as rodas no vão, com offset de referência zero.")
        if not self.fixed_gravity:
            raise ValueError("Declare ao menos uma parcela G fixa com fonte; zero exige justificativa explícita, não omissão.")
        if len({a.origin_id for a in self.fixed_gravity}) != len(self.fixed_gravity):
            raise ValueError("Origens permanentes repetidas.")
        for load in self.fixed_gravity:
            required(load.origin_id, "Origem G")
            required(load.source, "Fonte de G fixo")
            number(load.downward_kn_per_m, "G fixo", minimum=0)
        h = self.hoist_dynamics
        if h.hoist_class not in ("HC1", "HC2", "HC3", "HC4"):
            raise ValueError("Classe HC EN explícita obrigatória. Não há seleção ou conversão HD/NBR/CMAA.")
        number(h.steady_speed_m_s, "Velocidade estável de içamento EN", minimum=0)
        required(h.classification_source, "Fonte da classificação HC EN")
        required(h.speed_source, "Fonte da velocidade estável")
        t = self.travel_dynamics
        if t.basis not in ("unresolved", "class1_documented", "manufacturer"):
            raise ValueError("Base de φ4 desconhecida.")
        if t.basis == "unresolved":
            if t.phi4 is not None:
                raise ValueError("φ4 não pode ser preenchido sem base qualificada.")
        else:
            required(t.source, "Fonte de φ4 / evidência Classe 1 EN 1090-2")
            number(t.phi4, "φ4", minimum=1.)
            if t.basis == "class1_documented" and t.phi4 != 1.:
                raise ValueError("A rota Classe 1 documentada utiliza φ4=1.")
        if len({s.set_id for s in self.manufacturer_horizontal_sets}) != len(self.manufacturer_horizontal_sets):
            raise ValueError("Identificações de conjuntos horizontais repetidas.")
        wheel_map = {w.wheel_id:w for w in self.wheels}
        for s in self.manufacturer_horizontal_sets:
            for field in ("set_id", "source", "simultaneity_source", "direction_description", "application_geometry_source"):
                required(getattr(s, field), "Conjunto horizontal: " + field)
            if s.group_code != "G6":
                raise ValueError("Primeiro domínio de fabricante: grupo G6 correlacionado de aceleração/frenagem do trole. Outros grupos exigem extensão qualificada.")
            if not s.characteristic_dynamic_included:
                raise ValueError("Força motriz estática não é ação característica pronta. Forneça dinâmica qualificada, sem φ5 inventado.")
            if len(s.wheel_forces) != len(self.wheels) or {f.wheel_id for f in s.wheel_forces} != set(wheel_map):
                raise ValueError("Conjunto horizontal deve declarar todas as rodas, inclusive zeros explícitos; não preencher forças ausentes.")
            for force in s.wheel_forces:
                w = wheel_map[force.wheel_id]
                if (force.offset_m,force.y_m,force.z_m) != (w.offset_m,w.y_m,w.z_m):
                    raise ValueError("Força de fabricante fora das coordenadas do contato declarado; guia/rolete em outra altura requer adaptador próprio.")
        if len({t.test_id for t in self.tests}) != len(self.tests):
            raise ValueError("Identificações de ensaio repetidas.")
        for test in self.tests:
            required(test.test_id, "Ensaio")
            required(test.source, "Fonte do plano de ensaio")
            if test.kind not in ("dynamic", "static"):
                raise ValueError("Ensaio deve ser dinâmico ou estático.")
            minimum = (1.10 if test.kind == "dynamic" else 1.25)*self.nominal_qh_kn
            number(test.total_hoist_test_kn, "QT", positive=True)
            if test.total_hoist_test_kn + 1e-12 < minimum:
                raise ValueError("QT é inferior ao mínimo de 2.10 da EN 1991-3 para a carga içada nominal Qh completa.")
            if len(test.wheel_fractions) != len(self.wheels) or any(x < 0 for x in test.wheel_fractions) or not math.isclose(math.fsum(test.wheel_fractions),1.,rel_tol=0.,abs_tol=1e-10):
                raise ValueError("Frações explícitas de QT devem corresponder às rodas e somar 1.")
        if self.crane_absence_admissible:
            required(self.crane_absence_source, "Fonte da possibilidade física de ausência da talha")
        return self
