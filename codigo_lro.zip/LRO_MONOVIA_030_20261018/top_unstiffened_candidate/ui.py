"""Isolated Streamlit app. Blank physical fields; no fabricated real project.

Run: streamlit run top_unstiffened_candidate/ui.py
with runway_043/src and the repository root on PYTHONPATH.
"""
from __future__ import annotations
from copy import deepcopy
from dataclasses import fields,asdict
from pathlib import Path
import gzip,json
if not __package__:
    import sys
    sys.path[:0]=[str(Path(__file__).resolve().parents[1]),str(Path(__file__).resolve().parents[1]/'runway_043/src')]
    __package__='top_unstiffened_candidate'
from .project import (SCHEMA,SourceRecord,StructureInputs,ModelInputs,ActionInputs,TopWorkflowProject,SOURCE_GROUPS,
    TopBridgeInputs,Material,RailInput,StabilityPremises,ENPhysicalFatigueInputs,project_from_dict,loads_project,
    project_document,replace_catalog_profile,INTERMEDIATE_SCHEMA,INTERMEDIATE_BASIS_ID)
from .mechanics import BASIS_ID
from .stiffeners.ui import PREFIX as INTERMEDIATE_PREFIX,render_intermediate_inputs
from .action_inputs import CMAAActionPremises
from underslung_runway_candidate.autonomous_workflow.nbr_rolling import NBRRollingGuidance,GUIDANCE_MODEL
from .pipeline import analyze_project,analyze_profile_family,assert_current_result,calculation_document,AnalysisControls,presentation_receipt
from .report import build_report_docx,STATUS_LABELS,governing_check_rows,scope_status,report_is_partial,report_execution_note
from underslung_runway_candidate.autonomous_workflow.model import signature
from lro_beams.crane_catalog import select_references,get_catalog_record,can_propose_physical_reference,reference_rows
from lro_beams.document_metadata import DOCUMENT_FIELDS,word_cache_signature
from lro_beams.catalog import profile_names,section_from_profile

LABELS={
 'hoist_class':'Classe de içamento HC','drive_class':'Classe de acionamento HD','equipment_group':'Grupo de serviço A',
 'label':'Nome do projeto / estudo','span_m':'Vão entre apoios [m]','beam_end_left_mm':'Balanço físico sem rodas à esquerda [mm]',
 'beam_end_right_mm':'Balanço físico sem rodas à direita [mm]','support_bearing_length_mm':'Comprimento real de apoio sob a alma [mm]',
 'extra_dead_kn_per_m':'Carga permanente adicional [kN/m]','capacity_t':'Capacidade nominal de carga útil [t métricas], sem massa retida',
 'bridge_span_mm':'Vão da ponte entre vias [mm]','bridge_mass_kg':'Massa da ponte e cabeceiras, sem carro [kg]',
 'trolley_mass_kg':'Massa do carro [kg]','bridge_acceleration_m_s2':'Limite absoluto da aceleração longitudinal [m/s²]',
 'trolley_acceleration_m_s2':'Limite absoluto da aceleração transversal [m/s²]',
 'carriage_station_spacing_mm':'Distância entre estações de rodas [mm]','hook_min_from_left_mm':'Gancho mínimo desde a via esquerda [mm]',
 'hook_max_from_left_mm':'Gancho máximo desde a via esquerda [mm]','nominal_speed_m_s':'Velocidade nominal de elevação [m/s]',
 'creep_speed_m_s':'Velocidade lenta [m/s, quando aplicável]','horizontal_dynamic_factor':'Amplificação horizontal característica NBR [-]',
 'horizontal_dynamic_source':'Fonte da amplificação horizontal (não usar o psi vertical)',
 'fy_mpa':'Resistência ao escoamento fy [MPa]','fu_mpa':'Resistência à ruptura fu [MPa]',
 'E_mpa':'Módulo de elasticidade E [MPa]','G_mpa':'Módulo transversal G [MPa]','gamma_a1':'Coeficiente de resistência gamma a1 [-]',
 'bridge_cg_x_mm':'CG da ponte: ξ desde meio das estações [mm]','bridge_cg_y_mm':'CG da ponte: y desde via esquerda [mm]',
 'bridge_cg_z_mm':'CG da ponte: z acima do plano dos trilhos [mm]','trolley_cg_x_mm':'CG do carro: ξ desde meio das estações [mm]',
 'trolley_cg_z_mm':'CG do carro: z [mm]','trolley_cg_minus_hook_mm':'CG do carro menos posição do gancho [mm]',
 'suspension_point_x_mm':'Ponto de suspensão: ξ desde meio das estações [mm]','suspension_point_z_mm':'Ponto de suspensão: z [mm]',
 'lifted_cg_x_mm':'CG da carga guiada: ξ desde meio das estações [mm]','lifted_cg_z_min_mm':'CG da carga guiada: z mínimo [mm]',
 'lifted_cg_z_max_mm':'CG da carga guiada: z máximo [mm]','gravity_m_s2':'Gravidade [m/s²]',
}
LABELS.update({
 'mass_accounting_convention':'Composição comum das massas suspensas',
 'retained_suspended_mass_kg':'Massa suspensa retida no vazio [kg], informar inclusive zero',
 'retained_suspended_cg_x_mm':'CG da massa retida guiada: ξ desde o centro do trem [mm]',
 'retained_suspended_cg_z_mm':'CG da massa retida guiada: z desde contatos [mm]',
 'retained_mass_excluded_from_equipment':'Massa retida excluída das massas da ponte e do carro',
 'suspended_mass_source':'Fonte da massa retida, acessórios, CG e ausência de dupla contagem',
 'geometry_mass_cg_source':'Fontes das massas, geometria e centros de massa',
 'acceleration_dynamic_source':'Fonte dos limites de aceleração',
 'equalization_source':'Fonte da partilha igualizada dos contatos',
 'force_transfer_source':'Fonte do modelo de transferência da carga',
 'transfer_model':'Transferência da carga à ponte','equalization_model':'Partilha entre contatos',
 'hoist_classification_source':'Fonte das classes de elevação HC/HD',
 'equipment_group_source':'Fonte do grupo do equipamento','operating_scope':'Domínio operacional avaliado',
 'operating_scope_source':'Fonte e limites do domínio operacional',
 'physical_stiffeners':'Enrijecedores físicos','ordinary_member_geometry':'Condição do perfil',
 'nominal_basis':'Modelo de análise nominal','root_geometry_basis':'Base da geometria de raiz',
 'root_geometry_source':'Fonte da raiz/altura livre','end_fork_basis':'Modelo das forquilhas de extremidade',
 'end_fork_source':'Fonte/requisito da forquilha real','support_model':'Modelo dos apoios',
 'axial_support':'Ancoragem axial','wheel_travel_scope':'Trecho de passagem das rodas','support_contact':'Contato inferior do apoio',
 'method_adoption_source':'Fonte de adoção do método','resistance_gamma':'Coeficiente de resistência complementar',
 'material_environment':'Material e ambiente','material_environment_source':'Fonte da condição de material/ambiente',
 'permanent_baseline':'Referência da carga permanente no serviço','permanent_baseline_source':'Fonte da referência de serviço',
 'lateral_direction_model':'Sentidos do carregamento lateral de serviço',
 'dynamic_equipment':'Amplificação dinâmica do equipamento na fadiga','dynamic_lifted':'Amplificação da carga içada na fadiga',
 'action_source':'Fonte das ações da fadiga','fixed_train_operating_limit_source':'Fonte do limite operacional do trem fixo',
 'detail_delivery':'Condição de fornecimento do laminado','detail_condition_source':'Fonte da condição do detalhe',
 'environment':'Ambiente de exposição','environment_source':'Fonte das condições ambientais',
 'execution_source':'Fonte das condições de execução','nominal_method_adoption_source':'Fonte da adoção do método nominal',
 'assessed_plain_region_condition':'Regiões ordinárias avaliadas','vertical_operating_model':'Modelo de dinâmica vertical',
 'minimum_equipment_gravity':'Fator mínimo de gravidade do equipamento','minimum_lifted_gravity':'Fator mínimo da carga içada',
 'minimum_gravity_source':'Fonte dos fatores mínimos de gravidade','gamma_ff':'Fator de ações de fadiga gamma Ff',
 'gamma_mf':'Fator de resistência à fadiga gamma Mf','gamma_mser':'Fator do limite elástico gamma Mser'})
ENUM_LABELS={
 'payload_plus_retained_suspended_mass':'Carga útil nominal + massa suspensa retida separada',
 'legacy_all_lifted_removed_when_empty':'Legado: toda parcela içada removida no vazio; massa retida desconhecida',
 'reference':'Referência para comparação','design_requirement':'Requisito de projeto/fornecimento','confirmed':'Dado informado como confirmado',
 'actual_project':'Projeto real com dados a informar','synthetic_example':'Exemplo sintético explicitamente identificado',
 'absent':'Ausentes, explicitamente','plain_prismatic_no_modifications':'Laminado prismático ordinário, sem modificações',
 BASIS_ID:'Analogia nominal CISC 2005, complementar às verificações identificadas',
 'catalog_root_toe_depth':'Altura livre entre concordâncias, obtida do catálogo',
 'adopted_true_forks_free_warping':'Requisito de forquilhas verdadeiras com empenamento livre',
 'confirmed_true_forks_free_warping':'Forquilhas verdadeiras informadas como confirmadas, empenamento livre',
 'simple_forks_free_warping':'Forquilhas simples, empenamento livre','left_fixed_right_sliding':'Ancoragem axial à esquerda e deslizamento à direita',
 'between_support_axes':'Rodas somente entre eixos dos apoios','centered_under_web':'Apoio centrado sob a alma',
 'free_suspended_at_crab':'Carga livre suspensa pelo carro','guided_rigid_payload_cg':'Carga rígida guiada pelo CG declarado',
 'adopted_bilinear_four_contact_no_diagonal_self_stress':'Partilha bilinear igualizada em quatro contatos, sem autoequilíbrio diagonal',
 'normal_gravity_horizontal_drive_only':'Gravidade e acionamentos horizontais normais',
 'structural_steel_ambient_temperature':'Aço estrutural em temperatura ambiente',
 'wheel_load_increment_only':'Incremento devido somente às rodas','include_permanent_absolute_bound':'Limite absoluto incluindo a carga permanente',
 'both_signed_10_percent_wheel_load_scenarios':'Ambos os sentidos com 10% da carga de roda',
 'steel_or_equipment':'Aço ou equipamento','precast_or_timber':'Pré-moldado ou madeira',
 'cast_in_place_or_permanent_thrust':'Concreto moldado no local ou empuxo permanente',
 'industrial_with_in_situ_additions':'Equipamento industrial com acréscimos locais','general_construction':'Construção em geral',
 'rectangular_demonstration':'Retangular explicitamente informado','catalog_or_manufacturer':'Propriedades de catálogo/fabricante',
 'verified_catalog':'Catálogo verificado','non_composite':'Sem composição resistente','flanged':'Rodas com flange',
 'guide_roller_unguided_side':'Guiamento por roletes','non_rigid':'Fixação local não rígida','continuous_no_joint':'Trilho contínuo sem juntas',
 'EN10163-3_C3_no_weld_repair':'Laminado EN10163-3 C3 sem reparo por solda',
 'normal_atmosphere_maintained_no_galvanizing_no_weathering':'Atmosfera normal, manutenção, sem galvanização ou aço patinável',
 'ordinary_unmodified_undamaged_rolled_plain_regions_excluding_discontinuities':'Regiões ordinárias intactas, sem modificações e sem descontinuidades',
 'quasistatic_suspended_gravity_plus_horizontal':'Carga suspensa quase estática e movimentos horizontais',
 'source_bounded_vertical_dynamics':'Dinâmica vertical com limites documentados'}

LABELS.update(dict(equipment_category='Categoria do equipamento no serviço NBR',equipment_category_source='Fonte da categoria ou limite conservador adotado',
    measurement_plane='Plano real de medição da flecha',measurement_plane_source='Fonte da posição real do trilho',
    baseline='Estado de referência das deformações',baseline_source='Fonte da composição do estado de referência',
    horizontal_action_source='Fonte da adoção de m·a físico sem amplificação dinâmica no serviço',
    source='Fonte ou requisito explícito',vertical_ratio='Divisor vertical adicional de projeto L / ? [opcional]',horizontal_ratio='Divisor lateral adicional de projeto L / ? [opcional]'))
ENUM_LABELS.update(dict(siderurgical_equipment='Equipamento siderúrgico: L/1000, limitado a 25 mm',
    other_equipment='Demais equipamentos: L/600, limitado a 25 mm',
    unclassified_adopt_stricter_L1000='Categoria não estabelecida: adotar L/1000, limitado a 25 mm',
    top_of_actual_rail='Topo do trilho real, sem deslocar a medição para o centro de cisalhamento',
    support_structure_selfweight_only_same_linear_operator='Incremento desde o peso próprio da estrutura de suporte, no mesmo modelo linear',
    normal_operation_without_wind='Operação normal sem vento'))

def enum_label(value):return ENUM_LABELS.get(value,value)

ENUMS={
 'mass_accounting_convention':['payload_plus_retained_suspended_mass','legacy_all_lifted_removed_when_empty'],
 'extra_dead_kind':['steel_or_equipment','precast_or_timber','cast_in_place_or_permanent_thrust','industrial_with_in_situ_additions','general_construction'],
 'hoist_class':['HC1','HC2','HC3','HC4'],'drive_class':['HD1','HD2','HD3','HD4','HD5'],
 'equipment_group':[f'A{i}' for i in range(1,9)],'operating_scope':['normal_gravity_horizontal_drive_only'],
 'transfer_model':['free_suspended_at_crab','guided_rigid_payload_cg'],
 'equalization_model':['adopted_bilinear_four_contact_no_diagonal_self_stress'],
 'physical_stiffeners':['absent'],'ordinary_member_geometry':['plain_prismatic_no_modifications'],
 'nominal_basis':[BASIS_ID],'root_geometry_basis':['catalog_root_toe_depth'],
 'end_fork_basis':['adopted_true_forks_free_warping','confirmed_true_forks_free_warping'],
 'support_model':['simple_forks_free_warping'],'axial_support':['left_fixed_right_sliding'],
 'wheel_travel_scope':['between_support_axes'],'support_contact':['centered_under_web'],
 'material_environment':['structural_steel_ambient_temperature'],
 'permanent_baseline':['wheel_load_increment_only','include_permanent_absolute_bound'],
 'lateral_direction_model':['both_signed_10_percent_wheel_load_scenarios'],
 'shape':['rectangular_demonstration','catalog_or_manufacturer','verified_catalog'],
 'attachment':['non_composite'],'wheel_guidance':['flanged','guide_roller_unguided_side'],
 'local_attachment':['non_rigid'],'continuity':['continuous_no_joint'],
 'detail_delivery':['EN10163-3_C3_no_weld_repair'],
 'environment':['normal_atmosphere_maintained_no_galvanizing_no_weathering'],
 'assessed_plain_region_condition':['ordinary_unmodified_undamaged_rolled_plain_regions_excluding_discontinuities'],
 'vertical_operating_model':['quasistatic_suspended_gravity_plus_horizontal','source_bounded_vertical_dynamics'],
}

LABELS.update(dict(bridge_travel_speed_m_s='Velocidade física da ponte [m/s]',trolley_travel_speed_m_s='Velocidade física do carro [m/s]',
    hoist_speed_m_s='Velocidade física de içamento [m/s]',operating_environment='Ambiente de operação CMAA',load_engagement='Modo de engate da carga',
    crane_configuration='Configuração e adoção do método CMAA',physical_source='Fonte das velocidades, operação e adoção CMAA'))
ENUM_LABELS.update(dict(indoor_no_operating_wind='Operação interna sem vento operacional',normal_non_abrupt='Engate normal, não brusco',
    single_girder_under_running_trolley='Ponte de uma viga com carro suspenso',not_established_adopted_nominal_method='Configuração não estabelecida: adoção explícita do método nominal CMAA',
    NBR8800_NORMAL_ULS='Ações NBR declaradas → ELU NBR 8800 (rota existente)',
    CMAA74_2020_CHARACTERISTIC_NBR8800_NORMAL_ULS='Origens características CMAA 74:2020 → ELU NBR 8800 complementar'))
ENUMS.update(dict(operating_environment=['indoor_no_operating_wind'],load_engagement=['normal_non_abrupt'],
    crane_configuration=['single_girder_under_running_trolley','not_established_adopted_nominal_method']))

LABELS.update(dict(model='Topologia física de guiamento NBR',geometry_source='Fonte da topologia física real de rodas/guiamento',
    reference_adoption_source='Fonte da adoção conservadora da reação vertical estática/serviço'))
ENUM_LABELS[GUIDANCE_MODEL]='Quatro contatos de rodas com flange, sem bogies/equalizadores físicos ou guias separados'
ENUMS['model']=[GUIDANCE_MODEL]

ENUMS.update(dict(equipment_category=['siderurgical_equipment','other_equipment','unclassified_adopt_stricter_L1000'],
    measurement_plane=['top_of_actual_rail'],baseline=['support_structure_selfweight_only_same_linear_operator']))


def _blank(cls):
    return {f.name:None if any(t in str(f.type) for t in ('float','int','bool')) else '' for f in fields(cls)}


def blank_inputs():
    return dict(schema=SCHEMA,identity='actual_project',label='',section_catalog_id='',
        structure=_blank(StructureInputs),material=_blank(Material),rail=_blank(RailInput),bridge=_blank(TopBridgeInputs),
        model=_blank(ModelInputs),actions=_blank(ActionInputs),sources={k:dict(status='',source='') for k in SOURCE_GROUPS},
        stability=None,fatigue=None,service=None,nbr_fatigue=None,cmaa_fatigue=None,nbr_service=None,manual_service=None,cmaa_actions=None,nbr_rolling_guidance=None,verification_lengths=None)


def report_cache_key(result,metadata=None):
    return word_cache_signature(result['result_signature']+':'+presentation_receipt()['sha256'],metadata)


def technical_export_cache_key(result,metadata=None):
    return report_cache_key(result,metadata)+':technical-json-gzip-v1'


def build_technical_export_gzip(project,result,metadata=None):
    """Explicit advanced export only; retain the complete guarded signed result."""
    document=calculation_document(project,result,metadata)
    return gzip.compress(json.dumps(document,ensure_ascii=False,indent=2).encode('utf-8'),compresslevel=6,mtime=0)


def _clear_result(st):
    for k in ('tu_result','tu_word','tu_word_key','tu_family','tu_technical_gzip','tu_technical_key'):st.session_state.pop(k,None)


def _adopt_inputs(st,raw,metadata):
    for key in list(st.session_state):
        if key.startswith(('tu_input:','tu_meta:')):del st.session_state[key]
    st.session_state['tu_raw']=deepcopy(raw);st.session_state['tu_metadata']=dict(metadata);_clear_result(st)


def _edit_group(st,raw,cls,prefix,field_names=None):
    out=dict(raw)
    columns=st.columns(2)
    for i,f in enumerate(f for f in fields(cls) if field_names is None or f.name in field_names):
        with columns[i%2]:
            key='tu_input:'+prefix+'.'+f.name;label=LABELS.get(f.name,f.name.replace('_',' '))
            value=raw.get(f.name)
            if f.name=='capacity_t' and raw.get('mass_accounting_convention')=='legacy_all_lifted_removed_when_empty':
                label='Parcela içada removível declarada, convenção legada [t métricas]'
            if f.name in ENUMS:
                options=['normal_operation_without_wind'] if prefix=='nbr_service' and f.name=='operating_scope' else ENUMS[f.name]
                out[f.name]=st.selectbox(label,options,index=options.index(value) if value in options else None,placeholder='Selecionar explicitamente',key=key,format_func=enum_label) or ''
            elif 'bool' in str(f.type):
                options=[None,True]
                out[f.name]=st.selectbox(label,options,index=options.index(value) if value in options else 0,
                    format_func=lambda v:'Não declarado' if v is None else 'Sim, separado sem dupla contagem',key=key)
            elif 'float' in str(f.type) or 'int' in str(f.type):
                out[f.name]=st.number_input(label,value=None if value is None else float(value),format='%.3f',key=key)
            else:
                kw={} if key in st.session_state else {'value':'' if value is None else str(value)}
                out[f.name]=st.text_input(label,key=key,**kw)
    return out


# These fields are controlled together by the physical intermediate editor,
# never by the legacy absent-only model dropdowns.
_INTERMEDIATE_MODEL_FIELDS = ('physical_stiffeners', 'ordinary_member_geometry', 'nominal_basis')
_LEGACY_MODEL = dict(physical_stiffeners='absent',
    ordinary_member_geometry='plain_prismatic_no_modifications', nominal_basis=BASIS_ID)
_PRESENT_MODEL = dict(physical_stiffeners='present',
    ordinary_member_geometry='plain_prismatic_with_intermediate_stabilizers', nominal_basis=INTERMEDIATE_BASIS_ID)


def _intermediate_editor_base(raw):
    """A validated temporary base for editing, not an absent calculation fallback."""
    base = deepcopy(raw)
    base['schema'] = SCHEMA
    base.pop('intermediates', None)
    base['model'].update(_LEGACY_MODEL)
    return project_from_dict(base)


def _render_intermediate_editor(st, raw):
    """Apply valid physical edits only; invalid present input always fails closed."""
    state, prefix = st.session_state, INTERMEDIATE_PREFIX
    state[prefix+'input_valid'] = False
    state[prefix+'_editor_error'] = 'Revise as entradas do detalhe intermediário; o rascunho foi preservado.'
    try:
        base = _intermediate_editor_base(raw)
    except (ValueError, TypeError, KeyError) as exc:
        state[prefix+'_editor_error'] = str(exc)
        st.info('Complete os dados físicos e as fontes da viga/ponte para editar o detalhe intermediário: '+str(exc))
        return False
    geometry = (base.section_catalog_id, base.structure.span_m)
    current = None if state.get(prefix+'_editor_reset') else raw.get('intermediates', state.get(prefix+'_editor_inventory'))
    mode = state.get(prefix+'mode', state.get(prefix+'_draft_widgets', {}).get('mode'))
    if current is not None or mode == 'present':
        st.caption('A geometria adotada não é redimensionada ao alterar o perfil ou o vão. '
            'Para uma nova proposta sintética editável, reinicie explicitamente; os dados anteriores podem ser desfeitos.')
        if st.button('Reiniciar proposta para o perfil/vão atuais', key='tu_intermediate_reset'):
            previous = dict(schema=raw['schema'], model={k:raw['model'][k] for k in _INTERMEDIATE_MODEL_FIELDS},
                intermediates=deepcopy(raw.get('intermediates')),
                widgets={k:deepcopy(state[k]) for k in state if k.startswith(prefix) and k != prefix+'_editor_undo'})
            for key in list(state):
                if key.startswith(prefix): del state[key]
            state[prefix+'_editor_undo'] = previous
            state[prefix+'_editor_reset'] = True
            state[prefix+'mode'] = 'present'
            current, mode = None, 'present'
            _clear_result(st)
    if state.get(prefix+'_editor_undo') is not None and st.button('Desfazer reinício da proposta', key='tu_intermediate_undo'):
        previous = state[prefix+'_editor_undo']
        for key in list(state):
            if key.startswith(prefix): del state[key]
        state.update(previous['widgets'])
        raw['schema'] = previous['schema']
        raw['model'].update(previous['model'])
        if previous['intermediates'] is None: raw.pop('intermediates', None)
        else: raw['intermediates'] = deepcopy(previous['intermediates'])
        current = None if state.get(prefix+'_editor_reset') else raw.get('intermediates', state.get(prefix+'_editor_inventory'))
        mode = state.get(prefix+'mode', state.get(prefix+'_draft_widgets', {}).get('mode'))
        _clear_result(st)
    # An invalid first proposal has no typed inventory yet. Do not let the
    # panel's provisional-default mechanism silently rescale that saved draft.
    seed_geometry = state.get(prefix+'_editor_geometry')
    if current is None and mode == 'present' and seed_geometry is not None and seed_geometry != geometry:
        state[prefix+'input_valid'] = False
        st.warning('O perfil/vão mudou enquanto o detalhe estava em edição. O rascunho foi preservado; '
            'restaure o perfil/vão anterior ou reinicie explicitamente a proposta.')
        return False
    result = render_intermediate_inputs(st, base, current=current)
    if state.get(prefix+'mode') == 'present':
        state[prefix+'_editor_geometry'] = geometry
    if not state.get(prefix+'input_valid', False):
        return False
    if result is None:
        raw['schema'] = SCHEMA
        raw['model'].update(_LEGACY_MODEL)
        raw.pop('intermediates', None)
    else:
        inventory = result.to_dict()
        raw['schema'] = INTERMEDIATE_SCHEMA
        raw['model'].update(_PRESENT_MODEL)
        raw['intermediates'] = inventory
        state[prefix+'_editor_inventory'] = deepcopy(inventory)
        state[prefix+'_editor_reset'] = False
        # Freeze the adopted geometry. Later span/profile changes are validated,
        # not silently converted into new plate positions or beam dimensions.
        state[prefix+'_automatic'] = False
    return True


def catalog_physical_proposal(raw,record_id,capacity_t,bridge_span_m):
    """Preview only: correlated published values, never inferred CG/dynamics."""
    record=get_catalog_record(record_id)
    if not can_propose_physical_reference(record,capacity_t,bridge_span_m):
        raise ValueError('Registro não corresponde à capacidade/faixa ou não separa as massas necessárias.')
    after=deepcopy(raw)
    updates=dict(capacity_t=capacity_t,bridge_span_mm=bridge_span_m*1000,
        bridge_mass_kg=record['bridge_only_mass_kg'],trolley_mass_kg=record['trolley_mass_kg'],
        carriage_station_spacing_mm=record['wheelbase_m']*1000,
        hook_min_from_left_mm=record['hook_approach_left_m']*1000,
        hook_max_from_left_mm=bridge_span_m*1000-record['hook_approach_right_m']*1000)
    if updates['hook_min_from_left_mm']>updates['hook_max_from_left_mm']:raise ValueError('Aproximações incompatíveis com o vão informado.')
    source=record['record_id']+'; '+record['source_url']+'; página PDF '+str(record['source_pdf_page'])
    previous=after['bridge'].get('geometry_mass_cg_source','')
    updates['geometry_mass_cg_source']=source+'. Apenas massas, entre-eixos e aproximações publicados. CGs, acelerações e modelo de transferência não inferidos.'+((' Fonte anterior para os demais dados: '+previous) if previous else '')
    after['bridge'].update(updates)
    after['sources']['bridge']=dict(status='design_requirement',source='Hipótese correlacionada de fornecimento: '+source+'. Sem confirmação do equipamento instalado; compatibilizar CGs e demais condições separadamente.')
    diff=[dict(campo='bridge.'+key,antes=raw['bridge'].get(key),depois=value) for key,value in updates.items() if raw['bridge'].get(key)!=value]
    return dict(before_signature=signature(raw),after=after,diff=diff,record_id=record_id,
        source_url=record['source_url'],source_page=record['source_pdf_page'],capacity_t=capacity_t,bridge_span_m=bridge_span_m)


def _render_catalog(st,raw,metadata):
    with st.expander('Catálogo correlacionado da ponte · prévia antes de aplicar'):
        st.caption('O vão entre trilhos da ponte é diferente do vão entre apoios da viga. Massas, talha, entre-eixos e aproximações devem permanecer na mesma linha de catálogo. Nenhum Pmáx publicado é importado como esforço.')
        cols=st.columns(2)
        with cols[0]:capacity=st.number_input('Capacidade desejada no catálogo [t]',value=raw['bridge'].get('capacity_t'),key='tu_catalog_capacity')
        with cols[1]:span=st.number_input('Vão entre trilhos da ponte [m]',value=raw['bridge']['bridge_span_mm']/1000 if raw['bridge'].get('bridge_span_mm') is not None else None,key='tu_catalog_span')
        try:records=[r for r in select_references(capacity,span) if can_propose_physical_reference(r,capacity,span)]
        except (ValueError,TypeError):records=[]
        if records:
            ids=[r['record_id'] for r in records]
            selected=st.selectbox('Linha completa de referência',ids,index=None,placeholder='Escolher referência',key='tu_catalog_record')
            if selected:
                record=get_catalog_record(selected)
                st.dataframe([{'Dado':k,'Valor':v} for k,v in reference_rows(record)],hide_index=True)
                st.link_button('Consultar catálogo do fabricante',record['source_url'])
                if st.button('Preparar prévia dos dados publicados',key='tu_catalog_preview'):
                    st.session_state['tu_catalog_proposal']=catalog_physical_proposal(raw,selected,capacity,span)
        else:st.caption('Informe capacidade e vão da ponte para procurar correspondência exata ou faixa publicada. Sem interpolação automática.')
        proposal=st.session_state.get('tu_catalog_proposal')
        if proposal:
            st.dataframe([{k:('Não informado' if v is None else str(v)) for k,v in row.items()} for row in proposal['diff']],hide_index=True)
            current=(signature(raw)==proposal['before_signature'] and capacity==proposal['capacity_t'] and span==proposal['bridge_span_m'] and st.session_state.get('tu_catalog_record')==proposal['record_id'])
            if not current:st.warning('Dados ou seleção mudaram depois da prévia. Prepare nova proposta.')
            st.caption('CGs, alturas, acelerações e contenções não são inventados nem confirmados. O vão da viga, perfil, material e trilho não serão alterados.')
            if st.button('Aplicar como requisito de fornecimento',disabled=not current,key='tu_catalog_apply'):
                st.session_state['tu_catalog_previous']=deepcopy(raw)
                after=proposal['after'];st.session_state.pop('tu_catalog_proposal',None)
                _adopt_inputs(st,after,metadata);st.rerun()
            if st.button('Descartar prévia',key='tu_catalog_discard'):st.session_state.pop('tu_catalog_proposal',None);st.rerun()
        if st.session_state.get('tu_catalog_previous') is not None and st.button('Desfazer última aplicação do catálogo',key='tu_catalog_undo'):
            old=st.session_state.pop('tu_catalog_previous');st.session_state.pop('tu_catalog_proposal',None)
            _adopt_inputs(st,old,metadata);st.rerun()


def run(*,embedded=False):
    import streamlit as st
    from lro_beams.visual_identity import render_app_header
    if not embedded:
        st.set_page_config(page_title='LRO · TOP',layout='wide')
        render_app_header(st,'candidato isolado · TOP com intermediários opcionais')
    st.subheader('Ponte apoiada TOP · intermediários adotados opcionais')
    st.info('Dados físicos → reações da ponte → todas as configurações extremas → verificações por escopo. Nenhum esforço Robot é solicitado. Base híbrida identificada, não uma certificação integral CMAA.')
    st.caption('Não há geometria real pré-carregada. Campos vazios são desconhecidos; adotar um requisito não confirma a condição construída.')
    if 'tu_raw' not in st.session_state:st.session_state['tu_raw']=blank_inputs()
    raw=deepcopy(st.session_state['tu_raw']);metadata=dict(st.session_state.get('tu_metadata',{}))
    with st.expander('Abrir, identificar e salvar estudo',expanded=True):
        upload=st.file_uploader('Projeto físico JSON desta rota',type=['json'],key='tu_upload')
        if st.button('Abrir arquivo',disabled=upload is None):
            try:
                p,meta=loads_project(upload.getvalue());_adopt_inputs(st,p.to_dict(),meta);st.rerun()
            except (ValueError,TypeError,UnicodeError) as exc:st.error(str(exc))
        if st.button('Limpar todos os dados físicos'):_adopt_inputs(st,blank_inputs(),{});st.rerun()
        raw['identity']=st.selectbox('Natureza do estudo',['actual_project','synthetic_example'],index=0 if raw['identity']=='actual_project' else 1,key='tu_input:identity',format_func=enum_label)
        raw['label']=st.text_input('Nome do projeto / estudo',value=raw['label'],key='tu_input:label')
        for name,label in DOCUMENT_FIELDS.items():metadata[name]=st.text_input(label,value=metadata.get(name,''),key='tu_meta:'+name)
    tabs=st.tabs(['Viga e material','Ponte e movimentos','Modelo e fontes','Fadiga / estabilidade / serviço','Resultados e família'])
    with tabs[0]:
        names=profile_names();selected=st.selectbox('Perfil laminado do catálogo',names,index=names.index(raw['section_catalog_id']) if raw['section_catalog_id'] in names else None,placeholder='Selecionar perfil',key='tu_input:section')
        if selected:
            section=section_from_profile(selected)
            if raw['section_catalog_id']!=section.catalog_id:
                raw['model']['root_geometry_basis']='catalog_root_toe_depth';raw['model']['root_geometry_source']=section.property_source
                raw['sources']['section']={'status':'design_requirement','source':section.property_source}
                for key,value in {'tu_input:model.root_geometry_basis':'catalog_root_toe_depth','tu_input:model.root_geometry_source':section.property_source,'tu_input:source:section':'design_requirement','tu_input:source_text:section':section.property_source}.items():st.session_state[key]=value
            raw['section_catalog_id']=section.catalog_id
            st.caption(section.property_source)
        raw['structure']=_edit_group(st,raw['structure'],StructureInputs,'structure')
        with st.expander('Material',expanded=True):raw['material']=_edit_group(st,raw['material'],Material,'material')
        with st.expander('Trilho: propriedades e posição, sem composição resistente'):
            st.caption('Informe propriedades rastreáveis do trilho. A inércia é apenas do trilho; não da viga composta. Excentricidades são explícitas, inclusive zero.')
            raw['rail']=_edit_group(st,raw['rail'],RailInput,'rail')
    with tabs[1]:
        st.caption('x é a posição física ao longo da viga, desde o apoio esquerdo. ξ é a coordenada longitudinal da ponte/carga relativa ao centro entre estações do trem; y vai da via esquerda à direita; z é medido do plano comum dos contatos. A carga livre usa ponto de suspensão, não CG inventado da carga.')
        _render_catalog(st,raw,metadata)
        groups=[('Composição comum das massas suspensas',['mass_accounting_convention','retained_suspended_mass_kg','retained_suspended_cg_x_mm','retained_suspended_cg_z_mm','retained_mass_excluded_from_equipment','suspended_mass_source']),
          ('Capacidade, massas e geometria da ponte',['capacity_t','bridge_span_mm','bridge_mass_kg','trolley_mass_kg','carriage_station_spacing_mm','gravity_m_s2']),
          ('Curso do gancho e centros de massa a definir',['hook_min_from_left_mm','hook_max_from_left_mm','bridge_cg_x_mm','bridge_cg_y_mm','bridge_cg_z_mm','trolley_cg_x_mm','trolley_cg_z_mm','trolley_cg_minus_hook_mm']),
          ('Acelerações e caminho de transferência',['bridge_acceleration_m_s2','trolley_acceleration_m_s2','transfer_model','equalization_model','suspension_point_x_mm','suspension_point_z_mm','lifted_cg_x_mm','lifted_cg_z_min_mm','lifted_cg_z_max_mm']),
          ('Fontes da geometria, CGs, movimentos e partilha',['geometry_mass_cg_source','acceleration_dynamic_source','equalization_source','force_transfer_source'])]
        for title,names in groups:
            if title.startswith('Composição') and raw['bridge'].get('transfer_model')=='free_suspended_at_crab':
                names=[k for k in names if k not in ('retained_suspended_cg_x_mm','retained_suspended_cg_z_mm')]
            with st.expander(title,expanded=title.startswith(('Capacidade','Composição'))):
                raw['bridge']=_edit_group(st,raw['bridge'],TopBridgeInputs,'bridge',names)
                if title.startswith('Composição') and raw['bridge'].get('transfer_model')=='free_suspended_at_crab' and any(raw['bridge'].get(k) is not None for k in ('retained_suspended_cg_x_mm','retained_suspended_cg_z_mm')):
                    st.warning('Há CG retido de um modelo guiado anterior. A carga livre usa o ponto de suspensão declarado; remova os valores incompatíveis deliberadamente.')
                    if st.button('Remover CG retido incompatível com carga livre',key='tu_clear_retained_cg'):
                        for k in ('retained_suspended_cg_x_mm','retained_suspended_cg_z_mm'):
                            raw['bridge'][k]=None
                            st.session_state.pop('tu_input:bridge.'+k,None)
                        st.session_state['tu_raw']=deepcopy(raw)
                        _clear_result(st)
                        st.rerun()
        if raw['bridge'].get('mass_accounting_convention')=='legacy_all_lifted_removed_when_empty':
            st.warning('Entrada legada: a massa retida no vazio é desconhecida, não igual a zero. A aritmética histórica é preservada; revisar explicitamente a composição comum para dimensionar com moitão/acessórios retidos.')
        else:
            st.caption('Capacidade é somente carga útil. A massa retida permanece nos estados vazio e carregado, com a dinâmica própria da massa suspensa; nunca é somada ao peso da ponte/carro. Cabos livres usam o ponto declarado abaixo do carro, sem CG separado da massa retida.')
        missing=[LABELS.get(k,k) for k,v in raw['bridge'].items() if v is None and ('cg_' in k or k.startswith('suspension_point'))]
        if missing:st.caption('Ainda desconhecidos, não preenchidos pelo catálogo: '+', '.join(missing)+'. Declare limites de fornecimento/projeto com fonte quando não houver confirmação do equipamento.')
        st.subheader('Base explícita das ações de resistência')
        action_methods=['NBR8800_NORMAL_ULS','CMAA74_2020_CHARACTERISTIC_NBR8800_NORMAL_ULS']
        selected=st.selectbox('Método das ações para o ELU',action_methods,
            index=1 if raw.get('cmaa_actions') is not None else 0,key='tu_input:action_method',format_func=enum_label)
        if selected==action_methods[1]:
            st.caption('Seleção deliberada: substitui a geração NBR de resistência, sem somar as duas rotas. Usa origens CMAA 74:2020 e fatores ELU NBR 8800 com psi adicional igual a 1. O limite SK não é um estado físico testemunhado; a estabilidade usa um limite comum da família.')
            raw['cmaa_actions']=_edit_group(st,raw.get('cmaa_actions') or _blank(CMAAActionPremises),CMAAActionPremises,'cmaa_actions')
            st.caption('Velocidades, ambiente, engate e configuração são premissas de ações, separadas da classe/detalhe de fadiga CMAA. Massa retida e acelerações vêm da composição comum da ponte; não são informadas duas vezes.')
        else:raw['cmaa_actions']=None
        with st.expander('Declarações NBR: dinâmica, grupo e domínio normal',expanded=selected==action_methods[0]):
            if selected==action_methods[1]:
                st.caption('Declarações NBR preservadas separadamente para os critérios NBR aplicáveis. HC/HD, grupo A e amplificação horizontal não substituem os dados físicos CMAA nem entram novamente no ELU CMAA selecionado.')
            raw['actions']=_edit_group(st,raw['actions'],ActionInputs,'actions')
    with tabs[2]:
        raw['model']=_edit_group(st,raw['model'],ModelInputs,'model',
            [f.name for f in fields(ModelInputs) if f.name not in _INTERMEDIATE_MODEL_FIELDS])
        with st.expander('Comprimentos de flambagem para verificação da resistência',expanded=True):
            from .verification_lengths_ui import render_verification_lengths
            span=raw['structure'].get('span_m')
            raw['verification_lengths']=render_verification_lengths(st,raw.get('verification_lengths'),
                span*1000 if type(span) in (int,float) else None)
        for group in SOURCE_GROUPS:
            with st.expander('Origem: '+{'structure':'Viga','section':'Perfil','material':'Material','rail':'Trilho','bridge':'Ponte','actions':'Ações','model':'Modelo'}[group]):
                source=raw['sources'][group];opts=['reference','design_requirement','confirmed']
                status_key='tu_input:source:'+group
                status_kw={} if status_key in st.session_state else {'index':opts.index(source['status']) if source['status'] in opts else None}
                source['status']=st.selectbox('Status da informação',opts,key=status_key,format_func=enum_label,**status_kw) or ''
                source_key='tu_input:source_text:'+group
                source['source']=st.text_area('Documento, origem ou requisito explícito',key=source_key,**({} if source_key in st.session_state else {'value':source['source']}))
    with tabs[3]:
        from .fatigue_ui import render_nbr_premises,render_cmaa_premises
        from .detail_gallery import render_detail_gallery
        render_detail_gallery(st)
        for name,label,renderer in (('nbr_fatigue','fadiga NBR 10084 / NBR 8400-2 de vida classificada',render_nbr_premises),('cmaa_fatigue','comparação escalar de fadiga nominal CMAA',render_cmaa_premises)):
            with st.expander(label.capitalize()):
                enabled=st.checkbox('Avaliar '+label,value=raw.get(name) is not None,key='tu_input:enabled:'+name)
                raw[name]=renderer(st,raw.get(name),'tu_input:'+name+'.') if enabled else None
        with st.expander('Reação horizontal de rolamento NBR: topologia e referência vertical'):
            st.caption('Premissa física necessária à fadiga NBR Caso I e ao serviço NBR: quatro rodas com flange, duas vias e duas estações, sem bogies/equalizadores físicos ou guias separados. A partilha bilinear matemática da ponte não comprova esse arranjo físico. A relação p/a usa o vão da ponte e o entre-eixos comuns, nunca o vão da viga.')
            enabled=st.checkbox('Declarar topologia e adoção da reação de rolamento NBR',value=raw.get('nbr_rolling_guidance') is not None,key='tu_input:enabled:nbr_rolling_guidance')
            raw['nbr_rolling_guidance']=_edit_group(st,raw.get('nbr_rolling_guidance') or _blank(NBRRollingGuidance),NBRRollingGuidance,'nbr_rolling_guidance') if enabled else None
            st.caption('A fonte da geometria documenta a topologia informada. A fonte da referência registra uma adoção de cálculo: máximo conservador das reações verticais estáticas/de serviço, incluindo a inércia selecionada. Sem estes dados, os critérios NBR dependentes de rolamento permanecem não executados; não se assume λ = 0.')
        for name,cls,label in [('stability',StabilityPremises,'Estabilidade complementar EN C.2'),('fatigue',ENPhysicalFatigueInputs,'Fadiga nominal complementar EN')]:
            enabled=st.checkbox('Avaliar '+label,value=raw[name] is not None,key='tu_input:enabled:'+name)
            raw[name]=_edit_group(st,raw[name] or _blank(cls),cls,name) if enabled else None
        try:
            from .service import CMAAServicePremises
            enabled=st.checkbox('Avaliar serviço CMAA implementado',value=raw['service'] is not None,key='tu_input:enabled:service')
            raw['service']=_edit_group(st,raw['service'] or _blank(CMAAServicePremises),CMAAServicePremises,'service') if enabled else None
        except ImportError:st.warning('Módulo de serviço CMAA ainda indisponível nesta cópia; permanecerá pendente.')
        from .native_service import NBR10084ServicePremises,ManualServiceLimits
        with st.expander('Serviço NBR 10084 e limites adicionais de projeto'):
            st.caption('NBR mede o incremento no topo real do trilho desde o peso próprio do mesmo modelo, sem impacto nem majoração. Inclui os pares normais de ações HX, HY e Rλ sob a topologia de rolamento declarada. CMAA mantém ações e referência próprias. Os limites adicionais só podem restringir os critérios nativos, nunca relaxá-los ou substituir uma base ausente.')
            enabled=st.checkbox('Avaliar serviço NBR 10084 independente',value=raw.get('nbr_service') is not None,key='tu_input:enabled:nbr_service')
            raw['nbr_service']=_edit_group(st,raw.get('nbr_service') or _blank(NBR10084ServicePremises),NBR10084ServicePremises,'nbr_service') if enabled else None
            enabled=st.checkbox('Aplicar limites adicionais de flecha de projeto',value=raw.get('manual_service') is not None,key='tu_input:enabled:manual_service')
            raw['manual_service']=_edit_group(st,raw.get('manual_service') or _blank(ManualServiceLimits),ManualServiceLimits,'manual_service') if enabled else None
    with tabs[2]:
        with st.expander('Detalhe TOP · pares intermediários opcionais',expanded=True):
            intermediate_valid=_render_intermediate_editor(st,raw)
    st.session_state['tu_raw']=deepcopy(raw);st.session_state['tu_metadata']=dict(metadata)
    project=None;validation=st.session_state.get(INTERMEDIATE_PREFIX+'_editor_error','Revise as entradas do detalhe intermediário.')
    if intermediate_valid:
        try:project=project_from_dict(raw)
        except (ValueError,TypeError,KeyError) as exc:validation=str(exc)
    with tabs[4]:
        if project is None:st.warning('Complete os dados e fontes antes de calcular: '+validation)
        else:
            st.download_button('Salvar entradas físicas JSON',json.dumps(project_document(project,metadata),ensure_ascii=False,indent=2),file_name='rolamento_top_entradas.json',mime='application/json')
        if st.button('Calcular todas as configurações',disabled=project is None,type='primary'):
            _clear_result(st)
            bar=st.progress(0.,text='Gerando ações e casos internos')
            try:st.session_state['tu_result']=analyze_project(project,progress=lambda n,total,label:bar.progress(n/total,text=f'{label}: {n}/{total}'))
            except (ValueError,TypeError,ImportError) as exc:st.error('Cálculo interrompido sem resultado utilizável: '+str(exc))
            bar.empty()
        result=st.session_state.get('tu_result') if project is not None else None
        if result is not None and project is not None:
            try:assert_current_result(project,result)
            except ValueError as exc:st.warning(str(exc));result=None
        if result is not None:
            member_status=result['assessed_member_scope_status']
            message='Escopo de viga avaliado: '+STATUS_LABELS.get(member_status,member_status)+'.'
            (st.success if member_status=='SATISFIED' else st.error if member_status=='FAIL' else st.warning)(message)
            st.caption('A conclusão acima é limitada aos critérios do membro avaliados. Rodas, mecanismos, ligações e edifício são escopos externos opcionais, sem bloquear por si só a viga. Permanecem essenciais a validade física do modelo, dos apoios e das ações aplicáveis.')
            st.caption('Ligação viga–piso e demais ligações de apoio: fora do escopo, não verificadas. Os vínculos adotados continuam sendo requisitos físicos do projeto.')
            st.dataframe([dict(Escopo=v['label'],Situação=scope_status(k,v),Verificações=v['checks_count']) for k,v in result['scopes'].items()],hide_index=True,use_container_width=True)
            st.dataframe(governing_check_rows(result),hide_index=True,use_container_width=True)
            for scope_id,scope in result['scopes'].items():
                if scope['pending']:
                    separate=scope_id in ('rail_contact','support_connections','receiving_structure')
                    with st.expander(scope['label']+(' · fora do escopo' if separate else ' · pendências')):
                        st.write('Verificação separada, não executada por esta avaliação da viga.' if separate and not scope.get('actual_failure_proven') else '\n'.join(scope['pending']))
            key=report_cache_key(result,metadata)
            partial_report=report_is_partial(result)
            st.caption('A memória Word pode ser baixada mesmo com critérios não atendidos ou inconclusivos. '+report_execution_note(result))
            if st.button('Preparar memória Word'):
                st.session_state.pop('tu_word',None);st.session_state.pop('tu_word_key',None)
                try:
                    st.session_state['tu_word']=build_report_docx(project,result,metadata);st.session_state['tu_word_key']=key
                except (ValueError,TypeError,OSError) as exc:st.error('Memória Word não gerada: '+str(exc))
            if st.session_state.get('tu_word_key')==key:st.download_button('Baixar relatório parcial Word' if partial_report else 'Baixar memória Word',st.session_state['tu_word'],file_name='rolamento_top_parcial.docx' if partial_report else 'rolamento_top.docx',mime='application/vnd.openxmlformats-officedocument.wordprocessingml.document')
            with st.expander('Avançado · evidência técnica completa'):
                st.caption('Para guardar ou reabrir o estudo, use o JSON leve de entradas físicas. A evidência técnica completa inclui todos os casos e pode ser grande; só será gerada quando solicitada, em JSON comprimido. Não é necessária para a memória Word.')
                technical_key=technical_export_cache_key(result,metadata)
                if st.session_state.get('tu_technical_key')!=technical_key:
                    st.session_state.pop('tu_technical_gzip',None);st.session_state.pop('tu_technical_key',None)
                if st.button('Preparar evidência técnica comprimida',key='tu_prepare_technical_export'):
                    st.session_state.pop('tu_technical_gzip',None);st.session_state.pop('tu_technical_key',None)
                    try:
                        with st.spinner('Preparando evidência técnica completa…'):
                            data=build_technical_export_gzip(project,result,metadata)
                        st.session_state['tu_technical_gzip']=data;st.session_state['tu_technical_key']=technical_key
                    except (ValueError,TypeError,OSError) as exc:st.error('Evidência técnica não gerada: '+str(exc))
                if st.session_state.get('tu_technical_key')==technical_key:
                    st.download_button('Baixar evidência técnica JSON comprimida',st.session_state['tu_technical_gzip'],file_name='rolamento_top_calculo.json.gz',mime='application/gzip')
        st.subheader('Comparar perfis da mesma família')
        family=st.multiselect('Perfis a calcular, mantendo a ponte e o restante das entradas',profile_names(),key='tu_family_selection')
        st.caption('A troca de perfil é registrada como requisito de projeto. Resultados permanecem separados por perfil; nenhuma seleção automática equivale a aprovação.')
        if st.button('Calcular família selecionada',disabled=project is None or not family):
            bar=st.progress(0.)
            try:st.session_state['tu_family']=analyze_profile_family(project,family,progress=lambda n,total,label:bar.progress(n/total,text=label))
            except (ValueError,TypeError,ImportError) as exc:st.error(str(exc))
            bar.empty()
        family_result=st.session_state.get('tu_family')
        if family_result:
            valid=[]
            for item in family_result:
                try:
                    candidate=replace_catalog_profile(project,item['catalog_id']) if project else None
                    if candidate is None:raise ValueError('Invalid inputs')
                    assert_current_result(candidate,item['result']);valid.append(item)
                except ValueError:pass
            if len(valid)!=len(family_result):st.warning('Comparação de perfis desatualizada. Recalcule com as entradas atuais.')
            else:st.dataframe([dict(Perfil=i['catalog_id'],Resultado=STATUS_LABELS[i['result']['assessed_member_scope_status']],Casos=i['result']['generated_case_count']) for i in valid],hide_index=True)

if __name__=='__main__':run()
