"""Supplementary EN2025 fatigue of the explicitly adopted rolled nominal model.

Not an NBR fatigue equivalence, local sigmaT field or physical 3-D enclosure.
All-position component boxes deliberately lose favourable correlations. They
remain bounds at EVERY fixed ordinary material point; no cycle count is made up.
"""
from dataclasses import dataclass, asdict
from math import isfinite, sqrt
from .mechanics import PreparedCase


def _real(v, name, minimum=0.):
    if isinstance(v,bool) or not isinstance(v,(int,float)) or abs(v)>1e100 or not isfinite(v) or v<minimum:
        raise ValueError(name+' outside finite nonnegative domain')
    return float(v)


# Shared mechanics bounds remain re-exported for API compatibility.
from .bounds import plane_absolute_bounds, prepared_absolute_bounds, prepared_support_compression_bounds


def _local_pressure_geometry(p):
    s=p.section;r=p.rail
    if r.offset_from_web_mm!=0:raise ValueError('NBR compression spread requires rail physically centered over web')
    if r.local_attachment!='non_rigid' or r.continuity!='continuous_no_joint':raise ValueError('Continuous non-rigid rail model required')
    for name,value in (('web thickness',s.tw_mm),('flange thickness',s.tf_mm),
                       ('flange width',s.bf_mm),('rail width',r.width_mm),('rail height',r.height_mm)):
        _real(value,name,1e-12)
    _real(r.inertia_cm4,'rail inertia')
    bef=min(r.width_mm+r.height_mm+s.tf_mm,s.bf_mm)
    spread=_real((r.inertia_cm4*10000+bef*s.tf_mm**3/12)/s.tw_mm,'pressure dispersion quantity',1e-12)
    lef=_real(3.25*spread**(1/3),'wheel effective length',1e-12)
    ln=_real(p.support_bearing_length_mm,'bearing length',1e-12)
    for a in (p.beam_end_left_mm,p.beam_end_right_mm):
        _real(a,'physical projection length')
        if a<max(lef,ln)/2:raise ValueError('Complete wheel/support base footprints at travel endpoints need physical unloaded projections')
    _real(lef*s.tw_mm,'wheel pressure area',1e-12)
    _real(ln*s.tw_mm,'support pressure area',1e-12)
    return lef,ln


def _local_pressure_result(p,lef,ln,wheel,support,**extra):
    wheel=_real(wheel,'wheel compression bound');support=_real(support,'support compression bound')
    C=_real(wheel+support,'combined compression bound')
    return dict(transverse_compression_mpa=C,wheel_local_shear_mpa=.2*wheel,
                wheel_compression_mpa=wheel,support_compression_mpa=support,
                lef_mm=lef,bearing_length_mm=ln,
                source='NBR10084 prescribed top wheel/support pressure dispersion and wheel local shear; triangle sum without favourable spreading/relief',
                all_base_footprints_complete=True,local_sigmaT_calculated=False,
                all_wheel_contributions_summed=True,spatial_max_only_replacement=False,
                physical_full_3d_tensor_claim=False,**extra)


def local_compression_bounds(p, *, maximum_wheel_forces_kn, support_reaction_abs_kn):
    """LEGACY conservative sum of caller-provided absolute effort bounds.

    Retained for compatibility, NOT a verified PreparedCase receipt and never
    used by the EN/NBR prepared consumers. All wheel and support contributions
    are summed independently without favourable relief/end truncation.
    """
    lef,ln=_local_pressure_geometry(p);tw=p.section.tw_mm
    wheel=sum(_real(v,'peak wheel compression') for v in maximum_wheel_forces_kn)*1000/(lef*tw)
    support=sum(_real(v,'support reaction bound') for v in support_reaction_abs_kn)*1000/(ln*tw)
    return _local_pressure_result(p,lef,ln,wheel,support,
        bound_route='legacy_independent_absolute_support_sum',
        externally_supplied_support_bounds_unverified=True,prepared_case_receipt=None)


def prepared_local_compression_bounds(c):
    """Generate the joint-support receipt internally from a PreparedCase.

    No user scalar/receipt is accepted as proof. Keep the unchanged triangle
    sum of EVERY wheel, plus the joint support supremum (not max of wheel and
    support regions). Uplift is retained in the signed reaction receipt and
    requires its separate contact check; a negative reaction is not pressure.
    """
    if not isinstance(c,PreparedCase):raise ValueError('Internally prepared mechanical case required')
    lef,ln=_local_pressure_geometry(c.project);tw=c.project.section.tw_mm
    wheel=sum(_real(w.vertical_kn,'peak wheel compression') for w in c.source_wheels)*1000/(lef*tw)
    support=prepared_support_compression_bounds(c)
    return _local_pressure_result(c.project,lef,ln,wheel,support['transverse_compression_mpa'],
        bound_route='prepared_coexistent_positive_support_supremum',
        externally_supplied_support_bounds_unverified=False,prepared_case_receipt=support)

from underslung_runway_candidate.fatigue.autonomous_adapter import ENPhysicalFatigueInputs,gravity_minima
from underslung_runway_candidate.fatigue.en2025 import EN2025Inputs,evaluate
from .actions import generate_top_action_domain,combined_top_case,prepare_top_physical_case
from itertools import product


def _source_receipt():
    from pathlib import Path
    import hashlib,json
    root=Path(__file__).resolve().parents[1]
    files=[Path(__file__),Path(__file__).with_name('actions.py'),Path(__file__).with_name('mechanics.py')]
    bounds=Path(__file__).with_name('bounds.py')
    if bounds.exists():files.append(bounds)
    import lro_beams
    lro_root=Path(lro_beams.__file__).resolve().parent
    files+=list(lro_root.glob('*.py'))
    files.extend((Path(__file__).with_name('nominal_forces.py'),))
    files += [root/'underslung_runway_candidate'/f for f in ('fatigue/en2025.py','fatigue/tensor_bounds.py','fatigue/autonomous_adapter.py','autonomous_workflow/model.py','bridge_inertia/statics.py')]
    def label(p):
        try:return 'lro_beams/'+str(p.relative_to(lro_root))
        except ValueError:return str(p.relative_to(root))
    hashes={label(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(set(files))}
    return dict(sha256=hashlib.sha256(json.dumps(hashes,sort_keys=True).encode()).hexdigest(),files=hashes)


def evaluate_top_fatigue(basis, bridge_inputs, physical: ENPhysicalFatigueInputs):
    """Autonomous physical inputs -> all-state supplementary nominal cutoff.

    Reuses the physical material/environment/action adoption schema, NOT the
    bottom flange mechanics. Code derives every numerical qualification flag.
    All normal characteristic operating extrema also conservatively contain
    frequent effects. Exceptional collisions/tests are separately classified;
    this does not invent their fatigue frequency or claim whole-design closure.
    """
    source_start=_source_receipt()
    physical.validate();p=basis.validated_project();minimum=gravity_minima(physical)
    domain=generate_top_action_domain(basis,bridge_inputs)
    from underslung_runway_candidate.bridge_inertia.statics import suspended_mass_accounting
    mass_accounting=suspended_mass_accounting(bridge_inputs)
    if not mass_accounting['complete_suspended_mass_accounting']:
        return dict(status='PHYSICAL_MASS_ACCOUNTING_PENDING',qualified_nominal_detail_modes=False,whole_design_complete=False,
            suspended_mass_accounting=mass_accounting,reason='Declare retained suspended mass B, including explicit zero, and its application point; no legacy empty-state assumption')
    s=p.section;epsilon=sqrt(235/p.material.fy_mpa)
    if (s.bf_mm-s.tw_mm)/(2*s.tf_mm)>14*epsilon or (s.d_mm-2*s.tf_mm-2*s.root_radius_mm)/s.tw_mm>38*epsilon:
        raise ValueError('Conservative ordinary class1-3 uniform-compression geometry guard not satisfied')
    source=physical.action_source+'; EN13001-2 4.2.2.5 rigid drive reversal bound5 from |Si|,|Sf|<=Smax and phi5<=3; complete vectors scaled once; normal known-maxima domain'
    cases=[];peak=dict(sx=0.,txy=0.,txz=0.,compression=0.,local_shear=0.)
    for record in domain['records']:
        for loaded in (False,True):
            qfactors=sorted(set((minimum['lifted'],physical.dynamic_lifted))) if loaded else (0.,)
            for gf,qf,bf,hx,hy,rail in product(sorted(set((minimum['equipment'],physical.dynamic_equipment))),qfactors,sorted(set((minimum['lifted'],physical.dynamic_lifted))),(-5.,5.),(-5.,5.),(0,1)):
                name=f"EN2025/{record['id']}/{loaded}/{gf}/{qf}/B{bf}/{hx}/{hy}/rail{rail}"
                case=combined_top_case(record,equipment_factor=gf,lifted_factor=qf,hx_factor=hx,hy_factor=hy,loaded=loaded,rail_index=rail,case_name=name,source=source,retained_lifted_factor=bf)
                if not case['contact_valid']:
                    return dict(status='CONTACT_DOMAIN_SUFFICIENT_GUARD_INCONCLUSIVE',qualified_nominal_detail_modes=False,
                        reason='Independent factor extremes do not prove nonnegative contact; this is not observed actual lift-off',case=case,whole_design_complete=False)
                c=prepare_top_physical_case(basis,case)
                mechanical=prepared_absolute_bounds(c)
                local=prepared_local_compression_bounds(c)
                peak['sx']=max(peak['sx'],mechanical['sx_abs_mpa'])
                peak['txy']=max(peak['txy'],mechanical['txy_abs_mpa'])
                peak['txz']=max(peak['txz'],mechanical['txz_abs_mpa'])
                peak['compression']=max(peak['compression'],local['transverse_compression_mpa'])
                peak['local_shear']=max(peak['local_shear'],local['wheel_local_shear_mpa'])
                cases.append(dict(name=name,factors=case['factors'],mechanical=mechanical,local=local,contact_valid=True))
    box=dict(sx=(-peak['sx'],peak['sx']),sy=(0.,0.),sz=(-peak['compression'],0.),
             txy=(-peak['txy'],peak['txy']),txz=(-peak['txz']-peak['local_shear'],peak['txz']+peak['local_shear']),tyz=(0.,0.))
    receipt='Analytical all-position point-force/couple influence bounds + all physical multiaffine endpoint/action vertices; no sampled maxima or external efforts'
    assessment=evaluate(EN2025Inputs(box,box,box,p.material.fy_mpa,physical.gamma_ff,physical.gamma_mf,physical.gamma_mser,
        'Every ordinary plain region within supplementary CISC/NBR pressure nominal model',source,receipt,
        True,True,True,True,True,True,True,True))
    source_end=_source_receipt()
    if source_end['sha256']!=source_start['sha256']:
        return dict(status='SOURCE_CHANGED_DURING_ASSESSMENT',qualified_nominal_detail_modes=False,source_start=source_start,source_end=source_end,whole_design_complete=False)
    return dict(**assessment,source_receipt=source_end,physical_inputs=asdict(physical),action_domain=domain,suspended_mass_accounting=mass_accounting,case_receipts=cases,tensor_box_mpa=box,
        local_sigmaT_calculated=False,physical_full_3d_tensor_claim=False,duplicate_vlasov_b=False,
        model_composition='CISC ordinary rolled flange-flexure analogy longitudinal stress and nominal beam shear + NBR wheel/support transverse compression and prescribed wheel shear; no separately calculated local web-bending normal sigmaT in this alternative nominal model. Absent terms are model definitions, NOT measured physical zeros.',
        assessed_regions=['Ordinary unmodified rolled plain flange/web regions'],
        excluded_regions=['Holes/net sections, rail fasteners, welded attachments, disturbed support/connection zones, contact/rolling-contact fatigue'],
        action_scope='Declared normal gravity/horizontal-drive operating domain; complete-domain exceptional/event fatigue applicability remains separate',
        whole_design_complete=False,external_efforts_required=False,physical_stiffeners='absent')
