"""Explicit CMAA physical action premises, separate from fatigue classification.

No force, stress, dynamic factor or result flag is accepted. The common bridge
ledger supplies payload, retained block, mass locations and accelerations.
"""
from dataclasses import dataclass
from math import isfinite
from underslung_runway_candidate.autonomous_workflow.model import checked_text

@dataclass(frozen=True)
class CMAAActionPremises:
    bridge_travel_speed_m_s: float
    trolley_travel_speed_m_s: float
    hoist_speed_m_s: float
    operating_environment: str
    load_engagement: str
    crane_configuration: str
    physical_source: str

    def validate(self):
        for name in ('bridge_travel_speed_m_s','trolley_travel_speed_m_s','hoist_speed_m_s'):
            value=getattr(self,name)
            if type(value) not in (int,float) or not isfinite(value) or value<0:
                raise ValueError('Velocidade física CMAA deve ser finita e não negativa: '+name)
        if self.operating_environment!='indoor_no_operating_wind':
            raise ValueError('O domínio CMAA atual exige operação interna sem vento operacional.')
        if self.load_engagement!='normal_non_abrupt':
            raise ValueError('O domínio CMAA atual exige engate normal, não brusco.')
        if self.crane_configuration not in ('single_girder_under_running_trolley','not_established_adopted_nominal_method'):
            raise ValueError('Identificar a configuração ou adoção explícita do método nominal CMAA.')
        checked_text(self.physical_source,'Fonte das ações físicas e adoção CMAA')
        return self

    def physical(self,bridge):
        self.validate()
        from underslung_runway_candidate.cmaa74.actions import CMAA74PhysicalInputs
        from underslung_runway_candidate.bridge_inertia.statics import suspended_mass_accounting
        mass=suspended_mass_accounting(bridge)
        if not mass['complete_suspended_mass_accounting']:
            raise ValueError('Ações CMAA exigem carga útil e massa suspensa retida explicitamente separadas.')
        return CMAA74PhysicalInputs(self.bridge_travel_speed_m_s,self.trolley_travel_speed_m_s,self.hoist_speed_m_s,
            self.operating_environment,self.load_engagement,'payload_plus_retained_common_ledger',self.crane_configuration,
            self.physical_source+'; composição comum das massas: '+bridge.suspended_mass_source,
            bridge.retained_suspended_mass_kg,bridge.retained_suspended_cg_x_mm,bridge.retained_suspended_cg_z_mm).validate()
