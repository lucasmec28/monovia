"""NBR 8400-2 D.5 consumer for separately identified TOP nominal wall planes.

The bridge/action producer remains separate. This module consumes only an
internally prepared Case-I fatigue case, uses the existing analytical bounds,
and never relabels an EN/ULS envelope. It does not run a moving scan or invent a
history. Three wall planes are kept separate, rather than passing a fabricated
3-D box or a whole-section shear magnitude to a planar fatigue equation.

The adopted supplementary wall model is CISC two-flange longitudinal flexure,
wall-specific nominal shear, and NBR prescribed web pressure/shear. It is not a
3-D local tensor. NBR10084 sigmaT is local WEB-bending normal stress in
the xz plane, not a removable out-of-plane component. Literal NBR recovery
remains unresolved. An explicitly selected, previously adopted CISC alternative
may instead be assessed in its own documented nominal model. The adoption and remaining scope must stay visible in the calling design workflow.
"""
from dataclasses import asdict
from math import isfinite

from underslung_runway_candidate.fatigue.nbr_member import (
    ACTION_BASIS, NBRFatigueMaterial, NBRNominalPlane, evaluate_nbr_member_plane,
)
from .mechanics import PreparedCase, BASIS_ID
from .bounds import prepared_absolute_bounds
from .fatigue import prepared_local_compression_bounds
from underslung_runway_candidate.autonomous_workflow.nbr_rolling import (
    NBRRollingGuidance, four_contact_rolling_bound, horizontal_pairs, rolling_source_receipt,
)

WALL_MODEL = 'CISC_ordinary_rolled_flange_analogy_plus_NBR_web_pressure_nominal_wall_planes'
ADOPTED_ALTERNATIVE_SCOPE = 'adopted_CISC_alternative_nominal_model'
LITERAL_NBR_SCOPE = 'literal_NBR10084_local_web_model'
ROUTE_CONTRACT_SHA256 = 'c6fae43aefe9ca6e3bee6f1239004b4f5a61f1f05f9ab32150afd07e48aecc1a'


def _text(value, name):
    if not isinstance(value, str) or not value.strip():
        raise ValueError(name+' requires an explicit source/adoption record')


def top_case_nominal_planes(prepared_case, *, action_basis, action_source,
                           factors_source, nominal_wall_model_source, method_scope=LITERAL_NBR_SCOPE):
    """Analytical all-position bounds in each adopted ordinary wall plane.

    Case factors/dynamics must already have been generated exactly once by the
    upstream physical action ledger. This low-level helper cannot authenticate
    a caller's assertion that an arbitrary prepared case has the correct action
    basis, and therefore never establishes whole-member qualification itself.
    """
    if not isinstance(prepared_case, PreparedCase):
        raise ValueError('Internally prepared top mechanical case required')
    if action_basis != ACTION_BASIS:
        raise ValueError('Separate NBR Case-I fatigue actions required; EN/CMAA/ULS actions are not relabeled')
    for name, value in (('action_source', action_source), ('factors_source', factors_source),
                        ('nominal_wall_model_source', nominal_wall_model_source)):
        _text(value, name)
    c = prepared_case
    if method_scope not in (LITERAL_NBR_SCOPE, ADOPTED_ALTERNATIVE_SCOPE):
        raise ValueError('Explicit literal NBR or documented adopted CISC alternative method scope required')
    alternative = method_scope == ADOPTED_ALTERNATIVE_SCOPE
    c.basis.validated_project()
    if c.basis.nominal_basis != BASIS_ID:
        raise ValueError('Alternative must inherit the exact validated CISC ordinary-rolled basis')
    if c.basis.premise_status not in ('adopted', 'confirmed'):
        raise ValueError('A reference-only flange analogy is not an adopted nominal fatigue model')
    p, s, properties = c.project, c.project.section, c.properties
    bounds = prepared_absolute_bounds(c)
    local = prepared_local_compression_bounds(c)
    sx = bounds['sx_abs_mpa']
    compression = local['transverse_compression_mpa']
    # Longitudinal equilibrium: at a flange outstand tau_xy,Vz equals
    # Vz*z*(bf/2-|y|)/Ix in the thin-wall nominal major-bending field.
    # |z|<=d/2 and (bf/2-|y|)<=bf/2 give the displayed independent bound.
    # Keeping it is essential: web tau_xz is not all the vertical shear flow.
    flange_major_shear = bounds['major']['shear_abs_kn']*1000*s.d_mm*s.bf_mm/(4*properties.Ix_mm4)
    flange_lateral = {
        wall: 1.5*bounds[wall]['shear_abs_kn']*1000/(s.bf_mm*s.tf_mm)
        for wall in ('top', 'bottom')}
    flange_shear = {wall: flange_major_shear+flange_lateral[wall] for wall in ('top', 'bottom')}
    web_shear = bounds['txz_abs_mpa']+local['wheel_local_shear_mpa']
    if not all(isfinite(v) and v >= 0. for v in (sx, compression, flange_major_shear, web_shear, *flange_shear.values())):
        raise ValueError('Nonfinite derived nominal wall bound')
    provenance = bounds['proof']+'; '+local['source']
    planes, wall_receipts = [], []
    for wall in ('top', 'bottom', 'web'):
        web = wall == 'web'
        tensor = dict(sx=(-sx, sx), sy=(0., 0.), sz=((-compression, 0.) if alternative else None) if web else (0., 0.),
            txy=(0., 0.) if web else (-flange_shear[wall], flange_shear[wall]),
            txz=(-web_shear, web_shear) if web else (0., 0.), tyz=(0., 0.))
        plane_source = (
            'Ordinary nominal web xz plane: longitudinal flexure/axial, known NBR wheel/support pressure and vertical/local shear. REQUIRED local web-bending sigmaT is unresolved; sigma_cz=sigma_0z+0.75sigmaT is therefore not supplied. Flange xy shear is a different wall.'
            if web else
            'Adopted ordinary nominal flange xy model: CISC longitudinal flange-flexure analogy and in-plane shear from BOTH lateral flange flexure and major-bending longitudinal equilibrium. Other nominal tensor terms follow this wall model, not a physical 3-D zero assertion.')
        if web and alternative:
            plane_source = ('Documented adopted CISC ordinary-rolled alternative nominal model, bound to TopUnstiffenedBasis and its adoption source. NBR prescribed web pressure is the transverse-normal term of THIS model; this is neither sigmaT=0 nor full literal NBR10084 sigma_cz recovery. No source equivalence or 3-D bound is asserted.')
        planes.append(NBRNominalPlane(region_id=wall+'_ordinary_nominal_wall',
            point_id=wall+'_uniform_fixed_material_point_bound', face='both_nominal_wall_faces',
            plane='xz' if web else 'xy', tensor_intervals_mpa=tensor,
            action_basis=action_basis, action_source=action_source, factors_source=factors_source,
            bounds_source=provenance, nominal_model_source=nominal_wall_model_source+'; '+WALL_MODEL,
            plane_source=plane_source,
            same_point_scope='Uniform signed box covers every fixed ordinary point of the named nominal '+wall+' wall over the complete analytical travel domain; component extrema need not coexist'))
        wall_receipts.append(dict(wall=wall, plane='xz' if web else 'xy',
            physical_thickness_mm=s.tw_mm if web else s.tf_mm,
            normal_longitudinal_abs_mpa=sx,
            transverse_compression_abs_mpa=compression if web else 0.,
            shear_abs_mpa=web_shear if web else flange_shear[wall],
            lateral_flange_shear_abs_mpa=None if web else flange_lateral[wall],
            major_bending_flange_shear_abs_mpa=None if web else flange_major_shear,
            same_plane_global_and_local_composed=not web or alternative, physical_tensor_zero_claimed=False,
            local_web_bending_sigmaT_covered=False if web else None,
            known_web_pressure_only_interval_mpa=(-compression, 0.) if web else None))
    return dict(planes=tuple(planes), wall_receipts=wall_receipts,
        mechanical_bounds=bounds, local_pressure_bounds=local,
        action_basis=action_basis, case_factors=asdict(c.factors), model=WALL_MODEL,
        nominal_wall_model_source=nominal_wall_model_source,
        wall_shear_separation=True, whole_section_shear_magnitude_used_as_planar_tau=False,
        local_web_bending_sigmaT_calculated=False, physical_3d_tensor_complete=False,
        duplicate_vlasov_b=False, temporal_histories_created=0, sampled_maxima_used=False,
        whole_member_qualified=False, physical_stiffeners='absent',
        excluded_regions=['Actual rolled-root/contact stress concentration',
                          'Rail/fasteners, holes, welded attachments, connections and disturbed load-introduction regions'],
        method_scope=method_scope, alternative_nominal_model_used=alternative,
        literal_NBR10084_sigma_cz_covered=False,
        adopted_basis_provenance=c.basis.provenance(),
        documented_route_contract_sha256=ROUTE_CONTRACT_SHA256,
        scope=('Documented adopted CISC ordinary-rolled alternative plus NBR nominal web pressure; D.5 result applies only to this alternative nominal model, not literal NBR10084 sigma_cz or a physical local field' if alternative else
               'Ordinary CISC flange nominal model only can qualify; literal NBR web fatigue pending required local web-bending sigmaT. No 3-D contact or fillet field is claimed'),
        pending_member_effects=[] if alternative else ['NBR10084 9.1.3.3–9.1.3.4 local web-bending sigmaT and normative eccentricity; web normal sigma_cz=sigma_0z+0.75sigmaT unresolved'])


def evaluate_top_nbr_case(prepared_case, *, flange_material, web_material, duty,
                          detail, method, action_basis, action_source,
                          factors_source, nominal_wall_model_source, method_scope=LITERAL_NBR_SCOPE):
    """Evaluate all three ordinary nominal planes, not the entire design route."""
    result = dict(kind='top_unstiffened_NBR8400_nominal_wall_fatigue', status='APPLICABILITY_PENDING',
        qualified_nominal_detail_modes=False, actual_failure_proven=False,
        whole_member_qualified=False, whole_design_complete=False,
        point_results=[], pending=[], external_efforts_required=False,
        wheels_mechanisms_building_in_scope=False, contact_fatigue_in_scope=False)
    try:
        produced = top_case_nominal_planes(prepared_case, action_basis=action_basis,
            action_source=action_source, factors_source=factors_source,
            nominal_wall_model_source=nominal_wall_model_source, method_scope=method_scope)
        for key, material, expected in (
            ('flange', flange_material, prepared_case.project.section.tf_mm),
            ('web', web_material, prepared_case.project.section.tw_mm)):
            if not isinstance(material, NBRFatigueMaterial) or material.thickness_mm != expected:
                raise ValueError(key+' material must identify the actual physical thickness; no flange/web substitution')
        rows = [evaluate_nbr_member_plane(plane,
            material=web_material if plane.plane == 'xz' else flange_material,
            duty=duty, detail=detail, method=method) for plane in produced['planes']]
        passed = all(row['sufficient_planar_bound_satisfied'] for row in rows)
        result['domain_pending'] = sorted({message for row in rows for message in (*row.get('pending', []), *row.get('errors', []))})
        if method_scope == LITERAL_NBR_SCOPE:
            result['domain_pending'].append('Literal NBR10084 local web-bending sigmaT/sigma_cz is unresolved; select only an already adopted alternative method when applicable')
        result['pending'].extend(result['domain_pending'])
        applicability = any(row['status'] in ('APPLICABILITY_PENDING', 'INVALID_INPUT') for row in rows)
        result.update(plane_producer={k: v for k, v in produced.items() if k != 'planes'},
            point_results=rows, qualified_nominal_detail_modes=passed,
            status='SUFFICIENT_NOMINAL_WALL_FATIGUE_BOUNDS_SATISFIED' if passed else
                   'APPLICABILITY_PENDING' if applicability else 'INCONCLUSIVE_SUFFICIENT_FATIGUE_BOUND',
            scope=produced['scope'])
    except (ValueError, TypeError, KeyError, ArithmeticError) as exc:
        result['pending'].append(type(exc).__name__+': '+str(exc))
    return result


def top_nbr_source_receipt():
    """Independent consumer closure; no prior result is re-signed."""
    import hashlib
    from pathlib import Path
    from underslung_runway_candidate.autonomous_workflow.model import signature
    from underslung_runway_candidate.fatigue.nbr_member import nbr_consumer_source_receipt
    from .fatigue import _source_receipt
    payload = dict(top_mechanical_dependencies=_source_receipt(),
        nbr_consumer_dependencies=nbr_consumer_source_receipt(),
        top_nbr_consumer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        normal_rolling_dependencies=rolling_source_receipt(),
        adopted_route_contract_sha256=ROUTE_CONTRACT_SHA256)
    return dict(**payload, fingerprint=signature(payload))


def _nbr_action_vertex(base, pair, rolling_bound=None, rolling_signs=()):
    """Annotate a physical inertia case or a per-runway relaxed rolling vertex."""
    from copy import deepcopy
    from underslung_runway_candidate.autonomous_workflow.model import signature
    pair = tuple(pair)
    if pair not in horizontal_pairs():
        raise ValueError('Unqualified NBR horizontal-effect pair')
    if any(base['factors'][axis] != 0 for axis in ('HX', 'HY') if axis not in pair):
        raise ValueError('Inactive inertia event must not leak into a two-effect combination')
    case = deepcopy(base)
    case.update(base_physical_case=deepcopy(base), horizontal_pair=pair,
        rolling_reference=rolling_bound, rolling_signs=tuple(rolling_signs),
        relaxed_reaction_box_vertex=rolling_bound is not None,
        coexistent_operational_state_claimed=rolling_bound is None,
        whole_bridge_equilibrium_qualified=rolling_bound is None,
        action_extrema_are_temporal_histories=False)
    if 'Rlambda' in pair:
        if rolling_bound is None or len(rolling_signs) != 2 or any(type(v) is not int or v not in (-1, 1) for v in rolling_signs):
            raise ValueError('Two explicit signed rolling-box endpoint choices required')
        rows = sorted((r for r in rolling_bound['contacts'] if r['rail_index'] == base['rail_index']),
                      key=lambda r:r['position_mm'][0])
        addition = {r['id']: sign*r['Fy_interval_N'][1] for r, sign in zip(rows, rolling_signs)}
        for station in case['all_station_resultants']:
            station['force_N'][1] += addition.get(station['id'], 0.)
        case['stations'] = [s for s in case['all_station_resultants'] if s['rail_index'] == base['rail_index']]
        case['full_contact_receipt_scope'] = 'Base complete-inertia case only; added per-runway rolling vertex is a relaxed box, not a full-bridge equilibrium state'
        case['rolling_applied_force_N'] = {ident: (0., h, 0.) for ident, h in addition.items()}
    elif rolling_bound is not None or rolling_signs:
        raise ValueError('HX/HY must not also contain rolling as a third effect')
    case['nbr_vertex_signature'] = signature(case)
    return case


def generate_top_nbr_actions(basis, bridge_inputs, *, psi, horizontal_dynamic_factor,
                             horizontal_dynamic_source, rolling_guidance=None):
    """All three normal pairs, complete G/B/Q/inertia, plus honest Rlambda boxes.

    Reference maxima and independently signed rolling vertices are NOT physical
    operational states. Their analytic response bounds feed the explicit kappa
    = -1 sufficient D.5 inequality, never a synthesized cycle history.
    """
    from itertools import product
    from lro_beams.autonomous_actions import factors_10084
    from underslung_runway_candidate.bridge_inertia.statics import suspended_mass_accounting, real
    from .actions import generate_top_action_domain, combined_top_case, TopBridgeInputs
    if not isinstance(bridge_inputs, TopBridgeInputs):
        raise ValueError('Original physical TopBridgeInputs required')
    mass = suspended_mass_accounting(bridge_inputs)
    if not mass['complete_suspended_mass_accounting'] or not mass['retained_mass_explicit']:
        raise ValueError('Explicit common retained suspended B required, including a sourced zero; legacy empty-mass omission cannot qualify')
    hd = real(horizontal_dynamic_factor, 'NBR horizontal dynamic multiplier')
    if hd < 1.:
        raise ValueError('Sourced horizontal dynamics cannot reduce raw m*a effects')
    _text(horizontal_dynamic_source, 'horizontal dynamic source')
    if not isinstance(rolling_guidance, NBRRollingGuidance):
        raise ValueError('Explicit NBRRollingGuidance required for normal Case-I rolling reactions; missing guidance is not zero')
    factors = factors_10084('fatigue_8400', psi=psi)
    if factors.basis != ACTION_BASIS:
        raise ValueError('Source fatigue factors no longer match Case I without Mx')
    if basis.validated_project().rail.wheel_guidance != 'flanged':
        raise ValueError('Normal rolling four-contact domain requires actual wheel-flange guidance, not separate guide rollers')
    domain = generate_top_action_domain(basis, bridge_inputs)
    source = (factors.source+'; '+horizontal_dynamic_source+
        '; common G/retained B/removable Q and whole correlated inertia vectors; all three two-effect pairs HX/HY, HX/Rlambda, HY/Rlambda; '+
        'Rlambda is normal NBR8400-1 6.2.3.3, not CMAA SK or exceptional SHE; conservative static/service-plus-inertia reference and per-runway sign relaxation')
    cases, rolling_receipts = [], []
    for record in domain['records']:
        for loaded in (False, True):
            for pair in horizontal_pairs():
                active = tuple(axis for axis in ('HX', 'HY') if axis in pair)
                bound = None
                if 'Rlambda' in pair:
                    bound = four_contact_rolling_bound(record['generated'], psi=psi,
                        horizontal_dynamic_factor=hd, loaded=loaded, inertia_actions=active,
                        guidance=rolling_guidance)
                    rolling_receipts.append(dict(record_id=record['id'], horizontal_pair=pair, receipt=bound))
                for signs in product((-1, 1), repeat=len(active)):
                    mult = dict(HX=0., HY=0.)
                    mult.update({axis: sign*hd for axis, sign in zip(active, signs)})
                    for rail in (0, 1):
                        rsigns = tuple(product((-1, 1), repeat=2)) if bound else ((),)
                        for rs in rsigns:
                            name = f'NBR8400_FATIGUE/{record["id"]}/loaded{int(loaded)}/{"+".join(pair)}/HX{mult["HX"]:+g}/HY{mult["HY"]:+g}/rail{rail}/R{rs}'
                            base = combined_top_case(record, equipment_factor=factors.dead_equipment,
                                lifted_factor=factors.lifted, retained_lifted_factor=factors.lifted,
                                hx_factor=mult['HX']*factors.longitudinal, hy_factor=mult['HY']*factors.transverse,
                                loaded=loaded, rail_index=rail, case_name=name, source=source)
                            cases.append(_nbr_action_vertex(base, pair, bound, rs))
    return dict(action_basis=ACTION_BASIS, action_domain=domain, cases=cases,
        factors=asdict(factors), horizontal_dynamic_factor=hd,
        horizontal_dynamic_source=horizontal_dynamic_source,
        rolling_guidance=asdict(rolling_guidance), rolling_receipts=rolling_receipts,
        horizontal_pairs=horizontal_pairs(), normal_rolling_included=True,
        suspended_mass_accounting=mass, source=source,
        case_count=len(cases), Mx_applied=False, buckling_omega_applied=False,
        interpolation='Complete multiaffine hook/height/payload endpoints, both rails, all two-effect pairs and signs; rolling references use convex endpoint bounds; relaxed vertices are not physical histories',
        action_extrema_are_temporal_histories=False)


def prepare_top_nbr_action_case(basis, case, *, permanent_factor=1., extra_dead_factor=1.):
    """Reconstruct/authenticate the physical base AND relaxed rolling increment."""
    from copy import deepcopy
    from dataclasses import replace
    from underslung_runway_candidate.autonomous_workflow.model import signature
    from lro_beams.autonomous_model import WheelInput
    from lro_beams.autonomous_response import CaseFactors
    from .actions import (prepare_top_physical_case, generate_top_action_domain, TopBridgeInputs)
    from .mechanics import prepare_case
    base = case['base_physical_case']
    prepared = prepare_top_physical_case(basis, base,
        permanent_factor=permanent_factor, extra_dead_factor=extra_dead_factor)
    bound = case['rolling_reference']
    if bound is not None:
        record = next(r for r in generate_top_action_domain(basis, TopBridgeInputs(**base['physical_inputs']))['records']
                      if r['id'] == base['source_record'])
        fresh_bound = four_contact_rolling_bound(record['generated'], psi=base['factors']['lifted'],
            horizontal_dynamic_factor=bound['horizontal_dynamic_factor'], loaded=base['factors']['loaded'],
            inertia_actions=tuple(axis for axis in ('HX', 'HY') if axis in case['horizontal_pair']),
            guidance=NBRRollingGuidance(**bound['guidance']))
        if signature(fresh_bound) != signature(bound):
            raise ValueError('Stale/tampered rolling reference or source fingerprint')
        if any(abs(base['factors'][axis]) != bound['horizontal_dynamic_factor'] for axis in bound['inertia_actions']):
            raise ValueError('Rolling reference dynamics must match full selected inertia vectors')
    fresh = _nbr_action_vertex(base, case['horizontal_pair'], bound, case['rolling_signs'])
    if signature(fresh) != signature(case):
        raise ValueError('Stale/tampered NBR action vertex; regenerate from common physical inputs')
    if bound is None:
        return prepared
    p = deepcopy(basis.project)
    origin = min(s['position_mm'][0] for s in case['stations'])
    p.wheels = [WheelInput((s['position_mm'][0]-origin)/1000, -s['force_N'][2]/1000,
        0., s['force_N'][1]/1000, s['force_N'][0]/1000) for s in case['stations']]
    # The virtual vector is already factored. The linear structural operator
    # may evaluate a box vertex; no equilibrium or realizability claim follows.
    factors = CaseFactors(case['name'], permanent_factor, 1., 0., 1., 1.,
        case['source']+'; relaxed reaction-box vertex, not a physical state', extra_dead=extra_dead_factor)
    return prepare_case(replace(basis, project=p), factors)


def evaluate_top_nbr_fatigue(basis, bridge_inputs, physical, *, psi,
                             horizontal_dynamic_factor, horizontal_dynamic_source,
                             method_scope, rolling_guidance=None):
    """Autonomous physical inputs -> all-case top ordinary nominal NBR fatigue.

    The required method_scope prevents silently selecting the accepted CISC
    alternative or pretending literal NBR sigmaT recovery. Physical action
    vectors are regenerated under Case I without Mx, independent of ELU/CMAA/EN.
    Corresponding signed bounds are unioned only within each same wall/plane;
    they are not manufactured concurrent states or fatigue histories.
    """
    from dataclasses import replace
    from underslung_runway_candidate.autonomous_workflow.model import signature
    from underslung_runway_candidate.fatigue.nbr_member import NBRMemberFatigueInputs, COMPONENTS
    result = dict(kind='top_unstiffened_autonomous_NBR8400_nominal_member_fatigue',
        status='APPLICABILITY_PENDING', qualified_nominal_detail_modes=False,
        sufficient_nominal_member_fatigue_bounds_satisfied=False, point_results=[], pending=[],
        actual_failure_proven=False, whole_member_qualified=False, whole_design_complete=False,
        physical_unlimited_life_claim=False, calculated_cycles_to_failure=False,
        zero_damage_cutoff_used=False, external_efforts_required=False,
        physical_3d_tensor_complete=False, concurrent_tensor_claimed=False,
        wheels_mechanisms_building_in_scope=False, contact_fatigue_in_scope=False,
        repeated_FE_sweeps=0, method_scope=method_scope)
    try:
        if not isinstance(physical, NBRMemberFatigueInputs):
            raise ValueError('Explicit NBRMemberFatigueInputs required')
        _text(physical.nominal_model_source, 'nominal model adoption/source')
        p = basis.validated_project()
        for name, material, thickness in (('flange', physical.flange_material, p.section.tf_mm),
                                          ('web', physical.web_material, p.section.tw_mm)):
            if not isinstance(material, NBRFatigueMaterial) or material.thickness_mm != thickness:
                raise ValueError(name+' fatigue material must use the actual physical thickness')
            if material.fy_mpa != p.material.fy_mpa or material.fu_mpa != p.material.fu_mpa:
                raise ValueError(name+' fatigue material differs from the physical member material')
        before = signature(dict(basis=asdict(basis), bridge_inputs=asdict(bridge_inputs), physical=asdict(physical),
                                psi=psi, horizontal_dynamic_factor=horizontal_dynamic_factor,
                                horizontal_dynamic_source=horizontal_dynamic_source, method_scope=method_scope,
                                rolling_guidance=asdict(rolling_guidance) if isinstance(rolling_guidance, NBRRollingGuidance) else None))
        start = top_nbr_source_receipt()
        result['source_at_start'] = start
        generated = generate_top_nbr_actions(basis, bridge_inputs, psi=psi,
            horizontal_dynamic_factor=horizontal_dynamic_factor,
            horizontal_dynamic_source=horizontal_dynamic_source, rolling_guidance=rolling_guidance)
        result['suspended_mass_accounting'] = generated['suspended_mass_accounting']
        bad = [row for row in generated['cases'] if not row['contact_valid']]
        if bad:
            result.update(status='CONTACT_DOMAIN_SUFFICIENT_GUARD_INCONCLUSIVE',
                pending=['Generated physical endpoint contact domain does not establish nonnegative compression; not an inferred actual failure'],
                contact_case_ids=[row['name'] for row in bad])
            return result
        groups, case_receipts = {}, []
        factor_source = (generated['source']+'; Case-I permanent/equipment origins at 1, suspended B/payload at psi='+str(psi)+
                         '; inertia multiplier='+str(horizontal_dynamic_factor)+' applied to complete raw inertia vectors once; Rlambda=graph lambda times its already bounded vertical reference, no second psi/H factor; no Mx/omega')
        for case in generated['cases']:
            prepared = prepare_top_nbr_action_case(basis, case,
                permanent_factor=generated['factors']['dead_support'],
                extra_dead_factor=generated['factors']['extra_dead'])
            produced = top_case_nominal_planes(prepared, action_basis=ACTION_BASIS,
                action_source=generated['source'], factors_source=factor_source,
                nominal_wall_model_source=physical.nominal_model_source, method_scope=method_scope)
            for plane in produced['planes']:
                groups.setdefault(plane.region_id, []).append(plane)
            case_receipts.append(dict(case_id=case['name'], action_case_signature=signature(case),
                record_id=case['source_record'], rail_index=case['rail_index'], factors=case['factors'],
                horizontal_pair=case['horizontal_pair'], relaxed_reaction_box_vertex=case['relaxed_reaction_box_vertex'],
                rolling_reference=case['rolling_reference'], rolling_signs=case['rolling_signs'],
                whole_bridge_equilibrium_qualified=case['whole_bridge_equilibrium_qualified'],
                stations=case['stations'], all_station_resultants=case['all_station_resultants'],
                contact_valid=case['contact_valid'], wall_receipts=produced['wall_receipts'],
                mechanical_bounds=produced['mechanical_bounds'], local_pressure_bounds=produced['local_pressure_bounds']))
        pooled = []
        for region, planes in groups.items():
            first = planes[0]
            if any((row.plane, row.point_id, row.face) != (first.plane, first.point_id, first.face) for row in planes):
                raise ValueError('Cannot pool unlike point/face/material planes')
            tensor = {}
            for key in COMPONENTS:
                values = [row.tensor_intervals_mpa[key] for row in planes]
                tensor[key] = None if any(v is None for v in values) else (min(v[0] for v in values), max(v[1] for v in values))
            pooled.append(replace(first, tensor_intervals_mpa=tensor,
                bounds_source=first.bounds_source+'; union over all three two-effect pairs and source-domain endpoints, both rails, loaded/empty, complete inertia signs and relaxed normal-rolling vertices; no fabricated coexistent cycle',
                same_point_scope='Same ordinary nominal '+region+' in either runway design; every fixed point and all source-generated states. The signed union is a relaxation, not a concurrent tensor.'))
        rows = [evaluate_nbr_member_plane(plane,
            material=physical.web_material if plane.plane == 'xz' else physical.flange_material,
            duty=physical.duty, detail=physical.detail, method=physical.method) for plane in pooled]
        passed = all(row['sufficient_planar_bound_satisfied'] for row in rows)
        result['domain_pending'] = sorted({message for row in rows for message in (*row.get('pending', []), *row.get('errors', []))})
        if method_scope == LITERAL_NBR_SCOPE:
            result['domain_pending'].append('Literal NBR10084 local web-bending sigmaT/sigma_cz is unresolved; select only an already adopted alternative method when applicable')
        result['pending'].extend(result['domain_pending'])
        applicability = any(row['status'] in ('APPLICABILITY_PENDING', 'INVALID_INPUT') for row in rows)
        after = signature(dict(basis=asdict(basis), bridge_inputs=asdict(bridge_inputs), physical=asdict(physical),
                               psi=psi, horizontal_dynamic_factor=horizontal_dynamic_factor,
                               horizontal_dynamic_source=horizontal_dynamic_source, method_scope=method_scope,
                                rolling_guidance=asdict(rolling_guidance) if isinstance(rolling_guidance, NBRRollingGuidance) else None))
        if before != after:
            result['status'] = 'INPUT_CHANGED_DURING_ASSESSMENT'
            raise ValueError('Physical top inputs changed during NBR fatigue assessment')
        if start != top_nbr_source_receipt():
            result['status'] = 'SOURCE_CHANGED_DURING_ASSESSMENT'
            raise ValueError('Top numerical or NBR consumer source changed during assessment')
        binding = dict(input_signature=before, source_fingerprint=start['fingerprint'],
            physical_action_domain_signature=signature(generated['action_domain']),
            rolling_domain_signature=signature(generated['rolling_receipts']),
            rolling_guidance=generated['rolling_guidance'],
            action_case_signatures=[row['action_case_signature'] for row in case_receipts],
            method_scope=method_scope, adopted_basis_provenance=basis.provenance(),
            documented_route_contract_sha256=ROUTE_CONTRACT_SHA256)
        result.update(status='SUFFICIENT_NOMINAL_MEMBER_FATIGUE_BOUNDS_SATISFIED' if passed else
                            'APPLICABILITY_PENDING' if applicability else 'INCONCLUSIVE_SUFFICIENT_FATIGUE_BOUND',
            qualified_nominal_detail_modes=passed, sufficient_nominal_member_fatigue_bounds_satisfied=passed,
            point_results=rows, physical_inputs=asdict(physical), action_domain=generated['action_domain'],
            case_receipts=case_receipts, case_count=generated['case_count'], factors=generated['factors'],
            horizontal_pairs=generated['horizontal_pairs'], normal_rolling_included=True,
            rolling_guidance=generated['rolling_guidance'], rolling_receipts=generated['rolling_receipts'],
            temporal_histories_created=0,
            horizontal_dynamic_factor=horizontal_dynamic_factor, horizontal_dynamic_source=horizontal_dynamic_source,
            source_at_end=start, source_unchanged=True, consumer_binding=binding,
            alternative_nominal_model_used=method_scope == ADOPTED_ALTERNATIVE_SCOPE,
            literal_NBR10084_sigma_cz_covered=False, local_web_bending_sigmaT_calculated=False,
            assessment_scope='All ordinary nominal wall planes of the explicitly selected method, using all normal Case-I horizontal pairs and labeled per-runway rolling-reaction boxes; no actual physical 3-D/contact, holes or connection-region claim',
            member_only_scope=True, duplicate_vlasov_b=False)
    except (ValueError, TypeError, KeyError, ArithmeticError, AttributeError) as exc:
        result['pending'].append(type(exc).__name__+': '+str(exc))
    result['consumer_receipt_signature'] = signature(result)
    return result
