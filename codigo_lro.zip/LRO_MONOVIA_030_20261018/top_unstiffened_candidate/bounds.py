"""Sufficient all-position action bounds for the adopted flange analogy.

No scan or sampled maximum is relabeled as a proof. These are per-contribution
simple-support Green-function extrema plus triangle inequalities and actual
unloaded permanent-tail polynomials. No resistance/method qualification follows.

Moments/shears are kN*m and kN. The equivalent B is the generalized two-flange
resultant h/2*(Mtop-Mbottom), reported in N*mm² and kN*m². It is NOT an additional
Vlasov action to add back into flange stresses; using catalog Cw with it does not
reconstruct this analogy's already-computed stresses.
"""
from dataclasses import asdict
from fractions import Fraction
from hashlib import sha256
import json
from math import isfinite, nextafter, inf
from .mechanics import PreparedCase


def _signed(v,name):
    try:
        valid=not isinstance(v,bool) and isinstance(v,(int,float)) and abs(v)<=1e100 and isfinite(v)
    except (OverflowError,TypeError,ValueError):
        valid=False
    if not valid:raise ValueError(name+' must be finite numeric data within the supported range')
    return float(v)


def _real(v,name,minimum=0.):
    v=_signed(v,name)
    if v<minimum:raise ValueError(name+' outside nonnegative physical domain')
    return v


def _nominal_geometry(c):
    """Recheck the prepared copy as well as its adopted source geometry."""
    if not isinstance(c,PreparedCase):raise ValueError('Internally prepared mechanical case required')
    s=c.project.section;g=c.properties
    for name,v in (('depth',s.d_mm),('flange width',s.bf_mm),('web thickness',s.tw_mm),
                   ('flange thickness',s.tf_mm),('area',g.A_mm2),('major inertia',g.Ix_mm4)):
        _real(v,name,1e-12)
    for name,v in (('bottom flange width',s.bottom_bf_mm),('bottom flange thickness',s.bottom_tf_mm)):
        _real(v,name)
    try:c.basis.validated_project()
    except (OverflowError,TypeError):raise ValueError('Invalid source nominal geometry') from None
    if (s.fabrication!='rolled' or not s.doubly_symmetric or
            s.bottom_width!=s.bf_mm or s.bottom_thickness!=s.tf_mm):
        raise ValueError('Nominal shear bound requires an exactly doubly symmetric rolled section')


def _prepared_bound_signature(c):
    """Bind a computed receipt to inputs, not a caller-supplied effort/proof.

    This identity is not authentication of action origins; the EN/NBR producer
    retains that responsibility and must still generate every action vertex.
    """
    payload=dict(project=c.project.to_dict(),basis=c.basis.provenance(),
        factors=asdict(c.factors),udl=asdict(c.udl),
        source_wheels=[asdict(w) for w in c.source_wheels],
        major_fixed=[asdict(w) for w in c.major_fixed])
    return sha256(json.dumps(payload,sort_keys=True,allow_nan=False).encode()).hexdigest()


def prepared_support_compression_bounds(c, *, bearing_lengths_mm=None):
    """Joint positive reaction envelope from the SAME complete linear state.

    Reactions are affine between wheel entry/exit events. Their weighted
    positive-part sum is convex, so its supremum is among the actual events
    and both open-interval endpoint limits. Applied couples may jump there.
    All supplied UDL and fixed loads (including projection equivalents) stay
    active. No independent reaction maxima, spatial max-only substitution,
    sampled maximum, contact qualification or physical tensor is introduced.

    Rational arithmetic preserves the exact ordering and membership of events
    for the supplied finite numeric inputs, even when float midpoints collapse.
    The returned nonnegative supremum is rounded upward on conversion to float.
    Other nominal-model arithmetic is NOT an interval certificate.
    """
    _nominal_geometry(c)
    p=c.project
    if p.wheel_travel_scope!='between_support_axes' or p.support_model!='simple_forks_free_warping':
        raise ValueError('Joint reaction envelope requires the prepared simple-support travel model')
    L=Fraction(_real(p.span_m,'span',1e-12))
    if c.beam.span_m!=p.span_m:raise ValueError('Prepared beam span does not match the project')
    q=Fraction(_signed(c.udl.vertical_kn_per_m,'vertical UDL'))
    # A PreparedCase's permanent tail equivalents are part of its load state,
    # not optional relief. Reject a stale q/geometry copy that dropped them.
    from lro_beams.autonomous_response import projection_equivalent_loads
    for a in (p.beam_end_left_mm,p.beam_end_right_mm):_real(a,'physical projection length')
    if any(w not in c.major_fixed for w in projection_equivalent_loads(p,c.udl)):
        raise ValueError('Prepared case is missing the complete permanent projection equivalents')
    if bearing_lengths_mm is None:bearing_lengths_mm=(p.support_bearing_length_mm,)*2
    if not isinstance(bearing_lengths_mm,(tuple,list)) or len(bearing_lengths_mm)!=2:
        raise ValueError('Exactly two physical bearing lengths required')
    lengths=tuple(Fraction(_real(v,'bearing length',1e-12)) for v in bearing_lengths_mm)
    tw=Fraction(_real(p.section.tw_mm,'web thickness',1e-12))
    def load(w,coordinate):
        return tuple(Fraction(_signed(getattr(w,attr),attr)) for attr in
            (coordinate,'vertical_kn','major_moment_knm'))
    wheels=tuple(load(w,'offset_m') for w in c.source_wheels)
    fixed=tuple(load(w,'position_m') for w in c.major_fixed)
    if any(not 0<=x<=L for x,_,_ in fixed):raise ValueError('Fixed equivalent load outside support span')
    base=(q*L/2+sum(P*(L-x)/L-C/L for x,P,C in fixed),
          q*L/2+sum(P*x/L+C/L for x,P,C in fixed))
    events=tuple(sorted({-x for x,_,_ in wheels}|{L-x for x,_,_ in wheels})) if wheels else (Fraction(0),L)
    states=[]
    def record(t,active,kind):
        RA=base[0]+sum(P*(L-t-x)/L-C/L for x,P,C in active)
        RB=base[1]+sum(P*(t+x)/L+C/L for x,P,C in active)
        weighted=max(RA,0)/lengths[0]+max(RB,0)/lengths[1]
        states.append((weighted,t,kind,RA,RB,len(active)))
    for t in events:record(t,tuple(w for w in wheels if 0<=t+w[0]<=L),'actual_event')
    for a,b in zip(events[:-1],events[1:]):
        midpoint=(a+b)/2
        active=tuple(w for w in wheels if 0<midpoint+w[0]<L)
        record(a,active,'right_limit');record(b,active,'left_limit')
    def number(v,name,*,up=False):
        try:value=float(v)
        except (OverflowError,ValueError):raise ValueError(name+' exceeds supported numeric range') from None
        if up and isfinite(value) and Fraction(value)<v:value=nextafter(value,inf)
        return _signed(value,name)
    def witness(row):
        weighted,t,kind,RA,RB,count=row
        return dict(translation_m=number(t,'event coordinate'),
            translation_exact_ratio=(t.numerator,t.denominator),kind=kind,
            left_reaction_kn=number(RA,'left reaction'),right_reaction_kn=number(RB,'right reaction'),
            weighted_positive_reaction_kn_per_mm=number(weighted,'weighted positive reaction',up=True),
            active_wheel_count=count)
    peak=max(states,key=lambda row:row[0])
    minima=tuple(min(row[index] for row in states) for index in (3,4))
    return dict(kind='internally_prepared_joint_positive_support_envelope',
        prepared_case_signature=_prepared_bound_signature(c),
        bearing_lengths_mm=tuple(map(float,lengths)),
        weighted_positive_reaction_sup_kn_per_mm=number(peak[0],'joint support bound',up=True),
        transverse_compression_mpa=number(peak[0]*1000/tw,'joint support pressure',up=True),
        maximum_witness=witness(peak),candidate_states=tuple(witness(row) for row in states),
        candidate_count=len(states),event_count=len(events),
        support_minimum_reactions_kn=tuple(number(v,'minimum reaction') for v in minima),
        support_uplift_requires_separate_contact_check=any(v<0 for v in minima),
        contact_applicability_qualified=False,
        proof='Convex weighted positive parts of coexistent affine reactions; complete entry/exit events and both one-sided limits',
        arithmetic='Exact rational event/reaction arithmetic for supplied float inputs; supremum converted upward',
        independent_support_extrema_summed=False,sampled_maxima_used=False,
        action_origin_authenticated=False,floating_point_interval_certificate=False,
        physical_full_3d_tensor_claim=False,local_sigmaT_calculated=False)


def plane_absolute_bounds(*, span_m, point_forces_kn, point_couples_knm, udl_kn_m,
                          fixed_forces_kn=(), fixed_couples_knm=(), projection_lengths_m=()):
    """Uniform all-position absolute action enclosure, not an attained maximum.

    For a point force anywhere on a simply-supported span, |M|<=|P|L/4 and
    |V|<=|P|. For a point couple including at an endpoint, |M|<=|C| and
    |V|<=|C|/L. A uniform signed q gives |M|<=|q|L²/8, |V|<=|q|L/2.
    Fixed loads are deliberately treated as anywhere INSIDE the span, never
    assumed to disappear. Actual unloaded tails give |M|<=|q|a²/2, |V|<=|q|a.
    Their main-span equivalent loads must ALSO be supplied as fixed loads.
    """
    L=_real(span_m,'span',1e-12)
    def total(values,label):return sum(abs(_signed(v,label)) for v in values)
    P=total((*point_forces_kn,*fixed_forces_kn),'point force')
    C=total((*point_couples_knm,*fixed_couples_knm),'point couple')
    q=abs(_signed(udl_kn_m,'UDL'))
    tails=tuple(_real(a,'projection length') for a in projection_lengths_m)
    tail=max((0.,*tails))
    main_M=P*L/4+C+q*L*L/8;main_V=P+C/L+q*L/2
    tail_M=q*tail*tail/2;tail_V=q*tail
    M=max(main_M,tail_M);V=max(main_V,tail_V)
    _real(M,'derived moment');_real(V,'derived shear')
    return dict(moment_abs_knm=M,shear_abs_kn=V,
                main_span_moment_abs_knm=main_M,main_span_shear_abs_kn=main_V,
                projection_moment_abs_knm=tail_M,projection_shear_abs_kn=tail_V,
                proof='Simply-supported point-force/couple Green-function extrema + triangle inequality; actual unloaded projection UDL polynomial',
                bound_kind='sufficient_absolute_all_positions',attained_maximum_claimed=False,
                floating_point_interval_certificate=False)


def _combine_lateral(left,right,sign,*,moving):
    """Combine correlated signed loads BEFORE absolute-value inequalities."""
    coordinate='offset_m' if moving else 'position_m'
    ls={};rs={}
    for rows,target in ((left,ls),(right,rs)):
        for row in rows:
            x=getattr(row,coordinate)
            values=target.setdefault(x,[0.,0.])
            values[0]+=row.horizontal_kn;values[1]+=row.minor_moment_knm
    # Missing zero UDL tail contributions legitimately have no load record.
    xs=sorted(ls.keys()|rs.keys())
    return tuple(ls.get(x,(0.,0.))[0]+sign*rs.get(x,(0.,0.))[0] for x in xs),\
           tuple(ls.get(x,(0.,0.))[1]+sign*rs.get(x,(0.,0.))[1] for x in xs)


def prepared_absolute_bounds(c):
    """All-translation/all-section mechanics enclosure, no FE/scan.

    Includes permanent projection equivalents in main-span bounds and the
    actual UDL tail maximum. Both must be retained; omitting either is unsafe.
    Equivalent minor/B resultants combine signed top±bottom inputs first, so
    opposing flange forces are not unnecessarily treated as independent H.
    """
    _nominal_geometry(c)
    p=c.project;s=p.section;g=c.properties
    tails=(p.beam_end_left_mm/1000,p.beam_end_right_mm/1000)
    def plane(wheels,q,fixed,horizontal=False):
        force='horizontal_kn' if horizontal else 'vertical_kn'
        moment='minor_moment_knm' if horizontal else 'major_moment_knm'
        if any(not 0<=w.position_m<=p.span_m for w in fixed):raise ValueError('Fixed equivalent load outside support span')
        return plane_absolute_bounds(span_m=p.span_m,point_forces_kn=tuple(getattr(w,force) for w in wheels),
            point_couples_knm=tuple(getattr(w,moment) for w in wheels),udl_kn_m=q,
            fixed_forces_kn=tuple(getattr(w,force) for w in fixed),fixed_couples_knm=tuple(getattr(w,moment) for w in fixed),projection_lengths_m=tails)
    major=plane(c.source_wheels,c.udl.vertical_kn_per_m,c.major_fixed)
    top=plane(c.top_wheels,c.top_udl.horizontal_kn_per_m,c.top_fixed,True)
    bottom=plane(c.bottom_wheels,c.bottom_udl.horizontal_kn_per_m,c.bottom_fixed,True)
    equivalents={}
    for name,sign in (('equivalent_minor',1),('equivalent_difference',-1)):
        forces,couples=_combine_lateral(c.top_wheels,c.bottom_wheels,sign,moving=True)
        fixed_forces,fixed_couples=_combine_lateral(c.top_fixed,c.bottom_fixed,sign,moving=False)
        equivalents[name]=plane_absolute_bounds(span_m=p.span_m,point_forces_kn=forces,point_couples_knm=couples,
            udl_kn_m=c.top_udl.horizontal_kn_per_m+sign*c.bottom_udl.horizontal_kn_per_m,
            fixed_forces_kn=fixed_forces,fixed_couples_knm=fixed_couples,projection_lengths_m=tails)
    # N(x)=sum downstream Fx for the explicit left-anchor/right-slide model.
    # Positive/negative contribution sums enclose tension/compression separately.
    Fx=[_signed(w.longitudinal_kn,'longitudinal force') for w in (*c.source_wheels,*c.major_fixed)]
    qx=_signed(c.udl.longitudinal_kn_per_m,'longitudinal UDL')
    Nt=sum(max(v,0.) for v in Fx)+max(qx,0.)*p.span_m
    Nc=sum(max(-v,0.) for v in Fx)+max(-qx,0.)*p.span_m
    N=max(Nt,Nc)
    axial=N*1000/g.A_mm2
    sx=axial+major['moment_abs_knm']*1e6*s.d_mm/(2*g.Ix_mm4)+max(top['moment_abs_knm'],bottom['moment_abs_knm'])*1e6*s.bf_mm/(2*c.flange_I_mm4)
    # These are optional nominal shear-model boxes, NOT a compatible 3-D local
    # tensor proof. Symmetry gives top-half A/2 with |z|<=d/2, hence
    # Qmax<=A*d/4, including all catalog root material without a fillet shape.
    Q=_real(g.A_mm2*s.d_mm/4,'nominal major-shear first-moment bound')
    txz=major['shear_abs_kn']*1000*Q/(g.Ix_mm4*min(s.tw_mm,s.tf_mm))
    txy=1.5*max(top['shear_abs_kn'],bottom['shear_abs_kn'])*1000/(s.bf_mm*s.tf_mm)
    B=equivalents['equivalent_difference']['moment_abs_knm']*1e6*c.h_mm/2
    for name,v in [('sx',sx),('txz',txz),('txy',txy),('equivalent B',B),('N',N)]:_real(v,name)
    return dict(sx_abs_mpa=sx,txz_abs_mpa=txz,txy_abs_mpa=txy,N_abs_kn=N,
                nominal_major_shear_Q_upper_mm3=Q,
                nominal_major_shear_Q_proof='Doubly symmetric section: upper-half area A/2 and |z|<=d/2 imply Qmax<=A*d/4',
                N_tension_abs_kn=Nt,N_compression_abs_kn=Nc,N_interval_kn=(-Nc,Nt),
                major=major,top=top,bottom=bottom,**equivalents,
                equivalent_minor_M_abs_knm=equivalents['equivalent_minor']['moment_abs_knm'],
                equivalent_minor_V_abs_kn=equivalents['equivalent_minor']['shear_abs_kn'],
                equivalent_B_abs_nmm2=B,equivalent_B_abs_knm2=B/1e9,
                equivalent_analogy_torque_abs_knm=equivalents['equivalent_difference']['shear_abs_kn']*c.h_mm/2000,
                same_material_point_scope='Uniform box valid at every ordinary point in the adopted nominal member; no simultaneous witness asserted',
                proof='Sufficient per-contribution analytical Green-function bounds; no scan maxima',
                duplicate_vlasov_b=False,local_sigmaT_calculated=False,design_complete=False,
                shear_scope='Nominal Jourawski/rectangular flange model boxes, not a complete compatible local stress tensor')
