"""CMAA characteristic origins, supplementary NBR8800 ULS, top runway only.

This is not a second global ASD route. The source's DL/TL/payload/retained
suspended/IFD origins are reconstructed before normal NBR8800 partial factors
are applied, with psi=1. SK is an independent contact-force outer set. Its
vertices are mathematical design cases, never witnessed physical failures.
The existing CISC two-flange analogy receives SK at the real top rail height.
No bottom wheel gauge, local sigmaT or duplicate Vlasov stress is introduced.
"""
from copy import deepcopy
from dataclasses import asdict, dataclass, replace
from hashlib import sha256
from itertools import product
from math import fsum, isfinite
from pathlib import Path

from lro_beams.autonomous_actions import ActionFactors, variants_8800
from lro_beams.autonomous_model import WheelInput
from lro_beams.autonomous_response import CaseFactors
from underslung_runway_candidate.autonomous_workflow.model import signature
from underslung_runway_candidate.cmaa74.actions import (
    CMAA74PhysicalInputs, skew_coefficient_enclosure,
)
from .actions import TopBridgeInputs
from .cmaa_fatigue import generate_top_case1_actions, EDITION, PRIMARY_PDF_SHA256
from .mechanics import TopUnstiffenedBasis, TopIntermediateBasis, PreparedCase, prepare_case
from .stiffeners.loads import stationary_destabilizing_radius_nmm
from .verification_lengths import verification_lengths_metadata, CONTRACT_SHA256

ACTION_BASIS = 'CMAA74_2020_UNCOLLAPSED_CHARACTERISTIC_ORIGINS'
FAMILY = 'TOP_CMAA_CHARACTERISTIC_NBR8800_NORMAL_ULS'
FAMILY_BOUND_CONTRACT_SHA256 = 'e024ddd93f136139bdf277e303d004bd191cdb98b475cc21d9f7623ef5e0ca3b'
SOURCE = ('CMAA74:2020 3.3.2.1,3.3.2.2.2,3.3.2.5; '
          'ABNT NBR8800:2024 + Er1:2025 normal ULS with psi=1; '
          'declared CISC2005 ordinary rolled-flange nominal analogy')
FORMULA = ('gamma_Ge*(DL*DLF_B + TL*DLF_T) + '
           'gamma_Q*((payload + retained_LL)*(1+HLF) + signed_IFD + SK); '
           'runway/rail G and extra G have independent permanent-origin factors')


def _real(v, name):
    if type(v) not in (int, float) or not isfinite(v) or abs(v) > 1e100:
        raise ValueError(name+' must be finite numeric data')
    return float(v)


def generate_top_cmaa_characteristic_actions(basis, bridge_inputs, physical):
    """All four-origin source endpoints, both rails/states and both IFD signs.

    Reuses the audited Case1 *origin* producer, not its precombined total as a
    characteristic tensor. The public result deliberately has no force_N total.
    SK uses source dynamic vertical gravity plus both absolute IFD vertical
    redistributions, exactly the audited conservative source-ambiguity domain.
    """
    original = generate_top_case1_actions(basis, bridge_inputs, physical)
    skew = skew_coefficient_enclosure(bridge_inputs.bridge_span_mm,
                                     bridge_inputs.carriage_station_spacing_mm)
    cases = []
    for source in original:
        f = source['factors']; sx = f['longitudinal_sign']; sy = f['transverse_sign']
        contacts = []
        for c in source['full_contacts']:
            origins = dict(
                DL=[0., 0., -f['DLF_B']*c['DL_N']],
                TL=[0., 0., -f['DLF_T']*c['TL_N']],
                payload=[0., 0., -(1+f['HLF'])*c['payload_N']],
                retained_suspended=[0., 0., -(1+f['HLF'])*c['retained_LL_N']],
                IFD_bridge=[sx*x for x in c['IFD_bridge_vector_N']],
                IFD_trolley=[sy*x for x in c['IFD_trolley_vector_N']])
            ordinate = (-fsum(origins[k][2] for k in ('DL', 'TL', 'payload', 'retained_suspended'))
                        +abs(origins['IFD_bridge'][2])+abs(origins['IFD_trolley'][2]))
            contacts.append(dict(contact_id=c['id'], position_mm=c['position_mm'],
                rail_index=c['rail_index'], characteristic_origins_N=origins,
                source_origins_N=deepcopy(c['origins']),
                SK_characteristic_abs_upper_N=skew['coefficient_upper']*ordinate,
                SK_vertical_ordinate_upper_N=ordinate))
        cases.append(dict(id=source['id'].replace('CMAA74_CASE1/', 'CMAA74_ORIGINS/', 1),
            action_basis=ACTION_BASIS, source_origin_producer_id=source['id'], edition=EDITION,
            bridge_inputs=deepcopy(source['bridge_inputs']), physical_inputs=deepcopy(source['physical_inputs']),
            factors=deepcopy(f), loaded=source['loaded'], rail_index=source['rail_index'],
            hook_mm=source['hook_mm'], transfer_height_mm=source['transfer_height_mm'],
            full_contacts=contacts, source_equilibrium=deepcopy(source['equilibrium']),
            skew=deepcopy(skew), source=SOURCE,
            WLO='zero only within sourced indoor_no_operating_wind domain',
            SK_interpretation='Independent normal-to-rail contact force interval; no invented physical sign pattern or vertical redistribution',
            uncollapsed_characteristic_origins=True, precombined_Case2_tensor_factored=False,
            common_four_origin_mass_ledger=True, no_bottom_contact_geometry=True,
            whole_design_complete=False))
    return tuple(cases)


def _variants(basis, extra_dead_kind):
    p = basis.validated_project()
    # Presence/absence of the correlated crane variable family is a complete
    # normal ULS load case distinction, not an extra favorable multiplier.
    return tuple((present, f) for present in (True, False)
        for f in variants_8800(psi=1., extra_dead_kn_per_m=p.extra_dead_kn_per_m,
                              extra_dead_kind=extra_dead_kind,
                              variables=('crane',) if present else ()))


def _validate_factors(basis, factors, extra_dead_kind):
    if not isinstance(factors, ActionFactors) or factors not in tuple(f for _, f in _variants(basis, extra_dead_kind)):
        raise ValueError('Exact regenerated variants_8800(psi=1) factor ledger required; no second dynamics or overridden source factors')
    return factors


def _fresh_characteristic(basis, case):
    if not isinstance(case, dict):
        raise ValueError('Regenerated source-origin action record required')
    fresh = next((c for c in generate_top_cmaa_characteristic_actions(basis,
        TopBridgeInputs(**case['bridge_inputs']), CMAA74PhysicalInputs(**case['physical_inputs']))
        if c['id'] == case['id']), None)
    if fresh is None or signature(fresh) != signature(case):
        raise ValueError('Stale/tampered CMAA characteristic origins; regenerate from physical inputs')
    return fresh


def _factored_contacts(case, factors, skew_coordinates):
    selected = [c for c in case['full_contacts'] if c['rail_index'] == case['rail_index']]
    if len(selected) != 2 or len(case['full_contacts']) != 4:
        raise ValueError('Exactly four physical top contacts and two selected-runway contacts required')
    if not isinstance(skew_coordinates, (tuple, list)) or len(skew_coordinates) != 2:
        raise ValueError('Two independent selected-runway SK coordinates in [-1,1] required')
    coordinates = tuple(_real(x, 'SK normalized coordinate') for x in skew_coordinates)
    if any(abs(x) > 1 for x in coordinates):
        raise ValueError('SK design point outside the source contact-force box')
    sk_by_id = dict(zip((c['contact_id'] for c in selected), coordinates))
    rows = []
    for c in case['full_contacts']:
        o = c['characteristic_origins_N']
        factor_map = dict(DL=factors.dead_equipment, TL=factors.dead_equipment,
            payload=factors.lifted, retained_suspended=factors.lifted,
            IFD_bridge=factors.longitudinal, IFD_trolley=factors.transverse)
        parcels = {k: [factor_map[k]*v for v in vector] for k, vector in o.items()}
        sk = factors.transverse*c['SK_characteristic_abs_upper_N']
        # The unselected runway's two independent SK values do not affect this
        # beam. Zero is a projection representative, not a physical assignment.
        coordinate = sk_by_id.get(c['contact_id'], 0.)
        parcels['SK'] = [0., coordinate*sk, 0.]
        force = [fsum(v[j] for v in parcels.values()) for j in range(3)]
        if not all(isfinite(v) for v in force):
            raise ValueError('Nonfinite regenerated ULS vector')
        rows.append(dict(contact_id=c['contact_id'], position_mm=c['position_mm'],
            rail_index=c['rail_index'], force_N=force, factored_origins_N=parcels,
            SK_characteristic_abs_upper_N=c['SK_characteristic_abs_upper_N'],
            SK_ULS_abs_upper_N=sk, SK_coordinate=coordinate,
            selected_runway=c['rail_index'] == case['rail_index']))
    scale = max(1., *(abs(x) for row in rows for v in row['factored_origins_N'].values() for x in v))
    tolerance = 2e-11*scale
    uplift = [r['contact_id'] for r in rows if r['force_N'][2] > tolerance]
    audit = dict(contact_count=4, no_hold_down_contact_valid=not uplift, uplift_contacts=uplift,
        vertical_roundoff_allowance_N=tolerance, actual_failure_proven=False,
        SK_has_no_invented_vertical_redistribution=True,
        physical_drive_or_equalizer_qualified=False,
        all_four_contact_vectors_checked=True)
    return rows, audit, coordinates


@dataclass(frozen=True)
class CMAANormalULSReceipt:
    """A typed regeneration recipe, never an external-effort approval token."""
    basis: TopUnstiffenedBasis | TopIntermediateBasis
    characteristic_case: dict
    factors: ActionFactors
    extra_dead_kind: str
    skew_coordinates: tuple
    prepared_signature: str


def _prepare_generated(basis, case, factors, skew_coordinates, extra_dead_kind):
    from .checks import _prepared_key
    full, audit, coordinates = _factored_contacts(case, factors, skew_coordinates)
    if not audit['no_hold_down_contact_valid']:
        raise ValueError('All-four-contact no-hold-down source-origin ULS domain inconclusive; not witnessed physical lift-off')
    selected = [c for c in full if c['selected_runway']]
    origin = min(c['position_mm'][0] for c in selected)
    p = deepcopy(basis.project)
    p.wheels = [WheelInput((c['position_mm'][0]-origin)/1000,
        -c['force_N'][2]/1000, 0., c['force_N'][1]/1000, c['force_N'][0]/1000)
        for c in selected]
    variable_state = 'crane' if factors.lifted else 'G_only'
    name = FAMILY+'/'+case['id']+'/'+variable_state+'/'+factors.code+'/SK'+','.join(str(x) for x in coordinates)
    identity = CaseFactors(name, factors.dead_support, 1., 0., 1., 1., SOURCE,
                           extra_dead=factors.extra_dead)
    prepared = prepare_case(replace(basis, project=p), identity)
    receipt = CMAANormalULSReceipt(deepcopy(basis), deepcopy(case), factors, extra_dead_kind, coordinates,
                                  _prepared_key(prepared))
    return prepared, receipt


def prepare_top_cmaa_nbr_uls_case(basis, characteristic_case, factors, *, skew_coordinates=(0., 0.),
                                  extra_dead_kind='steel_or_equipment'):
    """Regenerate every origin, apply gamma once, and bind actual top mechanics."""
    if not isinstance(basis, (TopUnstiffenedBasis, TopIntermediateBasis)):
        raise ValueError('Explicit top nominal physical basis required')
    fresh = _fresh_characteristic(basis, characteristic_case)
    return _prepare_generated(basis, fresh, _validate_factors(basis, factors, extra_dead_kind), skew_coordinates, extra_dead_kind)


def verify_cmaa_normal_uls_receipt(prepared, ledger):
    """Mandatory check consumer dispatch; all mutable contents are regenerated."""
    from .checks import _prepared_key
    if not isinstance(prepared, PreparedCase) or not isinstance(ledger, CMAANormalULSReceipt):
        raise ValueError('Typed regenerated CMAA-origin ULS receipt required')
    fresh, rebuilt = prepare_top_cmaa_nbr_uls_case(ledger.basis, ledger.characteristic_case,
        ledger.factors, skew_coordinates=ledger.skew_coordinates, extra_dead_kind=ledger.extra_dead_kind)
    prepared.validate_stationary_identity()
    if rebuilt.prepared_signature != ledger.prepared_signature or _prepared_key(prepared) != rebuilt.prepared_signature or (isinstance(prepared.basis,TopIntermediateBasis) and prepared != fresh):
        raise ValueError('CMAA-origin ULS receipt does not bind this prepared case; stale/tampered data')
    full, audit, _ = _factored_contacts(rebuilt.characteristic_case, rebuilt.factors, rebuilt.skew_coordinates)
    return dict(kind='regenerated_CMAA_characteristic_origins_NBR8800_ULS',
        family=FAMILY, edition=EDITION, original_factors=asdict(ledger.factors),
        action_basis=ACTION_BASIS, source_origin_case=ledger.characteristic_case['id'],
        prepared_signature=rebuilt.prepared_signature, contact_audit=audit,
        full_contact_forces=full, skew_coordinates=ledger.skew_coordinates,
        box_design_case=True, physical_failure_witness=False,
        source_dynamics_applied_once=True, nbr_additional_psi=1.,
        external_efforts_required=False, precombined_Case2_tensor_factored=False,
        physical_stiffeners=prepared.basis.physical_stiffeners, no_bottom_contact_geometry=True,
        SK_applied_at_actual_top_rail=True, duplicate_vlasov_b=False)


def _source_receipt():
    from .cmaa_fatigue import _source_receipt as source_origins
    source = source_origins()
    from .source_closure import candidate_import_closure
    source['files'].update(candidate_import_closure('top_unstiffened_candidate.cmaa_strength'))
    for name in ('cmaa_strength.py', 'checks.py', 'stability.py', 'reference_bound.py', 'verification_lengths.py'):
        source['files']['top_unstiffened_candidate/'+name] = sha256(Path(__file__).with_name(name).read_bytes()).hexdigest()
    source['references']['common_family_bound_contract_sha256'] = FAMILY_BOUND_CONTRACT_SHA256
    source['references']['verification_lengths_contract_sha256'] = CONTRACT_SHA256
    source['sha256'] = signature(source['files'])
    return source


def _max_bounds(first, other):
    """Component union, not a concurrent force vector or a sampled extremum."""
    if first is None:
        return deepcopy(other)
    for key, value in other.items():
        if isinstance(value, dict):
            _max_bounds(first[key], value)
        elif type(value) in (int, float):
            first[key] = max(first[key], value)
        elif key == 'N_interval_kn':
            first[key] = (min(first[key][0], value[0]), max(first[key][1], value[1]))
    return first


def _component_summary(results, label):
    pending = list(dict.fromkeys(p for result in results for p in result.get('pending', [])))
    worst = {}
    for result in results:
        for row in result.get('checks', []):
            score = row['demand']/row['capacity'] if row['capacity'] else (float('inf') if row['demand'] else 0.)
            old = worst.get(row['id'])
            if old is None or score > old[0]:
                worst[row['id']] = (score, row)
    satisfied = bool(results) and all(r['component_bounds_satisfied'] for r in results)
    return dict(kind=label, status='PENDING' if pending or not results else 'COMPONENT_CHECKS_SATISFIED' if satisfied else 'INCONCLUSIVE',
        checks=[deepcopy(v[1]) for v in worst.values()], pending=pending,
        component_bounds_satisfied=satisfied, actual_failure_proven=False,
        all_translations=True, complete_continuous_SK_box=True,
        attained_global_governor=False, whole_design_complete=False)


def evaluate_top_cmaa_nbr_strength(basis, bridge_inputs, physical, *, stability_premises=None,
                                 extra_dead_kind='steel_or_equipment', progress=None, verification_lengths=None):
    """Full source endpoint/SK-box component route, without external efforts.

    Convex scalar component bounds cover every independent SK ordinate between
    vertices, plus the adopted multiaffine physical endpoint domain. Nonlinear
    combined stability is never inferred from separate vertex utilizations.
    """
    from .checks import check_uls_all_positions, bare_web_all_positions
    start = _source_receipt()
    inputs = dict(basis=basis.provenance(), project=basis.project.to_dict(),
        bridge=asdict(bridge_inputs), physical=asdict(physical), extra_dead_kind=extra_dead_kind,
        stability=None if stability_premises is None else asdict(stability_premises),
        verification_lengths=verification_lengths_metadata(verification_lengths,basis.project.span_m*1000))
    input_signature = signature(inputs)
    out = dict(kind=FAMILY, source=SOURCE, edition=EDITION, action_basis=ACTION_BASIS,
        formula=FORMULA, status='PENDING', cases=[], checks=[], pending=[],
        input_signature=input_signature,verification_lengths=inputs['verification_lengths'],
        component_bounds_satisfied=False, bare_web_bounds_satisfied=False,
        member_stability_qualified=False, whole_member_qualified=False,
        whole_design_complete=False, actual_failure_proven=False,
        local_sigmaT_calculated=False, physical_stiffeners=basis.physical_stiffeners,
        duplicate_vlasov_b=False, precombined_Case2_tensor_factored=False,
        external_efforts_required=False, nonlinear_vertex_maximum_claimed=False,
        special_actions_covered=False,
        operating_scope='Normal non-abrupt indoor source operation only; WLO zero only under explicit source premise',
        excluded_scopes=['Outdoor operating wind, abrupt engagement and exceptional/test/bumper events',
            'Rail/contact/wheel interface and actual support/fork connections',
            'Complete local transverse stress field and fatigue'],
        source_review_status='CANDIDATE_PENDING_INDEPENDENT_REVIEW',
        primary_pdf_sha256=PRIMARY_PDF_SHA256, source_receipt=start)
    try:
        characteristic = generate_top_cmaa_characteristic_actions(basis, bridge_inputs, physical)
        variants = _variants(basis, extra_dead_kind)
        total = len(characteristic)*len(variants)*4
        family_bounds=None; family_radius=0.; family_udl=0.; reference_case=None
        prepared_signatures=[]
        for index, (case, (present, factors), coordinates) in enumerate(
                product(characteristic, variants, product((-1., 1.), repeat=2)), 1):
            entry = dict(id=case['id']+('/crane/' if present else '/G_only/')+factors.code+'/SK'+str(coordinates),
                source_case=case['id'], rail_index=case['rail_index'], loaded=case['loaded'],
                hook_mm=case['hook_mm'], transfer_height_mm=case['transfer_height_mm'],
                longitudinal_sign=case['factors']['longitudinal_sign'],
                transverse_sign=case['factors']['transverse_sign'],
                source_family=FAMILY, action_basis=ACTION_BASIS,
                crane_variable_present=present, factors=asdict(factors),
                skew_coordinates=coordinates, box_design_case=True)
            try:
                c, receipt = _prepare_generated(basis, case, factors, coordinates, extra_dead_kind)
                entry['strength'] = check_uls_all_positions(c, receipt,verification_lengths=verification_lengths)
                entry['bare_web'] = bare_web_all_positions(c, receipt)
                entry['bounds'] = entry['strength']['bounds']
                entry['prepared_signature'] = receipt.prepared_signature
                family_bounds = _max_bounds(family_bounds, entry['strength']['bounds'])
                radius = fsum(max(0., w.vertical_kn*1000*c.rail_z_mm-w.horizontal_kn*1000*c.ey_mm)
                              for w in c.source_wheels)
                rail_q = c.project.rail.mass_kg_per_m*9.80665/1000*c.factors.dead_support
                radius += max(0., rail_q*c.rail_z_mm)*c.project.span_m*1000
                radius += stationary_destabilizing_radius_nmm(c.stationary_bodies,c.factors.dead_support)
                family_radius = max(family_radius, radius)
                family_udl = max(family_udl, c.udl.vertical_kn_per_m)
                prepared_signatures.append(receipt.prepared_signature)
                if reference_case is None:
                    reference_case=c
            except (ValueError, TypeError, KeyError, ArithmeticError, AttributeError) as exc:
                reason = type(exc).__name__+': '+str(exc)
                failed = dict(status='PENDING', checks=[], pending=[reason],
                    component_bounds_satisfied=False, actual_failure_proven=False)
                entry.update(strength=failed, bare_web=deepcopy(failed))
            out['cases'].append(entry)
            if progress is not None:
                progress(index, total)
        strength = [c['strength'] for c in out['cases']]
        web = [c['bare_web'] for c in out['cases']]
        out['component_bounds_satisfied'] = bool(strength) and all(c['component_bounds_satisfied'] for c in strength)
        out['bare_web_bounds_satisfied'] = bool(web) and all(c['component_bounds_satisfied'] for c in web)
        out['section_components'] = _component_summary(strength, 'CMAA_origin_NBR8800_section_components')
        out['bare_web'] = _component_summary(web, 'CMAA_origin_NBR8800_bare_web_components')
        out['action_case_count'] = len(characteristic)
        out['permanent_variant_count'] = len(variants)
        out['skew_box_vertices_per_runway'] = 4
        out['coverage'] = dict(all_four_contacts_audited=True, both_runways=True,
            both_IFD_signs=True, loaded_and_empty_retained_LL=True,
            complete_continuous_SK_box=True, all_translations=True,
            continuous_physical_domain='Convex endpoint hull of declared hook/height/payload states; SK absolute ordinate bounds obey triangle inequality',
            scalar_component_proof='Each response is affine in loads; absolute values, positive parts and sums/maxima are convex; enclosure at force vertices extends to their hull',
            physical_SK_pattern_asserted=False, attained_global_governor=False)
        out['pending'] = list(dict.fromkeys(p for result in (*strength, *web) for p in result.get('pending', [])))
        if stability_premises is None or len(prepared_signatures)!=total:
            reason = ('Explicit supplementary stability adoption/material-environment premises not supplied.'
                if stability_premises is None else 'Not every required source endpoint/permanent/SK-box case has a verified prepared response; common family stability is unqualified.')
            out['stability'] = dict(status='PENDING', checks=[], member_stability_qualified=False,
                actual_failure_proven=False, nonlinear_vertex_maximum_claimed=False, pending=[reason])
        else:
            from .stability import _evaluate_with_bounds
            family_receipt = dict(input_signature=input_signature,
                characteristic_family_signature=signature(characteristic),
                prepared_case_signatures=tuple(prepared_signatures),
                prepared_case_count=len(prepared_signatures), required_case_count=total,
                source_receipt_signature=start['sha256'], full_regeneration_verified=True,
                endpoint_hull_proof=out['coverage'],
                interpolation_uses_nonlinear_vertex_utilization=False,
                monotonicity_proof='CMAA_STRENGTH_CANDIDATE.md: reciprocal reduction curve elasticity in [0,2], common span/tail energy coefficient, and positive-coordinate C.2 interaction',
                zero_moment_policy='Positive envelope M is mandatory; valid section selfweight and normal permanent factors ensure M>0')
            components = dict(producer='regenerated_top_CMAA_origin_family_v1', bounds=family_bounds,
                destabilizing_radius_sum_Nmm=family_radius,
                permanent_vertical_udl_kn_per_m=family_udl, receipt=family_receipt)
            out['stability'] = _evaluate_with_bounds(reference_case, premises=stability_premises,
                                                    _family_components=components,verification_lengths=verification_lengths)
        out['member_stability_qualified'] = out['stability']['member_stability_qualified']
        out['pending'].extend(out['stability']['pending'])
        out['checks'] = out['section_components']['checks']+out['bare_web']['checks']+out['stability']['checks']
        out['status'] = 'PENDING' if out['pending'] else (
            'CMAA_NBR_STRENGTH_BOUNDS_SATISFIED' if out['component_bounds_satisfied'] and out['bare_web_bounds_satisfied'] and out['member_stability_qualified'] else 'INCONCLUSIVE_CMAA_NBR_STRENGTH_BOUNDS')
        out['source_receipt'] = start
        if start != _source_receipt():
            raise ValueError('CMAA strength numerical source changed during evaluation')
        if input_signature != signature(dict(basis=basis.provenance(), project=basis.project.to_dict(),
                bridge=asdict(bridge_inputs), physical=asdict(physical), extra_dead_kind=extra_dead_kind,
                stability=None if stability_premises is None else asdict(stability_premises),
                verification_lengths=verification_lengths_metadata(verification_lengths,basis.project.span_m*1000))):
            raise ValueError('CMAA strength original physical inputs or verification lengths changed during evaluation')
    except (ValueError, TypeError, KeyError, ArithmeticError, AttributeError) as exc:
        reason=type(exc).__name__+': '+str(exc)
        out.update(status='PENDING', component_bounds_satisfied=False, bare_web_bounds_satisfied=False,
                   member_stability_qualified=False, cases=[], checks=[])
        out['pending'].append(reason)
        for name in ('section_components','bare_web','stability'):
            out[name]=dict(status='PENDING',checks=[],pending=[reason],
                component_bounds_satisfied=False,member_stability_qualified=False,
                actual_failure_proven=False,whole_design_complete=False)
    return out
