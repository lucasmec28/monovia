"""Shared top-running physical actions, distinct from each code's factors.

Four rail/station resultants are EXACT sums of the independently verified
bridge kernel's equal pairs. The auxiliary split gauge is mathematical only,
not a bottom-flange geometry, extra actual wheels, or hardware qualification.
"""
from dataclasses import dataclass,asdict,replace,fields
from copy import deepcopy
from itertools import product
from math import fsum
from underslung_runway_candidate.bridge_inertia.statics import (PointMass,combine,_resultant,_compare,real,_cross,
    LEGACY_MASS_CONVENTION,MASS_ACCOUNTING_FIELDS,validate_suspended_mass_accounting,
    suspended_mass_accounting,serialize_mass_inputs,retained_point_mass)
from underslung_runway_candidate.autonomous_workflow.model import checked_text,signature
from lro_beams.autonomous_model import WheelInput
from lro_beams.autonomous_response import CaseFactors
from .mechanics import TopUnstiffenedBasis, TopIntermediateBasis, prepare_case


@dataclass(frozen=True)
class TopBridgeInputs:
    capacity_t: float
    bridge_span_mm: float
    bridge_mass_kg: float
    bridge_cg_x_mm: float
    bridge_cg_y_mm: float
    bridge_cg_z_mm: float
    trolley_mass_kg: float
    trolley_cg_x_mm: float
    trolley_cg_z_mm: float
    trolley_cg_minus_hook_mm: float
    hook_min_from_left_mm: float
    hook_max_from_left_mm: float
    carriage_station_spacing_mm: float
    bridge_acceleration_m_s2: float
    trolley_acceleration_m_s2: float
    geometry_mass_cg_source: str
    acceleration_dynamic_source: str
    equalization_source: str
    force_transfer_source: str
    transfer_model: str
    equalization_model: str = 'adopted_bilinear_four_contact_no_diagonal_self_stress'
    gravity_m_s2: float = 9.80665
    suspension_point_x_mm: float|None = None
    suspension_point_z_mm: float|None = None
    lifted_cg_x_mm: float|None = None
    lifted_cg_z_min_mm: float|None = None
    lifted_cg_z_max_mm: float|None = None
    mass_accounting_convention: str = LEGACY_MASS_CONVENTION
    retained_suspended_mass_kg: float|None = None
    retained_suspended_cg_x_mm: float|None = None
    retained_suspended_cg_z_mm: float|None = None
    retained_mass_excluded_from_equipment: bool|None = None
    suspended_mass_source: str = ''

    def __post_init__(self):
        for f in fields(self):
            v=getattr(self,f.name)
            if f.name in MASS_ACCOUNTING_FIELDS:continue
            if f.name.endswith('_source'):checked_text(v,f.name)
            elif f.name not in ('transfer_model','equalization_model') and v is not None:real(v,f.name)
        if self.equalization_model!='adopted_bilinear_four_contact_no_diagonal_self_stress':raise ValueError('Explicit four-contact equalized model required')
        if min(self.capacity_t,self.bridge_span_mm,self.carriage_station_spacing_mm,self.gravity_m_s2)<=0 or min(self.bridge_mass_kg,self.trolley_mass_kg,self.bridge_acceleration_m_s2,self.trolley_acceleration_m_s2)<0:raise ValueError('Invalid positive mass/geometry/absolute acceleration domain')
        if not 0<=self.hook_min_from_left_mm<=self.hook_max_from_left_mm<=self.bridge_span_mm:raise ValueError('Invalid hook range')
        if self.transfer_model=='free_suspended_at_crab':
            if None in (self.suspension_point_x_mm,self.suspension_point_z_mm) or any(v is not None for v in (self.lifted_cg_x_mm,self.lifted_cg_z_min_mm,self.lifted_cg_z_max_mm)):raise ValueError('Free-rope transfer uses explicit suspension point, not payload CG')
        elif self.transfer_model=='guided_rigid_payload_cg':
            if None in (self.lifted_cg_x_mm,self.lifted_cg_z_min_mm,self.lifted_cg_z_max_mm) or self.lifted_cg_z_min_mm>self.lifted_cg_z_max_mm or self.suspension_point_x_mm is not None or self.suspension_point_z_mm is not None:raise ValueError('Guided transfer requires ordered payload CG range only')
        else:raise ValueError('Explicit force transfer model required')
        validate_suspended_mass_accounting(self)


def _generate_four(masses,p):
    """Closed form EXACT sum of root kernel's equal pairs; no gauge exists."""
    L=p.bridge_span_mm;a=p.carriage_station_spacing_mm
    contacts=[dict(id=f'station{sx}/rail{iy}',position_mm=[sx*a/2,iy*L,0.],station_sign=sx,rail_index=iy) for sx,iy in product((-1,1),(0,1))]
    parcels=[];receipts=[]
    for m in masses:
        if not -a/2<=m.x_mm<=a/2 or not 0<=m.y_mm<=L:raise ValueError('Physical force point outside support rectangle')
        pos=[m.x_mm,m.y_mm,m.z_mm]
        for action,F in {'gravity':[0.,0.,-m.mass_kg*p.gravity_m_s2],'HX':[-m.mass_kg*m.ax_m_s2,0.,0.],'HY':[0.,-m.mass_kg*m.ay_m_s2,0.]}.items():
            loads=[]
            for c in contacts:
                sx=c['station_sign'];iy=c['rail_index'];sy=2*iy-1
                share=(.5+sx*m.x_mm/a)*(m.y_mm/L if iy else 1-m.y_mm/L)
                v=[f*share for f in F]
                if action!='gravity':v[2]+=sy*(-m.z_mm*F[1])/(2*L)-sx*(m.z_mm*F[0])/(2*a)
                loads.append(dict(contact_id=c['id'],position_mm=c['position_mm'],force_N=v))
            receipt=_compare(_resultant(loads),dict(force_N=F,moment_Nmm=_cross(pos,F)))
            receipts.append(receipt)
            parcels.append(dict(mass_id=m.id,kind=m.kind,action=action,source=m.source,source_position_mm=pos,source_force_N=F,loads=loads))
    from underslung_runway_candidate.autonomous_workflow.model import signature
    return dict(schema='top_equalized_four_contact_raw_v1',contacts=contacts,parcels=parcels,equilibrium=receipts,
        input_signature=signature(dict(inputs=serialize_mass_inputs(p),masses=[asdict(m) for m in masses])),inputs=dict(rail_span_mm=L,station_spacing_mm=a))


def generate_top_action_domain(basis, bridge_inputs):
    if not isinstance(basis,(TopUnstiffenedBasis, TopIntermediateBasis)):raise ValueError('Top nominal basis required')
    basis.validated_project()
    return _generate_domain(bridge_inputs)


def _generate_domain(bridge_inputs):
    """Regenerate all hook/force-transfer-height endpoints and BOTH runways.

    No bottom geometry or inherited NBR dynamics enter. Raw parcels contain rigid m*a; downstream named action
    factors apply their chosen dynamics exactly once to each complete vector.
    """
    p=bridge_inputs
    if not isinstance(p,TopBridgeInputs):raise ValueError('Physical TopBridgeInputs required')
    checked_text(p.geometry_mass_cg_source,'mass geometry source');checked_text(p.acceleration_dynamic_source,'absolute acceleration bounds')
    free=p.transfer_model=='free_suspended_at_crab'
    heights=(p.suspension_point_z_mm,) if free else tuple(sorted(set((p.lifted_cg_z_min_mm,p.lifted_cg_z_max_mm))))
    load_x=p.suspension_point_x_mm if free else p.lifted_cg_x_mm
    records=[]
    for hi,hook in enumerate(sorted(set((p.hook_min_from_left_mm,p.hook_max_from_left_mm)))):
        for zi,z in enumerate(heights):
            masses=(PointMass('bridge','equipment',p.bridge_mass_kg,p.bridge_cg_x_mm,p.bridge_cg_y_mm,p.bridge_cg_z_mm,p.bridge_acceleration_m_s2,0,p.geometry_mass_cg_source),
                    PointMass('trolley','equipment',p.trolley_mass_kg,p.trolley_cg_x_mm,hook+p.trolley_cg_minus_hook_mm,p.trolley_cg_z_mm,p.bridge_acceleration_m_s2,p.trolley_acceleration_m_s2,p.geometry_mass_cg_source),
                    PointMass('lifted' if p.mass_accounting_convention==LEGACY_MASS_CONVENTION else 'payload','lifted',p.capacity_t*1000,load_x,hook,z,p.bridge_acceleration_m_s2,p.trolley_acceleration_m_s2,p.force_transfer_source or p.geometry_mass_cg_source))
            retained=retained_point_mass(p,hook)
            if retained is not None:masses=(*masses,retained)
            raw=_generate_four(masses,p)
            records.append(dict(id=f'hook{hi}/height{zi}',generated=raw,hook_mm=hook,force_height_mm=z,physical_inputs=serialize_mass_inputs(p)))
    return dict(schema='TOP_EQUALIZED_FOUR_CONTACT_DOMAIN_V1',records=records,physical_inputs=serialize_mass_inputs(p),
        suspended_mass_accounting=suspended_mass_accounting(p),
        force_transfer_model=p.transfer_model,source='Exact equal-pair sum of bridge_inertia.statics; m*a raw parcels',
        input_contact_n_used=False,input_horizontal_dynamic_factor_used=False,
        pair_split='Closed-form sum of verified equal pairs; four physical contacts, no split gauge or bottom geometry',
        interpolation='Bilinear/multiaffine endpoint enclosure over declared hook/height/payload intervals',
        actual_hardware_qualified=False,external_efforts_required=False)


def combined_top_case(record, *, equipment_factor,lifted_factor,hx_factor,hy_factor,loaded,rail_index,case_name,source,retained_lifted_factor=None):
    """Compose complete correlated vectors; source factors never inferred."""
    if type(rail_index) is not int or rail_index not in (0,1):raise ValueError('Rail index must be integer 0 or 1')
    fresh=next((r for r in _generate_domain(TopBridgeInputs(**record['physical_inputs']))['records'] if r['id']==record['id']),None)
    if fresh is None or signature(record)!=signature(fresh):raise ValueError('Stale/tampered physical action record or parcel checksum')
    checked_text(case_name,'action case');checked_text(source,'action source')
    full=combine(record['generated'],equipment_factor=equipment_factor,lifted_factor=lifted_factor,
                 hx_multiplier=hx_factor,hy_multiplier=hy_factor,loaded=loaded,retained_lifted_factor=retained_lifted_factor)
    stations=[]
    by={r['contact_id']:r for r in full['loads']}
    for c in record['generated']['contacts']:
        row=by[c['id']]
        stations.append(dict(id=c['id'],position_mm=c['position_mm'],force_N=row['force_N'],rail_index=c['rail_index']))
    _compare(_resultant(full['loads']),_resultant(stations))
    return dict(name=case_name,source=source,physical_inputs=record['physical_inputs'],record_checksum=signature(record),rail_index=rail_index,stations=[s for s in stations if s['rail_index']==rail_index],
        all_station_resultants=stations,contact_valid=full['no_hold_down_contact_valid'],full_contact_receipt=full,
        factors=dict(equipment=equipment_factor,lifted=lifted_factor,retained_lifted=retained_lifted_factor,HX=hx_factor,HY=hy_factor,loaded=loaded),
        suspended_mass_accounting=suspended_mass_accounting(TopBridgeInputs(**record['physical_inputs'])),
        source_record=record['id'],top_application='Rail offset and actual rail height supplied by TopUnstiffenedBasis; bridge coordinates relative to common rail contact plane')


def prepare_top_physical_case(basis, case, *, permanent_factor=1.,extra_dead_factor=1.):
    """Internally generated actual case only; no external stress/result inputs."""
    record=next((r for r in generate_top_action_domain(basis,TopBridgeInputs(**case['physical_inputs']))['records'] if r['id']==case['source_record']),None)
    if record is None:raise ValueError('Unknown physical endpoint')
    f=case['factors']
    fresh=combined_top_case(record,equipment_factor=f['equipment'],lifted_factor=f['lifted'],hx_factor=f['HX'],hy_factor=f['HY'],loaded=f['loaded'],rail_index=case['rail_index'],case_name=case['name'],source=case['source'],retained_lifted_factor=f.get('retained_lifted'))
    if signature(fresh)!=signature(case):raise ValueError('Stale/tampered combined physical case; regenerate from inputs')
    if not case['contact_valid']:raise ValueError('Sufficient no-hold-down contact domain inconclusive; not observed actual lift-off')
    p=deepcopy(basis.project)
    origin=min(s['position_mm'][0] for s in case['stations'])
    p.wheels=[WheelInput((s['position_mm'][0]-origin)/1000,-s['force_N'][2]/1000,0,s['force_N'][1]/1000,s['force_N'][0]/1000) for s in case['stations']]
    # Already factored correlated wheel vectors: no further dynamics or H signs.
    factors=CaseFactors(case['name'],permanent_factor,1,0,1,1,case['source'],extra_dead=extra_dead_factor)
    return prepare_case(replace(basis,project=p),factors)
