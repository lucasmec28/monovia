"""Independent NBR10084 member service bounds and restrictive project limits.

NBR uses the same linear operator with the crane-only difference right-hand
side, not subtraction of independently enveloped displacements. CMAA keeps its
own prescribed wheel-load actions and baseline. A manual L/? is applied to
each source's demand separately and never replaces a source's absolute cap.
Only the actual fork-to-fork span is assessed; unloaded tails remain separate.
"""
from copy import deepcopy
from dataclasses import asdict, dataclass
from hashlib import sha256
from itertools import product
from math import isfinite, isclose
from pathlib import Path

from underslung_runway_candidate.autonomous_workflow.model import checked_text, signature
from underslung_runway_candidate.serviceability.nbr10084_criteria import (
    SOURCE, SOURCE_SHA256, ACTION_BASIS, BASELINE, CATEGORIES,
)
from .actions import generate_top_action_domain, combined_top_case
from .nbr_fatigue import _nbr_action_vertex, prepare_top_nbr_action_case
from underslung_runway_candidate.autonomous_workflow.nbr_rolling import (
    NBRRollingGuidance, four_contact_rolling_bound, horizontal_pairs, rolling_source_receipt,
)
from .service import CMAAServicePremises, evaluate_top_service, prepared_displacement_bounds
from .service import SOURCE as CMAA_SOURCE

OPERATING_SCOPE = 'normal_operation_without_wind'
MEASUREMENT_PLANE = 'top_of_actual_rail'
NBR_KIND = 'NBR10084_2020_top_runway_incremental_service_bound'
CMAA_KIND = 'CMAA74_2020_top_runway_service_bound'
PASS = 'SUFFICIENT_BOUND_SATISFIED'
INCONCLUSIVE = 'INCONCLUSIVE_SUFFICIENT_BOUND'
RESULT_PASS = 'SUFFICIENT_SERVICE_BOUND_SATISFIED'


def _number(value, label, *, positive=False):
    try:
        valid = type(value) in (int, float) and abs(value) <= 1e100 and isfinite(value)
    except (OverflowError, ValueError, TypeError):
        valid = False
    if not valid or value < 0 or (positive and value == 0):
        raise ValueError(label + ' must be finite ' + ('positive' if positive else 'nonnegative') + ' numeric data')
    return float(value)


@dataclass(frozen=True)
class NBR10084ServicePremises:
    method_adoption_source: str
    equipment_category: str
    equipment_category_source: str
    measurement_plane: str
    measurement_plane_source: str
    baseline: str
    baseline_source: str
    operating_scope: str
    operating_scope_source: str
    horizontal_action_source: str

    def validate(self):
        for key, value in asdict(self).items():
            checked_text(value, 'NBR service ' + key)
        if self.equipment_category not in CATEGORIES:
            raise ValueError('Explicit equipment class or adopted stricter unclassified L/1000 policy required')
        if self.measurement_plane != MEASUREMENT_PLANE:
            raise ValueError('NBR TOP service must measure at the top of the actual rail')
        if self.baseline != BASELINE:
            raise ValueError('NBR service requires the same-model structural selfweight-only baseline')
        if self.operating_scope != OPERATING_SCOPE:
            raise ValueError('Explicit normal-operation, no-wind member service scope required')
        return self


@dataclass(frozen=True)
class ManualServiceLimits:
    vertical_ratio: float | None = None
    horizontal_ratio: float | None = None
    source: str = ''

    def validate(self):
        active = self.vertical_ratio is not None or self.horizontal_ratio is not None
        checked_text(self.source, 'Manual service criterion source', required=active)
        for key in ('vertical_ratio', 'horizontal_ratio'):
            value = getattr(self, key)
            if value is not None:
                _number(value, 'Manual L/? ' + key, positive=True)
        return self


def _source_hashes():
    from . import actions, mechanics, service, nbr_fatigue
    import underslung_runway_candidate.autonomous_workflow.nbr_rolling as rolling
    import lro_beams.autonomous_response as response
    import lro_beams.moving_beam as beam
    import underslung_runway_candidate.bridge_inertia.statics as statics
    import underslung_runway_candidate.serviceability.nbr10084_criteria as criteria
    files = (Path(__file__), *(Path(m.__file__) for m in (actions, mechanics, service, nbr_fatigue, rolling, response, beam, statics, criteria)))
    return {str(p.parent.name + '/' + p.name): sha256(p.read_bytes()).hexdigest() for p in files}


def _pending(reason, *, kind='pending_service_criterion'):
    return dict(kind=kind, status='PENDING', checks=[], pending=[reason],
                assessed_span_service_sufficient=False, whole_member_qualified=False,
                actual_failure_proven=False, physical_projection_service_qualified=False)


def _status(value, limit):
    # Roundoff tolerance does not turn a physically attained response into proof.
    return PASS if value <= limit + 1e-12 * max(1., limit) else INCONCLUSIVE


def _exact_number(value, expected, label):
    if type(value) not in (int, float) or not isfinite(value) or value != expected:
        raise ValueError(label + ' must retain its exact source factor/value')


def generate_top_nbr_service_actions(basis, bridge_inputs, *, rolling_guidance):
    """Own ELS domain: static G+B+Q, raw complete inertia, three NBR pairs.

    The shared mechanics add pure Rlambda at the real wheel/rail height. Only
    that source's vertex constructor is reused, not fatigue labels or factors.
    """
    if not isinstance(rolling_guidance, NBRRollingGuidance):
        raise ValueError('Explicit NBRRollingGuidance required; missing physical guidance is not zero rolling action')
    if basis.validated_project().rail.wheel_guidance != 'flanged':
        raise ValueError('NBR rolling service requires actual wheel-flange guidance, not separate guides')
    domain = generate_top_action_domain(basis, bridge_inputs)
    if domain['suspended_mass_accounting']['complete_suspended_mass_accounting'] is not True:
        raise ValueError('Explicit payload plus retained suspended mass required for NBR service')
    cases = []
    source = SOURCE+'; G+B+Q plus declared raw m*a, no impact or majoration; native normal Rlambda, not CMAA SK/SHE'
    for record, loaded, pair in product(domain['records'], (False, True), horizontal_pairs()):
        active = tuple(axis for axis in ('HX', 'HY') if axis in pair)
        bound = four_contact_rolling_bound(record['generated'], psi=1., horizontal_dynamic_factor=1.,
            loaded=loaded, inertia_actions=active, guidance=rolling_guidance) if 'Rlambda' in pair else None
        for signs, rail in product(product((-1, 1), repeat=len(active)), (0, 1)):
            mult = dict(HX=0, HY=0)
            mult.update(zip(active, signs))
            for rs in (product((-1, 1), repeat=2) if bound else ((),)):
                name = f'NBR10084/SLS/{record["id"]}/rail{rail}/{"loaded" if loaded else "empty"}/{"+".join(pair)}/HX{mult["HX"]:+d}/HY{mult["HY"]:+d}/R{rs}'
                # loaded=False suppresses only removable Q, not retained B.
                base = combined_top_case(record, equipment_factor=1., lifted_factor=1.,
                    retained_lifted_factor=1., hx_factor=mult['HX'], hy_factor=mult['HY'],
                    loaded=loaded, rail_index=rail, case_name=name, source=source)
                cases.append(_nbr_action_vertex(base, pair, bound, rs))
    return dict(action_domain=domain, cases=cases, horizontal_pairs=horizontal_pairs(),
        rolling_guidance=asdict(rolling_guidance), rolling_source=rolling_source_receipt(),
        action_basis=ACTION_BASIS, vertical_reference='static_G+B+Q_plus_selected_raw_inertia',
        no_impact=True, no_majoration=True, normal_rolling_included=True)


def evaluate_top_nbr10084_service(basis, bridge_inputs, *, premises, rolling_guidance=None):
    """Regenerate all physical endpoints, both rails/states and signed raw H.

    HX and HY are independent signed acceleration endpoints adopted for this
    normal operating domain, not additional directions quoted from Table 4.
    Each entire inertia parcel, including its vertical redistribution, receives
    factor +/-1 exactly once. Retained suspended B stays present when Q=0.
    """
    out = _pending('NBR service not evaluated', kind=NBR_KIND)
    out.update(source=SOURCE, source_sha256=SOURCE_SHA256, pending=[])
    before = _source_hashes()
    try:
        if not isinstance(premises, NBR10084ServicePremises):
            raise ValueError('Typed NBR10084 service premises required')
        premises.validate()
        p = basis.validated_project()
        L = _number(p.span_m, 'Actual support span', positive=True) * 1000
        generated = generate_top_nbr_service_actions(basis, bridge_inputs, rolling_guidance=rolling_guidance)
        domain = generated['action_domain']
        original = signature(dict(project=basis.project.to_dict(), physical=asdict(bridge_inputs), premises=asdict(premises), rolling_guidance=asdict(rolling_guidance)))
        rows = []
        for case in generated['cases']:
            name, rail, loaded = case['name'], case['rail_index'], case['factors']['loaded']
            hx, hy = case['factors']['HX'], case['factors']['HY']
            prepared = prepare_top_nbr_action_case(basis, case, permanent_factor=0., extra_dead_factor=0.)
            bounds = prepared_displacement_bounds(prepared)
            for key in ('rail_vertical_mm', 'rail_horizontal_mm'):
                _number(bounds[key], key)
            rows.append(dict(case_id=name, configuration=case['source_record'], rail_index=rail, loaded=loaded,
                longitudinal_sign=hx, transverse_sign=hy, analytical_bounds=bounds,
                horizontal_pair=case['horizontal_pair'], rolling_signs=case['rolling_signs'],
                rolling_reference=deepcopy(case['rolling_reference']),
                effective_payload_factor=1. if loaded else 0.,
                relaxed_reaction_box_vertex=case['relaxed_reaction_box_vertex'],
                coexistent_operational_state_claimed=case['coexistent_operational_state_claimed'],
                source_wheel_forces_kn=[w.vertical_kn for w in prepared.source_wheels],
                source_lateral_forces_kn=[w.horizontal_kn for w in prepared.source_wheels],
                source_longitudinal_forces_kn=[w.longitudinal_kn for w in prepared.source_wheels],
                input_physical_case_checksum=signature(case), no_impact=True, no_majoration=True,
                permanent_factor=0., extra_dead_factor=0., source_action_category='I',
                action_factors=deepcopy(case['factors'])))
        if not rows:
            raise ValueError('Nonempty internally generated NBR service domain required')
        divisor = 600. if premises.equipment_category == 'other_equipment' else 1000.
        checks = []
        for direction, ratio, cap in (('vertical', divisor, 25.), ('horizontal', 600., None)):
            gov = max(rows, key=lambda r: r['analytical_bounds']['rail_' + direction + '_mm'])
            value = gov['analytical_bounds']['rail_' + direction + '_mm']
            limit = min(L / ratio, cap) if cap is not None else L / ratio
            _number(limit, 'Native source service limit', positive=True)
            utilization = _number(value / limit, 'Native source service utilization')
            checks.append(dict(id='NBR10084_' + direction, direction=direction, upper_bound_mm=value,
                limit_mm=limit, span_m=p.span_m, ratio=ratio, absolute_cap_mm=cap,
                utilization=utilization, status=_status(value, limit), actual_failure_proven=False,
                source=SOURCE, source_sha256=SOURCE_SHA256, action_basis=ACTION_BASIS, baseline=BASELINE,
                measurement_plane=MEASUREMENT_PLANE, governing_bound_case=gov['case_id'],
                physical_translation_governor=None, sufficient_bound=True))
        ids = [r['case_id'] for r in rows]
        baseline_receipt = dict(basis=BASELINE, method='linear_rhs_difference',
            same_linear_operator=True, same_contact_coordinates=True, same_support_constraints=True,
            same_state_chord_difference=True, independent_envelope_subtraction_used=False,
            incremental_selfweight_factor=0., incremental_extra_dead_factor=0.,
            incremental_prescribed_displacements_zero=True, case_ids=ids,
            operator_signature=signature(dict(section=asdict(p.section), material=asdict(p.material),
                span_m=p.span_m, rail=asdict(p.rail), support=p.support_model, axial=p.axial_support,
                projections_mm=[p.beam_end_left_mm, p.beam_end_right_mm], basis=basis.provenance())),
            baseline_case_signature=signature(dict(project=p.to_dict(), crane_factor=0., structural_permanent=1.,
                baseline=BASELINE, adoption=premises.baseline_source)),
            incremental_load_signature=signature([r['input_physical_case_checksum'] for r in rows]),
            permanent_scope='Beam, rail and declared unchanged structural permanent load belong to the adopted baseline; crane G+B+Q does not.')
        ledger = dict(basis=ACTION_BASIS, equipment_characteristic_factor=1., lifted_characteristic_factor=1.,
            retained_suspended_factor=1., retained_mass_in_empty=True,
            partial_factors=dict(equipment=1., payload=1., retained=1., horizontal=1.),
            dynamic_factors=dict(vertical=1., horizontal=1.), horizontal_inertia_dynamic_removed=True,
            horizontal_source='raw_declared_acceleration_m_a_no_dynamic_amplification',
            horizontal_source_adoption=premises.horizontal_action_source,
            horizontal_direction_model='three_native_two_effect_pairs_with_independent_signed_rolling_box',
            normal_rolling_included=True, horizontal_pairs=horizontal_pairs(),
            rolling_guidance=asdict(rolling_guidance), rolling_source=rolling_source_receipt(),
            horizontal_directions_adopted_not_quoted=True, complete_correlated_inertia_vectors=True,
            case_ids=ids, case_category={name: 'I' for name in ids}, source=SOURCE,
            category_scope='Normal no-wind case I only; no case II wind action is synthesized.',
            hoist_psi_used=False, strength_horizontal_dynamic_factor_used=False,
            en_horizontal_factor_used=False, physical_wheel_capacity_not_used=True)
        passed = all(c['status'] == PASS for c in checks)
        out.update(status=RESULT_PASS if passed else INCONCLUSIVE, checks=checks, cases=rows,
            assessed_span_service_sufficient=passed, premises=asdict(premises),
            equipment_category=premises.equipment_category, equipment_classification_inferred=False,
            measurement_plane=MEASUREMENT_PLANE, operating_scope=OPERATING_SCOPE,
            action_ledger=ledger, baseline_receipt=baseline_receipt,
            paired_runway_qualified=False, supporting_floor_qualified=False, torsion_angle_limit_invented=False,
            scope='Actual top of rail over the true fork-to-fork support span; all declared hook/height/rail/loaded endpoints, three native two-effect pairs and train translations. Rolling vertices are sufficient relaxed bounds, not concurrent physical states.',
            separate_scope=[
                'Unloaded physical end-projection deformation is not qualified by this support-span bound.',
                'Paired-runway differential, support movements/alignment and runway spacing/thermal variation are separate source checks.',
                'Out-of-service or operational wind and other unprovided action mechanisms are not synthesized.',
                'Rail/contact deformation, equipment clearances and actual restraint details are not inferred.'])
        if before != _source_hashes():
            raise ValueError('Native service numerical source changed during evaluation')
        if original != signature(dict(project=basis.project.to_dict(), physical=asdict(bridge_inputs), premises=asdict(premises), rolling_guidance=asdict(rolling_guidance))):
            raise ValueError('Native service physical inputs changed during evaluation')
        out['receipt'] = dict(input_signature=original, source_hashes=before, case_count=len(rows),
            all_positions_analytical_bound=True, complete_direction_coverage=True,
            physical_record_ids=[r['id'] for r in domain['records']])
    except (ValueError, TypeError, AttributeError, KeyError, ArithmeticError) as exc:
        out.update(status='PENDING', checks=[], assessed_span_service_sufficient=False)
        out['pending'].append(type(exc).__name__ + ': ' + str(exc))
    return out


def _validated_source_checks(result, family, span_m):
    """Validate completeness and actual-span/source limits, never all([]).

    This is an internal result combiner, not an API for external proof flags.
    The public evaluator obtains the source records directly from both engines.
    """
    expected_kind = CMAA_KIND if family == 'cmaa' else NBR_KIND
    source = CMAA_SOURCE if family == 'cmaa' else SOURCE
    prefix = 'CMAA74_' if family == 'cmaa' else 'NBR10084_'
    if not isinstance(result, dict) or result.get('kind') != expected_kind:
        raise ValueError('Recognized internal ' + family + ' service result required')
    if result.get('pending') or result.get('status') not in (RESULT_PASS, INCONCLUSIVE):
        raise ValueError(family + ' service is pending or unavailable')
    if result.get('actual_failure_proven') is not False or result.get('physical_projection_service_qualified') is not False:
        raise ValueError('Source service must remain a main-span sufficient bound, not actual failure or tail approval')
    checks = result.get('checks')
    if not isinstance(checks, list) or len(checks) != 2 or {c.get('id') for c in checks} != {prefix + d for d in ('vertical', 'horizontal')}:
        raise ValueError('Exactly one nonempty vertical and horizontal source check required')
    rows = result.get('cases')
    if not isinstance(rows, list) or not rows:
        raise ValueError('Nonempty source service cases required')
    ids = [r['case_id'] for r in rows]
    if len(set(ids)) != len(ids):
        raise ValueError('Unique service case IDs required')
    for case_id in ids:
        checked_text(case_id, 'Service case ID')
    record_ids = {r['configuration'] for r in rows}
    for record in record_ids:
        checked_text(record, 'Physical service configuration')
    if family == 'cmaa':
        scenarios = (('vertical', 0), ('horizontal', -1), ('horizontal', 1))
    else:
        scenarios = []
        for pair in horizontal_pairs():
            for hx, hy, rs in product((-1, 1) if 'HX' in pair else (0,),
                    (-1, 1) if 'HY' in pair else (0,),
                    tuple(product((-1, 1), repeat=2)) if 'Rlambda' in pair else ((),)):
                scenarios.append((pair, hx, hy, rs))
    expected = set(product(record_ids, (0, 1), (False, True), scenarios))
    actual = []
    for row in rows:
        if type(row['rail_index']) is not int or row['rail_index'] not in (0, 1) or type(row['loaded']) is not bool:
            raise ValueError('Explicit physical rail and loaded/empty state required')
        if family == 'cmaa':
            direction = row['direction']
            suffix = row['case_id'].rsplit('/', 1)[-1]
            if suffix not in ('-1', '+0', '+1'):
                raise ValueError('Missing prescribed signed CMAA service scenario')
            scenario = (direction, int(suffix))
            _number(row['bound_mm'], 'CMAA case bound')
            if row.get('no_VIF') is not True:
                raise ValueError('CMAA no-VIF service action required')
            _exact_number(row.get('source_lateral_ratio'), 0. if direction == 'vertical' else .1, 'CMAA lateral action ratio')
            _exact_number(row.get('permanent_factor'),
                1. if result['premises']['permanent_baseline'] == 'include_permanent_absolute_bound' else 0., 'CMAA baseline factor')
            vertical = row['source_wheel_forces_kn']
            lateral = row['source_lateral_forces_kn']
            if not vertical or len(vertical) != len(lateral):
                raise ValueError('Complete CMAA physical wheel vectors required')
            for v, h in zip(vertical, lateral):
                _number(v, 'CMAA static wheel force')
                _exact_number(h, scenario[1] * .1 * v, 'CMAA prescribed signed lateral wheel force')
            if direction not in ('vertical', 'horizontal') or row['bound_mm'] != row['analytical_bounds']['rail_' + direction + '_mm']:
                raise ValueError('CMAA source case direction/bound mismatch')
        else:
            pair = tuple(row['horizontal_pair'])
            hx, hy = row['longitudinal_sign'], row['transverse_sign']
            rs = tuple(row['rolling_signs'])
            scenario = (pair, hx, hy, rs)
            if scenario not in scenarios or any(type(v) is not int for v in (hx, hy, *rs)):
                raise ValueError('Complete three-pair signed native acceleration/rolling cases required')
            if row.get('relaxed_reaction_box_vertex') is not ('Rlambda' in pair):
                raise ValueError('Rolling box vertices must not be labelled physical states')
            if row.get('coexistent_operational_state_claimed') is not ('Rlambda' not in pair):
                raise ValueError('Native pair physical/relaxed scope mismatch')
            _exact_number(row.get('effective_payload_factor'), 1. if row['loaded'] else 0., 'Effective removable Q')
            ref = row['rolling_reference']
            if 'Rlambda' in pair:
                if not isinstance(ref, dict) or ref.get('source_receipt') != rolling_source_receipt():
                    raise ValueError('Native rolling source receipt stale or missing')
                if ref.get('receipt_signature') != signature({k:v for k,v in ref.items() if k != 'receipt_signature'}):
                    raise ValueError('Native rolling reference was altered')
                for name in ('psi', 'horizontal_dynamic_factor'):
                    _exact_number(ref.get(name), 1., 'Native static rolling reference '+name)
                if ref.get('loaded') is not row['loaded'] or tuple(ref['inertia_actions']) != tuple(a for a in ('HX', 'HY') if a in pair):
                    raise ValueError('Rolling reference must match its static state and selected inertia pair')
            elif ref is not None:
                raise ValueError('HX/HY may not silently include Rlambda as a third effect')
            if row.get('no_impact') is not True or row.get('no_majoration') is not True:
                raise ValueError('Native no-impact selfweight increment required')
            _exact_number(row.get('permanent_factor'), 0., 'NBR incremental permanent factor')
            _exact_number(row.get('extra_dead_factor'), 0., 'NBR incremental additional permanent factor')
            f = row['action_factors']
            for key, value in (('equipment', 1.), ('lifted', 1.),
                               ('retained_lifted', 1.), ('HX', hx), ('HY', hy)):
                _exact_number(f.get(key), value, 'NBR physical factor ' + key)
            if f.get('loaded') is not row['loaded'] or row.get('source_action_category') != 'I':
                raise ValueError('Native normal-operation loaded/action case mismatch')
        if row['analytical_bounds'].get('all_positions_analytical_bound') is not True:
            raise ValueError('Analytical continuum service bound required')
        for direction in ('vertical', 'horizontal'):
            _number(row['analytical_bounds']['rail_' + direction + '_mm'], 'Source analytical ' + direction)
        actual.append((row['configuration'], row['rail_index'], row['loaded'], scenario))
    if len(actual) != len(set(actual)) or set(actual) != expected:
        raise ValueError('Incomplete physical source direction/rail/loaded coverage')
    receipt = result.get('receipt', {})
    if receipt.get('case_count') != len(rows) or receipt.get('all_positions_analytical_bound') is not True:
        raise ValueError('Source case-count/analytical receipt mismatch')
    checked_text(receipt.get('input_signature'), 'Internal source input signature')
    ledger = result['action_ledger']
    if family != 'cmaa':
        NBR10084ServicePremises(**result['premises']).validate()
        NBRRollingGuidance(**ledger['rolling_guidance'])
        if ledger.get('normal_rolling_included') is not True or tuple(map(tuple, ledger.get('horizontal_pairs', ()))) != horizontal_pairs():
            raise ValueError('All three native normal two-effect pairs required')
        if ledger.get('rolling_source') != rolling_source_receipt():
            raise ValueError('Native rolling source closure differs')
        if result['equipment_category'] != result['premises']['equipment_category']:
            raise ValueError('NBR equipment category does not match adoption')
        if set(receipt.get('physical_record_ids', ())) != record_ids:
            raise ValueError('NBR physical endpoint receipt mismatch')
        baseline = result['baseline_receipt']
        if baseline.get('basis') != BASELINE or baseline.get('method') != 'linear_rhs_difference':
            raise ValueError('Native selfweight baseline receipt mismatch')
        for key in ('incremental_selfweight_factor', 'incremental_extra_dead_factor'):
            _exact_number(baseline.get(key), 0., 'NBR baseline ' + key)
        if any(baseline.get(flag) is not True for flag in ('same_linear_operator', 'same_contact_coordinates', 'same_support_constraints', 'same_state_chord_difference', 'incremental_prescribed_displacements_zero')):
            raise ValueError('Incomplete native same-operator baseline receipt')
        if set(baseline.get('case_ids', ())) != set(ids):
            raise ValueError('NBR baseline case coverage mismatch')
        if ledger.get('basis') != ACTION_BASIS or ledger.get('horizontal_source') != 'raw_declared_acceleration_m_a_no_dynamic_amplification':
            raise ValueError('Native source action basis must remain raw no-impact acceleration')
        for key in ('equipment_characteristic_factor', 'lifted_characteristic_factor', 'retained_suspended_factor'):
            _exact_number(ledger.get(key), 1., 'NBR service ' + key)
        for key, fields in (('partial_factors', ('equipment', 'payload', 'retained', 'horizontal')),
                            ('dynamic_factors', ('vertical', 'horizontal'))):
            if not isinstance(ledger.get(key), dict) or set(ledger[key]) != set(fields):
                raise ValueError('Complete native factor ledger required')
            for name in fields:
                _exact_number(ledger[key][name], 1., 'NBR service ' + key + '.' + name)
        if ledger.get('horizontal_inertia_dynamic_removed') is not True or ledger.get('retained_mass_in_empty') is not True or ledger.get('complete_correlated_inertia_vectors') is not True:
            raise ValueError('Native complete no-impact retained-mass inertia ledger required')
        if set(ledger.get('case_ids', ())) != set(ids) or ledger.get('case_category') != {name: 'I' for name in ids}:
            raise ValueError('Native normal no-wind case I action coverage mismatch')
    else:
        CMAAServicePremises(**result['premises']).validate()
        if ledger.get('basis') != 'CMAA74_2020_1.4.1.1.5_source_prescribed_service':
            raise ValueError('CMAA prescribed service action basis must remain independent')
        for key, expected_value in (('equipment_G', 1.), ('lifted_Q', 1.), ('retained_lifted_B', 1.), ('vertical_impact', 1.), ('horizontal_ratio', .1)):
            _exact_number(ledger.get(key), expected_value, 'CMAA service ' + key)
        if ledger.get('retained_mass_in_empty') is not True or ledger.get('horizontal_ratio_not_strength_action') is not True:
            raise ValueError('CMAA service retained-mass/prescribed-action ledger required')
        if ledger.get('permanent_baseline') != result['premises']['permanent_baseline']:
            raise ValueError('CMAA action baseline does not match explicit adoption')
    normalized = []
    for check in checks:
        direction = check['id'].removeprefix(prefix)
        if check.get('direction', direction) != direction:
            raise ValueError('Service check ID and direction mismatch')
        span = _number(check['span_m'], 'Source support span', positive=True)
        if span != span_m:
            raise ValueError('Service limit must use the actual support span')
        if family == 'cmaa':
            ratio = 600. if direction == 'vertical' else 400.
            cap = None
            relevant = [r for r in rows if r['direction'] == direction]
            maximum = max(r['bound_mm'] for r in relevant)
            governor_value = lambda r: r['bound_mm']
        else:
            ratio = 600. if direction == 'horizontal' or result['equipment_category'] == 'other_equipment' else 1000.
            cap = 25. if direction == 'vertical' else None
            relevant = rows
            maximum = max(r['analytical_bounds']['rail_' + direction + '_mm'] for r in relevant)
            governor_value = lambda r: r['analytical_bounds']['rail_' + direction + '_mm']
            if check.get('action_basis') != ACTION_BASIS or check.get('baseline') != BASELINE or check.get('measurement_plane') != MEASUREMENT_PLANE:
                raise ValueError('Native criterion must retain its own action, baseline and measurement plane')
            if cap is None:
                if check.get('absolute_cap_mm') is not None:
                    raise ValueError('No extra horizontal source absolute cap may be invented')
            else:
                _exact_number(check.get('absolute_cap_mm'), cap, 'Native vertical absolute source cap')
        limit = span_m * 1000 / ratio
        if cap is not None:
            limit = min(limit, cap)
        value = _number(check['upper_bound_mm'], 'Source service bound')
        _number(check['ratio'], 'Source L/?', positive=True)
        _number(check['limit_mm'], 'Source service limit', positive=True)
        utilization = _number(check['utilization'], 'Source utilization')
        gov = next((r for r in relevant if r['case_id'] == check.get('governing_bound_case')), None)
        if gov is None or not isclose(value, maximum, rel_tol=1e-12, abs_tol=1e-12) or not isclose(governor_value(gov), value, rel_tol=1e-12, abs_tol=1e-12):
            raise ValueError('Source governing bound/case mismatch')
        if check['ratio'] != ratio or not isclose(check['limit_mm'], limit, rel_tol=1e-12, abs_tol=1e-12) or not isclose(utilization, value / limit, rel_tol=1e-12, abs_tol=1e-12):
            raise ValueError('Source criterion ratio, absolute cap or utilization changed')
        if check.get('source') != source or check.get('status') != _status(value, limit) or check.get('actual_failure_proven') is not False:
            raise ValueError('Invalid source criterion provenance or outcome')
        normalized.append(dict(deepcopy(check), direction=direction, source_family=family,
            absolute_cap_mm=cap, sufficient_bound=True,
            action_basis=(result['action_ledger']['basis']),
            baseline=(result['premises']['permanent_baseline'] if family == 'cmaa' else BASELINE)))
    return normalized, record_ids


def combine_top_service_results(cmaa_result, nbr_result, *, actual_span_m, manual_limits=None):
    """Combine independent internal results; source limits/actions never migrate.

    Every required source must provide both complete directional checks. The
    minimum-limit summary is informational only: approval requires all original
    source checks and every active manual overlay on its own source demand.
    """
    out = _pending('Service criteria not evaluated', kind='TOP_independent_CMAA_NBR_manual_service_bounds')
    out.update(pending=[], source_results=dict(cmaa=deepcopy(cmaa_result), nbr10084=deepcopy(nbr_result)),
        manual_checks=[], normative_checks=[], strictest_limit_by_direction={},
        same_action_basis_across_sources=False, manual_limits_can_relax_normative=False)
    try:
        span = _number(actual_span_m, 'Actual support span', positive=True)
        if manual_limits is not None and not isinstance(manual_limits, ManualServiceLimits):
            raise ValueError('Typed manual L/? limits required')
        manual = manual_limits or ManualServiceLimits()
        manual.validate()
        records = {}
        for family, result in (('cmaa', cmaa_result), ('nbr10084', nbr_result)):
            try:
                checks, records[family] = _validated_source_checks(result, family, span)
                out['normative_checks'].extend(checks)
            except (ValueError, TypeError, AttributeError, KeyError, ArithmeticError) as exc:
                out['pending'].append(family + ': ' + type(exc).__name__ + ': ' + str(exc))
                if isinstance(result, dict):
                    out['pending'].extend(family + ': ' + str(reason) for reason in result.get('pending', ()))
        if len(records) == 2 and records['cmaa'] != records['nbr10084']:
            out['pending'].append('Source physical endpoint configurations do not match')
        for check in out['normative_checks']:
            ratio = getattr(manual, check['direction'] + '_ratio')
            if ratio is None:
                continue
            manual_limit = _number(span * 1000 / ratio, 'Derived manual service limit', positive=True)
            effective = min(check['limit_mm'], manual_limit)
            utilization = _number(check['upper_bound_mm'] / effective, 'Derived manual utilization')
            out['manual_checks'].append(dict(deepcopy(check), id='MANUAL_' + check['id'],
                normative_check_id=check['id'], normative_source=check['source'],
                normative_ratio=check['ratio'], normative_limit_mm=check['limit_mm'],
                requested_manual_ratio=ratio, requested_manual_limit_mm=manual_limit,
                ratio=max(check['ratio'], ratio), limit_mm=effective,
                utilization=utilization, status=_status(check['upper_bound_mm'], effective),
                source='Restrictive project L/? overlay on ' + check['source'], manual_source=manual.source,
                restrictive_relative_to_normative=effective < check['limit_mm'],
                source_action_and_baseline_preserved=True))
        out['checks'] = out['normative_checks'] + out['manual_checks']
        for direction in ('vertical', 'horizontal'):
            selected = [c for c in out['checks'] if c['direction'] == direction]
            if selected:
                limit = min(c['limit_mm'] for c in selected)
                out['strictest_limit_by_direction'][direction] = dict(limit_mm=limit,
                    criterion_ids=[c['id'] for c in selected if c['limit_mm'] == limit],
                    comparison_only_not_shared_action_basis=True)
        complete = len(out['normative_checks']) == 4 and not out['pending']
        passed = complete and bool(out['checks']) and all(c['status'] == PASS for c in out['checks'])
        out.update(status='PENDING' if not complete else (RESULT_PASS if passed else INCONCLUSIVE),
            assessed_span_service_sufficient=passed, actual_span_m=span, manual_limits=asdict(manual),
            complete_normative_direction_coverage=complete,
            scope='Main support span only; every source keeps its own actions, baseline and absolute cap. Manual limits only restrict. Bound excess is inconclusive, not an attained failure.')
    except (ValueError, TypeError, AttributeError, KeyError, ArithmeticError) as exc:
        out.update(status='PENDING', checks=[], assessed_span_service_sufficient=False)
        out['pending'].append(type(exc).__name__ + ': ' + str(exc))
    return out


def evaluate_top_service_criteria(basis, bridge_inputs, *, cmaa_premises, nbr_premises, manual_limits=None, rolling_guidance=None):
    """Public composite: source actions and receipts are always generated here."""
    try:
        span = basis.validated_project().span_m
        def inputs():
            return signature(dict(project=basis.project.to_dict(), physical=asdict(bridge_inputs),
                cmaa=cmaa_premises, nbr10084=nbr_premises, manual=manual_limits, rolling_guidance=rolling_guidance))
        original = inputs()
        before = _source_hashes()
        cmaa = evaluate_top_service(basis, bridge_inputs, premises=cmaa_premises)
        nbr = evaluate_top_nbr10084_service(basis, bridge_inputs, premises=nbr_premises, rolling_guidance=rolling_guidance)
        out = combine_top_service_results(cmaa, nbr, actual_span_m=span, manual_limits=manual_limits)
        if original != inputs() or before != _source_hashes():
            raise ValueError('Physical inputs or numerical service sources changed between independent source assessments')
        out['receipt'] = dict(input_signature=original, source_hashes=before,
            source_families_generated_from_same_physical_inputs=True,
            independent_source_action_and_baseline_preserved=True)
        return out
    except (ValueError, TypeError, AttributeError, KeyError, ArithmeticError) as exc:
        return _pending(type(exc).__name__ + ': ' + str(exc))
