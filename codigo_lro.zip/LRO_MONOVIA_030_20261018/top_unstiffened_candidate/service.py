"""CMAA74:2020 runway service criteria with internally generated wheel loads.

Clause1.4.1.1.5, printed p10: vertical L/600 from maximum wheel loads without
VIF; lateral L/400 from 10%maximum wheel loads without VIF. The clause does not
resolve runway-selfweight baseline or horizontal direction. Those are explicit
project policies here, not quotations. Analytical absolute displacement bounds
cover all train translations; excess is inconclusive, not an attained failure.
"""
from dataclasses import dataclass,replace,asdict
from copy import deepcopy
from hashlib import sha256
from pathlib import Path
from math import isfinite
from .mechanics import prepare_case,PreparedCase
from .actions import generate_top_action_domain,combined_top_case
from lro_beams.autonomous_model import WheelInput
from lro_beams.autonomous_response import CaseFactors
from underslung_runway_candidate.autonomous_workflow.model import checked_text,signature

SOURCE='CMAA Specification74:2020 §1.4.1.1.5, printedp10; user-supplied primary PDF'

@dataclass(frozen=True)
class CMAAServicePremises:
    method_adoption_source: str
    permanent_baseline: str
    permanent_baseline_source: str
    lateral_direction_model: str='both_signed_10_percent_wheel_load_scenarios'

    def validate(self):
        checked_text(self.method_adoption_source,'CMAA service adoption')
        checked_text(self.permanent_baseline_source,'permanent baseline source')
        if self.permanent_baseline not in ('wheel_load_increment_only','include_permanent_absolute_bound'):
            raise ValueError('Explicit wheel-only or total-permanent service baseline policy required')
        if self.lateral_direction_model!='both_signed_10_percent_wheel_load_scenarios':
            raise ValueError('Both directions of source-prescribed10% wheel lateral action required')
        return self


def _plane_deflection_bound(c,wheels,q,fixed,*,horizontal=False):
    """All x,a simple-support Green bounds; not independently enveloped states.

    |G|<=L³/(48EI), |dG/da|<=L²/(8EI), uniform q gives5qL⁴/(384EI).
    Point couples use the deliberately loose derivative bound. Physical tail
    equivalent forces/couples are included in the main span response.
    """
    L=c.project.span_m*1000;E=c.project.material.E_mpa
    I=c.flange_I_mm4 if horizontal else c.properties.Ix_mm4
    force='horizontal_kn' if horizontal else 'vertical_kn'
    moment='minor_moment_knm' if horizontal else 'major_moment_knm'
    P=sum(abs(getattr(w,force))*1000 for w in (*wheels,*fixed))
    C=sum(abs(getattr(w,moment))*1e6 for w in (*wheels,*fixed))
    result=P*L**3/(48*E*I)+C*L**2/(8*E*I)+5*abs(q)*L**4/(384*E*I)
    if not isfinite(result):raise ValueError('Derived service bound outside finite domain')
    return result


def prepared_displacement_bounds(c):
    if not isinstance(c,PreparedCase):raise ValueError('Internal prepared mechanics required')
    v=_plane_deflection_bound(c,c.source_wheels,c.udl.vertical_kn_per_m,c.major_fixed)
    t=_plane_deflection_bound(c,c.top_wheels,c.top_udl.horizontal_kn_per_m,c.top_fixed,horizontal=True)
    b=_plane_deflection_bound(c,c.bottom_wheels,c.bottom_udl.horizontal_kn_per_m,c.bottom_fixed,horizontal=True)
    h=c.h_mm;z=c.rail_z_mm;e=c.ey_mm
    return dict(vertical_main_span_mm=v,horizontal_top_flange_mm=t,horizontal_bottom_flange_mm=b,
        rail_vertical_mm=v+abs(e)*(t+b)/h,
        rail_horizontal_mm=abs(.5+z/h)*t+abs(.5-z/h)*b,
        twist_abs_rad=(t+b)/h,all_positions_analytical_bound=True,physical_attainment_claimed=False,
        same_state_end_chord_zero_by_model=True,physical_projection_service_qualified=False)


def _source():
    from . import mechanics,actions,bounds
    import lro_beams.moving_beam as beam
    files=(__file__,mechanics.__file__,actions.__file__,bounds.__file__,beam.__file__)
    return {str(Path(p).name):sha256(Path(p).read_bytes()).hexdigest() for p in files}


def evaluate_top_service(basis,bridge_inputs,*,premises):
    out=dict(kind='CMAA74_2020_top_runway_service_bound',source=SOURCE,status='PENDING',checks=[],pending=[],
             assessed_span_service_sufficient=False,whole_member_qualified=False,actual_failure_proven=False,
             physical_projection_service_qualified=False)
    before=_source()
    try:
        if not isinstance(premises,CMAAServicePremises):raise ValueError('Typed CMAA service premises required')
        premises.validate();p=basis.validated_project();domain=generate_top_action_domain(basis,bridge_inputs)
        if not domain['suspended_mass_accounting']['complete_suspended_mass_accounting']:
            raise ValueError('Explicit payload plus retained suspended mass is required for qualified service')
        original=signature(dict(project=basis.project.to_dict(),physical=asdict(bridge_inputs),premises=asdict(premises)))
        permanent=1. if premises.permanent_baseline=='include_permanent_absolute_bound' else 0.
        rows=[]
        for record in domain['records']:
            for rail in (0,1):
                for loaded in (False,True):
                    static=combined_top_case(record,equipment_factor=1.,lifted_factor=1. if loaded else 0.,retained_lifted_factor=1.,hx_factor=0.,hy_factor=0.,loaded=loaded,rail_index=rail,
                        case_name=f'CMAA74/SLS/{record["id"]}/rail{rail}/{"loaded" if loaded else "empty"}',source=SOURCE+'; computed physical G+B+Q wheel reaction without VIF')
                    if not static['contact_valid']:raise ValueError('Static physical wheel contact domain not satisfied')
                    for direction,sign in (('vertical',0),('horizontal',-1),('horizontal',1)):
                        project=deepcopy(p);origin=min(w['position_mm'][0] for w in static['stations'])
                        project.wheels=[WheelInput((w['position_mm'][0]-origin)/1000,-w['force_N'][2]/1000,0.,sign*.1*(-w['force_N'][2]/1000),0.) for w in static['stations']]
                        cf=CaseFactors(static['name']+f'/{direction}/{sign:+d}',permanent,1,0,1,0,SOURCE+'; source-prescribed lateral service scenario, not equipment inertia',extra_dead=permanent)
                        c=prepare_case(replace(basis,project=project),cf)
                        bounds=prepared_displacement_bounds(c)
                        value=bounds['rail_vertical_mm' if direction=='vertical' else 'rail_horizontal_mm']
                        rows.append(dict(case_id=cf.name,configuration=record['id'],rail_index=rail,loaded=loaded,direction=direction,
                            bound_mm=value,analytical_bounds=bounds,source_wheel_forces_kn=[w.vertical_kn for w in c.source_wheels],
                            source_lateral_forces_kn=[w.horizontal_kn for w in c.source_wheels],input_physical_case_checksum=signature(static),
                            no_VIF=True,source_lateral_ratio=0.1 if direction=='horizontal' else 0.,permanent_factor=permanent))
        for direction,divisor in (('vertical',600.),('horizontal',400.)):
            relevant=[r for r in rows if r['direction']==direction];gov=max(relevant,key=lambda r:r['bound_mm'])
            limit=p.span_m*1000/divisor;passed=gov['bound_mm']<=limit+1e-12*max(1.,limit)
            out['checks'].append(dict(id='CMAA74_'+direction,upper_bound_mm=gov['bound_mm'],limit_mm=limit,span_m=p.span_m,ratio=divisor,
                utilization=gov['bound_mm']/limit,status='SUFFICIENT_BOUND_SATISFIED' if passed else 'INCONCLUSIVE_SUFFICIENT_BOUND',
                actual_failure_proven=False,source=SOURCE,governing_bound_case=gov['case_id'],physical_translation_governor=None))
        ok=all(r['status']=='SUFFICIENT_BOUND_SATISFIED' for r in out['checks'])
        out.update(status='SUFFICIENT_SERVICE_BOUND_SATISFIED' if ok else 'INCONCLUSIVE_SUFFICIENT_BOUND',
                   assessed_span_service_sufficient=ok,cases=rows,premises=asdict(premises),
                   scope='Actual top running contact line over the fork-to-fork support span, all declared hook/height/rail endpoints and all train translations. Unloaded physical tails, rail alignment and support movements remain separate.',
                   action_ledger=dict(basis='CMAA74_2020_1.4.1.1.5_source_prescribed_service',equipment_G=1.,lifted_Q=1.,retained_lifted_B=1.,retained_mass_in_empty=True,vertical_impact=1.,horizontal_ratio=.1,
                       horizontal_ratio_not_strength_action=True,permanent_baseline=presm if (presm:=premises.permanent_baseline) else '',
                       lateral_signs_adopted_not_quoted=True,physical_wheel_capacity_not_used=True))
        if before!=_source():raise ValueError('Service numerical source changed')
        if original!=signature(dict(project=basis.project.to_dict(),physical=asdict(bridge_inputs),premises=asdict(premises))):raise ValueError('Service physical inputs changed')
        out['receipt']=dict(input_signature=original,source_hashes=before,case_count=len(rows),all_positions_analytical_bound=True)
    except (ValueError,TypeError,AttributeError,KeyError,ArithmeticError) as exc:
        out.update(status='PENDING',checks=[],assessed_span_service_sufficient=False)
        out['pending'].append(type(exc).__name__+': '+str(exc))
    return out
