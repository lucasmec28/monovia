"""Strict physical-input contract for the isolated unstiffened top-running route.

No forces, approval flags, foreign project dimensions or cached calculations are
accepted as physical inputs. Source status states what is known/adopted, not
whether a numerical verification passed.
"""
from __future__ import annotations
from copy import deepcopy
from dataclasses import asdict, dataclass, fields
import json
from math import isfinite
from typing import Any

from lro_beams.autonomous_model import AutonomousProject, RailInput, WheelInput, FatigueUse, validate_autonomous
from lro_beams.autonomous_actions import HoistDynamics, compute_hoist_dynamic, mx_for_equipment_group, factors_8800
from lro_beams.catalog import section_from_profile
from lro_beams.model import Material
from lro_beams.document_metadata import validate_xml_text, validate_document_metadata
from underslung_runway_candidate.autonomous_workflow.model import signature
from underslung_runway_candidate.fatigue.autonomous_adapter import ENPhysicalFatigueInputs
from .actions import TopBridgeInputs
from .mechanics import (TopUnstiffenedBasis, TopIntermediateBasis, BASIS_ID,
    INTERMEDIATE_BASIS_ID, INTERMEDIATE_DETAIL_BASIS)
from .stiffeners.inputs import IntermediateInputs
from .stability import StabilityPremises
from .verification_lengths import VerificationLengths
from .fatigue_inputs import NBRFatiguePremises, CMAAFatiguePremises, exact_premises
from .native_service import NBR10084ServicePremises, ManualServiceLimits
from .action_inputs import CMAAActionPremises
from underslung_runway_candidate.autonomous_workflow.nbr_rolling import NBRRollingGuidance

SCHEMA = 'LRO_TOP_UNSTIFFENED_PHYSICAL_V1'
INTERMEDIATE_SCHEMA = 'LRO_TOP_INTERMEDIATE_PHYSICAL_V1'
INTERMEDIATE_PROJECT_FORMAT = 'LRO_TOP_INTERMEDIATE_PROJECT'
INTERMEDIATE_CALCULATION_FORMAT = 'LRO_TOP_INTERMEDIATE_CALCULATION'
PROJECT_FORMAT = 'LRO_TOP_UNSTIFFENED_PROJECT'
CALCULATION_FORMAT = 'LRO_TOP_UNSTIFFENED_CALCULATION'
SOURCE_STATUSES = ('reference', 'design_requirement', 'confirmed')
SOURCE_GROUPS = ('structure', 'section', 'material', 'rail', 'bridge', 'actions', 'model')


def checked_tree(value, path='inputs', *, allow_exact_rationals=False):
    """Check all text/keys, nonfinite numbers, nesting and JSON types up front."""
    def ratio_tree(v,label,depth):
        if depth>30:raise ValueError('JSON nesting limit exceeded: '+label)
        if isinstance(v,dict) and v:
            for k,x in v.items():
                if not isinstance(k,str):raise ValueError('Exact-ratio keys must be text: '+label)
                validate_xml_text(k,label+' key',max_length=500);ratio_tree(x,label+'.'+k,depth+1)
        elif isinstance(v,(list,tuple)) and v:
            if len(v)==2 and all(type(x) is int for x in v):
                if v[1]<=0 or any(x.bit_length()>8192 for x in v):
                    raise ValueError('Bounded exact integers and positive denominator required: '+label)
            else:
                for i,x in enumerate(v):ratio_tree(x,f'{label}[{i}]',depth+1)
        else:raise ValueError('Lossless integer rational pair required: '+label)
    def walk(v, label, depth):
        if depth > 30: raise ValueError('JSON nesting limit exceeded: '+label)
        if isinstance(v,str): validate_xml_text(v,label,max_length=20000)
        elif v is None or type(v) is bool: pass
        elif type(v) in (int,float):
            try: valid=abs(v)<=1e100 and isfinite(v)
            except (OverflowError,ValueError): valid=False
            if not valid: raise ValueError('Finite supported numeric value required: '+label)
        elif isinstance(v,dict):
            for k,x in v.items():
                if not isinstance(k,str): raise ValueError('JSON object keys must be text: '+label)
                validate_xml_text(k,label+' key',max_length=500)
                if allow_exact_rationals and k.endswith(('_exact_ratio','_exact_ratios')):
                    ratio_tree(x,label+'.'+k,depth+1)
                else:walk(x,label+'.'+k,depth+1)
        elif isinstance(v,(list,tuple)):
            for i,x in enumerate(v): walk(x,f'{label}[{i}]',depth+1)
        else: raise ValueError('Unsupported JSON type: '+label)
    walk(value,path,0)
    return value


def _object(raw, expected, label):
    if not isinstance(raw,dict): raise ValueError(label+' must be an object')
    missing=set(expected)-set(raw); unknown=set(raw)-set(expected)
    if missing or unknown:
        raise ValueError(f'{label}: missing {sorted(missing)}; unknown {sorted(unknown)}')
    return dict(raw)


def _typed(cls, raw):
    return cls(**_object(raw,{f.name for f in fields(cls)},cls.__name__))


def _positive(value,label,zero=False):
    if type(value) not in (int,float) or not isfinite(value) or abs(value)>1e12 or (value<0 if zero else value<=0):
        raise ValueError(label+' must be finite and '+('nonnegative' if zero else 'positive'))
    return value


def _text(value,label):
    validate_xml_text(value,label)
    if not value.strip(): raise ValueError(label+' requires a source or explicit statement')
    return value


@dataclass(frozen=True)
class SourceRecord:
    status: str
    source: str
    def validate(self):
        if self.status not in SOURCE_STATUSES: raise ValueError('Source status must be reference, design_requirement or confirmed')
        _text(self.source,'Source record')
        return self


@dataclass(frozen=True)
class StructureInputs:
    span_m: float
    beam_end_left_mm: float
    beam_end_right_mm: float
    support_bearing_length_mm: float
    extra_dead_kn_per_m: float
    extra_dead_kind: str
    extra_dead_source: str
    def validate(self):
        for name in ('span_m','support_bearing_length_mm'): _positive(getattr(self,name),name)
        for name in ('beam_end_left_mm','beam_end_right_mm','extra_dead_kn_per_m'): _positive(getattr(self,name),name,zero=True)
        _text(self.extra_dead_source,'Extra permanent load, including declared zero')
        factors_8800('service_rare',psi=1.,extra_dead_kind=self.extra_dead_kind)
        return self


@dataclass(frozen=True)
class ModelInputs:
    physical_stiffeners: str
    ordinary_member_geometry: str
    nominal_basis: str
    root_geometry_basis: str
    root_geometry_source: str
    end_fork_basis: str
    end_fork_source: str
    support_model: str
    axial_support: str
    wheel_travel_scope: str
    support_contact: str


@dataclass(frozen=True)
class ActionInputs:
    hoist_class: str
    drive_class: str
    nominal_speed_m_s: float
    creep_speed_m_s: float | None
    hoist_classification_source: str
    equipment_group: str
    equipment_group_source: str
    horizontal_dynamic_factor: float
    horizontal_dynamic_source: str
    operating_scope: str
    operating_scope_source: str
    def validate(self):
        compute_hoist_dynamic(HoistDynamics(self.hoist_class,self.drive_class,self.nominal_speed_m_s,self.creep_speed_m_s,self.hoist_classification_source))
        mx_for_equipment_group(self.equipment_group)
        for name in ('equipment_group_source','horizontal_dynamic_source','operating_scope_source'): _text(getattr(self,name),name)
        if _positive(self.horizontal_dynamic_factor,'Horizontal dynamic factor')<1: raise ValueError('Horizontal characteristic amplification must be >=1')
        if self.operating_scope!='normal_gravity_horizontal_drive_only': raise ValueError('Only the explicitly bounded normal gravity/horizontal-drive operating domain is implemented')
        return self
    def dynamics(self):
        return compute_hoist_dynamic(HoistDynamics(self.hoist_class,self.drive_class,self.nominal_speed_m_s,self.creep_speed_m_s,self.hoist_classification_source))


@dataclass(frozen=True)
class TopWorkflowProject:
    schema: str
    identity: str
    label: str
    section_catalog_id: str
    structure: StructureInputs
    material: Material
    rail: RailInput
    bridge: TopBridgeInputs
    model: ModelInputs
    actions: ActionInputs
    sources: dict[str,SourceRecord]
    stability: StabilityPremises | None
    fatigue: ENPhysicalFatigueInputs | None
    service: dict | None
    nbr_fatigue: NBRFatiguePremises | None = None
    cmaa_fatigue: CMAAFatiguePremises | None = None
    nbr_service: NBR10084ServicePremises | None = None
    manual_service: ManualServiceLimits | None = None
    cmaa_actions: CMAAActionPremises | None = None
    nbr_rolling_guidance: NBRRollingGuidance | None = None
    verification_lengths: VerificationLengths | None = None

    intermediates: IntermediateInputs | None = None

    def to_dict(self):
        data=asdict(self)
        if self.intermediates is None:
            data.pop('intermediates')  # Preserve the old physical serialization.
        return data
    def validate(self):
        checked_tree(self.to_dict())
        expected_schema=SCHEMA if self.intermediates is None else INTERMEDIATE_SCHEMA
        if self.schema!=expected_schema: raise ValueError('Physical schema must match the explicit intermediate inventory')
        if self.intermediates is not None:
            if type(self.intermediates) is not IntermediateInputs:
                raise ValueError('Typed physical intermediate inputs required')
            self.intermediates.validate()

        if self.identity not in ('actual_project','synthetic_example'): raise ValueError('Explicit actual_project/synthetic_example identity required')
        _text(self.label,'Project label')
        if self.identity=='synthetic_example' and not self.label.lower().startswith(('synthetic','sintético','sintetico')):
            raise ValueError('Synthetic examples must be visibly named Synthetic/Sintético')
        self.structure.validate();self.actions.validate()
        _object(self.sources,SOURCE_GROUPS,'Source groups')
        for value in self.sources.values():
            if not isinstance(value,SourceRecord): raise ValueError('Typed source records required')
            value.validate()
        if not isinstance(self.bridge,TopBridgeInputs): raise ValueError('Physical bridge inputs required')
        TopBridgeInputs(**asdict(self.bridge))
        for name in ('fy_mpa','fu_mpa','E_mpa','G_mpa','gamma_a1'): _positive(getattr(self.material,name),name)
        _text(self.material.specification,'Material specification')
        if self.material.fy_mpa>self.material.fu_mpa: raise ValueError('fy cannot exceed fu')
        if self.material.gamma_a1<1: raise ValueError('Material resistance factor must be >=1')
        basis=self.basis();p=basis.validated_project()
        if self.verification_lengths is not None:
            if not isinstance(self.verification_lengths,VerificationLengths):
                raise ValueError('Typed independent resistance verification lengths required')
            self.verification_lengths.validate(self.structure.span_m*1000)
        errors=validate_autonomous(p)
        if errors: raise ValueError('; '.join(errors))
        if self.stability is not None: self.stability.validate()
        if self.fatigue is not None: self.fatigue.validate()
        if self.nbr_fatigue is not None: self.nbr_fatigue_physical()
        if self.cmaa_fatigue is not None: self.cmaa_fatigue_physical()
        if self.cmaa_actions is not None: self.cmaa_action_physical()
        if self.nbr_rolling_guidance is not None:
            if not isinstance(self.nbr_rolling_guidance,NBRRollingGuidance): raise ValueError('Typed NBR rolling-guidance declarations required')
            NBRRollingGuidance(**asdict(self.nbr_rolling_guidance))
            if self.rail.wheel_guidance!='flanged': raise ValueError('A topologia NBR declarada exige rodas com flange, sem roletes-guia separados.')
        for value,cls in ((self.nbr_service,NBR10084ServicePremises),(self.manual_service,ManualServiceLimits)):
            if value is not None:
                if not isinstance(value,cls): raise ValueError("Typed service declarations required")
                value.validate()
        if self.service is not None:
            from .service import CMAAServicePremises
            _typed(CMAAServicePremises,self.service).validate()
        return self

    def nbr_fatigue_physical(self):
        if self.nbr_fatigue is None: return None
        if not isinstance(self.nbr_fatigue,NBRFatiguePremises): raise ValueError("Typed NBR fatigue declarations required")
        section=section_from_profile(self.section_catalog_id)
        return self.nbr_fatigue.physical(fy_mpa=self.material.fy_mpa,fu_mpa=self.material.fu_mpa,
            flange_thickness_mm=section.tf_mm,web_thickness_mm=section.tw_mm,
            material_source=self.material.specification+"; "+self.sources["material"].source)

    def cmaa_action_physical(self):
        if self.cmaa_actions is None: return None
        if not isinstance(self.cmaa_actions,CMAAActionPremises): raise ValueError("Typed CMAA action declarations required")
        return self.cmaa_actions.physical(self.bridge)

    def cmaa_fatigue_physical(self):
        if self.cmaa_fatigue is None: return None
        if not isinstance(self.cmaa_fatigue,CMAAFatiguePremises): raise ValueError("Typed CMAA fatigue declarations required")
        f=self.cmaa_fatigue
        return f.physical(self.bridge),f.duty(),f.detail()

    def basis(self):
        """Private legacy adapter: no inherited physical wheel/plate/fatigue data."""
        s=self.structure;a=self.actions;m=self.model
        section=section_from_profile(self.section_catalog_id)
        p=AutonomousProject(section=section,material=deepcopy(self.material),material_grade='custom',
            demonstration=self.identity=='synthetic_example',span_m=s.span_m,rail=deepcopy(self.rail),
            wheels=[WheelInput(offset_m=0.,dead_kn=0.,lifted_kn=0.,transverse_kn=0.,longitudinal_kn=0.),
                    WheelInput(offset_m=self.bridge.carriage_station_spacing_mm/1000,dead_kn=0.,lifted_kn=0.,transverse_kn=0.,longitudinal_kn=0.)],
            fatigue=FatigueUse(life_years=0.,uses_per_year=0.,loaded_passages_per_use=0.,empty_passages_per_use=0.,component_group='E8_conservative',detail='inactive_not_used',stress_cycles_per_use=None,group_source='Inactive legacy storage; no cycles or E group used by this route'),
            extra_dead_kn_per_m=s.extra_dead_kn_per_m,beam_end_left_mm=s.beam_end_left_mm,beam_end_right_mm=s.beam_end_right_mm,
            support_bearing_length_mm=s.support_bearing_length_mm,upper_braces_m=[],lower_braces_m=[],lateral_only_braces_m=[],
            support_model=m.support_model,axial_support=m.axial_support,wheel_travel_scope=m.wheel_travel_scope,support_contact=m.support_contact,
            stiffener_layout='none_or_unknown',stiffener_spacing_m=1.,stiffener_thickness_mm=1.,stiffener_outstand_mm=0.,stiffener_connection='other_or_unknown',
            hoist_class=a.hoist_class,drive_class=a.drive_class,hoist_speed_m_s=a.nominal_speed_m_s,creep_speed_m_s=a.creep_speed_m_s or 0.,
            equipment_group=a.equipment_group,factor_basis='Internal separate source-ledger actions; no external effort input')
        source=self.sources['model']
        common=dict(physical_stiffeners=m.physical_stiffeners,ordinary_member_geometry=m.ordinary_member_geometry,
            nominal_basis=m.nominal_basis,premise_status={'design_requirement':'adopted'}.get(source.status,source.status),premise_source=source.source,
            root_geometry_basis=m.root_geometry_basis,root_geometry_source=m.root_geometry_source,end_fork_basis=m.end_fork_basis,end_fork_source=m.end_fork_source)
        if self.intermediates is None:
            return TopUnstiffenedBasis(p,**common)
        self.intermediates.validate_base_section(section,s.span_m*1000)
        self.intermediates.validate_base_material(self.material)
        self.intermediates.validate_project_sources(self)
        return TopIntermediateBasis(p,**common,detail_basis=INTERMEDIATE_DETAIL_BASIS,
            geometry_inputs_hash=self.intermediates.physical_geometry_hash(),geometry_source=self.intermediates.detail_source,
            stationary_bodies=self.intermediates.stationary_bodies())


def project_from_dict(raw):
    checked_tree(raw)
    compatible=dict(raw) if isinstance(raw,dict) else raw
    if isinstance(compatible,dict):
        # Old exports keep both new optional methods unrequested. No class or source is invented.
        compatible.setdefault('nbr_fatigue',None);compatible.setdefault('cmaa_fatigue',None)
        compatible.setdefault('nbr_service',None);compatible.setdefault('manual_service',None)
        compatible.setdefault('cmaa_actions',None);compatible.setdefault('nbr_rolling_guidance',None)
        compatible.setdefault('verification_lengths',None)
        compatible.setdefault('intermediates',None)
    d=_object(compatible,{f.name for f in fields(TopWorkflowProject)},'Top-running physical project')
    if isinstance(d.get('bridge'),dict) and 'mass_accounting_convention' not in d['bridge']:
        raise ValueError('Entrada antiga sem composição comum das massas suspensas. Revisar e declarar explicitamente carga útil e massa retida, inclusive zero; não há migração automática.')
    for key,cls in (('structure',StructureInputs),('material',Material),('rail',RailInput),('bridge',TopBridgeInputs),('model',ModelInputs),('actions',ActionInputs)):
        d[key]=_typed(cls,d[key])
    d['sources']={k:_typed(SourceRecord,v) for k,v in _object(d['sources'],SOURCE_GROUPS,'Source ledger').items()}
    for key,cls in (('stability',StabilityPremises),('fatigue',ENPhysicalFatigueInputs)):
        if d[key] is not None:d[key]=_typed(cls,d[key])
    for key,cls in (('nbr_fatigue',NBRFatiguePremises),('cmaa_fatigue',CMAAFatiguePremises)):
        if d[key] is not None: d[key]=exact_premises(cls,d[key])
    for key,cls in (('nbr_service',NBR10084ServicePremises),('manual_service',ManualServiceLimits)):
        if d[key] is not None: d[key]=_typed(cls,d[key]).validate()
    if d['cmaa_actions'] is not None: d['cmaa_actions']=_typed(CMAAActionPremises,d['cmaa_actions']).validate()
    if d['nbr_rolling_guidance'] is not None: d['nbr_rolling_guidance']=_typed(NBRRollingGuidance,d['nbr_rolling_guidance'])
    if d['verification_lengths'] is not None:
        d['verification_lengths']=VerificationLengths.from_dict(d['verification_lengths'])
    if d['intermediates'] is not None:
        d['intermediates']=IntermediateInputs.from_dict(d['intermediates'])
    return TopWorkflowProject(**d).validate()


def _unique_pairs(pairs):
    out={}
    for k,v in pairs:
        if k in out: raise ValueError('Duplicate JSON key: '+k)
        out[k]=v
    return out


def loads_project(payload):
    if isinstance(payload,bytes):payload=payload.decode('utf-8')
    raw=json.loads(payload,object_pairs_hook=_unique_pairs,parse_constant=lambda v:(_ for _ in ()).throw(ValueError('Nonfinite JSON number: '+v)))
    return unpack_project_document(raw)


def unpack_project_document(raw):
    checked_tree(raw,allow_exact_rationals=isinstance(raw,dict) and raw.get('format') in (CALCULATION_FORMAT,INTERMEDIATE_CALCULATION_FORMAT))
    if not isinstance(raw,dict):raise ValueError('Project document must be an object')
    if 'format' not in raw:
        return project_from_dict(raw),{}
    fmt=raw.get('format')
    if fmt not in (PROJECT_FORMAT,CALCULATION_FORMAT,INTERMEDIATE_PROJECT_FORMAT,INTERMEDIATE_CALCULATION_FORMAT) or type(raw.get('version')) is not int or raw['version']!=1:
        raise ValueError('Unrecognized top-running document wrapper identity/version')
    expected={'format','version','inputs','document_metadata'}|({'results'} if fmt in (CALCULATION_FORMAT,INTERMEDIATE_CALCULATION_FORMAT) else set())
    _object(raw,expected,'Project wrapper')
    # Results never become imported calculation evidence, even in a valid wrapper.
    project=project_from_dict(raw['inputs'])
    if (project.intermediates is not None)!=(fmt in (INTERMEDIATE_PROJECT_FORMAT,INTERMEDIATE_CALCULATION_FORMAT)):
        raise ValueError('Document wrapper and physical intermediate inventory disagree')
    return project,validate_document_metadata(raw['document_metadata'])


def project_document(project,metadata=None):
    project.validate()
    return dict(format=INTERMEDIATE_PROJECT_FORMAT if project.intermediates is not None else PROJECT_FORMAT,version=1,inputs=project.to_dict(),document_metadata=validate_document_metadata(metadata or {}))


def replace_catalog_profile(project,catalog_id):
    raw=project.to_dict();section=section_from_profile(catalog_id)
    raw['section_catalog_id']=section.catalog_id
    raw['model']['root_geometry_source']=section.property_source
    # Selection is a design requirement, never evidence of the installed section.
    raw['sources']['section']={'status':'design_requirement','source':section.property_source}
    return project_from_dict(raw)
