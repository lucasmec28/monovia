"""Readable navy Word report; current inputs/source/result identities required."""
from __future__ import annotations
from io import BytesIO
from dataclasses import asdict
from collections import defaultdict
from .pipeline import assert_current_result,presentation_receipt
from lro_beams.document_metadata import validate_document_metadata,DOCUMENT_FIELDS

FIELD_LABELS={'hoist_class':'Classe de içamento HC','drive_class':'Classe de acionamento HD','equipment_group':'Grupo de serviço A','width_mm':'Largura do trilho [mm]','height_mm':'Altura do trilho [mm]','inertia_cm4':'Inércia do trilho [cm⁴]','mass_kg_per_m':'Massa linear do trilho [kg/m]','lateral_eccentricity_mm':'Excentricidade lateral da roda [mm]','offset_from_web_mm':'Deslocamento do trilho da alma [mm]','wheel_rail_clearance_mm':'Folga roda trilho [mm]','head_width_mm':'Largura da cabeça do trilho [mm]','specification':'Especificação do material','extra_dead_source':'Fonte da carga permanente adicional','extra_dead_kind':'Natureza da carga permanente adicional','property_source':'Fonte das propriedades','catalog_id':'Registro de catálogo','shape':'Forma do trilho','attachment':'Composição do trilho','wheel_guidance':'Guiamento das rodas','local_attachment':'Fixação local do trilho','continuity':'Continuidade do trilho'}
CHECK_LABELS={'nominal_normal_yield':'Tensão normal nominal','major_local_bending':'Flexão maior local','equivalent_minor_local_bending':'Flexão menor equivalente','bare_web_vertical_shear':'Cisalhamento vertical na alma','top_flange_lateral_shear':'Cisalhamento lateral na mesa superior','bottom_flange_lateral_shear':'Cisalhamento lateral na mesa inferior','gross_axial_tension_yield':'Escoamento da seção bruta em tração','isolated_axial_compression':'Compressão axial isolada','nominal_shear_model_box':'Limite nominal de cisalhamento','all_wheels_yield':'Todas as rodas, escoamento','all_wheels_cripple':'Todas as rodas, enrugamento','supplementary_C1':'Interação complementar C1','supplementary_C2':'Interação complementar C2','CMAA74_vertical':'Deslocamento vertical CMAA74','CMAA74_horizontal':'Deslocamento lateral CMAA74','principal_range':'Variação de tensão principal Δσ','direct_range':'Variação de tensão direta Δσ','shear_range':'Variação de tensão de cisalhamento Δτ'}
CMAA_FAMILY_CASE='CMAA74_COMMON_FAMILY_BOUND'
NBR_FATIGUE_CASE='NBR8400_CLASSIFIED_LIFE_NOMINAL_BOUND'
BOUND_NOT_PROVEN='Seção não comprovada pelo critério conservador adotado; refinar ou aumentar seção'
STATUS_LABELS={'SATISFIED':'Critério atendido','FAIL':'Falha identificada no critério avaliado','PENDING':'Verificação pendente / não executada','INCONCLUSIVE':BOUND_NOT_PROVEN}

CHECK_LABELS.update({'NBR10084_vertical':'Deslocamento vertical NBR 10084','NBR10084_horizontal':'Deslocamento lateral NBR 10084',
    'MANUAL_CMAA74_vertical':'Restrição vertical de projeto sobre a base CMAA','MANUAL_CMAA74_horizontal':'Restrição lateral de projeto sobre a base CMAA',
    'MANUAL_NBR10084_vertical':'Restrição vertical de projeto sobre a base NBR','MANUAL_NBR10084_horizontal':'Restrição lateral de projeto sobre a base NBR'})


VALUE_LABELS={'steel_or_equipment':'Aço ou equipamento','rectangular_demonstration':'Retangular explicitamente informado','catalog_or_manufacturer':'Propriedades de catálogo ou fabricante','verified_catalog':'Catálogo verificado','non_composite':'Sem composição resistente','flanged':'Rodas com flange','guide_roller_unguided_side':'Guiamento por roletes','non_rigid':'Não rígida','continuous_no_joint':'Contínuo sem junta','free_suspended_at_crab':'Carga livre suspensa pelo carro','guided_rigid_payload_cg':'Carga rígida guiada pelo CG declarado','adopted_bilinear_four_contact_no_diagonal_self_stress':'Partilha bilinear igualizada em quatro contatos','normal_gravity_horizontal_drive_only':'Somente gravidade e acionamentos horizontais normais','payload_plus_retained_suspended_mass':'Carga útil nominal mais massa suspensa retida separada','legacy_all_lifted_removed_when_empty':'Convenção legada: parcela içada removida no vazio, massa retida desconhecida'}

VALUE_LABELS.update(dict(indoor_no_operating_wind='Operação interna sem vento operacional',normal_non_abrupt='Engate normal, não brusco',
    single_girder_under_running_trolley='Ponte de uma viga com carro suspenso',
    not_established_adopted_nominal_method='Configuração não estabelecida; método nominal CMAA adotado explicitamente'))


def fmt(value):
    if value is None:return 'Não informado'
    if isinstance(value,bool):return 'Sim' if value else 'Não'
    if isinstance(value,(int,float)):
        if value and (abs(value)<.001 or abs(value)>=1e9):return f'{value:.2e}'.replace('.',',')
        return f'{value:,.3f}'.rstrip('0').rstrip('.').replace(',','~').replace('.',',').replace('~','.')
    return VALUE_LABELS.get(str(value),str(value))


def field_label(key):
    from .ui import LABELS
    return FIELD_LABELS.get(key,LABELS.get(key,key.replace('_',' ')))


def check_label(row):
    key=row['id'];label=row.get('label') or CHECK_LABELS.get(key)
    if label is None and key.startswith('support_'):
        label=key.replace('support_left','Apoio esquerdo').replace('support_right','Apoio direito').replace('contact_uplift','perda de contato').replace('actual','testemunho').replace('yield','escoamento').replace('cripple','enrugamento').replace('opposed','compressão oposta').replace('_bound','').replace('_',' ')
    label=label or key.replace('_',' ')
    return label+(' ['+row['unit']+']' if row.get('unit') else '')


def check_status(value):
    value=str(value)
    if value in ('PASS','SATISFIED','NOMINAL_METHOD_ZERO_CALCULATED_DAMAGE_SUFFICIENT') or ('SATISFIED' in value and 'NOT_SATISFIED' not in value):return 'Critério atendido'
    if value=='FAIL':return 'Falha identificada no critério avaliado'
    if value=='CMAA74_LONGITUDINAL_RANGE_WITNESSED_EXCEEDANCE':return 'Limite excedido entre estados declarados calculados; não é previsão de falha física'
    if value=='CMAA74_LONGITUDINAL_RANGE_SUFFICIENT':return 'Critério atendido'
    if 'INCONCLUSIVE' in value or 'NOT_SATISFIED' in value:return BOUND_NOT_PROVEN
    return 'Verificação pendente / não executada'


def report_status(value):
    """Compact presentation only; the full bound explanation appears once."""
    status=check_status(value)
    return 'Inconclusivo' if status==BOUND_NOT_PROVEN else status


def _fatigue_number(value):
    """Keep the selected dimensionless fatigue interaction distinguishable."""
    if isinstance(value,(int,float)) and not isinstance(value,bool):
        return f'{value:.7f}'.rstrip('0').rstrip('.').replace('.',',')
    return fmt(value)


def _fiber_label(value):
    parts=str(value).split('_')
    if len(parts)==3 and parts[0] in ('top','bottom') and parts[1] in ('inner','outer') and parts[2] in ('left','right'):
        return ('Mesa '+{'top':'superior','bottom':'inferior'}[parts[0]]+', face '+
            {'inner':'interna','outer':'externa'}[parts[1]]+', borda '+{'left':'esquerda','right':'direita'}[parts[2]])
    return str(value)


def governing_check_rows(result):
    """Never mix demand and capacity from separate checks/states."""
    groups={}
    def add(case,scope,record,translation=None):
        for check in record.get('checks',[]):
            u=check.get('utilization')
            if not isinstance(u,(int,float)) and not check.get('actual_failure_proven'):continue
            key=(scope,check.get('id','unnamed'),bool(check.get('sufficient_bound',False)))
            row=dict(scope=scope,id=key[1],demand=check.get('demand'),capacity=check.get('capacity'),utilization=u,
                status=check.get('status'),unit=check.get('unit',''),sufficient_bound=key[2],case_id=case,translation_m=translation,source=check.get('source',''))
            score=float('inf') if u is None else u
            old=groups.get(key,{}).get('utilization')
            if key not in groups or score>(float('inf') if old is None else old):groups[key]=row
    selected_components=result.get('assessed_section_components')
    case_scopes=('bare_web','stability') if selected_components is not None else ('strength','bare_web','stability')
    for case in result.get('cases',[]):
        for scope in case_scopes:add(case['id'],scope,case.get(scope,{}))
        for witness in case.get('witnesses',[]):
            for scope in (('bare_web',) if selected_components is not None else ('strength','bare_web')):add(case['id'],scope,witness.get(scope,{}),witness['translation_m'])
    if selected_components is not None:
        add('CMAA74_ASSESSED_SECTION_COMPONENTS','strength',selected_components)
    cmaa=result.get('cmaa_strength')
    if cmaa is not None:
        add(CMAA_FAMILY_CASE,'stability',cmaa.get('stability',{}))
    for check in (result.get('service') or {}).get('checks',[]):
        groups[('service',check['id'],True)]=dict(scope='service',id=check['id'],unit='mm',demand=check.get('upper_bound_mm'),capacity=check.get('limit_mm'),utilization=check['utilization'],status=check['status'],sufficient_bound=True,case_id=check.get('governing_bound_case','CMAA service'),translation_m=None,source=check.get('source',''))
    fatigue=result.get('fatigue') or {}
    for name,demand,capacity in (('principal_range','principal_range_mpa','normal_vafl_design_mpa'),('direct_range','direct_range_mpa','normal_vafl_design_mpa'),('shear_range','shear_range_mpa','shear_vafl_design_mpa')):
        if fatigue.get(capacity):
            u=fatigue[demand]/fatigue[capacity]
            groups[('fatigue',name,True)]=dict(scope='fatigue',id=name,unit='MPa',demand=fatigue[demand],capacity=fatigue[capacity],utilization=u,status='SATISFIED' if u<1 else 'INCONCLUSIVE',sufficient_bound=True,case_id='Separate EN physical operating domain',translation_m=None,source=fatigue.get('source',''))
    rows=list(groups.values())
    if cmaa is not None:
        for row in rows:
            if row['scope']=='stability':row['source_short_label']='EN C.2 · família CMAA74'
            elif row['scope'] in ('strength','bare_web'):row['source_short_label']='NBR8800/CISC · ações CMAA74'
    return rows


def primary_governing_check_rows(result):
    """Select Word governors without altering the complete diagnostic helper.

    NBR and EN are alternative nominal fatigue methods, not cumulative gates.
    Each NBR row retains the recorded utilization and status of its own wall;
    pooled bounds are never presented as a physical governing position.
    """
    rows=governing_check_rows(result)
    if result.get('selected_fatigue_method')!='NBR8400_classified_life_nominal':
        return rows
    rows=[row for row in rows if row['scope']!='fatigue']
    for index,record in enumerate((result.get('nbr_fatigue') or {}).get('point_results',[])):
        plane=record.get('input',{}).get('plane',{})
        point=plane.get('point_id','')
        region={'top_uniform_fixed_material_point_bound':'mesa superior',
                'bottom_uniform_fixed_material_point_bound':'mesa inferior',
                'web_uniform_fixed_material_point_bound':'alma'}.get(point,point or 'região nominal '+str(index+1))
        utilization=(record.get('bound') or {}).get('combined_utilization_upper_bound')
        rows.append(dict(scope='nbr_fatigue',id='nbr_fatigue_'+str(index),
            label='Fadiga NBR D.5 · '+region+' (U)',unit='',
            demand=utilization,capacity=1. if utilization is not None else None,utilization=utilization,
            status='FAIL' if record.get('actual_failure_proven') else record.get('status','PENDING'),
            sufficient_bound=True,case_id=NBR_FATIGUE_CASE,translation_m=None,
            source=plane.get('action_source','')))
    return rows


def scope_status(scope_id, row):
    """Presentation only: exact external scope IDs, never erase a known failure."""
    if scope_id in ('rail_contact', 'support_connections', 'receiving_structure'):
        if row.get('actual_failure_proven') or row.get('status') == 'FAIL':
            return 'Fora do escopo principal; falha registrada no diagnóstico separado'
        if row.get('status') == 'SATISFIED':
            return 'Fora do escopo principal; resultado separado: critério atendido'
        return 'Fora do escopo; não verificado'
    return report_status(row.get('status', 'PENDING'))


def report_is_partial(result):
    """Execution completeness is separate from resistance adequacy.

    This is presentation only, after the caller's current-result guard. A FAIL
    can coexist with unresolved checks; neither FAIL nor an exceeded sufficient
    bound is, by itself, a missing calculation or a reason to block export.
    """
    if (result.get('route_execution_complete') is False or result.get('errors')
            or result.get('assessed_member_scope_status') not in ('SATISFIED','PASS','FAIL','INCONCLUSIVE')):
        return True
    scopes=result.get('scopes',{})
    keys=result.get('scope_groups',{}).get('assessed_member')
    if keys is None:
        external={'rail_contact','support_connections','receiving_structure','special_actions','normal_contact_domain','cmaa_complete_coverage'}
        keys=[key for key in scopes if key not in external]
    if not keys:return result.get('route_execution_complete') is not True
    for key in keys:
        row=scopes.get(key,{})
        if (row.get('status') not in ('SATISFIED','PASS','FAIL','INCONCLUSIVE')
                or row.get('verification_executed') is False or row.get('pending') or row.get('errors')
                or row.get('outcome_counts',{}).get('PENDING',0)):
            return True
    return False


def report_execution_note(result):
    if report_is_partial(result):
        return ('Avaliação parcial: há verificações pendentes ou interrompidas. Este relatório preserva os critérios já avaliados, '
            'mas não constitui memória completa do escopo avaliado.')
    return ('Avaliação executada no escopo declarado; não equivale à aprovação do projeto. '
        'A memória registra critérios atendidos, falhas e resultados inconclusivos.')


def report_sections(project,result,metadata=None):
    assert_current_result(project,result);metadata=validate_document_metadata(metadata or {})
    if project.intermediates is not None:
        return _intermediate_main_report_sections(project,result,metadata)
    p=project.basis().validated_project()
    cmaa=result.get('cmaa_strength')
    rows=primary_governing_check_rows(result)
    cases_by_id={c['id']:c for c in result.get('cases',[])}
    unique_ids=list(dict.fromkeys(r['case_id'] for r in rows));aliases={key:f'C{i+1:02d}' for i,key in enumerate(unique_ids)}
    legends=[]
    for key in unique_ids:
        c=cases_by_id.get(key)
        if key==CMAA_FAMILY_CASE:
            description='Estabilidade complementar EN C.2 sobre o limite comum de toda a família CMAA74/NBR8800. Máximos independentes dos componentes, raio desestabilizante e carga permanente; não é um canto SK, vetor concomitante de reações nem posição física crítica.'
        elif key==NBR_FATIGUE_CASE:
            description='Fadiga selecionada NBR 8400-2, caso I e vida classificada finita. Limites por parede nominal em ponto material fixo; U é a utilização equivalente da interação D.5, com limite 1. A união dos estados e pares de ações não é tensor concomitante, história de ciclos nem posição física crítica.'
        elif c and c.get('box_design_case'):
            f=c['factors']
            description=f"Origens CMAA 74:2020 → ELU NBR8800; via {'esquerda' if c['rail_index']==0 else 'direita'}; {'carregada' if c['loaded'] else 'vazia, com massa retida'}; gancho {fmt(c['hook_mm'])} mm; altura {fmt(c['transfer_height_mm'])} mm; IFDx {c['longitudinal_sign']:+d}, IFDy {c['transverse_sign']:+d}; coordenadas independentes SK {fmt(c['skew_coordinates'][0])}/{fmt(c['skew_coordinates'][1])}; {'família variável presente' if c['crane_variable_present'] else 'somente parcelas permanentes'}. Fatores G suporte/equipamento/adicional {fmt(f['dead_support'])}/{fmt(f['dead_equipment'])}/{fmt(f['extra_dead'])}; LL/IFDx/IFDy {fmt(f['lifted'])}/{fmt(f['longitudinal'])}/{fmt(f['transverse'])}; psi adicional 1. Canto do limite suficiente, não testemunho físico."
        elif c:
            f=c['source_factors'];record=next(v for v in result['physical_domain']['records'] if v['id']==c['record_id'])
            description=f"ELU NBR8800; via {'esquerda' if c['rail_index']==0 else 'direita'}; {'carregada' if c['loaded'] else 'vazia'}; gancho {fmt(record['hook_mm'])} mm; altura de transferência {fmt(record['force_height_mm'])} mm; Hx {c['longitudinal_sign']:+d}, Hy {c['transverse_sign']:+d}; fatores G suporte/equipamento {fmt(f['dead_support'])}/{fmt(f['dead_equipment'])}, Q {fmt(f['lifted'])}, H {fmt(f['transverse'])}."
        elif key.startswith('CMAA'):
            tags=key.split('/')
            description='Serviço CMAA74 sem impacto vertical; '+('; '.join({'hook0':'gancho no extremo mínimo','hook1':'gancho no extremo máximo','height0':'altura no extremo mínimo','height1':'altura no extremo máximo','rail0':'via esquerda','rail1':'via direita','loaded':'carregada','empty':'vazia','horizontal':'direção lateral','vertical':'direção vertical','+0':'sem força lateral','+1':'sentido positivo','-1':'sentido negativo'}.get(v,v) for v in tags[2:]))+'.'
        elif key.startswith('NBR10084'):
            description='Serviço NBR 10084 incremental no topo real do trilho, desde o peso próprio do mesmo modelo; gravidade, vetores físicos m·a e pares normais HX/HY/Rλ, sem impacto ou majoração. Rλ é um intervalo conservador, não um vetor concomitante testemunhado. Caso de limite: '+key+'.'
        else:description='Fadiga EN: domínio físico operacional completo, com fatores e ciclos tratados separadamente do ELU.'
        legends.append([aliases[key],description])
    identity='EXEMPLO SINTÉTICO. NÃO É UM PROJETO REAL.' if project.identity=='synthetic_example' else 'PROJETO INFORMADO. Fontes e premissas não equivalem a verificação executada.'
    sections=[dict(title='1. Identificação e conclusão',paragraphs=[identity,project.label,
        'Escopo de viga avaliado: '+report_status(result['assessed_member_scope_status'])+'.',
        report_execution_note(result),
        'Ligações de apoio, inclusive a ligação viga–piso, rodas e estrutura receptora estão fora do escopo desta avaliação e não são declaradas verificadas. Sua exclusão não altera os critérios nem as condições físicas de apoio adotadas.',('Base híbrida adotada: origens características CMAA 74:2020, incluindo SK normal como limite independente; ELU NBR8800 complementar com psi adicional 1; analogia de mesas CISC e estabilidade EN C.2 sobre a família completa. Fadiga e serviço têm métodos próprios. Não constitui conformidade integral CMAA.' if cmaa is not None else 'Base híbrida adotada: ações físicas internas; componentes ELU NBR8800; analogia nominal de mesas CISC; estabilidade complementar EN; fadiga e serviço nos métodos declarados; somente critérios CMAA explicitamente implementados. Não constitui conformidade integral CMAA.'),
        'Escopo desta memória: critérios nominais da viga de rolamento sem enrijecedores, no domínio geométrico e operacional declarado. Permanecem obrigatórias a validade dos apoios adotados, as verificações locais do trecho de rolamento e as ações aplicáveis a esse domínio.',
        'Inconclusivo: '+BOUND_NOT_PROVEN+'. Os limites analíticos cobrem todas as posições no modelo declarado. Exceder um limite suficiente não prova falha real.',
        'Atender aos critérios nominais calculados não comprova todos os detalhes da viga. Regiões perturbadas, concentrações locais e demais efeitos não cobertos pelo modelo continuam sujeitos à verificação aplicável.',
        ('Os cantos SK são casos matemáticos de limite, não testemunhos físicos. Não se apresentam reações concomitantes ou falha física a partir desses cantos. A interação de estabilidade usa um limite comum da família, não o máximo das utilizações nos cantos.' if cmaa is not None else 'Os estados testemunhos calculados em eventos e pontos intermediários podem provar falha. Não comprovam o máximo global de interações não lineares.')],
        headers=['Campo','Identificação'],rows=[[DOCUMENT_FIELDS[k],v] for k,v in metadata.items()]),
        dict(title='2. Situação por escopo',paragraphs=['Uma falha identificada continua visível mesmo com outros módulos pendentes. Limite superior excedido não é chamado de falha.'],
            headers=['Escopo','Resultado'],rows=[[v['label'],scope_status(k,v)] for k,v in result['scopes'].items()]),
        dict(title='3. Modelo físico e rastreabilidade',paragraphs=[
            'Sem enrijecedores: zero pares, zero peso e zero crédito de rigidez. Perfil laminado duplamente simétrico, sem modificações. A forquilha real/de projeto deve impedir translação lateral e giro de torção, permitir empenamento e respeitar a ancoragem axial declarada.',
            'O trilho não compõe a seção resistente. Nenhum resultado Robot ou esforço externo foi usado. Campos legados inativos não fornecem cargas, ciclos ou placas.',
            'Status da fonte: referência = comparação; requisito de projeto = deve ser realizado; confirmado = dado informado como confirmado, sem substituição do cálculo.'],
            headers=['Grupo','Status da fonte','Origem'],rows=[[{'structure':'Viga','section':'Perfil','material':'Material','rail':'Trilho','bridge':'Ponte','actions':'Ações','model':'Modelo'}.get(k,k),{'reference':'Referência','design_requirement':'Requisito de projeto','confirmed':'Confirmado'}.get(v.status,v.status),v.source] for k,v in project.sources.items()]),
        dict(title='4. Viga, trilho e material',paragraphs=[f'Perfil: {p.section.name}. {p.section.property_source}',project.material.specification],
            headers=['Dado','Valor'],rows=[[field_label(k),fmt(v)] for k,v in asdict(project.structure).items()]+[[field_label(k),fmt(v)] for k,v in asdict(project.material).items()]+[[field_label(k),fmt(v)] for k,v in asdict(project.rail).items()]),
        dict(title='5. Ponte e geração de ações',paragraphs=[
            f"{result['physical_endpoint_records']} extremos físicos de gancho/altura; {result['physical_runway_configurations']} configurações considerando as duas vias; {result['generated_case_count']} "+('casos de limite ELU com cantos SK independentes.' if cmaa is not None else 'combinações ELU geradas.'),
            ('CMAA: DL/TL com DLF próprios; carga útil e massa retida com 1+HLF; vetores IFD completos e SK característico recebem os fatores NBR uma única vez. Não se majora novamente um tensor CMAA Case 2 nem se aplica o psi de içamento NBR. SK atua no topo real do trilho.' if cmaa is not None else 'Todas as combinações incluem extremos declarados, carregado/vazio, sentidos de Hx/Hy e origens permanentes favoráveis/desfavoráveis. Os vetores correlacionados já majorados não recebem fatores duas vezes.'),
            'A família ELU e os métodos de fadiga têm fontes e fatores separados. Os limites nominais de fadiga não são alimentados por esforços ELU. A classe CMAA de serviço/fadiga não substitui as premissas físicas de ações.',
            'A partilha igualizada de quatro contatos é uma premissa do modelo, não uma certificação do hardware da ponte.',
            *suspended_mass_premises(project)],
            headers=['Dado físico / adoção','Valor'],rows=[[('Parcela içada removível declarada, convenção legada [t métricas]' if k=='capacity_t' and project.bridge.mass_accounting_convention=='legacy_all_lifted_removed_when_empty' else field_label(k)),('Não aplicável neste modelo' if v is None and (k.startswith('lifted_cg') or k.startswith('suspension_point')) else fmt(v))] for k,v in asdict(project.bridge).items()]+[[field_label(k),fmt(v)] for k,v in asdict(project.cmaa_actions if cmaa is not None else project.actions).items()]),
        dict(title='6. Verificações governantes',paragraphs=['Cada linha mantém demanda, resistência, utilização e caso da mesma verificação. Testemunhos são estados efetivamente calculados; limites são envelopes suficientes.',
            *(['A fadiga governante é a NBR 8400-2 selecionada. A alternativa EN VAFL está separada como diagnóstico informativo, sem veto cumulativo. U é adimensional e tem limite 1; os valores detalhados por parede estão na seção de fadiga NBR.'] if result.get('selected_fatigue_method')=='NBR8400_classified_life_nominal' else [])],
            headers=['Verificação e unidade','Demanda','Resistência','Uso','Caso e resultado'],
            rows=[[check_label(r)+(' · '+r['source_short_label'] if r.get('source_short_label') else ''),fmt(r['demand']),fmt(r['capacity']),('Não disponível' if r['utilization'] is None and r['capacity'] is None else 'Sem resistência' if r['utilization'] is None else ('<0,01%' if 0<r['utilization']<.0001 else f"{100*r['utilization']:.2f}%".replace('.',','))),aliases[r['case_id']]+' · '+('Limite' if r['sufficient_bound'] else 'Testemunho')+' / '+report_status(r['status'])] for r in rows]),
        dict(title='7. Legenda dos casos governantes',paragraphs=['Os códigos curtos identificam os mesmos casos da tabela anterior. Os identificadores integrais, vetores e fatores são preservados no JSON. Limites suficientes cobrem todas as posições e não atribuem uma falsa posição governante.'],headers=['Caso','Configuração e origem'],rows=legends),
        dict(title='7b Fontes efetivamente usadas',paragraphs=sorted({str(r['source']) for r in rows if r.get('source')}),headers=[],rows=[]),
        dict(title='8. Fadiga, serviço e pendências',paragraphs=[
            ('Fadiga selecionada para o membro: NBR 8400-2 de vida classificada finita. A alternativa EN, se calculada, é informativa e não atua como veto cumulativo.' if result.get('selected_fatigue_method')=='NBR8400_classified_life_nominal' else 'Fadiga complementar EN, condição VAFL independente: '+report_status(result.get('fatigue',{}).get('status','PENDING'))+'. Isso não certifica contato rolante nem vida ilimitada física.' if result.get('selected_fatigue_method')=='EN2025_zero_damage_sufficient' else 'Fadiga do membro pendente: nenhum método multiaxial foi declarado. A comparação longitudinal CMAA, se presente, não encerra esta obrigação.'),
            *complementary_premises(project),
            'Conjunto dos critérios de serviço no vão entre forquilhas: '+report_status((result.get('service') or {}).get('status','PENDING'))+'. As pontas físicas e movimentos dos apoios permanecem separados.',
            *[v['label']+': '+pending_text(reason) for v in result['scopes'].values() for reason in v.get('pending',[])],
            'A ausência de uma tensão transversal local 3D nesta analogia não significa tensão física nula. Contato roda/trilho, fixações, detalhes de ligação e eventos fora do domínio permanecem separados.'],headers=[],rows=[]),
        dict(title='9. Integridade e reprodução',paragraphs=[
            'Assinaturas completas no JSON associado. Prefixos de conferência: entradas '+result['project_signature'][:12]+'; fontes '+result['source_receipt']['sha256'][:12]+'; resultado '+result['result_signature'][:12]+'; apresentação '+presentation_receipt()['sha256'][:12]+'.',
            'A exportação foi validada contra entradas, resultado e arquivos de cálculo atuais. Alterações exigem recálculo. O JSON associado conserva os vetores, fontes e resultados detalhados.'],headers=[],rows=[])]
    from underslung_runway_candidate.autonomous_ui.family_report import nbr_fatigue_section
    if project.nbr_fatigue is not None:
        record=nbr_fatigue_section(result.get('nbr_fatigue'),project.nbr_fatigue_physical(),title='8b. Fadiga NBR 8400-2, vida classificada finita')
        record['paragraphs'][0]=report_status((result.get('nbr_fatigue') or {}).get('status','PENDING'))+'.'
        rows=record.pop('rows');record['headers']=list(rows[0]) if rows else []
        if rows:
            record['headers'][3]='Utilização equivalente U ≤ 1'
            for row,point in zip(rows,(result.get('nbr_fatigue') or {}).get('point_results',[])):
                bound=point.get('bound') or {}
                row['Interação D.5: Q ≤ 1']=_fatigue_number(bound.get('Q_upper_bound'))
                row['Utilização equivalente']=_fatigue_number(bound.get('combined_utilization_upper_bound'))
                row['Situação']=report_status('FAIL' if point.get('actual_failure_proven') else point.get('status','PENDING'))
        record['rows']=[list(row.values()) for row in rows]
        sections.insert(-1,record)
    if project.cmaa_fatigue is not None:
        f=project.cmaa_fatigue;c=result.get('cmaa_fatigue') or {}
        rows=[[str(row.get('rail_index',0)+1),_fiber_label(row.get('fiber','')),fmt(row.get('range_upper_mpa')),fmt((c.get('allowable') or {}).get('mpa')),fmt(100*row['utilization_upper'])+' %'] for row in c.get('ranges',[]) if row.get('utilization_upper') is not None]
        sections.insert(-1,dict(title='8c. Fadiga CMAA 74, comparação escalar independente',paragraphs=[
            report_status(c.get('status','PENDING'))+'.',
            ('Classe CMAA: '+f.service_class+'.' if f.classification_kind=='manual_code_selection' else
             ('Classe D adotada conservadoramente como requisito, não derivada de ciclos.' if f.classification_kind=='adopted_conservative_D' else 'Classe documentada '+f.service_class+'.')+' Fonte: '+f.classification_source),
            'Comparação da variação longitudinal nominal Δσ = σmáx − σmín em material-base laminado ordinário. Não substitui o procedimento multiaxial complementar selecionado e não aprova isoladamente a fadiga do membro.',
            'Velocidades ponte/carro/içamento: '+ ' / '.join(fmt(v) for v in (f.bridge_travel_speed_m_s,f.trolley_travel_speed_m_s,f.hoist_speed_m_s))+' m/s. '+f.physical_source,
            'Massa suspensa retida e seu CG seguem a composição comum, sem duplicação. Detalhe e ambiente: '+f.detail_source],
            headers=['Via','Fibra','Variação Δσ limitada [MPa]','Limite [MPa]','Utilização'],rows=rows))
    if result.get('selected_fatigue_method')=='NBR8400_classified_life_nominal' and (project.fatigue is not None or result.get('fatigue')):
        alternative=result.get('fatigue') or {}
        en_rows=[row for row in governing_check_rows(result) if row['scope']=='fatigue']
        sections.insert(-1,dict(title='8d. Fadiga EN VAFL, diagnóstico alternativo informativo',paragraphs=[
            'Método alternativo opcional, não selecionado para a conclusão do membro. Seus limites não se somam à fadiga NBR e não constituem veto cumulativo.',
            'Resultado do diagnóstico EN: '+report_status(alternative.get('status','PENDING'))+'. Não certifica contato rolante nem vida ilimitada física.',
            *_en_fatigue_premises(project),
            *[pending_text(reason) for reason in alternative.get('pending',[])],
            *sorted({str(row['source']) for row in en_rows if row.get('source')})],
            headers=['Verificação','Demanda [MPa]','Limite [MPa]','Uso','Diagnóstico'],
            rows=[[CHECK_LABELS.get(row['id'],row['id']),fmt(row['demand']),fmt(row['capacity']),f"{100*row['utilization']:.2f}%".replace('.',','),report_status(row['status'])] for row in en_rows]))
    return sections



def _intermediate_input_rows(data):
    """Client values only; verbatim provenance stays in the unchanged input JSON."""
    rows=[]
    for key,value in data.items():
        if key.endswith('_source') or key in ('property_source','catalog_id'):
            continue
        if key=='specification' and isinstance(value,str) and value.lower().startswith('synthetic'):
            value='Material adotado no exemplo; propriedades nominais indicadas nesta tabela.'
        if value is None and key.startswith(('lifted_cg','suspension_point','retained_suspended_cg')):
            value='Não aplicável neste modelo'
        rows.append([field_label(key),fmt(value)])
    return rows


def _intermediate_method_notes(project):
    """Compact physical/method inputs, without modifying their source records."""
    lines=suspended_mass_premises(project)[:2]
    # Translate this catalog identifier only when it is actually present in the
    # supplied provenance. Never assign this manufacturer to another fixture.
    import re
    catalog=re.search(r'\bMUNCK-(SG-[A-Za-z0-9_.-]+)',project.bridge.geometry_mass_cg_source)
    if catalog:
        lines.insert(0,'Referência de catálogo do exemplo: MUNCK, modelo '+catalog.group(1)+', para massas, faixa de vão, entre-eixos e aproximações. Não confirma o equipamento nem os CGs adotados separadamente.')
    v=project.verification_lengths
    if v is not None:
        lines.append('Comprimentos de verificação: eixo forte '+fmt(v.major_flexural_mm)+' mm; eixo fraco '+fmt(v.minor_flexural_mm)+' mm; torção '+fmt(v.torsional_mm)+' mm; FLT '+fmt(v.lateral_torsional_mm)+' mm. Vão da análise '+fmt(project.structure.span_m*1000)+' mm. Estes parâmetros não alteram solicitações, apoios ou flechas.')
    if project.stability:
        lines.append('Estabilidade EN C.2: coeficiente de resistência '+fmt(project.stability.resistance_gamma)+'; aço estrutural em temperatura ambiente.')
    if project.cmaa_fatigue:
        lines.append('Classe de serviço CMAA: '+project.cmaa_fatigue.service_class+'.')
    if project.nbr_fatigue:
        lines.append('Grupo de componente NBR: '+project.nbr_fatigue.component_group+'; relação conservadora entre extremos κ = −1. As categorias direcionais de cada detalhe são avaliadas separadamente.')
    if project.nbr_rolling_guidance is not None:
        lines.append('Rolamento NBR: quatro rodas com flange, duas estações longitudinais e duas vias, sem bogies nem guias separados. Avaliam-se os pares HX/HY, HX/Rλ e HY/Rλ; p/a usa o vão entre vias e o entre-eixos físicos. Rλ não é o SK CMAA nem o evento excepcional SHE. A referência vertical adotada inclui os estados estáticos e os efeitos de inércia selecionados.')
    elif project.nbr_fatigue is not None or project.nbr_service is not None:
        lines.append('Rolamento NBR: topologia física ou referência vertical não declaradas; a verificação correspondente permanece pendente.')
    if project.nbr_service:
        n=project.nbr_service
        category={'siderurgical_equipment':'equipamento siderúrgico: vertical L/1000, máximo 25 mm','other_equipment':'demais equipamentos: vertical L/600, máximo 25 mm','unclassified_adopt_stricter_L1000':'categoria não estabelecida: adotado vertical L/1000, máximo 25 mm'}[n.equipment_category]
        lines.append('Serviço NBR 10084: '+category+'; lateral L/600. Flechas incrementais no topo real do trilho desde o peso próprio da estrutura de suporte, no mesmo modelo. Operação normal sem vento, acelerações m·a sem amplificação dinâmica e os três pares horizontais com Rλ.')
    if project.manual_service:
        m=project.manual_service
        lines.append('Limites adicionais de projeto: vertical '+('L/'+fmt(m.vertical_ratio) if m.vertical_ratio is not None else 'não solicitado')+'; lateral '+('L/'+fmt(m.horizontal_ratio) if m.horizontal_ratio is not None else 'não solicitado')+'. Aplicados a cada base NBR/CMAA sem relaxar os limites originais ou tetos absolutos.')
    if project.service:
        baseline={'include_permanent_absolute_bound':'incluído o limite absoluto da carga permanente','wheel_load_increment_only':'somente incremento das rodas, sem carga permanente da viga'}[project.service['permanent_baseline']]
        lines.append('Serviço CMAA 74: vertical L/600 sem impacto e lateral L/400 com ±10% das rodas. Referência adotada: '+baseline+'.')
    return lines


def _intermediate_main_report_sections(project,result,metadata):
    """Client presentation of the authenticated result; no numerical mutation."""
    from .stiffeners.report import intermediate_report_sections,intermediate_status
    p=project.basis().validated_project()
    scopes=result.get('scopes',{})
    final_pending=[v.get('label',k)+': '+pending_text(reason)
        for k,v in scopes.items() for reason in v.get('pending',())]
    outcome=dict(status=result.get('assessed_member_scope_status','PENDING'),
        actual_failure_proven=result.get('actual_failure_proven',False),
        verification_executed=result.get('route_execution_complete',False),pending=final_pending)
    identity='EXEMPLO SINTÉTICO. NÃO É UM PROJETO REAL.' if project.identity=='synthetic_example' else 'Projeto informado.'
    sections=[dict(title='1. Identificação e conclusão',paragraphs=[identity,project.label,
        'Viga TOP com intermediários: '+intermediate_status(outcome)+'.',
        ('Avaliação parcial: as verificações ainda não concluídas são identificadas neste relatório, que não constitui memória completa.' if report_is_partial(result) else 'Verificações executadas no domínio declarado. Os critérios atendidos e não atendidos constam das tabelas.'),
        'Inconclusivo significa que o limite conservador adotado foi excedido: a seção não está comprovada por esse critério, sem afirmar falha física.',
        'Escopo: viga com trilho superior e pares intermediários estabilizadores. Enrijecedores de apoio, ligações de apoio, equipamentos, edifício e aplicação deste detalhe à ponte suspensa ficam fora desta avaliação. Os requisitos de execução indicados são de projeto, não confirmação de fabricação ou inspeção.'],
        headers=['Campo','Identificação'],rows=[[DOCUMENT_FIELDS[k],v] for k,v in metadata.items()]),
        dict(title='3. Modelo físico',paragraphs=[
            'Perfil laminado e trilho sem composição resistente. Chapas e soldas entram com seu peso nas posições reais; o mínimo estático local de ligação não é carga global adicional.',
            'As estações intermediárias não são apoios ou forquilhas. Mantêm-se os vínculos, o percurso das rodas e as condições físicas informadas.',
            'Geometria, materiais e condições abaixo são entradas do cálculo. Referências de catálogo e registros completos de origem permanecem no JSON.'],headers=[],rows=[]),
        dict(title='4. Viga, trilho e material',paragraphs=[f'Perfil: {p.section.name}.'],
            headers=['Dado','Valor'],rows=_intermediate_input_rows(asdict(project.structure))+_intermediate_input_rows(asdict(project.material))+_intermediate_input_rows(asdict(project.rail))),
        dict(title='5. Ponte e métodos selecionados',paragraphs=[
            'Global: ações características CMAA 74:2020, resistência complementar NBR 8800, analogia nominal CISC e estabilidade EN C.2. Local: NBR 10084/8400, Caso I, separado do ELU. Fadiga: NBR 8400-2, vida classificada, detalhes direcionais e interação D.5.',
            'A partilha de quatro contatos é bilinear igualizada no modelo.',
            *_intermediate_method_notes(project)],
            headers=['Dado físico / adoção','Valor'],rows=_intermediate_input_rows(asdict(project.bridge))+_intermediate_input_rows(asdict(project.cmaa_actions))) ]
    detail_sections=intermediate_report_sections(project,result)
    # The standalone detail presenter includes its own identity; the integrated
    # client document states it once at the beginning.
    if detail_sections and detail_sections[0]['paragraphs']:
        detail_sections[0]['paragraphs']=detail_sections[0]['paragraphs'][1:]
    sections.extend(detail_sections)
    sections.append(_intermediate_closure_section(result))
    if final_pending:
        sections.append(dict(title='I11. Verificações pendentes',paragraphs=final_pending,headers=[],rows=[]))
    sections.append(dict(title='9. Integridade e reprodução',paragraphs=[
        'Referência do cálculo: '+result['result_signature'][:12]+'. O JSON técnico conserva entradas, fontes, casos e verificações completas.'],headers=[],rows=[]))
    return sections


def _intermediate_closure_section(result):
    """Compact recorded governors for the two finite compositor obligations."""
    from .stiffeners.report import _check_row,_governing,intermediate_status
    scopes=result.get('scopes',{})
    planes=result.get('intermediate_member_planes') or {}
    concurrent=result.get('intermediate_concurrent_static') or {}
    labels={'top':'mesa superior','bottom':'mesa inferior','web':'alma',
        'plate':'chapa','beam_web':'alma receptora','beam_flange':'mesa receptora','CJP':'CJP verdadeira'}
    groups={}
    for case in planes.get('results',()):
        for check in case.get('checks',()):
            label='Estado plano · '+str(check.get('region_id','região'))+' · '+labels.get(check.get('wall'),str(check.get('wall','parede')))
            groups.setdefault(label,[]).append(dict(check,unit='MPa'))
    for check in concurrent.get('checks',()):
        local={'real_factored_G':'G real','connection_minimum_same_force_line':'mínimo local'}.get(check.get('local_case_id'),'corte do par')
        label='Interação local · '+labels.get(check.get('material_role'),'alma receptora')+' · '+local
        groups.setdefault(label,[]).append(dict(check,unit='MPa'))
    rows=[_check_row(label,_governing(checks)) for label,checks in groups.items()]
    if not planes.get('results'):
        rows.append(_check_row('Estado plano nominal NBR 8400, Caso I',None))
    if not concurrent.get('checks'):
        rows.append(_check_row('Interação local concomitante NBR 8800',None))
    transfer_scope=scopes.get('intermediate_G_transfer',{})
    resolution=transfer_scope.get('component_obligation_resolution') or {}
    paragraphs=[
        'Estado plano nominal NBR 8400, Caso I: '+intermediate_status(scopes.get('intermediate_member_plane'))+'.',
        'Interação estática local NBR 8800: '+intermediate_status(scopes.get('intermediate_static_interaction'))+'.',
        'As tabelas combinam as solicitações do membro com a transferência local. Mantêm-se as bases de ações e os limites próprios de cada verificação. Os envelopes não representam um estado físico crítico único.']
    return dict(title='I10. Estado plano e interação local',paragraphs=paragraphs,
        headers=['Verificação e unidade','Demanda','Limite','U','Resultado'],rows=rows)



def suspended_mass_premises(project):
    from underslung_runway_candidate.bridge_inertia.statics import suspended_mass_accounting
    mass=suspended_mass_accounting(project.bridge)
    if not mass['complete_suspended_mass_accounting']:
        return ['Convenção legada preservada: toda a parcela içada declarada é removida no vazio. A massa retida real do moitão/acessórios é desconhecida, não igual a zero; não se declara composição completa das massas suspensas.']
    return [
        'Capacidade nominal é carga útil. Massa suspensa retida no vazio e no carregado: '+fmt(mass['retained_suspended_mass_kg'])+' kg; total suspenso carregado: '+fmt(mass['loaded_suspended_mass_kg'])+' kg.',
        'A massa retida é separada da ponte/carro e recebe fatores de carga suspensa próprios de cada base. Não é peso permanente do equipamento e não se usa CG médio com a carga útil. Cabos livres usam o ponto de suspensão declarado; carga guiada usa o CG próprio da parcela retida.',
        'Fonte da composição comum: '+project.bridge.suspended_mass_source]


def _en_fatigue_premises(project):
    if not project.fatigue:return []
    f=project.fatigue
    return ['Fadiga EN: amplificações G/Q '+fmt(f.dynamic_equipment)+'/'+fmt(f.dynamic_lifted)+'; fatores γFf/γMf '+fmt(f.gamma_ff)+'/'+fmt(f.gamma_mf)+'. Regiões laminadas ordinárias, sem descontinuidades; fornecimento C3 sem reparo por solda e ambiente normal mantido, conforme premissas declaradas. Não é uma contagem de ciclos ou análise de contato.']


def complementary_premises(project):
    lines=[]
    if project.verification_lengths is not None:
        v=project.verification_lengths
        lines.append('Comprimentos de verificação: compressão no eixo forte '+fmt(v.major_flexural_mm)+' mm; no eixo fraco '+fmt(v.minor_flexural_mm)+' mm; torção '+fmt(v.torsional_mm)+' mm; FLT '+fmt(v.lateral_torsional_mm)+' mm. Vão da análise '+fmt(project.structure.span_m*1000)+' mm, sem alteração das solicitações, apoios ou flechas por estes parâmetros.')
    if project.stability:
        lines.append('Estabilidade EN C.2: coeficiente de resistência '+fmt(project.stability.resistance_gamma)+'; aço estrutural em temperatura ambiente. Adoção: '+project.stability.method_adoption_source+'.')
    if project.nbr_fatigue is None:
        lines.extend(_en_fatigue_premises(project))
    if project.nbr_rolling_guidance is not None:
        g=project.nbr_rolling_guidance
        lines.extend(['Reação de rolamento NBR para Caso I e serviço: topologia declarada de quatro rodas com flange, sem bogies/equalizadores físicos nem guias separados. A partilha bilinear matemática não comprova a topologia. Fonte física: '+g.geometry_source+'.',
            'Referência vertical de cálculo explicitamente adotada: '+g.reference_adoption_source+'. A relação p/a usa o vão entre vias e o entre-eixos físicos comuns. A ação Rλ é independente de CMAA SK e do evento excepcional SHE.'])
    elif project.nbr_fatigue is not None or project.nbr_service is not None:
        lines.append('Critérios NBR dependentes de rolamento não encerrados: topologia física/referência vertical não declaradas. Ausência de dados não significa reação de rolamento nula.')
    if project.nbr_service:
        n=project.nbr_service
        category={'siderurgical_equipment':'equipamento siderúrgico, vertical L/1000 limitado a 25 mm','other_equipment':'demais equipamentos, vertical L/600 limitado a 25 mm','unclassified_adopt_stricter_L1000':'categoria não estabelecida, L/1000 limitado a 25 mm adotado expressamente'}[n.equipment_category]
        lines.extend(['Serviço NBR 10084: '+category+'; lateral L/600. Categoria/requisito: '+n.equipment_category_source+'.',
            'Plano de medição no topo do trilho real: '+n.measurement_plane_source+'. Incremento desde o peso próprio da estrutura de suporte do mesmo modelo linear: '+n.baseline_source+'.',
            'Operação normal sem vento: '+n.operating_scope_source+'. Adoção de acelerações físicas m·a sem amplificação dinâmica e pares normais com Rλ sob topologia declarada: '+n.horizontal_action_source+'. Método: '+n.method_adoption_source+'.'])
    if project.manual_service:
        m=project.manual_service
        lines.append('Limites adicionais de projeto: vertical '+('L/'+fmt(m.vertical_ratio) if m.vertical_ratio is not None else 'não solicitado')+'; lateral '+('L/'+fmt(m.horizontal_ratio) if m.horizontal_ratio is not None else 'não solicitado')+'. Fonte: '+m.source+'. Aplicados separadamente a cada resposta NBR/CMAA, preservando o menor limite com o critério original e seu teto absoluto. Não relaxam nem substituem uma verificação nativa ausente.')
    if project.service:
        baseline={'include_permanent_absolute_bound':'inclui limite absoluto da carga permanente','wheel_load_increment_only':'somente incremento das rodas, sem a carga permanente da viga'}.get(project.service['permanent_baseline'],project.service['permanent_baseline'])
        lines.append('Serviço CMAA74: vertical L/600 sem impacto; lateral L/400 com ±10% das rodas. Referência adotada: '+baseline+'. A cláusula não resolve a inclusão do peso próprio da viga; esta é uma adoção explícita do projeto.')
    return lines


def pending_text(text):
    translations={
      'Selected NBR fatigue evaluation disabled.':'Fadiga NBR selecionada, mas desativada nesta execução.',
      'Supplementary EN fatigue physical/detail/operating inputs not supplied or disabled.':'Fadiga complementar EN sem premissas declaradas ou desativada nesta execução.',
      'CMAA service premises not supplied or disabled.':'Serviço sem premissas declaradas ou desativado nesta execução.',
      'CMAA fatigue class/detail inputs not supplied.':'Comparação longitudinal CMAA sem classe/detalhe declarados.',
      'Not every CMAA source-origin contact case was prepared; see the selected action family pending reasons.':'Nem todos os casos de contato das origens CMAA foram preparados; consultar as pendências da família de ações selecionada.',
      'Outdoor operating wind, abrupt engagement, thermal, test, emergency, impact/buffers and assembly remain outside the selected normal CMAA domain; normal SK is included as an independent bound.':'Vento operacional externo, engate brusco, temperatura, ensaios, emergência, choques/batentes e montagem estão fora do domínio CMAA normal selecionado; SK normal está incluído como limite independente.',
      'Class1–3 web sufficient gate not satisfied; a refined concurrent-gradient classification is separate.':'O limite suficiente de classe 1 a 3 da alma não foi demonstrado; a classificação com o gradiente concomitante exige avaliação separada.',
      'Wind, thermal, skew/guidance, test, emergency, impact/buffers and assembly are not closed by this normal-operation generator.':'Vento, temperatura, desalinhamento/guiamento, ensaios, emergência, choques/batentes e montagem não são encerrados pelo gerador normal.',
      'Wheel/rail rolling contact and rail fastener checks are separate unimplemented route scopes.':'Contato rolante roda/trilho e fixações do trilho ainda não são verificados nesta rota.',
      'Actual fork/support connection design remains separate from the assessed member scopes.':'O detalhamento da ligação real de forquilha/apoio é separado das verificações do membro.',
      'Receiving building/floor design is outside this member calculation; it is not a member strength criterion.':'O edifício ou piso receptor está fora deste cálculo do membro; não é um critério de resistência da viga.',
      'CMAA preference does not rename NBR/EN/CISC calculations. Only source-labelled implemented CMAA criteria are claimed.':'A preferência CMAA não transforma cálculos NBR/EN/CISC em cálculos CMAA. Somente os critérios CMAA explicitamente citados foram implementados.'}
    return translations.get(str(text),str(text))


def geometry_schematics(project):
    """Physical input drawing, not a synthetic envelope or critical case."""
    from .actions import generate_top_action_domain,combined_top_case
    from lro_beams.runway_views import ViewGeometry,_elevation_figure,_section_figure,_finish
    from lro_beams.autonomous_rail import get_rail_profile
    p=project.basis().validated_project();s=p.section
    record=generate_top_action_domain(project.basis(),project.bridge)['records'][0]
    case=combined_top_case(record,equipment_factor=1.,lifted_factor=1.,hx_factor=0.,hy_factor=0.,loaded=True,rail_index=0,case_name='Illustrative static source',source='Physical G+Q without dynamics, illustration only')
    origin=min(v['position_mm'][0] for v in case['stations']);offsets=[(v['position_mm'][0]-origin)/1000 for v in case['stations']]
    shift=(p.span_m-max(offsets))/2 if max(offsets)<=p.span_m else p.span_m/2
    active=[(i,v,shift+offsets[i]) for i,v in enumerate(case['stations']) if 0<=shift+offsets[i]<=p.span_m]
    rail_extra={}
    if p.rail.shape=='verified_catalog':
        profile=get_rail_profile(p.rail.catalog_id)
        rail_extra=dict(rail_head_width_mm=profile.head_width_mm,rail_web_thickness_mm=profile.web_thickness_mm,rail_head_height_mm=profile.head_height_mm,rail_foot_height_mm=profile.foot_height_mm,rail_profile_label=profile.designation)
    g=ViewGeometry(span_m=p.span_m,depth_mm=s.d_mm,top_width_mm=s.bf_mm,bottom_width_mm=s.bottom_width,
        flange_thickness_mm=s.tf_mm,web_thickness_mm=s.tw_mm,bottom_flange_thickness_mm=s.bottom_thickness,
        rail_height_mm=p.rail.height_mm,rail_width_mm=p.rail.width_mm,rail_offset_mm=p.rail.offset_from_web_mm,
        wheel_lateral_offset_mm=p.rail.lateral_eccentricity_mm,beam_end_left_mm=p.beam_end_left_mm,beam_end_right_mm=p.beam_end_right_mm,
        wheel_positions_m=tuple(x for i,v,x in active),wheel_loads_kN=tuple(-v['force_N'][2]/1000 for i,v,x in active),
        wheel_labels=tuple('R'+str(i+1) for i,v,x in active),stiffener_positions_m=(),stiffener_thickness_mm=0.,stiffener_outstand_mm=0.,
        bridge_span_m=project.bridge.bridge_span_mm/1000,wheelbase_m=project.bridge.carriage_station_spacing_mm/1000,
        wheel_load_basis=('G + carga útil + massa retida' if project.bridge.mass_accounting_convention=='payload_plus_retained_suspended_mass' else 'G + parcela içada declarada, legado')+'; sem dinâmica/majoração; posição ilustrativa, não crítica',
        view_case_label='Via esquerda, primeiro extremo de gancho/altura; somente rodas ativas no vão',**rail_extra)
    figure=_elevation_figure(g)
    # Format figure TEXT only; preserve the exact physical data and geometry.
    from matplotlib.text import Text
    for text in figure.findobj(match=Text):
        value=text.get_text()
        for load in g.wheel_loads_kN:
            value=value.replace(f'{load:.9g}'.replace('.',',')+' kN',fmt(load)+' kN')
        text.set_text(value)
    section=_section_figure(g);ax=section.axes[0]
    e=g.rail_offset_mm+g.wheel_lateral_offset_mm
    extent=max(g.depth_mm+g.rail_height_mm,g.top_width_mm,g.bottom_width_mm,g.rail_width_mm+2*abs(g.rail_offset_mm),2*abs(e))
    top=g.depth_mm+g.rail_height_mm;z=top+.12*extent
    if e:
        ax.annotate('',(0,z),(e,z),arrowprops={'arrowstyle':'|-|','color':'#C65A30','lw':1.0},zorder=9)
        for y in (0,e):ax.plot([y,y],[top,z+.02*extent],color='#C65A30',linewidth=.6,zorder=8)
    ax.annotate('e roda/alma = '+fmt(e)+' mm',(e/2,z),xytext=(max(g.top_width_mm,g.bottom_width_mm)/2+.30*extent,top+.15*extent),fontsize=9,color='#C65A30',ha='left',va='bottom',arrowprops={'arrowstyle':'-','color':'#C65A30','lw':.8},bbox={'facecolor':'white','edgecolor':'none','pad':1.5},zorder=10)
    return [('Elevação do modelo físico',_finish(figure,160)),('Seção transversal e excentricidades',_finish(section,160))]


def build_report_docx(project,result,metadata=None):
    sections=report_sections(project,result,metadata)
    from docx import Document
    from docx.shared import Inches,Pt,RGBColor
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn
    d=Document();s=d.sections[0]
    s.page_width=Inches(8.27);s.page_height=Inches(11.69)
    s.top_margin=s.bottom_margin=Inches(.65);s.left_margin=s.right_margin=Inches(.65)
    for name in ('Normal','Title','Heading 1','Heading 2'):
        style=d.styles[name];style.font.name='DejaVu Sans';style.font.color.rgb=RGBColor(0,0,0)
    d.styles['Normal'].font.size=Pt(9);d.styles['Normal'].paragraph_format.space_after=Pt(5)
    d.styles['Title'].font.size=Pt(24)
    for style in d.styles:
        ppr=style.element.find(qn('w:pPr'))
        if ppr is not None:
            for border in list(ppr.findall(qn('w:pBdr'))):ppr.remove(border)
    intermediate=project.intermediates is not None
    title='Viga de rolamento TOP com intermediários' if intermediate else 'Viga de rolamento sem enrijecedores'
    d.core_properties.title='LRO · '+title
    d.core_properties.subject='Memória do modelo físico interno; base híbrida e escopos explícitos'
    d.core_properties.author=''
    d.add_paragraph(title,style='Title')
    d.add_paragraph('Relatório parcial da avaliação da viga de rolamento' if report_is_partial(result) else 'Memória de cálculo da viga de rolamento')
    footer=s.footer.paragraphs[0];footer.alignment=2
    footer.add_run('LRO · TOP com intermediários | página ' if intermediate else 'LRO · sem enrijecedores | página ')
    field=OxmlElement('w:fldSimple');field.set(qn('w:instr'),'PAGE');footer._p.append(field)
    for r in footer.runs:r.font.size=Pt(8)
    displayed_section_number=0
    for part in sections:
        if part['title'].startswith('9.'):
            # Compact verification note, not a nearly empty final page. The
            # complete values and the public validation remain unchanged.
            paragraph=d.add_paragraph()
            paragraph.paragraph_format.space_before=Pt(5)
            paragraph.paragraph_format.space_after=Pt(0)
            paragraph.add_run('Referência. ' if intermediate else 'Integridade e reprodução. ').bold=True
            paragraph.add_run(' '.join(part['paragraphs']))
            for run in paragraph.runs:run.font.size=Pt(7.5)
            continue
        if part['title'].startswith('4.'):
            d.add_heading('Geometria do modelo físico',2 if intermediate else 1)
            if intermediate:
                from .stiffeners.report import intermediate_geometry_schematics
                d.add_paragraph('Posições das estações e geometria nominal do detalhe adotado.')
                drawings=intermediate_geometry_schematics(project)
            else:
                d.add_paragraph('Forquilhas nos apoios A e B, sem enrijecedores. As figuras ilustram somente a geometria e um estado estático com as parcelas de gravidade declaradas, sem declarar um caso crítico nem comprovar a ligação.')
                drawings=geometry_schematics(project)
            for caption,png in drawings:
                d.add_picture(BytesIO(png),width=Inches(6.8))
                if intermediate:d.add_paragraph(caption)
        import re
        displayed_section_number+=1
        display_title=(str(displayed_section_number)+'. '+part['title'].split('. ',1)[-1]) if intermediate else part['title']
        d.add_heading(re.sub(r'[.,:;()/]',' ',display_title),1)
        for j,text in enumerate(part['paragraphs']):
            paragraph=d.add_paragraph(text)
            if part['title'].startswith('7b'):
                paragraph.paragraph_format.space_after=Pt(3)
                for run in paragraph.runs:run.font.size=Pt(8.5)
            if part['title'].startswith('9.'):
                paragraph.paragraph_format.space_after=Pt(2)
                for run in paragraph.runs:run.font.size=Pt(8)
                if j<len(part['paragraphs'])-1:paragraph.paragraph_format.keep_with_next=True
        if not part['rows']:continue
        table=d.add_table(rows=1,cols=len(part['headers']));table.style='Table Grid';table.autofit=False
        n=len(part['headers']);widths={2:([.55,6.42] if part['title'].startswith('7.') else [2.6,4.37]),3:([3.4,2.8,.77] if part['title'].startswith('2.') else [1.0,1.3,4.67]),5:[2.65,1.0,1.0,.85,1.47]}.get(n,[6.97/n]*n)
        if part['title'].startswith('2.') and n==2:widths=[3.8,3.17]
        # Optional fatigue tables have different column semantics; retain the
        # existing style and widths for every pre-existing main report table.
        if part['title'].startswith('8b.') and n==5:widths=[1.9,1.2,1.,1.15,1.72]
        elif part['title'].startswith('8c.') and n==5:widths=[.4,2.4,1.5,1.2,1.47]
        elif part['title'].startswith('8d.') and n==5:widths=[2.35,1.0,1.0,.85,1.77]
        if intermediate:
            prefix=part['title'].split('.')[0]
            widths={'I2':[.74,.65,1.88,1.4,2.3],'I3':[.74,1.56,1.5,1.5,1.67],
                'I4':[2.2,1.8,.85,.85,1.27],'I6':[1.4,1.2,1.15,1.15,2.07],
                'I8':[.8,.95,1.25,3.97],'I9':[1.8,.85,1.8,.65,1.87]}.get(prefix,widths)
        for col,width in zip(table.columns,widths):col.width=Inches(width)
        borders=OxmlElement('w:tblBorders')
        for edge in ('top','left','bottom','right','insideH','insideV'):
            border=OxmlElement('w:'+edge);border.set(qn('w:val'),'single');border.set(qn('w:sz'),'4');border.set(qn('w:color'),'D9D9D9');borders.append(border)
        table._tbl.tblPr.append(borders)
        for c,text in zip(table.rows[0].cells,part['headers']):c.text=text
        header=OxmlElement('w:tblHeader');table.rows[0]._tr.get_or_add_trPr().append(header)
        for values in part['rows']:
            cells=table.add_row().cells
            for cell,value in zip(cells,values):cell.text=str(value)
        for i,row in enumerate(table.rows):
            row._tr.get_or_add_trPr().append(OxmlElement('w:cantSplit'))
            for ci,cell in enumerate(row.cells):
                cell.width=Inches(widths[ci])
                shd=OxmlElement('w:shd');shd.set(qn('w:fill'),'173858' if i==0 else ('F1F4F7' if i%2 else 'FFFFFF'));cell._tc.get_or_add_tcPr().append(shd)
                for p in cell.paragraphs:
                    p.paragraph_format.space_after=Pt(2)
                    for run in p.runs:
                        run.font.size=Pt(8);run.font.bold=i==0;run.font.color.rgb=RGBColor(255,255,255) if i==0 else RGBColor(0,0,0)
    out=BytesIO();d.save(out);return out.getvalue()
