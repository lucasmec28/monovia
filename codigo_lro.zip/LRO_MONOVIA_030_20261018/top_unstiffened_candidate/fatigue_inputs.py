"""Strict optional fatigue declarations; derived material/mass data are not inputs.

A missing optional record means unrequested, never conservative class adoption.
These declarations preserve NBR, EN and CMAA as independent assessments.
"""
from dataclasses import dataclass,fields
from math import isfinite
from underslung_runway_candidate.autonomous_workflow.model import checked_text
from underslung_runway_candidate.fatigue.nbr_member import (
    NBRMemberFatigueInputs,NBRFatigueMaterial,NBRFatigueDuty,NBRFatigueDetail,NBRFatigueMethod,KAPPA_POLICY,
)


MANUAL_CLASSIFICATION_KIND = 'manual_code_selection'
MANUAL_CLASSIFICATION_SOURCE = 'Selecionado no cálculo pelo usuário'


def _source(value,label):
    checked_text(value,label)
    return value


def _number(value,label):
    if type(value) not in (int,float) or not isfinite(value) or value<=0:
        raise ValueError(label+' deve ser positivo e derivado dos dados físicos validados.')
    return float(value)


def exact_premises(cls,raw):
    if not isinstance(raw,dict) or set(raw)!={f.name for f in fields(cls)}:
        raise ValueError('Fadiga: somente declarações físicas e fontes do contrato são aceitas, sem esforços, tensões, ciclos inventados ou comprovantes externos.')
    return cls(**raw).validate()


@dataclass(frozen=True)
class NBRFatiguePremises:
    material_grade: str
    component_group: str
    classification_kind: str
    classification_source: str
    construction_detail: str
    construction_detail_source: str
    fabrication_requirement: str
    fabrication_source: str
    evaluation_location: str
    kappa_policy: str
    adoption_source: str
    nominal_model_source: str

    def validate(self):
        if self.material_grade not in ('S235','S275','ASTM A36','S355','ASTM A572 GR50'):
            raise ValueError('Fadiga NBR: identificar aço coberto pela Tabela D.1, sem presumir equivalência.')
        if self.component_group not in tuple('E'+str(i) for i in range(1,9)):
            raise ValueError('Fadiga NBR: selecionar explicitamente o grupo do componente E1 a E8.')
        if self.classification_kind not in ('documented_component_classification','adopted_conservative_E8',MANUAL_CLASSIFICATION_KIND):
            raise ValueError('Fadiga NBR: selecionar o grupo no cálculo, declarar classificação documentada ou adoção conservadora explícita E8.')
        if self.classification_kind=='adopted_conservative_E8' and self.component_group!='E8':
            raise ValueError('Adoção conservadora sem classificação é somente E8; não representa uma seleção manual de outro grupo.')
        if self.construction_detail!='W0_plain_rolled_unnotched' or self.evaluation_location!='base_material':
            raise ValueError('Fadiga NBR: domínio inicial W0 de material-base laminado ordinário, sem entalhes.')
        if self.fabrication_requirement not in ('specified_h6','specified_h6_qc'):
            raise ValueError('Fadiga NBR: declarar o requisito de fabricação/inspeção aplicável, sem afirmar inspeção executada.')
        if self.kappa_policy!=KAPPA_POLICY:
            raise ValueError('Fadiga NBR: adotar explicitamente a redução conservadora de resistência com kappa = -1.')
        for key in ('classification_source','construction_detail_source','fabrication_source','adoption_source','nominal_model_source'):
            _source(getattr(self,key),'Fonte NBR '+key)
        return self

    def physical(self,*,fy_mpa,fu_mpa,flange_thickness_mm,web_thickness_mm,material_source):
        self.validate()
        fy=_number(fy_mpa,'fy');fu=_number(fu_mpa,'fu')
        if fy>fu or not 370<=fu<=520:
            raise ValueError('Fadiga NBR: o material validado deve satisfazer fy ≤ fu e 370 ≤ fu ≤ 520 MPa.')
        source=_source(material_source,'Fonte do material físico')
        flange=NBRFatigueMaterial(fy,fu,_number(flange_thickness_mm,'Espessura da mesa'),self.material_grade,source)
        web=NBRFatigueMaterial(fy,fu,_number(web_thickness_mm,'Espessura da alma'),self.material_grade,source)
        return NBRMemberFatigueInputs(flange,web,
            NBRFatigueDuty(self.component_group,self.classification_source,self.classification_kind),
            NBRFatigueDetail(self.construction_detail,self.construction_detail_source,self.fabrication_requirement,self.fabrication_source,self.evaluation_location),
            NBRFatigueMethod(self.kappa_policy,self.adoption_source),self.nominal_model_source)


@dataclass(frozen=True)
class CMAAFatiguePremises:
    bridge_travel_speed_m_s: float
    trolley_travel_speed_m_s: float
    hoist_speed_m_s: float
    operating_environment: str
    load_engagement: str
    crane_configuration: str
    physical_source: str
    classification_kind: str
    service_class: str
    classification_source: str
    surface_condition: str
    environment: str
    detail_source: str

    def validate(self):
        if self.classification_kind not in ('documented_service_class','adopted_conservative_D',MANUAL_CLASSIFICATION_KIND):
            raise ValueError('Fadiga CMAA: selecionar a classe A a D no cálculo, declarar classe documentada ou adoção conservadora D explícita.')
        if self.service_class not in ('A','B','C','D'):
            raise ValueError('Fadiga CMAA: selecionar classe A a D sem converter o grupo NBR ou inventar ciclos.')
        if self.classification_kind=='adopted_conservative_D' and self.service_class!='D':
            raise ValueError('Adoção conservadora sem classificação é somente D; classes menos severas exigem fonte.')
        for key in ('physical_source','classification_source','detail_source'):_source(getattr(self,key),key)
        from .cmaa_fatigue import CMAA74RolledDetail
        CMAA74RolledDetail(self.surface_condition,self.environment,self.detail_source).validate()
        return self

    def physical(self,bridge):
        self.validate()
        from underslung_runway_candidate.cmaa74.actions import CMAA74PhysicalInputs
        from underslung_runway_candidate.bridge_inertia.statics import suspended_mass_accounting
        mass=suspended_mass_accounting(bridge)
        if not mass['complete_suspended_mass_accounting']:
            raise ValueError('Fadiga CMAA exige a composição comum explícita de carga útil e massa retida.')
        return CMAA74PhysicalInputs(self.bridge_travel_speed_m_s,self.trolley_travel_speed_m_s,self.hoist_speed_m_s,
            self.operating_environment,self.load_engagement,'payload_plus_retained_common_ledger',self.crane_configuration,
            self.physical_source+'; massa retida e CG da composição comum: '+bridge.suspended_mass_source,
            bridge.retained_suspended_mass_kg,bridge.retained_suspended_cg_x_mm,bridge.retained_suspended_cg_z_mm).validate()

    def duty(self):
        self.validate()
        from .cmaa_fatigue import CMAA74DutyInputs
        source=(
            'Classe de serviço selecionada no cálculo; parâmetro de projeto, sem derivação de histórico operacional ou ciclos. '
            if self.classification_kind==MANUAL_CLASSIFICATION_KIND else
            'Adoção conservadora explícita da classe D como requisito de projeto, não classificação derivada de ciclos. '
            if self.classification_kind=='adopted_conservative_D' else 'Classe de serviço documentada. '
        )+self.classification_source
        return CMAA74DutyInputs('explicit_sourced_service_class',source,service_class=self.service_class)

    def detail(self):
        self.validate()
        from .cmaa_fatigue import CMAA74RolledDetail
        return CMAA74RolledDetail(self.surface_condition,self.environment,self.detail_source)
