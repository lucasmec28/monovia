"""Isolated NBR8800 component checks for the adopted rolled flange analogy.

This module does not create a CMAA procedure, a local sigmaT tensor, a supported
web panel, a combined-stability approval or a fatigue approval. The CISC nominal
analysis is a declared supplement. No physical stiffener exists or is credited.
An actual signed demand may violate an applicable component criterion. Exceeding
a grouped zero-length wheel envelope or sufficient analytical bound is instead
INCONCLUSIVE, never proof of physical failure.
"""
from __future__ import annotations
from copy import deepcopy
from dataclasses import dataclass, asdict
from math import fsum, isfinite, sqrt
from hashlib import sha256
from pathlib import Path

from lro_beams.autonomous_actions import ActionFactors
from lro_beams.autonomous_resistance import local_bending_resistances, axial_compression_resistance
from lro_beams.autonomous_local_resistance import local_web_capacities, SOURCE as LOCAL_SOURCE
from lro_beams.engine import vertical_shear_resistance, horizontal_shear_resistance
from lro_beams.geometry import section_properties
from underslung_runway_candidate.autonomous_workflow.model import signature
from .mechanics import TopUnstiffenedBasis, TopIntermediateBasis, PreparedCase, ConcurrentResponse, prepare_case, action_case_factors
from .bounds import prepared_absolute_bounds
from .verification_lengths import verification_lengths_metadata

SECTION_SOURCE = 'ABNT NBR 8800:2024 + Er1:2025, 5.4.3, 5.5.2.3(a,b), Anexo D; declared CISC2005 nominal flange analogy'
EXCLUSIONS = (
    'Combined global/local member instability is assessed separately.',
    'No computed NBR10084 local sigmaT or complete compatible three-dimensional tensor.',
    'No stiffener, four-edge panel, postbuckling tension-field or rail resistance credit.',
    'Fatigue, service, load/event coverage, rail contact and actual fork connections remain separate.',
)


def _number(v, name, minimum=0.):
    if type(v) not in (int, float) or abs(v)>1e100 or not isfinite(v) or v<minimum:
        raise ValueError(name+' must be finite and within the physical domain')
    return float(v)


def _normal_factors(a):
    if not isinstance(a, ActionFactors) or a.basis!='nbr8800_uls_normal':
        raise ValueError('Explicit independent normal NBR8800 ULS ActionFactors required')
    if a.incremental_service or a.wind or a.thermal or a.event_action:
        raise ValueError('Service, wind, thermal and event vectors cannot be silently omitted')
    if not isinstance(a.source,str) or not a.source.strip():raise ValueError('ULS source required')
    for k in ('dead_support','dead_equipment','extra_dead','lifted','transverse','longitudinal'):
        _number(getattr(a,k), k)
    if min(a.dead_support,a.dead_equipment)<1 or (a.extra_dead and a.extra_dead<1):
        raise ValueError('Permanent normal-ULS origin factors below 1 are unsupported')
    if a.transverse!=a.longitudinal or (a.transverse and a.transverse<1.5) or a.lifted<a.transverse:
        raise ValueError('Correlated crane normal-ULS factors must retain gammaQ >=1.5 and psi >=1')
    if bool(a.lifted)!=bool(a.transverse):raise ValueError('Crane gravity/H presence must remain correlated')
    if any('abaixo do valor normal' in text for text in a.limitations):
        raise ValueError('Subnormative factor override requires separate qualification')
    return a


def _prepared_key(c):
    # Deliberately excludes inactive pair fields in the caller's unnormalized
    # project. The private adapter has already normalized them without credit.
    fields=('factors','properties','udl','source_wheels','top_wheels','bottom_wheels',
            'beam','flange_beam','top_udl','bottom_udl','transverse_sign',
            'longitudinal_sign','force_split','major_fixed','top_fixed','bottom_fixed')
    def value(v):
        if hasattr(v,'__dataclass_fields__'):return asdict(v)
        if isinstance(v,(tuple,list)):return [value(x) for x in v]
        return v
    return signature(dict(project=c.project.to_dict(),premises=c.basis.provenance(),
                          **{k:value(getattr(c,k)) for k in fields}))


@dataclass(frozen=True)
class NormalULSReceipt:
    """Internal regenerated action identity, not a user approval flag.

    Public construction grants nothing: consumers regenerate the complete
    physical case and compare signatures, factors, sources and signed vectors.
    """
    basis: TopUnstiffenedBasis
    record: dict
    factors: ActionFactors
    loaded: bool
    rail_index: int
    transverse_sign: int
    longitudinal_sign: int
    horizontal_dynamic_factor: float
    horizontal_dynamic_source: str
    prepared_signature: str


def prepare_normal_uls_physical_case(basis, record, factors, *, loaded, rail_index,
        horizontal_dynamic_factor, horizontal_dynamic_source,
        transverse_sign=1, longitudinal_sign=1):
    """Physical inputs -> complete factored parcels -> identity beam adapter.

    No external efforts and no hidden H dynamic coefficient. A caller must give
    the sourced characteristic H multiplier; it scales every component of each
    inertia parcel exactly once. gammaQ then scales that complete parcel once.
    """
    from .actions import combined_top_case, prepare_top_physical_case
    if not isinstance(basis,(TopUnstiffenedBasis, TopIntermediateBasis)):raise ValueError('Explicit nominal basis required')
    a=_normal_factors(factors)
    if basis.validated_project().extra_dead_kn_per_m and a.extra_dead==0:
        raise ValueError('Present permanent extra dead origin cannot have an omitted ULS factor')
    for sign in (transverse_sign,longitudinal_sign):
        if type(sign) is not int or sign not in (-1,1):raise ValueError('Signed directions must be integer +/-1')
    physical=record.get('physical_inputs',{})
    zero_inertia=(physical.get('bridge_acceleration_m_s2')==0 and physical.get('trolley_acceleration_m_s2')==0)
    zero_H=zero_inertia or (a.transverse==a.longitudinal==0)
    if horizontal_dynamic_factor is None and zero_H:
        dynamic=1.  # Multiplies exactly zero; no adopted physical coefficient.
    else:
        dynamic=_number(horizontal_dynamic_factor,'sourced horizontal dynamic multiplier',1.)
    if not isinstance(horizontal_dynamic_source,str):raise ValueError('Horizontal dynamic source must be text')
    if not horizontal_dynamic_source.strip():
        if zero_H and dynamic==1.:
            horizontal_dynamic_source='Exact zero H: declared zero accelerations or omitted correlated crane-action family; no physical multiplier assumed'
        else:raise ValueError('Explicit horizontal dynamic source/method required; no implicit NBR coefficient')
    name=f'{a.code}/{record["id"]}/loaded{loaded}/rail{rail_index}/HY{transverse_sign}/HX{longitudinal_sign}'
    source=a.source+'; characteristic H dynamics: '+horizontal_dynamic_source
    case=combined_top_case(record,equipment_factor=a.dead_equipment,lifted_factor=a.lifted,
        hx_factor=longitudinal_sign*a.longitudinal*dynamic,
        hy_factor=transverse_sign*a.transverse*dynamic,loaded=loaded,rail_index=rail_index,
        case_name=name,source=source)
    c=prepare_top_physical_case(basis,case,permanent_factor=a.dead_support,extra_dead_factor=a.extra_dead)
    receipt=NormalULSReceipt(deepcopy(basis),deepcopy(record),a,loaded,rail_index,
        transverse_sign,longitudinal_sign,dynamic,horizontal_dynamic_source,_prepared_key(c))
    return c,receipt


def _verify(c, ledger):
    if not isinstance(c,PreparedCase):raise ValueError('Internally prepared mechanical case required')
    # A different source-origin route needs its own strict regeneration recipe;
    # accepting generic precombined CaseFactors here would bypass ULS identity.
    from .cmaa_strength import CMAANormalULSReceipt, verify_cmaa_normal_uls_receipt
    if isinstance(ledger,CMAANormalULSReceipt):
        return verify_cmaa_normal_uls_receipt(c,ledger)
    if isinstance(ledger,NormalULSReceipt):
        fresh,new=prepare_normal_uls_physical_case(ledger.basis,ledger.record,ledger.factors,
            loaded=ledger.loaded,rail_index=ledger.rail_index,
            horizontal_dynamic_factor=ledger.horizontal_dynamic_factor,
            horizontal_dynamic_source=ledger.horizontal_dynamic_source,
            transverse_sign=ledger.transverse_sign,longitudinal_sign=ledger.longitudinal_sign)
        if new.prepared_signature!=ledger.prepared_signature or _prepared_key(c)!=new.prepared_signature:
            raise ValueError('ULS receipt does not bind this prepared physical case; stale/tampered inputs')
        a=ledger.factors
        provenance=dict(kind='regenerated_correlated_physical_normal_uls',original_factors=asdict(a),
            horizontal_dynamic_factor=ledger.horizontal_dynamic_factor,
            horizontal_dynamic_source=ledger.horizontal_dynamic_source,
            prepared_signature=new.prepared_signature,external_efforts_required=False)
    else:
        a=_normal_factors(ledger)
        if c.project.extra_dead_kn_per_m and a.extra_dead==0:
            raise ValueError('Present permanent extra dead origin cannot have an omitted ULS factor')
        if c.factors!=action_case_factors(a):raise ValueError('Response factors do not exactly match the original ULS ledger')
        fresh=prepare_case(c.basis,a,c.transverse_sign,c.longitudinal_sign)
        if _prepared_key(c)!=_prepared_key(fresh):raise ValueError('Prepared case changed after generation')
        provenance=dict(kind='exact_direct_ActionFactors_identity',original_factors=asdict(a),prepared_signature=_prepared_key(c))
    return provenance


def _response(response, ledger):
    if not isinstance(response,ConcurrentResponse):raise ValueError('ConcurrentResponse required')
    evidence=_verify(response.prepared,ledger)
    fresh=response.prepared.solve_position(response.translation_m)
    if response!=fresh:raise ValueError('Response changed after the internal solve')
    return evidence


def _row(identifier,demand,capacity,*,source=SECTION_SOURCE,bound=False,unit='',**extra):
    demand=_number(demand,'component demand');capacity=_number(capacity,'component capacity')
    ok=demand<=capacity+1e-12*max(1.,capacity)
    return dict(id=identifier,demand=demand,capacity=capacity,unit=unit,
        utilization=demand/capacity if capacity else (0. if demand==0 else None),
        status='PASS' if ok else ('INCONCLUSIVE' if bound else 'FAIL'),
        sufficient_bound=bound,actual_failure_proven=not ok and not bound,source=source,**extra)


def _finish(kind,checks,pending,**extra):
    physical_state = extra.pop("physical_state", "absent")
    if physical_state not in ("absent", "present"):
        raise ValueError("Explicit physical stiffener state required")
    # An independent CMAA SK contact-force box is not a physical event. Even a
    # solved endpoint is only a mathematical design point of this outer set.
    if extra.get('action_identity',{}).get('box_design_case'):
        checks=[dict(r,status='INCONCLUSIVE' if r['status']=='FAIL' else r['status'],
            actual_failure_proven=False,sufficient_bound=True,
            box_design_case=True,physical_failure_witness=False) for r in checks]
    failed=any(r['actual_failure_proven'] for r in checks)
    inconclusive=any(r['status']=='INCONCLUSIVE' for r in checks)
    status='FAIL' if failed else 'PENDING' if pending else 'INCONCLUSIVE' if inconclusive else 'COMPONENT_CHECKS_SATISFIED'
    return dict(kind=kind,status=status,checks=checks,pending=list(dict.fromkeys(pending)),
        actual_failure_proven=failed,component_checks_calculated=not pending,
        component_bounds_satisfied=not pending and not failed and not inconclusive,
        whole_member_qualified=False,design_complete=False,local_sigmaT_calculated=False,
        physical_stiffeners=physical_state,stiffener_resistance_credit=False,panel_credit=False,
        exclusions=EXCLUSIONS,**extra)


def _resistance_source_hashes():
    from . import verification_lengths as lengths
    import lro_beams.autonomous_resistance as axial
    import lro_beams.engine as engine
    import lro_beams.geometry as geometry
    import lro_beams.beam_torsion as torsion
    return {Path(path).name: sha256(Path(path).read_bytes()).hexdigest()
            for path in (__file__, lengths.__file__, axial.__file__, engine.__file__, geometry.__file__, torsion.__file__)}


def section_resistances(basis, *, verification_lengths=None):
    """Bare rolled section components. No support pair or circular-fillet mass."""
    if not isinstance(basis,(TopUnstiffenedBasis, TopIntermediateBasis)):raise ValueError('Explicit TopUnstiffenedBasis required')
    p=basis.validated_project();s=p.section;m=p.material;g=section_properties(s)
    lengths=verification_lengths_metadata(verification_lengths,p.span_m*1000)
    inputs=dict(project=p.to_dict(),premises=basis.provenance(),verification_lengths=lengths)
    key=signature(inputs);sources=_resistance_source_hashes()
    local=local_bending_resistances(s,m)
    shear=vertical_shear_resistance(s,g,m);lateral=horizontal_shear_resistance(s,m)
    if verification_lengths is None:
        axial=axial_compression_resistance(s,m,p.span_m,p.span_m,p.span_m)
    else:
        use=lengths['strength_lengths_mm']
        axial=axial_compression_resistance(s,m,use['major_flexural_mm']/1000,
            use['minor_flexural_mm']/1000,use['torsional_mm']/1000)
    if key!=signature(dict(project=basis.validated_project().to_dict(),premises=basis.provenance(),
            verification_lengths=verification_lengths_metadata(verification_lengths,p.span_m*1000))):
        raise ValueError('Section resistance inputs or verification lengths changed during calculation')
    if sources!=_resistance_source_hashes():
        raise ValueError('Section resistance numerical source changed during calculation')
    return dict(source=SECTION_SOURCE,verification_lengths=lengths,
        receipt=dict(input_signature=key,source_hashes=sources,verification_lengths=lengths),local_bending=local,vertical_shear=shear,
        horizontal_shear=lateral,individual_flange_shear_kn=lateral['Vrd_kn']/2,
        axial_compression=axial,gross_tension_yield_kn=g.A_mm2*m.fy_mpa/m.gamma_a1/1000,
        nominal_normal_yield_mpa=m.fy_mpa/m.gamma_a1,nominal_shear_yield_mpa=.6*m.fy_mpa/m.gamma_a1,
        root_geometry=dict(h_mm=g.h_mm,k_mm=s.tf_mm+s.root_radius_mm,
            basis=basis.root_geometry_basis,source=basis.root_geometry_source,
            radius_is_actual_circle=basis.root_geometry_basis=='documented_circular_root',
            fictitious_fillet_mass_added=False),
        physical_stiffeners=basis.physical_stiffeners,shear_kv=5.34,tension_field_credit=False,
        combined_stability_qualified=False,design_complete=False)


def _spatial_states(r):
    # The nominal stress stationary set alone need not contain every separate
    # major/flange moment extremum. Explicitly add each plane's candidates.
    rows={(v['position_m'],v['side']):v for v in r.exact_spatial_states()}
    L=r.prepared.project.span_m
    for plane in (r.major.vertical,r.top.horizontal,r.bottom.horizontal):
        for x in plane.critical_positions():
            for side in (('right',) if x==0 else ('left',) if x==L else ('left','right')):
                rows[x,side]=r.at(x,side)
    return tuple(rows.values())


def _section_rows(c,cap,demands,*,bound,witnesses=None):
    s=c.project.section;g=c.properties;If=c.flange_I_mm4
    specs=(('nominal_normal_yield',demands['normal'],cap['nominal_normal_yield_mpa'],'MPa',bound),
        ('major_local_bending',demands['major_M'],cap['local_bending']['major_local_knm'],'kN m',True),
        ('equivalent_minor_local_bending',(demands['top_M']+demands['bottom_M'])*g.Iy_mm4/(2*If),cap['local_bending']['minor_local_knm'],'kN m',True),
        ('bare_web_vertical_shear',demands['major_V'],cap['vertical_shear']['Vrd_kn'],'kN',bound),
        ('top_flange_lateral_shear',demands['top_V'],cap['individual_flange_shear_kn'],'kN',bound),
        ('bottom_flange_lateral_shear',demands['bottom_V'],cap['individual_flange_shear_kn'],'kN',bound),
        ('gross_axial_tension_yield',demands['tension'],cap['gross_tension_yield_kn'],'kN',bound),
        ('isolated_axial_compression',demands['compression'],cap['axial_compression']['capacity_kn'],'kN',True))
    checks=[_row(name,demand,capacity,unit=unit,bound=bounded,
        **({'witness':witnesses[name]} if witnesses and name in witnesses else {})) for name,demand,capacity,unit,bounded in specs]
    # Conservative nominal model shear box. Q <= A*d/2 includes catalog root
    # material without inventing its shape. No local wheel/fillet stress claim.
    txz=demands['major_V']*1000*g.A_mm2*s.d_mm/(2*g.Ix_mm4*min(s.tw_mm,s.tf_mm))
    txy=1.5*max(demands['top_V'],demands['bottom_V'])*1000/(s.bf_mm*s.tf_mm)
    checks.append(_row('nominal_shear_model_box',sqrt(txz*txz+txy*txy),cap['nominal_shear_yield_mpa'],unit='MPa',bound=True,
        nominal_model_only=True,physical_local_tensor_claim=False))
    return checks


def check_uls_position(response, action_ledger, *, verification_lengths=None):
    """Exact linear spatial component extrema at ONE concurrent train position."""
    identity=_response(response,action_ledger);c=response.prepared
    lengths=verification_lengths_metadata(verification_lengths,c.project.span_m*1000)
    cap=section_resistances(c.basis,verification_lengths=verification_lengths);states=_spatial_states(response)
    names=dict(major_M='Mx_knm',major_V='Vy_kn',top_M='top_flange_M_knm',bottom_M='bottom_flange_M_knm',
               top_V='top_flange_V_kn',bottom_V='bottom_flange_V_kn')
    demand={key:max(abs(row[field]) for row in states) for key,field in names.items()}
    demand.update(normal=max(abs(f['sigma_x_mpa']) for row in states for f in row['stresses'].values()),
                  tension=max(0.,*(row['N_kn'] for row in states)),compression=max(0.,*(-row['N_kn'] for row in states)))
    worst=max(((abs(f['sigma_x_mpa']),row,fiber,f) for row in states for fiber,f in row['stresses'].items()),key=lambda v:v[0])
    witnesses={'nominal_normal_yield':dict(position_m=worst[1]['position_m'],side=worst[1]['side'],
        fiber=worst[2],signed_sigma_x_mpa=worst[3]['sigma_x_mpa'])}
    checks=_section_rows(c,cap,demand,bound=False,witnesses=witnesses)
    if lengths!=verification_lengths_metadata(verification_lengths,c.project.span_m*1000):
        raise ValueError('Verification lengths changed during section-position calculation')
    return _finish('normal_uls_section_components_at_position',checks,[],physical_state=c.basis.physical_stiffeners,action_identity=identity,
        verification_lengths=lengths,resistance_receipt=cap['receipt'],
        translation_m=response.translation_m,demands=demand,resistances=cap,
        spatial_scope='Exact linear scalar extrema; nonlinear interaction not inferred',all_positions=False)


def check_uls_all_positions(prepared, action_ledger, *, verification_lengths=None):
    """Uniform analytical sufficient section bounds, never sampled maxima."""
    identity=_verify(prepared,action_ledger);c=prepared
    lengths=verification_lengths_metadata(verification_lengths,c.project.span_m*1000)
    cap=section_resistances(c.basis,verification_lengths=verification_lengths);b=prepared_absolute_bounds(c)
    demand=dict(normal=b['sx_abs_mpa'],major_M=b['major']['moment_abs_knm'],major_V=b['major']['shear_abs_kn'],
        top_M=b['top']['moment_abs_knm'],bottom_M=b['bottom']['moment_abs_knm'],top_V=b['top']['shear_abs_kn'],
        bottom_V=b['bottom']['shear_abs_kn'],tension=b['N_tension_abs_kn'],compression=b['N_compression_abs_kn'])
    if lengths!=verification_lengths_metadata(verification_lengths,c.project.span_m*1000):
        raise ValueError('Verification lengths changed during section all-position calculation')
    return _finish('normal_uls_section_all_position_bounds',_section_rows(c,cap,demand,bound=True),[],physical_state=c.basis.physical_stiffeners,
        verification_lengths=lengths,resistance_receipt=cap['receipt'],
        action_identity=identity,demands=demand,resistances=cap,bounds=b,all_positions=True,
        attained_maximum_claimed=False,floating_point_interval_certificate=False)


def _support_end_distances(p):
    """Support load centre to its nearest physical end, including short spans."""
    L=p.span_m*1000
    return (min(p.beam_end_left_mm,L+p.beam_end_right_mm),
            min(p.beam_end_right_mm,L+p.beam_end_left_mm))


def _local_pending(p):
    pending=[]
    if abs(p.rail.offset_from_web_mm)>1e-9:
        pending.append('NBR8800 5.7 centered-force component requires the physical rail centered over the web; eccentric nominal torque is separate.')
    for name,a in zip(('left','right'),_support_end_distances(p)):
        if a<p.support_bearing_length_mm/2:
            pending.append(name+' support bearing footprint extends beyond the physical member end.')
    return pending


def _local_cap(p,bearing,distance,flange='top'):
    return local_web_capacities(p.section,p.material,bearing_length_mm=bearing,
        end_distance_mm=distance,lateral_length_mm=p.span_m*1000,loaded_flange=flange,
        rotation_restrained=flange=='bottom')


def _local_row(identifier,demand,capacity,*,bound,**extra):
    return _row(identifier,demand,capacity,source=LOCAL_SOURCE,unit='kN',bound=bound,
                demand_kn=demand,capacity_kn=capacity,**extra)


def bare_web_position(response, action_ledger):
    """Unreinforced 5.7 components, actual support forces and grouped wheels.

    At the true end fork, relative flange lateral translation is restrained:
    support sidesway is excluded by 5.7.5.1, NOT by a fictitious web edge/panel.
    Ordinary wheel forces use ln=0 and conservative grouping, so exceedance of
    their lower-capacity envelope requires refinement instead of physical FAIL.
    """
    identity=_response(response,action_ledger);p=response.prepared.project;L=p.span_m
    pending=_local_pending(p);checks=[];wheels=[];supports=[]
    loads=sorted(response.major.loads,key=lambda w:w.position_m)
    if any(w.vertical_kn<0 for w in loads):pending.append('Tensile wheel contact is outside this compression-only local route.')
    if abs(p.rail.offset_from_web_mm)<=1e-9 and not any(w.vertical_kn<0 for w in loads):
        groups=[]
        for w in loads:
            if groups and (w.position_m-groups[-1][-1].position_m)*1000<=p.section.d_mm:groups[-1].append(w)
            else:groups.append([w])
        total=fsum(w.vertical_kn for w in loads)
        for i,group in enumerate(groups):
            distance=min(min(w.position_m*1000+p.beam_end_left_mm,(L-w.position_m)*1000+p.beam_end_right_mm) for w in group)
            cap=_local_cap(p,0.,distance);force=fsum(w.vertical_kn for w in group)
            wheels.append(dict(names=[w.name for w in group],positions_m=[w.position_m for w in group],force_kn=force,
                               capacities=cap,zero_length_patch_bound=True))
            for mode,key in (('yield','web_yield_kn'),('cripple','web_crippling_kn')):
                checks.append(_local_row(f'wheel_group_{i}_{mode}',force,cap[key],bound=True))
            # Endpoint wheels may be restrained, but including them in this
            # all-wheel group remains a conservative sufficient wheel screen.
            if not cap['lateral_mode_excluded']:
                checks.append(_local_row(f'wheel_group_{i}_sidesway',total,cap['web_sidesway_kn'],bound=True,
                    grouped_all_present_wheels=True,Cr_lower_branch=True))
    reactions=(response.major.reactions.vertical_left_kn,response.major.reactions.vertical_right_kn)
    distances=_support_end_distances(p)
    for x,name,R,a in ((0.,'left',reactions[0],distances[0]),(L,'right',reactions[1],distances[1])):
        witness=dict(translation_m=response.translation_m,support=name,signed_reaction_kn=R)
        checks.append(_local_row('support_'+name+'_contact_uplift',max(0.,-R),0.,bound=False,witness=witness,
            interpretation='No tensile hold-down is present in the adopted compression-bearing contact model'))
        if R<0:pending.append(name+' support has actual uplift; anchorage/tension mechanism is not qualified.')
        if a<p.support_bearing_length_mm/2:continue
        cap=_local_cap(p,p.support_bearing_length_mm,a,'bottom')
        if R>=0:
            for mode,key in (('yield','web_yield_kn'),('cripple','web_crippling_kn')):
                checks.append(_local_row('support_'+name+'_'+mode,R,cap[key],bound=False,witness=witness))
            opposed=fsum(w.vertical_kn for w in loads if w.vertical_kn>0 and abs(w.position_m-x)*1000<=p.support_bearing_length_mm/2+1e-7)
            if opposed:
                checks.append(_local_row('support_'+name+'_opposed',max(opposed,R),cap['opposed_compression_kn'],bound=True,
                    grouped_opposed_forces=True,witness=witness))
        supports.append(dict(name=name,reaction_kn=R,capacities=cap,
            sidesway_applicability='Excluded at actual assumed true fork by 5.7.5.1 relative flange lateral restraint',
            fork_connection_designed=False,full_depth_web_edge_support_claimed=False))
    return _finish('bare_web_components_at_position',checks,pending,physical_state=response.prepared.basis.physical_stiffeners,action_identity=identity,
        translation_m=response.translation_m,wheels=wheels,supports=supports,all_positions=False)


def support_reaction_bounds(prepared):
    """Exact-arithmetic piecewise-affine reaction ranges over complete passage.

    End-entry/exit couple jumps retain both actual events and open-interval
    one-sided limits. This is not a sampled grid or an absolute-force box.
    """
    c=prepared
    if not isinstance(c,PreparedCase):raise ValueError('PreparedCase required')
    L=c.project.span_m;q=c.udl.vertical_kn_per_m
    base=(q*L/2+fsum(w.vertical_kn*(L-w.position_m)/L-w.major_moment_knm/L for w in c.major_fixed),
          q*L/2+fsum(w.vertical_kn*w.position_m/L+w.major_moment_knm/L for w in c.major_fixed))
    events=c.translation_events();candidates=[[],[]]
    def record(t,active,kind):
        values=(base[0]+fsum(w.vertical_kn*(L-t-w.offset_m)/L-w.major_moment_knm/L for w in active),
                base[1]+fsum(w.vertical_kn*(t+w.offset_m)/L+w.major_moment_knm/L for w in active))
        for side,value in enumerate(values):candidates[side].append(dict(value_kn=value,translation_m=t,kind=kind))
    for t in events:record(t,[w for w in c.source_wheels if 0<=t+w.offset_m<=L],'actual_event')
    for a,b in zip(events[:-1],events[1:]):
        t=(a+b)/2;active=[w for w in c.source_wheels if 0<t+w.offset_m<L]
        record(a,active,'right_limit');record(b,active,'left_limit')
    return tuple(dict(support=name,minimum_kn=min(row['value_kn'] for row in rows),
        maximum_kn=max(row['value_kn'] for row in rows),
        minimum_witness=min(rows,key=lambda row:row['value_kn']),maximum_witness=max(rows,key=lambda row:row['value_kn']),
        method='Piecewise affine exact event/one-sided-limit enclosure',floating_point_interval_certificate=False)
        for name,rows in zip(('left','right'),candidates))


def bare_web_all_positions(prepared, action_ledger):
    """Sufficient whole-passage bare-web bounds with exact support ranges.

    Wheel force sums/zero-length patches intentionally lose favorable spacing.
    Exceedances remain inconclusive. Actual event reactions independently retain
    any witnessed support capacity violation, even if another domain is pending.
    """
    identity=_verify(prepared,action_ledger);p=prepared.project
    pending=_local_pending(p);checks=[];supports=[];wheel=None
    if any(w.vertical_kn<0 for w in prepared.source_wheels):pending.append('Tensile wheel contact outside local compression scope.')
    elif abs(p.rail.offset_from_web_mm)<=1e-9:
        total=fsum(w.vertical_kn for w in prepared.source_wheels)
        cap=_local_cap(p,0.,min(p.beam_end_left_mm,p.beam_end_right_mm))
        wheel=dict(force_sum_kn=total,capacities=cap,zero_length_patch_bound=True)
        for mode,key in (('yield','web_yield_kn'),('cripple','web_crippling_kn')):
            checks.append(_local_row('all_wheels_'+mode,total,cap[key],bound=True))
        if not cap['lateral_mode_excluded']:
            checks.append(_local_row('all_wheels_sidesway',total,cap['web_sidesway_kn'],bound=True,Cr_lower_branch=True))
    ranges=support_reaction_bounds(prepared)
    for env,a in zip(ranges,_support_end_distances(p)):
        name=env['support'];low=env['minimum_kn'];high=max(0.,env['maximum_kn'])
        checks.append(_local_row('support_'+name+'_contact_uplift_bound',max(0.,-low),0.,bound=True))
        if a<p.support_bearing_length_mm/2:continue
        cap=_local_cap(p,p.support_bearing_length_mm,a,'bottom')
        for mode,key in (('yield','web_yield_kn'),('cripple','web_crippling_kn')):
            checks.append(_local_row('support_'+name+'_'+mode+'_bound',high,cap[key],bound=True))
        total=fsum(max(0.,w.vertical_kn) for w in prepared.source_wheels)
        if total:checks.append(_local_row('support_'+name+'_opposed_bound',max(total,high),cap['opposed_compression_kn'],bound=True))
        # Retain ACTUAL event failures, not the one-sided envelope as a physical
        # witness. A strict limiting exceedance can be refined separately.
        events=prepared.translation_events()
        for t in events:
            r=prepared.solve_position(t).major.reactions
            R=r.vertical_left_kn if name=='left' else r.vertical_right_kn
            witness=dict(translation_m=t,support=name,signed_reaction_kn=R)
            if R<0:checks.append(_local_row('support_'+name+'_actual_uplift',-R,0.,bound=False,witness=witness))
            for mode,key in (('yield','web_yield_kn'),('cripple','web_crippling_kn')):
                if R>cap[key]:checks.append(_local_row('support_'+name+'_actual_'+mode,R,cap[key],bound=False,witness=witness))
        supports.append(dict(**env,capacities=cap,sidesway_excluded_at_true_fork=True,
                             fork_connection_designed=False,full_depth_web_edge_support_claimed=False))
    return _finish('bare_web_all_position_bounds',checks,pending,physical_state=prepared.basis.physical_stiffeners,action_identity=identity,
        wheels=wheel,supports=supports,reaction_envelopes=ranges,all_positions=True,
        attained_maximum_claimed=False,floating_point_interval_certificate=False)
