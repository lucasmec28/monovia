"""Isolated elastic LTB reference lower bound with destabilizing load radius.
Not a member resistance/fatigue check or code compliance declaration.

Vlasov second variation assumed: EIweak*||v''||²+ECw*||phi''||²
-2*lambda*int(M(x)*v''*phi)-lambda*sum(Di*phi(xi)²), plus
nonnegative GJ omitted. True forks v=phi=0 at each segment end. Axial
compression, follower loads, pre-twist/large displacement, distortion and
connection adequacy are not proved here. NBR/EN resistance use needs its
separate source/domain contract.

For ||M||inf<=Mref, Dirichlet Poincare gives the cross coefficient c.
Point evaluation |phi(x)|²<=x(L-x)/L*||phi'||² and
||phi'||²<=L²/pi²*||phi''||² gives d. Thus sufficient PSD matrix is
[[1,-lambda*c],[-lambda*c,1-lambda*d]]. Its positive root is a lower
bound on the elastic critical load multiplier of this declared energy model.
"""
from math import isfinite,pi,sqrt,hypot

def _real(v,name,positive=False):
 if isinstance(v,bool) or not isinstance(v,(int,float)) or abs(v)>1e100 or not isfinite(v):raise ValueError(name+' invalid')
 v=float(v)
 if positive and v<=0:raise ValueError(name+' must be positive')
 return v

def critical_reference(*,length_mm,EIweak_Nmm2,ECw_Nmm4,moment_abs_bound_Nmm,point_radius_actions,unlocated_radius_sum_Nmm=0.):
 L=_real(length_mm,'L',True);EI=_real(EIweak_Nmm2,'EIweak',True);ECw=_real(ECw_Nmm4,'ECw',True);M=_real(moment_abs_bound_Nmm,'Mref',True)
 unknown=_real(unlocated_radius_sum_Nmm,'unlocated D')
 if unknown<0:raise ValueError('Unlocated destabilizing sum cannot be negative')
 weighted=unknown*L/4; rows=[]
 for x,D in point_radius_actions:
  x=_real(x,'point x');D=_real(D,'signed destabilizing radius action')
  if not 0<=x<=L:raise ValueError('Point outside actual segment')
  # D=-F_transverse dot r_transverse. Drop stabilizing D<0, never credit it.
  value=max(D,0.)*x*(L-x)/L;weighted+=value;rows.append(dict(x_mm=x,D_Nmm=D,trace_weighted_Nmm2=value))
 c=M*L*L/(pi*pi*sqrt(EI)*sqrt(ECw));d=weighted*L*L/(pi*pi*ECw)
 den=d+hypot(d,2*c)
 if not all(isfinite(v) for v in (weighted,c,d,den)) or c<=0 or den<=0:raise ValueError('Derived numeric overflow/underflow')
 lam=2/den;Mcr=lam*M
 if not isfinite(Mcr) or Mcr<=0:raise ValueError('Derived critical reference invalid')
 return dict(critical_multiplier_lower=lam,Mcr_lower_Nmm=Mcr,c=c,d=d,point_actions=rows,
  model='declared_Vlasov_fork_energy_bound_with_destabilizing_point_radius',
  favorable_GJ_discarded=True,favorable_radius_discarded=True,axial_or_combined_eigenvalue_claimed=False,
  physical_support_or_member_resistance_qualified=False)
