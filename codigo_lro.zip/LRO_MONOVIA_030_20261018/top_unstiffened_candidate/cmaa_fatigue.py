"""Isolated CMAA 74:2020 Case 1 longitudinal stress-range candidate.

This is a source-qualified scalar consumer, NOT multiaxial fatigue completion.
CMAA native longitudinal direction is y; the existing mechanics calls it x.
No von-Mises range, principal-axis tracking, S-N curve or Miner rule is invented.
The model remains the explicitly adopted supplementary rolled-flange analogy.
"""
from copy import deepcopy
from dataclasses import asdict, dataclass, replace
from itertools import product
from math import cbrt, fsum, isfinite
from pathlib import Path
import hashlib
import json

from lro_beams.autonomous_model import WheelInput
from lro_beams.autonomous_response import CaseFactors
from underslung_runway_candidate.bridge_inertia.statics import PointMass, _compare, _resultant
from underslung_runway_candidate.cmaa74.actions import (
    CMAA74PhysicalInputs, dead_load_factor, hoist_load_factor, inertia_drive_factor, validate_cmaa_mass_ledger,
)
from .actions import TopBridgeInputs, _generate_domain
from .mechanics import TopUnstiffenedBasis, TopIntermediateBasis, PreparedCase, prepare_case
from .bounds import prepared_absolute_bounds

SOURCE = 'CMAA 74:2020'
PRIMARY_PDF_SHA256 = '575a53390f90d11cfd213f0277324334f826296584e716fba399df69f0d4149a'
EDITION = 'cmaa74_2020_verified'
ACTION_BASIS = 'CMAA74_2020_CASE1_NOMINAL'
CASE1_FORMULA = 'DL*DLF_B + TL*DLF_T + LL*(1+HLF) + IFD'
KSI_TO_MPA = 6.894757293168
RANGES_KSI = {
    'A': dict(zip('ABCDEF', (63, 49, 35, 28, 22, 15))),
    'B': dict(zip('ABCDEF', (50, 39, 28, 22, 18, 14))),
    'C': dict(zip('ABCDEF', (37, 29, 21, 16, 13, 12))),
    'D': dict(zip('ABCDEF', (31, 24, 17, 13, 11, 11))),
}
CLASS_MATRIX = (('A', 'B', 'C', 'D'), ('B', 'C', 'D', None),
                ('C', 'D', None, None), ('D', None, None, None))


def _real(v, name, minimum=None):
    try:
        ok = not isinstance(v, bool) and isinstance(v, (int, float)) and isfinite(v) and abs(v) < 1e100
    except (OverflowError, ValueError, TypeError):
        ok = False
    if not ok or minimum is not None and v < minimum:
        raise ValueError(name+' outside finite numerical domain')
    return float(v)


def _text(value, name):
    if not isinstance(value, str) or not value.strip():
        raise ValueError(name+' must identify its physical/source record')
    return value


def _digest(value):
    return hashlib.sha256(json.dumps(value, default=asdict, sort_keys=True,
                                    separators=(',', ':'), allow_nan=False).encode()).hexdigest()


@dataclass(frozen=True)
class CMAA74LoadBin:
    """Total suspended LL includes retained block/accessories, even when empty."""
    suspended_mass_kg: float
    cycles: int
    operation: str


@dataclass(frozen=True)
class CMAA74DutyInputs:
    method: str
    source: str
    service_class: str | None = None
    rated_capacity_kg: float | None = None
    spectrum: tuple[CMAA74LoadBin, ...] = ()


@dataclass(frozen=True)
class CMAA74RolledDetail:
    surface_condition: str
    environment: str
    source: str

    def validate(self):
        if self.surface_condition != 'as_rolled_or_cleaned_plain_base_material':
            raise ValueError('Category A requires identified rolled/cleaned plain base surfaces; holes, welds, attachments, damage and unqualified cut edges are excluded')
        if self.environment != 'normal_ambient_noncorrosive':
            raise ValueError('This source class/domain adopts normal ambient, noncorrosive service; other environments require separate qualification')
        _text(self.source, 'Detail surface/environment source')
        return self


def allowable_range(service_class, joint_category):
    if service_class not in RANGES_KSI or not isinstance(joint_category, str) or len(joint_category) != 1 or joint_category not in 'ABCDEF':
        raise ValueError('Explicit CMAA A-D service class and A-F joint category required')
    value = RANGES_KSI[service_class][joint_category]
    return dict(ksi=value, mpa=value*KSI_TO_MPA, service_class=service_class,
                joint_category=joint_category, source=SOURCE+' Table 3.4.7-1, PDF26',
                yield_strength_used=False)


def classify_duty(duty, *, loaded_total_mass_kg, retained_empty_mass_kg):
    """Real bins -> source class; rounded gaps and blank cells remain unsupported.

    rated_capacity_kg is independently identified as the source k denominator.
    It is NOT silently equated with a physical capacity that includes accessories.
    """
    if not isinstance(duty, CMAA74DutyInputs):
        raise ValueError('CMAA74DutyInputs required')
    _text(duty.source, 'Service class or actual load-spectrum source')
    loaded = _real(loaded_total_mass_kg, 'Loaded total LL mass', 0.)
    retained = _real(retained_empty_mass_kg, 'Retained empty LL mass', 0.)
    if retained > loaded:
        raise ValueError('Retained empty LL exceeds loaded LL')
    common = dict(source=SOURCE+' 2.1.3 and Table 2.6-1, PDF16-17',
                  input_source=duty.source, k_is_stress_range_multiplier=False,
                  calculated_finite_life=False)
    if duty.method == 'explicit_sourced_service_class':
        if duty.service_class not in RANGES_KSI or duty.spectrum or duty.rated_capacity_kg is not None:
            raise ValueError('Explicit-class method needs A-D only, without unused numerical spectrum inputs')
        return dict(**common, status='SERVICE_CLASS_SUPPLIED', service_class=duty.service_class,
                    class_derived_from_spectrum=False, declared_service_life_cycles=None)
    if duty.method != 'source_load_spectrum' or duty.service_class is not None:
        raise ValueError('Choose sourced explicit class OR source load-spectrum classification')
    rated = _real(duty.rated_capacity_kg, 'Source rated capacity denominator', 1e-12)
    if any(not isinstance(b, CMAA74LoadBin) for b in duty.spectrum):
        raise ValueError('Physical load bins required')
    if not duty.spectrum or not any(b.operation == 'empty' for b in duty.spectrum):
        raise ValueError('Spectrum must explicitly include empty operations, including a stated zero count if none occur')
    total = 0
    for b in duty.spectrum:
        if not isinstance(b, CMAA74LoadBin):
            raise ValueError('Physical load bins required')
        mass = _real(b.suspended_mass_kg, 'Spectrum total suspended LL', 0.)
        if type(b.cycles) is not int or b.cycles < 0 or b.operation not in ('empty', 'carrying_payload'):
            raise ValueError('Nonnegative integer cycles and identified empty/payload operation required')
        if b.operation == 'empty' and abs(mass-retained) > 1e-9*max(1., retained):
            raise ValueError('Empty spectrum bin must retain the same physical block/accessory mass')
        if not retained <= mass <= loaded:
            raise ValueError('Spectrum mass is outside the generated physical empty-to-loaded LL domain')
        total += b.cycles
    if not total:
        raise ValueError('Spectrum requires positive total service cycles')
    k = cbrt(fsum((b.suspended_mass_kg/rated)**3*(b.cycles/total) for b in duty.spectrum))
    bands = ((.35, .53), (.531, .67), (.671, .85), (.851, 1.))
    # Tolerance only absorbs cubic/root floating-point roundoff, not printed gaps.
    load_index = next((i for i, (lo, hi) in enumerate(bands) if lo-1e-14 <= k <= hi+1e-14), None)
    cycle_index = None if total < 20000 else 0 if total < 100000 else 1 if total < 500000 else 2 if total <= 2000000 else 3
    result = dict(**common, k=k, total_cycles=total, declared_service_life_cycles=total,
                  rated_capacity_kg=rated, load_class=None if load_index is None else 'L'+str(load_index+1),
                  cycle_class=None if cycle_index is None else 'N'+str(cycle_index+1),
                  class_derived_from_spectrum=True, spectrum=[asdict(b) for b in duty.spectrum],
                  cycle_boundary_policy='Use higher band at 100000/500000; N4 strictly greater than 2000000',
                  rounded_load_band_policy='No interpolation through printed gaps and no below-0.35 extension')
    if load_index is None or cycle_index is None:
        return dict(**result, status='DUTY_OUTSIDE_PRINTED_BANDS', service_class=None)
    cls = CLASS_MATRIX[load_index][cycle_index]
    return dict(**result, status='DUTY_BLANK_CLASS_CELL' if cls is None else 'SERVICE_CLASS_DERIVED', service_class=cls)


def _empty_transfer(p, physical):
    validate_cmaa_mass_ledger(p,physical)
    if p.transfer_model=='free_suspended_at_crab':
        return p.suspension_point_x_mm,p.suspension_point_z_mm
    if p.retained_suspended_mass_kg:
        return p.retained_suspended_cg_x_mm,p.retained_suspended_cg_z_mm
    return 0.,0.


def generate_top_case1_actions(basis, bridge_inputs, physical):
    """Regenerate physical four-contact nominal actions, never NBR/EN totals."""
    if not isinstance(basis, (TopUnstiffenedBasis, TopIntermediateBasis)) or not isinstance(bridge_inputs, TopBridgeInputs):
        raise ValueError('Explicit top nominal basis and original physical TopBridgeInputs required')
    basis.validated_project()
    if not isinstance(physical, CMAA74PhysicalInputs):
        raise ValueError('CMAA74PhysicalInputs required')
    physical.validate()
    p = bridge_inputs
    ex, ez = _empty_transfer(p, physical)
    factors = dict(DLF_B=dead_load_factor(physical.bridge_travel_speed_m_s),
                   DLF_T=dead_load_factor(physical.trolley_travel_speed_m_s),
                   HLF=hoist_load_factor(physical.hoist_speed_m_s),
                   IFD_bridge=inertia_drive_factor(p.bridge_acceleration_m_s2),
                   IFD_trolley=inertia_drive_factor(p.trolley_acceleration_m_s2))
    ab, at = factors['IFD_bridge']*p.gravity_m_s2, factors['IFD_trolley']*p.gravity_m_s2
    effective=replace(p,bridge_acceleration_m_s2=ab,trolley_acceleration_m_s2=at)
    common_domain=_generate_domain(effective)
    free = p.transfer_model == 'free_suspended_at_crab'
    heights = (p.suspension_point_z_mm,) if free else tuple(sorted(set((p.lifted_cg_z_min_mm, p.lifted_cg_z_max_mm))))
    lx = p.suspension_point_x_mm if free else p.lifted_cg_x_mm
    cases = []
    for hi, hook in enumerate(sorted(set((p.hook_min_from_left_mm, p.hook_max_from_left_mm)))):
        for loaded in (False, True):
            for zi, z in enumerate(heights if loaded else (ez,)):
                # All four origins come from the common ledger. Empty operation
                # removes payload parcels only; retained suspended B survives.
                raw=next(r['generated'] for r in common_domain['records']
                    if r['hook_mm']==hook and (not loaded or r['force_height_mm']==z))
                for sx, sy in product((-1, 1), repeat=2):
                    contacts = []
                    applied = []
                    for c in raw['contacts']:
                        origins = {}
                        for parcel in raw['parcels']:
                            vector=next(r['force_N'] for r in parcel['loads'] if r['contact_id'] == c['id'])
                            origins[parcel['mass_id']+'/'+parcel['action']] = [0.,0.,0.] if not loaded and parcel['kind']=='lifted' else vector
                        v = [0., 0., 0.]
                        for key, factor in (('bridge/gravity', factors['DLF_B']), ('trolley/gravity', factors['DLF_T']), ('payload/gravity', 1+factors['HLF']), ('retained_suspended/gravity', 1+factors['HLF'])):
                            for j in range(3):
                                v[j] += factor*origins[key][j]
                        hx = [fsum(origins[m+'/HX'][j] for m in ('bridge','trolley','payload','retained_suspended')) for j in range(3)]
                        hy = [fsum(origins[m+'/HY'][j] for m in ('bridge','trolley','payload','retained_suspended')) for j in range(3)]
                        v = [v[j]+sx*hx[j]+sy*hy[j] for j in range(3)]
                        contacts.append(dict(id=c['id'], position_mm=c['position_mm'], rail_index=c['rail_index'], force_N=v,
                                             DL_N=-origins['bridge/gravity'][2], TL_N=-origins['trolley/gravity'][2], LL_N=-origins['payload/gravity'][2]-origins['retained_suspended/gravity'][2],
                                             payload_N=-origins['payload/gravity'][2],retained_LL_N=-origins['retained_suspended/gravity'][2],
                                             IFD_bridge_vector_N=hx, IFD_trolley_vector_N=hy, origins=origins))
                    # Independent total-resultant identity preserves signed horizontal-height redistribution.
                    for parcel in raw['parcels']:
                        if not loaded and parcel['kind']=='lifted':continue
                        f = (factors['DLF_B'] if parcel['mass_id'] == 'bridge' else factors['DLF_T'] if parcel['mass_id'] == 'trolley' else 1+factors['HLF']) if parcel['action'] == 'gravity' else sx if parcel['action'] == 'HX' else sy
                        applied.append(dict(position_mm=parcel['source_position_mm'], force_N=[f*v for v in parcel['source_force_N']]))
                    equilibrium = _compare(_resultant(contacts), _resultant(applied))
                    for rail in (0, 1):
                        ident = f'CMAA74_CASE1/hook{hi}/'+('loaded' if loaded else 'empty')+f'/height{zi}/IFDX{sx:+d}/IFDY{sy:+d}/rail{rail}'
                        cases.append(dict(id=ident, action_basis=ACTION_BASIS, formula=CASE1_FORMULA, edition=EDITION,
                            bridge_inputs=asdict(p), physical_inputs=asdict(physical), factors=dict(factors, longitudinal_sign=sx, transverse_sign=sy),
                            loaded=loaded, rail_index=rail, hook_mm=hook, transfer_height_mm=z,
                            full_contacts=contacts, equilibrium=equilibrium,
                            contact_domain_valid=all(c['force_N'][2] <= 1e-9 for c in contacts),
                            source=SOURCE+' 3.3.2.1 and 3.3.2.5.1; separate DL/TL/LL and IFD, PDF18-21'))
    return tuple(cases)


def _prepare_generated(basis, case, *, include_permanent):
    if not case['contact_domain_valid']:
        raise ValueError('All-state no-hold-down contact domain not established; not observed physical lift-off')
    p = deepcopy(basis.project)
    contacts = [c for c in case['full_contacts'] if c['rail_index'] == case['rail_index']]
    origin = min(c['position_mm'][0] for c in contacts)
    p.wheels = [WheelInput((c['position_mm'][0]-origin)/1000, -c['force_N'][2]/1000, 0., c['force_N'][1]/1000, c['force_N'][0]/1000) for c in contacts]
    permanent = 1. if include_permanent else 0.
    # Complete precombined Case1 wheel vector; no inherited NBR factors, H sign or dynamics.
    f = CaseFactors(case['id'], permanent, 1., 0., 1., 1., case['source'], extra_dead=permanent)
    return prepare_case(replace(basis, project=p), f)


def prepare_top_case1(basis, case, *, include_permanent=True):
    """Public adapter rejects modified/stale external case resultants."""
    if type(include_permanent) is not bool:
        raise ValueError('Explicit permanent-load selection required')
    fresh = next((c for c in generate_top_case1_actions(basis, TopBridgeInputs(**case['bridge_inputs']), CMAA74PhysicalInputs(**case['physical_inputs'])) if c['id'] == case['id']), None)
    if fresh is None or _digest(fresh) != _digest(case):
        raise ValueError('Stale/tampered Case1 ledger; regenerate from physical inputs')
    return _prepare_generated(basis, fresh, include_permanent=include_permanent)


def signed_flange_intervals(prepared):
    """Uniform enclosure at EACH fixed fiber and x; not attained global extrema.

    Unit point-force moment is in [0,L/4]. Unit point-couple moment is in [-1,1].
    Fx is included once through downstream axial-force sums. Correlated major
    and flange-lateral contributions are combined per wheel BEFORE bounds.
    Fixed runway permanent stress cancels in a range and must be removed first.
    """
    c = prepared
    if not isinstance(c, PreparedCase) or any((c.udl.vertical_kn_per_m, c.udl.longitudinal_kn_per_m,
            c.top_udl.horizontal_kn_per_m, c.bottom_udl.horizontal_kn_per_m)):
        raise ValueError('Moving-only internally prepared case required; permanent stress cancels at the same material point')
    if any(any((w.vertical_kn, w.horizontal_kn, w.longitudinal_kn, w.major_moment_knm, w.minor_moment_knm))
           for rows in (c.major_fixed, c.top_fixed, c.bottom_fixed) for w in rows):
        raise ValueError('Moving-only internally prepared case required; permanent stress cancels at the same material point')
    s, g, L = c.project.section, c.properties, c.project.span_m
    axial_lo = fsum(min(0., w.longitudinal_kn) for w in c.source_wheels)*1000/g.A_mm2
    axial_hi = fsum(max(0., w.longitudinal_kn) for w in c.source_wheels)*1000/g.A_mm2
    out = {}
    for flange, sign, wheels in (('top', 1, c.top_wheels), ('bottom', -1, c.bottom_wheels)):
        for face, z in (('outer', sign*s.d_mm/2), ('inner', sign*(s.d_mm/2-s.tf_mm))):
            for edge, y in (('left', -s.bf_mm/2), ('right', s.bf_mm/2)):
                a, b = -1e6*z/g.Ix_mm4, 1e6*y/c.flange_I_mm4
                F = [a*w.vertical_kn+b*f.horizontal_kn for w, f in zip(c.source_wheels, wheels)]
                C = [a*w.major_moment_knm+b*f.minor_moment_knm for w, f in zip(c.source_wheels, wheels)]
                lo = axial_lo+L/4*fsum(min(0., v) for v in F)-fsum(abs(v) for v in C)
                hi = axial_hi+L/4*fsum(max(0., v) for v in F)+fsum(abs(v) for v in C)
                _real(lo, 'Derived signed lower stress'); _real(hi, 'Derived signed upper stress')
                out[f'{flange}_{face}_{edge}'] = dict(lower_mpa=lo, upper_mpa=hi, y_mm=y, z_mm=z)
    return out


def _fixed_point_witnesses(cases, x):
    """Actual signed states at the SAME x/fiber, not independently moving maxima.

    Event/midpoint observations establish witnessed lower range, never coverage.
    No finite-cycle occurrence or joint probability is inferred from extrema.
    """
    out = {}
    for case, c in cases:
        L = c.project.span_m
        _real(x, 'Fixed section x', 0.)
        if x > L:
            raise ValueError('Fixed fatigue section lies outside support span')
        side = 'left' if x == L else 'right'
        events = c.translation_events(section_positions_m=(x,))
        ts = sorted({*events, *((a+b)/2 for a, b in zip(events[:-1], events[1:]))})
        for t in ts:
            row = c.solve_position(t).at(x, side)
            for fiber, stress in row['stresses'].items():
                v = stress['sigma_x_mpa']
                witness = dict(sigma_mpa=v, case=case['id'], rail_index=case['rail_index'], x_m=x, translation_m=t, side=side)
                target = out.setdefault((case['rail_index'], fiber), dict(minimum=witness, maximum=witness))
                if v < target['minimum']['sigma_mpa']:
                    target['minimum'] = witness
                if v > target['maximum']['sigma_mpa']:
                    target['maximum'] = witness
    return [dict(rail_index=rail, fiber=fiber, x_m=x,
                 witnessed_range_mpa=row['maximum']['sigma_mpa']-row['minimum']['sigma_mpa'], **row)
            for (rail, fiber), row in out.items()]


def _source_receipt():
    import lro_beams
    root = Path(__file__).resolve().parents[1]
    lib = Path(lro_beams.__file__).resolve().parent
    local = [Path(__file__), *[Path(__file__).with_name(n) for n in ('actions.py', 'bounds.py', 'mechanics.py', 'nominal_forces.py')]]
    local += [root/'underslung_runway_candidate'/n for n in ('cmaa74/__init__.py', 'cmaa74/actions.py', 'cmaa74/kernel.py',
        'cmaa74/autonomous_adapter.py', 'autonomous_workflow/inertia_bridge_adapter.py',
        'autonomous_workflow/model.py', 'bridge_inertia/statics.py')]
    # The reviewed source document is provenance, not an executable runtime
    # dependency. Its verified digest stays explicit without shipping the PDF.
    hashes = {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest() for p in local}
    from .source_closure import candidate_import_closure
    hashes.update(candidate_import_closure('top_unstiffened_candidate.cmaa_fatigue'))
    hashes.update({'lro_beams/'+p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in lib.glob('*.py')})
    return dict(sha256=_digest(hashes), files=hashes, references={'CMAA74_2020_primary_pdf_sha256':PRIMARY_PDF_SHA256})


def evaluate_top_cmaa_fatigue(basis, bridge_inputs, physical, duty, detail, *, witness_sections_m=()):
    """Physical inputs -> Case1 flange-normal range, with explicit missing scopes.

    Even a sufficient scalar result never sets qualified_nominal_detail_modes,
    member fatigue or whole-design completion. A supplementary verified
    multiaxial/local criterion is still necessary; no EN criterion is borrowed.
    """
    start = _source_receipt()
    if not isinstance(detail, CMAA74RolledDetail):
        raise ValueError('Source-identified plain rolled detail required')
    detail.validate()
    actions = generate_top_case1_actions(basis, bridge_inputs, physical)
    classification = classify_duty(duty, loaded_total_mass_kg=bridge_inputs.capacity_t*1000+bridge_inputs.retained_suspended_mass_kg,
                                   retained_empty_mass_kg=physical.empty_suspended_mass_kg)
    common = dict(edition=EDITION, action_basis=ACTION_BASIS, formula=CASE1_FORMULA,
        duty=classification, detail=asdict(detail), joint_category='A',
        physical_inputs=asdict(physical), bridge_inputs=asdict(bridge_inputs), action_case_count=len(actions),
        input_signature=_digest(dict(basis=basis.provenance(), project=asdict(basis.project), bridge=asdict(bridge_inputs), physical=asdict(physical), duty=asdict(duty), detail=asdict(detail))),
        action_scope='Declared normal Case1 operating endpoint domain, both rails, signed IFD and empty retained LL; no WLO/SK/exceptional events',
        action_interpolation='Convex interpolation of source force/moment endpoint ledgers; physical equalization and transfer model are explicit adopted premises',
        normal_stress_axis='Longitudinal: mechanics sigma_x = native CMAA sigma_y',
        stress_range_uses_k=False, physical_stiffeners='absent', external_efforts_required=False,
        qualified_nominal_detail_modes=False, member_fatigue_complete=False, whole_design_complete=False,
        source_review_status='CANDIDATE_PENDING_INDEPENDENT_REVIEW',
        multiaxial_status='UNQUALIFIED_NO_VERIFIED_CMAA_ROTATING_PRINCIPAL_AXIS_RULE',
        calculated_finite_life=False, miner_damage_calculated=False, von_mises_range_used=False,
        local_sigmaT_calculated=False, physical_full_3d_tensor_claim=False, duplicate_vlasov_b=False,
        assessed_scope='Signed longitudinal normal range in ordinary rectangular rolled-flange fiber families under the adopted two-flange nominal analogy',
        excluded_scopes=['Shear and combined multiaxial fatigue', 'Local transverse/contact/rolling-contact fatigue and web/fillet stress fields',
                         'Holes, welds, attachments, damaged surfaces, rail fasteners and disturbed connection/support zones',
                         'Maximum-stress ASD combination/buckling checks required separately by 3.4.7'],
        permanent_range_treatment='Fixed runway steel/rail/extra-dead stress cancels exactly at the same point; moving bridge DL and trolley TL do not cancel',
        normative_scope='CMAA74 single-girder crane with under-running trolley' if physical.crane_configuration == 'single_girder_under_running_trolley' else 'Explicit adopted CMAA nominal-method supplement; crane applicability not established')
    bad = next((a for a in actions if not a['contact_domain_valid']), None)
    if bad:
        return dict(**common, status='CONTACT_DOMAIN_SUFFICIENT_GUARD_INCONCLUSIVE',
                    qualified_longitudinal_range=False, case=bad, source_receipt=start)
    if classification['service_class'] is None:
        return dict(**common, status=classification['status'], qualified_longitudinal_range=False, source_receipt=start)
    limit = allowable_range(classification['service_class'], 'A')
    ranges, receipts, prepared = {}, [], []
    maximum_abs = 0.
    for action in actions:
        c = _prepare_generated(basis, action, include_permanent=False)
        intervals = signed_flange_intervals(c)
        prepared.append((action, c))
        # Maximum stress is not ignored; full Case1 + fixed runway G is reported
        # separately, without falsely turning one scalar bound into ASD closure.
        full_bound = prepared_absolute_bounds(_prepare_generated(basis, action, include_permanent=True))['sx_abs_mpa']
        maximum_abs = max(maximum_abs, full_bound)
        receipts.append(dict(id=action['id'], factors=action['factors'], loaded=action['loaded'], rail_index=action['rail_index'],
                             full_contacts=action['full_contacts'], equilibrium=action['equilibrium'],
                             scalar_intervals_mpa=intervals, maximum_normal_abs_bound_mpa=full_bound))
        for fiber, interval in intervals.items():
            key = (action['rail_index'], fiber)
            row = ranges.setdefault(key, dict(lower_mpa=0., upper_mpa=0., lower_case=None, upper_case=None))
            for end in ('lower', 'upper'):
                improves = interval[end+'_mpa'] < row[end+'_mpa'] if end == 'lower' else interval[end+'_mpa'] > row[end+'_mpa']
                if improves:
                    row[end+'_mpa'] = interval[end+'_mpa']; row[end+'_case'] = action['id']
    results = [dict(rail_index=rail, fiber=fiber, **row, range_upper_mpa=row['upper_mpa']-row['lower_mpa'],
                    utilization_upper=(row['upper_mpa']-row['lower_mpa'])/limit['mpa']) for (rail, fiber), row in ranges.items()]
    governing = max(results, key=lambda r:r['utilization_upper'])
    passed = governing['utilization_upper'] <= 1.
    witnesses = [row for x in witness_sections_m for row in _fixed_point_witnesses(prepared, x)]
    witnessed_exceedance = any(row['witnessed_range_mpa'] > limit['mpa'] for row in witnesses)
    end = _source_receipt()
    status = 'CMAA74_LONGITUDINAL_RANGE_SUFFICIENT' if passed else 'CMAA74_LONGITUDINAL_RANGE_BOUND_INCONCLUSIVE'
    if witnessed_exceedance:
        status = 'CMAA74_LONGITUDINAL_RANGE_WITNESSED_EXCEEDANCE'
    if start['sha256'] != end['sha256']:
        status, passed = 'SOURCE_CHANGED_DURING_ASSESSMENT', False
    return dict(**common, status=status, qualified_longitudinal_range=passed,
        allowable=limit, ranges=results, governing=governing, fixed_point_witnesses=witnesses,
        range_bound_method='Signed all-position Green-function triangle enclosure, valid at every fixed x/fiber; extrema need not coexist',
        witnessed_exceedance_of_declared_state_envelope=witnessed_exceedance,
        maximum_normal_abs_bound_mpa=maximum_abs, maximum_stress_ASD_complete=False,
        floating_point_interval_certificate=False, case_receipts=receipts, source_receipt=end)
