"""Internal physical generation, isolated source families and honest scope outcomes.

Analytical all-position bounds are fast sufficient checks. Selected actual
witness positions may prove failure but never certify a nonlinear envelope.
"""
from __future__ import annotations
from dataclasses import asdict,dataclass
from hashlib import sha256
from itertools import product
from pathlib import Path
from collections import Counter
import time
from math import isfinite

from lro_beams.autonomous_actions import variants_8800
from underslung_runway_candidate.autonomous_workflow.model import signature
from .project import TopWorkflowProject, checked_tree, CALCULATION_FORMAT, validate_document_metadata
from .actions import generate_top_action_domain
from .bounds import prepared_absolute_bounds


@dataclass(frozen=True)
class AnalysisControls:
    witness_positions: str='events_and_midpoints'
    evaluate_fatigue: bool=True
    evaluate_service: bool=True
    def validate(self):
        if self.witness_positions not in ('events_and_midpoints','none'): raise ValueError('Unknown witness policy')
        if type(self.evaluate_fatigue) is not bool or type(self.evaluate_service) is not bool: raise ValueError('Explicit analysis options required')
        return self


def source_receipt():
    """Portable static numerical import closure plus immutable catalog data.

    Resolve installed package locations, never silently omit a repository path.
    Imports inside functions also belong to this closure. Presentation-only
    modules are not seeds, so formatting edits do not invalidate calculations.
    """
    import ast,importlib.util,platform
    prefixes=('top_unstiffened_candidate','lro_beams','underslung_runway_candidate')
    queue=['top_unstiffened_candidate.'+n for n in ('project','pipeline','mechanics','actions','bounds','checks','fatigue','stability','service','nominal_forces','reference_bound')]
    seen=set();files={}
    while queue:
        name=queue.pop()
        if name in seen:continue
        seen.add(name)
        spec=importlib.util.find_spec(name)
        if spec is not None and spec.origin is None and spec.submodule_search_locations is not None:
            if not all(Path(p).is_dir() for p in spec.submodule_search_locations):raise ValueError('Missing namespace package: '+name)
            continue
        if spec is None or not spec.origin or not Path(spec.origin).is_file():
            raise ValueError('Required numerical module missing: '+name)
        path=Path(spec.origin)
        if path.suffix!='.py':raise ValueError('Expected inspectable Python numerical module: '+name)
        files[name.replace('.','/')+('/__init__.py' if spec.submodule_search_locations is not None else '.py')]=sha256(path.read_bytes()).hexdigest()
        package=name if spec.submodule_search_locations is not None else name.rpartition('.')[0]
        # Package initialization is executable and must be included too.
        if '.' in name:queue.append(name.rpartition('.')[0])
        tree=ast.parse(path.read_text(encoding='utf-8'))
        for node in ast.walk(tree):
            candidates=[]
            if isinstance(node,ast.Import):candidates=[a.name for a in node.names]
            elif isinstance(node,ast.ImportFrom):
                if node.module:
                    candidates=[importlib.util.resolve_name('.'*node.level+node.module,package) if node.level else node.module]
                elif node.level:
                    base=importlib.util.resolve_name('.'*node.level,package)
                    candidates=[base+'.'+a.name for a in node.names if a.name!='*']
            queue.extend(v for v in candidates if v.split('.')[0] in prefixes and v not in seen)
    import lro_beams,numpy,scipy
    runtime=Path(lro_beams.__file__).resolve().parent
    for name in ('profiles.json','catalog_manifest.json','crane_catalog_records.json'):
        path=runtime/'data'/name
        if not path.is_file():raise ValueError('Required catalog dependency missing: '+name)
        files['lro_beams/data/'+name]=sha256(path.read_bytes()).hexdigest()
    libraries=dict(python=platform.python_version(),numpy=numpy.__version__,scipy=scipy.__version__)
    return dict(sha256=signature(dict(files=files,libraries=libraries)),files=files,libraries=libraries)


def presentation_receipt():
    files={name:sha256(Path(__file__).with_name(name).read_bytes()).hexdigest() for name in ('ui.py','report.py','fatigue_ui.py','verification_lengths_ui.py','detail_gallery.py')}
    for name in ('stiffeners/ui.py','stiffeners/report.py'):
        files[name]=sha256((Path(__file__).parent/name).read_bytes()).hexdigest()
    gallery=Path(__file__).parent/'assets'/'fatigue_details'
    for name in ('catalog_manifest.json',*[f'cmaa_detail_{letter}.png' for letter in 'ABCDEF']):
        files['assets/fatigue_details/'+name]=sha256((gallery/name).read_bytes()).hexdigest()
    from underslung_runway_candidate.autonomous_ui import family_report
    files['underslung_runway_candidate/autonomous_ui/family_report.py']=sha256(Path(family_report.__file__).read_bytes()).hexdigest()
    return dict(sha256=signature(files),files=files)


def _pending(reason):
    return dict(status='PENDING',pending=[reason],checks=[],actual_failure_proven=False,design_complete=False)


def _normalized_scope_check(check):
    """Read-only typed projection of the two native D.5 result schemas.

    Their capacity is a mapping, not a scalar resistance. No arbitrary mapping
    or favorable label is accepted, and both existing bound decisions survive.
    """
    if not isinstance(check.get('capacity'),dict):return check
    kinds={'NBR8400_2_source_qualified_planar_nominal_member_fatigue',
           'NBR8400_2_directional_stiffener_receiver_nominal_fatigue'}
    out=dict(check);cap=check['capacity'];bound=check.get('bound')
    valid=(type(check.get('kind')) is str and check['kind'] in kinds and check.get('input_valid') is True
        and not any(k in check for k in ('demand','demand_mpa','capacity_mpa'))
        and type(check.get('sufficient_planar_bound_satisfied')) is bool
        and isinstance(bound,dict))
    if valid:
        valid=all(type(bound.get(k)) is bool for k in
            ('individual_bounds_satisfied','interaction_bound_satisfied','sufficient_bound_satisfied'))
        for key in ('normal_x_capacity_mpa','normal_y_capacity_mpa','shear_capacity_mpa'):
            value=cap.get(key)
            inactive=(key=='normal_y_capacity_mpa' and value is None
                and bound.get('inactive_parallel_normal_normalization_only') is True
                and bound.get('parallel_normal_capacity_claimed') is False
                and isinstance(bound.get('component_utilizations'),dict)
                and type(bound['component_utilizations'].get('sigma_y')) in (int,float)
                and bound['component_utilizations']['sigma_y']==0.)
            if not inactive and (type(value) not in (int,float) or not isfinite(value) or value<=0):valid=False
        u=bound.get('combined_utilization_upper_bound')
        if type(u) not in (int,float) or not isfinite(u) or u<0:valid=False
    if not valid:
        out['input_valid']=False
        return out
    out.pop('capacity')
    out['utilization']=bound['combined_utilization_upper_bound']
    out['sufficient_bound_satisfied']=(check['sufficient_planar_bound_satisfied']
        and bound['sufficient_bound_satisfied'] and bound['individual_bounds_satisfied']
        and bound['interaction_bound_satisfied'])
    return out


def _zero_uplift_check(check):
    # A zero permitted uplift is a contact constraint, not a zero resistance.
    return (check.get('id') in ('support_left_contact_uplift_bound','support_right_contact_uplift_bound')
        and check.get('unit')=='kN'
        and all(type(check.get(k)) in (int,float) and check[k]==0. for k in ('demand','capacity','utilization')))


def _outcome(items):
    """Exact known states, with failure and missing evidence taking precedence."""
    items=list(items)
    if not items:return 'PENDING'
    accepted={'SATISFIED','PASS','SUFFICIENT','COMPONENT_CHECKS_SATISFIED',
        'SUFFICIENT_BOUND_SATISFIED','SUFFICIENT_STABILITY_BOUND_SATISFIED',
        'SUFFICIENT_SERVICE_BOUND_SATISFIED','CMAA_NBR_STRENGTH_BOUNDS_SATISFIED',
        'NOMINAL_METHOD_ZERO_CALCULATED_DAMAGE_SUFFICIENT','CMAA74_LONGITUDINAL_RANGE_SUFFICIENT',
        'SUFFICIENT_NOMINAL_MEMBER_FATIGUE_BOUNDS_SATISFIED','SUFFICIENT_NOMINAL_WALL_FATIGUE_BOUNDS_SATISFIED',
        'SUFFICIENT_NOMINAL_FATIGUE_BOUNDS_SATISFIED','SUFFICIENT_PLANAR_NOMINAL_FATIGUE_BOUND_SATISFIED'}
    inconclusive={'INCONCLUSIVE','INCONCLUSIVE_CMAA_NBR_STRENGTH_BOUNDS','INCONCLUSIVE_SUFFICIENT_BOUND',
        'INCONCLUSIVE_SUFFICIENT_FATIGUE_BOUND','SUFFICIENT_CHECK_NOT_SATISFIED',
        'CMAA74_LONGITUDINAL_RANGE_BOUND_INCONCLUSIVE','CMAA74_LONGITUDINAL_RANGE_WITNESSED_EXCEEDANCE',
        'CONTACT_DOMAIN_SUFFICIENT_GUARD_INCONCLUSIVE'}
    states=[]
    for item in items:
        if not isinstance(item,dict):states.append('PENDING');continue
        status=item.get('status','PENDING');checks=item.get('checks',[])
        if not isinstance(checks,(list,tuple)):states.append('PENDING');continue
        children=[_normalized_scope_check(v) for v in checks if isinstance(v,dict)]
        if item.get('actual_failure_proven') is True or status=='FAIL' or any(c.get('actual_failure_proven') is True or c.get('status')=='FAIL' for c in children):
            states.append('FAIL')
        elif (type(status) is not str or item.get('input_valid',True) is not True or item.get('pending') or item.get('errors') or item.get('unresolved_mode_ids')
                or len(children)!=len(checks)
                or any(c.get('input_valid',True) is not True or c.get('pending') or c.get('errors') or c.get('unresolved_mode_ids') for c in children)):
            states.append('PENDING')
        elif any(type(c.get('status')) is not str or c.get('status') not in accepted|inconclusive|{'FAIL'} for c in children):
            states.append('PENDING')
        elif any(type(c['utilization']) not in (int,float) or not isfinite(c['utilization']) or c['utilization']<0
                for c in children if 'utilization' in c):
            states.append('PENDING')
        elif any(type(c[k]) is not bool for c in children for k in ('sufficient_bound_satisfied','criterion_satisfied') if k in c):
            states.append('PENDING')
        elif any(type(c[k]) not in (int,float) or not isfinite(c[k]) or (c[k]<0 if k.startswith('demand') else c[k]<0 or (c[k]==0 and not _zero_uplift_check(c)))
                for c in children for k in ('demand','capacity','demand_mpa','capacity_mpa') if k in c):
            states.append('PENDING')
        elif any(c[d]>c[cap] for c in children for d,cap in (('demand','capacity'),('demand_mpa','capacity_mpa')) if d in c and cap in c):
            states.append('INCONCLUSIVE')
        elif status in inconclusive or any(c.get('status') in inconclusive or c.get('sufficient_bound_satisfied') is False
                or c.get('utilization',0)>1 for c in children):states.append('INCONCLUSIVE')
        elif status in accepted:states.append('SATISFIED')
        else:states.append('PENDING')
    return next((s for s in ('FAIL','PENDING','INCONCLUSIVE') if s in states),'SATISFIED')


def _scope(label,items):
    items=list(items)
    return dict(label=label,status=_outcome(items),checks_count=sum(len(v.get('checks',[])) for v in items),
        actual_failure_proven=any(_outcome([v])=='FAIL' for v in items),
        pending=list(dict.fromkeys(str(p) for v in items for p in v.get('pending',[]))),
        outcome_counts=dict(Counter(_outcome([v]) for v in items)),whole_design_complete=False)


def _safe(fn,*args,**kwargs):
    try:return fn(*args,**kwargs)
    except (ValueError,TypeError,KeyError,AttributeError,ArithmeticError) as exc:return _pending(type(exc).__name__+': '+str(exc))


def _witness_translations(prepared):
    xs=prepared.translation_events(section_positions_m=(prepared.project.span_m/2,))
    return sorted(set(xs)|{(a+b)/2 for a,b in zip(xs[:-1],xs[1:])})


def analyze_project(project,*,controls=None,progress=None):
    if not isinstance(project,TopWorkflowProject):raise ValueError('Typed physical project required')
    project.validate();controls=(controls or AnalysisControls()).validate()
    if project.intermediates is not None:
        from .stiffeners.workflow import analyze_intermediate_project
        return analyze_intermediate_project(project,controls=controls,progress=progress)
    start=time.monotonic();before=source_receipt();input_sig=signature(project.to_dict())
    basis=project.basis();bridge=project.bridge
    dynamics=project.actions.dynamics();psi=dynamics['psi']
    cmaa_strength=None
    if project.cmaa_actions is not None:
        from .cmaa_strength import evaluate_top_cmaa_nbr_strength
        cmaa_strength=_safe(evaluate_top_cmaa_nbr_strength,basis,bridge,project.cmaa_action_physical(),
            stability_premises=project.stability,extra_dead_kind=project.structure.extra_dead_kind,
            verification_lengths=project.verification_lengths,
            progress=(lambda n,total:progress(n,total,'Origens CMAA, cantos do limite SK e estabilidade comum da família')) if progress else None)
        cases=cmaa_strength.get('cases',[])
        strength=[cmaa_strength.get('section_components',_pending('CMAA section component evaluation unavailable.'))]
        web=[cmaa_strength.get('bare_web',_pending('CMAA bare web evaluation unavailable.'))]
        # Never attach the common nonlinear stability envelope to one force-box
        # corner: its independent maxima are not a concurrent physical state.
        stability=[cmaa_strength.get('stability',_pending('CMAA common family stability evaluation unavailable.'))]
        endpoints=sorted({(c['hook_mm'],c['transfer_height_mm']) for c in cases})
        configurations={(c['hook_mm'],c['transfer_height_mm'],c['rail_index']) for c in cases}
        endpoint_count=len(endpoints);runway_configuration_count=len(configurations)
        domain=dict(kind='CMAA_CHARACTERISTIC_ORIGIN_DOMAIN',
            action_basis=cmaa_strength.get('action_basis'),
            physical_endpoint_coordinates=[dict(hook_mm=h,transfer_height_mm=z) for h,z in endpoints],
            characteristic_action_case_count=cmaa_strength.get('action_case_count',0),
            coverage=cmaa_strength.get('coverage',{}),
            box_design_cases_are_not_physical_records=True,
            physical_force_witnesses_generated=False)
        all_prepared=bool(cases) and all(c.get('prepared_signature') for c in cases)
        contact=[dict(status='COMPONENT_CHECKS_SATISFIED',checks=[],pending=[],actual_failure_proven=False)] if all_prepared else [
            _pending('Not every CMAA source-origin contact case was prepared; see the selected action family pending reasons.')]
    else:
        domain=generate_top_action_domain(basis,bridge)
        factors=[]
        for present in (True,False):
            for f in variants_8800(psi=psi,extra_dead_kn_per_m=project.structure.extra_dead_kn_per_m,
                                  extra_dead_kind=project.structure.extra_dead_kind,variables=('crane',) if present else ()):
                factors.append((present,f))
        cases=[];strength=[];web=[];stability=[];contact=[]
        from .checks import prepare_normal_uls_physical_case,check_uls_all_positions,bare_web_all_positions,check_uls_position,bare_web_position
        from .stability import evaluate_prepared_case
        total=len(domain['records'])*len(factors)*2*2*4
        for idx,(record,(present,f),loaded,rail,sx,sy) in enumerate(product(domain['records'],factors,(False,True),(0,1),(-1,1),(-1,1)),1):
            case_id=f"NBR8800/{record['id']}/rail{rail}/{'loaded' if loaded else 'empty'}/HX{sx:+d}/HY{sy:+d}/{'crane' if present else 'G_only'}/{f.code}"
            entry=dict(id=case_id,record_id=record['id'],rail_index=rail,loaded=loaded,longitudinal_sign=sx,transverse_sign=sy,
                       crane_variable_present=present,source_family='NBR8800_NORMAL_ULS',source_factors=asdict(f),
                       horizontal_dynamic_factor=project.actions.horizontal_dynamic_factor,horizontal_dynamic_source=project.actions.horizontal_dynamic_source)
            try:
                c,ledger=prepare_normal_uls_physical_case(basis,record,f,loaded=loaded,rail_index=rail,transverse_sign=sy,longitudinal_sign=sx,
                    horizontal_dynamic_factor=project.actions.horizontal_dynamic_factor,horizontal_dynamic_source=project.actions.horizontal_dynamic_source)
                entry['source_ledger']=asdict(ledger) if hasattr(ledger,'__dataclass_fields__') else ledger
                entry['bounds']=prepared_absolute_bounds(c)
                entry['strength']=_safe(check_uls_all_positions,c,ledger,verification_lengths=project.verification_lengths);entry['bare_web']=_safe(bare_web_all_positions,c,ledger)
                entry['stability']=_safe(evaluate_prepared_case,c,premises=project.stability,verification_lengths=project.verification_lengths) if project.stability else _pending('Supplementary stability adoption/material-environment inputs not supplied.')
                entry['witnesses']=[]
                if controls.witness_positions!='none' and (_outcome([entry['strength']])!='SATISFIED' or _outcome([entry['bare_web']])!='SATISFIED'):
                    for a in _witness_translations(c):
                        response=c.solve_position(a)
                        sw=_safe(check_uls_position,response,ledger,verification_lengths=project.verification_lengths);ww=_safe(bare_web_position,response,ledger)
                        # Keep all selected witness outcomes. A witness set is not a global proof.
                        entry['witnesses'].append(dict(translation_m=a,strength=sw,bare_web=ww))
                        strength.append(sw);web.append(ww)
                middle=sum(c.translation_range_m)/2
                response=c.solve_position(middle)
                entry['concurrent_support_example']=dict(translation_m=middle,claim='Actual concurrent example, not the governing support vector',vectors=response.support_vectors(),equilibrium=response.equilibrium())
                contact.append(dict(status='COMPONENT_CHECKS_SATISFIED',checks=[],pending=[],actual_failure_proven=False))
            except (ValueError,TypeError,KeyError,AttributeError,ArithmeticError) as exc:
                reason=type(exc).__name__+': '+str(exc)
                inconclusive=any(word in str(exc).lower() for word in ('contact domain','contact guard','contact-domain','no-hold-down','nonnegative contact'))
                failed=dict(status='INCONCLUSIVE' if inconclusive else 'PENDING',checks=[],pending=[reason],actual_failure_proven=False,design_complete=False)
                entry.update(strength=failed,bare_web=failed,stability=failed,witnesses=[],preparation_error=reason)
                contact.append(failed)
            strength.append(entry['strength']);web.append(entry['bare_web']);stability.append(entry['stability']);cases.append(entry)
            if progress and (idx==1 or idx==total or idx%32==0):progress(idx,total,'Combinações internas ELU, limites suficientes e testemunhos reais')
        endpoint_count=len(domain['records'])
        runway_configuration_count=endpoint_count*2
    fatigue=_pending('Supplementary EN fatigue physical/detail/operating inputs not supplied or disabled.')
    if project.fatigue is not None and controls.evaluate_fatigue:
        from .fatigue import evaluate_top_fatigue
        fatigue=_safe(evaluate_top_fatigue,basis,bridge,project.fatigue)
    nbr_fatigue=None
    if getattr(project,'nbr_fatigue',None) is not None and controls.evaluate_fatigue:
        from .nbr_fatigue import evaluate_top_nbr_fatigue,ADOPTED_ALTERNATIVE_SCOPE
        nbr_fatigue=_safe(evaluate_top_nbr_fatigue,basis,bridge,project.nbr_fatigue_physical(),psi=psi,
            horizontal_dynamic_factor=project.actions.horizontal_dynamic_factor,
            horizontal_dynamic_source=project.actions.horizontal_dynamic_source,method_scope=ADOPTED_ALTERNATIVE_SCOPE,
            rolling_guidance=project.nbr_rolling_guidance)
    cmaa_fatigue=None
    if getattr(project,'cmaa_fatigue',None) is not None and controls.evaluate_fatigue:
        from .cmaa_fatigue import evaluate_top_cmaa_fatigue
        physical,duty,detail=project.cmaa_fatigue_physical()
        cmaa_fatigue=_safe(evaluate_top_cmaa_fatigue,basis,bridge,physical,duty,detail)
    selected_fatigue=(nbr_fatigue if nbr_fatigue is not None else _pending('Selected NBR fatigue evaluation disabled.')) if project.nbr_fatigue is not None else fatigue
    service=_pending('CMAA service premises not supplied or disabled.')
    if controls.evaluate_service:
        from .service import CMAAServicePremises
        from .native_service import evaluate_top_service_criteria
        service=_safe(evaluate_top_service_criteria,basis,bridge,
            cmaa_premises=CMAAServicePremises(**project.service) if project.service is not None else None,
            nbr_premises=project.nbr_service,manual_limits=project.manual_service,rolling_guidance=project.nbr_rolling_guidance)
    scopes=dict(cmaa_longitudinal_fatigue=_scope('Fadiga longitudinal CMAA por classe e detalhe',[cmaa_fatigue] if cmaa_fatigue is not None else [_pending('CMAA fatigue class/detail inputs not supplied.')]),normal_uls_strength=_scope('Componentes ELU NBR 8800 sobre origens CMAA 74:2020' if cmaa_strength is not None else 'Componentes de resistência ELU NBR 8800',strength),
        bare_web=_scope('Alma sem enrijecedores',web),supplementary_stability=_scope('Estabilidade complementar EN C.2: limite comum da família CMAA' if cmaa_strength is not None else 'Estabilidade complementar EN C.2',stability),
        normal_contact_domain=_scope('Contato comprimido no domínio normal declarado',contact),
        nominal_fatigue=_scope('Fadiga nominal NBR8400 por grupo de componente' if project.nbr_fatigue is not None else 'Fadiga nominal complementar EN: critério suficiente de dano nulo' if project.fatigue is not None else 'Fadiga nominal: método e premissas necessários', [selected_fatigue]),cmaa_service=_scope('Serviço: critérios CMAA, NBR e restrições do projeto',[service]),
        special_actions=_scope('Eventos, ações ocasionais e situações especiais',[_pending('Outdoor operating wind, abrupt engagement, thermal, test, emergency, impact/buffers and assembly remain outside the selected normal CMAA domain; normal SK is included as an independent bound.' if cmaa_strength is not None else 'Wind, thermal, skew/guidance, test, emergency, impact/buffers and assembly are not closed by this normal-operation generator.')]),
        rail_contact=_scope('Contato roda/trilho e fixações',[_pending('Wheel/rail rolling contact and rail fastener checks are separate unimplemented route scopes.')]),
        support_connections=_scope('Ligações de apoio',[_pending('Actual fork/support connection design remains separate from the assessed member scopes.')]),
        receiving_structure=_scope('Estrutura receptora',[_pending('Receiving building/floor design is outside this member calculation; it is not a member strength criterion.')]),
        cmaa_complete_coverage=_scope('Cobertura integral CMAA',[_pending('CMAA preference does not rename NBR/EN/CISC calculations. Only source-labelled implemented CMAA criteria are claimed.')]))
    member_keys=('normal_uls_strength','bare_web','supplementary_stability','nominal_fatigue','cmaa_service')
    member_outcome=_outcome(scopes[k] for k in member_keys)
    scope_groups=dict(assessed_member=list(member_keys),additional_actions=['normal_contact_domain','special_actions'],rail_contact=['rail_contact'],support_connections=['support_connections'],receiving_structure=['receiving_structure'],full_code_coverage=['cmaa_complete_coverage'])
    outcome=_outcome(scopes.values())
    after=source_receipt()
    if before!=after or input_sig!=signature(project.to_dict()):
        raise ValueError('Inputs or numerical source changed during calculation; recalculate before using/exporting results')
    out=dict(schema='LRO_TOP_UNSTIFFENED_RESULT_V1',project_signature=input_sig,source_receipt=after,
        verification_lengths=None if project.verification_lengths is None else project.verification_lengths.to_dict(),
        identity=project.identity,project_label=project.label,status=outcome,scopes=scopes,scope_groups=scope_groups,cases=cases,
        assessed_member_scope_status=member_outcome,assessed_member_scopes_satisfied=member_outcome=='SATISFIED',
        full_route_incomplete_reasons=['Additional action/event coverage and rail/contact criteria remain open; assessed member results are reported separately.'],
        generated_case_count=len(cases),physical_endpoint_records=endpoint_count,
        physical_runway_configurations=runway_configuration_count,
        selected_action_method='CMAA74_2020_CHARACTERISTIC_NBR8800_NORMAL_ULS' if cmaa_strength is not None else 'NBR8800_NORMAL_ULS',
        cmaa_strength=cmaa_strength,normal_uls_uses_nbr_hoist_dynamics=cmaa_strength is None,
        physical_domain=domain,hoist_dynamics=dynamics,controls=asdict(controls),fatigue=fatigue,nbr_fatigue=nbr_fatigue,cmaa_fatigue=cmaa_fatigue,selected_fatigue_method='NBR8400_classified_life_nominal' if project.nbr_fatigue is not None else 'EN2025_zero_damage_sufficient' if project.fatigue is not None else None,service=service,
        source_status_ledger={k:asdict(v) for k,v in project.sources.items()},
        actual_failure_proven=any(v['actual_failure_proven'] for v in scopes.values()),
        whole_design_complete=False,whole_member_qualified=False,external_efforts_required=False,physical_stiffeners='absent',
        plate_metadata=dict(pair_count=0,weight_total_kn=0.,stiffness_credited=0.),
        basis_statement=('Adopted hybrid: CMAA74:2020 uncollapsed characteristic origins including an independent SK outer box; supplementary NBR8800 normal ULS with psi=1; CISC ordinary rolled flange analogy; supplementary EN common-family stability. Fatigue and service are separately source-labelled. Not full CMAA conformity.' if cmaa_strength is not None else 'Adopted hybrid: internal physical bridge actions; source NBR8800 normal ULS; CISC ordinary rolled flange analogy; supplementary EN stability/fatigue; explicitly implemented CMAA service only. Not full CMAA conformity.'),
        witness_scope=('No physical failure witnesses or concurrent support reactions generated for CMAA SK box corners. The common-family stability bound is not a physical force state.' if cmaa_strength is not None else 'Selected event/midpoint positions can prove witnessed failure; they do not prove a complete nonlinear interaction maximum.'),
        bound_scope='Analytical sufficient all-position bounds. Exceedance is INCONCLUSIVE, not proof of actual failure.',
        elapsed_seconds=time.monotonic()-start)
    checked_tree(out,'result');out['result_signature']=signature(out)
    return out


def assert_current_result(project,result):
    project.validate();checked_tree(result,'result',allow_exact_rationals=True)
    expected_schema='LRO_TOP_INTERMEDIATE_RESULT_V1' if project.intermediates is not None else 'LRO_TOP_UNSTIFFENED_RESULT_V1'
    if result.get('schema')!=expected_schema or result.get('project_signature')!=signature(project.to_dict()):
        raise ValueError('Result does not belong to current physical inputs; recalculate')
    copy=dict(result);claimed=copy.pop('result_signature',None)
    if claimed!=signature(copy):raise ValueError('Result changed after calculation; recalculate')
    current=source_receipt()
    if result.get('source_receipt')!=current:
        old=result.get('source_receipt',{}).get('files',{});new=current.get('files',{})
        changed=[name for name in old.keys()|new.keys() if old.get(name)!=new.get(name)]
        raise ValueError('Calculation source changed; recalculate before export: '+', '.join(changed))
    return result


def calculation_document(project,result,metadata=None):
    assert_current_result(project,result)
    from .project import INTERMEDIATE_CALCULATION_FORMAT
    return dict(format=INTERMEDIATE_CALCULATION_FORMAT if project.intermediates is not None else CALCULATION_FORMAT,version=1,inputs=project.to_dict(),document_metadata=validate_document_metadata(metadata or {}),results=result)


def analyze_profile_family(project,catalog_ids,*,controls=None,progress=None):
    from .project import replace_catalog_profile
    if not isinstance(catalog_ids,(list,tuple)) or not 1<=len(catalog_ids)<=100 or len(set(catalog_ids))!=len(catalog_ids):
        raise ValueError('Select 1–100 distinct catalog profiles')
    out=[]
    for i,catalog_id in enumerate(catalog_ids,1):
        candidate=replace_catalog_profile(project,catalog_id)
        result=analyze_project(candidate,controls=controls)
        out.append(dict(catalog_id=catalog_id,project=candidate.to_dict(),result=result))
        if progress:progress(i,len(catalog_ids),catalog_id)
    return out
