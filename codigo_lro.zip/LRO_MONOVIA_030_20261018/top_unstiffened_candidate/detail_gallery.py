"""Read-only fatigue-detail reference; deliberately independent of calculations.

The frozen catalog describes examples, not selectable calculation capabilities.
No project, session state, numerical module, or classification is changed here.
"""
from hashlib import sha256
import json
from pathlib import Path


ASSET_DIRECTORY = Path(__file__).resolve().parent / 'assets' / 'fatigue_details'
MANIFEST_SHA256 = '73e1f97aabccc3d2e2f6e63a42dcc8ee65b1d320a86eb0606460cb44e7ebc81e'


def _load_catalog():
    """Accept only the reviewed reference; do not silently display altered data."""
    content = (ASSET_DIRECTORY / 'catalog_manifest.json').read_bytes()
    if sha256(content).hexdigest() != MANIFEST_SHA256:
        raise ValueError('Reference catalog integrity check failed')
    return json.loads(content)


def _read_image(item):
    asset = item['assets']['png']
    content = (ASSET_DIRECTORY / asset['file']).read_bytes()
    if len(content) != asset['bytes'] or sha256(content).hexdigest() != asset['sha256']:
        raise ValueError('Reference image integrity check failed')
    return content


def _source_caption(item):
    source = item['source']
    return (
        f"Fonte: CMAA 74:2020, Tabela {source['table']}, "
        f"p. {source['table_printed_page']}; Figura {source['figure']}, "
        f"p. {source['figure_printed_page']}, exemplo {source['figure_example']}. "
        'Páginas impressas da norma.'
    )


def render_detail_gallery(st):
    """Render consultation only; return no input or calculation declaration.

Missing or changed bundled assets only suppress the affected reference content.
They must not prevent the surrounding application from running calculations.
"""
    with st.expander('Entenda as categorias de detalhe A–F (CMAA 74:2020)', expanded=False):
        st.info(
            'Apenas consulta: estes exemplos ajudam a reconhecer detalhes de fadiga. '
            'A galeria não seleciona categorias, não altera os dados ou resultados '
            'do projeto e não habilita detalhes fora do escopo do cálculo.'
        )
        st.markdown(
            'As categorias de detalhe A–F não são as classes de serviço A–D. '
            'A categoria depende da região avaliada, da geometria, da ligação e '
            'da direção da tensão, não de uma letra única para toda a viga. '
            'Os exemplos A–E abaixo tratam de tensão normal; o exemplo F trata '
            'de cisalhamento na garganta efetiva de solda de filete, não de '
            'tensão normal no material-base.'
        )
        try:
            catalog = _load_catalog()
        except (OSError, ValueError):
            st.warning(
                'A galeria de consulta está indisponível: o arquivo de referência '
                'está ausente ou inválido. Isso não altera nem impede o cálculo. '
                'Confira os arquivos da instalação para restaurar a galeria.'
            )
            return

        st.caption(catalog['global_warning'])
        for item in catalog['items']:
            category, description, illustration = st.columns([0.45, 2.7, 3.3])
            with category:
                st.markdown(f"### {item['category']}")
            with description:
                st.markdown(f"**{item['title']}**")
                st.markdown(item['subtitle'])
                st.markdown('\n'.join(f'- {condition}' for condition in item['conditions']))
                st.caption(_source_caption(item))
            with illustration:
                try:
                    content = _read_image(item)
                except (OSError, ValueError):
                    st.warning(
                        f"Ilustração da categoria {item['category']} indisponível ou inválida. "
                        'O texto de referência continua disponível. Isso não altera '
                        'nem impede o cálculo.'
                    )
                else:
                    st.image(content, caption=item['short_caption'], use_container_width=True)
            st.markdown('---')

        st.caption(
            'Leitura das imagens: ' + ' '.join(catalog['legend'].values())
        )
        st.caption(catalog['items'][0]['scope_warning'])
