"""Supplementary C.2 sufficient bounds for the declared rolled flange analogy.

These are all-position equivalent resistance demands, never fictitious physical
reactions or simultaneous force vectors. The CISC nominal response is not called
an exact full-Vlasov response. Local web, fatigue, service and connections are
separate. Unmet sufficient bounds are inconclusive, not witnessed failure.
"""
from dataclasses import dataclass, asdict
from hashlib import sha256
from pathlib import Path
import math
from .mechanics import PreparedCase,prepare_case,TopIntermediateBasis
from .stiffeners.loads import stationary_destabilizing_radius_nmm
from lro_beams.beam_torsion import VlasovBeam, thin_wall_i_torsion_properties
from lro_beams.beam_end_projection import projection_flexure_reference_bound
from lro_beams.runway_stability_en2025 import _chi_adopted
from .reference_bound import critical_reference
from .verification_lengths import verification_lengths_metadata

SOURCE = ('DIN EN1993-1-1:2025 7.2.2,8.3.3,Tables7.3/7.4,AnnexC.2; '
          'CISC2005 ordinary rolled flange analogy; independently derived destabilizing-load-radius reference')

@dataclass(frozen=True)
class StabilityPremises:
    method_adoption_source: str
    resistance_gamma: float
    material_environment: str = 'unspecified'
    material_environment_source: str = ''

    def validate(self):
        from underslung_runway_candidate.autonomous_workflow.model import checked_text
        checked_text(self.method_adoption_source, 'C.2 method adoption source')
        checked_text(self.material_environment_source, 'material/environment source')
        if self.material_environment != 'structural_steel_ambient_temperature':
            raise ValueError('Explicit ambient structural-steel project premise required')
        g=self.resistance_gamma
        if type(g) not in (int,float) or not math.isfinite(g) or not 1<=g<=10:
            raise ValueError('Explicit finite resistance margin >=1 required')
        return self


def _signature(value):
    from underslung_runway_candidate.autonomous_workflow.model import signature
    return signature(value)


def _source():
    from . import mechanics,bounds,verification_lengths
    import lro_beams.beam_end_projection as tails
    import lro_beams.runway_stability_en2025 as c2
    import lro_beams.beam_torsion as torsion
    from . import reference_bound as reference
    from .stiffeners import loads
    files=(__file__,mechanics.__file__,bounds.__file__,tails.__file__,c2.__file__,torsion.__file__,reference.__file__,verification_lengths.__file__,loads.__file__)
    return {str(Path(p).name):sha256(Path(p).read_bytes()).hexdigest() for p in files}


def _row(identifier,demand,capacity,source=SOURCE):
    ratio=demand/capacity
    return dict(id=identifier,demand=demand,capacity=capacity,utilization=ratio,
                status='SUFFICIENT_BOUND_SATISFIED' if demand<=capacity+1e-12*max(1.,capacity) else 'INCONCLUSIVE_SUFFICIENT_BOUND',
                actual_failure_proven=False,sufficient_bound=True,source=source)


def evaluate_prepared_case(c,*,premises,verification_lengths=None):
    """Strict public single-case producer; no external envelope arguments."""
    return _evaluate_with_bounds(c,premises=premises,verification_lengths=verification_lengths)


def _evaluate_with_bounds(c,*,premises,_family_components=None,verification_lengths=None):
    """Internal analytical producer, all translations and material stations.

    Initial domain retains the conservative uniform-compression class gate.
    A source-qualified actual-gradient gate can be added separately. No user
    declaration substitutes for bounds, instability criteria or action identity.
    The private family branch is called only by the regenerated CMAA producer.
    Its common component/radius/tail envelope is not a fabricated PreparedCase.
    """
    out=dict(kind='top_unstiffened_supplementary_C2_all_position_bound',source=SOURCE,
        status='PENDING',checks=[],pending=[],member_stability_qualified=False,
        whole_member_qualified=False,actual_failure_proven=False,
        equivalent_demands_are_physical_reactions=False,duplicate_vlasov_stress=False,
        local_sigmaT_calculated=False)
    before=_source()
    try:
        from .bounds import prepared_absolute_bounds
        if not isinstance(c,PreparedCase):raise ValueError('Internally prepared top mechanical case required')
        if not isinstance(premises,StabilityPremises):raise ValueError('Typed stability premises required')
        premises.validate()
        # Revalidate the physical domain and bind the private prepared project.
        c.basis.validated_project()
        c.validate_stationary_identity()
        rebuilt=prepare_case(c.basis,c.factors,c.transverse_sign,c.longitudinal_sign)
        if c != rebuilt:raise ValueError('Prepared mechanics changed after physical generation; regenerate the whole case')
        p,s,m,g=c.project,c.project.section,c.project.material,c.properties
        lengths=verification_lengths_metadata(verification_lengths,p.span_m*1000)
        physical_identity=dict(physical_basis=c.basis.provenance()) if isinstance(c.basis,TopIntermediateBasis) else {}
        key=_signature(dict(project=p.to_dict(),factors=asdict(c.factors),signs=(c.transverse_sign,c.longitudinal_sign),premises=asdict(premises),verification_lengths=lengths,**physical_identity))
        out['verification_lengths']=lengths
        b=prepared_absolute_bounds(c);L=p.span_m*1000;E=m.E_mpa;fy=m.fy_mpa;gamma=premises.resistance_gamma
        family_signature=None
        if _family_components is not None:
            family_signature=_signature(_family_components)
            if _family_components.get('producer')!='regenerated_top_CMAA_origin_family_v1':
                raise ValueError('Internal regenerated CMAA family producer required')
            b=_family_components['bounds']
            if b['major']['moment_abs_knm']<=0:
                raise ValueError('Positive family major-moment bound required; zero-moment radius modes are not bypassed')
            out.update(kind='top_unstiffened_supplementary_C2_continuous_family_bound',
                uniform_component_envelope=True,nonlinear_vertex_maximum_claimed=False,
                family_envelope_receipt=_family_components['receipt'],
                family_component_inputs=dict(
                    destabilizing_radius_sum_Nmm=_family_components['destabilizing_radius_sum_Nmm'],
                    permanent_vertical_udl_kn_per_m=_family_components['permanent_vertical_udl_kn_per_m']))
        if not 200<=fy<=700:out['pending'].append('Steel fy outside supplementary 200–700 MPa domain.')
        t=thin_wall_i_torsion_properties(s.d_mm,s.bf_mm,s.tf_mm,s.tw_mm)
        A,Imajor,Iweak=g.A_mm2,g.Ix_mm4,g.Iy_mm4
        If=c.flange_I_mm4;Cw=t['Cw_mm6'];h=c.h_mm;omega=s.bf_mm*h/4
        if not math.isclose(Cw,If*h*h/2,rel_tol=1e-12):raise ValueError('Thin-wall stress mapping inconsistency')
        N=b['N_abs_kn']*1000;Ncomp=b['N_compression_abs_kn']*1000
        M=b['major']['moment_abs_knm']*1e6
        minor=b['equivalent_minor_M_abs_knm']*1e6*Iweak/(2*If)
        B=b['equivalent_B_abs_nmm2']
        # Physical F=(Fx,H,-P), r=(0,ey,zrail). D=-F_transverse dot r.
        # Unknown translation permits max x(L-x)/L=L/4. Favourable signs ignored.
        radius=sum(max(0.,w.vertical_kn*1000*c.rail_z_mm-w.horizontal_kn*1000*c.ey_mm) for w in c.source_wheels)
        # Permanent rail density at its actual height. Other declared dead UDL
        # is centered; using the outer rail height for rail mass is adverse.
        rail_q=p.rail.mass_kg_per_m*9.80665/1000*c.factors.dead_support
        radius += max(0.,rail_q*c.rail_z_mm)*L
        stationary_radius=stationary_destabilizing_radius_nmm(c.stationary_bodies,c.factors.dead_support)
        radius += stationary_radius
        if isinstance(c.basis,TopIntermediateBasis):
            out.update(kind=('top_intermediate_nominal_supplementary_C2_continuous_family_bound' if _family_components is not None
                else 'top_intermediate_nominal_supplementary_C2_all_position_bound'),
                physical_stiffeners='present',stationary_destabilizing_radius_sum_Nmm=stationary_radius,
                physical_basis=c.basis.provenance(),EI_J_Cw_Mcr_credit=False,
                station_qualified=False,local_detail_qualified=False,design_complete=False)
        projection_udl=c.udl.vertical_kn_per_m
        if _family_components is not None:
            radius=_family_components['destabilizing_radius_sum_Nmm']
            projection_udl=_family_components['permanent_vertical_udl_kn_per_m']
            if any(type(v) not in (int,float) or not math.isfinite(v) or v<0 for v in (radius,projection_udl)):
                raise ValueError('Finite nonnegative family radius/permanent-UDL envelope required')
        reference=critical_reference(length_mm=L,EIweak_Nmm2=E*Iweak,ECw_Nmm4=E*Cw,
            moment_abs_bound_Nmm=max(M,1e-30),point_radius_actions=(),unlocated_radius_sum_Nmm=radius)
        lam=reference['critical_multiplier_lower']
        tail_rows=[]
        beam=VlasovBeam(L,E,m.G_mpa,t['J_mm4'],Cw)
        for length in (p.beam_end_left_mm,p.beam_end_right_mm):
            if length:
                if p.rail.offset_from_web_mm!=0:
                    out['pending'].append('Eccentric permanent rail torque on physical projection needs a separate tail stability reference.')
                    continue
                # No wheels/H/axial or external torque on the physical tail.
                # Its whole UDL placed at rail height is an adverse reference.
                tail=projection_flexure_reference_bound(beam,Iweak,length,projection_udl,max(0.,c.rail_z_mm))
                tail_rows.append(tail)
                if tail['load_factor_lower_bound'] is not None:lam=min(lam,tail['load_factor_lower_bound'])
        Mcr=lam*M if M>0 else math.pi**2*math.sqrt(E*Iweak)*math.sqrt(E*Cw)/L**2
        # Strength effective lengths are independent of the mechanical model.
        # The first-order validity gate ALWAYS retains the original fullspan.
        Ny_gate=math.pi**2*E*Imajor/L**2;Nz_gate=math.pi**2*E*Iweak/L**2
        if verification_lengths is None:
            Ny=Ny_gate;Nz=Nz_gate
            NT=(m.G_mpa*t['J_mm4']+E*Cw*math.pi**2/L**2)/((Imajor+Iweak)/A)
        else:
            use=lengths['strength_lengths_mm']
            Ny=math.pi**2*E*Imajor/use['major_flexural_mm']**2
            Nz=math.pi**2*E*Iweak/use['minor_flexural_mm']**2
            NT=(m.G_mpa*t['J_mm4']+E*Cw*math.pi**2/use['torsional_mm']**2)/((Imajor+Iweak)/A)
        gate=min(Ny_gate,Nz_gate)/25
        if Ncomp>gate:out['pending'].append('Ncr/25 sufficient first-order axial gate not satisfied; second-order assessment required.')
        eps=math.sqrt(235/fy)
        # Table7.3 uses the documented flat web between root toes. The basis
        # validates catalog d-prime; root_radius_mm here reconstructs that
        # vertical dimension only, not a physical circular fillet. Its unknown
        # horizontal extent is NOT deducted from the flange outstand.
        flat_web_depth=s.d_mm-2*s.tf_mm-2*s.root_radius_mm
        flange_ratio=(s.bf_mm-s.tw_mm)/(2*s.tf_mm);web_ratio=flat_web_depth/s.tw_mm
        if flange_ratio>14*eps:out['pending'].append('Uniform-compression class1–3 flange sufficient gate not satisfied.')
        web_limit=(121. if Ncomp==0 else 38.)*eps
        web_class_basis='no_compressive_axial_force_pure_bending_or_tension_web' if Ncomp==0 else 'uniform_compression_sufficient_gate'
        if web_ratio>web_limit:out['pending'].append('Class1–3 web sufficient gate not satisfied; a refined concurrent-gradient classification is separate.')
        NR=A*fy;MR=2*Imajor/s.d_mm*fy;MRminor=2*Iweak/s.bf_mm*fy;BR=Cw*fy/omega
        if B/BR>.3:out['pending'].append('Equivalent B/BRk exceeds the C.2 <=0.30 applicability domain.')
        chiN=_chi_adopted(math.sqrt(NR/Ny),True)
        chiMinor=_chi_adopted(math.sqrt(NR/Nz),True)
        chiTorsion=_chi_adopted(math.sqrt(NR/NT),True)
        chiWeak=min(chiMinor,chiTorsion)
        chiLT=_chi_adopted(math.sqrt(MR/Mcr),True)
        ny=Ncomp*gamma/(chiN*NR);nz=Ncomp*gamma/(chiWeak*NR)
        my=M*gamma/(chiLT*MR);mz=minor*gamma/MRminor;tor=1.4*B*gamma/BR
        kyy=1+.8*ny;kzz=1+1.4*nz;kzy=max(1.,.8*kyy)
        u1=ny+kyy*my+kzz*mz+tor;u2=nz+kzy*my+kzz*mz+tor
        out.update(bounds=b,reference=reference,tail_references=tail_rows,
            equivalent_demands=dict(N_abs_N=N,N_compression_bound_N=Ncomp,major_M_Nmm=M,
                minor_M_equivalent_Nmm=minor,B_equivalent_Nmm2=B,
                mapping='Mminor resistance equivalent = |Mtop+Mbottom| Iweak/(2If); |B|=(h/2)|Mtop−Mbottom|, signed correlated top+bottom and top−bottom forces combined before analytical bounds; no second B stress added'),
            intermediates=dict(Mcr_lower_Nmm=Mcr,chi_major=chiN,chi_minor_torsion=chiWeak,chi_LT=chiLT,
                Ncr_major_N=Ny,Ncr_minor_N=Nz,Ncr_torsion_N=NT,
                Ncr_gate_major_fullspan_N=Ny_gate,Ncr_gate_minor_fullspan_N=Nz_gate,
                first_order_gate_limit_N=gate,first_order_gate_satisfied=Ncomp<=gate,
                chi_minor_flexural=chiMinor,chi_torsion=chiTorsion,
                ny=ny,nz=nz,my=my,mz=mz,tor=tor,kyy=kyy,kzz=kzz,kzy=kzy,
                NRk_N=NR,MRk_Nmm=MR,MRminor_Rk_Nmm=MRminor,
                BRk_Nmm2=BR,B_ratio=B/BR,flange_ratio=flange_ratio,web_ratio=web_ratio,flange_limit=14*eps,web_limit=web_limit,web_classification_basis=web_class_basis,
                flat_web_depth_mm=flat_web_depth,flat_web_geometry_source=c.basis.root_geometry_source,
                flange_root_extent_deducted=False,root_radius_is_physical_circle=False,
                C1_bound=u1,C2_bound=u2),action_case=c.factors.name,action_source=c.factors.source)
        if not out['pending']:
            out['checks']=[_row('supplementary_C1',u1,1.),_row('supplementary_C2',u2,1.)]
            ok=all(r['status']=='SUFFICIENT_BOUND_SATISFIED' for r in out['checks'])
            out.update(status='SUFFICIENT_STABILITY_BOUND_SATISFIED' if ok else 'INCONCLUSIVE_SUFFICIENT_BOUND',member_stability_qualified=ok)
        if before!=_source():raise ValueError('Stability numerical source changed during calculation')
        if _family_components is not None and family_signature!=_signature(_family_components):
            raise ValueError('CMAA family envelope changed during stability consumption')
        if key!=_signature(dict(project=p.to_dict(),factors=asdict(c.factors),signs=(c.transverse_sign,c.longitudinal_sign),premises=asdict(premises),verification_lengths=verification_lengths_metadata(verification_lengths,p.span_m*1000),**(dict(physical_basis=c.basis.provenance()) if isinstance(c.basis,TopIntermediateBasis) else {}))):raise ValueError('Prepared inputs or verification lengths changed during calculation')
        out['receipt']=dict(input_signature=key,source_hashes=before,analytical_all_position_bound=True,
            verification_lengths=lengths,
            analysis_gate=dict(Ncr_major_fullspan_N=Ny_gate,Ncr_minor_fullspan_N=Nz_gate,
                Ncomp_N=Ncomp,limit_N=gate,satisfied=Ncomp<=gate),
            strength_critical_loads=dict(Ncr_major_N=Ny,Ncr_minor_N=Nz,Ncr_torsion_N=NT),
            no_artificial_governor=True,nominal_analysis_basis=c.basis.nominal_basis)
        if family_signature is not None:
            out['receipt'].update(family_component_signature=family_signature,
                family_input_signature=_family_components['receipt']['input_signature'],
                component_envelope_is_not_a_physical_force_state=True,
                continuous_family_monotonicity='q(t)=1/chi is nondecreasing and q(t)/t^2 nonincreasing; mu=max(mu_span,mu_tails) increases with M while mu/M decreases; hence M*q(sqrt(MR*mu/M)) and complete C.2 interactions increase with component bounds')
    except (ValueError,TypeError,KeyError,AttributeError,ArithmeticError) as exc:
        out.update(status='PENDING',checks=[],member_stability_qualified=False)
        out['pending'].append(type(exc).__name__+': '+str(exc))
    return out
