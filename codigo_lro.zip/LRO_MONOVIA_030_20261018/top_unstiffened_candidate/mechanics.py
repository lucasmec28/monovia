"""Signed classical two-flange flexure analogy, NOT a local stress tensor.

CISC MacCrimmon 2005 §5.11/Fig.6 and ASI Gorenc 2003 §6.2. This is an
explicitly adopted supplementary nominal analysis basis, not automatic NBR
qualification. Runtime lro_beams is read-only. All beam solves reuse its
analytical moving_beam solver. No FE engine or Vlasov stress is introduced.

Axes: x along beam, y lateral, z upward. P and vertical deflection are downward
positive. theta=(u_top-u_bottom)/h is MINUS physical rotation about +x.
Flange force split: Ft=(P*ey+H*(zrail-zbottom))/h; Fb=H-Ft.
HL: global N from Fx, global major couple Fx*zrail, and minor couple -Fx*ey
on TOP FLANGE ONLY. Sectorial coordinate is y*z_flange_centroid, never y*zrail.

Domain: prismatic doubly symmetric rolled I, known/adopted root-toe geometry,
ordinary unmodified member under TopUnstiffenedBasis (physical stiffeners absent),
or explicit TopIntermediateBasis with adopted AISE stabilizer detail and its real
stationary G inventory, without rigidity or local qualification credit. Real end
forks free to warp, left axial anchor at section axis, no intermediate braces. No
wheel travels on an end projection. Unloaded projections carry permanent UDL
and are recovered analytically with actual support slopes and free ends.
"""
from __future__ import annotations
from dataclasses import dataclass, field, asdict
from copy import deepcopy
from math import isfinite, isclose, ceil, nextafter
from typing import Literal
from hashlib import sha256
from pathlib import Path
from .stiffeners.loads import (
    StationaryBody, StationaryLedger, COORDINATE_BASIS, GRAVITY_M_S2,
    validate_stationary_ledger, stationary_ledger_hash, stationary_point_loads,
    body_vertical_kn, stationary_destabilizing_radius_nmm,
)
from lro_beams.autonomous_model import AutonomousProject
from lro_beams.autonomous_response import CaseFactors, case_loads, projection_equivalent_loads
from lro_beams.autonomous_actions import ActionFactors
from lro_beams.moving_beam import (
    BeamModel, PointLoad, MovingWheel, UniformLoad, PlaneSolution,
    solve_position as solve_beam, translate_train, _roots_in_unit_interval,
)
from .nominal_forces import wheel_flange_forces

BASIS_ID = 'cisc2005_ordinary_rolled_flexure_analogy_supplement_to_brazilian_checks'
INTERMEDIATE_BASIS_ID = 'aise2002_intermediate_top_cjp_gap_with_cisc2005_nominal_flange_analogy'
INTERMEDIATE_DETAIL_BASIS = 'fisher_van_de_pas2002_intermediate_top_cjp_continuous_web_weld_lower_gap'
SCOPE = (
    'Nominal longitudinal stress and two-flange Euler-Bernoulli response only.',
    'Not a computed NBR10084 local transverse sigmaT tensor or 3-D fillet stress.',
    'No Saint-Venant relief; no additional Vlasov B stress from the same torque.',
    'Resistance, stability, fatigue categories/cycles, local contact and connection design require separate checks.',
    'Physical projection response does not qualify projection stability; a two-fork span reference cannot certify the free tails.',
    'Numerical roundoff is not interval-certified.',
)


def _number(value, name, *, positive=False, nonnegative=False):
    try:
        finite = not isinstance(value, bool) and isinstance(value, (int, float)) and isfinite(value)
    except (OverflowError, ValueError, TypeError):
        finite = False
    if not finite:
        raise ValueError(name + ' must be finite numeric data')
    if positive and value <= 0 or nonnegative and value < 0:
        raise ValueError(name + ' outside allowed physical range')
    return value


@dataclass(frozen=True)
class TopUnstiffenedBasis:
    """Explicit physical/model specification, NEVER a computed qualification flag.

    `project` is copied when preparing a case; the caller's editable project is
    never mutated. `reference` inputs may be calculated for comparison but do
    not become an adopted or confirmed physical design.
    root_geometry_basis='catalog_root_toe_depth' allows verified clear d′; the
    Section radius is then only (d-2tf-d′)/2, NOT a circular physical fillet.
    """
    project: AutonomousProject
    physical_stiffeners: str = 'unknown'
    nominal_basis: str = ''
    premise_status: str = 'reference'
    premise_source: str = ''
    ordinary_member_geometry: str = 'unknown'
    root_geometry_basis: str = 'unknown'
    root_geometry_source: str = ''
    end_fork_basis: str = 'unknown'
    end_fork_source: str = ''

    def validated_project(self):
        if not isinstance(self.project, AutonomousProject):
            raise ValueError('AutonomousProject required')
        if self.physical_stiffeners != 'absent':
            raise ValueError('Physical stiffeners must be explicitly absent; unknown is not absence')
        if self.nominal_basis != BASIS_ID:
            raise ValueError('Explicit ordinary rolled nominal analysis basis required; no automatic migration')
        return _validated_project_common(self,
            ordinary_geometry='plain_prismatic_no_modifications',
            ordinary_error='Ordinary plain prismatic rolled section required; holes, copes, welded caps/attachments need another scope',
            layout_error='Paired stiffener project contradicts explicit absent physical state')

    def provenance(self):
        return {name: getattr(self, name) for name in (
            'physical_stiffeners', 'nominal_basis', 'premise_status', 'premise_source',
            'ordinary_member_geometry', 'root_geometry_basis', 'root_geometry_source',
            'end_fork_basis', 'end_fork_source')}



def _validated_project_common(basis, *, ordinary_geometry, ordinary_error, layout_error):
    """Shared base-section/fork validation; never fabricates an absent basis.

    Legacy pair fields are an inactive input-codec concern only. They never
    constitute the physical inventory of either explicitly distinct basis.
    """
    if basis.premise_status not in ('reference', 'adopted', 'confirmed') or not basis.premise_source.strip():
        raise ValueError('Sourced reference/adopted/confirmed premise status required')
    if basis.ordinary_member_geometry != ordinary_geometry:
        raise ValueError(ordinary_error)
    if basis.root_geometry_basis not in ('catalog_root_toe_depth', 'documented_circular_root') or not basis.root_geometry_source.strip():
        raise ValueError('Documented root-toe depth or actual circular root geometry required')
    if basis.end_fork_basis not in ('adopted_true_forks_free_warping', 'confirmed_true_forks_free_warping') or not basis.end_fork_source.strip():
        raise ValueError('Explicit physical/design end-fork premise required, distinct from stiffener plates')
    p = deepcopy(basis.project)
    if p.stiffener_layout not in ('none_or_unknown', 'absent'):
        raise ValueError(layout_error)
    s = p.section
    if s.fabrication != 'rolled' or not s.doubly_symmetric:
        raise ValueError('Only doubly symmetric rolled I sections are in this nominal domain')
    _number(s.root_radius_mm, 'root geometry', positive=True)
    if basis.root_geometry_basis == 'documented_circular_root' and 'r equivalente=' in s.property_source:
        raise ValueError('Equivalent catalog root radius cannot be called a documented circular fillet')
    if any((p.upper_braces_m, p.lower_braces_m, p.lateral_only_braces_m)):
        raise ValueError('Intermediate braces unsupported; simple true end forks only')
    if p.support_model != 'simple_forks_free_warping' or p.axial_support != 'left_fixed_right_sliding':
        raise ValueError('True simple end forks/free warping and left axial anchor required')
    if p.wheel_travel_scope != 'between_support_axes':
        raise ValueError('Wheels on physical projections unsupported')
    if p.support_contact != 'centered_under_web':
        raise ValueError('Support contact must be centered under web')
    if p.rail.continuity != 'continuous_no_joint' or p.rail.local_attachment != 'non_rigid':
        raise ValueError('Ordinary continuous rail/non-rigid local attachment scope required')
    # Legacy validation still expects positive pair dimensions even when no
    # pairs exist. Canonicalize only INACTIVE fields on this private adapter
    # copy. These are not physical plates and enter no load/stiffness formula.
    p.stiffener_layout = 'none_or_unknown'
    p.stiffener_spacing_m = 1.0
    p.stiffener_thickness_mm = 1.0
    p.stiffener_outstand_mm = 0.0
    p.stiffener_connection = 'other_or_unknown'
    p.stiffener_flange_weld_min_leg_mm = 0.0
    p.stiffener_web_weld_min_leg_mm = 0.0
    p.flange_web_weld_min_leg_mm = 0.0
    return p


@dataclass(frozen=True)
class TopIntermediateBasis:
    """Published AISE detail + CISC nominal mechanics, not local qualification.

    The physical inventory is separate from inactive AutonomousProject pair
    fields. EI, J, Cw and resistance geometry remain exactly the base section.
    Geometry/CJP/toe/panel/sign/fatigue qualification is deliberately NOT granted
    by this mass adapter or by a supplied geometry digest.
    """
    project: AutonomousProject
    physical_stiffeners: str = 'present'
    nominal_basis: str = ''
    premise_status: str = 'reference'
    premise_source: str = ''
    ordinary_member_geometry: str = 'unknown'
    root_geometry_basis: str = 'unknown'
    root_geometry_source: str = ''
    end_fork_basis: str = 'unknown'
    end_fork_source: str = ''
    detail_basis: str = ''
    geometry_inputs_hash: str = ''
    geometry_source: str = ''
    stationary_bodies: StationaryLedger = ()
    stationary_ledger_sha256: str = ''

    def __post_init__(self):
        validate_stationary_ledger(self.stationary_bodies)
        if not self.stationary_ledger_sha256:
            object.__setattr__(self,'stationary_ledger_sha256',stationary_ledger_hash(self.stationary_bodies))

    def validated_project(self):
        if not isinstance(self.project,AutonomousProject):
            raise ValueError('AutonomousProject required')
        if self.physical_stiffeners!='present':
            raise ValueError('Intermediate physical stiffeners must remain explicitly present')
        if self.nominal_basis!=INTERMEDIATE_BASIS_ID or self.detail_basis!=INTERMEDIATE_DETAIL_BASIS:
            raise ValueError('Explicit adopted AISE intermediate detail plus CISC nominal basis required')
        if (not isinstance(self.geometry_inputs_hash,str) or len(self.geometry_inputs_hash)!=64 or
                any(c not in '0123456789abcdef' for c in self.geometry_inputs_hash)):
            raise ValueError('Canonical SHA256 of physical geometry inputs required')
        if not isinstance(self.geometry_source,str) or not self.geometry_source.strip():
            raise ValueError('Physical geometry source required')
        if not self.stationary_bodies:
            raise ValueError('Present intermediate basis requires a nonempty physical body inventory')
        validate_stationary_ledger(self.stationary_bodies,span_mm=self.project.span_m*1000)
        if stationary_ledger_hash(self.stationary_bodies)!=self.stationary_ledger_sha256:
            raise ValueError('Stationary body/source ledger changed; regenerate physical geometry and basis')
        return _validated_project_common(self,
            ordinary_geometry='plain_prismatic_with_intermediate_stabilizers',
            ordinary_error='Only base prismatic rolled geometry with the explicitly adopted intermediate stabilizer detail is supported',
            layout_error='Legacy AutonomousProject pair inventory must be inactive; use the separate physical intermediate ledger')

    def provenance(self):
        result={name:getattr(self,name) for name in (
            'physical_stiffeners','nominal_basis','premise_status','premise_source',
            'ordinary_member_geometry','root_geometry_basis','root_geometry_source',
            'end_fork_basis','end_fork_source','detail_basis','geometry_inputs_hash',
            'geometry_source','stationary_ledger_sha256')}
        from .stiffeners import loads
        result.update(stationary_bodies=tuple(asdict(body) for body in self.stationary_bodies),
            stationary_loads_source_sha256=sha256(Path(loads.__file__).read_bytes()).hexdigest(),
            coordinate_basis=COORDINATE_BASIS,physical_inventory_separate_from_legacy_fields=True,
            EI_J_Cw_Mcr_credit=False,local_detail_qualified=False,station_qualified=False,
            design_complete=False)
        return result

def action_case_factors(action, *, wheel_vertical_override_kn=None):
    """Adapter preserves every explicitly supplied source-backed action factor."""
    if isinstance(action, CaseFactors):
        if wheel_vertical_override_kn is not None:
            raise ValueError('CaseFactors already owns its wheel override; do not supply another')
        return action
    if not isinstance(action, ActionFactors):
        raise ValueError('ActionFactors or CaseFactors required')
    if action.wind or action.thermal or action.event_action:
        raise ValueError('Wind/thermal/event vectors are not synthesized by this wheel-only adapter')
    return CaseFactors(action.code, action.dead_support, action.dead_equipment,
                       action.lifted, action.transverse, action.longitudinal,
                       action.source, action.extra_dead, wheel_vertical_override_kn)


def _projection_fixed(p, q, *, horizontal=False):
    rows = []
    for a, x, sign in ((p.beam_end_left_mm/1000, 0., -1.),
                       (p.beam_end_right_mm/1000, p.span_m, 1.)):
        if a and q:
            rows.append(PointLoad(x, 0. if horizontal else q*a,
                q*a if horizontal else 0., 'Permanent unloaded projection',
                major_moment_knm=0. if horizontal else sign*q*a*a/2,
                minor_moment_knm=sign*q*a*a/2 if horizontal else 0.))
    return tuple(rows)


@dataclass(frozen=True)
class PreparedCase:
    basis: TopUnstiffenedBasis | TopIntermediateBasis
    project: AutonomousProject
    factors: CaseFactors
    properties: object
    udl: UniformLoad
    source_wheels: tuple
    top_wheels: tuple
    bottom_wheels: tuple
    beam: BeamModel
    flange_beam: BeamModel
    top_udl: UniformLoad
    bottom_udl: UniformLoad
    transverse_sign: int
    longitudinal_sign: int
    force_split: tuple
    major_fixed: tuple
    top_fixed: tuple
    bottom_fixed: tuple
    stationary_bodies: StationaryLedger = ()
    stationary_ledger_sha256: str = ''
    geometry_inputs_hash: str = ''

    @property
    def h_mm(self): return self.project.section.d_mm-self.project.section.tf_mm
    @property
    def flange_I_mm4(self):
        s=self.project.section
        return s.tf_mm*s.bf_mm**3/12
    @property
    def rail_z_mm(self): return self.project.section.d_mm/2+self.project.rail.height_mm
    @property
    def ey_mm(self): return self.project.rail.offset_from_web_mm+self.project.rail.lateral_eccentricity_mm
    @property
    def translation_range_m(self):
        return (-max(w.offset_m for w in self.source_wheels), self.project.span_m-min(w.offset_m for w in self.source_wheels))
    @property
    def plate_metadata(self):
        if isinstance(self.basis,TopIntermediateBasis):
            return dict(physical_state='present',body_count=len(self.stationary_bodies),
                body_ids=tuple(body.id for body in self.stationary_bodies),
                positions_m=tuple(body.x_mm/1000 for body in self.stationary_bodies),
                mass_total_kg=sum(body.mass_kg for body in self.stationary_bodies),
                weight_total_kn=sum(body_vertical_kn(body,1.) for body in self.stationary_bodies),
                factored_weight_total_kn=sum(body_vertical_kn(body,self.factors.dead_support) for body in self.stationary_bodies),
                structural_G_factor=self.factors.dead_support,stiffness_credited=0.,
                coordinate_basis=COORDINATE_BASIS,stationary_ledger_sha256=self.stationary_ledger_sha256,
                geometry_inputs_hash=self.geometry_inputs_hash,physical_bodies=tuple(asdict(body) for body in self.stationary_bodies),
                inactive_pair_dimensions_used=False,station_qualified=False,design_complete=False)
        return dict(physical_state='absent', pair_count=0, positions_m=(),
                    volume_total_m3=0., weight_total_kn=0., stiffness_credited=0.,
                    inactive_pair_dimensions_used=False)
    def translation_events(self, *, section_positions_m=()):
        lo,hi=self.translation_range_m
        stations=(0.,self.project.span_m,*section_positions_m,*(w.position_m for rows in (self.major_fixed,self.top_fixed,self.bottom_fixed) for w in rows))
        for x in stations:
            _number(x,'section event coordinate')
            if not 0<=x<=self.project.span_m: raise ValueError('Wheel events restricted to support span')
        return tuple(sorted({lo,hi,*(x-w.offset_m for x in stations for w in self.source_wheels if lo<=x-w.offset_m<=hi)}))
    def validate_stationary_identity(self):
        if isinstance(self.basis,TopIntermediateBasis):
            self.basis.validated_project()
            if (self.stationary_bodies!=self.basis.stationary_bodies or
                    self.stationary_ledger_sha256!=self.basis.stationary_ledger_sha256 or
                    self.geometry_inputs_hash!=self.basis.geometry_inputs_hash):
                raise ValueError('Prepared stationary body/geometry identity changed; regenerate the whole case')
            fixed=stationary_point_loads(self.stationary_bodies,span_mm=self.project.span_m*1000,
                h_mm=self.h_mm,dead_support=self.factors.dead_support)
            expected=(projection_equivalent_loads(self.project,self.udl)+fixed[0],
                _projection_fixed(self.project,self.top_udl.horizontal_kn_per_m,horizontal=True)+fixed[1],
                _projection_fixed(self.project,self.bottom_udl.horizontal_kn_per_m,horizontal=True)+fixed[2])
            if (self.major_fixed,self.top_fixed,self.bottom_fixed)!=expected:
                raise ValueError('Prepared stationary physical loads changed; regenerate the whole case')
        elif self.stationary_bodies or self.stationary_ledger_sha256 or self.geometry_inputs_hash:
            raise ValueError('Absent basis cannot carry a physical stationary stiffener inventory')

    def solve_position(self, translation_m):
        self.validate_stationary_identity()
        _number(translation_m,'translation')
        major=solve_beam(self.beam,translate_train(self.beam,self.source_wheels,translation_m),self.udl,fixed_loads=self.major_fixed)
        top=solve_beam(self.flange_beam,translate_train(self.flange_beam,self.top_wheels,translation_m),self.top_udl,fixed_loads=self.top_fixed)
        bottom=solve_beam(self.flange_beam,translate_train(self.flange_beam,self.bottom_wheels,translation_m),self.bottom_udl,fixed_loads=self.bottom_fixed)
        return ConcurrentResponse(self,translation_m,major,top,bottom)


def prepare_case(basis, factors, transverse_sign=1, longitudinal_sign=1, *, wheel_vertical_override_kn=None):
    if not isinstance(basis,(TopUnstiffenedBasis,TopIntermediateBasis)): raise ValueError('Explicit TopUnstiffenedBasis or TopIntermediateBasis required')
    if type(transverse_sign) is not int or type(longitudinal_sign) is not int or transverse_sign not in (-1,1) or longitudinal_sign not in (-1,1):
        raise ValueError('Signed directions must be integer -1 or +1')
    p=basis.validated_project()
    factors=action_case_factors(factors,wheel_vertical_override_kn=wheel_vertical_override_kn)
    g,udl,wheels=case_loads(p,factors,transverse_sign,longitudinal_sign)
    s=p.section;h=s.d_mm-s.tf_mm;zt=h/2;zb=-zt;zrail=s.d_mm/2+p.rail.height_mm
    ey=p.rail.offset_from_web_mm+p.rail.lateral_eccentricity_mm
    tops=[];bottoms=[];splits=[]
    for wheel in wheels:
        split=wheel_flange_forces(vertical_n=wheel.vertical_kn*1000,lateral_n=wheel.horizontal_kn*1000,
            rail_eccentricity_mm=ey,lateral_application_z_mm=zrail,top_flange_z_mm=zt,bottom_flange_z_mm=zb)
        splits.append(dict(wheel=wheel.name,offset_m=wheel.offset_m,**split))
        tops.append(MovingWheel(wheel.offset_m,0.,split['top_lateral_n']/1000,wheel.name,
                               minor_moment_knm=wheel.minor_moment_knm))
        bottoms.append(MovingWheel(wheel.offset_m,0.,split['bottom_lateral_n']/1000,wheel.name))
    # Permanent rail weight uses its actual geometric offset, NOT the wheel's
    # accidental contact eccentricity; profile and extra dead load are centered.
    rail_q=p.rail.mass_kg_per_m*9.80665/1000*factors.dead_support
    qtop=rail_q*p.rail.offset_from_web_mm/h
    top_udl=UniformLoad(horizontal_kn_per_m=qtop)
    bottom_udl=UniformLoad(horizontal_kn_per_m=-qtop)
    If=s.tf_mm*s.bf_mm**3/12
    beam=BeamModel(p.span_m,p.material.E_mpa,g.Ix_mm4,g.Iy_mm4)
    flange=BeamModel(p.span_m,p.material.E_mpa,If,If)
    bodies=basis.stationary_bodies if isinstance(basis,TopIntermediateBasis) else ()
    fixed=stationary_point_loads(bodies,span_mm=p.span_m*1000,h_mm=h,dead_support=factors.dead_support)
    return PreparedCase(basis,p,factors,g,udl,tuple(wheels),tuple(tops),tuple(bottoms),beam,flange,
        top_udl,bottom_udl,transverse_sign,longitudinal_sign,tuple(splits),
        projection_equivalent_loads(p,udl)+fixed[0],_projection_fixed(p,qtop,horizontal=True)+fixed[1],
        _projection_fixed(p,-qtop,horizontal=True)+fixed[2],bodies,
        basis.stationary_ledger_sha256 if bodies else '',basis.geometry_inputs_hash if bodies else '')


def solve_concurrent_position(basis,factors,translation_m,transverse_sign=1,longitudinal_sign=1,**kwargs):
    return prepare_case(basis,factors,transverse_sign,longitudinal_sign,**kwargs).solve_position(translation_m)


def _tail(plane,a,outward,distance):
    """Signed-UDL free tail; direct integration, not a Vlasov extrapolation."""
    q=plane.udl_kn_per_m;EI=plane.EI_knm2;u=distance
    x=0. if outward==-1 else plane.span_m
    slope=outward*plane.slope_rad(x)
    return dict(moment=-q*(a-u)**2/2,shear=outward*q*(a-u),
        displacement=1000*(slope*u+q/EI*(a*a*u*u/4-a*u**3/6+u**4/24)),
        slope=outward*(slope+q/(6*EI)*(a**3-(a-u)**3)))


def _plane_at(plane,x,side):
    return dict(moment=plane.moment_knm(x,side),shear=plane.shear_kn(x,side),
                displacement=plane.deflection_mm(x),slope=plane.slope_rad(x))


@dataclass(frozen=True)
class ConcurrentResponse:
    prepared: PreparedCase
    translation_m: float
    major: object
    top: object
    bottom: object
    @property
    def case_name(self): return self.prepared.factors.name
    @property
    def vertical(self): return self.major
    @property
    def properties(self): return self.prepared.properties
    @property
    def factors(self): return self.prepared.factors
    @property
    def rail_level_mm(self): return self.prepared.rail_z_mm
    @property
    def projection_lengths_m(self):
        p=self.prepared.project
        return (p.beam_end_left_mm/1000,p.beam_end_right_mm/1000)

    def _fields(self,x,side):
        _number(x,'section position')
        if side not in ('left','right'): raise ValueError('Section side must be left/right')
        L=self.prepared.project.span_m;a,b=self.projection_lengths_m
        if not -a<=x<=L+b: raise ValueError('Section outside physical beam')
        left=x<0 or x==0 and side=='left' and a>0
        right=x>L or x==L and side=='right' and b>0
        if left or right:
            outward=-1 if left else 1
            length=a if left else b;distance=-x if left else x-L
            rows=tuple(_tail(plane,length,outward,distance) for plane in (self.major.vertical,self.top.horizontal,self.bottom.horizontal))
            return rows,0.,('left_projection' if left else 'right_projection')
        if x==0 and side=='left' or x==L and side=='right':
            raise ValueError('No material on the requested exterior support face')
        return tuple(_plane_at(plane,x,side) for plane in (self.major.vertical,self.top.horizontal,self.bottom.horizontal)),self.major.axial_force_kn(x,side),'main_span'

    def axial_displacement_mm(self,x):
        # u_axis(0)=0; N tension positive. Axial tails carry no Fx and inherit
        # support u. The right projection is not falsely axially fixed.
        p=self.prepared.project;xx=min(p.span_m,max(0.,x))
        integral=self.major.udl.longitudinal_kn_per_m*(p.span_m*xx-xx*xx/2)
        integral+=sum(w.longitudinal_kn*min(xx,w.position_m) for w in self.major.all_loads)
        return integral*1e6/(p.material.E_mpa*self.properties.A_mm2)

    def at(self,x_m,side='right'):
        fields,N,region=self._fields(x_m,side);v,t,b=fields
        c=self.prepared;s=c.project.section;g=self.properties;h=c.h_mm
        theta=(t['displacement']-b['displacement'])/h
        horizontal=(t['displacement']+b['displacement'])/2
        axial=N*1000/g.A_mm2
        stress={}
        # All actual rectangular flange edge fibers, inner and outer faces.
        # Lateral analogy stress is constant across each flange thickness.
        for flange,sign,f in (('top',1,t),('bottom',-1,b)):
            for face,z in (('outer',sign*s.d_mm/2),('inner',sign*(s.d_mm/2-s.tf_mm))):
                for edge,y in (('left',-s.bf_mm/2),('right',s.bf_mm/2)):
                    stress[f'{flange}_{face}_{edge}']=dict(
                        sigma_x_mpa=axial-v['moment']*1e6*z/g.Ix_mm4+f['moment']*1e6*y/c.flange_I_mm4,
                        y_mm=y,z_mm=z,omega_mm2=y*sign*h/2,
                        sigma_axial_mpa=axial,sigma_major_mpa=-v['moment']*1e6*z/g.Ix_mm4,
                        sigma_flange_lateral_mpa=f['moment']*1e6*y/c.flange_I_mm4,
                        tau_xy_flange_mpa=0.)
        ux=self.axial_displacement_mm(x_m)
        return dict(case_name=self.case_name,translation_m=self.translation_m,position_m=x_m,side=side,region=region,
            transverse_sign=c.transverse_sign,longitudinal_sign=c.longitudinal_sign,
            N_kn=N,Mx_knm=v['moment'],My_knm=t['moment']+b['moment'],
            top_flange_M_knm=t['moment'],bottom_flange_M_knm=b['moment'],
            Vy_kn=v['shear'],Vx_kn=t['shear']+b['shear'],
            top_flange_V_kn=t['shear'],bottom_flange_V_kn=b['shear'],
            analogy_torque_knm=(t['shear']-b['shear'])*h/2000,
            vertical_mm=v['displacement'],horizontal_mm=horizontal,
            top_horizontal_mm=t['displacement'],bottom_horizontal_mm=b['displacement'],theta_rad=theta,
            physical_rotation_x_rad=-theta,
            rail_horizontal_mm=horizontal+c.rail_z_mm*theta,
            rail_vertical_mm=v['displacement']+c.ey_mm*theta,
            axial_mm=ux,rail_longitudinal_mm=ux+c.rail_z_mm*v['slope']-c.ey_mm*t['slope'],
            major_slope_rad=v['slope'],top_lateral_slope_rad=t['slope'],bottom_lateral_slope_rad=b['slope'],
            stresses=stress,
            flange_shear_center_mpa=dict(top=t['shear']*1000*s.bf_mm**2/(8*c.flange_I_mm4),
                                         bottom=b['shear']*1000*s.bf_mm**2/(8*c.flange_I_mm4)),
            local_sigmaT_calculated=False,complete_stress_tensor=False,
            shear_scope='Signed rectangular flange lateral shear only; no local fillet/web/tensor qualification',
            design_complete=False)

    def flange_shear_mpa(self,x_m,flange,y_mm,side='right'):
        if flange not in ('top','bottom'): raise ValueError('Flange must be top/bottom')
        _number(y_mm,'flange coordinate')
        s=self.prepared.project.section
        if abs(y_mm)>s.bf_mm/2: raise ValueError('Point outside flange')
        row=self.at(x_m,side)
        return row[flange+'_flange_V_kn']*1000*(s.bf_mm**2/4-y_mm**2)/(2*self.prepared.flange_I_mm4)

    def support_vectors(self):
        """Coexistent 6-vectors, about centroid, physical x/y/z coordinates.

        Positive beam solver horizontal reactions balance positive applied H,
        therefore the actual force ON BEAM is their negative. Vertical is up.
        Axial anchor is on the section axis. Demand ON SUPPORT is exact opposite.
        """
        c=self.prepared;h=c.h_mm;r=self.major.reactions
        result=[]
        for i,(name,x,rz,rx) in enumerate((('left',0.,r.vertical_left_kn,r.longitudinal_left_kn),
                                         ('right',c.project.span_m,r.vertical_right_kn,r.longitudinal_right_kn))):
            ft=(self.top.horizontal.left_reaction_kn,self.top.horizontal.right_reaction_kn)[i]
            fb=(self.bottom.horizontal.left_reaction_kn,self.bottom.horizontal.right_reaction_kn)[i]
            v=dict(Fx_kn=rx,Fy_kn=-ft-fb,Fz_kn=rz,Mx_knm=(ft-fb)*h/2000,My_knm=0.,Mz_knm=0.)
            result.append(dict(case_name=self.case_name,translation_m=self.translation_m,support=name,position_m=x,
                on_beam=v,on_support={k:-a for k,a in v.items()},
                top_lateral_on_beam_kn=-ft,bottom_lateral_on_beam_kn=-fb,
                moment_reference='section centroid; axial anchor on section axis',
                physical_stiffener_credit=False,connection_designed=False))
        return tuple(result)

    def equilibrium(self):
        """Independent 3-D force/moment closure of original loads + supports."""
        c=self.prepared;p=c.project;L=p.span_m;a,b=self.projection_lengths_m
        force=[0.,0.,0.];moment=[0.,0.,0.]
        for w in self.major.loads:
            Fx,H,P=w.longitudinal_kn,w.horizontal_kn,w.vertical_kn
            force[0]+=Fx;force[1]+=H;force[2]-=P
            moment[0]-=(P*c.ey_mm+H*c.rail_z_mm)/1000
            moment[1]+=w.position_m*P+w.major_moment_knm
            moment[2]+=w.position_m*H+w.minor_moment_knm
        # Original physical body gravity once, not its lateral analogy pair or
        # projection equivalents. Each body's own real CG retains its torque.
        for body in c.stationary_bodies:
            P=body_vertical_kn(body,c.factors.dead_support)
            force[2]-=P
            moment[0]-=P*body.y_mm/1000
            moment[1]+=P*body.x_mm/1000
        total_q=c.udl.vertical_kn_per_m*(L+a+b)
        force[2]-=total_q
        moment[1]+=c.udl.vertical_kn_per_m*((L+b)**2-a*a)/2
        rail_q=p.rail.mass_kg_per_m*9.80665/1000*c.factors.dead_support
        moment[0]-=rail_q*(L+a+b)*p.rail.offset_from_web_mm/1000
        for row in self.support_vectors():
            r=row['on_beam'];x=row['position_m']
            for i,key in enumerate(('Fx_kn','Fy_kn','Fz_kn')): force[i]+=r[key]
            moment[0]+=r['Mx_knm'];moment[1]+=r['My_knm']-x*r['Fz_kn'];moment[2]+=r['Mz_knm']+x*r['Fy_kn']
        return dict(force_residual_kn=tuple(force),moment_residual_knm=tuple(moment))

    def _displacement_weights(self):
        c=self.prepared;h=c.h_mm;z=c.rail_z_mm;e=c.ey_mm
        return dict(vertical_mm=(1.,0.,0.),horizontal_mm=(0.,.5,.5),
            top_horizontal_mm=(0.,1.,0.),bottom_horizontal_mm=(0.,0.,1.),
            theta_rad=(0.,1/h,-1/h),rail_horizontal_mm=(0.,.5+z/h,.5-z/h),
            rail_vertical_mm=(1.,e/h,-e/h))

    def exact_spatial_states(self):
        """Exact polynomial extrema of advertised linear stress/displacements.

        Includes every wheel/couple/axial jump on BOTH physical faces and real
        projection roots. Does NOT certify arbitrary nonlinear interactions.
        """
        c=self.prepared;p=c.project;s=p.section;L=p.span_m
        planes=(self.major.vertical,self.top.horizontal,self.bottom.horizontal)
        nodes=sorted({0.,L,*(w.position_m for solution in (self.major,self.top,self.bottom) for w in solution.all_loads)})
        points=set(nodes)
        # Signed normal stress derivative on each fixed-active-set interval.
        for a,b in zip(nodes[:-1],nodes[1:]):
            width=b-a
            for flange,sign,plane in (('top',1,planes[1]),('bottom',-1,planes[2])):
                for z in (sign*s.d_mm/2,sign*(s.d_mm/2-s.tf_mm)):
                    for y in (-s.bf_mm/2,s.bf_mm/2):
                        A=-1e6*z/self.properties.Ix_mm4;B=1e6*y/c.flange_I_mm4
                        deriv=A*planes[0].shear_kn(a)+B*plane.shear_kn(a)
                        curve=A*planes[0].udl_kn_per_m+B*plane.udl_kn_per_m
                        if curve:
                            x=a+deriv/curve
                            if a<x<b: points.add(x)
            for weights in self._displacement_weights().values():
                coeff=[0.,0.,0.,0.]
                for w,plane in zip(weights,planes):
                    coeff[0]+=w*plane.slope_rad(a)
                    coeff[1]-=w*plane.moment_knm(a)*width/plane.EI_knm2
                    coeff[2]-=w*plane.shear_kn(a)*width**2/(2*plane.EI_knm2)
                    coeff[3]+=w*plane.udl_kn_per_m*width**3/(6*plane.EI_knm2)
                points.update(a+r*width for r in _roots_in_unit_interval(tuple(coeff)))
        a,b=self.projection_lengths_m
        for length,outward,root in ((a,-1,0.),(b,1,L)):
            if not length:continue
            points.update((root,root+outward*length))
            # Tail stresses/actions are monotone quadratics/linear and extremize
            # at root/tip. Combined tail displacement has cubic derivative.
            for weights in self._displacement_weights().values():
                coeff=[0.,0.,0.,0.]
                for w,plane in zip(weights,planes):
                    coeff[0]+=w*outward*plane.slope_rad(root)
                    k=w*plane.udl_kn_per_m/plane.EI_knm2
                    coeff[1]+=k*length**3/2;coeff[2]-=k*length**3/2;coeff[3]+=k*length**3/6
                points.update(root+outward*r*length for r in _roots_in_unit_interval(tuple(coeff)))
        rows=[]
        for x in sorted(points):
            if x==-a: sides=('right',)
            elif x==L+b: sides=('left',)
            elif x in nodes: sides=('left','right')
            else: sides=('right',)
            rows.extend(self.at(x,side) for side in sides)
        return tuple(rows)

    def metadata(self):
        return dict(basis=self.prepared.basis.provenance(),plate=self.prepared.plate_metadata,
            local_sigmaT_calculated=False,design_complete=False,scope=SCOPE,
            root_radius_used_as_actual_circle=self.prepared.basis.root_geometry_basis=='documented_circular_root',
            sectorial_height_mm=self.prepared.h_mm/2,rail_load_height_mm=self.prepared.rail_z_mm,
            analytic_spatial_scope='signed nominal edge stress and advertised linear displacement fields',
            HL_mapping='global Fx/A once + major Fx*zrail once + top-only minor -Fx*ey once')


@dataclass(frozen=True)
class ScalarEnvelope:
    metric: str
    signed_value: float
    absolute_value: float
    upper_bound: float
    discretization_error_bound: float
    translation_m: float
    state: dict


@dataclass(frozen=True)
class MovingCaseResult:
    maxima: dict
    samples: tuple
    converged: bool
    refinements: int
    translation_range_m: tuple
    max_translation_gap_m: float
    method: str = 'Exact polynomial spatial extrema; event-aligned nested moving grid with analytic scalar discretization bounds'
    design_complete: bool = False
    limitations: tuple = SCOPE + ('Bounds do not certify nonlinear resistance, stability or fatigue-cycle extraction.',)


def _flatten_metrics(row):
    values={name:row[name] for name in ('vertical_mm','horizontal_mm','top_horizontal_mm',
            'bottom_horizontal_mm','theta_rad','rail_horizontal_mm','rail_vertical_mm')}
    values.update({'sigma/'+name:point['sigma_x_mpa'] for name,point in row['stresses'].items()})
    return values


def _moving_constants(c):
    """Within-event Lipschitz constants for maxima; units metric per metre.

    Normal-stress candidates: fixed x, stationary x, or moving load faces. At a
    fixed x, |dM/da| <= sum|P|. At a moving face an extra |V| applies. Axial
    point-force jumps also move, so retain that extra term even without couples.
    Stress on tails has translation derivative zero (UDL fixed). Displacement
    uses Green-function uniform derivative bounds, plus support slope times
    physical tail length. Entry/exit jumps are partitioned into separate events.
    """
    s=c.project.section;L=c.project.span_m;tail=max(c.project.beam_end_left_mm,c.project.beam_end_right_mm)/1000
    plane_inputs=((c.source_wheels,c.udl.vertical_kn_per_m,c.beam.Ix_mm4,'vertical_kn','major_moment_knm'),
                  (c.top_wheels,c.top_udl.horizontal_kn_per_m,c.flange_I_mm4,'horizontal_kn','minor_moment_knm'),
                  (c.bottom_wheels,c.bottom_udl.horizontal_kn_per_m,c.flange_I_mm4,'horizontal_kn','minor_moment_knm'))
    displ=[]
    for wheels,q,I,load,couple in plane_inputs:
        P=sum(abs(getattr(w,load)) for w in wheels);C=sum(abs(getattr(w,couple)) for w in wheels)
        EI=c.project.material.E_mpa*I*1e-9
        main=1000*(P*L*L/8+C*L/4)/EI
        projection=1000*tail*(P*L/2+C)/EI
        displ.append(max(main,projection))
    dummy=c.solve_position(c.translation_range_m[0])
    constants={name:sum(abs(w)*K for w,K in zip(weights,displ)) for name,weights in dummy._displacement_weights().items()}
    for flange,sign,fw,fq in (('top',1,c.top_wheels,c.top_udl.horizontal_kn_per_m),('bottom',-1,c.bottom_wheels,c.bottom_udl.horizontal_kn_per_m)):
        for face,z in (('outer',sign*s.d_mm/2),('inner',sign*(s.d_mm/2-s.tf_mm))):
            for edge,y in (('left',-s.bf_mm/2),('right',s.bf_mm/2)):
                A=-1e6*z/c.properties.Ix_mm4;B=1e6*y/c.flange_I_mm4
                F=[A*w.vertical_kn+B*f.horizontal_kn for w,f in zip(c.source_wheels,fw)]
                C=[A*w.major_moment_knm+B*f.minor_moment_knm for w,f in zip(c.source_wheels,fw)]
                q=A*c.udl.vertical_kn_per_m+B*fq
                # Fixed tail root couples/forces affect V at a moving station.
                fixed_v=sum(abs(A*w.vertical_kn) for w in c.major_fixed)
                fixed_c=sum(abs(A*w.major_moment_knm) for w in c.major_fixed)
                ff=c.top_fixed if flange=='top' else c.bottom_fixed
                fixed_v+=sum(abs(B*w.horizontal_kn) for w in ff)
                fixed_c+=sum(abs(B*w.minor_moment_knm) for w in ff)
                V=abs(q)*L/2+sum(abs(v) for v in F)+sum(abs(v) for v in C)/L+fixed_v+fixed_c/L
                # Fixed body fields vary along a travelling wheel face even
                # without a moving couple/axial jump. Keep the legacy no-body
                # bound unchanged; add the full safe spatial slope for bodies.
                moving_jump=any(C) or any(w.longitudinal_kn for w in c.source_wheels) or bool(c.stationary_bodies)
                constants[f'sigma/{flange}_{face}_{edge}']=sum(abs(v) for v in F)+(V if moving_jump else 0.)
    return constants


def scan_moving_case(prepared, *, initial_intervals=16,max_refinements=6,relative_tolerance=.005,
                     stress_absolute_mpa=.01,deflection_absolute_mm=.001,rotation_absolute_rad=1e-7,
                     extra_translation_events=(),observer=None):
    """Bound only advertised linear fields; every envelope keeps actual witness.

    `observer(response, exact_states)` is called for each newly solved position,
    allowing an integration layer to calculate other checks without inventing a
    coexistent vector from independent envelope components. Observer calculations
    acquire NO proof/qualification from this scalar bound.
    """
    c=prepared
    if not isinstance(c,PreparedCase):raise ValueError('PreparedCase required')
    for key,value in (('initial_intervals',initial_intervals),('max_refinements',max_refinements)):
        if type(value) is not int or value<(1 if key=='initial_intervals' else 0):raise ValueError('Invalid '+key)
    for value in (relative_tolerance,stress_absolute_mpa,deflection_absolute_mm,rotation_absolute_rad):_number(value,'tolerance',nonnegative=True)
    lo,hi=c.translation_range_m
    events=set(c.translation_events())
    for a in extra_translation_events:
        _number(a,'translation event')
        if lo<=a<=hi:events.add(a)
    events=sorted(events);positions=set(events);spacing=(hi-lo)/initial_intervals
    for a,b in zip(events[:-1],events[1:]):
        n=max(1,ceil((b-a)/spacing))
        positions.update(a+(b-a)*i/n for i in range(1,n))
        eps=min((b-a)*1e-6,c.project.span_m*1e-9)
        near_a=max(nextafter(a,b),a+eps);near_b=min(nextafter(b,a),b-eps)
        if not a<near_a<b or not a<near_b<b:raise ValueError('Event interval below floating-point resolution')
        positions.update((near_a,near_b))
    cache={};best={};constants=_moving_constants(c)
    for refinement in range(max_refinements+1):
        positions=sorted(positions)
        for t in positions:
            if t in cache:continue
            response=c.solve_position(t);states=response.exact_spatial_states();cache[t]=response
            if observer is not None:observer(response,states)
            for row in states:
                for metric,value in _flatten_metrics(row).items():
                    if metric not in best or abs(value)>abs(best[metric][0]):best[metric]=(value,t,row)
        gap=max((b-a for a,b in zip(positions[:-1],positions[1:])),default=0.)
        cover=0.
        for a,b in zip(events[:-1],events[1:]):
            inside=[x for x in positions if a<x<b]
            cover=max(cover,inside[0]-a,b-inside[-1],max((y-x for x,y in zip(inside[:-1],inside[1:])),default=0.)/2)
        maxima={}
        converged=True
        for metric,(value,t,row) in best.items():
            err=constants[metric]*cover
            maxima[metric]=ScalarEnvelope(metric,value,abs(value),abs(value)+err,err,t,row)
            absolute=stress_absolute_mpa if metric.startswith('sigma/') else rotation_absolute_rad if metric=='theta_rad' else deflection_absolute_mm
            converged &= err<=absolute+relative_tolerance*abs(value)
        if converged or refinement==max_refinements:break
        positions={*positions,*((a+b)/2 for a,b in zip(positions[:-1],positions[1:]))}
    return MovingCaseResult(maxima,tuple(cache[t] for t in positions),bool(converged),refinement,(lo,hi),gap)
