"""Static transitive candidate import closure for numerical result lineage.

Walk all source import branches conservatively, including package initializers.
This excludes unrelated reports/research without relying on what happened to be
imported in this process. LRO runtime dependencies are additionally bound by the
caller; computed import names require an explicit caller root.
"""
import ast
import hashlib
import importlib.util
from pathlib import Path

PREFIXES = ('top_unstiffened_candidate', 'underslung_runway_candidate')


def candidate_import_closure(*module_roots):
    root = Path(__file__).resolve().parents[1]
    seen = set()
    hashes = {}

    def module_file(name):
        if not any(name == p or name.startswith(p+'.') for p in PREFIXES):
            return None
        stem = root.joinpath(*name.split('.'))
        return stem.with_suffix('.py') if stem.with_suffix('.py').is_file() else stem/'__init__.py' if (stem/'__init__.py').is_file() else None

    def visit(name):
        if name in seen:
            return
        seen.add(name)
        path = module_file(name)
        if path is None:
            return
        data = path.read_bytes()
        hashes[str(path.relative_to(root))] = hashlib.sha256(data).hexdigest()
        pieces = name.split('.')
        for i in range(1, len(pieces)):
            visit('.'.join(pieces[:i]))
        package = name if path.name == '__init__.py' else name.rpartition('.')[0]
        for node in ast.walk(ast.parse(data, filename=str(path))):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    visit(alias.name)
            elif isinstance(node, ast.ImportFrom):
                target = importlib.util.resolve_name('.'*node.level+(node.module or ''), package) if node.level else node.module or ''
                visit(target)
                for alias in node.names:
                    if alias.name != '*':
                        visit(target+'.'+alias.name)
            elif isinstance(node, ast.Call) and node.args and isinstance(node.args[0], ast.Constant) and isinstance(node.args[0].value, str):
                if isinstance(node.func, ast.Attribute) and node.func.attr == 'import_module':
                    visit(node.args[0].value)
    for name in (*module_roots, 'top_unstiffened_candidate.source_closure'):
        visit(name)
    return dict(sorted(hashes.items()))
