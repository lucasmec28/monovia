"""Sourced effective lengths for resistance checks, never physical supports.

Only minor-flexural shortening is supported by this rollout. The effective
length is supplied directly (K=1 restraint-spacing premise); this module does
not create restraints, reactions, redistributed actions or connection checks.
"""
from dataclasses import asdict, dataclass, fields
from math import isfinite

MODE = 'effective_buckling_lengths_only'
MINOR_RESTRAINT_BASIS = 'effective_shear_center_lateral_restraint_K1'
CONTRACT_SHA256 = 'bf083612bf0d88993457e22a54d295580a1f77efaf12a7ac2b12988c471eddc3'
_LENGTH_FIELDS = ('major_flexural_mm', 'minor_flexural_mm', 'torsional_mm', 'lateral_torsional_mm')


def _length(value, name):
    # Bound the accepted numeric domain before float conversion or powers.
    if type(value) not in (int, float) or not 1e-6 <= value <= 1e12 or not isfinite(value):
        raise ValueError(name+' must be finite positive millimetres within the supported domain [1e-6, 1e12]')
    return float(value)


@dataclass(frozen=True)
class VerificationLengths:
    major_flexural_mm: float
    minor_flexural_mm: float
    torsional_mm: float
    lateral_torsional_mm: float
    premise_status: str
    source: str
    mode: str = MODE
    minor_restraint_basis: str = MINOR_RESTRAINT_BASIS
    units: str = 'mm'

    def __post_init__(self):
        self._validate_content()

    def _validate_content(self):
        from underslung_runway_candidate.autonomous_workflow.model import checked_text
        for name in ('mode', 'premise_status', 'minor_restraint_basis', 'source', 'units'):
            checked_text(getattr(self, name), 'Verification lengths '+name)
        for name in _LENGTH_FIELDS:
            _length(getattr(self, name), name)
        if self.mode != MODE:
            raise ValueError('Unsupported verification-length mode; no physical-bracing mode is accepted')
        if self.units != 'mm':
            raise ValueError('Verification lengths must explicitly use mm')
        if self.premise_status not in ('design_requirement', 'confirmed'):
            raise ValueError('Verification lengths require a design_requirement or confirmed premise')
        if self.minor_restraint_basis != MINOR_RESTRAINT_BASIS:
            raise ValueError('Explicit effective shear-center lateral-restraint K=1 premise required')
        if not isinstance(self.source, str) or not self.source.strip():
            raise ValueError('Verification-length source is required')
        return self

    def validate(self, physical_span_mm):
        self._validate_content()  # Also detects illicit mutation of a frozen instance.
        span = _length(physical_span_mm, 'physical_span_mm')
        if self.major_flexural_mm < span:
            raise ValueError('Major-flexural shortening is unsupported; use fullspan or an explicit resistance penalty')
        if self.torsional_mm < span:
            raise ValueError('Torsional shortening is unsupported; use fullspan or an explicit resistance penalty')
        if self.lateral_torsional_mm != span:
            raise ValueError('Lateral-torsional verification length must equal the original fullspan')
        return self

    def to_dict(self):
        self._validate_content()
        return asdict(self)

    @classmethod
    def from_dict(cls, data):
        if not isinstance(data, dict):
            raise ValueError('Verification lengths must be an object with explicit mm fields')
        unknown = set(data)-{f.name for f in fields(cls)}
        if unknown:
            raise ValueError('Unsupported verification-length fields: '+', '.join(sorted(map(str, unknown))))
        try:
            return cls(**data)
        except TypeError as exc:
            raise ValueError('Incomplete verification-length object: '+str(exc)) from exc


def verification_lengths_metadata(verification_lengths, physical_span_mm):
    """Resolve resistance metadata without modifying any mechanical inputs."""
    span = _length(physical_span_mm, 'physical_span_mm')
    if verification_lengths is None:
        adopted = {name: span for name in _LENGTH_FIELDS}
        supplied = None
    else:
        if not isinstance(verification_lengths, VerificationLengths):
            raise ValueError('Typed VerificationLengths or None required')
        verification_lengths.validate(span)
        supplied = verification_lengths.to_dict()
        adopted = {name: float(getattr(verification_lengths, name)) for name in _LENGTH_FIELDS}
    return dict(mode='legacy_fullspan' if supplied is None else MODE,
        supplied=supplied, units='mm', analysis_span_mm=span,
        strength_lengths_mm=adopted,
        first_order_gate_lengths_mm=dict(major_flexural_mm=span, minor_flexural_mm=span),
        first_order_gate_basis='original_fullspan_Ncomp_le_min_Ncr_major_minor_divided_by_25',
        minor_effective_length_factor=1.,
        minor_effective_length_is_design_premise=supplied is not None,
        source='Legacy original fullspan resistance lengths' if supplied is None else supplied['source'],
        premise_status='legacy_fullspan' if supplied is None else supplied['premise_status'],
        physical_supports_added=False, physical_brace_reactions_calculated=False,
        physical_action_redistribution_claimed=False,
        original_actions_bound_every_physical_braced_response_claimed=False,
        physical_brace_strength_or_stiffness_qualified=False,
        local_web_restraint_credit=False, lateral_torsional_restraint_credit=False,
        service_or_fatigue_lengths_changed=False, contract_sha256=CONTRACT_SHA256)
