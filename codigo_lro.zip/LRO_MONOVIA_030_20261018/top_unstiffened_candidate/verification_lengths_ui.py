"""Ordinary resistance parameters, deliberately separate from analysis supports."""
from copy import deepcopy
from math import isfinite

from .verification_lengths import VerificationLengths

MANUAL_SOURCE = 'Comprimentos de verificação selecionados no cálculo pelo usuário; solicitações do modelo global original preservadas.'
FIELDS = (
    ('major_flexural_mm', 'Flambagem por compressão: eixo de maior inércia [mm]'),
    ('minor_flexural_mm', 'Flambagem por compressão: eixo de menor inércia [mm]'),
    ('torsional_mm', 'Flambagem por torção [mm]'),
    ('lateral_torsional_mm', 'Flambagem lateral com torção, FLT [mm]'),
)


def default_lengths(span_mm):
    return VerificationLengths(major_flexural_mm=span_mm,minor_flexural_mm=span_mm,
        torsional_mm=span_mm,lateral_torsional_mm=span_mm,
        premise_status='design_requirement',source=MANUAL_SOURCE).to_dict()


def render_verification_lengths(st, raw, physical_span_mm, prefix='tu_input:verification_lengths.'):
    """No approval checkbox, new physical support, or implicit span division."""
    if type(physical_span_mm) not in (int,float) or not isfinite(physical_span_mm) or physical_span_mm<=0:
        st.caption('Informe o vão da viga antes dos comprimentos de verificação.')
        return deepcopy(raw)
    span=float(physical_span_mm)
    # None is the persisted automatic mode. Materialized widget defaults are
    # not manual choices. Follow span edits only while those defaults are intact.
    auto_key=prefix+'automatic_span'
    previous_auto_span=st.session_state.get(auto_key)
    if raw is None and previous_auto_span is not None:
        for name,_ in FIELDS:
            key=prefix+name
            if st.session_state.get(key)==previous_auto_span:
                st.session_state[key]=span
    if st.button('Usar o vão integral em todos os comprimentos',key=prefix+'reset_fullspan'):
        raw=None
        for name,_ in FIELDS:
            st.session_state[prefix+name]=span
    original=deepcopy(raw)
    data=deepcopy(raw) if raw is not None else default_lengths(span)
    st.caption('Comprimentos usados somente na resistência à instabilidade. Não alteram solicitações, tensões, flechas ou apoios da análise. Na seção I, o eixo de menor inércia é o eixo vertical da seção, não o eixo longitudinal da viga.')
    if st.button('Usar um terço do vão para a flambagem de menor inércia',key=prefix+'thirds'):
        st.session_state[prefix+'minor_flexural_mm']=span/3
    for name,label in FIELDS:
        key=prefix+name
        if name=='lateral_torsional_mm':
            # This first qualified rollout never credits an intermediate FLT restraint.
            st.session_state[key]=span
            data[name]=st.number_input(label,min_value=1.0,format='%.3f',disabled=True,key=key)
        else:
            kw={} if key in st.session_state else {'value':float(data[name])}
            data[name]=st.number_input(label,min_value=1.0,format='%.3f',key=key,**kw)
    st.caption('Nesta versão, só o comprimento de compressão no eixo fraco pode ser menor que o vão. Torção e eixo forte não recebem esse encurtamento; FLT e a verificação de primeira ordem permanecem referidas ao vão integral. Sem compressão axial, o ganho pode ser nulo.')
    if original is None and all(data[name]==span for name,_ in FIELDS):
        st.session_state[auto_key]=span
        return None
    st.session_state.pop(auto_key,None)
    if original is None or any(data[name]!=original[name] for name,_ in FIELDS):
        data.update(premise_status='design_requirement',source=MANUAL_SOURCE)
    return data
