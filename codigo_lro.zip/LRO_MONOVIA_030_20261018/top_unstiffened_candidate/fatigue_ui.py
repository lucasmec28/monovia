"""Optional sourced fatigue declarations; no guessed cycles or stresses."""
from dataclasses import fields
from .fatigue_inputs import (NBRFatiguePremises, CMAAFatiguePremises,
    MANUAL_CLASSIFICATION_KIND, MANUAL_CLASSIFICATION_SOURCE)

NBR_ENUMS={
 'material_grade':('Identificação do aço na Tabela D.1', {k:k for k in ('S235','S275','ASTM A36','S355','ASTM A572 GR50')}),
 'construction_detail':('Detalhe construtivo avaliado',{'W0_plain_rolled_unnotched':'W0: material-base laminado ordinário, sem entalhes'}),
 'fabrication_requirement':('Requisito de fabricação e inspeção',{'specified_h6':'Especificar h6 como requisito de fornecimento','specified_h6_qc':'Especificar h6 com controle de qualidade documentado'}),
 'evaluation_location':('Local de avaliação',{'base_material':'Material-base, fora de soldas, furos e regiões perturbadas'}),
 'kappa_policy':('Adoção do método resistente',{'explicit_kappa_minus_one_resistance_reduction':'Redução conservadora explícita da resistência com κ = −1'}),
}
NBR_SOURCES={
 'construction_detail_source':'Fonte da condição W0 do detalhe ordinário',
 'fabrication_source':'Fonte do requisito de fabricação/inspeção, sem afirmar inspeção executada',
 'adoption_source':'Fonte da adoção conservadora de κ = −1',
 'nominal_model_source':'Fonte e limites do modelo nominal de tensões adotado',
}
CMAA_ENUMS={
 'operating_environment':('Ambiente operacional',{'indoor_no_operating_wind':'Interno, sem vento operacional'}),
 'load_engagement':('Engate da carga',{'normal_non_abrupt':'Normal, sem engate brusco'}),
 'crane_configuration':('Aplicabilidade do método nominal CMAA',{
   'single_girder_under_running_trolley':'Viga única com carro suspenso',
   'not_established_adopted_nominal_method':'Método nominal adotado explicitamente, sem alegar conformidade integral'}),
 'surface_condition':('Condição superficial do detalhe ordinário',{'as_rolled_or_cleaned_plain_base_material':'Material-base laminado ou limpo, sem descontinuidades'}),
 'environment':('Ambiente do detalhe',{'normal_ambient_noncorrosive':'Temperatura ambiente normal, não corrosivo'}),
}
CMAA_NUMBERS={
 'bridge_travel_speed_m_s':'Velocidade física da ponte [m/s]',
 'trolley_travel_speed_m_s':'Velocidade física do carro [m/s]',
 'hoist_speed_m_s':'Velocidade física de içamento [m/s]',
}
CMAA_SOURCES={
 'physical_source':'Fonte das velocidades, ambiente, engate e aplicabilidade',
 'detail_source':'Fonte da condição superficial, detalhe e ambiente',
}


NBR_GROUP_LABELS = {f'E{i}':f'E{i} · Grupo de utilização do componente' for i in range(1,9)}
# CMAA 74:2020 section 2.1, PDF16: qualitative titles only. The loading
# patterns and spectrum-to-class rules are not replaced by an hours/cycles rule.
CMAA_SERVICE_LABELS = {
    'A':'A · Reserva ou uso pouco frequente',
    'B':'B · Serviço leve',
    'C':'C · Serviço moderado',
    'D':'D · Serviço pesado',
}


def blank_premises(cls):
    return {f.name:None if f.type is float else '' for f in fields(cls)}


def _render(st,raw,enums,sources,prefix,numbers=None):
    raw=dict(raw)
    for key,(label,labels) in enums.items():
        values=[None]+list(labels)
        value=raw.get(key)
        raw[key]=st.selectbox(label,values,index=values.index(value) if value in values else 0,
            format_func=lambda v,labels=labels:'Não informado / não adotado' if v is None else labels[v],key=prefix+key) or ''
    for key,label in (numbers or {}).items():
        value=raw.get(key)
        raw[key]=st.number_input(label,value=None if value is None or value=='' else float(value),format='%.3f',key=prefix+key)
    for key,label in sources.items():
        raw[key]=st.text_input(label,value=raw.get(key) or '',key=prefix+key)
    return raw



def _classification_radio(st,raw,*,field,label,labels,prefix):
    """Only an actual choice/change records manual selection.

    Opening an imported record must not relabel its existing classification or
    repair its missing provenance. In particular, selecting a lower group never
    repurposes an old unclassified E8/D conservative mode.
    """
    raw=dict(raw)
    previous=raw.get(field)
    options=list(labels)
    selected=st.radio(label,options,index=options.index(previous) if previous in labels else None,
        format_func=lambda value:labels[value],key=prefix+field)
    raw[field]=selected or ''
    if selected != previous and not (selected is None and previous in (None,'')):
        raw['classification_kind']=MANUAL_CLASSIFICATION_KIND if selected else ''
        raw['classification_source']=MANUAL_CLASSIFICATION_SOURCE if selected else ''
    return raw


def render_nbr_premises(st,raw,prefix):
    st.caption('Selecione o grupo de utilização do componente para a verificação NBR de vida classificada finita. A severidade cresce de E1 a E8. O resultado se refere ao grupo selecionado; não gera histórico de ciclos nem converte a classe CMAA em grupo E.')
    raw=_classification_radio(st,raw or blank_premises(NBRFatiguePremises),field='component_group',
        label='Grupo de utilização do componente',labels=NBR_GROUP_LABELS,prefix=prefix)
    return _render(st,raw,NBR_ENUMS,NBR_SOURCES,prefix)


def render_cmaa_premises(st,raw,prefix):
    st.caption('Selecione a classe de serviço CMAA usada na comparação nominal longitudinal de fadiga. A seleção não gera histórico de ciclos nem determina o grupo NBR; a verificação se refere à classe escolhida.')
    raw=_classification_radio(st,raw or blank_premises(CMAAFatiguePremises),field='service_class',
        label='Classe de serviço CMAA',labels=CMAA_SERVICE_LABELS,prefix=prefix)
    return _render(st,raw,CMAA_ENUMS,CMAA_SOURCES,prefix,CMAA_NUMBERS)
