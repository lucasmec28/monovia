"""Isolated classical flange-force decomposition for rolled runway candidates.

CISC MacCrimmon 2005 Fig6/p58 and ASI Gorenc 2003 §6.2/p25.
Positive H acts lateral; positive T=Fz*ey has same sense as positive H above
bottom-flange centroid. Each signed wheel case is retained; never zero eccentricity.
This is a nominal force calculation, NOT a NBR10084 local stress evaluator,
not a complete design, and not a fatigue-category assignment.
"""
from math import isfinite

def wheel_flange_forces(*,vertical_n,lateral_n,rail_eccentricity_mm,
                         lateral_application_z_mm,top_flange_z_mm,bottom_flange_z_mm):
    v=locals().copy()
    if any(isinstance(a,bool) or not isinstance(a,(int,float)) or not isfinite(a) for a in v.values()):
        raise ValueError('Finite numeric physical actions/coordinates required')
    h=top_flange_z_mm-bottom_flange_z_mm
    if h<=0:raise ValueError('Positive flange centroid separation required')
    if vertical_n<0:raise ValueError('Uplift outside adopted compression wheel model')
    tv=vertical_n*rail_eccentricity_mm
    Ht=(tv+lateral_n*(lateral_application_z_mm-bottom_flange_z_mm))/h
    Hb=lateral_n-Ht
    return dict(top_lateral_n=Ht,bottom_lateral_n=Hb,
                vertical_eccentric_torque_nmm=tv,
                total_moment_about_bottom_nmm=tv+lateral_n*(lateral_application_z_mm-bottom_flange_z_mm),
                force_residual_n=Ht+Hb-lateral_n,
                moment_residual_nmm=Ht*h-tv-lateral_n*(lateral_application_z_mm-bottom_flange_z_mm),
                source='CISC2005 Fig6; ASI2003 §6.2, signed equilibrium generalization',
                saint_venant_relief_credited=False,local_sigmaT_calculated=False,
                design_complete=False)

def flange_nominal_longitudinal_stress(*,global_major_sigma_mpa,lateral_flange_moment_nmm,
                                       flange_width_mm,flange_thickness_mm):
    vals=locals()
    if any(isinstance(a,bool) or not isinstance(a,(int,float)) or not isfinite(a) for a in vals.values()):
        raise ValueError('Finite numeric inputs required')
    if min(flange_width_mm,flange_thickness_mm)<=0:raise ValueError('Positive flange dimensions')
    W=flange_thickness_mm*flange_width_mm**2/6
    lateral=lateral_flange_moment_nmm/W
    return dict(edge_minus_mpa=global_major_sigma_mpa-lateral,
                edge_plus_mpa=global_major_sigma_mpa+lateral,
                lateral_flange_elastic_modulus_mm3=W,
                source='Elastic rectangular flange bending; CISC flexure analogy',
                scope='Signed nominal longitudinal stress only; not local transverse tensor')
