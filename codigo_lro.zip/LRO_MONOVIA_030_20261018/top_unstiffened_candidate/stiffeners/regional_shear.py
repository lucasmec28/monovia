"""Sufficient regional vertical-shear enclosures for prepared TOP mechanics.

This is a demand calculation, not a resistance or stiffener qualification. The
continuous full passage of every wheel is retained. No scan, new EI/Mcr/bracing
benefit, local tensor, or attained train maximum is introduced.

For a cut x and an active point force P/couple C at y in [0,L],
V = P*((L-y)/L - I[y left of cut]) - C/L. Including both shear sides,
the force coefficient is in [-x/L, 1-x/L]. Each signed P/C pair is
combined BEFORE including inactive zero. Summing the resulting intervals
relaxes coexisting wheel positions outward, never clips physical travel.

Fixed forces at their actual positions, fixed couples and signed UDL are
combined first. Between fixed-load cuts, the lower moving enclosure is
concave and the upper enclosure convex; adding the affine fixed shear
preserves this. Their extrema therefore occur at the closed region ends
or a fixed-load cut, with both material sides retained. Exact rational
arithmetic is used for the supplied numerical load state. This is not an
interval certificate of upstream preparation or a physical model validation.
"""
from __future__ import annotations

from fractions import Fraction
from math import inf, isfinite, nextafter

from ..bounds import _nominal_geometry, _prepared_bound_signature, _real, _signed
from ..mechanics import prepare_case


_ZERO = Fraction(0)


def _fraction(value, name):
    return Fraction(_signed(value, name))


def _number(value, name, direction=0):
    """Convert a rational receipt value; bound ends are rounded outwards."""
    try:
        result = float(value)
    except (OverflowError, ValueError):
        raise ValueError(name + ' exceeds the finite supported numeric range') from None
    if isfinite(result):
        if direction < 0 and Fraction(result) > value:
            result = nextafter(result, -inf)
        elif direction > 0 and Fraction(result) < value:
            result = nextafter(result, inf)
    return _signed(result, name)


def _interval(values, name):
    return (_number(values[0], name + ' lower', -1),
            _number(values[1], name + ' upper', 1))


def _ratio(value):
    return value.numerator, value.denominator


def _load_rows(rows, coordinate):
    return tuple((_fraction(getattr(w, coordinate), coordinate),
                  _fraction(w.vertical_kn, 'vertical point force'),
                  _fraction(w.major_moment_knm, 'major point couple')) for w in rows)


def _regional_shear_enclosure(*, span_m, left_mm, right_mm, moving_loads=(),
                              fixed_loads=(), udl_kn_m=0.,
                              projection_lengths_mm=(0., 0.)):
    """Pure mechanics helper; the public prepared adapter authenticates state.

    Loads are MovingWheel/PointLoad-compatible records in m, kN and kN*m.
    Coordinates and projection lengths supplied by the caller are in mm.
    Projection equivalent loads MUST already be included in fixed_loads.
    This helper is deliberately private, and does not qualify load origins.
    """
    L = Fraction(_real(span_m, 'span', 1e-12))
    left_mm = _signed(left_mm, 'region left coordinate')
    right_mm = _signed(right_mm, 'region right coordinate')
    if left_mm > right_mm:
        raise ValueError('Region endpoints must be ordered and closed')
    if type(projection_lengths_mm) not in (tuple, list) or len(projection_lengths_mm) != 2:
        raise ValueError('Exactly two physical projection lengths are required')
    tail_mm = tuple(_real(v, 'physical projection length') for v in projection_lengths_mm)
    tails = tuple(Fraction(v / 1000) for v in tail_mm)
    span_mm = _signed(float(L) * 1000, 'span in mm')
    end_mm = _signed(span_mm + tail_mm[1], 'physical right endpoint in mm')
    if left_mm < -tail_mm[0] or right_mm > end_mm:
        raise ValueError('Region lies outside the physical beam')
    def section_coordinate(mm):
        # Recognize exact supplied physical identities, not an epsilon band.
        # E.g. 6280/1000 and 6.02+0.260 can round differently. The endpoint
        # expressed as span_mm+projection_mm is the SAME physical endpoint,
        # and maps to the exact internal sum. Nearby distinct cuts stay distinct.
        if mm == 0.:
            return _ZERO
        if mm == span_mm:
            return L
        if mm == -tail_mm[0]:
            return -tails[0]
        if mm == end_mm:
            return L + tails[1]
        return _fraction(mm / 1000, 'region coordinate in m')
    left, right = section_coordinate(left_mm), section_coordinate(right_mm)
    if left > right:
        raise ValueError('Region endpoints must be ordered and closed')
    if left < -tails[0] or right > L + tails[1]:
        raise ValueError('Region lies outside the physical beam')
    q = _fraction(udl_kn_m, 'vertical UDL')
    moving = _load_rows(moving_loads, 'offset_m')
    fixed = _load_rows(fixed_loads, 'position_m')
    if any(not 0 <= x <= L for x, unused_P, unused_C in fixed):
        raise ValueError('Fixed equivalent load outside the support span')
    travel = (-max(row[0] for row in moving), L - min(row[0] for row in moving)) if moving else (_ZERO, L)
    fixed_RA = q * L / 2 + sum((P * (L - x) / L - C / L for x, P, C in fixed), _ZERO)
    segments = []
    extrema = []

    def fixed_shear(x, side):
        return fixed_RA - q * x - sum((P for y, P, unused_C in fixed
            if y < x or (y == x and side == 'right')), _ZERO)

    def moving_interval(x):
        lo = hi = _ZERO
        for unused_offset, P, C in moving:
            values = (_ZERO, -P * x / L - C / L, P * (L - x) / L - C / L)
            lo += min(values)
            hi += max(values)
        return lo, hi

    def coordinate(x):
        return dict(section_m=_number(x, 'section coordinate'),
                    section_exact_ratio_m=_ratio(x),
                    section_mm=_number(x * 1000, 'section coordinate in mm'))

    if left <= L and right >= 0:
        a, b = max(left, _ZERO), min(right, L)
        cuts = sorted({a, b, *(x for x, unused_P, unused_C in fixed if a <= x <= b)})
        rows = []
        fixed_values = []
        main_lo = main_hi = None
        for x in cuts:
            # At a support only the main-span material side belongs to this
            # segment. If a projection exists its other side is added below.
            sides = ('right',) if x == 0 else ('left',) if x == L else ('left', 'right')
            moving_lo, moving_hi = moving_interval(x)
            for side in sides:
                permanent = fixed_shear(x, side)
                lo, hi = permanent + moving_lo, permanent + moving_hi
                fixed_values.append(permanent)
                row = dict(**coordinate(x), side=side,
                    fixed_and_udl_shear_kn=_number(permanent, 'coexistent fixed shear'),
                    moving_shear_interval_kn=_interval((moving_lo, moving_hi), 'moving shear'),
                    shear_interval_kn=_interval((lo, hi), 'total shear'),
                    actual_train_witness=False)
                rows.append(row)
                extrema.append((lo, hi, 'main_span', row))
                main_lo = lo if main_lo is None else min(main_lo, lo)
                main_hi = hi if main_hi is None else max(main_hi, hi)
        receipts = []
        for index, (offset, P, C) in enumerate(moving):
            active = (-P * b / L - C / L, P * (L - a) / L - C / L) if P >= 0 else (
                P * (L - a) / L - C / L, -P * b / L - C / L)
            receipts.append(dict(index=index, offset_m=_number(offset, 'wheel offset'),
                offset_exact_ratio_m=_ratio(offset), vertical_force_kn=_number(P, 'vertical force'),
                major_couple_knm=_number(C, 'major couple'),
                active_region_shear_interval_kn=_interval(active, 'active wheel shear'),
                inactive_zero_included=True,
                region_shear_interval_kn=_interval((min(_ZERO, active[0]), max(_ZERO, active[1])), 'wheel shear')))
        segments.append(dict(kind='main_span', left_m=_number(a, 'segment start'),
            right_m=_number(b, 'segment end'),
            shear_interval_kn=_interval((main_lo, main_hi), 'main span shear'),
            fixed_and_udl_shear_interval_kn=_interval((min(fixed_values), max(fixed_values)), 'fixed shear'),
            fixed_load_positions_m=tuple(_number(x, 'fixed coordinate') for x, unused_P, unused_C in fixed),
            candidate_sections=tuple(rows), candidate_count=len(rows),
            moving_load_receipts=tuple(receipts)))

    for kind, length, a, b in (
            ('left_projection', tails[0], max(left, -tails[0]), min(right, _ZERO)),
            ('right_projection', tails[1], max(left, L), min(right, L + tails[1]))):
        if length <= 0 or a > b:
            continue
        def tail_shear(x):
            return -q * (length + x) if kind == 'left_projection' else q * (length - (x - L))
        values = tuple(tail_shear(x) for x in (a, b))
        rows = []
        for x, value in zip((a, b), values):
            row = dict(**coordinate(x), side='left' if kind == 'left_projection' else 'right',
                shear_interval_kn=_interval((value, value), 'tail shear'), actual_train_witness=False)
            rows.append(row)
            extrema.append((value, value, kind, row))
        segments.append(dict(kind=kind, left_m=_number(a, 'segment start'),
            right_m=_number(b, 'segment end'),
            shear_interval_kn=_interval((min(values), max(values)), 'projection shear'),
            candidate_sections=tuple(rows), candidate_count=len(rows),
            unloaded_projection_udl_polynomial=True, moving_wheels_on_projection=False))

    if not extrema:
        raise ValueError('No physical material section exists in the requested region')
    lower = min(extrema, key=lambda row: row[0])
    upper = max(extrema, key=lambda row: row[1])
    bound = max(abs(lower[0]), abs(upper[1]))
    controlling = lower if abs(lower[0]) >= abs(upper[1]) else upper
    return dict(kind='sufficient_regional_vertical_shear_enclosure',
        bound_kind='sufficient_absolute_continuous_full_travel',
        left_mm=left_mm, right_mm=right_mm,
        region_interval_mm=(left_mm, right_mm),
        region_interval_m=(_number(left, 'region start'), _number(right, 'region end')),
        region_exact_ratios_m=(_ratio(left), _ratio(right)),
        coordinate_mapping='mm-to-m float conversion with exact source-identity mapping at supports and free ends; no epsilon snapping',
        full_physical_travel_m=tuple(_number(t, 'travel endpoint') for t in travel),
        full_physical_travel_exact_ratios_m=tuple(_ratio(t) for t in travel),
        physical_beam_interval_m=(_number(-tails[0], 'physical start'), _number(L + tails[1], 'physical end')),
        shear_interval_kn=_interval((lower[0], upper[1]), 'regional shear'),
        shear_abs_kn=_number(bound, 'regional shear demand', 1),
        demand_abs_kn=_number(bound, 'regional shear demand', 1),
        demand_abs_N=_number(bound * 1000, 'regional shear demand in N', 1),
        lower_enclosure_section=dict(segment=lower[2], **lower[3]),
        upper_enclosure_section=dict(segment=upper[2], **upper[3]),
        controlling_enclosure_section=dict(segment=controlling[2], **controlling[3]),
        segments=tuple(segments), moving_load_count=len(moving), fixed_load_count=len(fixed),
        fixed_loads=tuple(dict(position_m=_number(x, 'fixed position'),
            position_exact_ratio_m=_ratio(x), vertical_force_kn=_number(P, 'fixed force'),
            major_couple_knm=_number(C, 'fixed couple')) for x, P, C in fixed),
        vertical_udl_kn_per_m=_number(q, 'vertical UDL'),
        closed_region_endpoints=True, both_material_shear_sides=True,
        fixed_loads_retained_at_actual_coordinates=True,
        fixed_and_udl_combined_before_enclosure=True,
        moving_force_and_couple_combined_before_enclosure=True,
        main_span_projection_equivalents_retained=True,
        full_travel_not_clipped_to_region=True,
        independent_wheel_positions_relaxed=True,
        sampled_maxima_used=False, attained_maximum_claimed=False,
        action_origin_authenticated=False, resistance_credit_granted=False,
        station_qualified=False, EI_J_Cw_Mcr_credit=False,
        floating_point_interval_certificate=False,
        arithmetic='Exact rational regional-demand arithmetic for supplied float load state; bound ends converted outward',
        proof=('Point-force/couple Green interval including inactive zero; fixed loads and UDL coexist at their actual spatial cuts; '
               'concave lower and convex upper enclosures attain outward extrema at closed endpoints and both fixed-cut sides; '
               'actual unloaded projection UDL polynomials'),
        scope='Vertical shear demand only; no resistance, material, panel, station, connection, fatigue or stability qualification')


def prepared_regional_shear_bounds(c, *, left_mm, right_mm, region_id=None):
    """Return a sufficient continuous-passage demand for one closed mm region.

    Rebuilding the prepared case rejects omitted fixed masses, tail equivalents,
    substituted moving loads and stale geometric inputs. Source action-family
    authentication remains the caller's separate responsibility. The supported
    basis forbids wheels on physical projections; unsupported travel is rejected
    rather than silently dropping loads or granting reduced resistance demand.
    """
    _nominal_geometry(c)
    if region_id is not None and (not isinstance(region_id, str) or not region_id.strip()):
        raise ValueError('Region identifier must be a nonempty string when supplied')
    p = c.project
    if p.wheel_travel_scope != 'between_support_axes' or p.support_model != 'simple_forks_free_warping':
        raise ValueError('Regional shear requires the prepared support-span wheel travel model')
    if c.beam.span_m != p.span_m:
        raise ValueError('Prepared beam span does not match the project')
    c.validate_stationary_identity()
    if c != prepare_case(c.basis, c.factors, c.transverse_sign, c.longitudinal_sign):
        raise ValueError('Prepared loads or geometry changed; regenerate the complete mechanical case')
    result = _regional_shear_enclosure(span_m=p.span_m, left_mm=left_mm, right_mm=right_mm,
        moving_loads=c.source_wheels, fixed_loads=c.major_fixed,
        udl_kn_m=c.udl.vertical_kn_per_m,
        projection_lengths_mm=(p.beam_end_left_mm, p.beam_end_right_mm))
    result.update(region_id=region_id, prepared_case_signature=_prepared_bound_signature(c),
        prepared_load_state_revalidated=True,
        stationary_ledger_sha256=c.stationary_ledger_sha256,
        geometry_inputs_hash=c.geometry_inputs_hash,
        projection_wheel_travel_supported=False,
        projection_wheel_travel_rejected_not_omitted=True)
    return result
