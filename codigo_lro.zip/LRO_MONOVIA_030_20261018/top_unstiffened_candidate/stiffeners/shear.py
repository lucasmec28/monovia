"""Isolated NBR 8800 shear-panel and paired-stiffener scalar kernels.

Units are N, mm and MPa.  This module evaluates the scalar expressions of
the first-domain contract for a doubly symmetric rolled I section with a
solid web. Positive numeric inputs outside the source material limits are
still evaluated mathematically, but explicitly identified as outside that
source domain. Its results are not production credit or approval of a
station or beam.

``clear_web_depth_mm`` must come from a documented clear depth or actual
rolled-section root geometry.  Neither service spans nor restraints create
panel endpoints: a supplied panel length is the actual distance between
two adjacent transverse stiffeners.  Geometry, attachments, load paths,
weld transfer and fatigue are deliberately outside these pure kernels.
"""

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass, field
from decimal import Decimal
from math import isfinite, sqrt
from numbers import Real


SHEAR_SOURCE = (
    "ABNT NBR 8800:2024, 5.4.3.1.1-5.4.3.1.2, pp. 57-58 "
    "(source PDF pp. 79-80); material scope 4.6.2.2.1-4.6.2.2.3 and "
    "4.6.2.9; isolated first-domain contract 2026-10-17, 12:36 correction"
)
STIFFENER_SOURCE = (
    "ABNT NBR 8800:2024, 5.4.3.1.3, p. 58 "
    "(source PDF p. 80), with Er1:2025 p. 1 reciprocal correction; "
    "material scope 4.6.2.2.1-4.6.2.2.3 and 4.6.2.9; "
    "isolated first-domain contract 2026-10-17, 12:36 correction"
)
MATERIAL_DOMAIN_PENDING = (
    "documented_nominal_strength_basis_not_supplied",
    "nominal_fu_over_fy_at_least_1_15_not_evaluated",
    "structural_steel_qualification_and_material_source_not_supplied",
)


def _source_numeric_domain_violations(E_MPa: float, fy_MPa: float) -> tuple[str, ...]:
    """Known source-domain failures, distinct from missing material evidence."""
    violations = []
    if E_MPa != 200000.0:
        violations.append("E_MPa_outside_NBR_8800_value_200000")
    if fy_MPa > 450.0:
        violations.append("fy_MPa_exceeds_first_domain_nominal_limit_450")
    return tuple(violations)


def _positive_real(value: object, name: str) -> float:
    """Accept finite real numbers, not bool, strings or complex coercions."""
    if isinstance(value, bool) or not isinstance(value, (Real, Decimal)):
        raise TypeError(f"{name} must be a real number, not {type(value).__name__}")
    try:
        number = float(value)
    except (OverflowError, ValueError) as exc:
        raise ValueError(f"{name} must be finite and representable") from exc
    if not isfinite(number) or number <= 0.0:
        raise ValueError(f"{name} must be finite and strictly positive")
    return number


def _derived_positive(value: float, name: str) -> float:
    if not isfinite(value) or value <= 0.0:
        raise ValueError(f"{name} is outside the finite positive numeric domain")
    return value


@dataclass(frozen=True)
class SteelShearInput:
    """Numeric beam/material inputs, not evidence of nominal steel qualification."""

    d_mm: float
    web_thickness_mm: float
    clear_web_depth_mm: float
    E_MPa: float
    fy_MPa: float
    gamma_a1: float

    def __post_init__(self) -> None:
        for name in self.__dataclass_fields__:
            object.__setattr__(self, name, _positive_real(getattr(self, name), name))
        if self.clear_web_depth_mm >= self.d_mm:
            raise ValueError("rolled-section geometry requires d_mm > clear_web_depth_mm > 0")


@dataclass(frozen=True)
class ShearResistanceResult:
    """Prescriptive selected result plus independently visible candidate benefit.

    ``candidate_*`` assumes supplied panel endpoints become prescriptively
    eligible.  ``kv``/``VRd_N`` use that candidate only when the explicit
    prescriptive condition is true.  Neither result establishes a complete
    station, welds, fatigue or the validity of an action combination.
    """

    kv: float
    VRd_N: float
    baseline_kv: float
    baseline_VRd_N: float
    candidate_kv: float | None
    candidate_VRd_N: float | None
    candidate_benefit_N: float | None
    applied_benefit_N: float
    slenderness: float
    lambda_p: float
    lambda_r: float
    Aw_mm2: float
    Vpl_N: float
    regime: str
    panel_length_mm: float | None
    panel_aspect_ratio: float | None
    panel_stiffeners_prescriptively_eligible: bool
    panel_kv_selected: bool
    source_numeric_limits_pass: bool
    domain_violations: tuple[str, ...]
    domain_pending: tuple[str, ...] = field(default=MATERIAL_DOMAIN_PENDING, init=False)
    material_domain_evaluated: bool = field(default=False, init=False)
    source_domain_qualified: bool = field(default=False, init=False)
    complete_station_eligible: bool = field(default=False, init=False)
    production_credit_enabled: bool = field(default=False, init=False)
    source: str = field(default=SHEAR_SOURCE, init=False)
    scope: str = field(
        default=(
            "Parametric evaluation of NBR ULS shear expressions only. Source "
            "material domain is not qualified by scalar inputs: an external "
            "compositor must evaluate nominal strengths, fu/fy and documented "
            "structural steel qualification. Missing evidence is not a permanent "
            "veto; known numeric domain violations remain explicit. "
            "Prescriptive endpoint eligibility "
            "is an internal composition condition, not a UI qualification. "
            "Attachments, actual transfers, welds and fatigue remain separate."
        ),
        init=False,
    )


def _capacity(
    steel: SteelShearInput, kv: float, slenderness: float, Vpl_N: float
) -> tuple[float, float, float, str]:
    root = sqrt(_derived_positive(kv * steel.E_MPa / steel.fy_MPa, "kv E/fy"))
    lambda_p = _derived_positive(1.10 * root, "lambda_p")
    lambda_r = _derived_positive(1.37 * root, "lambda_r")
    if slenderness <= lambda_p:
        factor, regime = 1.0, "plastic"
    elif slenderness <= lambda_r:
        factor, regime = lambda_p / slenderness, "inelastic_buckling"
    else:
        factor, regime = 1.24 * (lambda_p / slenderness) ** 2, "elastic_buckling"
    VRd_N = _derived_positive(factor * (Vpl_N / steel.gamma_a1), "VRd_N")
    return VRd_N, lambda_p, lambda_r, regime


def shear_resistance(
    steel: SteelShearInput,
    *,
    panel_length_mm: float | None = None,
    panel_stiffeners_prescriptively_eligible: bool = False,
) -> ShearResistanceResult:
    """Evaluate NBR 8800 shear expressions without tension-field credit.

    With no real panel, or without prescriptively eligible endpoint
    stiffeners, selected kv is 5.34.  For an eligible real panel with
    a/h <= 3, selected kv is 5 + 5/(a/h)^2.  A supplied but unqualified
    panel still produces a clearly separated hypothetical candidate.
    Eligibility without a panel length is rejected, not given a span or
    an invented endpoint.  No ULS demand is inferred from another basis.
    """
    if not isinstance(steel, SteelShearInput):
        raise TypeError("steel must be a SteelShearInput")
    if type(panel_stiffeners_prescriptively_eligible) is not bool:
        raise TypeError("panel_stiffeners_prescriptively_eligible must be bool")
    if panel_length_mm is None and panel_stiffeners_prescriptively_eligible:
        raise ValueError("eligible panel stiffeners require a real panel_length_mm")
    a = None if panel_length_mm is None else _positive_real(panel_length_mm, "panel_length_mm")
    slenderness = _derived_positive(steel.clear_web_depth_mm / steel.web_thickness_mm, "h/tw")
    Aw_mm2 = _derived_positive(steel.d_mm * steel.web_thickness_mm, "Aw_mm2")
    Vpl_N = _derived_positive(0.60 * Aw_mm2 * steel.fy_MPa, "Vpl_N")
    baseline = _capacity(steel, 5.34, slenderness, Vpl_N)
    ratio = None if a is None else _derived_positive(a / steel.clear_web_depth_mm, "a/h")
    candidate_kv: float | None = None
    candidate: tuple[float, float, float, str] | None = None
    if ratio is not None:
        # The reciprocal form is deliberate. No tolerance moves the a/h=3 gate.
        candidate_kv = 5.34 if ratio > 3.0 else _derived_positive(5.0 + 5.0 / ratio / ratio, "candidate_kv")
        candidate = _capacity(steel, candidate_kv, slenderness, Vpl_N)
    use_panel = panel_stiffeners_prescriptively_eligible and ratio is not None and ratio <= 3.0
    selected = candidate if use_panel else baseline
    assert selected is not None
    domain_violations = _source_numeric_domain_violations(steel.E_MPa, steel.fy_MPa)
    return ShearResistanceResult(
        kv=candidate_kv if use_panel else 5.34,
        VRd_N=selected[0],
        baseline_kv=5.34,
        baseline_VRd_N=baseline[0],
        candidate_kv=candidate_kv,
        candidate_VRd_N=None if candidate is None else candidate[0],
        candidate_benefit_N=None if candidate is None else candidate[0] - baseline[0],
        applied_benefit_N=selected[0] - baseline[0],
        slenderness=slenderness,
        lambda_p=selected[1],
        lambda_r=selected[2],
        Aw_mm2=Aw_mm2,
        Vpl_N=Vpl_N,
        regime=selected[3],
        panel_length_mm=a,
        panel_aspect_ratio=ratio,
        panel_stiffeners_prescriptively_eligible=panel_stiffeners_prescriptively_eligible,
        panel_kv_selected=use_panel,
        source_numeric_limits_pass=not domain_violations,
        domain_violations=domain_violations,
    )


@dataclass(frozen=True)
class PanelInertiaRequirement:
    """One actual adjacent panel, retained even when it is not governing."""

    panel_length_mm: float
    aspect_ratio: float
    j: float
    Irequired_mm4: float


@dataclass(frozen=True)
class PairedStiffenerResult:
    """Only c/t and Is checks, excluding connection and bearing requirements."""

    Is_mm4: float
    c_over_t: float
    c_over_t_limit: float
    stockiness_pass: bool
    Irequired_mm4: float
    inertia_pass: bool
    section_rules_pass: bool
    panels: tuple[PanelInertiaRequirement, ...]
    source_numeric_limits_pass: bool
    domain_violations: tuple[str, ...]
    domain_pending: tuple[str, ...] = field(default=MATERIAL_DOMAIN_PENDING, init=False)
    material_domain_evaluated: bool = field(default=False, init=False)
    source_domain_qualified: bool = field(default=False, init=False)
    complete_station_eligible: bool = field(default=False, init=False)
    production_credit_enabled: bool = field(default=False, init=False)
    source: str = field(default=STIFFENER_SOURCE, init=False)
    scope: str = field(
        default=(
            "Paired identical full-height transverse plates, common beam/plate "
            "steel modulus E. Section-rule inequalities are mathematical only; "
            "an external compositor must evaluate nominal strengths, fu/fy and "
            "documented structural steel qualification. Missing material evidence "
            "is not a permanent veto; known numeric source-domain violations "
            "remain explicit. No attachment approval, no "
            "bearing-web strips, no bearing minima or transformed stiffness."
        ),
        init=False,
    )


def paired_stiffener_prescriptive(
    *,
    outstand_mm: float,
    plate_thickness_mm: float,
    web_thickness_mm: float,
    clear_web_depth_mm: float,
    E_MPa: float,
    fy_MPa: float,
    panel_lengths_mm: Sequence[float],
) -> PairedStiffenerResult:
    """Check an identical pair about the web midplane, excluding web strips.

    ``outstand_mm`` is each plate's projection from the web face, not
    from its midplane. ``E_MPa`` is the common beam/plate modulus;
    ``fy_MPa`` is the plate yield stress. Check every adjacent real panel,
    including a shorter last panel. Passing these scalar section rules
    alone does not establish the prescribed attachments or station safety.
    """
    c = _positive_real(outstand_mm, "outstand_mm")
    t = _positive_real(plate_thickness_mm, "plate_thickness_mm")
    tw = _positive_real(web_thickness_mm, "web_thickness_mm")
    h = _positive_real(clear_web_depth_mm, "clear_web_depth_mm")
    E = _positive_real(E_MPa, "E_MPa")
    fy = _positive_real(fy_MPa, "fy_MPa")
    if isinstance(panel_lengths_mm, (str, bytes, bytearray)) or not isinstance(panel_lengths_mm, Sequence):
        raise TypeError("panel_lengths_mm must be an ordered sequence of actual panel lengths")
    if not panel_lengths_mm:
        raise ValueError("at least one actual adjacent panel length is required")
    lengths = tuple(_positive_real(a, f"panel_lengths_mm[{i}]") for i, a in enumerate(panel_lengths_mm))
    c_over_t = _derived_positive(c / t, "c/t")
    limit = _derived_positive(0.56 * sqrt(_derived_positive(E / fy, "E/fy")), "c/t limit")
    # Exact expansion of (2t/3)[(c+tw/2)^3-(tw/2)^3], avoiding
    # cancellation for small outstands. It includes plates ONLY.
    try:
        Is = _derived_positive(2.0 * t * c * (c * c / 3.0 + c * tw / 2.0 + tw * tw / 4.0), "Is_mm4")
        requirements = []
        for a in lengths:
            ratio = _derived_positive(a / h, "a/h")
            # Er1:2025: 2.5/(a/h)^2, NOT 2.5*(a/h)^2.
            j = _derived_positive(max(0.5, 2.5 / ratio / ratio - 2.0), "j")
            required = _derived_positive(a * tw**3 * j, "Irequired_mm4")
            requirements.append(PanelInertiaRequirement(a, ratio, j, required))
    except OverflowError as exc:
        raise ValueError("derived stiffener result exceeds the finite numeric domain") from exc
    governing = max(panel.Irequired_mm4 for panel in requirements)
    stockiness_pass = c_over_t <= limit
    inertia_pass = Is >= governing
    domain_violations = _source_numeric_domain_violations(E, fy)
    return PairedStiffenerResult(
        Is_mm4=Is,
        c_over_t=c_over_t,
        c_over_t_limit=limit,
        stockiness_pass=stockiness_pass,
        Irequired_mm4=governing,
        inertia_pass=inertia_pass,
        section_rules_pass=stockiness_pass and inertia_pass,
        panels=tuple(requirements),
        source_numeric_limits_pass=not domain_violations,
        domain_violations=domain_violations,
    )
