"""Physical stationary body inventory, not a station/detail qualification.

Coordinates are x along the beam, y lateral and z upward FROM THE BASE-SECTION
CENTROID. Each body is retained individually, including symmetric cancelling
parts. Its gravity is structural G, never equipment/wheel dynamics. This module
only adapts loads to the existing analytical simple-span beam solver.
"""
from __future__ import annotations
from dataclasses import asdict, dataclass
from hashlib import sha256
import json
from math import fsum, isfinite
from typing import TypeAlias
from lro_beams.moving_beam import PointLoad

GRAVITY_M_S2 = 9.80665
COORDINATE_BASIS = 'x_from_left_support_y_lateral_z_up_from_base_section_centroid_mm'


def _real(value, name, *, positive=False, nonnegative=False):
    try:
        valid=type(value) in (int,float) and isfinite(value) and abs(value)<=1e100
    except (OverflowError,TypeError,ValueError):
        valid=False
    if not valid:
        raise ValueError(name+' must be finite numeric data')
    if positive and value<=0 or nonnegative and value<0:
        raise ValueError(name+' outside physical range')
    return value


def _text(value, name):
    if not isinstance(value, str) or not value.strip():
        raise ValueError(name+' requires a nonempty physical/source identifier')
    return value


@dataclass(frozen=True)
class StationaryBody:
    """Actual body mass and CG; z_mm is centroidal, NOT bottom-datum height."""
    id: str
    x_mm: float
    y_mm: float
    z_mm: float
    mass_kg: float
    source: str

    def __post_init__(self):
        self.validate()

    def validate(self):
        _text(self.id, 'Body id'); _text(self.source, 'Body source')
        for name in ('x_mm', 'y_mm', 'z_mm'):
            _real(getattr(self, name), name)
        _real(self.mass_kg, 'Body mass', positive=True)
        return self


StationaryLedger: TypeAlias = tuple[StationaryBody, ...]


def validate_stationary_ledger(ledger: StationaryLedger, *, span_mm=None) -> StationaryLedger:
    """No dict/list coercion, duplicate identities, fake zero mass or tail CG."""
    if type(ledger) is not tuple or any(type(body) is not StationaryBody for body in ledger):
        raise ValueError('A tuple of typed StationaryBody records is required')
    if span_mm is not None:
        _real(span_mm, 'Span', positive=True)
    ids=set()
    for body in ledger:
        body.validate()
        if body.id in ids:
            raise ValueError('Duplicate stationary body id: '+body.id)
        ids.add(body.id)
        if span_mm is not None and not 0<=body.x_mm<=span_mm:
            raise ValueError('Stationary body CG outside support span; physical tail bodies unsupported')
    return ledger


def stationary_ledger_hash(ledger: StationaryLedger) -> str:
    validate_stationary_ledger(ledger)
    payload=dict(coordinate_basis=COORDINATE_BASIS, bodies=[asdict(body) for body in ledger])
    return sha256(json.dumps(payload,sort_keys=True,separators=(',', ':'),allow_nan=False).encode()).hexdigest()


def body_vertical_kn(body: StationaryBody, dead_support: float) -> float:
    body.validate(); _real(dead_support,'Structural G factor',nonnegative=True)
    return _real(body.mass_kg*GRAVITY_M_S2/1000*dead_support,'Factored body gravity',nonnegative=True)


def stationary_point_loads(ledger: StationaryLedger, *, span_mm: float, h_mm: float,
                           dead_support: float) -> tuple[tuple[PointLoad, ...], tuple[PointLoad, ...], tuple[PointLoad, ...]]:
    """Actual P at each CG x and its single nominal Ft=P*y/h, Fb=-Ft pair.

    No wheel eccentricity, rail height or DLF/HLF/IFD/SK enters this conversion.
    Zero factored G retains zero PointLoads and the original positive-mass body.
    """
    validate_stationary_ledger(ledger,span_mm=span_mm)
    _real(h_mm,'Flange-centroid separation',positive=True)
    _real(dead_support,'Structural G factor',nonnegative=True)
    major=[]; top=[]; bottom=[]
    for body in ledger:
        P=body_vertical_kn(body,dead_support); lateral=P*body.y_mm/h_mm
        x=body.x_mm/1000; name='Physical stationary G: '+body.id
        major.append(PointLoad(x,P,name=name))
        top.append(PointLoad(x,0.,horizontal_kn=lateral,name=name))
        bottom.append(PointLoad(x,0.,horizontal_kn=-lateral,name=name))
    return tuple(major),tuple(top),tuple(bottom)


def stationary_destabilizing_radius_nmm(ledger: StationaryLedger, dead_support: float) -> float:
    """Conservative adverse-only sum max(0, P_N*z_CG_mm), body by body."""
    validate_stationary_ledger(ledger)
    _real(dead_support,'Structural G factor',nonnegative=True)
    return fsum(max(0.,body_vertical_kn(body,dead_support)*1000*body.z_mm) for body in ledger)
