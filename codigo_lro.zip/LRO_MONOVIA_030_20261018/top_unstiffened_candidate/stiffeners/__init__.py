"""Isolated physical TOP intermediate-stiffener candidate."""
