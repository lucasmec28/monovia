"""Physical intermediate lines partition the nominal scope, not the travel.

This geometric inventory grants no panel resistance or station qualification.
Forks are not transverse plates. In particular the two exterior regions have
no invented NBR10084 stiffener spacing. Distances use millimetres; a station
belongs to both adjoining regions, never silently to the more favourable one.
"""
from __future__ import annotations

from dataclasses import dataclass
from math import isfinite


def _coordinate(value, name):
    if type(value) not in (int, float) or not isfinite(value):
        raise ValueError(name + ' must be finite numeric data')
    return float(value)


@dataclass(frozen=True)
class StationLine:
    station_id: str
    x_mm: float

    def __post_init__(self):
        if type(self.station_id) is not str or not self.station_id.strip():
            raise ValueError('Physical station identifier is required')
        object.__setattr__(self, 'x_mm', _coordinate(self.x_mm, 'Station coordinate'))


@dataclass(frozen=True)
class NominalRegion:
    region_id: str
    left_mm: float
    right_mm: float
    left_station_id: str | None
    right_station_id: str | None
    method: str
    physical_panel_spacing_mm: float | None

    @property
    def geometry_only(self):
        return True


@dataclass(frozen=True)
class RegionInventory:
    span_mm: float
    stations: tuple[StationLine, ...]

    def __post_init__(self):
        span = _coordinate(self.span_mm, 'Span')
        if span <= 0:
            raise ValueError('Positive span required')
        if type(self.stations) is not tuple or not self.stations:
            raise ValueError('Nonempty tuple of physical station lines required')
        if any(type(s) is not StationLine for s in self.stations):
            raise ValueError('Typed physical station lines required')
        if len({s.station_id for s in self.stations}) != len(self.stations):
            raise ValueError('Duplicate physical station identity')
        xs = [s.x_mm for s in self.stations]
        if xs != sorted(xs) or len(set(xs)) != len(xs):
            raise ValueError('Station coordinates must be unique and increasing')
        if not all(0 < x < span for x in xs):
            raise ValueError('Intermediate stations must lie strictly inside the support span')
        object.__setattr__(self, 'span_mm', span)

    def regions(self):
        boundaries = (0., *(s.x_mm for s in self.stations), self.span_mm)
        ids = (None, *(s.station_id for s in self.stations), None)
        rows = []
        for i, (left, right) in enumerate(zip(boundaries, boundaries[1:])):
            panel = ids[i] is not None and ids[i + 1] is not None
            rows.append(NominalRegion(
                f'R{i + 1}', left, right, ids[i], ids[i + 1],
                'physical_panel_geometry_only' if panel else 'ordinary_end_region_no_panel_credit',
                right - left if panel else None))
        return tuple(rows)

    def at(self, x_mm):
        """Both adjoining scopes at a physical station; full span retained."""
        x = _coordinate(x_mm, 'Evaluation coordinate')
        if not 0 <= x <= self.span_mm:
            raise ValueError('Region lookup is restricted to the actual support span')
        return tuple(r for r in self.regions() if r.left_mm <= x <= r.right_mm)

    def adjacent_panels(self, station_id):
        if station_id not in {s.station_id for s in self.stations}:
            raise ValueError('Unknown physical station identity')
        return tuple(r for r in self.regions()
                     if r.physical_panel_spacing_mm is not None
                     and station_id in (r.left_station_id, r.right_station_id))

    def wheel_entry_exit_range_mm(self, wheel_offsets_mm):
        """Exactly the unmodified full-passage domain; no stiffener clipping."""
        if type(wheel_offsets_mm) is not tuple or not wheel_offsets_mm:
            raise ValueError('Nonempty tuple of wheel offsets required')
        offsets = tuple(_coordinate(x, 'Wheel offset') for x in wheel_offsets_mm)
        return -max(offsets), self.span_mm - min(offsets)

