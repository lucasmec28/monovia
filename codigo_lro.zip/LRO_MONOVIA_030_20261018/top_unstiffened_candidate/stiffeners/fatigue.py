"""Directional nominal fatigue at adopted TOP intermediate-stiffener details.

This isolated consumer classifies a RECEIVER, not a weld throat. It neither
produces stresses nor reconstructs a moving-load history. The trusted producer
must establish the same fixed material point/face/region and all six nominal
components under NBR 8400 fatigue Case I. A source string is traceability, not
verification of that mechanics. Fabrication records below are specifications,
never evidence that a weld has actually been executed or inspected.

The original plain-rolled W0 consumer is not called or relaxed. Only its public
material/duty/method types and exact signed-box D.5 mathematics are reused.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from math import isfinite, sqrt
from typing import Mapping

from lro_beams.autonomous_fatigue import elastic_allowables_autonomous
from lro_beams.stress_8400 import (
    HIGH_GRADES, K0_MPA, LOW_GRADES, W0_HIGH_MPA, W0_LOW_MPA,
)
from underslung_runway_candidate.fatigue.nbr_member import (
    ACTION_BASIS, COMPONENTS, KAPPA_POLICY, SOURCE, SOURCE_SHA256,
    NBRFatigueDuty, NBRFatigueMaterial, NBRFatigueMethod, NBRNominalPlane,
    d5_interval_bound,
)

K1_MPA = (323.1, 262.3, 212.9, 172.8, 140.3, 113.8, 92.4, 75.0)
K3_MPA = (193.1, 157.4, 127.7, 103.7, 84.2, 68.3, 55.4, 45.0)
STRAIGHT = 'straight_vertical_toe'
LOWER_TERMINATION = 'lower_fillet_termination'
UPPER_TERMINATION = 'upper_fillet_termination'
CJP_FLANGE = 'cjp_flange_receiver'
SOURCE_CONTRACT = dict(
    standard=SOURCE, primary_pdf_sha256=SOURCE_SHA256,
    capacities='Table D.1, printed p.60 / PDF71; kappa=-1; no repeated 4/3 factor',
    web_perpendicular='Table D.5, K3,21, printed p.74 / PDF86',
    web_straight_parallel='Table D.5, K0,31, printed p.69 / PDF81',
    web_termination_parallel='Table D.5, K3,35, printed p.75 / PDF87; Table D.3, p.67 / PDF79',
    cjp_flange_perpendicular='Table D.5, K1,2, printed p.70 / PDF82; K preparation, QE',
    base_shear='D.2.2, printed p.62 / PDF73-74; material-family W0/sqrt(3), not throat shear',
    interaction='D.2.3, Eq. D.5, printed pp.62-63 / PDF74-75; strict Q <= 1',
    static_075_factor='NBR10084 9.1.3.4 is a static combination; this fatigue consumer applies no 0.75 reduction',
    strict_limit=1., relaxed_1_05_limit_used=False,
)


@dataclass(frozen=True)
class NBRStiffenerFatigueIdentity:
    station_id: str
    plate_side: str
    weld_line_id: str
    receiver_material_id: str
    region_id: str
    point_id: str
    face: str
    geometry_weld_hash: str


@dataclass(frozen=True)
class NBRStiffenerTerminationQuality:
    """Specified conditions for BOTH ends of this continuous vertical fillet."""
    stiffener_thickness_mm: float
    end_quality_lengths_mm: tuple[float, float]  # lower, upper; each >= 10 ts
    end_quality_specification: str              # QE
    termination_finish: str                    # ground_without_notches
    upper_termination_configuration: str       # separated_from_cjp_by_unwelded_cutout
    quality_source: str
    end_zone_toe_finish: str = 'not_specified'
    effective_weld_geometry: str = 'not_specified'


@dataclass(frozen=True)
class NBRStiffenerCJPQuality:
    """K/QE design specification, not an as-built inspection certificate."""
    preparation: str
    penetration: str
    root_treatment: str
    toe_finish: str
    lamination_check: str
    minimum_reinforcement_mm: float
    permanent_backing: bool
    tensile_end_treatment: str
    inspection: str
    procedure_source: str
    prescriptive_local_connection_source: str
    additional_cyclic_transfer: str


@dataclass(frozen=True)
class NBRStiffenerFatigueDetail:
    identity: NBRStiffenerFatigueIdentity
    location: str
    receiver_material: NBRFatigueMaterial
    construction_detail: str
    evaluation_location: str
    weld_axis: str
    quality_specification: str
    detail_source: str
    fabrication_source: str
    lamination_check_source: str
    termination_quality: NBRStiffenerTerminationQuality | None = None
    cjp_quality: NBRStiffenerCJPQuality | None = None


@dataclass(frozen=True)
class NBRStiffenerNominalPlane:
    """A fixed point or a proven uniform region, not extrema across faces.

The nested NBRNominalPlane carries six components, action/model/factor sources,
and the nominal-zero justification. Coordinates are global member x/y/z in mm.
Region bounds identify spatial coverage; their source must prove interior as
well as boundary coverage. This consumer cannot verify that upstream proof.
"""
    identity: NBRStiffenerFatigueIdentity
    nominal_plane: NBRNominalPlane
    coverage_kind: str                         # fixed_point or verified_region_bound
    coverage_source: str
    nominal_field_kind: str                    # same_point_global_plus_local or cisc_longitudinal_flange
    coordinates_mm: tuple[float, float, float] | None = None
    region_bounds_mm: tuple[tuple[float, float], ...] | None = None


@dataclass(frozen=True)
class NBRStiffenerFatigueCase:
    plane: NBRStiffenerNominalPlane
    material: NBRFatigueMaterial
    duty: NBRFatigueDuty
    detail: NBRStiffenerFatigueDetail
    method: NBRFatigueMethod


def _real(value, name, *, positive=False):
    try:
        valid = (type(value) in (int, float) and abs(value) <= 1e100 and isfinite(value))
    except (OverflowError, ValueError, TypeError):
        valid = False
    if not valid or positive and value <= 0.:
        raise ValueError(name + ' requires a finite ' + ('positive ' if positive else '') + 'real value')
    return float(value)


def _text(value, name):
    if type(value) is not str or not value.strip():
        raise ValueError(name + ' requires an explicit physical/source record')
    return value


def _interval(value, name):
    if type(value) not in (tuple, list) or len(value) != 2:
        raise ValueError(name + ' requires two signed interval endpoints')
    lo, hi = (_real(v, name) for v in value)
    if lo > hi:
        raise ValueError(name + ' interval is reversed')
    return lo, hi


def _typed(value, cls):
    if type(value) is not cls:
        raise ValueError(cls.__name__ + ' required')


def _identity(identity):
    _typed(identity, NBRStiffenerFatigueIdentity)
    for key, value in asdict(identity).items():
        _text(value, key)
    digest = identity.geometry_weld_hash
    if len(digest) != 64 or any(c not in '0123456789abcdef' for c in digest):
        raise ValueError('geometry_weld_hash requires a lowercase SHA-256 digest')


def _material(material):
    _typed(material, NBRFatigueMaterial)
    fy = _real(material.fy_mpa, 'fy', positive=True)
    fu = _real(material.fu_mpa, 'fu', positive=True)
    _real(material.thickness_mm, 'physical receiving-material thickness', positive=True)
    _text(material.material_grade, 'material_grade')
    _text(material.material_source, 'material_source')
    if fy > fu:
        raise ValueError('fy cannot exceed fu')
    return fy, fu


def _context(material, duty, method):
    """Validate independently; do not impersonate W0 to obtain capacities."""
    fy, fu = _material(material)
    _typed(duty, NBRFatigueDuty)
    _typed(method, NBRFatigueMethod)
    for obj in (duty, method):
        for key, value in asdict(obj).items():
            _text(value, key)
    pending = []
    if material.material_grade not in LOW_GRADES + HIGH_GRADES or not 370. <= fu <= 520.:
        pending.append('Table D.1/5.6.5 requires S235/S275/ASTM A36/S355/ASTM A572 GR50 and 370 <= fu <= 520 MPa; no inferred equivalence')
    if duty.component_group not in tuple('E' + str(i) for i in range(1, 9)):
        pending.append('Explicit sourced COMPONENT group E1-E8 required; no default E8 or CMAA/equipment/mechanism conversion')
    if duty.classification_kind not in ('documented_component_classification', 'adopted_conservative_E8', 'manual_code_selection'):
        pending.append('A documented component classification, manual code selection, or explicit conservative E8 adoption is required')
    if duty.classification_kind == 'adopted_conservative_E8' and duty.component_group != 'E8':
        pending.append('Conservative unclassified group adoption applies only to explicitly selected E8')
    if method.kappa_policy != KAPPA_POLICY:
        pending.append('Explicit kappa=-1 resistance adoption required; positive-kappa D.3 is not implemented')
    return fy, fu, pending


def _detail(detail, material):
    _typed(detail, NBRStiffenerFatigueDetail)
    _identity(detail.identity)
    _material(detail.receiver_material)
    for key in ('location', 'construction_detail', 'evaluation_location', 'weld_axis',
                'quality_specification', 'detail_source', 'fabrication_source', 'lamination_check_source'):
        _text(getattr(detail, key), key)
    pending = []
    if detail.receiver_material != material:
        pending.append('Capacity material, thickness and source must exactly match this receiving material, not the stiffener or weld')
    term = detail.termination_quality
    if term is not None:
        _typed(term, NBRStiffenerTerminationQuality)
        ts = _real(term.stiffener_thickness_mm, 'stiffener thickness', positive=True)
        if type(term.end_quality_lengths_mm) is not tuple or len(term.end_quality_lengths_mm) != 2:
            raise ValueError('Both lower/upper end quality lengths must be declared')
        lengths = tuple(_real(x, 'end quality length', positive=True) for x in term.end_quality_lengths_mm)
        for key in ('end_quality_specification', 'termination_finish', 'upper_termination_configuration',
                    'quality_source', 'end_zone_toe_finish', 'effective_weld_geometry'):
            _text(getattr(term, key), key)
    cjp = detail.cjp_quality
    if cjp is not None:
        _typed(cjp, NBRStiffenerCJPQuality)
        _real(cjp.minimum_reinforcement_mm, 'CJP reinforcement', positive=True)
        if type(cjp.permanent_backing) is not bool:
            raise ValueError('CJP permanent_backing must be a boolean specification')
        for key, value in asdict(cjp).items():
            if key not in ('minimum_reinforcement_mm', 'permanent_backing'):
                _text(value, key)

    if detail.location in (STRAIGHT, LOWER_TERMINATION, UPPER_TERMINATION):
        if (detail.construction_detail != 'continuous_vertical_fillet_to_web'
                or detail.evaluation_location != 'web_base_material' or detail.weld_axis != 'z'):
            pending.append('Vertical continuous fillet, weld axis z and web RECEIVER base material required; this is not a throat check')
        if detail.quality_specification not in ('QC', 'QE'):
            pending.append('Specified QC (or QE) fabrication quality required for the vertical fillet')
        if detail.location == STRAIGHT:
            return dict(plane='xz', components=('sx', 'sz', 'txz'), normal_x_code='K3,21',
                        normal_y_code='K0,31', normal_x_table=K3_MPA, normal_y_table=K0_MPA), pending
        if term is None:
            pending.append('Both vertical-fillet terminations require a sourced K3,35 end-quality specification')
        else:
            if any(length < 10. * ts for length in lengths):
                pending.append('K3,35 requires QE over the final 10*ts at EACH end of the vertical fillet')
            if term.end_quality_specification != 'QE' or term.termination_finish != 'ground_without_notches':
                pending.append('K3,35 requires QE end quality and ground terminations without notches')
            if term.end_zone_toe_finish != 'without_undercuts_ground_where_needed':
                pending.append('QE requires the complete end-quality zones to have toes without undercuts, ground where needed')
            if term.effective_weld_geometry != 'required_throat_and_length_preserved_after_finishing':
                pending.append('Termination finishing must preserve the required effective weld throat and length')
            if term.upper_termination_configuration != 'separated_from_cjp_by_unwelded_cutout':
                pending.append('Upper vertical-fillet termination must remain separated from CJP by an unwelded cutout, without crossing or following its arc')
        return dict(plane='xz', components=('sx', 'sz', 'txz'), normal_x_code='K3,21',
                    normal_y_code='K3,35', normal_x_table=K3_MPA, normal_y_table=K3_MPA), pending

    if detail.location == CJP_FLANGE:
        if (detail.construction_detail != 'K_prepared_CJP_stiffener_to_top_flange'
                or detail.evaluation_location != 'top_flange_base_material' or detail.weld_axis != 'y'):
            pending.append('K-prepared CJP along y and top-flange RECEIVER base material required; a larger fillet is not CJP')
        if detail.quality_specification != 'QE':
            pending.append('K1,2 requires specified QE weld quality')
        if cjp is None:
            pending.append('K1,2 requires its complete K/QE CJP specification and prescriptive local-connection scope')
        else:
            expected = dict(
                preparation='double_bevel_K', penetration='complete_joint_penetration',
                root_treatment='root_removed_before_back_weld', toe_finish='ground_without_undercuts',
                lamination_check='specified_absence_of_lamellar_defects_in_tension',
                tensile_end_treatment='run_on_off_removed_and_ground_if_tensile',
                inspection='UT_or_RT_fatigue_acceptance',
                additional_cyclic_transfer='absent_in_exclusively_prescriptive_stabilizer',
            )
            for key, expected_value in expected.items():
                if getattr(cjp, key) != expected_value:
                    pending.append('CJP K1,2 specification missing or outside scope: ' + key)
            if cjp.minimum_reinforcement_mm < 6. or cjp.permanent_backing:
                pending.append('Adopted CJP requires reinforcement >= 6 mm and no permanent backing')
        return dict(plane='xy', components=('sx', 'sy', 'txy'), normal_x_code='K1,2',
                    normal_y_code=None, normal_x_table=K1_MPA, normal_y_table=None), pending

    pending.append('Unsupported fatigue receiver region: ' + detail.location + '; no automatic class for cutout, crossing, stiffener body or weld throat')
    return None, pending


def _capacity(material, duty, method, fy, fu, classification):
    elastic = elastic_allowables_autonomous(fy, fu, 'I')
    index = int(duty.component_group[1:]) - 1
    sxw = classification['normal_x_table'][index]
    syw = None if classification['normal_y_table'] is None else classification['normal_y_table'][index]
    w0 = (W0_LOW_MPA if material.material_grade in LOW_GRADES else W0_HIGH_MPA)[index]
    ax = min(sxw, .75 * fu, elastic['sigma_a_mpa'])
    ay = None if syw is None else min(syw, .75 * fu, elastic['sigma_a_mpa'])
    shear = min(w0 / sqrt(3), .75 * fu / sqrt(3), elastic['tau_a_mpa'])
    for value, name in ((ax, 'normal x capacity'), (shear, 'base-material shear capacity')):
        _real(value, name, positive=True)
    if ay is not None:
        _real(ay, 'normal y capacity', positive=True)
    return dict(normal_x_capacity_mpa=ax, normal_y_capacity_mpa=ay, shear_capacity_mpa=shear,
        table_normal_x_mpa=sxw, table_normal_y_mpa=syw, table_W0_mpa=w0,
        normal_x_detail=classification['normal_x_code'], normal_y_detail=classification['normal_y_code'],
        shear_detail='W0_material_family_divided_by_sqrt3_BASE_MATERIAL',
        elastic_case_i=elastic, rupture_normal_cap_mpa=.75 * fu,
        rupture_shear_cap_mpa=.75 * fu / sqrt(3), receiver_material=asdict(material),
        adopted_resistance_kappa=-1., actual_history_kappa=None,
        component_group=duty.component_group, classification_kind=duty.classification_kind,
        actual_component_classification=duty.classification_kind == 'documented_component_classification',
        project_group_adopted=duty.classification_kind == 'manual_code_selection',
        classification_derived_from_history=False, group_source=duty.classification_source,
        method_adoption_source=method.adoption_source,
        fatigue_factor_4_over_3_applied_again=False, exact_positive_kappa_equation_used=False,
        capacity_policy='Each directional table capped by 0.75fu and Case-I elastic; shear uses material-family W0/sqrt(3)',
        no_parallel_detail_class_claimed=ay is None)


def _base_result(kind='NBR8400_2_directional_stiffener_receiver_nominal_fatigue'):
    return dict(kind=kind, status='APPLICABILITY_PENDING', input_valid=True, errors=[], pending=[],
        source_contract=dict(SOURCE_CONTRACT), isolated_plane_result=True,
        sufficient_planar_bound_satisfied=False, qualified_nominal_detail_modes=False,
        actual_failure_proven=False, whole_member_qualified=False, whole_station_qualified=False,
        whole_design_complete=False, physical_unlimited_life_claim=False,
        calculated_cycles_to_failure=False, zero_damage_cutoff_used=False,
        uses_fabricated_history=False, concurrent_tensor_claimed=False,
        uses_hypot_3d=False, weld_throat_fatigue_verified=False,
        mechanical_evidence_verified_by_this_consumer=False, as_built_execution_verified=False,
        fabrication_record_kind='design_specification_not_as_built',
        static_075_factor_applied_to_fatigue=False, criterion_exceedances=[])


def evaluate_stiffener_nominal_plane(plane, *, material, duty, detail, method):
    """Return an isolated conditional bound, never whole-station acceptance."""
    result = _base_result()
    try:
        _typed(plane, NBRStiffenerNominalPlane)
        _identity(plane.identity)
        nominal = plane.nominal_plane
        _typed(nominal, NBRNominalPlane)
        for key, value in asdict(nominal).items():
            if key != 'tensor_intervals_mpa':
                _text(value, key)
        for key in ('coverage_kind', 'coverage_source', 'nominal_field_kind'):
            _text(getattr(plane, key), key)
        if plane.coverage_kind == 'fixed_point':
            if type(plane.coordinates_mm) is not tuple or len(plane.coordinates_mm) != 3 or plane.region_bounds_mm is not None:
                raise ValueError('A fixed point requires exactly three coordinates and no regional bounds')
            tuple(_real(v, 'material-point coordinate') for v in plane.coordinates_mm)
        elif plane.coverage_kind == 'verified_region_bound':
            if type(plane.region_bounds_mm) is not tuple or len(plane.region_bounds_mm) != 3 or plane.coordinates_mm is not None:
                raise ValueError('A regional bound requires three spatial intervals and no single-point coordinates')
            tuple(_interval(v, 'spatial regional bound') for v in plane.region_bounds_mm)
        else:
            result['pending'].append('Only fixed-point or sourced uniform-region coverage is supported; finite samples do not prove intervening coverage')
        for key in ('point_id', 'region_id', 'face'):
            if getattr(plane.identity, key) != getattr(nominal, key):
                result['pending'].append('Physical identity differs from nested nominal field: ' + key)
        if not isinstance(nominal.tensor_intervals_mpa, Mapping):
            raise ValueError('All six nominal tensor components must be explicitly mapped')
        unknown = set(nominal.tensor_intervals_mpa) - set(COMPONENTS)
        if unknown:
            raise ValueError('Unknown tensor component keys: ' + repr(tuple(unknown)))
        tensor = {}
        for key in COMPONENTS:
            value = nominal.tensor_intervals_mpa.get(key)
            if value is None:
                result['pending'].append('Unresolved nominal tensor component ' + key + ' is not zero')
            else:
                tensor[key] = _interval(value, key)
        if nominal.action_basis != ACTION_BASIS:
            result['pending'].append('Fatigue Case I without Mx or omega required; CMAA/ULS actions cannot be relabeled')

        fy, fu, pending = _context(material, duty, method)
        result['pending'].extend(pending)
        classification, pending = _detail(detail, material)
        result['pending'].extend(pending)
        if detail.identity != plane.identity:
            result['pending'].append('Detail and nominal field must share exact station/side/weld/receiver/region/point/face/geometry identity')
        if classification is not None:
            if nominal.plane != classification['plane']:
                result['pending'].append('Receiver plane or weld-relative directions do not match the classified detail')
            outside = {key: value for key, value in tensor.items()
                       if key not in classification['components'] and value != (0., 0.)}
            if outside:
                result['pending'].append('Nonzero out-of-plane nominal components cannot be omitted: ' + ', '.join(sorted(outside)))
                result['out_of_plane_intervals_mpa'] = outside
            if detail.location == CJP_FLANGE:
                if plane.nominal_field_kind != 'cisc_longitudinal_flange' or tensor.get('sy') != (0., 0.):
                    result['pending'].append('CJP K1,2 branch requires explicit sy=(0,0) from the sourced CISC longitudinal nominal field; nonzero parallel normal needs its own class')
            elif plane.nominal_field_kind != 'same_point_global_plus_local':
                result['pending'].append('Web nominal field must cover applicable global plus local/secondary contributions at the same point')
        result['input'] = dict(plane=asdict(plane), material=asdict(material), duty=asdict(duty),
                               detail=asdict(detail), method=asdict(method))
        result['coverage'] = dict(identity=asdict(plane.identity), kind=plane.coverage_kind,
                                  source=plane.coverage_source, whole_trajectory_coverage_verified=False)
        if result['pending']:
            return result

        capacity = _capacity(material, duty, method, fy, fu, classification)
        # CJP has NO claimed parallel-normal class. Its explicitly zero sy makes
        # the second normalization inactive, so use Ax only as a denominator for
        # that zero; never turn this into an allowable for nonzero sy.
        ay = capacity['normal_y_capacity_mpa']
        bound = d5_interval_bound(*(tensor[key] for key in classification['components']),
            normal_x_capacity_mpa=capacity['normal_x_capacity_mpa'],
            normal_y_capacity_mpa=capacity['normal_x_capacity_mpa'] if ay is None else ay,
            shear_capacity_mpa=capacity['shear_capacity_mpa'])
        if ay is None:
            bound.update(inactive_parallel_normal_normalization_only=True,
                         inactive_parallel_normal_denominator_mpa=capacity['normal_x_capacity_mpa'],
                         effective_formula='Q=(sx/A_K1)^2+(txy/Tbase)^2; sy is explicitly nominal zero',
                         parallel_normal_capacity_claimed=False)
            # Do not expose the auxiliary denominator as a parallel capacity to
            # downstream reporting or consumers: that direction is unclassified.
            bound['capacities_mpa']['sigma_y'] = None
        passed = bound['sufficient_bound_satisfied']
        result.update(capacity=capacity, bound=bound,
            planar_components=dict(zip(('sigma_x', 'sigma_y', 'tau_xy'), classification['components'])),
            status='SUFFICIENT_PLANAR_NOMINAL_FATIGUE_BOUND_SATISFIED' if passed else 'INCONCLUSIVE_SUFFICIENT_FATIGUE_BOUND',
            sufficient_planar_bound_satisfied=passed, qualified_nominal_detail_modes=passed,
            classification_applicable=True,
            scope='Only this supplied nominal receiver point/face/plane or proven region; station inventory and mechanics remain independent',
            limitations=[
                'The eight box vertices are relaxation witnesses, not actual concurrent stress states.',
                'Exceeding a sufficient bound does not prove physical fatigue failure.',
                'No physical three-dimensional tensor, weld throat, fatigue life or whole station is verified.',
                'Sources and fabrication requirements are specifications; upstream mechanics and as-built quality are not verified here.',
                'No 0.75 reduction, dynamic factor, Mx, omega or extra 4/3 factor is applied by this consumer.',
            ])
        if detail.location == CJP_FLANGE:
            result['local_connection_modes'] = dict(status='covered_by_prescriptive_detail',
                source=detail.cjp_quality.prescriptive_local_connection_source,
                function='exclusive_intermediate_stabilization', stress_is_zero_claimed=False,
                numerically_verified=False)
        result['criterion_exceedances'] = [key for key, value in bound['component_utilizations'].items() if value > 1.]
        if bound['Q_upper_bound'] > 1.:
            result['criterion_exceedances'].append('D.5_interaction')
        return result
    except (ValueError, TypeError, ArithmeticError, KeyError) as exc:
        result.update(status='INVALID_INPUT', input_valid=False, errors=[type(exc).__name__ + ': ' + str(exc)])
        return result


def evaluate_stiffener_nominal_inventory(cases):
    """Evaluate each supplied trajectory independently, retaining every result.

    This is an inventory of isolated results, NOT the all-regions compositor.
    A pending/invalid point never erases another point's known bound exceedance.
    """
    result = _base_result('NBR8400_2_isolated_stiffener_fatigue_inventory')
    result.update(isolated_plane_result=False, isolated_plane_inventory=True, results=[],
                  any_sufficient_bound_exceeded=False, all_supplied_bounds_satisfied=False)
    if type(cases) not in (tuple, list) or not cases:
        result.update(status='INVALID_INPUT', input_valid=False, errors=['Nonempty typed fatigue-case inventory required'])
        return result
    seen = set()
    for index, case in enumerate(cases):
        if type(case) is not NBRStiffenerFatigueCase:
            row = _base_result()
            row.update(status='INVALID_INPUT', input_valid=False, errors=['NBRStiffenerFatigueCase required'])
        else:
            row = evaluate_stiffener_nominal_plane(case.plane, material=case.material, duty=case.duty,
                                                  detail=case.detail, method=case.method)
            if row['input_valid']:
                identity = tuple(asdict(case.plane.identity).values())
                if identity in seen:
                    result['pending'].append('Duplicate physical nominal identity at inventory index ' + str(index))
                seen.add(identity)
        result['results'].append(row)
        result['criterion_exceedances'].extend(dict(case_index=index, criterion=criterion)
                                               for criterion in row['criterion_exceedances'])
        result['errors'].extend('case ' + str(index) + ': ' + error for error in row['errors'])
        result['pending'].extend('case ' + str(index) + ': ' + pending for pending in row['pending'])
    result['input_valid'] = all(row['input_valid'] for row in result['results'])
    result['any_sufficient_bound_exceeded'] = bool(result['criterion_exceedances'])
    result['all_supplied_bounds_satisfied'] = all(row['sufficient_planar_bound_satisfied'] for row in result['results']) and not result['pending']
    if not result['input_valid']:
        result['status'] = 'INVALID_INPUT'
    elif result['any_sufficient_bound_exceeded']:
        result['status'] = 'INCONCLUSIVE_SUFFICIENT_FATIGUE_BOUND'
    elif result['pending']:
        result['status'] = 'APPLICABILITY_PENDING'
    else:
        result['status'] = 'ALL_SUPPLIED_ISOLATED_PLANAR_BOUNDS_SATISFIED'
    return result
