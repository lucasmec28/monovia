"""Classical nominal mixed CJP/fillet group for the physical TOP stabilizer G.

Coordinates: x longitudinal, y transverse, z upward from the bottom flange.
A group is the two real vertical web-fillet root lines plus the real horizontal
CJP line, projected into the plate y-z plane. Mx is normal to THIS plane, not
torsion of the web x-z face. The +/-x fillets are separate interfaces; their
projection is legitimate only for this symmetric, planar G load system.

Small displacements, nominally rigid connected parts and a common isotropic
specific traction stiffness on effective area are assumed. Thus t=k(U+theta
cross r), and k cancels in equilibrium. This is a CLASSICAL GROUP IDEALIZATION,
not measured E/G stiffness, springs, a shell solution, directional weld gain,
or a proof that an arbitrary real connection has this stiffness. Normal and
shear demands are resolved on the actual interfaces AFTER this allocation.

NBR 8800:2024 6.2.3 admits mixed weld types; 6.2.2 supplies effective areas;
Table 9 supplies separate unit-length resistances. No CJP-as-fillet conversion.
The additional 45 kN is ONCE PER PHYSICAL PLATE CONNECTION, in the gravity
sense and, conservatively, on the same force line. It replaces G locally,
never adds mass/global load or fatigue range. All physical mass comes from
unchanged detail.stationary_mass_ledger, including preparation/refill bodies.

Explicit component and sufficient-section checks do not qualify a station.
Unmodelled mechanisms, exceeded computed sufficient checks and missing input
are DIFFERENT outcomes. Concurrent member stresses and the finite mechanisms
listed in each result must be closed by the route compositor, not by a generic
requirement for a 3-D stress solution.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, field, replace
from hashlib import sha256
import json
from math import fsum, hypot, isclose, isfinite, pi, sqrt
from pathlib import Path

from lro_beams.autonomous_resistance import reduction_chi
from lro_beams.autonomous_local import rectangle_torsion_constant, RECTANGLE_SOURCE

from .detail import IntermediateLayout, _physical, assess_detail, stationary_mass_ledger
from .loads import GRAVITY_M_S2
from .prescriptive import _validate_material_identity

SCHEMA = 'TOP_INTERMEDIATE_MIXED_SELFWEIGHT_V1'
FROZEN_DETAIL_SHA256 = '8b52173131e896d243d6ee62bf778c6026e44a4d8c58c4ca738465d4a25d3fc5'
MINIMUM_CONNECTION_FORCE_N = 45000.
GAMMA_A1, GAMMA_A2, GAMMA_W2 = 1.1, 1.35, 1.35
SOURCES = (
    'NBR 8800:2024 6.1.1.2/.3, 6.1.5.2, 6.2.2/.3 and Table 9',
    'NBR 8800:2024 6.5.1/.3/.4/.5/.6; 5.4 and Annex D for actual rectangular strips',
    'AISC Steel Interchange May 2011, Larry S. Muir PJP elastic method; corroboration of classical method only, not this orthogonal mixed geometry or AISC resistance factors',
)
GROUP_ASSUMPTION = (
    'Rigid nominal connected parts; small displacement; equal isotropic traction stiffness '
    'per unit effective area in physical y-z coordinates; stiffness multiplier cancels; '
    'no actual E/G stiffness or deformation prediction and no directional enhancement.'
)
UNRESOLVED_MODE_IDS = ('concurrent_member_local_static',)
MECHANISM_PENDING = (
    'Same-point interaction remains for web-footprint sigma_yy/tau_yz plus member sigma_xx/sigma_zz/tau_xz, and CJP/plate/flange normal-shear stresses; component-only checks here do not claim that interaction.',
)


def _number(value, name, *, positive=False, nonnegative=False):
    if type(value) not in (int, float) or not isfinite(value) or abs(value) > 1e50:
        raise ValueError(name+' must be a finite real physical value')
    value = float(value)
    if positive and value <= 0 or nonnegative and value < 0:
        raise ValueError(name+' has an invalid physical sign')
    return value


def _side(value):
    if type(value) is not int or value not in (-1, 1):
        raise ValueError('Physical side must be integer -1 or +1')
    return value


@dataclass(frozen=True)
class InterfaceLine:
    interface_id: str
    weld_type: str
    y0_mm: float
    z0_mm: float
    y1_mm: float
    z1_mm: float
    effective_throat_mm: float
    x_from_station_mm: float = 0.

    def __post_init__(self):
        if not isinstance(self.interface_id, str) or not self.interface_id.strip():
            raise ValueError('Interface identity required')
        if self.weld_type not in ('fillet', 'CJP'):
            raise ValueError('Only real fillet and CJP interfaces are supported')
        for k in ('y0_mm', 'z0_mm', 'y1_mm', 'z1_mm', 'x_from_station_mm'):
            object.__setattr__(self, k, _number(getattr(self,k), k))
        object.__setattr__(self, 'effective_throat_mm', _number(self.effective_throat_mm,
            'effective_throat_mm', positive=True))
        _number(self.length_mm, 'Interface length', positive=True)

    @property
    def length_mm(self):
        return hypot(self.y1_mm-self.y0_mm, self.z1_mm-self.z0_mm)

    @property
    def area_mm2(self):
        return self.effective_throat_mm*self.length_mm


@dataclass(frozen=True)
class MixedGroup:
    interfaces: tuple[InterfaceLine, ...]
    area_mm2: float
    centroid_y_mm: float
    centroid_z_mm: float
    polar_second_moment_mm4: float
    assumption: str = field(default=GROUP_ASSUMPTION, init=False)


@dataclass(frozen=True)
class LineDemand:
    interface: InterfaceLine
    ty0_mpa: float
    tz0_mpa: float
    ty1_mpa: float
    tz1_mpa: float
    qy0_N_per_mm: float
    qz0_N_per_mm: float
    qy1_N_per_mm: float
    qz1_N_per_mm: float
    Fy_N: float
    Fz_N: float
    Mx_about_group_Nmm: float
    peak_resultant_N_per_mm: float

    def moment_about(self, y_mm, z_mm):
        """Integral (y-yref)qz-(z-zref)qy, not a relocated scalar torque."""
        i = self.interface
        ymid, zmid = (i.y0_mm+i.y1_mm)/2, (i.z0_mm+i.z1_mm)/2
        dy, dz = i.y1_mm-i.y0_mm, i.z1_mm-i.z0_mm
        dqy, dqz = self.qy1_N_per_mm-self.qy0_N_per_mm, self.qz1_N_per_mm-self.qz0_N_per_mm
        return (ymid-y_mm)*self.Fz_N-(zmid-z_mm)*self.Fy_N+i.length_mm*(dy*dqz-dz*dqy)/12


@dataclass(frozen=True)
class GroupDemand:
    group: MixedGroup
    required_Fy_N: float
    required_Fz_N: float
    required_Mx_about_group_Nmm: float
    lines: tuple[LineDemand, ...]
    recovered_Fy_N: float
    recovered_Fz_N: float
    recovered_Mx_about_group_Nmm: float
    force_residual_y_N: float
    force_residual_z_N: float
    moment_residual_Nmm: float
    nominal_rotation_coefficient_MPa_per_mm: float
    equilibrium_satisfied: bool


@dataclass(frozen=True)
class ComponentCheck:
    check_id: str
    demand: float
    capacity: float
    utilization: float
    units: str
    status: str
    basis: str
    scope: str
    sufficient_bound: bool = False


@dataclass(frozen=True)
class ConnectionCase:
    case_id: str
    required_Fz_N: float
    reaction_Mx_about_web_face_Nmm: float
    force_line_y_mm: float
    replaces_real_G_locally: bool
    group_demand: GroupDemand
    checks: tuple[ComponentCheck, ...]
    section_results: dict
    executed_checks_sufficient: bool
    exceeded_check_ids: tuple[str, ...]
    pending: tuple[str, ...]
    unresolved_mode_ids: tuple[str, ...]
    local_path_complete: bool = field(default=False, init=False)
    global_load_increment_N: float = field(default=0., init=False)
    fatigue_stress_range_increment_mpa: float = field(default=0., init=False)


@dataclass(frozen=True)
class PlateConnection:
    physical_connection_id: str
    side: int
    body_ids: tuple[str, ...]
    mass_kg: float
    G_characteristic_N: float
    G_design_N: float
    centroid_y_mm: float
    centroid_z_mm: float
    web_face_y_mm: float
    local_gravity_My_about_station_Nmm: float
    group: MixedGroup
    cases: tuple[ConnectionCase, ...]


@dataclass(frozen=True)
class StationTransfer:
    station_id: str
    connections: tuple[PlateConnection, ...]
    pair_receiver_checks: tuple[ComponentCheck, ...]
    symmetry: dict
    pending: tuple[str, ...]
    unresolved_mode_ids: tuple[str, ...]
    station_qualified: bool = field(default=False, init=False)


@dataclass(frozen=True)
class SelfweightTransfer:
    status: str
    input_signature: str
    geometry_inputs_hash: str
    physical_mass_ledger_signature: str
    structural_G_factor: float
    total_mass_kg: float
    stations: tuple[StationTransfer, ...]
    executed_checks_sufficient: bool
    pending: tuple[str, ...]
    unresolved_mode_ids: tuple[str, ...]
    prepared_case_authenticated: bool = False
    prepared_stationary_ledger_sha256: str | None = None
    action_family_authenticated: bool = field(default=False, init=False)
    schema: str = field(default=SCHEMA, init=False)
    sources: tuple[str, ...] = field(default=SOURCES, init=False)
    station_qualified: bool = field(default=False, init=False)
    member_qualified: bool = field(default=False, init=False)
    receiver_closed: bool = field(default=False, init=False)
    production_credit_enabled: bool = field(default=False, init=False)
    global_stiffness_credit: bool = field(default=False, init=False)
    nominal_stiffness_idealization: str = field(default=GROUP_ASSUMPTION, init=False)
    force_floor_policy: str = field(default=(
        'max(real factored G,45000 N) once per plate connection, same downward gravity '
        'direction and same real force line; conservative moment policy, not a normative '
        'requirement to scale every moment. No added G, global force or fatigue range.'), init=False)

    def to_dict(self):
        return asdict(self)


def mixed_group(interfaces):
    """Exact area moments of physical straight effective interface lines."""
    if type(interfaces) is not tuple or not interfaces or any(type(v) is not InterfaceLine for v in interfaces):
        raise ValueError('An immutable nonempty tuple of typed interface lines is required')
    if len({v.interface_id for v in interfaces}) != len(interfaces):
        raise ValueError('Duplicate physical interface identity')
    area = _number(fsum(v.area_mm2 for v in interfaces), 'Group area', positive=True)
    y = fsum(v.area_mm2*(v.y0_mm+v.y1_mm)/2 for v in interfaces)/area
    z = fsum(v.area_mm2*(v.z0_mm+v.z1_mm)/2 for v in interfaces)/area
    J = fsum(v.area_mm2*(((v.y0_mm+v.y1_mm)/2-y)**2+
        ((v.z0_mm+v.z1_mm)/2-z)**2+v.length_mm**2/12) for v in interfaces)
    return MixedGroup(interfaces, area, y, z, _number(J,'Group J in y-z plane',positive=True))


def physical_mixed_group(beam, station, side):
    """All and only the three real interfaces belonging to one plate."""
    side = _side(side)
    geo = _physical(beam,station)
    w, p = station.web_fillet, station.pair
    # 6.2.2.2(d): this first domain needs beta=1, not an unexplained shortening
    # or uniform dilution of the stiffness over a longer physical weld.
    if geo['web_length'] > 100*w.leg_mm:
        raise ValueError('Web fillet exceeds 100 legs: 6.2.2.2(d) effective-length reduction is outside this group domain')
    yw = side*beam.web_thickness_mm/2
    root = f'{station.station_id}:plate:{"left" if side<0 else "right"}'
    fillets = tuple(InterfaceLine(root+f':web:{face:+d}', 'fillet', yw, geo['weld_low_z'],
        yw, geo['weld_high_z'], w.leg_mm/sqrt(2), face*p.thickness_mm/2) for face in (-1,1))
    cjp = InterfaceLine(root+':cjp', 'CJP', yw+side*geo['cope_start_u'], geo['top_z'],
        yw+side*p.outstand_mm, geo['top_z'], min(p.thickness_mm,beam.flange_thickness_mm))
    return mixed_group(fillets+(cjp,))


def solve_mixed_group(group, *, Fy_N, Fz_N, Mx_about_group_Nmm):
    """Closed-form classical group equilibrium, including self-balanced couples."""
    if type(group) is not MixedGroup or group != mixed_group(group.interfaces):
        raise ValueError('Regenerated untampered MixedGroup required')
    Fy, Fz, M = (_number(v,n) for v,n in ((Fy_N,'Fy'),(Fz_N,'Fz'),(Mx_about_group_Nmm,'Mx')))
    k = M/group.polar_second_moment_mm4
    rows = []
    for i in group.interfaces:
        ty0 = Fy/group.area_mm2-k*(i.z0_mm-group.centroid_z_mm)
        tz0 = Fz/group.area_mm2+k*(i.y0_mm-group.centroid_y_mm)
        ty1 = Fy/group.area_mm2-k*(i.z1_mm-group.centroid_z_mm)
        tz1 = Fz/group.area_mm2+k*(i.y1_mm-group.centroid_y_mm)
        qy0,qz0,qy1,qz1 = (i.effective_throat_mm*v for v in (ty0,tz0,ty1,tz1))
        ry,rz = i.length_mm*(qy0+qy1)/2,i.length_mm*(qz0+qz1)/2
        provisional = LineDemand(i,ty0,tz0,ty1,tz1,qy0,qz0,qy1,qz1,ry,rz,0.,
            max(hypot(qy0,qz0),hypot(qy1,qz1)))
        m = provisional.moment_about(group.centroid_y_mm,group.centroid_z_mm)
        rows.append(LineDemand(i,ty0,tz0,ty1,tz1,qy0,qz0,qy1,qz1,ry,rz,m,provisional.peak_resultant_N_per_mm))
    actual = (fsum(v.Fy_N for v in rows),fsum(v.Fz_N for v in rows),fsum(v.Mx_about_group_Nmm for v in rows))
    residual = tuple(a-b for a,b in zip(actual,(Fy,Fz,M)))
    fscale = max(abs(Fy),abs(Fz),1.)
    mscale = max(abs(M),fscale*sqrt(group.polar_second_moment_mm4/group.area_mm2),1.)
    ok = abs(residual[0])<=1e-11*fscale and abs(residual[1])<=1e-11*fscale and abs(residual[2])<=1e-11*mscale
    if not ok or any(not isfinite(v) for v in (*actual,*residual,k)):
        raise ValueError('Finite mixed-group equilibrium was not recovered')
    return GroupDemand(group,Fy,Fz,M,tuple(rows),*actual,*residual,k,ok)


def _check(identifier, demand, capacity, units, basis, scope, *, bound=False):
    demand = _number(demand,identifier+' demand',nonnegative=True)
    capacity = _number(capacity,identifier+' capacity',positive=True)
    ratio = _number(demand/capacity,identifier+' utilization',nonnegative=True)
    status = 'SUFFICIENT' if ratio<=1 else 'NOT_SUFFICIENT' if bound else 'COMPONENT_EXCEEDED'
    return ComponentCheck(identifier,demand,capacity,ratio,units,status,basis,scope,bound)


def _normal_checks(prefix, tensile, compressive, material, scope, *, bound=False, net_tension=False):
    # Compression check is GROSS YIELD only, never a stability capacity.
    checks = (
        _check(prefix+'/tension_gross_yield',tensile,material.fy_mpa/GAMMA_A1,'MPa','NBR 8800 6.5.3(a)',scope,bound=bound),
        _check(prefix+'/compression_gross_yield',compressive,material.fy_mpa/GAMMA_A1,'MPa','NBR 8800 6.5.4 gross yielding only; stability separate',scope,bound=bound),
    )
    if net_tension:
        checks += (_check(prefix+'/tension_effective_net_rupture',tensile,material.fu_mpa/GAMMA_A2,
            'MPa','NBR 8800 6.5.3(b), 5.2.4.2 and 5.2.5(a): An=Ag, Ct=1 for this wholly directly connected no-hole section',
            scope,bound=bound),)
    return checks


def _shear_checks(prefix, stress, material, scope, *, bound=False):
    return (
        _check(prefix+'/shear_gross_yield',stress,.60*material.fy_mpa/GAMMA_A1,'MPa','NBR 8800 6.5.5(a)',scope,bound=bound),
        _check(prefix+'/shear_net_rupture',stress,.60*material.fu_mpa/GAMMA_A2,'MPa','NBR 8800 6.5.5(b), unperforated actual net shear section',scope,bound=bound),
    )



def _rectangular_core_stability(*, outstand_mm, thickness_mm, active_height_mm, E_mpa, G_mpa, fy_mpa, compression_mpa):
    """Sufficient uniform-compression envelope of the real continuous core.

    Classical Euler fixed-free bar about its weak principal axis: Le=2b,
    NOT an inferred global member restraint. The same nominal rigid-root
    assumption as the group is adopted. Extra CJP/upper-plate restraint is
    ignored. A constant maximum compression over the whole core dominates
    the variable compression component; no elastic stress field is invented.
    The torsional critical load uses physical rectangular J and common project
    steel G, with the favorable warping term omitted. Both elastic modes feed chi.
    """
    b,t,h,E,G,fy=(_number(v,n,positive=True) for v,n in (
        (outstand_mm,'Physical core outstand'),(thickness_mm,'Core thickness'),
        (active_height_mm,'Active core height'),(E_mpa,'Core E'),(G_mpa,'Common nominal steel G'),(fy_mpa,'Core fy')))
    stress=_number(compression_mpa,'Core compression envelope',nonnegative=True)
    A=_number(t*h,'Core area',positive=True)
    Iweak=_number(min(h*t**3,t*h**3)/12,'Core weak inertia',positive=True)
    r=_number(sqrt(Iweak/A),'Core least radius',positive=True)
    Le=_number(2*b,'Core effective length',positive=True)
    denominator=_number(Le*Le,'Core effective length squared',positive=True)
    Nef=_number(pi*pi*E*Iweak/denominator,'Core Euler force',positive=True)
    # Solid doubly symmetric rectangle also has a torsional instability mode.
    # Omitting its nonnegative warping contribution gives a conservative Ne,t
    # without an invented torsional effective length or CJP restraint credit.
    Istrong=_number(max(h*t**3,t*h**3)/12,'Core strong inertia',positive=True)
    r0sq=_number((Iweak+Istrong)/A,'Core polar gyration squared',positive=True)
    J=_number(rectangle_torsion_constant(h,t),'Physical core torsion constant',positive=True)
    Net=_number(G*J/r0sq,'Core torsional critical-force lower bound',positive=True)
    Ne=min(Nef,Net)
    lam=sqrt(A*fy/Ne);chi=reduction_chi(lam)
    capacity=chi*fy/GAMMA_A1
    record=dict(outstand_mm=b,thickness_mm=t,active_height_mm=h,area_mm2=A,
        weak_axis_inertia_mm4=Iweak,least_radius_mm=r,effective_length_mm=Le,
        effective_length_factor=2.,boundary_condition='Nominal rigid root, free end; classical fixed-free Euler',
        elastic_critical_force_N=Ne,flexural_elastic_critical_force_N=Nef,
        torsional_elastic_critical_force_lower_N=Net,polar_gyration_squared_mm2=r0sq,
        rectangle_J_lower_mm4=J,rectangle_J_source=RECTANGLE_SOURCE,
        common_nominal_steel_G_mpa=G,torsional_warping_contribution_credited=False,
        governing_elastic_mode='flexural' if Nef<=Net else 'torsional_lower_bound',
        lambda_zero=lam,chi=chi,design_compression_mpa=capacity,
        uniform_compression_envelope_mpa=stress,
        extra_CJP_or_upper_plate_restraint_credit=False,
        manufactured_geometry_or_strength_changed=False,
        source='NBR 8800 5.3.2/.3/.5: min(classical fixed-free flexural Ne, GJ/r0² torsional lower bound); sufficient rectangular-core envelope')
    check=_check('plate_core_transverse_compression_stability',stress,capacity,'MPa',
        record['source'],'Maximum actual nominal core compression imposed uniformly; local weld/root capacity and concurrent stress interaction remain separate',bound=True)
    return record,check


def _connection_case(beam, station, plate_material, beam_material, weld, group,
                     side, force, yg, name, replaces):
    geo, p, w = _physical(beam,station), station.pair, station.web_fillet
    demand = solve_mixed_group(group,Fy_N=0.,Fz_N=force,Mx_about_group_Nmm=force*(yg-group.centroid_y_mm))
    checks=[]; sections={}; web=tuple(v for v in demand.lines if v.interface.weld_type=='fillet')
    cjp=next(v for v in demand.lines if v.interface.weld_type=='CJP')
    for row in web:
        prefix=row.interface.interface_id
        checks.append(_check(prefix+'/weld_resultant',row.peak_resultant_N_per_mm,
            .60*weld.fuw_mpa*row.interface.effective_throat_mm/GAMMA_W2,'N/mm',
            'NBR 8800 Table 9 fillet, resultant of ALL joint force components; unit effective length',
            'Fillet metal only; no directional factor'))
        # On the web face qy is normal and qz shear. On the PLATE x-face
        # both qy and qz are in-plane shear, never normal_y on that face.
        # Web traction is the opposite reaction; surface normal is side*y.
        normal = (-side*row.qy0_N_per_mm/w.leg_mm,-side*row.qy1_N_per_mm/w.leg_mm)
        normal_scope='Actual fused web footprint width=fillet leg, NOT effective throat or web thickness; nominal interface stress'
        checks.extend(_normal_checks(prefix+'/web_footprint',max(0.,*normal),max(0.,*(-v for v in normal)),beam_material,normal_scope,net_tension=True))
        checks.extend(_shear_checks(prefix+'/web_footprint',max(abs(row.qz0_N_per_mm),abs(row.qz1_N_per_mm))/w.leg_mm,beam_material,normal_scope))
        checks.extend(_shear_checks(prefix+'/plate_footprint',row.peak_resultant_N_per_mm/w.leg_mm,plate_material,
            'Actual plate-side fused footprint width=fillet leg; y/z vector is shear on its x-normal plane'))
    normal=max(abs(cjp.tz0_mpa),abs(cjp.tz1_mpa)); shear=max(abs(cjp.ty0_mpa),abs(cjp.ty1_mpa))
    lesser_fy=min(plate_material.fy_mpa,beam_material.fy_mpa)
    checks.append(_check(cjp.interface.interface_id+'/CJP_normal',normal,lesser_fy/GAMMA_A1,'MPa',
        'NBR 8800 Table 9 true CJP normal to effective plane; lesser base-metal fy',
        'Normal sigma_z; compatible fully penetrating CJP requirements remain explicit'))
    checks.append(_check(cjp.interface.interface_id+'/CJP_shear',shear,.60*lesser_fy/GAMMA_A1,'MPa',
        'NBR 8800 Table 9 true CJP shear on effective plane; lesser base-metal fy',
        'Shear tau_yz, separate from sigma_z; not fillet resultant capacity'))
    # Actual final upper ligament, no full outstand or reinforcement credited.
    cp_sigma=[cjp.qz0_N_per_mm/p.thickness_mm,cjp.qz1_N_per_mm/p.thickness_mm]
    checks.extend(_normal_checks('plate_top_ligament',max(0.,*cp_sigma),max(0.,*(-v for v in cp_sigma)),plate_material,
        'Final physical tp by real CJP length; cope removed, full compatible refill prerequisite',net_tension=True))
    checks.extend(_shear_checks('plate_top_ligament',max(abs(cjp.qy0_N_per_mm),abs(cjp.qy1_N_per_mm))/p.thickness_mm,
        plate_material,'Final unperforated physical top ligament'))
    # Nominal root section is the actual wholly connected active rectangle,
    # not total plate/root height. The unwelded lower setback is not credited.
    # Actual web reaction (not all G) supplies its N,V,M.
    yw=side*beam.web_thickness_mm/2; h=geo['web_length']
    zp=(geo['weld_high_z']+geo['weld_low_z'])/2
    A=p.thickness_mm*h; W=p.thickness_mm*h*h/6
    H=fsum(v.Fy_N for v in web); V=fsum(v.Fz_N for v in web)
    M=fsum(v.moment_about(yw,zp) for v in web)
    root_sigma=(-side*H/A-side*M/W,-side*H/A+side*M/W)
    tau=1.5*abs(V)/A
    sections['plate_root']=dict(y_mm=yw,z_centroid_mm=zp,height_mm=h,area_mm2=A,elastic_modulus_mm3=W,
        physical_remaining_root_height_mm=geo['weld_high_z']-p.bottom_z_mm,
        net_area_mm2=A,effective_area_mm2=A,Ct=1.,
        section_scope='Actual connected subrectangle z=weld_low..weld_high; lower unwelded setback not credited',
        reaction_Fy_N=H,reaction_Fz_N=V,reaction_Mx_Nmm=M,normal_endpoints_mpa=root_sigma,
        rectangular_peak_shear_mpa=tau,stress_model='Nominal rectangular beam section; no cope stress-concentration or stability claim')
    checks.extend(_normal_checks('plate_root',max(0.,*root_sigma),max(0.,*(-v for v in root_sigma)),plate_material,
        'Actual tp by wholly connected active root height, linear normal stress, full web-line resultants only',bound=True,net_tension=True))
    checks.extend(_shear_checks('plate_root',tau,plate_material,
        'Parabolic nominal rectangular-section shear, actual root area; no interior elasticity peak claim',bound=True))
    # The active z rectangle exists for the complete outstand: the actual
    # circular cope removes material only ABOVE z=top-Rc. Full compatible
    # preparation refill is separately required wherever it intersects this
    # core. No upper additional plate or CJP restraint is credited.
    core_exists=(geo['weld_low_z']>=p.bottom_z_mm and geo['weld_high_z']<=geo['top_z']-p.cope_radius_mm
        and h>0 and station.web_fillet.continuous and len(web)==2)
    if not core_exists:
        raise ValueError('Continuous physical rectangular compression core and two continuous root fillets required')
    stability,stability_check=_rectangular_core_stability(outstand_mm=p.outstand_mm,
        thickness_mm=p.thickness_mm,active_height_mm=h,E_mpa=plate_material.E_mpa,
        G_mpa=beam_material.G_mpa,fy_mpa=plate_material.fy_mpa,compression_mpa=max(0.,*(-v for v in root_sigma)))
    stability['common_G_basis']='Project structural-steel G, adopted common nominal elastic constant for the beam and plate steels; no strength inferred'
    stability['continuous_physical_core_verified']=core_exists
    stability['root_connection_local_capacity_sufficient']=all(c.utilization<=1 for c in checks
        if ':web:' in c.check_id or c.check_id.startswith('plate_root/'))
    stability['root_geometry']=dict(y_root_mm=yw,z_bottom_mm=geo['weld_low_z'],z_top_mm=geo['weld_high_z'],
        no_cope_within_core=True,two_continuous_fillets=True)
    sections['plate_core_transverse_compression_stability']=stability
    checks.append(stability_check)
    # Whole-plate detachment path: vertical directly connected root in
    # shear plus horizontal real CJP ligament in tension, joined by the
    # existing free cope contour. Both are actual no-hole plate sections.
    # Use the smaller active root height, not the unwelded lower setback.
    Av=p.thickness_mm*h; At=p.thickness_mm*geo['cjp_length']; Cts=.5
    block=(min(.60*plate_material.fu_mpa*Av,.60*plate_material.fy_mpa*Av)
        +Cts*plate_material.fu_mpa*At)/GAMMA_A2
    checks.append(_check('plate_combined_root_top_block',force,block,'N',
        'NBR 8800 6.5.6, Agv=Anv=tp*Lactive, Ant=tp*Bc, Cts=0.5 for nonuniform top tension',
        'Vertical-G detachment path around existing free circular cope; actual root/top local moments are checked separately',bound=True))
    sections['plate_combined_root_top_block']=dict(Agv_mm2=Av,Anv_mm2=Av,Ant_mm2=At,Cts=Cts,
        force_N=force,capacity_N=block,
        geometry='Root vertical section and top horizontal section separated by existing free cope contour; no invented interior web block',
        local_moments_checked_separately=True)
    # An intentionally narrow REAL tp-wide strip. Integrate CJP load at its
    # lower flange surface, with qy eccentric to the flange midplane.
    zmid=geo['top_z']+beam.flange_thickness_mm/2
    FM=cjp.moment_about(yw,zmid); FA=p.thickness_mm*beam.flange_thickness_mm
    FW=p.thickness_mm*beam.flange_thickness_mm**2/6
    fsigma=(-side*cjp.Fy_N/FA-side*FM/FW,-side*cjp.Fy_N/FA+side*FM/FW)
    ftau=1.5*abs(cjp.Fz_N)/FA
    sections['flange_physical_strip']=dict(width_x_mm=p.thickness_mm,thickness_mm=beam.flange_thickness_mm,
        area_mm2=FA,elastic_modulus_mm3=FW,root_y_mm=yw,root_z_mm=zmid,
        reaction_Fy_N=cjp.Fy_N,reaction_Fz_N=cjp.Fz_N,reaction_Mx_Nmm=FM,
        normal_extrema_mpa=fsigma,rectangular_peak_shear_mpa=ftau,
        moment_includes_lower_surface_shear_eccentricity=True,
        stress_model='Separate physical cantilever strip of width tp; no effective-width spread, plastic redistribution or complete receiver claim')
    checks.extend(_normal_checks('flange_physical_strip',max(0.,*fsigma),max(0.,*(-v for v in fsigma)),beam_material,
        'Elastic sufficient normal-strength bound on actual rectangular tp by tf strip; not a failure certificate for the whole flange',bound=True))
    checks.extend(_shear_checks('flange_physical_strip',ftau,beam_material,
        'Nominal rectangular strip shear; no effective-width enlargement',bound=True))
    sections['CJP_resolved_components']=dict(sigma_z_endpoints_mpa=(cjp.tz0_mpa,cjp.tz1_mpa),
        tau_yz_endpoints_mpa=(cjp.ty0_mpa,cjp.ty1_mpa),Fy_N=cjp.Fy_N,Fz_N=cjp.Fz_N,
        normal_and_shear_interaction_evaluated=False)
    # Signed Cauchy components at REAL receiving faces. These are nominal
    # uniform footprint values, not an interpolated 3-D interior stress field.
    points=[]
    for row in web:
        face=1 if row.interface.x_from_station_mm>0 else -1
        for endpoint,z,qy,qz in (('bottom',row.interface.z0_mm,row.qy0_N_per_mm,row.qz0_N_per_mm),
                                ('top',row.interface.z1_mm,row.qy1_N_per_mm,row.qz1_N_per_mm)):
            points.append(dict(point_id=row.interface.interface_id+'/web/'+endpoint,
                x_from_station_mm=face*(p.thickness_mm/2+w.leg_mm/2),y_mm=yw,z_mm=z,
                x_footprint_interval_from_station_mm=tuple(sorted((face*p.thickness_mm/2,face*(p.thickness_mm/2+w.leg_mm)))),
                y_footprint_interval_mm=(yw,yw),
                material_role='beam_web',surface_normal=(0,side,0),
                tensor_components_mpa=dict(sigma_yy=-side*qy/w.leg_mm,tau_yz=-side*qz/w.leg_mm),
                basis='Nominal actual fused footprint: width=leg; no interior field reconstructed'))
            points.append(dict(point_id=row.interface.interface_id+'/plate/'+endpoint,
                x_from_station_mm=face*p.thickness_mm/2,y_mm=yw+side*w.leg_mm/2,z_mm=z,
                x_footprint_interval_from_station_mm=(face*p.thickness_mm/2,face*p.thickness_mm/2),
                y_footprint_interval_mm=tuple(sorted((yw,yw+side*w.leg_mm))),
                material_role='plate',surface_normal=(face,0,0),
                tensor_components_mpa=dict(tau_xy=face*qy/w.leg_mm,tau_xz=face*qz/w.leg_mm),
                basis='Both force components are shear on the real plate x-face footprint'))
    for endpoint,y,qy,qz in (('inner',cjp.interface.y0_mm,cjp.qy0_N_per_mm,cjp.qz0_N_per_mm),
                            ('outer',cjp.interface.y1_mm,cjp.qy1_N_per_mm,cjp.qz1_N_per_mm)):
        points.append(dict(point_id=cjp.interface.interface_id+'/flange_contact/'+endpoint,
            x_from_station_mm=0.,y_mm=y,z_mm=geo['top_z'],
            x_footprint_interval_from_station_mm=(-p.thickness_mm/2,p.thickness_mm/2),
            y_footprint_interval_mm=(y,y),material_role='beam_flange',surface_normal=(0,0,-1),
            tensor_components_mpa=dict(sigma_zz=qz/p.thickness_mm,tau_yz=qy/p.thickness_mm),
            basis='Actual tp-wide receiving contact; distinct from min(tp,tf) CJP resistance throat'))
    sections['signed_interface_points']=tuple(points)
    section_points=[]
    for position,z,sigma,tau in (
        ('bottom',zp-h/2,root_sigma[0],0.),('middle',zp,-side*H/A,-side*1.5*V/A),
        ('top',zp+h/2,root_sigma[1],0.)):
        section_points.append(dict(point_id='plate_root/'+position,x_from_station_mm=0.,y_mm=yw,z_mm=z,
            material_role='plate',tensor_components_mpa=dict(sigma_yy=sigma,tau_yz=tau),
            basis='Concurrent signed components of nominal active rectangular root section; linear normal/parabolic shear'))
    for position,z,sigma,tau in (
        ('lower',zmid-beam.flange_thickness_mm/2,fsigma[0],0.),
        ('middle',zmid,-side*cjp.Fy_N/FA,-side*1.5*cjp.Fz_N/FA),
        ('upper',zmid+beam.flange_thickness_mm/2,fsigma[1],0.)):
        section_points.append(dict(point_id='flange_strip_root/'+position,x_from_station_mm=0.,y_mm=yw,z_mm=z,
            material_role='beam_flange',tensor_components_mpa=dict(sigma_yy=sigma,tau_yz=tau),
            basis='Concurrent signed components of actual tp-wide nominal rectangular flange strip; not maxima copied from another point'))
    sections['signed_section_points']=tuple(section_points)
    functions=[]
    for identity,zcenter,depth,normal0,normal1,shear0,role in (
        ('plate_root',zp,h,-side*H/A,side*M/W,-side*1.5*V/A,'plate'),
        ('flange_strip_root',zmid,beam.flange_thickness_mm,-side*cjp.Fy_N/FA,side*FM/FW,
         -side*1.5*cjp.Fz_N/FA,'beam_flange')):
        functions.append(dict(section_id=identity,material_role=role,x_from_station_mm=0.,y_mm=yw,
            z_centroid_mm=zcenter,z_interval_mm=(zcenter-depth/2,zcenter+depth/2),
            local_coordinate='u=2*(z-z_centroid)/section_depth',u_interval=(-1.,1.),section_depth_mm=depth,
            sigma_yy_coefficients_mpa=(normal0,normal1),tau_yz_coefficients_mpa=(shear0,0.,-shear0),
            polynomial_order='ascending powers of the SAME u; evaluate all components at the same point',
            sufficient_component_intervals_mpa=dict(sigma_yy=(normal0-abs(normal1),normal0+abs(normal1)),
                tau_yz=(min(0.,shear0),max(0.,shear0))),
            interval_scope='Every point of this single physical nominal section is enclosed; box vertices are not claimed simultaneous actual states',
            torsional_or_interior_tensor_interpolation=False))
    sections['nominal_section_stress_functions']=tuple(functions)
    sections['point_snapshot_scope']=dict(case_id=name,required_force_N=force,
        represents_real_G=(name=='real_factored_G'),minimum_substitutes_G=replaces,
        exact_continuum_maximum_claimed=False,interior_stress_tensor_reconstructed=False)
    exceeded=tuple(c.check_id for c in checks if c.utilization>1)
    return ConnectionCase(name,force,force*(yg-yw),yg,replaces,demand,tuple(checks),sections,
        not exceeded,exceeded,MECHANISM_PENDING,UNRESOLVED_MODE_IDS)


def assess_selfweight_transfer(project, *, structural_G_factor):
    """Regenerate G from physical inputs. This is a parametric normal-ULS check.

    The scalar factor does not authenticate a load family. Use the prepared
    wrapper when consuming an already regenerated mechanical action case.
    """
    project.validate()
    inputs=project.intermediates
    if inputs is None:
        raise ValueError('Physical adopted intermediate inputs required; no absent/fake station')
    factor=_number(structural_G_factor,'Structural G factor',nonnegative=True)
    _validate_material_identity(project,inputs)
    source_hash=sha256(Path(__file__).with_name('detail.py').read_bytes()).hexdigest()
    if source_hash!=FROZEN_DETAIL_SHA256:
        raise ValueError('Frozen physical detail source changed; requalify geometry/mass consumers')
    layout=inputs.layout;beam=layout.beam
    if type(layout) is not IntermediateLayout:
        raise ValueError('Validated physical IntermediateLayout required')
    ledger=stationary_mass_ledger(layout,gravity_m_s2=GRAVITY_M_S2)
    steels={v.material_id:v for v in inputs.plate_materials};welds={v.material_id:v for v in inputs.weld_consumables}
    stations=[];all_pending=list(MECHANISM_PENDING);all_modes=list(UNRESOLVED_MODE_IDS)
    for station in layout.stations:
        geo=_physical(beam,station);detail=assess_detail(beam,station)
        pending=list(MECHANISM_PENDING)+list(detail.pending)
        mode_ids=list(UNRESOLVED_MODE_IDS)
        if detail.pending: mode_ids.append('detail_execution_requirements')
        plate_steel=steels[station.pair.material.material_id]
        cjp_weld=welds[station.cjp.material.material_id]
        reconstruction_materials=(cjp_weld.fyw_mpa is not None and cjp_weld.E_mpa==plate_steel.E_mpa
            and cjp_weld.fyw_mpa>=plate_steel.fy_mpa and cjp_weld.fuw_mpa>=plate_steel.fu_mpa)
        if not reconstruction_materials:
            mode_ids.append('cjp_reconstructed_ligament_material')
            pending.append('Actual CJP reconstructed top ligament lacks matching declared fyw, E and fuw; its plate-steel capacities are conditional, not accepted')
        if cjp_weld.fuw_mpa<max(plate_steel.fu_mpa,project.material.fu_mpa):
            mode_ids.append('cjp_full_compatibility')
            pending.append('CJP specified tensile strength is below a connected base-metal fu: full Table 9 compatibility has not been established')
        tolerance_values=(beam.flange_thickness_tolerance_mm,beam.web_thickness_tolerance_mm,
            beam.root_radius_tolerance_mm,station.pair.bottom_tolerance_mm,station.pair.cope_radius_tolerance_mm,
            station.web_fillet.endpoint_tolerance_mm,station.cjp.root_gap_tolerance_mm,
            station.cjp.reinforcement_leg_tolerance_mm)
        if any(tolerance_values):
            mode_ids.append('asymmetric_tolerance_realizations')
            pending.append('Nominal mirrored geometry only: independently adverse/asymmetric tolerance realizations are not evaluated')
        connections=[]
        for side,label in ((-1,'left'),(1,'right')):
            identifier=f'{station.station_id}:plate:{label}'
            points=tuple(p for p in ledger['points'] if p['part_id']==identifier or p['part_id'].startswith(identifier+':'))
            if not points:
                raise ValueError('Physical plate has no own mass bodies')
            mass=fsum(p['mass_kg'] for p in points)
            yg=fsum(p['mass_kg']*p['y_mm'] for p in points)/mass
            zg=fsum(p['mass_kg']*p['z_from_bottom_mm'] for p in points)/mass
            Gk=mass*GRAVITY_M_S2;G=Gk*factor
            my=fsum((p['x_mm']-station.x_mm)*(-p['Fz_N'])*factor for p in points)
            if not isclose(my,0.,abs_tol=1e-10*max(1.,G*station.pair.thickness_mm)):
                raise ValueError('Nonplanar G moment about y is outside the symmetric planar group domain')
            group=physical_mixed_group(beam,station,side)
            common=(beam,station,steels[station.pair.material.material_id],project.material,
                welds[station.web_fillet.material.material_id],group,side)
            cases=tuple(_connection_case(*common,force,yg,name,replaces) for name,force,replaces in (
                ('real_factored_G',G,False),('connection_minimum_same_force_line',max(G,MINIMUM_CONNECTION_FORCE_N),True)))
            for case in cases:
                case.section_results['CJP_material_requirements']=dict(
                    consumable_id=cjp_weld.consumable_id,material_id=cjp_weld.material_id,
                    fuw_mpa=cjp_weld.fuw_mpa,fyw_mpa=cjp_weld.fyw_mpa,E_mpa=cjp_weld.E_mpa,
                    reconstruction_materials_sufficient=reconstruction_materials,
                    compatibility_basis=station.cjp.compatibility_basis,
                    source=cjp_weld.specification_source,
                    no_deposit_yield_inferred_from_fuw=True)
            cases=tuple(replace(case,pending=tuple(dict.fromkeys(pending)),unresolved_mode_ids=tuple(mode_ids)) for case in cases)
            connections.append(PlateConnection(identifier,side,tuple(p['part_id'] for p in points),mass,Gk,G,yg,zg,
                side*beam.web_thickness_mm/2,my,group,cases))
        checks=[]
        for case_index,name in enumerate(('real_factored_G','connection_minimum_same_force_line')):
            # Actual sum reaching the web, NOT 2G and NOT a new floor for each cut.
            lines=[v for c in connections for v in c.cases[case_index].group_demand.lines if v.interface.weld_type=='fillet']
            web_force=fsum(v.Fz_N for v in lines)
            area=2*beam.web_thickness_mm*geo['web_length']
            checks.extend(_shear_checks(name+'/paired_web_two_vertical_cuts',abs(web_force)/area,project.material,
                'Two real vertical cuts outside outer fillet toes, total 2twL; average shear only, not a block-tear or elastic-peak proof',bound=True))
        left,right=connections
        mirror=all(isclose(getattr(l,k),sign*getattr(r,k),rel_tol=1e-12,abs_tol=1e-10)
            for lc,rc in zip(left.cases,right.cases) for l,r in zip(lc.group_demand.lines,rc.group_demand.lines)
            for k,sign in (('qy0_N_per_mm',-1),('qy1_N_per_mm',-1),('qz0_N_per_mm',1),('qz1_N_per_mm',1)))
        symmetry=dict(nominal_mirror_verified=mirror,
            web_opposite_normal_tractions_coincident_and_cancel_resultant=mirror,
            through_thickness_normal_stress_eliminated=False,web_shear_eliminated=False,
            flange_CJP_load_eliminated=False,tolerance_realizations_evaluated=not any(tolerance_values),
            pair_real_G_external_Mx_origin_Nmm=-fsum(c.G_design_N*c.centroid_y_mm for c in connections),
            each_physical_plate_floor_count=1,physical_plate_connections=2)
        if not mirror:
            raise ValueError('Nominal symmetric pair lost pointwise mirrored G tractions')
        all_pending.extend(pending);all_modes.extend(mode_ids)
        stations.append(StationTransfer(station.station_id,tuple(connections),tuple(checks),symmetry,tuple(dict.fromkeys(pending)),tuple(mode_ids)))
    sufficient=all(c.executed_checks_sufficient for s in stations for p in s.connections for c in p.cases)
    sufficient=sufficient and all(c.utilization<=1 for s in stations for c in s.pair_receiver_checks)
    signature=sha256(json.dumps(dict(inputs=inputs.to_dict(),beam_material=asdict(project.material),
        structural_G_factor=factor,method=SCHEMA,source_hash=source_hash,
        method_source_sha256=sha256(Path(__file__).read_bytes()).hexdigest()),sort_keys=True,allow_nan=False).encode()).hexdigest()
    return SelfweightTransfer('PARTIAL_CHECKS_SUFFICIENT' if sufficient else 'PARTIAL_CHECKS_NOT_SUFFICIENT',
        signature,ledger['geometry_inputs_hash'],ledger['input_signature'],factor,ledger['total_mass_kg'],
        tuple(stations),sufficient,tuple(dict.fromkeys(all_pending)),tuple(dict.fromkeys(all_modes)))


def assess_prepared_selfweight_transfer(project, prepared_case):
    """Authenticate physical basis, full prepared actions and real-G ledger first."""
    from dataclasses import replace
    from .nominal_field import _context
    _context(project,prepared_case)
    result=assess_selfweight_transfer(project,structural_G_factor=prepared_case.factors.dead_support)
    if result.geometry_inputs_hash!=prepared_case.geometry_inputs_hash:
        raise ValueError('Physical geometry changed between prepared case and connection checks')
    return replace(result,prepared_case_authenticated=True,
        prepared_stationary_ledger_sha256=prepared_case.stationary_ledger_sha256)


__all__=['InterfaceLine','MixedGroup','LineDemand','GroupDemand','ComponentCheck',
    'ConnectionCase','PlateConnection','StationTransfer','SelfweightTransfer','mixed_group',
    'physical_mixed_group','solve_mixed_group','assess_selfweight_transfer','assess_prepared_selfweight_transfer']
