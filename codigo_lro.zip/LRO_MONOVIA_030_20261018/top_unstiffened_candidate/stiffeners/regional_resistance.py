"""Regional NBR 8800 shear resistance for the adopted physical TOP detail.

Only the functional prescriptive qualification of a shear-panel endpoint is
used here. Transfer, fatigue and other member checks remain independent final
obligations. This is not certification of a complete station or fabrication.
The former uniform bare-web buckling check is replaced by this SAME obligation
on a complete closed spatial partition; every other component check survives.
"""
from copy import deepcopy
from dataclasses import asdict
from fractions import Fraction
from math import isfinite

from underslung_runway_candidate.autonomous_workflow.model import signature
from ..checks import _prepared_key
from .prescriptive import assemble_prescriptive
from .shear import SteelShearInput, shear_resistance, SHEAR_SOURCE
from .regional_shear import prepared_regional_shear_bounds

SCHEMA = 'TOP_INTERMEDIATE_REGIONAL_SHEAR_V1'
REPLACED_CHECK = 'bare_web_vertical_shear'


def _finite(v, name, *, positive=False):
    if type(v) not in (int, float) or not isfinite(v) or (v <= 0 if positive else v < 0):
        raise ValueError(name+' must be finite '+('positive' if positive else 'nonnegative'))
    return v


def physical_shear_regions(project, assembly):
    """Closed regions; true overhangs are additional bare-web regions."""
    rows = [asdict(r) for r in assembly.inventory.regions()]
    p = project.structure
    left, right = p.beam_end_left_mm, p.beam_end_right_mm
    if left:
        rows.insert(0,dict(region_id='left_projection',left_mm=-left,right_mm=0.,
            left_station_id=None,right_station_id=None,method='physical_projection_no_panel_credit',
            physical_panel_spacing_mm=None))
    if right:
        L=p.span_m*1000
        rows.append(dict(region_id='right_projection',left_mm=L,right_mm=L+right,
            left_station_id=None,right_station_id=None,method='physical_projection_no_panel_credit',
            physical_panel_spacing_mm=None))
    return rows


def regional_case_demands(project, assembly, c, case_id):
    """Only called on each regenerated, ledger-checked current ULS PreparedCase."""
    rows=[]
    for region in physical_shear_regions(project,assembly):
        bound=prepared_regional_shear_bounds(c,left_mm=region['left_mm'],right_mm=region['right_mm'],
            region_id=region['region_id'])
        demand=_finite(bound['demand_abs_kn'],'regional shear demand')
        rows.append(dict(region=region,demand_abs_kn=demand,bound=bound))
    return dict(case_id=case_id,prepared_signature=_prepared_key(c),regions=rows,
        full_travel_m=list(c.translation_range_m),case_demand_signature=signature(rows))


def _assert_no_incomplete(value):
    if isinstance(value,dict):
        if value.get('pending') or value.get('errors') or value.get('input_valid',True) is not True:
            raise ValueError('Incomplete nested sign evidence')
        if 'status' in value and value['status'] not in ('CONDITIONAL_PER_CASE_NOMINAL_SIGN_BOUNDS_SATISFIED','INCONCLUSIVE_SUFFICIENT_NOMINAL_SIGN_BOUND'):
            raise ValueError('Unknown sign evidence status')
        for item in value.values():_assert_no_incomplete(item)
    elif isinstance(value,(list,tuple)):
        for item in value:_assert_no_incomplete(item)


def _signs(project, cmaa, nbr):
    """Validate six exact material patches at each station in both full families.

    Completeness of regenerated action membership is established by the owning
    workflow and again by its normal Case-I consumer. Those current receipts
    bind every sign result; no UI qualification flag can substitute for them.
    """
    ids=tuple(s.station_id for s in sorted(project.intermediates.layout.stations,key=lambda s:s.x_mm))
    qualified=dict.fromkeys(ids,True)
    counts={}
    geom=project.intermediates.physical_geometry_hash()
    for name,family,key in (('CMAA_normal_ULS',cmaa,'results'),('NBR_normal_Case_I',nbr,'sign_case_results')):
        rows=family.get(key);receipts=family.get('case_receipts');n=family.get('case_count')
        if (family.get('action_family_authenticated') is not True or type(n) is not int or n<=0
            or not isinstance(rows,(tuple,list)) or len(rows)!=n
            or not isinstance(receipts,(tuple,list)) or len(receipts)!=n
            or family.get('project_signature')!=signature(project.to_dict())):
            raise ValueError('Complete current '+name+' sign family required')
        if len({r['case_id'] for r in receipts})!=n:raise ValueError('Duplicate sign case identity')
        for row,receipt in zip(rows,receipts):
            _assert_no_incomplete(row)
            if (row.get('input_valid') is not True or row.get('pending') or row.get('errors')
                or row.get('geometry_inputs_hash')!=geom
                or row.get('all_translations_and_patches_covered') is not True
                or receipt.get('sign_result_signature')!=signature(row)):
                raise ValueError('Incomplete, foreign or changed sign proof')
            stations=row.get('station_results');patches=row.get('patch_results')
            if (not isinstance(stations,(list,tuple)) or tuple(s.get('station_id') for s in stations)!=ids
                or not isinstance(patches,(list,tuple)) or len(patches)!=6*len(ids)):
                raise ValueError('Every physical endpoint and six material patches are required')
            by_patch={p.get('patch_id'):p for p in patches}
            if len(by_patch)!=len(patches):raise ValueError('Duplicate material patch')
            decisions=[]
            for station in stations:
                sid=station['station_id'];names=station.get('patch_ids')
                expected={sid+':bottom_flange:'+side for side in ('negative_y','positive_y')}
                expected|={sid+':lower_web:'+side+':'+end for side in ('negative_y','positive_y') for end in ('negative_x','positive_x')}
                if not isinstance(names,(list,tuple)) or len(names)!=6 or set(names)!=expected:
                    raise ValueError('Exact lower flange and weld-footprint inventory required')
                passed=True
                for pid in names:
                    patch=by_patch.get(pid);certificate=patch.get('certificate',{}) if isinstance(patch,dict) else {}
                    if (patch is None or patch.get('station_id')!=sid or patch.get('pending') or patch.get('errors')
                        or certificate.get('all_translations_and_patch_covered') is not True):
                        raise ValueError('Incomplete material patch proof')
                    ratios=certificate.get('sigma_x_exact_ratio')
                    if not isinstance(ratios,(list,tuple)) or len(ratios)!=2:raise ValueError('Exact signed interval required')
                    values=[]
                    for pair in ratios:
                        if not isinstance(pair,(list,tuple)) or len(pair)!=2 or any(type(v) is not int for v in pair) or pair[1]<=0:
                            raise ValueError('Canonical exact sign ratio required')
                        values.append(Fraction(*pair))
                    lo,hi=values
                    if lo>hi:raise ValueError('Reversed sign interval')
                    ok=lo>=0
                    if (type(certificate.get('no_nominal_compression')) is not bool
                        or certificate['no_nominal_compression']!=ok
                        or type(patch.get('no_nominal_compression')) is not bool
                        or patch['no_nominal_compression']!=ok
                        or patch.get('sigma_x_exact_ratio')!=ratios):raise ValueError('Sign decision differs from exact interval')
                    passed=passed and ok
                if (station.get('no_nominal_compression') is not passed
                    or station.get('conditional_sign_bound_satisfied') is not passed):raise ValueError('Station sign decision differs')
                qualified[sid]=qualified[sid] and passed;decisions.append(passed)
            if row.get('all_station_sign_bounds_satisfied') is not all(decisions):raise ValueError('Family sign decision differs')
        counts[name]=n
    return qualified,counts


def compose_regional_shear(project, assembly, cmaa, nbr):
    """Select kv regionally after exact endpoint functional qualifications."""
    fresh=assemble_prescriptive(project)
    if fresh!=assembly:raise ValueError('Prescriptive geometry/material snapshot changed')
    signs,counts=_signs(project,cmaa,nbr)
    expected=physical_shear_regions(project,assembly)
    demands=cmaa.get('regional_shear_cases')
    receipts=cmaa.get('case_receipts')
    if not isinstance(demands,(list,tuple)) or len(demands)!=cmaa['case_count']:
        raise ValueError('Every regenerated CMAA ULS case needs regional shear demands')
    worst={};case_ids=set()
    for case,receipt in zip(demands,receipts):
        if (case.get('case_id')!=receipt['case_id'] or case['case_id'] in case_ids
            or case.get('prepared_signature')!=receipt['prepared_signature']
            or case.get('case_demand_signature')!=signature(case.get('regions'))
            or receipt.get('regional_shear_signature')!=signature(case)):
            raise ValueError('Changed, duplicated or foreign regional demand case')
        case_ids.add(case['case_id']);rows=case.get('regions')
        if not isinstance(rows,(list,tuple)) or [r.get('region') for r in rows]!=expected:
            raise ValueError('Complete closed region partition is required in every case')
        for row in rows:
            value=_finite(row.get('demand_abs_kn'),'regional demand')
            if row['bound'].get('demand_abs_kn')!=value:raise ValueError('Demand differs from its analytical enclosure')
            rid=row['region']['region_id']
            if rid not in worst or value>worst[rid]['demand_abs_kn']:
                worst[rid]=dict(row,governing_case_id=case['case_id'],prepared_signature=case['prepared_signature'])
    stations={s.station_id:s for s in assembly.stations}
    eligible={sid:bool(s.geometry_prescriptive_candidate_sufficient and signs[sid]) for sid,s in stations.items()}
    beam=project.intermediates.layout.beam;m=project.material
    steel=SteelShearInput(beam.depth_mm,beam.web_thickness_mm,beam.clear_web_depth_8800_mm,m.E_mpa,m.fy_mpa,m.gamma_a1)
    checks=[];regions=[]
    for region in expected:
        a=region['physical_panel_spacing_mm']
        ends=(region['left_station_id'],region['right_station_id'])
        qualification=a is not None and all(eligible.get(sid) is True for sid in ends)
        cap=shear_resistance(steel,panel_length_mm=a,panel_stiffeners_prescriptively_eligible=qualification)
        if not cap.source_numeric_limits_pass:raise ValueError('Shear source material domain violated')
        demand=worst[region['region_id']]['demand_abs_kn'];capacity=cap.VRd_N/1000
        u=demand/capacity;ok=demand<=capacity
        check=dict(id='regional_web_vertical_shear:'+region['region_id'],demand=demand,capacity=capacity,
            unit='kN',utilization=u,status='PASS' if ok else 'INCONCLUSIVE',sufficient_bound=True,
            sufficient_bound_satisfied=ok,actual_failure_proven=False,source=SHEAR_SOURCE,
            region=region,selected_kv=cap.kv,panel_shear_eligibility=qualification,
            governing_case_id=worst[region['region_id']]['governing_case_id'],
            prepared_signature=worst[region['region_id']]['prepared_signature'])
        checks.append(check)
        regions.append(dict(region=region,selected_kv=cap.kv,selected_VRd_N=cap.VRd_N,
            baseline_kv=cap.baseline_kv,baseline_VRd_N=cap.baseline_VRd_N,
            applied_benefit_N=cap.applied_benefit_N,panel_kv_selected=cap.panel_kv_selected,
            panel_shear_eligibility=qualification,endpoint_shear_eligibility={sid:eligible[sid] for sid in ends if sid is not None},
            demand_abs_kn=demand,check=check,resistance=asdict(cap),governing_demand=worst[region['region_id']],
            station_complete=False,whole_member_qualified=False))
    passed=all(c['sufficient_bound_satisfied'] for c in checks)
    return dict(schema=SCHEMA,status='COMPONENT_CHECKS_SATISFIED' if passed else 'INCONCLUSIVE',
        checks=checks,regions=regions,pending=[],errors=[],input_valid=True,
        component_bounds_satisfied=passed,actual_failure_proven=False,verification_executed=True,
        function_specific_endpoint_eligibility=eligible,sign_family_case_counts=counts,
        full_uls_case_count=len(demands),all_translations=True,complete_spatial_partition=True,
        shared_boundaries_both_sides=True,no_tension_field_credit=True,
        no_global_EI_J_Cw_or_stability_credit=True,station_complete=False,whole_member_qualified=False,
        project_signature=signature(project.to_dict()),prescriptive_signature=signature(assembly.to_dict()),
        replacement_obligation=REPLACED_CHECK,
        scope='Regional web shear resistance only. Transfer, fatigue, local stresses and stability remain independently mandatory. End regions and physical projections have no panel credit.')


def replace_bare_shear_obligation(section_components, regional):
    """Replace one identified obligation, not a blanket status/pending filter."""
    from ..pipeline import _outcome
    rows=section_components.get('checks')
    if not isinstance(rows,(list,tuple)) or sum(r.get('id')==REPLACED_CHECK for r in rows)!=1:
        raise ValueError('Exactly one known bare-web shear obligation required')
    if (regional.get('schema')!=SCHEMA or regional.get('replacement_obligation')!=REPLACED_CHECK
        or regional.get('input_valid') is not True or regional.get('complete_spatial_partition') is not True
        or not regional.get('checks')):raise ValueError('Complete current regional replacement required')
    retained=[deepcopy(r) for r in rows if r['id']!=REPLACED_CHECK]
    if not retained:raise ValueError('Other section obligations cannot be omitted')
    for obj in (section_components,regional):
        if any(not isinstance(obj.get(key,()),(list,tuple)) for key in ('pending','errors')):
            raise ValueError('Structured pending/error inventories required')
    pending=list(section_components.get('pending',()))+list(regional.get('pending',()))
    for obj,label in ((section_components,'original'),(regional,'regional')):
        if obj.get('unresolved_mode_ids'):
            if not isinstance(obj['unresolved_mode_ids'],(list,tuple)):raise ValueError('Structured unresolved modes required')
            pending.extend(label+' unresolved mechanism: '+str(v) for v in obj['unresolved_mode_ids'])
    if regional.get('status') not in ('COMPONENT_CHECKS_SATISFIED','INCONCLUSIVE','FAIL'):
        pending.append('Unresolved regional aggregate status: '+str(regional.get('status')))
    if section_components.get('status') not in ('COMPONENT_CHECKS_SATISFIED','INCONCLUSIVE','FAIL'):
        pending.append('Unresolved original component aggregate status: '+str(section_components.get('status')))
    failure_reported=section_components.get('actual_failure_proven') is True or section_components.get('status')=='FAIL'
    failure_rows=[r for r in rows if r.get('actual_failure_proven') is True or r.get('status')=='FAIL']
    unattributed_failure=(failure_reported and not failure_rows) or regional.get('actual_failure_proven') is True or regional.get('status')=='FAIL'
    errors=list(section_components.get('errors',()))+list(regional.get('errors',()))
    checks=retained+deepcopy(regional['checks'])
    # Original aggregate may be inconclusive only because of the replaced bare
    # check. Re-evaluate every retained check, preserving unknown states/errors.
    state=_outcome([dict(status='FAIL' if unattributed_failure else 'COMPONENT_CHECKS_SATISFIED',
        actual_failure_proven=unattributed_failure,checks=checks,pending=pending,errors=errors)])
    return dict(kind='CMAA_origin_NBR8800_section_components_regional_shear',
        status='COMPONENT_CHECKS_SATISFIED' if state=='SATISFIED' else state,checks=checks,
        pending=pending,errors=errors,component_bounds_satisfied=state=='SATISFIED',
        actual_failure_proven=state=='FAIL',all_translations=True,complete_continuous_SK_box=True,
        whole_design_complete=False,known_obligation_replaced=REPLACED_CHECK,
        baseline_section_signature=signature(section_components),regional_shear_signature=signature(regional),
        retained_component_ids=[r['id'] for r in retained],
        original_bare_shear_diagnostic=deepcopy(next(r for r in rows if r['id']==REPLACED_CHECK)))
