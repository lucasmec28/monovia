"""Presentation of the adopted physical TOP intermediate route, never a solver.

The caller owns current-result/signature validation. This module neither signs
results nor promotes component snapshots to a complete calculation. It returns
legacy-compatible section dictionaries and (caption, PNG bytes) drawings only.
It is deliberately not imported by the legacy bare-member report.
"""
from __future__ import annotations

from collections.abc import Mapping
from dataclasses import asdict
from fractions import Fraction
from io import BytesIO
from math import acos, cos, isfinite, pi, sin

from .detail import _physical


MISSING = 'Não disponível'
EXCEEDED = 'Calculado: limite conservador excedido'
SCOPE_LABELS = {
    'normal_uls_strength': 'Resistência global nominal',
    'bare_web': 'Alma sob rodas e reações',
    'supplementary_stability': 'Estabilidade complementar',
    'intermediate_geometry': 'Geometria e prescrições',
    'intermediate_interruption_sign': 'Sinal longitudinal no término',
    'intermediate_local_static': 'Pressão local por região',
    'intermediate_G_transfer': 'Peso próprio e ligação local',
    'intermediate_static_interaction': 'Interação estática no receptor',
    'nominal_fatigue': 'Fadiga nominal direcional',
    'cmaa_service': 'Deslocamentos no vão',
}
CHECK_LABELS = {
    'nominal_normal_yield': 'Tensão normal nominal',
    'major_local_bending': 'Flexão maior',
    'equivalent_minor_local_bending': 'Flexão menor equivalente',
    'bare_web_vertical_shear': 'Cisalhamento da alma',
    'top_flange_lateral_shear': 'Cisalhamento da mesa superior',
    'bottom_flange_lateral_shear': 'Cisalhamento da mesa inferior',
    'gross_axial_tension_yield': 'Tração axial',
    'isolated_axial_compression': 'Compressão axial',
    'nominal_shear_model_box': 'Cisalhamento nominal',
    'all_wheels_yield': 'Alma sob rodas: escoamento',
    'all_wheels_cripple': 'Alma sob rodas: enrugamento',
    'supplementary_C1': 'Interação C1',
    'supplementary_C2': 'Interação C2',
    'CMAA74_vertical': 'Flecha vertical CMAA',
    'CMAA74_horizontal': 'Flecha lateral CMAA',
    'NBR10084_vertical': 'Flecha vertical NBR',
    'NBR10084_horizontal': 'Flecha lateral NBR',
}
REGION_LABELS = {
    'left_projection': 'Projeção esquerda',
    'right_projection': 'Projeção direita',
}
FATIGUE_LABELS = {
    'top': 'Mesa superior ordinária', 'bottom': 'Mesa inferior ordinária',
    'web': 'Alma ordinária',
    'straight_vertical_toe': 'Pé reto do filete na alma',
    'lower_fillet_termination': 'Término inferior do filete',
    'upper_fillet_termination': 'Término superior do filete',
    'cjp_flange_receiver': 'Mesa receptora da CJP',
}


def _region_label(value):
    """Translate display labels without changing recorded region identities."""
    return REGION_LABELS.get(str(value), str(value))


def _mapping(value):
    return value if isinstance(value, Mapping) else {}


def _number(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool) and isfinite(value)


def _fmt(value, digits=3):
    """Portuguese presentation only; no rounding is fed back to calculation."""
    if not _number(value):
        return MISSING
    if 0 < abs(value) < .5 * 10**-digits:
        return ('−' if value < 0 else '') + '<' + f'{10**-digits:.{digits}f}'.replace('.', ',')
    return f'{value:,.{digits}f}'.replace(',', '~').replace('.', ',').replace('~', '.')


def _pending(row):
    return bool(row.get('pending') or row.get('errors') or row.get('input_valid') is False)


def intermediate_status(row):
    """A computed excess and a missing calculation must never share a label."""
    row = _mapping(row)
    status = str(row.get('status', ''))
    if row.get('actual_failure_proven') is True or status == 'FAIL':
        return 'Falha identificada no critério avaliado'
    utilization = row.get('utilization', row.get('combined_utilization_upper_bound'))
    exceeded = (row.get('sufficient_bound_exceeded') is True
        or row.get('bound_exceeded_not_physical_failure') is True
        or row.get('any_sufficient_bound_exceeded') is True
        or _number(utilization) and utilization > 1
        or 'INCONCLUSIVE' in status or 'NOT_SATISFIED' in status
        or status in ('NOT_SUFFICIENT', 'COMPONENT_EXCEEDED'))
    if exceeded:
        return EXCEEDED + ('; fechamento pendente' if _pending(row) else '')
    if _pending(row) or status in ('PENDING', 'INPUT_REQUIRED', 'INVALID_INPUT'):
        return 'Calculado parcialmente; fechamento pendente' if row.get('verification_executed') else 'Dados ou evidência pendentes'
    if status in ('PASS', 'SUFFICIENT') or ('SATISFIED' in status and 'NOT_SATISFIED' not in status) or row.get('criterion_satisfied') is True:
        return 'Calculado: critério atendido'
    if row.get('verification_executed') is True:
        return 'Calculado; conclusão não demonstrada'
    return 'Dados ou evidência pendentes'


def _section(title, paragraphs, headers=(), rows=()):
    return dict(title=title, paragraphs=list(paragraphs), headers=list(headers), rows=[list(v) for v in rows])


def _governing(checks):
    """Return a complete recorded row; never splice unrelated demand/capacity."""
    valid = [r for r in checks if isinstance(r, Mapping) and (_number(r.get('utilization'))
        or r.get('actual_failure_proven') is True or r.get('status') == 'FAIL')]
    return max(valid, key=lambda r: (r.get('actual_failure_proven') is True or r.get('status') == 'FAIL',
        r['utilization'] if _number(r.get('utilization')) else float('inf')), default=None)


def _check_row(label, record):
    if not record:
        return [label, MISSING, MISSING, MISSING, 'Dados ou evidência pendentes']
    unit = record.get('unit', record.get('units', ''))
    demand = record.get('demand', record.get('demand_mpa', record.get('upper_bound_mm')))
    capacity = record.get('capacity', record.get('capacity_mpa', record.get('limit_mm')))
    scale, unit = (1000., 'kN') if unit == 'N' else (1e6, 'kN·m') if unit == 'Nmm' else (1., unit)
    return [label + (' [' + unit + ']' if unit else ''),
        _fmt(demand/scale if _number(demand) else None),
        _fmt(capacity/scale if _number(capacity) else None),
        _fmt(record.get('utilization')), intermediate_status(record)]


def _transfer_group(check):
    key = str(check.get('check_id', ''))
    if 'flange_physical_strip' in key: return 'Faixa física da mesa receptora'
    if 'CJP_' in key: return 'CJP superior verdadeira'
    if 'weld_resultant' in key: return 'Metal dos filetes da alma'
    if 'web_footprint' in key or 'web_receiver' in key: return 'Alma receptora'
    if 'plate_footprint' in key: return 'Metal-base junto aos filetes'
    if 'plate_core' in key: return 'Estabilidade transversal da chapa'
    if 'plate_combined' in key: return 'Rasgamento da chapa'
    if 'plate_root' in key: return 'Raiz ativa da chapa'
    if 'plate_top' in key: return 'Ligamento superior da chapa'
    return 'Seção receptora do par'


def _fatigue_rows(fatigue):
    groups = {}
    for point in fatigue.get('point_results', ()):
        inp, coverage = _mapping(point.get('input')), _mapping(point.get('adapter_coverage'))
        detail = _mapping(inp.get('detail'))
        key = detail.get('location') or coverage.get('wall') or 'other'
        bound = _mapping(point.get('bound'))
        u = bound.get('combined_utilization_upper_bound')
        old = groups.get(key)
        incomplete = _pending(point) or not _number(u) or bool(old and old.get('pending'))
        rank = (point.get('actual_failure_proven') is True or point.get('status') == 'FAIL', u if _number(u) else -1.)
        old_rank = (old.get('actual_failure_proven') is True or old.get('status') == 'FAIL',
            old['utilization'] if _number(old.get('utilization')) else -1.) if old else None
        if old is None or rank > old_rank:
            identity = _mapping(_mapping(inp.get('plane')).get('identity'))
            station = identity.get('station_id')
            region = _mapping(inp.get('plane')).get('region_id', '').split(':')[0]
            groups[key] = dict(utilization=u, status=point.get('status'), pending=point.get('pending'), verification_executed=_number(u),
                errors=point.get('errors'), actual_failure_proven=point.get('actual_failure_proven'),
                identity=station or region or 'Região nominal', capacity=_mapping(point.get('capacity')),
                plane=_mapping(_mapping(inp.get('plane')).get('nominal_plane') or inp.get('plane')),
                components=_mapping(point.get('planar_components')))
        if incomplete:
            groups[key]['pending'] = ['Incomplete point/detail evidence retained in the complete result']
    rows = []
    for key, r in groups.items():
        cap = r['capacity']
        limits = [_fmt(cap.get(k)) for k in ('normal_x_capacity_mpa', 'normal_y_capacity_mpa', 'shear_capacity_mpa')]
        parallel = r['components'].get('sigma_y')
        interval = _mapping(r['plane'].get('tensor_intervals_mpa')).get(parallel)
        if cap.get('no_parallel_detail_class_claimed') is True and cap.get('normal_y_capacity_mpa') is None and interval in ([0., 0.], (0., 0.)):
            limits[1] = 'Não mobilizado'
        limits = ' / '.join(limits)
        rows.append([FATIGUE_LABELS.get(key, 'Outro detalhe nominal'), _region_label(r['identity']), limits,
            _fmt(r['utilization']), intermediate_status(r)])
    return rows


def _sign_rows(result):
    rows = []
    family = _mapping(result.get('intermediate_NBR_family'))
    sources = [('NBR', family.get('sign_case_results', ())),
               ('CMAA/NBR', _mapping(result.get('intermediate_CMAA_sign')).get('results', ()))]
    for label, cases in sources:
        bounds = {}
        for case in cases:
            patches = case.get('patch_results')
            if patches is None:
                patches = [p for s in case.get('station_results', ()) for p in s.get('patch_results', ())]
            for patch in patches:
                intervals = patch.get('sigma_x_exact_ratio') or _mapping(patch.get('certificate')).get('sigma_x_exact_ratio')
                try:
                    lower = Fraction(*intervals[0])
                except (TypeError, ValueError, ZeroDivisionError, IndexError):
                    continue
                key = patch.get('station_id', 'Estação')
                bounds[key] = min(lower, bounds.get(key, lower))
        for station, lower in sorted(bounds.items()):
            # A display rounded to zero must not hide a strictly negative sign.
            rows.append([station, label, _fmt(float(lower)),
                'Não compressivo no limite nominal' if lower >= 0 else 'Limite nominal inclui compressão; domínio não demonstrado'])
        if not bounds:
            rows.append(['Todas', label, MISSING, 'Dados ou evidência pendentes'])
    return rows


def intermediate_report_sections(project, result):
    """Compact Word sections from physical inputs and recorded component results.

    No assert_current_result is called here: this module can also present clearly
    labelled component snapshots. The integrating exporter must validate a full
    result before calling it. Input/output mappings are never modified.
    """
    if project.intermediates is None:
        raise ValueError('Physical intermediate inputs are required for this presentation')
    if not isinstance(result, Mapping):
        raise TypeError('Recorded result mapping required')
    layout = project.intermediates.layout
    beam = layout.beam
    stations = sorted(layout.stations, key=lambda s: s.x_mm)
    prescriptive = _mapping(result.get('intermediate_prescriptive'))
    station_results = {s['station_id']: s for s in prescriptive.get('stations', ())}
    transfer = _mapping(result.get('intermediate_selfweight_transfer'))
    family = _mapping(result.get('intermediate_NBR_family'))
    fatigue = _mapping(family.get('fatigue') or result.get('nbr_fatigue'))
    scopes = _mapping(result.get('scopes'))
    identity = ('EXEMPLO SINTÉTICO. NÃO É UM PROJETO REAL.'
        if project.identity == 'synthetic_example' else 'Projeto informado; escopo nominal de cálculo.')
    scope_rows = [[label, intermediate_status(scopes.get(key))] for key, label in SCOPE_LABELS.items()
        if key != 'intermediate_static_interaction' or key in scopes]
    # New finite scopes may be added by the compositor before this formatter.
    # Never drop their outcome because their stable ID is not yet translated.
    for key, value in scopes.items():
        if key not in SCOPE_LABELS:
            label = str(_mapping(value).get('label') or 'Verificação complementar')
            if '.py' in label or '/' in label or '\\' in label:
                label = 'Verificação complementar'
            scope_rows.append([label, intermediate_status(value)])
    geometry_rows, joint_rows = [], []
    for s in stations:
        geo, p = _physical(beam, s), s.pair
        record = _mapping(station_results.get(s.station_id))
        d = _mapping(record.get('detail'))
        gap = geo['weld_low_z'] - beam.lower_root_toe_z_mm
        geometry_rows.append([s.station_id, _fmt(s.x_mm/1000),
            '2 × ' + _fmt(p.outstand_mm) + ' × ' + _fmt(p.thickness_mm),
            _fmt(p.cope_radius_mm), _fmt(gap)])
        joint_rows.append([s.station_id,
            _fmt(min(p.thickness_mm, beam.flange_thickness_mm)) + ' / ' + _fmt(geo['cjp_length']),
            _fmt(s.web_fillet.leg_mm) + ' / ' + _fmt(geo['web_length']),
            _fmt(p.bottom_z_mm) + ' / ' + _fmt(geo['weld_low_z']),
            (_fmt(d.get('gap_weld_min_mm')) + ' a ' + _fmt(d.get('gap_weld_max_mm'))) if d else MISSING])
    region_rows = []
    selected_regions = _mapping(result.get('intermediate_regional_shear')).get('regions')
    for entry in (selected_regions if isinstance(selected_regions, (list, tuple)) and selected_regions else prescriptive.get('regions', ())):
        r = entry['region']; panel = r.get('physical_panel_spacing_mm') is not None
        region_rows.append([_region_label(r['region_id']) + ' · ' + _fmt(r['left_mm']/1000) + '–' + _fmt(r['right_mm']/1000) + ' m',
            (str(r['left_station_id']) + '–' + str(r['right_station_id'])) if panel else 'Região externa: apoio ≠ chapa',
            _fmt(r.get('physical_panel_spacing_mm')) if panel else 'Não se aplica',
            _fmt(entry.get('selected_kv')),
            _fmt(entry['selected_VRd_N']/1000) if _number(entry.get('selected_VRd_N')) else MISSING])
    if not region_rows:
        region_rows = [['Inventário calculado', 'Dados ou evidência pendentes', MISSING, MISSING, MISSING]]
    governors = []
    global_result = _mapping(result.get('cmaa_strength'))
    for key, label in [('section_components', 'Resistência global'), ('bare_web', 'Alma local'), ('stability', 'Estabilidade EN C.2')]:
        selected = result.get('assessed_section_components') if key == 'section_components' else None
        record = _governing(_mapping(selected if isinstance(selected, Mapping) else global_result.get(key)).get('checks', ()))
        check_name = ('Cisalhamento regional da alma' if str(record.get('id', '')).startswith('regional_web_vertical_shear:') else CHECK_LABELS.get(record.get('id'), 'Critério governante')) if record else ''
        governors.append(_check_row(label + (' · ' + check_name if check_name else ''), record))
    local_groups = {}
    for case in family.get('static_case_results', ()):
        for check in case.get('checks', ()):
            region = _mapping(check.get('region')).get('region_id', 'Região')
            local_groups.setdefault(region, []).append(dict(check, unit='MPa'))
    governors.extend(_check_row('Cisalhamento · ' + _region_label(r.get('region', {}).get('region_id', 'Região')), r) for r in _mapping(result.get('intermediate_regional_shear')).get('checks', ()))
    governors.extend(_check_row('Pressão local · ' + _region_label(k), _governing(v)) for k, v in local_groups.items())
    for check in _mapping(result.get('service')).get('checks', ()):
        governors.append(_check_row(CHECK_LABELS.get(check.get('id'), 'Restrição de deslocamento'), dict(check, unit='mm')))
    mass_rows, transfer_groups = [], {}
    for station in transfer.get('stations', ()):
        for connection in station.get('connections', ()):
            label = str(station['station_id']) + (' · lado −y' if connection['side'] < 0 else ' · lado +y')
            minimum = next((c.get('required_Fz_N') for c in connection.get('cases', ()) if c.get('replaces_real_G_locally')), None)
            mass_rows.append([label, _fmt(connection.get('mass_kg')),
                _fmt(connection['G_characteristic_N']/1000) if _number(connection.get('G_characteristic_N')) else MISSING,
                _fmt(connection['G_design_N']/1000) if _number(connection.get('G_design_N')) else MISSING,
                _fmt(minimum/1000) if _number(minimum) else MISSING])
            for case in connection.get('cases', ()):
                basis = 'mínimo local' if case.get('replaces_real_G_locally') else 'G real'
                for check in case.get('checks', ()):
                    transfer_groups.setdefault(_transfer_group(check), []).append(dict(check, presentation_case=label+' · '+basis))
        for check in station.get('pair_receiver_checks', ()):
            transfer_groups.setdefault(_transfer_group(check), []).append(dict(check, presentation_case=str(station['station_id'])+' · par'))
    transfer_rows = []
    for label, checks in transfer_groups.items():
        record = _governing(checks)
        transfer_rows.append(_check_row(label + ' · ' + record['presentation_case'], record))
    if not mass_rows:
        mass_rows = [['Inventário de massa e transferência', MISSING, MISSING, MISSING, MISSING]]
    fabrication = []
    for s in stations:
        rec = _mapping(station_results.get(s.station_id))
        fabrication.append(s.station_id + ': ' + ('requisitos de projeto especificados' if _mapping(rec.get('detail')).get('design_requirements_satisfied') is True else 'especificação do detalhe não demonstrada') + '.')
    return [
        _section('I1. Intermediários TOP: método e escopo', [identity,
            'Par de chapas simétricas para estabilização de painéis. Detalhe AISE/Fisher: CJP superior verdadeira, filetes contínuos na alma e término livre antes da mesa inferior.',
            'Global: origens CMAA 74, resistência NBR 8800, analogia CISC e estabilidade complementar EN C.2. Local: NBR 10084; fadiga selecionada: NBR 8400, interação D.5 por plano e vida classificada.',
            'Limite conservador excedido indica resultado inconclusivo pela idealização adotada, não prova de falha física. Dados e verificações pendentes são indicados separadamente.',
            'As chapas não recebem crédito de EI/J/Cw nem reduzem o comprimento de flambagem. Apoios, apoio local de contato, garfos e contraventamentos são funções distintas.'], ['Escopo', 'Resultado'], scope_rows),
        _section('I2. Geometria física dos pares', [
            'x é medido a partir do apoio esquerdo. Cada estação contém duas chapas, uma em cada face da alma; b é a largura saliente e t a espessura longitudinal.',
            'g é a distância do pé real da concordância laminada inferior ao ponto efetivamente mais baixo da solda, não à face da mesa nem somente à borda da chapa.'],
            ['Estação', 'x [m]', 'Par: b × t [mm]', 'Recorte R [mm]', 'g real [mm]'], geometry_rows),
        _section('I3. Juntas e términos', [
            'CJP em T com duplo bisel e penetração total: garganta efetiva = menor espessura ligada. Não há filete equivalente nem chapa de espera permanente; reforço externo não aumenta essa garganta.',
            'Dois filetes por chapa, quatro por estação, contínuos no trecho real de contato. z = 0 na face externa inferior; término da chapa, término da solda e tolerâncias são distintos.',
            'Exigir 4tw ≤ g ≤ 6tw em ambas as faces, inclusive tolerâncias. A folga inferior não é o recorte de acesso superior.', *fabrication,
            'Requisitos das juntas: EPS/WPS, acesso, fusão da raiz, acabamento, zonas Q.E. dos términos e UT/RT.'],
            ['Estação', 'CJP: garganta / L [mm]', 'Filete: perna / L [mm]', 'z chapa / solda [mm]', 'g com tolerâncias [mm]'], joint_rows),
        _section('I4. Painéis e regiões externas', [
            'Somente duas estações físicas delimitam a distância a. Apoio/forquilha não é uma segunda chapa. Regiões externas mantêm kv = 5,34, sem espaçamento fictício nem benefício automático.',
            'O kv regional depende de ambos os extremos físicos qualificados por material, detalhe, Is, esbeltez e sinal longitudinal. Transferência, fadiga e demais critérios permanecem obrigatórios e independentes.',
            'São mostrados os valores efetivamente selecionados, não os candidatos favoráveis. Is usa a menor seção física das chapas, sem faixa de bearing. Se a alma já atinge o limite plástico, aumentar kv não aumenta VRd.'],
            ['Região e posição', 'Fronteiras', 'a [mm]', 'kv adotado', 'VRd [kN]'], region_rows),
        _section('I5. Valores governantes do membro', [
            'Demanda, limite e U são mantidos na mesma verificação registrada. U é adimensional; limite 1. Envelopes não identificam uma posição física crítica. A lista integral permanece no JSON.'],
            ['Verificação e unidade', 'Demanda', 'Limite', 'U', 'Resultado'], governors),
        _section('I6. Peso próprio e mínimo estático local', [
            'Massa física total das chapas e depósitos: ' + _fmt(transfer.get('total_mass_kg')) + ' kg. Recortes, preparo, reposição e reforços pertencem ao inventário real, sem dupla contagem.',
            'Grupo elástico nominal completo: dois filetes e CJP por chapa, coordenadas físicas e partes conectadas nominalmente rígidas; sem ganho direcional. Cada tipo de solda mantém sua resistência própria.',
            'NBR 8800 §6.1.5.2: max(Gd real, 45 kN), uma vez por ligação de chapa, no sentido da gravidade e na mesma linha física de força. O mínimo substitui G somente no ensaio estático local; não é massa, carga global adicional ou faixa de fadiga.',
            'A capacidade da faixa física da mesa é avaliada por idealização suficiente conservadora.'],
            ['Chapa', 'Massa [kg]', 'Gk real [kN]', 'Gd real [kN]', 'Ensaio local [kN]'], mass_rows),
        _section('I7. Transferência local: governantes', [
            'Resumo por mecanismo com o caso governante identificado. O teste do mínimo local não é somado ao caso de G real.',
            'Situação do fechamento local: ' + intermediate_status(scopes.get('intermediate_G_transfer', transfer)) + '.'],
            ['Mecanismo e caso', 'Demanda', 'Limite', 'U', 'Resultado'], transfer_rows),
        _section('I8. Sinal longitudinal no término', [
            'Menor limite de σx em todas as regiões verificadas da estação e posições de passagem; tração positiva. Uma extensão espacial ou união de casos não é ponto crítico testemunhado.',
            'O domínio não compressivo deve ser demonstrado nas duas famílias pertinentes, nas bordas inferiores e nos términos reais. Não se substitui essa verificação pelo sinal do momento maior.'],
            ['Estação', 'Família', 'σx inferior [MPa]', 'Leitura do limite'], _sign_rows(result)),
        _section('I9. Fadiga nominal selecionada', [
            'NBR 8400-2: interação D.5, κ = −1 conservador e classes direcionais por detalhe/plano. A classificação de serviço declarada não é inferida de uma história de ciclos.',
            'Os limites Ax / Ay / T referem-se aos dois eixos locais e cisalhamento do plano indicado no resultado detalhado. U conserva a interação original; não é uma faixa equivalente de von Mises.',
            'Máximo registrado por família de detalhe, sem inventar história temporal ou tensor concomitante. G fixo é retirado das faixas. W0 não é transferido aos novos términos ou receptores.',
            'O JSON reúne faces, planos, categorias, ações e a lista completa de verificações.'],
            ['Detalhe', 'Estação / região', 'Ax / Ay / T [MPa]', 'U ≤ 1', 'Resultado'], _fatigue_rows(fatigue)),
    ]


def _finish(figure, dpi=160):
    stream = BytesIO()
    figure.savefig(stream, format='png', dpi=dpi, facecolor='white', bbox_inches='tight')
    return stream.getvalue()


def intermediate_geometry_figures(project):
    """Return matplotlib figures with true physical coordinates, no load case.

    The in-plane drawing shows the two x-face fillets per plate in projection;
    CJP is a distinct horizontal joint, never a fillet symbol or equivalent leg.
    """
    from matplotlib.figure import Figure
    from matplotlib.patches import Polygon, Rectangle
    if project.intermediates is None:
        raise ValueError('Physical intermediate inputs required')
    layout = project.intermediates.layout
    beam, ordered = layout.beam, sorted(layout.stations, key=lambda s: s.x_mm)
    navy, blue, red, green, grey = '#17324D', '#DCE8F0', '#AE452D', '#287561', '#6B7280'
    fig = Figure(figsize=(10, 3.1), layout='constrained'); ax = fig.subplots()
    span = project.structure.span_m * 1000
    boundaries = [0., *(s.x_mm for s in ordered), span]
    for i, (left, right) in enumerate(zip(boundaries, boundaries[1:])):
        panel = 0 < i < len(boundaries)-2
        ax.add_patch(Rectangle((left/1000, .15), (right-left)/1000, .22,
            facecolor=blue if panel else '#F1F2F4', edgecolor='white'))
        ax.text((left+right)/2000, .26, ('Painel físico\na = '+_fmt(right-left)+' mm') if panel else 'Região externa\nsem crédito de painel',
            ha='center', va='center', fontsize=8, color=navy)
    ax.plot([layout.beam_start_mm/1000, layout.beam_end_mm/1000], [.5, .5], color=navy, lw=5)
    for s in ordered:
        ax.plot([s.x_mm/1000]*2, [.43, .61], color=red, lw=2)
        ax.text(s.x_mm/1000, .67, s.station_id+' · '+_fmt(s.x_mm/1000)+' m', ha='center', fontsize=9, color=navy)
    width = span/1000*.014
    for x, name in [(0., 'A'), (span/1000, 'B')]:
        ax.add_patch(Polygon([(x,.48),(x-width,.40),(x+width,.40)], facecolor='white', edgecolor=navy))
        ax.text(x, .03, 'Apoio '+name, ha='center', fontsize=9, color=navy)
    ax.set(xlim=(-span/1000*.04,span/1000*1.04), ylim=(-.04,.83))
    ax.set_axis_off(); ax.set_title('Posições físicas: estações não são apoios', loc='left', color=navy, fontsize=12)
    figures = [('Elevação física dos pares e regiões; sem posição crítica de rodas', fig)]
    # One distinct drawing per physical shape, not one misleading typical shape.
    grouped = {}
    for s in ordered:
        key = repr((asdict(s.pair), asdict(s.web_fillet), asdict(s.cjp)))
        grouped.setdefault(key, []).append(s)
    for same in grouped.values():
        s = same[0]; p = s.pair; g = _physical(beam, s)
        fig = Figure(figsize=(10, 6.5), layout='constrained')
        ax, zoom = fig.subplots(1, 2, gridspec_kw={'width_ratios':[1.3,1]})
        tw, tf, r, d, bf = beam.web_thickness_mm, beam.flange_thickness_mm, beam.root_radius_mm, beam.depth_mm, beam.flange_width_mm
        def draw_section(axis):
            for z in (0., d-tf):
                axis.add_patch(Rectangle((-bf/2,z),bf,tf,facecolor='#E3E6E9',edgecolor=navy,lw=.8))
            axis.add_patch(Rectangle((-tw/2,tf),tw,d-2*tf,facecolor='#E3E6E9',edgecolor=navy,lw=.8))
            for side in (-1,1):
                # Real circular rolled roots: toe lies at tf+r, not at tf.
                for lower in (True,False):
                    center_z = tf+r if lower else d-tf-r
                    angles = [pi+pi/2*i/32 for i in range(33)] if lower else [pi-pi/2*i/32 for i in range(33)]
                    curve = [(side*(tw/2+r+r*cos(a)),center_z+r*sin(a)) for a in angles]
                    corner = (side*tw/2, tf if lower else d-tf)
                    axis.add_patch(Polygon([corner,*curve],closed=True,facecolor='#E3E6E9',edgecolor=navy,lw=.8))
                theta = acos(s.cjp.root_gap_mm/p.cope_radius_mm)
                arc = [(side*(tw/2+p.cope_radius_mm*sin(a)),g['top_z']-p.cope_radius_mm*cos(a))
                       for a in [theta*i/48 for i in range(49)]]
                contour = [(side*tw/2,p.bottom_z_mm),(side*(tw/2+p.outstand_mm),p.bottom_z_mm),
                    (side*(tw/2+p.outstand_mm),g['plate_top_z']),*reversed(arc)]
                axis.add_patch(Polygon(contour,closed=True,facecolor=blue,edgecolor=navy,lw=1))
                axis.plot([side*(tw/2+g['cope_start_u']),side*(tw/2+p.outstand_mm)], [g['top_z']]*2,color=red,lw=3)
                axis.plot([side*tw/2]*2,[g['weld_low_z'],g['weld_high_z']],color=green,lw=3)
        draw_section(ax); draw_section(zoom)
        ax.set_aspect('equal'); ax.set_xlim(-bf*.75,bf*.8); ax.set_ylim(-20,d+35); ax.set_axis_off()
        ax.set_title(' / '.join(v.station_id for v in same)+' · par simétrico',fontsize=11,color=navy)
        ax.annotate('CJP plena\nsem filete equivalente', (tw/2+p.outstand_mm*.8,g['top_z']),
            xytext=(bf*.15,d*.85), fontsize=9, color=red, arrowprops={'arrowstyle':'-','color':red})
        ax.annotate('Recorte real\nR = '+_fmt(p.cope_radius_mm)+' mm',(tw/2+p.cope_radius_mm*.7,g['top_z']-p.cope_radius_mm*.7),
            xytext=(-bf*.7,d*.70),fontsize=8,color=navy,arrowprops={'arrowstyle':'-','color':navy})
        ax.annotate('Filetes contínuos\n2 por chapa, em projeção', (tw/2,(g['weld_low_z']+g['weld_high_z'])/2),
            xytext=(bf*.1,d*.43),fontsize=8,color=green,arrowprops={'arrowstyle':'-','color':green})
        ax.text(-bf*.65,d*.27,'2 chapas\nb = '+_fmt(p.outstand_mm)+' mm\nt = '+_fmt(p.thickness_mm)+' mm',fontsize=8,color=navy)
        gap = g['weld_low_z']-beam.lower_root_toe_z_mm
        xdim = tw/2+p.outstand_mm*.72
        for z in (beam.lower_root_toe_z_mm,g['weld_low_z']):
            zoom.plot([tw/2,xdim+8],[z,z],color=grey,lw=.6,ls='--')
        zoom.annotate('',(xdim,beam.lower_root_toe_z_mm),(xdim,g['weld_low_z']),arrowprops={'arrowstyle':'|-|','color':red})
        zoom.text(xdim+6,(beam.lower_root_toe_z_mm+g['weld_low_z'])/2,
            'g = '+_fmt(gap)+' mm\n4tw a 6tw',fontsize=9,color=red,va='center')
        zoom.annotate('Pé real da concordância\nz = '+_fmt(beam.lower_root_toe_z_mm)+' mm', (tw/2,beam.lower_root_toe_z_mm),
            xytext=(tw/2+p.outstand_mm*.25,tf*.45),fontsize=8,color=navy,arrowprops={'arrowstyle':'-','color':navy})
        zoom.annotate('Ponto mais baixo da solda', (tw/2,g['weld_low_z']),
            xytext=(tw/2+p.outstand_mm*.2,g['weld_low_z']+gap*.32),fontsize=8,color=green,arrowprops={'arrowstyle':'-','color':green})
        zoom.annotate('Borda da chapa\nz = '+_fmt(p.bottom_z_mm)+' mm', (tw/2+p.outstand_mm,p.bottom_z_mm),
            xytext=(tw/2+p.outstand_mm*1.1,p.bottom_z_mm+gap*.57),fontsize=8,color=navy,arrowprops={'arrowstyle':'-','color':navy})
        zoom.set_aspect('equal');zoom.set_xlim(-tw,tw/2+p.outstand_mm*2.0)
        zoom.set_ylim(0,g['weld_low_z']+gap*1.05);zoom.set_axis_off();zoom.set_title('Ampliação do término inferior',fontsize=11,color=navy)
        fig.text(.5,.005,'Dimensões em mm; z = 0 na face externa inferior.',ha='center',fontsize=8,color=grey)
        figures.append(('Detalhe físico de '+' / '.join(v.station_id for v in same)+'; CJP, recorte, filetes e gap real',fig))
    return figures


def intermediate_geometry_schematics(project):
    """Legacy-compatible list of caption/PNG pairs; no files are written."""
    return [(caption, _finish(figure)) for caption, figure in intermediate_geometry_figures(project)]
