"""Physical intermediate TOP detail, not a station-resistance qualification.

Units: mm, N, MPa, kg; density kg/m3. Geometric z=0 is the external bottom
flange face. Mass records explicitly expose both that datum and centroidal z.
Only a symmetric rolled I, two symmetric transverse plates, a true circular
concave cope, continuous web fillets and a double-bevel T/CJP are modelled.
No wheel demand, bearing strip, capacity, fatigue class, stiffness/FLT credit,
P/2 force, as-built verification or virtual end-panel is produced here.

Nominal physical prisms are used, not weld effective-resistance lengths.
Actual root opening is additional metal. Groove preparation is subtracted
from the plate and replaced as a separate CJP body, so cancellation is only
an explicitly reported equal-volume/equal-density identity. Reinforcement
is deposited mass, never an addition to min(tp,tf) CJP effective throat.
The plate/deposit partition covers only the declared double-bevel wedges; it
is NOT an as-built prediction of dilution, fusion, or additional backgouging.
Any EPS/WPS removal outside those wedges requires an extended geometric
input/partition and a new mass receipt; it cannot silently cancel here.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
import hashlib
import json
import math
from numbers import Real
from typing import Literal

CONTRACT_SHA256 = "b08a4b522fa3f4fed76c26baa473dd4f1ebe05e0205b1a1008c3855f0962d9a7"
GEOMETRY_DATUM = "z_from_external_bottom_flange_mm"
MASS_DATUM = "z_relative_to_section_centroid_mm"


def _number(name, value, *, positive=False, nonnegative=False):
    if isinstance(value, bool) or not isinstance(value, Real):
        raise TypeError(f"{name} requires a real number, not {type(value).__name__}")
    try:
        result = float(value)
    except (OverflowError, ValueError) as exc:
        raise ValueError(f"{name} must be finite") from exc
    if not math.isfinite(result) or abs(result) > 1e50:
        raise ValueError(f"{name} is outside the finite supported numeric domain")
    if positive and result <= 0 or nonnegative and result < 0:
        raise ValueError(f"{name} has an invalid sign")
    return result


def _label(name, value, *, optional=False):
    if optional and value is None:
        return
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{name} requires a nonempty identity")


def _bool(name, value):
    if type(value) is not bool:
        raise TypeError(f"{name} must be a bool")


def _numeric_fields(obj, positive=(), nonnegative=(), unrestricted=()):
    for name in positive + nonnegative + unrestricted:
        object.__setattr__(obj, name, _number(name, getattr(obj, name),
            positive=name in positive, nonnegative=name in nonnegative))


def _typed(value):
    if isinstance(value, float):
        return {"float_hex": value.hex()}
    if isinstance(value, dict):
        return {key: _typed(val) for key, val in sorted(value.items())}
    if isinstance(value, (tuple, list)):
        return [_typed(val) for val in value]
    return value


@dataclass(frozen=True)
class MaterialSpec:
    material_id: str
    density_kg_m3: float = 7850.0

    def __post_init__(self):
        _label("material_id", self.material_id)
        _numeric_fields(self, positive=("density_kg_m3",))


@dataclass(frozen=True)
class RolledISection:
    depth_mm: float
    flange_width_mm: float
    flange_thickness_mm: float
    web_thickness_mm: float
    root_radius_mm: float
    root_radius_source: str
    material: MaterialSpec
    root_radius_basis: Literal["real_circular"] = "real_circular"
    root_radius_tolerance_mm: float = 0.0
    flange_thickness_tolerance_mm: float = 0.0
    web_thickness_tolerance_mm: float = 0.0
    fabrication: Literal["rolled"] = "rolled"

    def __post_init__(self):
        _numeric_fields(self, positive=("depth_mm", "flange_width_mm",
            "flange_thickness_mm", "web_thickness_mm", "root_radius_mm"),
            nonnegative=("root_radius_tolerance_mm", "flange_thickness_tolerance_mm",
                         "web_thickness_tolerance_mm"))
        _label("root_radius_source", self.root_radius_source)
        if not isinstance(self.material, MaterialSpec):
            raise TypeError("beam material must be MaterialSpec")
        if self.fabrication != "rolled" or self.root_radius_basis != "real_circular":
            raise ValueError("only an explicitly supplied real circular rolled root is accepted; never equivalent")
        if (self.web_thickness_tolerance_mm >= self.web_thickness_mm
                or self.flange_thickness_tolerance_mm >= self.flange_thickness_mm
                or self.root_radius_tolerance_mm >= self.root_radius_mm):
            raise ValueError("section tolerances cannot remove a positive physical dimension")
        rmax = self.root_radius_mm + self.root_radius_tolerance_mm
        tfmax = self.flange_thickness_mm + self.flange_thickness_tolerance_mm
        twmax = self.web_thickness_mm + self.web_thickness_tolerance_mm
        if self.depth_mm <= 2 * (tfmax + rmax) or self.flange_width_mm <= twmax + 2*rmax:
            raise ValueError("invalid rolled I-section proportions including real roots")

    @property
    def top_inner_z_mm(self):
        return self.depth_mm - self.flange_thickness_mm

    @property
    def lower_root_toe_z_mm(self):
        return self.flange_thickness_mm + self.root_radius_mm

    @property
    def clear_web_depth_8800_mm(self):
        return self.depth_mm - 2*(self.flange_thickness_mm + self.root_radius_mm)

    @property
    def inner_flange_distance_10084_mm(self):
        return self.depth_mm - 2*self.flange_thickness_mm


@dataclass(frozen=True)
class IntermediatePlatePair:
    """One physical shape mirrored about y=0; tp is thickness along x.

    Cope circle center is the theoretical web-face/top-flange intersection,
    NOT a fitted equivalent radius or a chamfer. Material occupies the
    rectangle outside that disk. A nonzero CJP root gap trims the top of the
    same disk; it never moves the actual flange/root datum.
    """
    outstand_mm: float
    thickness_mm: float
    bottom_z_mm: float
    cope_radius_mm: float
    material: MaterialSpec
    bottom_tolerance_mm: float = 0.0
    cope_radius_tolerance_mm: float = 0.0
    required_root_clearance_mm: float = 0.0
    cope_finish: Literal["ground", "machined", "unspecified"] = "unspecified"
    thermally_cut: bool = False
    thermal_cut_roughness_um: float | None = None

    def __post_init__(self):
        _numeric_fields(self, positive=("outstand_mm", "thickness_mm", "cope_radius_mm"),
            nonnegative=("bottom_tolerance_mm", "cope_radius_tolerance_mm",
                         "required_root_clearance_mm"), unrestricted=("bottom_z_mm",))
        if not isinstance(self.material, MaterialSpec):
            raise TypeError("plate material must be MaterialSpec")
        if self.cope_radius_mm - self.cope_radius_tolerance_mm < 25:
            raise ValueError("actual concave cope radius including tolerance must be at least 25 mm")
        if self.outstand_mm <= self.cope_radius_mm + self.cope_radius_tolerance_mm:
            raise ValueError("cope must leave a positive straight upper connection")
        if self.cope_finish not in ("ground", "machined", "unspecified"):
            raise ValueError("unsupported cope finish")
        _bool("thermally_cut", self.thermally_cut)
        if self.thermal_cut_roughness_um is not None:
            object.__setattr__(self, "thermal_cut_roughness_um",
                _number("thermal_cut_roughness_um", self.thermal_cut_roughness_um, nonnegative=True))


@dataclass(frozen=True)
class WebFilletSpec:
    """Four straight, square-ended equal-leg physical runs, two per plate.

    lower_setback_mm is measured from plate bottom to the ACTUAL lowest
    deposited point, not to an effective-length or nominal center marker.
    Other rounded/returned terminations need a different explicit solid.
    Q.E. end-zone and tension-region statements are design requirements only,
    never an assertion that fabrication or inspection has been performed.
    """
    leg_mm: float
    material: MaterialSpec
    lower_setback_mm: float = 0.0
    endpoint_tolerance_mm: float = 0.0
    continuous: bool = True
    termination_shape: Literal["square_ended"] = "square_ended"
    consumable_id: str | None = None
    compatibility_basis: str | None = None
    procedure_id: str | None = None
    qe_end_zone_length_mm: float | None = None
    qe_both_ends_specified: bool = False
    ends_ground_notch_free_specified: bool = False
    qe_end_zones_undercut_free_specified: bool = False
    tension_region_lamination_free_specified: bool = False

    def __post_init__(self):
        _numeric_fields(self, positive=("leg_mm",),
            nonnegative=("lower_setback_mm", "endpoint_tolerance_mm"))
        if not isinstance(self.material, MaterialSpec):
            raise TypeError("fillet material must be MaterialSpec")
        for name in ("continuous", "qe_both_ends_specified", "ends_ground_notch_free_specified",
                     "qe_end_zones_undercut_free_specified", "tension_region_lamination_free_specified"):
            _bool(name, getattr(self, name))
        if not self.continuous:
            raise ValueError("the physical first-domain web fillets must be continuous")
        if self.termination_shape != "square_ended":
            raise ValueError("only explicitly square-ended physical fillet prisms are supported")
        for name in ("consumable_id", "compatibility_basis", "procedure_id"):
            _label(name, getattr(self, name), optional=True)
        if self.qe_end_zone_length_mm is not None:
            object.__setattr__(self, "qe_end_zone_length_mm",
                _number("qe_end_zone_length_mm", self.qe_end_zone_length_mm, positive=True))


@dataclass(frozen=True)
class CJPTopSpec:
    """True T/CJP, symmetric double bevel on the plate, no permanent backing.

    Bevel angle is between the bevel face and the vertical plate face.
    Root face is the unprepared central land across plate thickness. Two
    triangular removed wedges are completely refilled by the specified
    procedure. The optional root gap is a separate deposited rectangular
    prism. Reinforcement triangles lie outside the original plate thickness.
    Gap/leg tolerances define physical envelopes; zero declares an exact
    supplied dimension, not an implicit fabrication tolerance allowance.
    """
    material: MaterialSpec
    reinforcement_leg_mm: float
    bevel_angle_deg: float = 45.0
    root_face_mm: float = 0.0
    root_gap_mm: float = 0.0
    joint_type: Literal["double_bevel_T_CJP"] = "double_bevel_T_CJP"
    permanent_backing: bool = False
    consumable_id: str | None = None
    compatibility_basis: str | None = None
    procedure_id: str | None = None
    procedure_status: Literal["qualified", "prequalified", "unspecified"] = "unspecified"
    root_method: Literal["backgouged_and_welded", "removable_backing_removed", "unspecified"] = "unspecified"
    access_description: str | None = None
    full_root_fusion_specified: bool = False
    groove_full_refill_specified: bool = False
    inspection_method: Literal["UT", "RT"] | None = None
    inspection_acceptance: str | None = None
    run_on_off_tabs_specified: bool = False
    tabs_removed_and_ends_ground_flush_specified: bool = False
    end_dams_prohibited: bool = False
    qe_weld_specified: bool = False
    edges_undercut_free_specified: bool = False
    root_removed_before_backweld_specified: bool = False
    tension_region_lamination_free_specified: bool = False
    root_gap_tolerance_mm: float = 0.0
    reinforcement_leg_tolerance_mm: float = 0.0

    def __post_init__(self):
        _numeric_fields(self, positive=("reinforcement_leg_mm", "bevel_angle_deg"),
            nonnegative=("root_face_mm", "root_gap_mm", "root_gap_tolerance_mm",
                         "reinforcement_leg_tolerance_mm"))
        if self.root_gap_tolerance_mm > self.root_gap_mm:
            raise ValueError("root opening tolerance cannot produce a negative physical gap")
        if self.reinforcement_leg_tolerance_mm >= self.reinforcement_leg_mm:
            raise ValueError("reinforcement tolerance cannot remove the positive physical leg")
        if not isinstance(self.material, MaterialSpec):
            raise TypeError("CJP material must be MaterialSpec")
        if self.joint_type != "double_bevel_T_CJP":
            raise ValueError("a real double-bevel T/CJP is required, not a fillet substitute")
        if not 0 < self.bevel_angle_deg < 90:
            raise ValueError("bevel angle must lie strictly between 0 and 90 degrees")
        for name in ("permanent_backing", "full_root_fusion_specified", "groove_full_refill_specified", "run_on_off_tabs_specified",
                     "tabs_removed_and_ends_ground_flush_specified", "end_dams_prohibited",
                     "qe_weld_specified", "edges_undercut_free_specified",
                     "root_removed_before_backweld_specified", "tension_region_lamination_free_specified"):
            _bool(name, getattr(self, name))
        if self.permanent_backing:
            raise ValueError("permanent backing is outside this adopted detail")
        for name in ("consumable_id", "compatibility_basis", "procedure_id",
                     "access_description", "inspection_acceptance"):
            _label(name, getattr(self, name), optional=True)
        if self.procedure_status not in ("qualified", "prequalified", "unspecified"):
            raise ValueError("invalid CJP procedure status")
        if self.root_method not in ("backgouged_and_welded", "removable_backing_removed", "unspecified"):
            raise ValueError("unsupported CJP root method")
        if self.inspection_method not in (None, "UT", "RT"):
            raise ValueError("only UT or RT is supported for the specified cyclic CJP")


@dataclass(frozen=True)
class IntermediateStation:
    station_id: str
    x_mm: float
    pair: IntermediatePlatePair
    web_fillet: WebFilletSpec
    cjp: CJPTopSpec
    functions: tuple[str, ...] = ("shear_panel",)

    def __post_init__(self):
        _label("station_id", self.station_id)
        _numeric_fields(self, unrestricted=("x_mm",))
        for name, kind in (("pair", IntermediatePlatePair), ("web_fillet", WebFilletSpec), ("cjp", CJPTopSpec)):
            if not isinstance(getattr(self, name), kind):
                raise TypeError(f"{name} must be {kind.__name__}; an empty physical station is not accepted")
        if not isinstance(self.functions, (tuple, list)) or tuple(self.functions) != ("shear_panel",):
            raise ValueError("the only admitted station function is shear_panel")
        object.__setattr__(self, "functions", tuple(self.functions))


def _physical(beam, station):
    if not isinstance(beam, RolledISection) or not isinstance(station, IntermediateStation):
        raise TypeError("validated RolledISection and IntermediateStation are required")
    p, w, c = station.pair, station.web_fillet, station.cjp
    zt, r, gap = beam.top_inner_z_mm, p.cope_radius_mm, c.root_gap_mm
    # Nominal solids remain the mass basis. Every fit/existence check below
    # uses coherent adverse vertices of the independently specified physical
    # tolerances; never combine an Rc-min assertion with nominal sqrt(Rc²-g²).
    r_min = r-p.cope_radius_tolerance_mm
    r_max = r+p.cope_radius_tolerance_mm
    gap_min = gap-c.root_gap_tolerance_mm
    gap_max = gap+c.root_gap_tolerance_mm
    top_min = zt-beam.flange_thickness_tolerance_mm
    bottom_min = p.bottom_z_mm-p.bottom_tolerance_mm
    bottom_max = p.bottom_z_mm+p.bottom_tolerance_mm
    root_max = beam.root_radius_mm+beam.root_radius_tolerance_mm
    reinforcement_min = c.reinforcement_leg_mm-c.reinforcement_leg_tolerance_mm
    reinforcement_max = c.reinforcement_leg_mm+c.reinforcement_leg_tolerance_mm
    if (p.outstand_mm+(beam.web_thickness_mm+beam.web_thickness_tolerance_mm)/2
            > beam.flange_width_mm/2):
        raise ValueError("plate outstand extends beyond the physical flange including tolerances")
    if gap_max >= r_min or c.root_face_mm >= p.thickness_mm:
        raise ValueError("root opening or preparation removes the entire physical joint including tolerances")
    upper_start = math.sqrt(r*r-gap*gap)
    upper_start_min = math.sqrt(r_min*r_min-gap_max*gap_max)
    if upper_start_min <= w.leg_mm:
        raise ValueError("cope does not physically separate the CJP and web fillet bodies including tolerances")
    if bottom_min <= (beam.lower_root_toe_z_mm
            + beam.flange_thickness_tolerance_mm + beam.root_radius_tolerance_mm):
        raise ValueError("plate bottom must clear the real lower root and its tolerance")
    if w.lower_setback_mm < w.endpoint_tolerance_mm:
        raise ValueError("lowest web fillet endpoint can protrude below its physical plate")
    lowest_weld = p.bottom_z_mm+w.lower_setback_mm
    upper_weld = zt-r
    lowest_weld_max = bottom_max+w.lower_setback_mm+w.endpoint_tolerance_mm
    if lowest_weld_max >= top_min-r_max or bottom_max >= top_min-r_max:
        raise ValueError("no positive continuous straight web interface remains including tolerances")
    if gap_max >= reinforcement_min:
        raise ValueError("reinforcement must reach the plate below the root opening including tolerances")
    # Every reinforcement triangle lies outside x=+/-tp/2 and must remain
    # attached to the actual plate side over its complete vertical leg. This
    # also prevents penetration into the lower flange/root or non-existing
    # plate volume. Equality only permits boundary contact, never overlap.
    if top_min-reinforcement_max < bottom_max:
        raise ValueError("CJP reinforcement extends below the physical plate envelope including tolerances")
    bevel_width = (p.thickness_mm-c.root_face_mm)/2
    bevel_depth = bevel_width/math.tan(math.radians(c.bevel_angle_deg))
    if not math.isfinite(bevel_depth) or bevel_depth >= top_min-gap_max-bottom_max:
        raise ValueError("CJP bevel preparation extends outside the physical plate including tolerances")
    # Checking fit against the actual radius cannot be replaced by catalog area.
    required_clearance = root_max+p.required_root_clearance_mm
    if r_min < required_clearance:
        raise ValueError("actual circular cope does not clear the real root, tolerance and access allowance")
    if upper_start_min < required_clearance:
        raise ValueError("root opening/CJP start encroaches on real flange-root clearance at tolerance limits")
    return {"top_z": zt, "plate_top_z": zt-gap, "cope_start_u": upper_start,
            "cjp_length": p.outstand_mm-upper_start, "weld_low_z": lowest_weld,
            "weld_high_z": upper_weld, "web_length": upper_weld-lowest_weld,
            "web_length_min": top_min-r_max-lowest_weld_max,
            "bevel_width": bevel_width, "bevel_depth": bevel_depth,
            "cope_start_u_min": upper_start_min,
            "reinforcement_low_z_min": top_min-reinforcement_max}



@dataclass(frozen=True)
class IntermediateLayout:
    beam: RolledISection
    beam_start_mm: float
    beam_end_mm: float
    stations: tuple[IntermediateStation, ...]
    state: Literal["present"] = "present"

    def __post_init__(self):
        if not isinstance(self.beam, RolledISection):
            raise TypeError("layout requires its physical rolled beam")
        _numeric_fields(self, unrestricted=("beam_start_mm", "beam_end_mm"))
        if self.beam_end_mm <= self.beam_start_mm:
            raise ValueError("physical span must be positive")
        if self.state != "present":
            raise ValueError("physical intermediate layouts remain present, never absent or unknown")
        if not isinstance(self.stations, (tuple, list)) or not self.stations:
            raise ValueError("present layout needs at least one nonempty physical station")
        if any(not isinstance(s, IntermediateStation) for s in self.stations):
            raise TypeError("invalid station type")
        object.__setattr__(self, "stations", tuple(self.stations))
        if len({s.station_id for s in self.stations}) != len(self.stations):
            raise ValueError("station identities must be unique")
        extents = []
        for s in self.stations:
            _physical(self.beam, s)
            extent = s.pair.thickness_mm/2+max(s.web_fillet.leg_mm,
                s.cjp.reinforcement_leg_mm+s.cjp.reinforcement_leg_tolerance_mm)
            left, right = s.x_mm-extent, s.x_mm+extent
            if not self.beam_start_mm < left < right < self.beam_end_mm:
                raise ValueError("all plate/weld bodies must lie strictly inside the real beam span")
            extents.append((left, right, s.station_id))
        extents.sort()
        for first, second in zip(extents, extents[1:]):
            if first[1] > second[0]:
                raise ValueError(f"longitudinal physical bodies overlap: {first[2]} / {second[2]}")


@dataclass(frozen=True)
class PhysicalPanel:
    left_station_id: str
    right_station_id: str
    x_start_mm: float
    x_end_mm: float
    length_mm: float
    qualified: bool = field(default=False, init=False)


def physical_panels(layout: IntermediateLayout):
    """Physical centerline-to-centerline candidates only, NEVER support panels."""
    if not isinstance(layout, IntermediateLayout):
        raise TypeError("IntermediateLayout required")
    ordered = sorted(layout.stations, key=lambda s: s.x_mm)
    return tuple(PhysicalPanel(a.station_id, b.station_id, a.x_mm, b.x_mm, b.x_mm-a.x_mm)
                 for a, b in zip(ordered, ordered[1:]))


def plate_area_centroid(beam: RolledISection, station: IntermediateStation):
    """Exact unprepared positive-side plate area and centroid (y,z).

    At root_gap=0: rectangle minus PI*Rc²/4, removed centroid 4Rc/(3PI)
    from each corner axis. For g>0 the SAME disk is clipped by the lower
    plate top. Integrals are exact, not a polygon/mesh approximation.
    """
    geo = _physical(beam, station)
    p, g = station.pair, station.cjp.root_gap_mm
    r, b = p.cope_radius_mm, p.outstand_mm
    h = geo["plate_top_z"]-p.bottom_z_mm
    q = geo["cope_start_u"]
    removed_area = math.pi*r*r/4 - (g*q+r*r*math.asin(g/r))/2
    removed_u_moment = r**3/3-r*r*g/2+g**3/6
    removed_v_moment = q**3/3
    rect_area = b*h
    area = rect_area-removed_area
    _number("derived plate area", area, positive=True)
    u = (rect_area*b/2-removed_u_moment)/area
    z = (rect_area*(p.bottom_z_mm+geo["plate_top_z"])/2
         -(geo["top_z"]*removed_area-removed_v_moment))/area
    return {"area_mm2": area, "y_mm": beam.web_thickness_mm/2+u,
            "z_from_bottom_mm": z, "removed_cope_area_mm2": removed_area,
            "basis": "rectangle_minus_exact_circular_cope_intersection"}


def minimum_plate_inertia_mm4(beam: RolledISection, pair: IntermediatePlatePair,
                             *, root_gap_mm: float = 0.0):
    """Conservative least physical horizontal slice, plates ONLY.

    Is is about the web midplane (z axis). The inner material removed by
    the cope is not credited. No web bearing strip is included. This helper
    returns the gross original-contour minimum. assess_detail separately
    reports the prepared root-land minimum and gates final reconstruction
    on explicitly specified compatible full refill, with no reinforcement
    credit. E/fy compatibility remains for the structural consumer.
    """
    if not isinstance(beam, RolledISection) or not isinstance(pair, IntermediatePlatePair):
        raise TypeError("RolledISection and IntermediatePlatePair required")
    gap = _number("root_gap_mm", root_gap_mm, nonnegative=True)
    if gap >= pair.cope_radius_mm:
        raise ValueError("root gap must remain below cope radius")
    cut = math.sqrt(pair.cope_radius_mm**2-gap**2)
    outer, inner = beam.web_thickness_mm/2+pair.outstand_mm, beam.web_thickness_mm/2+cut
    # Factored difference of cubes avoids subtraction cancellation.
    result = 2*pair.thickness_mm*(outer-inner)*(outer*outer+outer*inner+inner*inner)/3
    return _number("minimum plate Is", result, positive=True)


@dataclass(frozen=True)
class DetailAssessment:
    status: str
    design_requirements_satisfied: bool
    pending: tuple[str, ...]
    gap_weld_mm: float
    gap_weld_min_mm: float
    gap_weld_max_mm: float
    required_gap_min_mm: float
    required_gap_max_mm: float
    plate_bottom_z_mm: float
    lowest_weld_z_mm: float
    lower_root_toe_z_mm: float
    cjp_effective_throat_mm: float
    cjp_physical_length_mm: float
    cjp_effective_area_mm2: float
    web_fillet_physical_length_mm: float
    minimum_Is_mm4: float
    maximum_outstand_over_thickness: float
    gross_plate_minimum_Is_mm4: float
    prepared_plate_minimum_Is_mm4: float
    final_section_minimum_Is_mm4: float | None
    section_reconstruction_specified: bool
    web_fillet_minimum_physical_length_mm: float
    station_complete: bool = field(default=False, init=False)
    as_built_verified: bool = field(default=False, init=False)
    fatigue_qualified: bool = field(default=False, init=False)
    global_stiffness_credit: bool = field(default=False, init=False)
    physical_input_valid: bool = field(default=True, init=False)


def assess_detail(beam: RolledISection, station: IntermediateStation):
    """Requirements SPECIFIED in design only; no strength or fatigue conclusion."""
    geo = _physical(beam, station)
    p, w, c = station.pair, station.web_fillet, station.cjp
    pending = []
    gap = geo["weld_low_z"]-beam.lower_root_toe_z_mm
    tolerance = (p.bottom_tolerance_mm+w.endpoint_tolerance_mm+
                 beam.flange_thickness_tolerance_mm+beam.root_radius_tolerance_mm)
    low, high = gap-tolerance, gap+tolerance
    required_low = 4*(beam.web_thickness_mm+beam.web_thickness_tolerance_mm)
    required_high = 6*(beam.web_thickness_mm-beam.web_thickness_tolerance_mm)
    if low < required_low or high > required_high:
        pending.append("Lowest actual web-weld point does not satisfy 4tw..6tw throughout specified tolerances")
    lesser = min(p.thickness_mm, beam.web_thickness_mm+beam.web_thickness_tolerance_mm)
    minimum_leg = 3 if lesser <= 6.3 else 5 if lesser <= 12.5 else 6 if lesser <= 19 else 8
    maximum_leg = p.thickness_mm if p.thickness_mm < 6.3 else p.thickness_mm-1.5
    if not minimum_leg <= w.leg_mm <= maximum_leg:
        pending.append("Web fillet leg does not satisfy the minimum connected-thickness and plate-edge limits")
    if geo["web_length_min"] < max(40, 4*w.leg_mm):
        pending.append("Web fillet physical length at tolerance limits is below the adopted ordinary-fillet minimum")
    if not w.continuous:
        pending.append("Continuous web fillets are not specified")
    for name in ("consumable_id", "compatibility_basis", "procedure_id"):
        if getattr(w, name) is None:
            pending.append(f"Web fillet {name} is required")
    if (not w.qe_both_ends_specified or w.qe_end_zone_length_mm is None
            or w.qe_end_zone_length_mm < 10*p.thickness_mm):
        pending.append("Q.E. is required over the final 10ts at BOTH ends of every web fillet")
    if not w.ends_ground_notch_free_specified:
        pending.append("Both web-fillet terminations must be specified ground and notch-free")
    if not w.qe_end_zones_undercut_free_specified:
        pending.append("Both 10ts Q.E. web-fillet end zones must be specified free of undercuts")
    if not w.tension_region_lamination_free_specified:
        pending.append("Web-fillet tension-region plate must be specified free of lamination flaws perpendicular to the forces")
    if c.reinforcement_leg_mm-c.reinforcement_leg_tolerance_mm < 6:
        pending.append("CJP re-entrant reinforcement must be at least 6 mm; it adds no effective throat")
    for name in ("consumable_id", "compatibility_basis", "procedure_id", "access_description", "inspection_acceptance"):
        if getattr(c, name) is None:
            pending.append(f"CJP {name} is required")
    if (c.procedure_status == "unspecified" or c.root_method == "unspecified"
            or not c.full_root_fusion_specified or not c.groove_full_refill_specified):
        pending.append("Identified qualified/prequalified CJP procedure and fully fused root execution are required")
    if c.inspection_method not in ("UT", "RT"):
        pending.append("CJP UT or RT with fatigue acceptance must be specified")
    if not (c.run_on_off_tabs_specified and c.tabs_removed_and_ends_ground_flush_specified and c.end_dams_prohibited):
        pending.append("Cyclic CJP requires run-on/off tabs removed, ends ground flush and no end dams")
    if not (c.qe_weld_specified and c.edges_undercut_free_specified
            and c.root_removed_before_backweld_specified and c.tension_region_lamination_free_specified):
        pending.append("K/CJP Q.E. requires undercut-free edges, root removal before backweld and lamination-free tension region")
    if p.cope_finish != "ground":
        pending.append("Ground cope finish is not specified; radius alone grants no fatigue category")
    if p.thermally_cut and (p.thermal_cut_roughness_um is None or p.thermal_cut_roughness_um > 25):
        pending.append("Thermal cope cut requires specified roughness no greater than 25 micrometres")
    gross_inertia = minimum_plate_inertia_mm4(beam, p, root_gap_mm=c.root_gap_mm)
    # Before welding the top root land can vanish. The FINAL nominal section
    # only reconstructs its original contour under explicit full compatible
    # refill. No exterior reinforcement or web-strip credit is included.
    # Consumers must still verify the lesser compatible E/fy and station scope.
    prepared_inertia = gross_inertia*c.root_face_mm/p.thickness_mm
    reconstruction = bool(c.groove_full_refill_specified and c.full_root_fusion_specified
        and c.compatibility_basis and c.procedure_id and c.procedure_status != "unspecified"
        and c.root_method != "unspecified" and c.root_removed_before_backweld_specified)
    final_inertia = gross_inertia if reconstruction else None
    min_inertia = gross_inertia if reconstruction else 0.0
    throat = min(p.thickness_mm, beam.flange_thickness_mm)
    return DetailAssessment("DESIGN_REQUIREMENTS_SPECIFIED" if not pending else "INPUT_REQUIRED",
        not pending, tuple(pending), gap, low, high, required_low, required_high,
        p.bottom_z_mm, geo["weld_low_z"], beam.lower_root_toe_z_mm, throat,
        geo["cjp_length"], throat*geo["cjp_length"], geo["web_length"], min_inertia,
        p.outstand_mm/p.thickness_mm, gross_inertia, prepared_inertia, final_inertia, reconstruction,
        geo["web_length_min"])


def geometry_inputs_hash(layout: IntermediateLayout):
    if not isinstance(layout, IntermediateLayout):
        raise TypeError("IntermediateLayout required")
    payload = {"contract_sha256": CONTRACT_SHA256, "geometry_datum": GEOMETRY_DATUM, "layout": asdict(layout)}
    return hashlib.sha256(json.dumps(_typed(payload), sort_keys=True,
        separators=(",", ":"), allow_nan=False).encode()).hexdigest()


def stationary_mass_ledger(layout: IntermediateLayout, *, gravity_m_s2=9.80665):
    """One exact nominal selfweight resultant per physical plate/weld body.

    z_mm is CENTROIDAL here (explicit companion datum fields are mandatory).
    Each point's local y eccentricity is preserved; only the assembled pair
    cancels global Mx under gravity; My=-x*Fz remains the global moment.
    """
    if not isinstance(layout, IntermediateLayout):
        raise TypeError("IntermediateLayout required")
    gravity = _number("gravity_m_s2", gravity_m_s2, positive=True)
    beam, points, replacements = layout.beam, [], []
    def add(s, part_id, kind, volume, material, xyz, extent, length=None):
        _number("physical body volume", volume, positive=True)
        x, y, z = xyz
        mass = _number("physical body mass", volume*material.density_kg_m3/1e9, positive=True)
        p = {"station_id": s.station_id, "part_id": part_id, "part_kind": kind,
             "volume_mm3": volume, "mass_kg": mass, "material_id": material.material_id,
             "density_kg_m3": material.density_kg_m3, "x_mm": x,
             "x_from_beam_start_mm": x-layout.beam_start_mm, "y_mm": y,
             "z_from_bottom_mm": z, "z_centroid_mm": z-beam.depth_mm/2,
             "z_mm": z-beam.depth_mm/2, "x_extent_mm": list(extent),
             "Fz_N": -mass*gravity, "Mx_origin_Nmm": -y*mass*gravity,
             "My_origin_Nmm": x*mass*gravity, "source": "adopted_TOP_intermediate_physical_detail"}
        if length is not None:
            p["physical_length_mm"] = length
        for key in ("x_mm", "y_mm", "z_from_bottom_mm", "z_centroid_mm", "Fz_N", "Mx_origin_Nmm", "My_origin_Nmm"):
            _number(key, p[key])
        points.append(p)
    for s in layout.stations:
        geo, area = _physical(beam, s), plate_area_centroid(beam, s)
        p, w, c = s.pair, s.web_fillet, s.cjp
        t, L = p.thickness_mm, geo["cjp_length"]
        removed_volume = geo["bevel_width"]*geo["bevel_depth"]*L
        gross_volume = area["area_mm2"]*t
        remaining_volume = gross_volume-removed_volume
        _number("prepared plate volume", remaining_volume, positive=True)
        groove_u = (geo["cope_start_u"]+p.outstand_mm)/2
        groove_z = geo["plate_top_z"]-geo["bevel_depth"]/3
        for side in (-1, 1):
            plate_id = f"{s.station_id}:plate:{'left' if side < 0 else 'right'}"
            groove_y = side*(beam.web_thickness_mm/2+groove_u)
            plate_y = (gross_volume*side*area["y_mm"]-removed_volume*groove_y)/remaining_volume
            plate_z = (gross_volume*area["z_from_bottom_mm"]-removed_volume*groove_z)/remaining_volume
            add(s, plate_id, "prepared_plate", remaining_volume, p.material,
                (s.x_mm, plate_y, plate_z), (s.x_mm-t/2, s.x_mm+t/2))
            add(s, plate_id+":cjp_groove", "cjp_groove_replacement", removed_volume, c.material,
                (s.x_mm, groove_y, groove_z), (s.x_mm-t/2, s.x_mm+t/2), L)
            replacements.append({"plate_id": plate_id, "removed_volume_mm3": removed_volume,
                "replacement_volume_mm3": removed_volume,
                "removed_density_kg_m3": p.material.density_kg_m3,
                "replacement_density_kg_m3": c.material.density_kg_m3,
                "cancellation_permitted": p.material.density_kg_m3 == c.material.density_kg_m3,
                "basis": "declared_full_refill_equal_volumes; density_equality_checked_not_assumed",
                "partition_scope": "declared_double_bevel_wedges_only_not_as_built_dilution_or_extra_backgouging"})
            if c.root_gap_mm > 0:
                add(s, plate_id+":cjp_root_gap", "cjp_root_gap_additional", t*c.root_gap_mm*L,
                    c.material, (s.x_mm, groove_y, geo["top_z"]-c.root_gap_mm/2),
                    (s.x_mm-t/2, s.x_mm+t/2), L)
            for face in (-1, 1):
                # Actual centroid of each triangular prism, not its root or throat.
                leg = w.leg_mm
                add(s, plate_id+f":web:{face:+d}", "web_fillet_equal_leg", leg*leg/2*geo["web_length"],
                    w.material, (s.x_mm+face*(t/2+leg/3), side*(beam.web_thickness_mm/2+leg/3),
                                 (geo["weld_low_z"]+geo["weld_high_z"])/2),
                    sorted((s.x_mm+face*t/2, s.x_mm+face*(t/2+leg))), geo["web_length"])
                leg = c.reinforcement_leg_mm
                add(s, plate_id+f":cjp_reinforcement:{face:+d}", "cjp_reinforcement_equal_leg",
                    leg*leg/2*L, c.material,
                    (s.x_mm+face*(t/2+leg/3), groove_y, geo["top_z"]-leg/3),
                    sorted((s.x_mm+face*t/2, s.x_mm+face*(t/2+leg))), L)
    ledger_signature = hashlib.sha256(json.dumps(_typed({"geometry_inputs_hash": geometry_inputs_hash(layout),
        "gravity_m_s2": gravity}), sort_keys=True, separators=(",", ":")).encode()).hexdigest()
    return {"status": "PHYSICAL_MASS_MODEL_CALCULATED", "points": points,
        "total_mass_kg": math.fsum(p["mass_kg"] for p in points),
        "Fz_N": math.fsum(p["Fz_N"] for p in points),
        "Mx_origin_Nmm": math.fsum(p["Mx_origin_Nmm"] for p in points),
        "My_origin_Nmm": math.fsum(p["My_origin_Nmm"] for p in points),
        "preparation_replacement": replacements, "input_signature": ledger_signature,
        "gravity_m_s2": gravity,
        "geometry_inputs_hash": geometry_inputs_hash(layout), "station_complete": False,
        "as_built_verified": False, "global_stiffness_credit": False, "buckling_length_credit": False,
        "geometric_z_datum": GEOMETRY_DATUM, "mass_z_datum": MASS_DATUM,
        "beam_start_mm": layout.beam_start_mm, "beam_end_mm": layout.beam_end_mm,
        "x_mm_datum": "global_geometry_origin; use x_from_beam_start_mm for simple_span_solver",
        "load_model": "fixed_selfweight_resultants_at_individual_physical_body_centroids",
        "weld_volume_basis": "physical_lengths_equal_leg_triangles_plus_explicit_CJP_groove_and_root_gap",
        "unspecified_overfill_included": False,
        "preparation_partition_scope": "declared_double_bevel_wedges_only",
        "extra_backgouging_or_dilution_predicted": False,
        "extra_removal_requires_new_geometry_and_mass_receipt": True}


__all__ = ["MaterialSpec", "RolledISection", "IntermediatePlatePair", "WebFilletSpec", "CJPTopSpec",
           "IntermediateStation", "IntermediateLayout", "PhysicalPanel", "DetailAssessment",
           "physical_panels", "plate_area_centroid", "minimum_plate_inertia_mm4", "assess_detail",
           "geometry_inputs_hash", "stationary_mass_ledger", "CONTRACT_SHA256"]
