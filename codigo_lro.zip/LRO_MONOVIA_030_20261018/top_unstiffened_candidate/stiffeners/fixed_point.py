"""Signed all-travel envelopes at one fixed material point.

This is the existing simply-supported Macaulay model, not a new local model.
For a fixed cut, all resultants are affine in train translation between wheel
entry, exit and cut-crossing events. Actual events AND both open-cell limits
are evaluated analytically; no moving mesh, favourable side or force history
is substituted. Bounds here are algebraic-model bounds, not a directed-rounding
certificate or an authenticated choice of NBR/CMAA action factors.
"""
from __future__ import annotations

from fractions import Fraction
from math import fsum, isfinite
from ..mechanics import PreparedCase, prepare_case


def _number(v, name):
    if type(v) not in (int, float) or not isfinite(v):
        raise ValueError(name + ' must be finite numeric data')
    return float(v)


def _point_terms(L, x, a, P, C, left):
    # A positive applied couple gives a +C moment jump, matching PlaneSolution.
    return (P*((L-a)*x/L - (x-a if left else 0.)) + C*(-x/L + int(left)),
            P*((L-a)/L-int(left)) - C/L)


def _fixed_plane(L, x, fixed, q, force_key, couple_key, cut_side):
    mv = [_point_terms(L, x, w.position_m, getattr(w,force_key),
                       getattr(w,couple_key),
                       w.position_m < x or (w.position_m == x and cut_side == 'right'))
          for w in fixed]
    return (fsum((q*x*(L-x)/2, *(v[0] for v in mv))),
            fsum((q*(L/2-x), *(v[1] for v in mv))))


def fixed_point_resultant_bounds(c, x_m, *, cut_side='right'):
    if not isinstance(c, PreparedCase):
        raise ValueError('Internally prepared mechanical case required')
    c.basis.validated_project()
    fresh=prepare_case(c.basis,c.factors,c.transverse_sign,c.longitudinal_sign)
    if c != fresh:
        raise ValueError('Prepared mechanics changed; regenerate from original physical inputs and factors')
    if hasattr(c, 'validate_stationary_identity'):
        c.validate_stationary_identity()
    L = c.project.span_m
    x = _number(x_m, 'Fixed material cut')
    if not 0 <= x <= L or cut_side not in ('left', 'right'):
        raise ValueError('Physical cut within the span and explicit side required')
    if not c.source_wheels or not (len(c.source_wheels)==len(c.top_wheels)==len(c.bottom_wheels)):
        raise ValueError('Complete coexistent three-plane wheel train required')
    if any(not (a.offset_m==b.offset_m==d.offset_m)
           for a,b,d in zip(c.source_wheels,c.top_wheels,c.bottom_wheels)):
        raise ValueError('Three-plane wheel positions must coincide')
    # Exact rational event topology of the supplied binary64 inputs. Subtracting
    # nearly coincident offsets in binary64 can merge two distinct jumps and
    # silently erase a nonzero axial/shear state. No spacing tolerance is used.
    offsets=tuple(Fraction(w.offset_m) for w in c.source_wheels)
    exact_L,exact_x=Fraction(L),Fraction(x)
    lo,hi=-max(offsets),exact_L-min(offsets)
    events=sorted({lo,hi,*(station-offset for station in (Fraction(0),exact_x,exact_L)
        for offset in offsets if lo<=station-offset<=hi)})
    fixed = (
        _fixed_plane(L,x,c.major_fixed,c.udl.vertical_kn_per_m,'vertical_kn','major_moment_knm',cut_side),
        _fixed_plane(L,x,c.top_fixed,c.top_udl.horizontal_kn_per_m,'horizontal_kn','minor_moment_knm',cut_side),
        _fixed_plane(L,x,c.bottom_fixed,c.bottom_udl.horizontal_kn_per_m,'horizontal_kn','minor_moment_knm',cut_side))
    Nfixed=fsum((c.udl.longitudinal_kn_per_m*(L-x),
        *(w.longitudinal_kn for w in c.major_fixed
          if w.position_m>x or (w.position_m==x and cut_side=='left'))))
    rows=[]

    def record(t, representative, kind):
        # representative only selects an active set and the side of a jump.
        # Each limiting value is evaluated at t itself, not at epsilon offsets.
        moving=[[],[],[]]; ns=[]
        for offset,trio in zip(offsets,zip(c.source_wheels,c.top_wheels,c.bottom_wheels)):
            a_ref=representative+offset
            if not 0 <= a_ref <= exact_L:
                continue
            a=float(t+offset)
            left=(a_ref<exact_x or (a_ref==exact_x and cut_side=='right'))
            for i,(w,f,m) in enumerate(zip(trio,
                    ('vertical_kn','horizontal_kn','horizontal_kn'),
                    ('major_moment_knm','minor_moment_knm','minor_moment_knm'))):
                moving[i].append(_point_terms(L,x,a,getattr(w,f),getattr(w,m),left))
            if not left:
                ns.append(trio[0].longitudinal_kn)
        values={'N_kn':fsum((Nfixed,*ns))}
        for i,label in enumerate(('major','top','bottom')):
            values[label+'_M_knm']=fsum((fixed[i][0],*(r[0] for r in moving[i])))
            values[label+'_V_kn']=fsum((fixed[i][1],*(r[1] for r in moving[i])))
        if not all(isfinite(v) for v in values.values()):
            raise ValueError('Derived fixed-point envelope overflow')
        rows.append(dict(translation_m=float(t),translation_exact_ratio=(t.numerator,t.denominator),
            event_representable_binary64=Fraction(float(t))==t,limit_kind=kind,values=values))

    for event in events:
        record(event,event,'actual_event')
    for a,b in zip(events,events[1:]):
        mid=(a+b)/2
        record(a,mid,'right_open_cell_limit')
        record(b,mid,'left_open_cell_limit')
    fields=tuple(rows[0]['values'])
    return dict(position_m=x,cut_side=cut_side,translation_range_m=(float(lo),float(hi)),events_m=tuple(float(e) for e in events),
        event_exact_ratios=tuple((e.numerator,e.denominator) for e in events),
        bounds={k:(min(r['values'][k] for r in rows),max(r['values'][k] for r in rows)) for k in fields},
        candidate_states=tuple(rows),all_translation_positions_covered=True,
        method='Piecewise-affine fixed-cut Macaulay resultants; actual events and both cell limits',
        physical_history_claimed=False,roundoff_interval_certified=False,station_qualified=False)


def fixed_point_longitudinal_bounds(c, x_m, y_mm, z_mm, *, cut_side='right'):
    """Same-state longitudinal CISC interpolation in the web and flanges.

    Linear interpolation between flange-centroid lateral moments is the
    declared nominal wall extension, not a 3-D stress recovery. At flange
    thicknesses the associated flange moment is retained, as in mechanics.at.
    """
    y=_number(y_mm,'Material y'); z=_number(z_mm,'Material z')
    s=c.project.section; h=c.h_mm
    if abs(z)>s.d_mm/2:
        raise ValueError('Point outside the base section height')
    in_flange=abs(z)>=s.d_mm/2-s.tf_mm
    if abs(y)>(s.bf_mm/2 if in_flange else s.tw_mm/2):
        raise ValueError('Point outside nominal rectangular wall material')
    weight=max(0.,min(1.,.5+z/h))
    if in_flange:
        weight=1. if z>=0 else 0.
    result=fixed_point_resultant_bounds(c,x_m,cut_side=cut_side)
    values=[]
    for row in result['candidate_states']:
        v=row['values']
        sigma=fsum((v['N_kn']*1000/c.properties.A_mm2,
            -v['major_M_knm']*1e6*z/c.properties.Ix_mm4,
            (weight*v['top_M_knm']+(1-weight)*v['bottom_M_knm'])*1e6*y/c.flange_I_mm4))
        if not isfinite(sigma):
            raise ValueError('Derived nominal longitudinal stress overflow')
        values.append(sigma)
    return dict(**result,y_mm=y,z_mm=z,sigma_x_mpa=(min(values),max(values)),
        candidate_sigma_x_mpa=tuple(values),nominal_wall_model_only=True)
