"""Conditional per-prepared-case static and interruption-sign consumers.

These are consumers of the adopted nominal TOP model, not an action-family
generator, local FE solution or station approval. Source strings are records,
never authentication. The caller must regenerate and cover the complete family.
The 0.75 factor is used ONLY in the prescribed static compression check.
"""
from __future__ import annotations

from dataclasses import asdict
from fractions import Fraction as F
from math import isfinite

from lro_beams.autonomous_actions import factors_10084
from lro_beams.autonomous_fatigue import elastic_allowables_autonomous

from ..mechanics import PreparedCase
from .detail import CONTRACT_SHA256, GEOMETRY_DATUM
from .nominal_field import _context, produce_nominal_regions
from .sign_domain import exact_longitudinal_patch_sign


STATIC_ACTION_BASIS = 'nbr10084_8400_admissible'
STATIC_SOURCE = (
    'ABNT NBR 10084:2020, 9.1.3.1-9.1.3.4, pp.5-8; '
    'ABNT NBR 8400-2:2019, 5.2.1, Case I; '
    'adopted_intermediate_detail_20261017/CONTRACT.md section 5; '
    'runway_primary_references/stiffeners/'
    'TOP_STIFFENED_NOMINAL_CLOSURE_CONTRACT_2026-10-17.md section 4'
)
SIGN_SOURCE = (
    'adopted_intermediate_detail_20261017/CONTRACT.md sections 2-3; '
    'actual lower square-ended fillet footprints and both lower flange sides '
    'in the adopted longitudinal Macaulay/CISC nominal model'
)


def _result(kind):
    return dict(kind=kind, status='APPLICABILITY_PENDING', input_valid=True,
        errors=[], pending=[], conditional_bounds_satisfied=False,
        all_supplied_bounds_satisfied=False, any_sufficient_bound_exceeded=False,
        actual_failure_proven=False, action_family_authenticated=False,
        all_action_cases_covered=False, station_qualified=False,
        whole_station_qualified=False, member_qualified=False,
        whole_member_qualified=False, whole_design_complete=False,
        stage_qualified=False, production_credit_enabled=False,
        physical_3d_bound_claimed=False, sampled_maxima_used=False,
        as_built_execution_verified=False, detail_contract_sha256=CONTRACT_SHA256)


def _invalid(result, exc):
    result.update(status='INVALID_INPUT', input_valid=False,
        errors=[type(exc).__name__ + ': ' + str(exc)],
        conditional_bounds_satisfied=False, all_supplied_bounds_satisfied=False)
    return result


def _text(value, name):
    if type(value) is not str or not value.strip():
        raise ValueError(name + ' requires an explicit source record')


def _prepared(project, case):
    if type(case) is not PreparedCase:
        raise ValueError('An internally prepared mechanical case is required')
    _context(project, case)
    if case.basis.premise_status not in ('adopted', 'confirmed'):
        raise ValueError('Reference-only mechanics cannot become an adopted nominal check')


def _static_factors(project, case, action_basis):
    """One explicit decomposition, not proof of the upstream wheel factors.

    The original Case-I wheel vectors already contain psi and H dynamics,
    but not Mx. Mx then scales each complete vector and every fixed G origin.
    Reject a ULS or fatigue factor shape, omitted G, a vertical override and
    a silently discarded lifted component. Authenticating the original
    vector, signs and complete family belongs to the compositor.
    """
    if action_basis != STATIC_ACTION_BASIS:
        raise ValueError('Static compression requires the nominal NBR10084/8400 Case-I action basis, not ULS')
    source = factors_10084('I', psi=project.actions.dynamics()['psi'],
        equipment_group=project.actions.equipment_group)
    mx = source.dead_support
    factors = case.factors
    if any(getattr(factors, name) != mx for name in (
            'dead_support', 'dead_equipment', 'transverse', 'longitudinal', 'extra_dead')):
        raise ValueError('Case-I nominal decomposition requires explicit uniform sourced Mx on every complete wheel vector and fixed G origin')
    if factors.lifted != 0. or factors.wheel_vertical_override_kn is not None:
        raise ValueError('Case-I wheel vectors must already include psi exactly once; lifted=0 and no wheel override are required')
    if any(w.lifted_kn != 0. for w in case.basis.project.wheels):
        raise ValueError('Preassembled Case-I wheel vectors cannot silently discard a separate lifted component')
    return dict(source_factors=asdict(source), Mx=mx,
        decomposition='Case-I psi/H-dynamic wheel vectors without Mx, then uniform Mx on all vectors and permanent origins',
        required_upstream_wheel_basis='Complete nominal Case I with psi and characteristic horizontal dynamics already included exactly once',
        factor_shape_checked=True, upstream_wheel_factors_authenticated=False,
        source_labels_authenticate_actions=False, uls_to_admissible_conversion_used=False)


def evaluate_intermediate_static_case(project, c, *, action_basis,
                                      action_source, factors_source):
    """Regional sigma0z + 0.75|sigmaT| versus actual elastic Case-I allowable.

    Exterior regions retain the adopted ordinary CISC alternative and their
    pressure check. Their missing physical second station is not fabricated,
    nor is an exterior physical sigmaT=0 asserted. Exceeding a sufficient
    nominal bound is inconclusive, not proof of an actual physical failure.
    """
    result = _result('TOP_intermediate_conditional_per_case_static_compression')
    result.update(region_results=[], checks=[], source=STATIC_SOURCE,
        conditional_on_caller_authenticated_case_i=True,
        fatigue_075_reduction_used=False, scope='Regional prescribed static web '
            'compression only. Other member, plate, connection, stability, '
            'fatigue and action-family checks remain separate.')
    try:
        _text(action_source, 'action_source')
        _text(factors_source, 'factors_source')
        _prepared(project, c)
        factors = _static_factors(project, c, action_basis)
        produced = produce_nominal_regions(project, c)
        material = c.project.material
        allowables = elastic_allowables_autonomous(material.fy_mpa, material.fu_mpa, 'I')
        capacity = allowables['sigma_a_mpa']
        if not isfinite(capacity) or capacity <= 0:
            raise ValueError('Finite positive elastic Case-I normal allowable required')
        pressure = produced['pressure']['transverse_compression_mpa']
        rows = []
        for region in produced['regions']:
            sigma_t = region['sigmaT_magnitude_sum_mpa']
            demand = pressure + .75 * sigma_t
            if not isfinite(demand) or demand < 0:
                raise ValueError('Finite nonnegative regional static compression required')
            if demand != region['maximum_static_compression_mpa']:
                raise ValueError('Regional static formula and nominal producer disagree')
            panel = region['region']['physical_panel_spacing_mm'] is not None
            satisfied = demand <= capacity
            rows.append(dict(region=region['region'],
                sigma0z_bound_mpa=pressure, sigmaT_magnitude_sum_mpa=sigma_t,
                demand_mpa=demand, capacity_mpa=capacity, utilization=demand/capacity,
                sufficient_static_compression_bound_satisfied=satisfied,
                status='CONDITIONAL_STATIC_BOUND_SATISFIED' if satisfied else 'INCONCLUSIVE_SUFFICIENT_STATIC_BOUND',
                formula='sigma_cz = sigma0z + 0.75 * |sigmaT|' if panel else 'sigma_cz = sigma0z in the adopted ordinary endpoint-region model',
                literal_transverse_panel_expression_applied=panel,
                external_region_sigmaT_zero_claimed=False,
                local_model=region['local_model'], full_travel_covered=True,
                all_wheel_magnitudes_summed=True, actual_failure_proven=False,
                action_family_authenticated=False, station_qualified=False,
                member_qualified=False, source=STATIC_SOURCE))
        if not rows or len(rows) != len(project.intermediates.layout.stations)+1:
            raise ValueError('Every physical nominal region must have a static compression check')
        passed = all(row['sufficient_static_compression_bound_satisfied'] for row in rows)
        result.update(region_results=rows, checks=rows, elastic_allowables=allowables,
            normal_case='I', material=dict(fy_mpa=material.fy_mpa, fu_mpa=material.fu_mpa),
            action_basis=action_basis, action_source=action_source,
            factors_source=factors_source, factor_receipt=factors,
            case_factors=asdict(c.factors), nominal_field=produced,
            geometry_inputs_hash=produced['geometry_inputs_hash'],
            conditional_bounds_satisfied=passed, all_supplied_bounds_satisfied=passed,
            any_sufficient_bound_exceeded=not passed,
            status='CONDITIONAL_PER_CASE_STATIC_BOUNDS_SATISFIED' if passed else 'INCONCLUSIVE_SUFFICIENT_STATIC_BOUND')
        return result
    except (ValueError, TypeError, ArithmeticError, KeyError, AttributeError) as exc:
        return _invalid(result, exc)


def _ratio(value):
    return value.numerator, value.denominator


def _patch(case, station_id, identity, wall, ranges, **geometry):
    """All decisions use exact ratios; float coordinates are display-only."""
    certificate = exact_longitudinal_patch_sign(case, *ranges)
    lower, upper = (F(*ratio) for ratio in certificate['sigma_x_exact_ratio'])
    passed = lower >= 0
    if (lower > upper or certificate['no_nominal_compression'] is not passed
            or certificate['all_translations_and_patch_covered'] is not True):
        raise ValueError('Invalid exact nominal patch-sign certificate')
    return dict(station_id=station_id, patch_id=identity, nominal_wall=wall,
        coordinate_exact_ratios=dict(x_range_m=tuple(map(_ratio, ranges[0])),
            y_range_mm=tuple(map(_ratio, ranges[1])),
            z_range_centroid_mm=tuple(map(_ratio, ranges[2]))),
        geometry=geometry, certificate=certificate,
        no_nominal_compression=passed, sigma_x_exact_ratio=certificate['sigma_x_exact_ratio'],
        station_qualified=False, member_qualified=False, action_family_authenticated=False)


def evaluate_intermediate_sign_case(project, c):
    """Sufficient exact sign proof for all declared interruption receiver areas.

    Two lower-flange side patches cover the entire nominal flange thickness
    and width over the complete station physical x envelope. Four lower web
    patches cover both faces and both fore/aft fillet footprints, including
    plate-bottom and actual square-end tolerances. No patch crosses the void,
    rolled root, or a nominal wall branch; no mass CG substitutes for a toe.
    """
    result = _result('TOP_intermediate_conditional_per_case_interruption_sign')
    result.update(station_results=[], patch_results=[], source=SIGN_SOURCE,
        coordinate_datum=GEOMETRY_DATUM, mechanical_z_datum='section_centroid_mm',
        sign_decision_arithmetic='Exact rational, no float conversion or tolerance',
        sign_proved_from_scan=False, full_section_geometry_tolerance_analysis=False,
        scope='Exact sufficient longitudinal sign bounds in the declared nominal '
            'section model, for the supplied case and complete physical travel. '
            'Family completeness, prescriptive applicability and station/member acceptance remain separate.')
    try:
        _prepared(project, c)
        layout = project.intermediates.layout
        beam = layout.beam
        half_d, half_b, half_w = F(beam.depth_mm)/2, F(beam.flange_width_mm)/2, F(beam.web_thickness_mm)/2
        flange_z = (-half_d, -half_d+F(beam.flange_thickness_mm))
        patches, stations = [], []
        for station in sorted(layout.stations, key=lambda item: item.x_mm):
            p, w, j = station.pair, station.web_fillet, station.cjp
            x, half_t, leg = F(station.x_mm), F(p.thickness_mm)/2, F(w.leg_mm)
            extent = half_t + max(leg, F(j.reinforcement_leg_mm)+F(j.reinforcement_leg_tolerance_mm))
            envelope = ((x-extent)/1000, (x+extent)/1000)
            bottom = F(p.bottom_z_mm)+F(w.lower_setback_mm)
            tol = F(p.bottom_tolerance_mm)+F(w.endpoint_tolerance_mm)
            z_from_bottom = (bottom-tol, bottom+tol)
            web_z = tuple(value-half_d for value in z_from_bottom)
            root_low = F(beam.flange_thickness_mm)+F(beam.flange_thickness_tolerance_mm)+F(beam.root_radius_mm)+F(beam.root_radius_tolerance_mm)
            root_high = F(beam.depth_mm)-root_low
            if not root_low < z_from_bottom[0] <= z_from_bottom[1] < root_high:
                raise ValueError('Actual lower web endpoints must remain in the straight web, never across a rolled root')
            rows = []
            for side, ys in (('negative_y', (-half_b, F(0))), ('positive_y', (F(0), half_b))):
                rows.append(_patch(c, station.station_id, station.station_id+':bottom_flange:'+side,
                    'bottom_flange', (envelope, ys, flange_z),
                    receiver_side=side, coverage='Complete nominal lower flange side, including both vertical edges and full physical station x envelope'))
            for side, y in (('negative_y', -half_w), ('positive_y', half_w)):
                for end, xx in (('negative_x', ((x-half_t-leg)/1000, (x-half_t)/1000)),
                                ('positive_x', ((x+half_t)/1000, (x+half_t+leg)/1000))):
                    rows.append(_patch(c, station.station_id, station.station_id+':lower_web:'+side+':'+end,
                        'web', (xx, (y, y), web_z), receiver_side=side, fillet_side=end,
                        actual_lower_endpoint_from_bottom_exact_ratios=tuple(map(_ratio, z_from_bottom)),
                        coverage='Complete square-ended lower fillet receiver footprint, including plate-bottom and endpoint tolerances; not its mass centroid'))
            if len(rows) != 6 or len({row['patch_id'] for row in rows}) != 6:
                raise ValueError('Both lower flange sides and all four actual web-weld lower footprints are required')
            passed = all(row['no_nominal_compression'] for row in rows)
            stations.append(dict(station_id=station.station_id,
                physical_x_envelope_m_exact_ratios=tuple(map(_ratio, envelope)),
                patch_ids=tuple(row['patch_id'] for row in rows),
                no_nominal_compression=passed, conditional_sign_bound_satisfied=passed,
                station_qualified=False, station_complete=False, member_qualified=False,
                action_family_authenticated=False, actual_compression_proven=False))
            patches.extend(rows)
        if not stations or len(patches) != 6*len(layout.stations):
            raise ValueError('Nonempty complete physical interruption inventory required')
        passed = all(row['no_nominal_compression'] for row in stations)
        result.update(station_results=stations, patch_results=patches,
            geometry_inputs_hash=project.intermediates.physical_geometry_hash(),
            case_factors=asdict(c.factors), full_physical_travel_m=c.translation_range_m,
            all_translations_and_patches_covered=True,
            no_nominal_compression=passed, all_station_sign_bounds_satisfied=passed,
            conditional_bounds_satisfied=passed, all_supplied_bounds_satisfied=passed,
            any_sufficient_bound_exceeded=not passed,
            status='CONDITIONAL_PER_CASE_NOMINAL_SIGN_BOUNDS_SATISFIED' if passed else 'INCONCLUSIVE_SUFFICIENT_NOMINAL_SIGN_BOUND')
        return result
    except (ValueError, TypeError, ArithmeticError, KeyError, AttributeError) as exc:
        return _invalid(result, exc)
