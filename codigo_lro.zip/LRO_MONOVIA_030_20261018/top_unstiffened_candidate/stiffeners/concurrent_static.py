"""Consumers of existing nominal fields, never another stress-field solver.

NBR 8400-2 5.2.1.3 remains a PLANE check with its own Case-I actions and
allowables. Local NBR 8800 normal, shear, rupture and block mechanisms remain
separate. Gershgorin is only an algebraic enclosure of normal/shear demands;
it is not a new yield criterion or a normative three-dimensional interaction.
The caller regenerates/authenticates the complete action family. Pool hashes
detect mutation, not authenticity. No helper here approves a station/member.
"""
from __future__ import annotations

from copy import deepcopy
from dataclasses import asdict, replace
from hashlib import sha256
from itertools import product
import json
from math import hypot, isfinite, sqrt

from lro_beams.autonomous_fatigue import elastic_allowables_autonomous

from .nominal_field import produce_nominal_regions
from .regions import RegionInventory, StationLine
from .selfweight_transfer import (SelfweightTransfer, assess_selfweight_transfer,
    MINIMUM_CONNECTION_FORCE_N, GAMMA_A1, GAMMA_A2)
from .static_adapter import _prepared, _static_factors, _result, _invalid, STATIC_ACTION_BASIS


COMPONENTS = ('sx', 'sy', 'sz', 'txy', 'txz', 'tyz')
SIGNED_COMPONENTS = dict(sigma_xx='sx', sigma_yy='sy', sigma_zz='sz',
    tau_xy='txy', tau_xz='txz', tau_yz='tyz')
POOL_SCHEMA = 'TOP_CONCURRENT_REGIONAL_POOL_V1'
MODE_ID = 'concurrent_member_local_static'
PLANE_SOURCE = 'NBR 8400-2:2019 5.2.1.3, plane equivalent stress and separate normal/shear limits, Case I'
LOCAL_SOURCE = 'NBR 8800:2024 6.5.3/.4/.5; 5.5.2.3(a,b) only for the adopted physical prismatic strips'


def _number(value, name, *, nonnegative=False):
    if type(value) not in (int, float) or not isfinite(value) or abs(value) > 1e50:
        raise ValueError(name + ' requires finite real numeric data')
    if nonnegative and value < 0:
        raise ValueError(name + ' must be nonnegative')
    return float(value)


def _interval(value, name):
    if type(value) not in (tuple, list) or len(value) != 2:
        raise ValueError(name + ' requires exactly two interval endpoints')
    lo, hi = (_number(v, name) for v in value)
    if lo > hi:
        raise ValueError(name + ' interval is reversed')
    return lo, hi


def _tensor(value):
    if type(value) is not dict or set(value) != set(COMPONENTS):
        raise ValueError('Exactly the six named symmetric tensor components are required')
    return {k: _interval(value[k], k) for k in COMPONENTS}


def _absolute(interval):
    return max(abs(interval[0]), abs(interval[1]))


def _scaled_interval(interval, scales):
    """Signed endpoint products, not abs(local)+global or a positive-only scale."""
    values = [a*b for a in _interval(interval, 'stress') for b in _interval(scales, 'scale')]
    return min(values), max(values)


def _add_tensors(a, b):
    a, b = _tensor(a), _tensor(b)
    return {k: (a[k][0]+b[k][0], a[k][1]+b[k][1]) for k in COMPONENTS}


def _zero_tensor():
    return {k: (0., 0.) for k in COMPONENTS}


def _signed_tensor(components, scales):
    if type(components) is not dict or not components or not set(components) <= set(SIGNED_COMPONENTS):
        raise ValueError('Existing signed nominal Cauchy components are required')
    out = _zero_tensor()
    for name, value in components.items():
        value = _number(value, name)
        out[SIGNED_COMPONENTS[name]] = _scaled_interval((value, value), scales)
    return out


def gershgorin_normal_shear_bounds(tensor):
    """Enclose every eigenvalue of every symmetric tensor in a component box.

    Maximum absolute normal traction on any plane is bounded by max(|l-|,
    |l+|), and shear traction by (l+-l-)/2. These demands are compared ONLY
    with the separately adopted normal/shear limits, never a new criterion.
    """
    t = _tensor(tensor)
    xy, xz, yz = (_absolute(t[k]) for k in ('txy', 'txz', 'tyz'))
    radii = (xy+xz, xy+yz, xz+yz)
    lower = min(t[k][0]-r for k, r in zip(('sx', 'sy', 'sz'), radii))
    upper = max(t[k][1]+r for k, r in zip(('sx', 'sy', 'sz'), radii))
    return dict(lambda_lower_mpa=lower, lambda_upper_mpa=upper,
        normal_abs_bound_mpa=max(abs(lower), abs(upper)),
        shear_abs_bound_mpa=(upper-lower)/2,
        all_component_box_tensors_enclosed=True,
        normative_3d_criterion_claimed=False, new_stress_field_created=False)


def plane_box_demands(tensor, plane):
    """Exact corner maximum of the convex plane equivalent-stress norm."""
    t = _tensor(tensor)
    if plane not in ('xy', 'xz'):
        raise ValueError('Only existing ordinary xy/xz nominal walls are supported')
    axes = ('sx', 'sy', 'txy') if plane == 'xy' else ('sx', 'sz', 'txz')
    if any(t[k] != (0., 0.) for k in COMPONENTS if k not in axes):
        raise ValueError('Plane 8400 check rejects nonzero out-of-plane components')
    corners = tuple(product(*(t[k] for k in axes)))
    # hypot avoids cancellation in a*a+b*b-a*b at near equal large values.
    equivalent = max(hypot(a-b/2, sqrt(3)*b/2, sqrt(3)*s) for a, b, s in corners)
    return dict(plane=plane, component_ids=axes,
        normal_1_abs_mpa=_absolute(t[axes[0]]), normal_2_abs_mpa=_absolute(t[axes[1]]),
        shear_abs_mpa=_absolute(t[axes[2]]), equivalent_plane_bound_mpa=equivalent,
        corner_count=len(corners), full_component_box_covered=True,
        formula='sqrt(sigma_1^2 + sigma_2^2 - sigma_1*sigma_2 + 3*tau_12^2)',
        out_of_plane_extension_used=False, transverse_075_reduction_used=False)


def _check(identifier, demand, capacity, source, **context):
    demand, capacity = _number(demand, identifier, nonnegative=True), _number(capacity, 'capacity')
    if capacity <= 0:
        raise ValueError('Positive stress capacity required')
    return dict(check_id=identifier, demand_mpa=demand, capacity_mpa=capacity,
        demand=demand, capacity=capacity, utilization=demand/capacity,
        sufficient_bound_satisfied=demand <= capacity,
        status='SUFFICIENT' if demand <= capacity else 'INCONCLUSIVE_SUFFICIENT_BOUND',
        source=source, actual_failure_proven=False, **context)


def evaluate_member_plane_case(project, c):
    result = _result('TOP_intermediate_member_plane_Case_I')
    result.update(checks=[], region_results=[], resolved_mode_ids=[], source=PLANE_SOURCE)
    try:
        _prepared(project, c)
        factors = _static_factors(project, c, STATIC_ACTION_BASIS)
        produced = produce_nominal_regions(project, c)
        _producer_identity(produced)
        allow = elastic_allowables_autonomous(c.project.material.fy_mpa, c.project.material.fu_mpa, 'I')
        rows, checks = [], []
        for region in produced['regions']:
            for wall, value in region['walls'].items():
                demands = plane_box_demands(value['tensor_intervals_mpa'], value['plane'])
                prefix = region['region']['region_id']+'/'+wall
                local = [_check(prefix+'/'+key, demands[key], allow[capacity], PLANE_SOURCE,
                    region_id=region['region']['region_id'], wall=wall, plane=value['plane'])
                    for key, capacity in (('normal_1_abs_mpa', 'sigma_a_mpa'),
                        ('normal_2_abs_mpa', 'sigma_a_mpa'), ('shear_abs_mpa', 'tau_a_mpa'),
                        ('equivalent_plane_bound_mpa', 'sigma_a_mpa'))]
                rows.append(dict(region_id=region['region']['region_id'], wall=wall,
                    tensor_intervals_mpa=deepcopy(value['tensor_intervals_mpa']), demands=demands, checks=local))
                checks.extend(local)
        passed = bool(checks) and all(v['sufficient_bound_satisfied'] for v in checks)
        result.update(checks=checks, region_results=rows, nominal_field=produced,
            factor_receipt=factors, action_basis=STATIC_ACTION_BASIS, elastic_allowables=allow,
            normal_case='I', full_sigmaT_used=True, transverse_075_reduction_used=False,
            maximum_utilization=max(v['utilization'] for v in checks),
            conditional_bounds_satisfied=passed, all_supplied_bounds_satisfied=passed,
            any_sufficient_bound_exceeded=not passed,
            status='CONDITIONAL_PER_CASE_STATIC_BOUNDS_SATISFIED' if passed else 'INCONCLUSIVE_SUFFICIENT_STATIC_BOUND')
        return result
    except (ValueError, TypeError, ArithmeticError, KeyError, AttributeError) as exc:
        return _invalid(result, exc)


def _producer_identity(produced):
    if type(produced) is not dict:
        raise ValueError('A generated nominal regional dictionary is required')
    for key, value in (('physical_stiffeners', 'present'), ('ordinary_region_boxes_only', True),
            ('all_wheel_magnitudes_summed', True), ('temporal_history_created', False),
            ('sigmaT_faces_assigned', False), ('horizontal_torque_mapped_to_sigmaT', False)):
        if type(produced.get(key)) is not type(value) or produced.get(key) != value:
            raise ValueError('Nominal field identity changed: '+key)
    geometry = produced.get('geometry_inputs_hash')
    if type(geometry) is not str or len(geometry) != 64 or any(c not in '0123456789abcdef' for c in geometry):
        raise ValueError('Explicit physical geometry hash required')
    travel = _interval(produced['full_physical_travel_m'], 'full physical travel')
    if travel[0] >= travel[1]:
        raise ValueError('Nonempty full physical travel required')
    regions = produced['regions']
    if type(regions) not in (tuple, list) or len(regions) < 2:
        raise ValueError('All ordinary physical regions must be nonempty')
    identities, previous_right, seen = [], None, set()
    for row in regions:
        region = row['region']
        keys = {'region_id', 'left_mm', 'right_mm', 'left_station_id', 'right_station_id', 'method', 'physical_panel_spacing_mm'}
        if type(region) is not dict or set(region) != keys:
            raise ValueError('Exact physical region identity required')
        identity = region['region_id']
        if type(identity) is not str or not identity or identity in seen:
            raise ValueError('Unique nonempty region IDs required')
        seen.add(identity)
        left, right = (_number(region[k], k, nonnegative=True) for k in ('left_mm', 'right_mm'))
        if left >= right or (previous_right is not None and left != previous_right):
            raise ValueError('Contiguous ordered physical regions required')
        previous_right = right
        walls = row['walls']
        if type(walls) is not dict or set(walls) != {'top', 'bottom', 'web'}:
            raise ValueError('Every region requires all three ordinary walls')
        wall_identity = {}
        for wall in ('top', 'bottom', 'web'):
            value = walls[wall]
            plane = 'xz' if wall == 'web' else 'xy'
            if value['plane'] != plane:
                raise ValueError('Nominal wall plane changed')
            plane_box_demands(value['tensor_intervals_mpa'], plane)
            thickness = _number(value['thickness_mm'], 'wall thickness')
            if thickness <= 0 or value['welded_attachment_regions_excluded_from_plain_material_category'] is not True:
                raise ValueError('Wall thickness/category identity changed')
            basis = value['nominal_zero_basis']
            if type(basis) is not str or not basis:
                raise ValueError('Nominal zero-component identity is required')
            wall_identity[wall] = dict(plane=plane, thickness_mm=thickness, nominal_zero_basis=basis,
                welded_attachment_regions_excluded_from_plain_material_category=True)
        local_model = row['local_model']
        if type(local_model) is not str or not local_model:
            raise ValueError('Regional nominal model identity required')
        identities.append(dict(region=deepcopy(region), walls=wall_identity, local_model=local_model))
    return dict(geometry_inputs_hash=geometry, full_physical_travel_m=list(travel), regions=identities,
        physical_stiffeners='present', ordinary_region_boxes_only=True,
        all_wheel_magnitudes_summed=True, temporal_history_created=False,
        sigmaT_faces_assigned=False, horizontal_torque_mapped_to_sigmaT=False)


def _digest(value):
    return sha256(json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()).hexdigest()


def _validate_pool(pool):
    if type(pool) is not dict or pool.get('schema') != POOL_SCHEMA:
        raise ValueError('A nonempty internally pooled regional field is required')
    if type(pool.get('count')) is not int or pool['count'] < 1:
        raise ValueError('Positive integer regional case count required')
    if pool.get('action_family_authenticated') is not False:
        raise ValueError('Regional pooling cannot authenticate an action family')
    unsigned = {k: v for k, v in pool.items() if k != 'integrity_sha256'}
    if pool.get('integrity_sha256') != _digest(unsigned):
        raise ValueError('Pooled regional fields changed after their integrity receipt')
    if _producer_identity(pool) != pool['nominal_identity']:
        raise ValueError('Pooled nominal identity changed')
    return pool


def _pool_regional_fields(pool, produced):
    """Copy-on-write union; caller alone authenticates regenerated family members."""
    identity = _producer_identity(produced)
    if pool is None:
        result = deepcopy(identity)
        result.update(schema=POOL_SCHEMA, count=1, nominal_identity=deepcopy(identity),
            action_family_authenticated=False, integrity_is_authentication=False)
        for target, source in zip(result['regions'], produced['regions']):
            for wall in ('top', 'bottom', 'web'):
                target['walls'][wall]['tensor_intervals_mpa'] = {
                    k: list(v) for k, v in _tensor(source['walls'][wall]['tensor_intervals_mpa']).items()}
    else:
        _validate_pool(pool)
        if identity != pool['nominal_identity']:
            raise ValueError('Regional IDs, geometry, full travel, walls or nominal identity differ')
        result = deepcopy(pool)
        result['count'] += 1
        for target, source in zip(result['regions'], produced['regions']):
            for wall in ('top', 'bottom', 'web'):
                old = target['walls'][wall]['tensor_intervals_mpa']
                new = _tensor(source['walls'][wall]['tensor_intervals_mpa'])
                for k in COMPONENTS:
                    old[k] = [min(old[k][0], new[k][0]), max(old[k][1], new[k][1])]
    result.pop('integrity_sha256', None)
    result['integrity_sha256'] = _digest(result)
    _validate_pool(result)
    return result


def pool_regional_fields(pool, produced):
    """Strict public union API; malformed inputs never become an empty pool."""
    try:
        return _pool_regional_fields(pool, produced)
    except (KeyError, TypeError, AttributeError) as exc:
        raise ValueError('Malformed nominal regional input: '+str(exc)) from exc


def _tensor_checks(prefix, tensor, material, *, section_axis=None, **context):
    bounds = gershgorin_normal_shear_bounds(tensor)
    source = LOCAL_SOURCE if section_axis else 'NBR 8800 6.5.3/.4/.5: separate local normal/shear limits, algebraic demand enclosure only'
    checks = [_check(prefix+'/normal_stress_bound', bounds['normal_abs_bound_mpa'], material.fy_mpa/GAMMA_A1, source, **context),
        _check(prefix+'/shear_stress_bound', bounds['shear_abs_bound_mpa'], .60*material.fy_mpa/GAMMA_A1, source, **context)]
    # Actual no-hole prismatic cut, not an arbitrary oblique rupture plane.
    if section_axis == 'y':
        shear = hypot(_absolute(tensor['txy']), _absolute(tensor['tyz']))
        checks.extend((
            _check(prefix+'/actual_cut_tension_net_rupture', max(0., tensor['sy'][1]), material.fu_mpa/GAMMA_A2,
                'NBR 8800 6.5.3(b), actual wholly connected unperforated y-normal section; Ae=Ag', **context),
            _check(prefix+'/actual_cut_shear_net_rupture', shear, .60*material.fu_mpa/GAMMA_A2,
                'NBR 8800 6.5.5(b), resultant shear on actual unperforated y-normal section', **context)))
    return checks, bounds


def _continuous_section_tensor(section, nominal_function, *, normal_key, scales):
    normal = section[normal_key]
    if type(normal) not in (tuple, list) or len(normal) != 2:
        raise ValueError('Both actual section normal extrema required')
    ends = [_number(v, 'section normal') for v in normal]
    tau = _number(section['rectangular_peak_shear_mpa'], 'section shear', nonnegative=True)
    tensor = _zero_tensor()
    supplied = nominal_function['sufficient_component_intervals_mpa']
    normal_interval = _interval(supplied['sigma_yy'], 'whole-section normal')
    shear_interval = _interval(supplied['tau_yz'], 'whole-section shear')
    if (normal_interval != (min(ends), max(ends)) or _absolute(shear_interval) != tau
            or nominal_function['u_interval'] != (-1., 1.)
            or nominal_function['torsional_or_interior_tensor_interpolation'] is not False):
        raise ValueError('Existing whole-section intervals and section extrema disagree')
    tensor['sy'] = _scaled_interval(normal_interval, scales)
    tensor['tyz'] = _scaled_interval(shear_interval, scales)
    return tensor


def evaluate_concurrent_transfer(project, pooled_fields, transfer, *, G_factor_range):
    """Cover all local force scales against both neighboring member boxes.

    Global boxes already contain real fixed G. The 45-kN case REPLACES local
    G; it never augments those global boxes. Endpoints cover linear interface
    tractions. Full-section component intervals, not three snapshots, cover
    rectangular cuts. Pooled case/component combinations are sufficient
    enclosures, not simultaneous histories or physical failure certificates.
    """
    result = _result('TOP_concurrent_member_local_static')
    result.update(checks=[], point_results=[], section_results=[], cut_results=[],
        coverage={}, resolved_mode_ids=[], unresolved_mode_ids=[MODE_ID],
        maximum_utilization=None, scope_uncertainties=[], source=LOCAL_SOURCE,
        normative_3d_criterion_claimed=False, new_stress_field_created=False,
        temporal_history_created=False, minimum_force_added_globally=False)
    try:
        project.validate()
        pool = _validate_pool(pooled_fields)
        factors = _interval(G_factor_range, 'structural G factor range')
        if factors[0] < 0:
            raise ValueError('Structural G factors must be nonnegative')
        if type(transfer) is not SelfweightTransfer or transfer.prepared_case_authenticated is not True:
            raise ValueError('Typed prepared-authenticated selfweight transfer required')
        if transfer.structural_G_factor != factors[1]:
            raise ValueError('Transfer must be generated at the exact maximum G factor')
        basis = project.basis()
        if (transfer.prepared_stationary_ledger_sha256 != basis.stationary_ledger_sha256
                or pool['geometry_inputs_hash'] != transfer.geometry_inputs_hash
                or transfer.geometry_inputs_hash != basis.geometry_inputs_hash):
            raise ValueError('Prepared geometry or physical mass ledger identity changed')
        fresh = assess_selfweight_transfer(project, structural_G_factor=factors[1])
        if replace(transfer, prepared_case_authenticated=False, prepared_stationary_ledger_sha256=None) != fresh:
            raise ValueError('Selfweight transfer was changed; regenerate actual physical geometry, mass and forces')
        layout = project.intermediates.layout
        inventory = RegionInventory(project.structure.span_m*1000,
            tuple(StationLine(s.station_id, s.x_mm) for s in sorted(layout.stations, key=lambda s: s.x_mm)))
        if [r['region'] for r in pool['regions']] != [asdict(r) for r in inventory.regions()]:
            raise ValueError('Pooled regions do not match every physical project region')
        if len(transfer.stations) != len(layout.stations) or not transfer.stations:
            raise ValueError('Every physical station requires a nonempty transfer')
        steels = {v.material_id: v for v in project.intermediates.plate_materials}
        checks, points, sections, cuts, retained = [], [], [], [], []
        coverage = []
        for station in transfer.stations:
            physical = next(s for s in layout.stations if s.station_id == station.station_id)
            neighbors = [r for r in pool['regions'] if station.station_id in
                (r['region']['left_station_id'], r['region']['right_station_id'])]
            if len(neighbors) != 2 or {p.side for p in station.connections} != {-1, 1}:
                raise ValueError('Both physical sides and both adjoining regions required')
            for plate in station.connections:
                material = steels[physical.pair.material.material_id]
                for case in plate.cases:
                    floor = case.case_id == 'connection_minimum_same_force_line'
                    if not floor and case.case_id != 'real_factored_G':
                        raise ValueError('Unknown local load case')
                    force_range = tuple(max(plate.G_characteristic_N*f, MINIMUM_CONNECTION_FORCE_N) if floor
                        else plate.G_characteristic_N*f for f in factors)
                    if case.required_Fz_N != force_range[1]:
                        raise ValueError('Local force is not the actual G or the replacing 45-kN floor')
                    scales = ((0., 0.) if force_range[1] == 0 else
                        (force_range[0]/force_range[1], 1.))
                    common = dict(station_id=station.station_id, connection_id=plate.physical_connection_id,
                        side=plate.side, local_case_id=case.case_id, local_force_range_N=force_range,
                        local_scale_range=scales, minimum_replaces_local_G=floor)
                    prefix = plate.physical_connection_id+'/'+case.case_id
                    for original in case.checks:
                        retained.append(dict(**common, **asdict(original)))
                    snapshots = case.section_results['signed_interface_points']
                    section_snapshots = case.section_results['signed_section_points']
                    if len(snapshots) != 10 or len(section_snapshots) != 6:
                        raise ValueError('Complete existing interface and section snapshot inventories required')
                    for point in (*snapshots, *section_snapshots):
                        role = point['material_role']
                        if role not in ('plate', 'beam_web', 'beam_flange'):
                            raise ValueError('Unknown local receiving material role')
                        wall = 'web' if role == 'beam_web' else 'top' if role == 'beam_flange' else None
                        local = _signed_tensor(point['tensor_components_mpa'], scales)
                        selected = neighbors if wall is not None else (None,)
                        for region in selected:
                            rid = None if region is None else region['region']['region_id']
                            global_tensor = _zero_tensor() if region is None else region['walls'][wall]['tensor_intervals_mpa']
                            combined = _add_tensors(local, global_tensor)
                            context = dict(**common, point_id=point['point_id'], material_role=role,
                                region_id=rid, wall=wall)
                            rows, bounds = _tensor_checks(prefix+'/'+str(rid)+'/'+point['point_id'], combined,
                                material if role == 'plate' else project.material, **context)
                            checks.extend(rows)
                            points.append(dict(**context, coordinates={k: point[k] for k in
                                ('x_from_station_mm', 'y_mm', 'z_mm')}, tensor_intervals_mpa=combined,
                                local_tensor_intervals_mpa=local, member_field_added=wall is not None,
                                bounds=bounds, coverage_kind='section_snapshot_diagnostic' if point in section_snapshots
                                    else 'linear_interface_endpoint', checks=rows))
                    # The real top ligament is the plate-side counterpart of
                    # the tp-wide CJP contact. Reuse its existing signed q/tp
                    # tractions, without attaching ANY global beam stresses.
                    for point in snapshots:
                        if point['material_role'] != 'beam_flange':
                            continue
                        local = _signed_tensor(point['tensor_components_mpa'], scales)
                        context = dict(**common, point_id=point['point_id']+'/plate_top_ligament',
                            material_role='plate', region_id=None, wall=None)
                        rows, bounds = _tensor_checks(prefix+'/'+context['point_id'], local, material, **context)
                        checks.extend(rows)
                        points.append(dict(**context, tensor_intervals_mpa=local,
                            local_tensor_intervals_mpa=local, member_field_added=False,
                            bounds=bounds, coverage_kind='linear_plate_top_ligament_endpoint', checks=rows))
                    functions = {f['section_id']: f for f in case.section_results['nominal_section_stress_functions']}
                    for key, normal_key, role in (
                            ('plate_root', 'normal_endpoints_mpa', 'plate'),
                            ('flange_physical_strip', 'normal_extrema_mpa', 'beam_flange')):
                        function_id = 'plate_root' if key == 'plate_root' else 'flange_strip_root'
                        local = _continuous_section_tensor(case.section_results[key], functions[function_id],
                            normal_key=normal_key, scales=scales)
                        for region in neighbors if role == 'beam_flange' else (None,):
                            rid = None if region is None else region['region']['region_id']
                            combined = _add_tensors(local, _zero_tensor() if region is None
                                else region['walls']['top']['tensor_intervals_mpa'])
                            context = dict(**common, section_id=key, material_role=role, region_id=rid,
                                wall='top' if region is not None else None)
                            rows, bounds = _tensor_checks(prefix+'/'+str(rid)+'/'+key+'/whole_section', combined,
                                material if role == 'plate' else project.material, section_axis='y', **context)
                            checks.extend(rows)
                            sections.append(dict(**context, tensor_intervals_mpa=combined,
                                bounds=bounds, whole_actual_section_enclosed=True,
                                three_snapshots_used_as_continuum_maximum=False,
                                interpolation_created=False, checks=rows))
                    # Actual CJP effective plane, not tp receiving contact and not a fillet.
                    cjp = case.section_results['CJP_resolved_components']
                    fy = min(material.fy_mpa, project.material.fy_mpa)
                    for field, capacity, label in (('sigma_z_endpoints_mpa', fy/GAMMA_A1, 'normal'),
                            ('tau_yz_endpoints_mpa', .60*fy/GAMMA_A1, 'shear')):
                        endpoints = cjp[field]
                        demand = max(_absolute(_scaled_interval((_number(v, field), _number(v, field)), scales)) for v in endpoints)
                        checks.append(_check(prefix+'/actual_CJP_effective_plane/'+label, demand, capacity,
                            'NBR 8800 Table 9 true CJP effective plane; lesser plate/beam fy, separate normal/shear',
                            **common, weld_type='CJP', fillet_capacity_used=False, material_role='CJP'))
            # A different coverage: actual two-cut mean shear, not local interior maxima.
            for original in station.pair_receiver_checks:
                for region in neighbors:
                    rid = region['region']['region_id']
                    global_shear = _absolute(region['walls']['web']['tensor_intervals_mpa']['txz'])
                    row = _check(station.station_id+'/'+rid+'/'+original.check_id+'/concurrent',
                        original.demand+global_shear, original.capacity, original.basis,
                        station_id=station.station_id, region_id=rid, wall='web',
                        local_mean_shear_mpa=original.demand, global_txz_bound_mpa=global_shear,
                        coverage_kind='paired_vertical_cut_average_shear', elastic_peak_claimed=False)
                    checks.append(row); cuts.append(row)
            coverage.append(dict(station_id=station.station_id, sides=[-1, 1],
                adjoining_region_ids=[r['region']['region_id'] for r in neighbors],
                both_adjoining_region_boxes_used=True, physical_connection_count=2))
        if not checks or not points or not sections or not cuts or not retained:
            raise ValueError('No finite local coverage can be silently omitted')
        combined_pass = all(v['sufficient_bound_satisfied'] for v in checks)
        retained_pass = all(v['utilization'] <= 1 for v in retained)
        passed = combined_pass and retained_pass
        unresolved = [v for v in transfer.unresolved_mode_ids if v != MODE_ID]
        result.update(checks=checks, point_results=points, section_results=sections, cut_results=cuts,
            retained_transfer_checks=retained, retained_transfer_checks_sufficient=retained_pass,
            concurrent_bounds_satisfied=combined_pass, conditional_bounds_satisfied=passed,
            all_supplied_bounds_satisfied=passed, any_sufficient_bound_exceeded=not passed,
            maximum_utilization=max([v['utilization'] for v in checks]+[v['utilization'] for v in retained]),
            resolved_mode_ids=[MODE_ID], unresolved_mode_ids=unresolved,
            scope_uncertainties=list(transfer.pending),
            coverage=dict(stations=coverage, regional_case_count=pool['count'],
                full_physical_travel_m=pool['full_physical_travel_m'], G_factor_range=factors,
                whole_actual_sections_enclosed=True, linear_interface_endpoints_complete=True,
                same_point_snapshots_retained=True, paired_cut_average_checks_separate=True,
                real_G_already_present_globally=True, local_floor_substitutes_not_adds=True,
                beam_stress_added_to_plate=False, action_family_authentication_owned_by_caller=True),
            geometry_inputs_hash=transfer.geometry_inputs_hash,
            physical_mass_ledger_signature=transfer.physical_mass_ledger_signature,
            prepared_case_authenticated=True,
            status='CONDITIONAL_CONCURRENT_STATIC_BOUNDS_SATISFIED' if passed else 'INCONCLUSIVE_SUFFICIENT_STATIC_BOUND')
        # The transfer's one now-executed interaction placeholder is not an uncertainty.
        from .selfweight_transfer import MECHANISM_PENDING
        result['scope_uncertainties'] = [v for v in result['scope_uncertainties'] if v not in MECHANISM_PENDING]
        result['pending'] = list(result['scope_uncertainties'])
        return result
    except (ValueError, TypeError, ArithmeticError, KeyError, AttributeError, StopIteration) as exc:
        return _invalid(result, exc)


__all__ = ['evaluate_member_plane_case', 'pool_regional_fields', 'evaluate_concurrent_transfer',
    'gershgorin_normal_shear_bounds', 'plane_box_demands']
