"""Declared TOP intermediate-stabilizer route, separate from the old bare route.

Only regenerated physical inputs are consumed. No old calculation is re-signed;
no bare-section/no-attachment fatigue result is promoted to this geometry.
"""
from dataclasses import asdict
from itertools import product
import time
from math import isfinite
from lro_beams.autonomous_actions import ActionFactors
from underslung_runway_candidate.autonomous_workflow.model import signature
from ..cmaa_strength import (evaluate_top_cmaa_nbr_strength,generate_top_cmaa_characteristic_actions,
    prepare_top_cmaa_nbr_uls_case,_variants)
from ..native_service import evaluate_top_service_criteria
from ..service import CMAAServicePremises
from ..checks import _prepared_key
from .prescriptive import assemble_prescriptive
from .family import evaluate_intermediate_nbr_family,prepare_intermediate_normal_case
from .static_adapter import evaluate_intermediate_sign_case
from .selfweight_transfer import assess_prepared_selfweight_transfer,MECHANISM_PENDING
from .nominal_field import produce_nominal_regions
from .concurrent_static import (pool_regional_fields,evaluate_concurrent_transfer,
    evaluate_member_plane_case,MODE_ID)
from ..nbr_fatigue import generate_top_nbr_actions
from .regional_resistance import regional_case_demands, compose_regional_shear, replace_bare_shear_obligation

RESULT_SCHEMA='LRO_TOP_INTERMEDIATE_RESULT_V1'


def _conditional_scope(label,results,key):
    """Never use a sufficient flag to hide missing/nested evidence or FAIL.

    Only these per-case consumers are accepted here. Prescriptive-kernel
    explanatory pending lists are intentionally NOT passed to this function;
    their finite obligations have a separate, explicitly named compositor.
    """
    rows=list(results);errors=[];failed=False;invalid=not rows;count=0;exceeded=False
    positive={'SATISFIED','PASS','SUFFICIENT','CONDITIONAL_PER_CASE_STATIC_BOUNDS_SATISFIED',
        'CONDITIONAL_PER_CASE_NOMINAL_SIGN_BOUNDS_SATISFIED','CONDITIONAL_STATIC_BOUND_SATISFIED',
        'CONDITIONAL_CONCURRENT_STATIC_BOUNDS_SATISFIED'}
    negative={'INCONCLUSIVE','INCONCLUSIVE_SUFFICIENT_STATIC_BOUND','INCONCLUSIVE_SUFFICIENT_NOMINAL_SIGN_BOUND',
        'INCONCLUSIVE_SUFFICIENT_BOUND','NOT_SUFFICIENT','COMPONENT_EXCEEDED','INCONCLUSIVE_SUFFICIENT_SIGN_BOUND'}
    def inspect(value):
        nonlocal failed,invalid,exceeded
        if isinstance(value,dict):
            if value.get('actual_failure_proven') is True or value.get('status')=='FAIL':failed=True
            if value.get('input_valid',True) is not True:invalid=True
            if 'status' in value:
                status=value['status']
                if type(status) is not str:invalid=True
                elif status in negative:exceeded=True
                elif status not in positive and status!='FAIL':invalid=True
            if 'unresolved_mode_ids' in value:
                modes=value['unresolved_mode_ids']
                if type(modes) not in (list,tuple) or any(type(v) is not str or not v for v in modes):invalid=True
                else:errors.extend('Unresolved explicit mechanism: '+v for v in modes)
            if 'actual_failure_proven' in value and type(value['actual_failure_proven']) is not bool:invalid=True
            for flag in ('sufficient_bound_satisfied','conditional_bounds_satisfied','all_supplied_bounds_satisfied','all_station_sign_bounds_satisfied'):
                if flag in value:
                    if type(value[flag]) is not bool:invalid=True
                    elif not value[flag]:exceeded=True
            for name in ('utilization','demand','capacity','demand_mpa','capacity_mpa'):
                if name in value:
                    v=value[name]
                    if type(v) not in (int,float) or not isfinite(v):invalid=True
                    elif name=='utilization' and (v<0 or v>1):
                        if v<0:invalid=True
                        else:exceeded=True
            for dkey,ckey in (('demand','capacity'),('demand_mpa','capacity_mpa')):
                if dkey in value and ckey in value:
                    d,c=value[dkey],value[ckey]
                    if type(d) in (int,float) and type(c) in (int,float) and isfinite(d) and isfinite(c):
                        if d<0 or c<=0:invalid=True
                        elif d>c:exceeded=True
            if value.get('any_sufficient_bound_exceeded') is True:exceeded=True
            if value.get('status') in ('PENDING','INVALID_INPUT','SOURCE_CHANGED_DURING_ASSESSMENT'):
                errors.append('Incomplete nested conditional evidence: '+str(value.get('status')))
            for name in ('pending','errors'):
                if name in value:
                    if not isinstance(value[name],(tuple,list)):invalid=True
                    else:errors.extend(str(v) for v in value[name])
            for item in value.values():inspect(item)
        elif isinstance(value,(tuple,list)):
            for item in value:inspect(item)
    for row in rows:
        if not isinstance(row,dict):invalid=True;continue
        inspect(row)
        evidence=row.get('checks',row.get('patch_results'))
        # Sign consumers expose the station-owned patch inventory instead of
        # duplicating the full certificates at the result root.
        if evidence is None and isinstance(row.get('station_results'),(tuple,list)):
            evidence=[p for s in row['station_results'] for p in s.get('patch_results',())]
        if not isinstance(evidence,(tuple,list)) or not evidence:invalid=True
        else:count+=len(evidence)
    errors=sorted(set(errors))
    passed=bool(rows) and not failed and not errors and not invalid and not exceeded and all(row.get(key) is True for row in rows)
    return dict(label=label,status='FAIL' if failed else 'PENDING' if invalid or errors else 'SATISFIED' if passed else 'INCONCLUSIVE',
        checks_count=count,
        actual_failure_proven=failed,pending=errors,criterion_satisfied=passed,
        verification_executed=bool(rows) and not invalid,
        bound_exceeded_not_physical_failure=bool(rows) and not failed and not invalid and not errors and not passed)


def _cmaa_signs(project,strength,progress=None,*,prescriptive=None):
    """Reconstruct the exact same complete CMAA-origin/ULS/SK recipe, never effort input."""
    basis=project.basis()
    characteristic=generate_top_cmaa_characteristic_actions(basis,project.bridge,project.cmaa_action_physical())
    by_id={c['id']:c for c in characteristic}
    factors_by_identity={(present,signature(asdict(f))):f for present,f in _variants(basis,project.structure.extra_dead_kind)}
    rows=[];receipts=[];G_reference=None;regional_pool=None;G_factors=[];shear_cases=[]
    prescriptive=assemble_prescriptive(project) if prescriptive is None else prescriptive
    if not strength.get('cases'):raise ValueError('No complete CMAA global action family is available')
    expected={(case_id,present,fkey,coordinates) for case_id in by_id
        for present,fkey in factors_by_identity for coordinates in product((-1.,1.),repeat=2)}
    actual=[]
    for entry in strength['cases']:
        coordinates=entry.get('skew_coordinates')
        if (type(entry.get('crane_variable_present')) is not bool or
            not isinstance(coordinates,(tuple,list)) or len(coordinates)!=2 or
            any(type(v) not in (int,float) or v not in (-1.,1.) for v in coordinates)):
            raise ValueError('Explicit complete ULS/SK membership required')
        actual.append((entry['source_case'],entry['crane_variable_present'],signature(entry['factors']),tuple(coordinates)))
    if len(actual)!=len(expected) or len(set(actual))!=len(actual) or set(actual)!=expected:
        raise ValueError('CMAA family is missing, duplicating or replacing a regenerated ULS/SK case')
    for i,entry in enumerate(strength['cases'],1):
        case=by_id[entry['source_case']]
        present=entry.get('crane_variable_present')
        if type(present) is not bool:raise ValueError('Explicit actual variable-action membership required')
        factors=factors_by_identity.get((present,signature(entry['factors'])))
        if factors is None:raise ValueError('Factor recipe is not a regenerated normal-ULS family member')
        c,receipt=prepare_top_cmaa_nbr_uls_case(basis,case,factors,
            skew_coordinates=tuple(entry['skew_coordinates']),extra_dead_kind=project.structure.extra_dead_kind)
        if receipt.prepared_signature!=entry.get('prepared_signature') or _prepared_key(c)!=entry.get('prepared_signature'):
            raise ValueError('Global source-family case and reconstructed sign case differ')
        result=evaluate_intermediate_sign_case(project,c)
        regional_pool=pool_regional_fields(regional_pool,produce_nominal_regions(project,c))
        G_factors.append(c.factors.dead_support)
        shear=regional_case_demands(project,prescriptive,c,entry['id']);shear_cases.append(shear)
        rows.append(result);receipts.append(dict(case_id=entry['id'],prepared_signature=receipt.prepared_signature,
            sign_result_signature=signature(result),regional_shear_signature=signature(shear)))
        if G_reference is None or c.factors.dead_support>G_reference.factors.dead_support:G_reference=c
        if progress and (i==1 or i%128==0 or i==len(strength['cases'])):
            progress(i,len(strength['cases']),'Domínio de interrupção nas combinações CMAA/NBR')
    return dict(results=rows,case_receipts=receipts,case_count=len(rows),action_family_authenticated=True,
        project_signature=signature(project.to_dict()),regional_shear_cases=shear_cases,
        regional_pool=regional_pool,G_factor_range=(min(G_factors),max(G_factors))),G_reference


def _nbr_member_planes(project,family,progress=None):
    """Regenerate the same Case-I membership; never relabel an ELU stress box."""
    basis=project.basis();a=project.actions
    generated=generate_top_nbr_actions(basis,project.bridge,psi=a.dynamics()['psi'],
        horizontal_dynamic_factor=a.horizontal_dynamic_factor,horizontal_dynamic_source=a.horizontal_dynamic_source,
        rolling_guidance=project.nbr_rolling_guidance)
    cases=generated['cases'];receipts=family.get('case_receipts')
    if (family.get('action_family_authenticated') is not True or
        family.get('project_signature')!=signature(project.to_dict()) or
        family.get('action_domain_signature')!=signature(generated) or
        not cases or len(cases)!=family.get('case_count') or not isinstance(receipts,(list,tuple)) or len(receipts)!=len(cases)):
        raise ValueError('Complete regenerated NBR Case-I family required for the separate plane check')
    if len({r['action_signature'] for r in receipts})!=len(receipts):
        raise ValueError('Duplicate Case-I membership')
    by_action={r['action_signature']:r for r in receipts};rows=[];bindings=[]
    for i,case in enumerate(cases,1):
        receipt=by_action.get(signature(case))
        if receipt is None or not case['contact_valid']:raise ValueError('Foreign or invalid Case-I action')
        c,ledger=prepare_intermediate_normal_case(basis,case,project)
        if (_prepared_key(c)!=receipt['normal_prepared_signature'] or
            signature(ledger)!=signature(receipt['normal_factor_ledger'])):
            raise ValueError('Case-I plane action/factor identity differs from the regenerated family')
        row=evaluate_member_plane_case(project,c);rows.append(row)
        bindings.append(dict(action_signature=signature(case),prepared_signature=_prepared_key(c),result_signature=signature(row)))
        if progress and (i==1 or i%32==0 or i==len(cases)):progress(i,len(cases),'Estado plano nominal NBR 8400, Caso I')
    return dict(case_count=len(rows),action_family_authenticated=True,results=rows,case_receipts=bindings)


def _transfer_scope(transfer,concurrent,expected_cases):
    """Resolve only the named component obligation, retaining every unknown one."""
    checks=[asdict(c) for s in transfer.stations for p in s.connections for case in p.cases for c in case.checks]
    checks.extend(asdict(c) for s in transfer.stations for c in s.pair_receiver_checks)
    resolved=(concurrent.get('input_valid') is True and not concurrent.get('errors')
        and concurrent.get('resolved_mode_ids')==[MODE_ID] and bool(concurrent.get('checks'))
        and concurrent.get('coverage',{}).get('regional_case_count')==expected_cases
        and concurrent.get('geometry_inputs_hash')==transfer.geometry_inputs_hash
        and concurrent.get('physical_mass_ledger_signature')==transfer.physical_mass_ledger_signature)
    unresolved=[v for v in transfer.unresolved_mode_ids if not (resolved and v==MODE_ID)]
    pending=[p for p in transfer.pending if not (resolved and MODE_ID in transfer.unresolved_mode_ids and p in MECHANISM_PENDING)]
    pending.extend('Unresolved explicit local mechanism: '+v for v in unresolved)
    pending.extend(str(v) for v in concurrent.get('pending',()))
    pending=sorted(set(pending))
    sufficient=bool(checks) and not pending and transfer.executed_checks_sufficient
    return dict(label='Peso próprio real e capacidade mínima local do grupo misto',
        status='PENDING' if not checks or pending else 'SATISFIED' if sufficient else 'INCONCLUSIVE',
        criterion_satisfied=sufficient,verification_executed=bool(checks),actual_failure_proven=False,
        pending=pending,checks_count=len(checks),unresolved_mode_ids=unresolved,
        component_obligation_resolution=dict(mode_id=MODE_ID,resolved=resolved,
            resolving_result_signature=signature(concurrent) if resolved else None),
        sufficient_bound_exceeded=any(c['utilization']>1 for c in checks),
        actual_G_and_connection_floor_are_distinct=True)


def analyze_intermediate_project(project,*,controls,progress=None):
    from ..pipeline import source_receipt,_scope,_outcome
    from ..project import checked_tree
    project.validate();controls.validate()
    if project.intermediates is None:raise ValueError('Physical adopted intermediate inventory required')
    if project.cmaa_actions is None:raise ValueError('First intermediate route requires the selected CMAA characteristic-origin normal strength family')
    if not controls.evaluate_fatigue:
        raise ValueError('The adopted intermediate route requires its new attachment fatigue inventory; disabling it cannot approve this route')
    if not controls.evaluate_service:raise ValueError('Service cannot be silently omitted from the complete selected intermediate route')
    before=source_receipt();input_signature=signature(project.to_dict());start=time.monotonic()
    prescriptive=assemble_prescriptive(project)
    strength=evaluate_top_cmaa_nbr_strength(project.basis(),project.bridge,project.cmaa_action_physical(),
        stability_premises=project.stability,extra_dead_kind=project.structure.extra_dead_kind,
        verification_lengths=project.verification_lengths,
        progress=(lambda i,n:progress(i,n,'Componentes e estabilidade global CMAA/NBR')) if progress else None)
    cmaa_sign,G_case=_cmaa_signs(project,strength,progress,prescriptive=prescriptive)
    transfer=assess_prepared_selfweight_transfer(project,G_case)
    concurrent=evaluate_concurrent_transfer(project,cmaa_sign['regional_pool'],transfer,
        G_factor_range=cmaa_sign['G_factor_range'])
    family=evaluate_intermediate_nbr_family(project,progress=progress)
    member_planes=_nbr_member_planes(project,family,progress)
    regional_shear=compose_regional_shear(project,prescriptive,cmaa_sign,family)
    selected_components=replace_bare_shear_obligation(strength['section_components'],regional_shear)
    service=evaluate_top_service_criteria(project.basis(),project.bridge,
        cmaa_premises=CMAAServicePremises(**project.service) if project.service else None,
        nbr_premises=project.nbr_service,manual_limits=project.manual_service,rolling_guidance=project.nbr_rolling_guidance)
    geometry_ok=prescriptive.geometry_prescriptive_candidates_sufficient
    geometry_scope=dict(label='Geometria, material, Is e detalhamento prescrito dos intermediários',
        status='SATISFIED' if geometry_ok else 'PENDING' if not prescriptive.detail_requirements_all_specified else 'INCONCLUSIVE',
        criterion_satisfied=geometry_ok,verification_executed=True,actual_failure_proven=False,
        pending=[] if prescriptive.detail_requirements_all_specified else [p for s in prescriptive.stations for p in s.detail.pending],
        checks_count=len(prescriptive.stations))
    transfer_scope=_transfer_scope(transfer,concurrent,cmaa_sign['case_count'])
    scopes=dict(
        normal_uls_strength=_scope('Resistência nominal NBR8800 sobre origens CMAA, cisalhamento por região',[selected_components]),
        bare_web=_scope('Introdução vertical localizada e regiões sem crédito de painel',[strength['bare_web']]),
        supplementary_stability=_scope('Estabilidade complementar EN C.2, sem crédito de rigidez das chapas',[strength['stability']]),
        intermediate_geometry=geometry_scope,
        intermediate_interruption_sign=_conditional_scope('Domínio nominal da interrupção junto à mesa tracionada',
            (*family['sign_case_results'],*cmaa_sign['results']),'all_station_sign_bounds_satisfied'),
        intermediate_local_static=_conditional_scope('Compressão local nominal NBR10084 por painel real',family['static_case_results'],'conditional_bounds_satisfied'),
        intermediate_member_plane=_conditional_scope('Combinação plana nominal NBR8400, Caso I',member_planes['results'],'conditional_bounds_satisfied'),
        intermediate_G_transfer=transfer_scope,
        intermediate_static_interaction=_conditional_scope('Solicitações locais concomitantes: mecanismos NBR8800',[concurrent],'conditional_bounds_satisfied'),
        nominal_fatigue=_scope('Fadiga nominal NBR8400: regiões ordinárias e detalhes direcionais',[family['fatigue']]),
        cmaa_service=_scope('Flechas globais: CMAA/NBR e restrição de projeto',[service]))
    member_status=_outcome(scopes.values())
    # These checks never qualify actual hardware/building or manufacturing.
    if source_receipt()!=before or signature(project.to_dict())!=input_signature:
        raise ValueError('Inputs or numerical source changed during adopted intermediate assessment')
    out=dict(schema=RESULT_SCHEMA,identity=project.identity,project_label=project.label,
        project_signature=input_signature,source_receipt=before,status=member_status,
        scopes=scopes,scope_groups=dict(assessed_member=list(scopes),external_connections=['support_connections']),
        assessed_member_scope_status=member_status,assessed_member_scopes_satisfied=member_status=='SATISFIED',
        verification_lengths=None if project.verification_lengths is None else project.verification_lengths.to_dict(),
        cmaa_strength=strength,cases=strength['cases'],intermediate_prescriptive=prescriptive.to_dict(),
        intermediate_NBR_family=family,intermediate_CMAA_sign=cmaa_sign,intermediate_selfweight_transfer=transfer.to_dict(),
        intermediate_member_planes=member_planes,intermediate_concurrent_static=concurrent,
        intermediate_regional_shear=regional_shear,assessed_section_components=selected_components,
        cmaa_bare_section_components_are_diagnostic=True,
        nbr_fatigue=family['fatigue'],selected_fatigue_method='NBR8400_classified_life_directional_intermediate_details',
        cmaa_fatigue=None,fatigue=None,service=service,
        generated_case_count=len(strength['cases']),physical_endpoint_records=len(family['action_domain']['records']),
        physical_runway_configurations=2*len(family['action_domain']['records']),
        selected_action_method='CMAA74_2020_CHARACTERISTIC_NBR8800_NORMAL_ULS',
        local_static_action_method='NBR10084_8400_NORMAL_CASE_I_WITH_Mx',
        physical_stiffeners='present',intermediate_function='shear_stabilizer_only',
        extra_bearing_or_bracing_function_credited=False,global_EI_J_Cw_credit=False,
        whole_design_complete=False,whole_member_qualified=False,
        actual_failure_proven=any(s.get('actual_failure_proven') is True for s in scopes.values()),
        external_efforts_required=False,source_status_ledger={k:asdict(v) for k,v in project.sources.items()},
        controls=asdict(controls),hoist_dynamics=project.actions.dynamics(),elapsed_seconds=time.monotonic()-start,
        basis_statement='Published TOP intermediate detail; CMAA action origins, NBR8800 global component resistance, previously adopted EN C.2/CISC nominal analysis; real-panel NBR10084 sigmaT, NBR8400 directional classified fatigue. No own shell model or actual connection hardware certification.',
        bound_scope='Every exceeded sufficient bound is inconclusive for section adequacy, not a proven physical failure or an unimplemented check.',
        station_approval=False,calculation_route_available=True,
        station_approval_scope="Actual fabrication and hardware certification are outside the assessed nominal calculation scope.",
        nominal_station_criteria_satisfied=member_status=='SATISFIED',
        route_execution_complete=all(s['status'] not in ('PENDING','INVALID_INPUT') and not s.get('pending') for s in scopes.values()),
        full_route_incomplete_reasons=sorted({p for s in scopes.values() for p in s.get('pending',())}))
    checked_tree(out,'result',allow_exact_rationals=True);out['result_signature']=signature(out)
    return out
