"""Conditional, per-case nominal fatigue inventory for adopted TOP stabilizers.

The caller must regenerate a genuine NBR 8400 Case-I action from its original
physical ledger, without Mx/omega, with stationary/permanent G removed. This
adapter verifies prepared mechanics and geometry, NOT the action family. Text
describing a source is never authentication. No stage, station or member is
approved here, even if every supplied conditional inequality is satisfied.

Every box bounds each fixed point of its stated receiver region over full
travel. The boxes are not histories or physically concurrent 3-D tensors.
Attachment toes are recovered from geometric interfaces, never mass centroids.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from math import sqrt

from ..mechanics import PreparedCase
from underslung_runway_candidate.fatigue.nbr_member import (
    ACTION_BASIS, COMPONENTS, NBRMemberFatigueInputs, NBRNominalPlane,
    NBRFatigueMaterial, NBRFatigueDuty, NBRFatigueDetail, NBRFatigueMethod,
    evaluate_nbr_member_plane,
)
from .detail import GEOMETRY_DATUM, assess_detail
from .fatigue import (
    CJP_FLANGE, LOWER_TERMINATION, STRAIGHT, UPPER_TERMINATION,
    NBRStiffenerCJPQuality, NBRStiffenerFatigueDetail,
    NBRStiffenerFatigueIdentity, NBRStiffenerNominalPlane, NBRStiffenerFatigueCase,
    NBRStiffenerTerminationQuality, evaluate_stiffener_nominal_plane,
)
from .nominal_field import produce_nominal_regions


PRESCRIBED_DETAIL_SOURCE = (
    'Adopted AISE/Fisher intermediate stabilizer: '
    'adopted_intermediate_detail_20261017/CONTRACT.md sections 1-6 '
    '(sha256 b08a4b522fa3f4fed76c26baa473dd4f1ebe05e0205b1a1008c3855f0962d9a7); '
    'directional receiver/end/CJP requirements: '
    'stiffened_nominal_fatigue_qualification_20261017/CONTRACT.md section 10 '
    '(sha256 bb36e91b85ede288fd1ab44c27a9f33aa9aa040a2a7b6bbe375b63379176aeb8)'
)


def _text(value, name):
    if type(value) is not str or not value.strip():
        raise ValueError(name + ' requires an explicit source record')
    return value


def _without_fixed_g(case):
    """Do not turn fixed selfweight into a repeated variable stress range."""
    if type(case) is not PreparedCase:
        raise ValueError('An internally prepared mechanical case is required')
    factors = case.factors
    if factors.dead_support != 0. or factors.extra_dead not in (None, 0.):
        raise ValueError('Variable fatigue case requires dead_support=0 and extra_dead=None/0; fixed G must be removed upstream')
    for load in (case.udl, case.top_udl, case.bottom_udl):
        if any(value != 0. for value in asdict(load).values()):
            raise ValueError('Nonzero permanent UDL cannot enter a variable fatigue range')
    for rows in (case.major_fixed, case.top_fixed, case.bottom_fixed):
        for load in rows:
            if any(getattr(load, field) != 0. for field in (
                    'vertical_kn', 'horizontal_kn', 'longitudinal_kn',
                    'major_moment_knm', 'minor_moment_knm')):
                raise ValueError('Nonzero fixed G/action cannot enter a variable fatigue range')


def _nominal(identity, wall, tensor, *, action_source, factors_source,
             physical, region_source):
    web = wall == 'web'
    return NBRNominalPlane(
        region_id=identity['region_id'], point_id=identity['point_id'], face=identity['face'],
        plane='xz' if web else 'xy', tensor_intervals_mpa=dict(tensor),
        action_basis=ACTION_BASIS, action_source=action_source,
        factors_source=factors_source,
        bounds_source='produce_nominal_regions: analytical full-travel sufficient signed bounds; ' + region_source,
        nominal_model_source=physical.nominal_model_source + '; ' + PRESCRIBED_DETAIL_SOURCE,
        plane_source=(
            'Adopted nominal web xz: global longitudinal normal and web shear plus '
            'local wheel pressure/shear and actual-panel sigmaT. sy/txy/tyz are '
            'zero only in this nominal wall model, not a physical 3-D tensor.'
            if web else
            'Adopted CISC longitudinal flange xy: longitudinal normal plus major '
            'and lateral nominal in-plane shear. sy/sz/txz/tyz are zero only in '
            'this nominal wall model. Local CJP transfer has separate prescribed '
            'detail coverage, not zero physical stress.'),
        same_point_scope='Each fixed material point of this identified receiver/face/region '
            'is bounded through the complete physical travel; box vertices and '
            'component extrema need not coexist. ' + region_source)


def _union_adjacent(produced, station, wall):
    rows = [row for row in produced['regions'] if station.station_id in (
        row['region']['left_station_id'], row['region']['right_station_id'])]
    if len(rows) != 2 or not all(
            row['region']['left_mm'] <= station.x_mm <= row['region']['right_mm']
            for row in rows):
        raise ValueError('Every station requires BOTH physical adjacent nominal regions')
    tensor = {key: (min(row['walls'][wall]['tensor_intervals_mpa'][key][0] for row in rows),
                    max(row['walls'][wall]['tensor_intervals_mpa'][key][1] for row in rows))
              for key in COMPONENTS}
    return tensor, tuple(row['region']['region_id'] for row in rows)


def _qualities(station, source):
    """Map actual booleans, never upgrade a missing requirement to QE/CJP."""
    w, c, p = station.web_fillet, station.cjp, station.pair
    term = None
    if w.qe_end_zone_length_mm is not None:
        term = NBRStiffenerTerminationQuality(
            p.thickness_mm, (w.qe_end_zone_length_mm, w.qe_end_zone_length_mm),
            'QE' if w.qe_both_ends_specified else 'not_specified',
            'ground_without_notches' if w.ends_ground_notch_free_specified else 'not_specified',
            'separated_from_cjp_by_unwelded_cutout', source,
            end_zone_toe_finish=('without_undercuts_ground_where_needed'
                if w.qe_end_zones_undercut_free_specified else 'not_specified'),
            # A baseline requirement of the explicitly adopted contract, not
            # a fabricated geometry measurement or completed inspection.
            effective_weld_geometry='required_throat_and_length_preserved_after_finishing')
    cjp = NBRStiffenerCJPQuality(
        preparation='double_bevel_K' if c.joint_type == 'double_bevel_T_CJP' else 'not_specified',
        penetration=('complete_joint_penetration' if c.full_root_fusion_specified
            and c.groove_full_refill_specified else 'not_specified'),
        root_treatment=('root_removed_before_back_weld'
            if c.root_removed_before_backweld_specified
            and c.root_method == 'backgouged_and_welded' else 'not_specified'),
        toe_finish='ground_without_undercuts' if c.edges_undercut_free_specified else 'not_specified',
        lamination_check=('specified_absence_of_lamellar_defects_in_tension'
            if c.tension_region_lamination_free_specified else 'not_specified'),
        minimum_reinforcement_mm=c.reinforcement_leg_mm-c.reinforcement_leg_tolerance_mm,
        permanent_backing=c.permanent_backing,
        tensile_end_treatment=('run_on_off_removed_and_ground_if_tensile'
            if c.run_on_off_tabs_specified and c.tabs_removed_and_ends_ground_flush_specified
            and c.end_dams_prohibited else 'not_specified'),
        inspection=('UT_or_RT_fatigue_acceptance'
            if c.inspection_method in ('UT', 'RT') and c.inspection_acceptance else 'not_specified'),
        procedure_source=(c.procedure_id + '; ' + c.compatibility_basis + '; ' + source
            if c.procedure_id and c.compatibility_basis
            and c.procedure_status in ('qualified', 'prequalified') else 'not_specified'),
        prescriptive_local_connection_source=source,
        additional_cyclic_transfer='absent_in_exclusively_prescriptive_stabilizer')
    return term, cjp


def _geometry(beam, station):
    """Actual interface coordinates in the published geometric datum."""
    p, w, c = station.pair, station.web_fillet, station.cjp
    ztop = beam.top_inner_z_mm
    start = sqrt(p.cope_radius_mm**2-c.root_gap_mm**2)
    return dict(web_x_offset_mm=p.thickness_mm/2+w.leg_mm,
        web_y_mm=beam.web_thickness_mm/2,
        lower_z_mm=p.bottom_z_mm+w.lower_setback_mm,
        upper_z_mm=ztop-p.cope_radius_mm,
        cjp_x_offset_mm=p.thickness_mm/2+c.reinforcement_leg_mm,
        cjp_inner_y_mm=beam.web_thickness_mm/2+start,
        cjp_outer_y_mm=beam.web_thickness_mm/2+p.outstand_mm,
        cjp_z_mm=ztop)


def _exclusions(layout):
    """W0 ordinary walls exclude attachments, not merely their centroids."""
    output = {'top': [], 'bottom': [], 'web': []}
    for station in layout.stations:
        geo = _geometry(layout.beam, station)
        for side in (-1, 1):
            for wall in ('web', 'top'):
                if wall == 'web':
                    width = geo['web_x_offset_mm']
                    y = side*geo['web_y_mm']
                    yz = ((y, y), (geo['lower_z_mm'], geo['upper_z_mm']))
                else:
                    width = geo['cjp_x_offset_mm']
                    ys = sorted((side*geo['cjp_inner_y_mm'], side*geo['cjp_outer_y_mm']))
                    yz = (tuple(ys), (geo['cjp_z_mm'], geo['cjp_z_mm']))
                output[wall].append(dict(station_id=station.station_id,
                    plate_side='negative_y' if side < 0 else 'positive_y',
                    region_bounds_mm=((station.x_mm-width, station.x_mm+width), *yz),
                    scope='Actual nominal attachment footprint including receiver toe boundaries; no W0 attachment claim'))
    return output


def _gate_detail(row, pending):
    """Retain computed exceedances even when another requirement is pending."""
    row['conditional_numeric_bound_satisfied'] = row['sufficient_planar_bound_satisfied']
    if pending:
        row['pending'].extend(pending)
        row['sufficient_planar_bound_satisfied'] = False
        row['qualified_nominal_detail_modes'] = False
        if 'classification_applicable' in row:
            row['consumer_classification_conditional_on_adopted_detail'] = row['classification_applicable']
            row['classification_applicable'] = False
        if 'local_connection_modes' in row:
            row['local_connection_modes']['status'] = 'APPLICABILITY_PENDING'
            row['local_connection_modes']['pending'] = list(pending)
        if row['input_valid'] and not row.get('criterion_exceedances'):
            row['status'] = 'APPLICABILITY_PENDING'
    return row


@dataclass(frozen=True)
class NBRIntermediateOrdinaryFatigueCase:
    """One generated ordinary regional wall, kept separate from attachments."""
    plane: NBRNominalPlane
    material: NBRFatigueMaterial
    duty: NBRFatigueDuty
    detail: NBRFatigueDetail
    method: NBRFatigueMethod


def produce_intermediate_fatigue_planes(project, prepared_case, action_source, factors_source):
    """Generate typed receiver cases from original physical mechanics, not stresses.

    No fatigue consumer is invoked. The complete family compositor may union
    tensor_intervals_mpa ONLY for matching material/geometry/region/point/face,
    preserving every other typed field, then call the audited plane consumers.
    attachment_pending must still gate each associated result after evaluation;
    the required adopted geometry/fabrication conditions are not approval flags.
    Source strings never authenticate an action family. All fixed G is rejected.
    """
    payload = dict(ordinary_cases=[], attachment_cases=[], ordinary_coverage=[],
        attachment_coverage=[], attachment_pending=[], station_detail_requirements=[])
    _text(action_source, 'action_source')
    _text(factors_source, 'factors_source')
    _without_fixed_g(prepared_case)
    produced = produce_nominal_regions(project, prepared_case)
    if prepared_case.basis.premise_status not in ('adopted', 'confirmed'):
        raise ValueError('Reference-only mechanics cannot become an adopted nominal fatigue model')
    physical = project.nbr_fatigue_physical()
    if type(physical) is not NBRMemberFatigueInputs:
        raise ValueError('Explicit physical NBR material, component group and method are required')
    section = prepared_case.project.section
    for label, material, thickness in (
            ('web', physical.web_material, section.tw_mm),
            ('flange', physical.flange_material, section.tf_mm)):
        if (material.thickness_mm != thickness
                or material.fy_mpa != prepared_case.project.material.fy_mpa
                or material.fu_mpa != prepared_case.project.material.fu_mpa):
            raise ValueError(label + ' fatigue material must match the actual receiving beam and thickness')
    layout = project.intermediates.layout
    stations = layout.stations
    if not stations or len(produced['regions']) != len(stations)+1:
        raise ValueError('Nonempty complete physical station and nominal-region inventory required')
    expected_regions = {'R'+str(i+1) for i in range(len(stations)+1)}
    if {row['region']['region_id'] for row in produced['regions']} != expected_regions:
        raise ValueError('Missing or duplicate ordinary regional identities')
    exclusions = _exclusions(layout)
    digest = produced['geometry_inputs_hash']
    if digest != project.intermediates.physical_geometry_hash():
        raise ValueError('Nominal field geometry and physical receiver identity disagree')
    source = project.intermediates.detail_source + '; ' + PRESCRIBED_DETAIL_SOURCE
    common = dict(action_source=action_source, factors_source=factors_source, physical=physical)

    for region in produced['regions']:
        rid = region['region']['region_id']
        for wall in ('top', 'bottom', 'web'):
            identity = dict(region_id=rid+':ordinary:'+wall,
                point_id=rid+':ordinary:'+wall+':each_fixed_material_point',
                face='both_nominal_wall_faces')
            exclusions_here = tuple(e for e in exclusions[wall]
                if e['region_bounds_mm'][0][0] <= region['region']['right_mm']
                and e['region_bounds_mm'][0][1] >= region['region']['left_mm'])
            nominal = _nominal(identity, wall, region['walls'][wall]['tensor_intervals_mpa'],
                region_source=rid+'; ordinary wall with actual attachment receiver footprints/loci excluded', **common)
            case = NBRIntermediateOrdinaryFatigueCase(nominal,
                physical.web_material if wall == 'web' else physical.flange_material,
                physical.duty, physical.detail, physical.method)
            receipt = dict(identity=identity, wall=wall, coverage_kind='ordinary_region_minus_attachment_receivers',
                longitudinal_region_mm=(region['region']['left_mm'], region['region']['right_mm']),
                excluded_attachment_receiver_regions=exclusions_here,
                geometry_weld_hash=digest, attachment_category_W0_claimed=False,
                full_travel_m=produced['full_physical_travel_m'])
            payload['ordinary_cases'].append(case)
            payload['ordinary_coverage'].append(receipt)

    for station in stations:
        assessment = assess_detail(layout.beam, station)
        payload['station_detail_requirements'].append(dict(station_id=station.station_id,
            assessment=asdict(assessment)))
        term, cjp = _qualities(station, source)
        geo = _geometry(layout.beam, station)
        for side in (-1, 1):
            plate_side = 'negative_y' if side < 0 else 'positive_y'
            for xside in (-1, 1):
                toe = 'negative_x' if xside < 0 else 'positive_x'
                for location in (STRAIGHT, LOWER_TERMINATION, UPPER_TERMINATION, CJP_FLANGE):
                    web = location != CJP_FLANGE
                    wall = 'web' if web else 'top'
                    tensor, adjacent_ids = _union_adjacent(produced, station, wall)
                    ident = NBRStiffenerFatigueIdentity(station.station_id, plate_side,
                        station.station_id+':'+plate_side+':'+('web_fillet:' if web else 'cjp:')+toe,
                        layout.beam.material.material_id,
                        station.station_id+':'+plate_side+':'+toe+':'+location,
                        station.station_id+':'+plate_side+':'+toe+':'+location+':receiver',
                        plate_side if web else 'top_flange_lower_face', digest)
                    nominal = _nominal(asdict(ident), wall, tensor,
                        region_source='Conservative union of BOTH adjacent regional boxes '+','.join(adjacent_ids)+
                            '; including full sigmaT wherever either adjacent region is a real physical panel', **common)
                    x = station.x_mm+xside*geo['web_x_offset_mm' if web else 'cjp_x_offset_mm']
                    y = side*geo['web_y_mm']
                    coords, bounds = None, None
                    if location in (LOWER_TERMINATION, UPPER_TERMINATION):
                        coords = (x, y, geo['lower_z_mm' if location == LOWER_TERMINATION else 'upper_z_mm'])
                    elif web:
                        bounds = ((x, x), (y, y), (geo['lower_z_mm'], geo['upper_z_mm']))
                    else:
                        yrange = tuple(sorted((side*geo['cjp_inner_y_mm'], side*geo['cjp_outer_y_mm'])))
                        bounds = ((x, x), yrange, (geo['cjp_z_mm'], geo['cjp_z_mm']))
                    coverage = ('Actual nominal web toe; straight interior excludes both separately classified endpoints'
                        if location == STRAIGHT else 'Actual nominal CJP flange-receiver toe line INCLUDING its two ends'
                        if location == CJP_FLANGE else 'Actual nominal web-fillet endpoint on the receiving web face')
                    plane = NBRStiffenerNominalPlane(ident, nominal,
                        'fixed_point' if coords is not None else 'verified_region_bound',
                        coverage+'; uniform complete-travel regional boxes enclose the whole locus; never mass CGs',
                        'same_point_global_plus_local' if web else 'cisc_longitudinal_flange',
                        coordinates_mm=coords, region_bounds_mm=bounds)
                    material = physical.web_material if web else physical.flange_material
                    detail = NBRStiffenerFatigueDetail(ident, location, material,
                        'continuous_vertical_fillet_to_web' if web else 'K_prepared_CJP_stiffener_to_top_flange',
                        'web_base_material' if web else 'top_flange_base_material',
                        'z' if web else 'y', 'QC' if web else 'QE' if station.cjp.qe_weld_specified else 'not_specified',
                        source, source+'; design requirements only, never as-built execution',
                        source+'; tension-region lamination requirement specified'
                            if (station.web_fillet.tension_region_lamination_free_specified if web
                                else station.cjp.tension_region_lamination_free_specified) else 'not_specified',
                        termination_quality=term if location in (LOWER_TERMINATION, UPPER_TERMINATION) else None,
                        cjp_quality=cjp if not web else None)
                    case = NBRStiffenerFatigueCase(plane, material,
                        physical.duty, detail, physical.method)
                    receipt = dict(identity=asdict(ident), location=location, wall=wall,
                        coordinates_mm=coords, region_bounds_mm=bounds,
                        coordinate_datum=GEOMETRY_DATUM, coverage=coverage,
                        adjacent_regional_boxes=adjacent_ids,
                        adjoining_boxes_unioned=True, favourable_side_selected=False,
                        full_travel_m=produced['full_physical_travel_m'],
                        geometry_configuration='supplied_nominal_design_geometry; '
                            'specified tolerances checked in detail assessment; not as-built coordinates',
                        mass_centroid_used_as_toe=False, entire_plate_claimed_as_receiver=False)
                    payload['attachment_cases'].append(case)
                    payload['attachment_coverage'].append(receipt)
                    payload['attachment_pending'].append(tuple(assessment.pending))


    expected_ordinary, expected_attachments = 3*(len(stations)+1), 16*len(stations)
    receipts = payload['ordinary_coverage']+payload['attachment_coverage']
    if (not receipts or len(payload['ordinary_cases']) != expected_ordinary
            or len(payload['attachment_cases']) != expected_attachments
            or len({row['identity']['point_id'] for row in receipts}) != len(receipts)):
        raise ValueError('Incomplete or duplicate physical fatigue coverage; empty inventories never qualify')
    for key in ('ordinary_cases', 'attachment_cases', 'ordinary_coverage',
                'attachment_coverage', 'attachment_pending', 'station_detail_requirements'):
        payload[key] = tuple(payload[key])
    payload.update(physical=physical, physical_inputs=asdict(physical),
        case_factors=asdict(prepared_case.factors), nominal_field=produced,
        action_source=action_source, factors_source=factors_source,
        expected_ordinary_count=expected_ordinary, expected_attachment_count=expected_attachments,
        geometry_weld_hash=digest, fixed_G_removed=True, stationary_physical_bodies_retained=True,
        prescribed_detail_source=source, action_family_authenticated=False,
        conditional_on_caller_authenticated_case_i=True,
        whole_station_qualified=False, whole_member_qualified=False,
        local_connection_modes=dict(status='conditionally_covered_by_prescriptive_detail',
            source=source, function='exclusive_intermediate_stabilization',
            conditional_on='All adopted geometry/fabrication, sign and function requirements outside this per-case consumer',
            stress_is_zero_claimed=False, numerically_verified=False))
    return payload


def evaluate_intermediate_fatigue_case(project, prepared_case, action_source, factors_source):
    """Return ordinary and directional receiver bounds, conditional on Case I.

    Inputs are original typed physical project plus internally prepared actions,
    not imported efforts. Sources record the caller's basis but do not prove it.
    The action-family compositor must authenticate/regenerate all required cases
    and union signed bounds by the exact same identity before final evaluation.
    Satisfying each case separately is not a proof of the unioned D.5 box.
    """
    result = dict(kind='TOP_intermediate_conditional_per_case_NBR8400_fatigue',
        status='APPLICABILITY_PENDING', input_valid=True, errors=[], pending=[],
        ordinary_results=[], attachment_results=[], point_results=[],
        coverage_receipts=[], station_detail_requirements=[],
        all_supplied_bounds_satisfied=False, conditional_bounds_satisfied=False,
        any_sufficient_bound_exceeded=False, criterion_exceedances=[],
        qualified_nominal_detail_modes=False, whole_station_qualified=False,
        whole_member_qualified=False, whole_design_complete=False,
        stage_qualified=False, actual_failure_proven=False,
        action_family_authenticated=False, all_action_cases_covered=False,
        conditional_on_caller_authenticated_case_i=True,
        physical_3d_tensor_complete=False, physical_tensor_zero_claimed=False,
        concurrent_tensor_claimed=False, uses_fabricated_history=False,
        temporal_histories_created=0, sampled_maxima_used=False,
        as_built_execution_verified=False, weld_throat_fatigue_verified=False,
        physical_unlimited_life_claim=False, calculated_cycles_to_failure=False,
        static_075_factor_applied_to_fatigue=False, fixed_G_removed=False,
        coordinate_datum=GEOMETRY_DATUM,
        prescribed_detail_source=PRESCRIBED_DETAIL_SOURCE,
        scope='Isolated conditional per-case nominal inequalities only. Complete Case-I action-family '
            'authentication, same-identity across-case union, sign/prescriptive applicability, '
            'station/static checks and whole-member acceptance remain separate.')
    try:
        produced = produce_intermediate_fatigue_planes(project, prepared_case, action_source, factors_source)
        for key in ('physical_inputs', 'case_factors', 'nominal_field', 'action_source',
                    'factors_source', 'expected_ordinary_count', 'expected_attachment_count',
                    'geometry_weld_hash', 'fixed_G_removed', 'stationary_physical_bodies_retained',
                    'local_connection_modes', 'station_detail_requirements'):
            result[key] = produced[key]
        for case, coverage in zip(produced['ordinary_cases'], produced['ordinary_coverage']):
            row = evaluate_nbr_member_plane(case.plane, material=case.material,
                duty=case.duty, detail=case.detail, method=case.method)
            row['adapter_coverage'] = coverage
            result['ordinary_results'].append(row)
            result['coverage_receipts'].append(coverage)
        for case, coverage, pending in zip(produced['attachment_cases'],
                produced['attachment_coverage'], produced['attachment_pending']):
            row = evaluate_stiffener_nominal_plane(case.plane, material=case.material,
                duty=case.duty, detail=case.detail, method=case.method)
            _gate_detail(row, list(pending))
            row['adapter_coverage'] = coverage
            result['attachment_results'].append(row)
            result['coverage_receipts'].append(coverage)
        rows = result['ordinary_results']+result['attachment_results']
        if (not rows or len(result['ordinary_results']) != produced['expected_ordinary_count']
                or len(result['attachment_results']) != produced['expected_attachment_count']):
            raise ValueError('Complete nonempty generated fatigue inventory required')
        result['point_results'] = rows
        result['errors'] = [error for row in rows for error in row['errors']]
        result['pending'] = list(dict.fromkeys(pending for row in rows for pending in row['pending']))
        result['criterion_exceedances'] = [dict(
            point_id=row['adapter_coverage']['identity']['point_id'], criterion=criterion)
            for row in rows for criterion in row.get('criterion_exceedances', ())]
        passed = bool(rows) and all(row['sufficient_planar_bound_satisfied'] for row in rows)
        valid = all(row['input_valid'] for row in rows)
        exceeded = bool(result['criterion_exceedances'])
        result.update(input_valid=valid, fixed_G_removed=True,
            conditional_bounds_satisfied=passed, all_supplied_bounds_satisfied=passed,
            any_sufficient_bound_exceeded=exceeded,
            status='INVALID_INPUT' if not valid else 'INCONCLUSIVE_SUFFICIENT_FATIGUE_BOUND' if exceeded
                else 'APPLICABILITY_PENDING' if result['pending']
                else 'CONDITIONAL_PER_CASE_NOMINAL_FATIGUE_BOUNDS_SATISFIED',
            evaluated_plane_count=len(rows))
        return result
    except (ValueError, TypeError, ArithmeticError, KeyError, AttributeError) as exc:
        result.update(status='INVALID_INPUT', input_valid=False,
            errors=[type(exc).__name__+': '+str(exc)],
            conditional_bounds_satisfied=False, all_supplied_bounds_satisfied=False)
        return result
