"""Regenerate and pool the complete normal NBR family for the adopted detail.

No external effort/result input, no invented cycle, and no source-label based
qualification. Static Case I and fatigue Case I without Mx are generated from
the same original physical ledger with their own explicitly separated factors.
"""
from dataclasses import asdict,replace
from hashlib import sha256
from pathlib import Path
from lro_beams.autonomous_actions import factors_10084
from lro_beams.autonomous_response import CaseFactors
from underslung_runway_candidate.autonomous_workflow.model import signature
from underslung_runway_candidate.fatigue.nbr_member import COMPONENTS,evaluate_nbr_member_plane
from ..nbr_fatigue import generate_top_nbr_actions,prepare_top_nbr_action_case
from ..mechanics import prepare_case
from ..checks import _prepared_key
from .fatigue import evaluate_stiffener_nominal_plane
from .fatigue_adapter import produce_intermediate_fatigue_planes,_gate_detail


def _plane(case,attachment):
    return case.plane.nominal_plane if attachment else case.plane


def _nonstress_identity(case,attachment):
    d=asdict(case)
    p=d['plane']['nominal_plane'] if attachment else d['plane']
    p.pop('tensor_intervals_mpa')
    return signature(d)


def _union_case(old,new,attachment):
    if type(old) is not type(new) or _nonstress_identity(old,attachment)!=_nonstress_identity(new,attachment):
        raise ValueError('Family pooling cannot change fixed point/face/geometry/material/detail or source identity')
    a,b=_plane(old,attachment),_plane(new,attachment)
    if set(a.tensor_intervals_mpa)!=set(COMPONENTS) or set(b.tensor_intervals_mpa)!=set(COMPONENTS):
        raise ValueError('All six tensor components required before family pooling')
    tensor={k:(min(a.tensor_intervals_mpa[k][0],b.tensor_intervals_mpa[k][0]),
               max(a.tensor_intervals_mpa[k][1],b.tensor_intervals_mpa[k][1])) for k in COMPONENTS}
    p=replace(a,tensor_intervals_mpa=tensor)
    return replace(old,plane=replace(old.plane,nominal_plane=p) if attachment else p)


def _pool_produced(pooled,produced):
    """Strict aligned physical inventory; no all([]), dropped point or best-side selection."""
    pending=produced.get('attachment_pending')
    attachments=produced.get('attachment_cases')
    if (type(pending) is not tuple or type(attachments) is not tuple or len(pending)!=len(attachments)
        or any(type(row) is not tuple or any(type(v) is not str for v in row) for row in pending)):
        raise ValueError('Every generated attachment must retain its aligned requirement tuple')
    if not produced.get('station_detail_requirements'):
        raise ValueError('Physical station detail inventory cannot be empty')
    for attachment,key,coverage_key in ((False,'ordinary_cases','ordinary_coverage'),
                                      (True,'attachment_cases','attachment_coverage')):
        rows,coverage=produced[key],produced[coverage_key]
        if not rows or len(rows)!=len(coverage):raise ValueError('Incomplete generated receiver inventory')
        expected=3*(len(produced['station_detail_requirements'])+1) if not attachment else 16*len(produced['station_detail_requirements'])
        if len(rows)!=expected:raise ValueError('Generated family receiver coverage count is incomplete')
        identities=tuple(c['identity']['point_id'] for c in coverage)
        if len(set(identities))!=len(identities):raise ValueError('Duplicate receiver identity')
        if pooled is None:continue
        if tuple(c['identity']['point_id'] for c in pooled[coverage_key])!=identities or pooled[coverage_key]!=coverage:
            raise ValueError('Receiver inventory or physical coverage changed between action cases')
        pooled[key]=tuple(_union_case(a,b,attachment) for a,b in zip(pooled[key],rows))
    if pooled is None:
        return {key:produced[key] for key in ('ordinary_cases','attachment_cases','ordinary_coverage',
            'attachment_coverage','attachment_pending','station_detail_requirements','geometry_weld_hash')}
    if (pooled['attachment_pending']!=produced['attachment_pending'] or
        pooled['geometry_weld_hash']!=produced['geometry_weld_hash'] or
        pooled['station_detail_requirements']!=produced['station_detail_requirements']):
        raise ValueError('Geometry/detail requirements changed during action pooling')
    return pooled


def _evaluate_pooled(pooled):
    if pooled is None:raise ValueError('No authenticated action case produced any receiver plane')
    _pool_produced(None,pooled) # Revalidate coverage before any zip or approval.
    rows=[]
    for case,coverage in zip(pooled['ordinary_cases'],pooled['ordinary_coverage']):
        row=evaluate_nbr_member_plane(case.plane,material=case.material,duty=case.duty,detail=case.detail,method=case.method)
        row['adapter_coverage']=coverage;rows.append(row)
    for case,coverage,pending in zip(pooled['attachment_cases'],pooled['attachment_coverage'],pooled['attachment_pending']):
        row=evaluate_stiffener_nominal_plane(case.plane,material=case.material,duty=case.duty,detail=case.detail,method=case.method)
        _gate_detail(row,list(pending));row['adapter_coverage']=coverage;rows.append(row)
    expected=len(pooled['ordinary_cases'])+len(pooled['attachment_cases'])
    if len(rows)!=expected:raise ValueError('Every pooled receiver must be evaluated exactly once')
    errors=sorted({str(v) for r in rows for v in r.get('errors',())})
    pending=sorted({str(v) for r in rows for v in r.get('pending',())})
    valid=bool(rows) and all(r.get('input_valid') is True for r in rows)
    sufficient=valid and not pending and all(r.get('sufficient_planar_bound_satisfied') is True for r in rows)
    return dict(status='PENDING' if errors or pending or not valid else
        'SUFFICIENT_NOMINAL_FATIGUE_BOUNDS_SATISFIED' if sufficient else 'INCONCLUSIVE_SUFFICIENT_FATIGUE_BOUND',
        point_results=rows,pending=pending,errors=errors,checks=rows,
        evaluated_plane_count=len(rows),sufficient_nominal_fatigue_bounds_satisfied=sufficient,
        action_family_authenticated=False,whole_member_qualified=False,station_qualified=False,
        fixed_G_removed=True,temporal_histories_created=False,actual_failure_proven=False,
        pooling='All regenerated Case-I action boxes unioned only at the same fixed material point/face/detail; kappa=-1, no fictitious cycle')


def prepare_intermediate_normal_case(basis,case,project):
    """Fresh admissible Case I, not a relabelled ELU/ASD tensor.

    The authenticated physical wheel vectors already carry psi/H dynamics and
    normal rolling once. Mx then scales that entire vector and every fixed G.
    """
    base=prepare_top_nbr_action_case(basis,case,permanent_factor=1.,extra_dead_factor=1.)
    f=factors_10084('I',psi=project.actions.dynamics()['psi'],equipment_group=project.actions.equipment_group)
    mx=f.dead_support
    if any(v!=mx for v in (f.dead_equipment,f.transverse,f.longitudinal,f.extra_dead)):
        raise ValueError('Case-I uniform Mx source contract changed')
    converted=CaseFactors(f.code,mx,mx,0.,mx,mx,
        f.source+'; original physical wheel vectors already include psi and full horizontal dynamics once; uniform Mx applied after source regeneration',extra_dead=mx)
    return prepare_case(base.basis,converted),dict(source_factors=asdict(f),mechanical_factors=asdict(converted),
        base_action_signature=signature(case),uniform_Mx=mx,psi_applied_twice=False,
        factored_ELU_or_CMAA_tensor_used=False,stationary_G_scaled_same_origin=True)


def evaluate_intermediate_nbr_family(project,*,progress=None):
    """Complete NBR regional static/sign and nominal-life families, freshly generated."""
    from .static_adapter import evaluate_intermediate_static_case,evaluate_intermediate_sign_case
    project.validate()
    if project.intermediates is None or project.nbr_fatigue is None:
        raise ValueError('Adopted physical intermediate inventory and explicit NBR fatigue method required')
    before=signature(project.to_dict());basis=project.basis();a=project.actions
    generated=generate_top_nbr_actions(basis,project.bridge,psi=a.dynamics()['psi'],
        horizontal_dynamic_factor=a.horizontal_dynamic_factor,horizontal_dynamic_source=a.horizontal_dynamic_source,
        rolling_guidance=project.nbr_rolling_guidance)
    cases=generated['cases']
    if not cases or generated['case_count']!=len(cases) or len({c['nbr_vertex_signature'] for c in cases})!=len(cases):
        raise ValueError('Complete distinct generated normal action inventory required')
    if any(not c['contact_valid'] for c in cases):
        raise ValueError('Normal physical contact-domain sufficient guard not established for every endpoint')
    pooled=None;receipts=[];statics=[];signs=[]
    factor_source=generated['source']+'; fixed beam/rail/stationary attachment G removed from fatigue; moving equipment retained; Case I without Mx/omega'
    for i,case in enumerate(cases,1):
        variable=prepare_top_nbr_action_case(basis,case,permanent_factor=0.,extra_dead_factor=0.)
        produced=produce_intermediate_fatigue_planes(project,variable,generated['source'],factor_source)
        pooled=_pool_produced(pooled,produced)
        normal,ledger=prepare_intermediate_normal_case(basis,case,project)
        static=evaluate_intermediate_static_case(project,normal,action_basis='nbr10084_8400_admissible',
            action_source=generated['source'],factors_source=ledger['source_factors']['source'])
        sign=evaluate_intermediate_sign_case(project,normal)
        statics.append(static);signs.append(sign)
        receipts.append(dict(case_id=case['name'],action_signature=signature(case),sign_result_signature=signature(sign),
            physical_record=case['source_record'],horizontal_pair=case['horizontal_pair'],
            rolling_signs=case['rolling_signs'],relaxed_box_not_physical_history=case['relaxed_reaction_box_vertex'],
            variable_prepared_signature=_prepared_key(variable),normal_prepared_signature=_prepared_key(normal),
            normal_factor_ledger=ledger,fatigue_plane_inventory_signature=signature(tuple(asdict(v) for v in produced['ordinary_cases'])+tuple(asdict(v) for v in produced['attachment_cases'])),
            full_physical_travel_m=variable.translation_range_m))
        if progress:progress(i,len(cases),'Família NBR: regiões reais, sinal, σT e fadiga nos detalhes')
    if before!=signature(project.to_dict()):raise ValueError('Physical inputs changed during family evaluation')
    fatigue=_evaluate_pooled(pooled)
    fatigue['action_family_authenticated']=True
    return dict(kind='TOP_INTERMEDIATE_REGENERATED_NBR_FAMILY',action_family_authenticated=True,
        project_signature=before,geometry_inputs_hash=project.intermediates.physical_geometry_hash(),
        action_domain=generated['action_domain'],action_domain_signature=signature(generated),
        source=generated['source'],source_factors=generated['factors'],horizontal_pairs=generated['horizontal_pairs'],
        rolling_guidance=generated['rolling_guidance'],rolling_receipts=generated['rolling_receipts'],
        case_count=len(cases),case_receipts=receipts,fatigue=fatigue,
        static_case_results=statics,sign_case_results=signs,station_qualified=False,
        stationary_G_applied_to_static_and_removed_from_fatigue=True,
        source_file_sha256=sha256(Path(__file__).read_bytes()).hexdigest())
