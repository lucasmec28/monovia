"""Nominal TOP regional stress boxes with the adopted intermediate detail.

No physical-history claim, shell model, plate-force assignment or station
approval. The caller must regenerate action families; this layer authenticates
prepared mechanics and geometry but does not label arbitrary factors Case I.
"""
from dataclasses import asdict
from math import fsum,isfinite
from lro_beams.autonomous_local import rectangle_torsion_constant
from ..mechanics import TopIntermediateBasis,prepare_case
from ..bounds import prepared_absolute_bounds
from ..fatigue import prepared_local_compression_bounds
from .regions import RegionInventory,StationLine
from .transverse_stress import transverse_web_stress,flanged_wheel_eccentricity_mm


def _context(project,c):
    project.validate()
    if project.intermediates is None or type(c.basis) is not TopIntermediateBasis:
        raise ValueError('Explicit physical adopted intermediate inputs and mechanical basis required')
    expected=project.basis()
    for key in ('physical_stiffeners','nominal_basis','geometry_inputs_hash','stationary_ledger_sha256','stationary_bodies'):
        if getattr(c.basis,key)!=getattr(expected,key):
            raise ValueError('Prepared mechanics and physical geometry/mass identity disagree')
    actual=c.basis.validated_project().to_dict();wanted=expected.validated_project().to_dict()
    actual.pop('wheels');wanted.pop('wheels')
    if actual!=wanted:
        raise ValueError('Prepared base section, material, rail, support or permanent origins changed')
    if c!=prepare_case(c.basis,c.factors,c.transverse_sign,c.longitudinal_sign):
        raise ValueError('Prepared loads changed; regenerate physical actions')
    c.validate_stationary_identity()
    return RegionInventory(c.project.span_m*1000,tuple(StationLine(s.station_id,s.x_mm) for s in sorted(project.intermediates.layout.stations,key=lambda s:s.x_mm)))


def produce_nominal_regions(project,c):
    """Full-travel uniform nominal boxes for every ordinary regional wall.

    For each real panel, linear superposition sums EVERY wheel's magnitude.
    Applying this maximum throughout that nominal panel is a sufficient model
    enclosure, not a decay field. Exterior regions retain the adopted ordinary
    CISC alternative without a fabricated transverse-stiffener boundary.
    Local Fz eccentricity is prescribed independently of the global torque.
    """
    inventory=_context(project,c);s=c.project.section;r=c.project.rail
    if r.wheel_guidance!='flanged':
        raise ValueError('Initial intermediate route requires the existing flanged-wheel action topology')
    if r.local_attachment!='non_rigid' or r.attachment!='non_composite' or r.offset_from_web_mm!=0:
        raise ValueError('Centered continuous non-rigid non-composite rail required')
    bounds=prepared_absolute_bounds(c);pressure=prepared_local_compression_bounds(c)
    prescribed_ey=flanged_wheel_eccentricity_mm(wheel_flange_clearance_mm=r.wheel_rail_clearance_mm)
    ey=max(prescribed_ey,abs(r.lateral_eccentricity_mm))
    it=rectangle_torsion_constant(s.bf_mm,s.tf_mm)
    major_shear=bounds['major']['shear_abs_kn']*1000*s.d_mm*s.bf_mm/(4*c.properties.Ix_mm4)
    flanges={wall:major_shear+1.5*bounds[wall]['shear_abs_kn']*1000/(s.bf_mm*s.tf_mm) for wall in ('top','bottom')}
    web_shear=bounds['txz_abs_mpa']+pressure['wheel_local_shear_mpa']
    sx=bounds['sx_abs_mpa'];compression=pressure['transverse_compression_mpa']
    if any(not isfinite(v) or v<0 for v in (it,ey,sx,compression,web_shear,*flanges.values())):
        raise ValueError('Derived nominal field exceeds finite physical numeric domain')
    regions=[]
    for region in inventory.regions():
        scalar=[]
        if region.physical_panel_spacing_mm is not None:
            for wheel in c.source_wheels:
                scalar.append(transverse_web_stress(stiffener_spacing_mm=region.physical_panel_spacing_mm,
                    total_web_depth_mm=s.d_mm-2*s.tf_mm,web_thickness_mm=s.tw_mm,
                    upper_flange_saint_venant_mm4=it,vertical_force_N=wheel.vertical_kn*1000,eccentricity_mm=ey))
        st=fsum(v.sigmaT_magnitude_MPa for v in scalar)
        walls={}
        for wall in ('top','bottom','web'):
            web=wall=='web'
            walls[wall]=dict(plane='xz' if web else 'xy',
                tensor_intervals_mpa=dict(sx=(-sx,sx),sy=(0.,0.),sz=(-compression-st,st) if web else (0.,0.),
                    txy=(0.,0.) if web else (-flanges[wall],flanges[wall]),
                    txz=(-web_shear,web_shear) if web else (0.,0.),tyz=(0.,0.)),
                nominal_zero_basis=('Adopted nominal web xz wall' if web else 'Adopted CISC flange xy wall; transverse local connection covered only by separate detail prescription'),
                thickness_mm=s.tw_mm if web else s.tf_mm,
                welded_attachment_regions_excluded_from_plain_material_category=True)
        regions.append(dict(region=asdict(region),walls=walls,sigmaT_magnitude_sum_mpa=st,
            transverse_scalar_receipts=tuple(asdict(v) for v in scalar),
            maximum_static_compression_mpa=compression+.75*st,
            fatigue_transverse_reduction_used=False,
            local_model='NBR10084 real transverse panel plus adopted global nominal field' if scalar else 'Previously adopted ordinary CISC endpoint-region model; no transverse-panel credit',
            actual_station_qualified=False))
    return dict(regions=tuple(regions),mechanical_bounds=bounds,pressure=pressure,
        upper_flange_only_J_mm4=it,prescribed_eccentricity_mm=prescribed_ey,eccentricity_envelope_mm=ey,
        physical_stiffeners='present',geometry_inputs_hash=expected_hash(project),
        all_wheel_magnitudes_summed=True,horizontal_torque_mapped_to_sigmaT=False,
        sigmaT_faces_assigned=False,temporal_history_created=False,
        full_physical_travel_m=c.translation_range_m,
        ordinary_region_boxes_only=True,action_family_authenticated=False,station_qualified=False,
        scope='Nominal regional equations and sufficient boxes only; physical detail, sign, transfer, capacities and fatigue consumers remain separate')


def expected_hash(project):
    return project.intermediates.physical_geometry_hash()
