"""Unhooked physical-input editor for the adopted TOP intermediate stabilizer.

This module does not activate a route, modify a project, call an FE solver, or
issue strength/fatigue/as-built approval. The caller must keep a ``None`` return
with ``input_valid=False`` distinct from the explicitly selected absent mode.
Widget state is namespaced; imported records are never normalized into defaults.
"""
from __future__ import annotations

from copy import deepcopy
from dataclasses import asdict
import json

from lro_beams.catalog import section_from_profile
from .detail import (CJPTopSpec, IntermediatePlatePair,
    IntermediateStation, MaterialSpec, RolledISection, WebFilletSpec, assess_detail)
from .inputs import IntermediateInputs, StiffenerSteel, WeldConsumable

PREFIX = 'tu_input:intermediates.'
ADOPTED = 'adopted_execution_requirements'
PRESERVED = 'preserve_supplied_requirements'
REQUIREMENTS = (
    'Requisitos de execução, não resultados de inspeção: duas chapas simétricas; '
    'filetes contínuos na alma, Q.E. nos 10tp de ambas as extremidades, terminações '
    'esmerilhadas sem entalhes e zonas sem mordeduras; recorte circular esmerilhado. '
    'Ligação superior K/T com penetração total (CJP), sem backing permanente, '
    'goivagem e ressoldagem da raiz, fusão e recomposição integral do chanfro, '
    'acesso pelos dois lados, Q.E., UT/RT com aceitação para solicitação cíclica, '
    'abas de início/fim removidas e extremidades esmerilhadas, sem diques; '
    'regiões tracionadas sem falhas de laminação. Nada aqui atesta fabricação, '
    'qualificação de EPS já realizada, inspeção executada ou aprovação resistente.'
)
WEB_REQUIREMENTS = ('qe_both_ends_specified', 'ends_ground_notch_free_specified',
    'qe_end_zones_undercut_free_specified', 'tension_region_lamination_free_specified')
CJP_REQUIREMENTS = ('full_root_fusion_specified', 'groove_full_refill_specified',
    'run_on_off_tabs_specified', 'tabs_removed_and_ends_ground_flush_specified',
    'end_dams_prohibited', 'qe_weld_specified', 'edges_undercut_free_specified',
    'root_removed_before_backweld_specified', 'tension_region_lamination_free_specified')


def _token(raw):
    return json.dumps(raw, sort_keys=True, separators=(',', ':'), allow_nan=False)


def _defaults(project, section):
    """Editable design proposal, not manufacturer/as-built data or a result."""
    span = project.structure.span_m * 1000
    root = section.root_radius_mm
    beam = RolledISection(section.d_mm, section.bf_mm, section.tf_mm, section.tw_mm,
        root, 'Geometria circular física sintética adotada neste cálculo; raio '
        'conciliado com a altura livre de catálogo, não medido nem confirmado pelo fabricante.',
        MaterialSpec('intermediate_receiving_beam'))
    plate = MaterialSpec('intermediate_plate')
    web_material = MaterialSpec('intermediate_web_weld')
    cjp_material = MaterialSpec('intermediate_cjp_weld')
    pair = IntermediatePlatePair(100., 12., 80., 30., plate,
        required_root_clearance_mm=5., cope_finish='ground')
    web = WebFilletSpec(6., web_material, lower_setback_mm=5., consumable_id='E7018',
        compatibility_basis='Exigir compatibilidade do consumível com os aços da viga e das chapas.',
        procedure_id='EPS dos filetes contínuos a qualificar antes da execução',
        qe_end_zone_length_mm=120., **dict.fromkeys(WEB_REQUIREMENTS, True))
    cjp = CJPTopSpec(cjp_material, 6., root_face_mm=2., consumable_id='E7018',
        compatibility_basis='Exigir depósito compatível para recomposição integral da seção preparada.',
        procedure_id='EPS da junta K/CJP: qualificação exigida antes da execução',
        procedure_status='qualified', root_method='backgouged_and_welded',
        access_description='Exigir acesso pelos dois lados da junta após o recorte circular.',
        inspection_method='UT', inspection_acceptance='Exigir aceitação para solicitação cíclica conforme AWS D1.1.',
        **dict.fromkeys(CJP_REQUIREMENTS, True))
    stations = [asdict(IntermediateStation('I'+str(i), span*i/3, pair, web, cjp)) for i in (1, 2)]
    for station in stations:
        station['pair'].update(outstand_mm=min(100., (section.bf_mm-section.tw_mm)/2),
            bottom_z_mm=section.tf_mm+root+5*section.tw_mm-5., cope_radius_mm=max(30., root+12.))
    # Do not validate a provisional layout before the widgets can correct it.
    raw = dict(layout=dict(beam=asdict(beam), beam_start_mm=0., beam_end_mm=span,
        stations=stations, state='present'), plate_materials=(asdict(StiffenerSteel(
            plate.material_id, 345., 450., 200000., 'ASTM A572 GR50',
            'Propriedades nominais sintéticas das chapas adotadas neste cálculo; editar conforme projeto.')),),
        weld_consumables=tuple(asdict(WeldConsumable(m.material_id, 'E7018', 490.,
            'Propriedades nominais sintéticas do depósito adotadas neste cálculo; editar conforme EPS.',
            fyw_mpa=400., E_mpa=200000.)) for m in (web_material, cjp_material)),
        detail_source='Detalhe TOP intermediário adotado neste cálculo somente como estabilizador de painéis ao cortante; '
            'geometria inicial sintética editável e requisitos de execução, sem confirmação de obra.',
        additional_function='none_beyond_shear_stabilization_and_selfweight')
    if getattr(project, 'identity', None) != 'synthetic_example':
        # A real project cannot acquire a real root datum merely by opening UI.
        raw['layout']['beam']['root_radius_mm'] = None
        raw['layout']['beam']['root_radius_source'] = ''
    return raw


class _Fields:
    def __init__(self, st, automatic):
        self.st, self.automatic = st, automatic
        self.defaults = dict(st.session_state.get(PREFIX+'_defaults', {}))
        self.previous = dict(st.session_state.get(PREFIX+'_draft_widgets', {}))

    def seed(self, name, value):
        key = PREFIX+name
        if key not in self.st.session_state and name in self.previous:
            self.st.session_state[key] = self.previous[name]
        if (self.automatic and name in self.defaults and key in self.st.session_state
                and self.st.session_state[key] == self.defaults[name]):
            self.st.session_state[key] = value
        self.defaults[name] = deepcopy(value)
        return key

    def number(self, name, label, value, *, integer=False):
        key = self.seed(name, value)
        kw = {} if key in self.st.session_state else {'value': value if value is None else int(value) if integer else float(value)}
        # No widget clamp rewrites an imported invalid value. Schema validation
        # handles signs/ranges and the nullable real-root/material inputs.
        return self.st.number_input(label, key=key, step=1 if integer else .01,
            format='%d' if integer else '%.3f', **kw)

    def text(self, name, label, value):
        key = self.seed(name, value or '')
        kw = {} if key in self.st.session_state else {'value': value or ''}
        return self.st.text_input(label, key=key, **kw)

    def choice(self, name, label, value, labels):
        key = self.seed(name, value)
        options = list(labels)
        return self.st.selectbox(label, options, index=options.index(value),
            format_func=lambda v: labels[v], key=key)

    def save(self):
        self.st.session_state[PREFIX+'_defaults'] = self.defaults
        draft = dict(self.previous)
        for key in self.st.session_state:
            if key.startswith(PREFIX) and not key[len(PREFIX):].startswith('_') and key != PREFIX+'input_valid':
                draft[key[len(PREFIX):]] = deepcopy(self.st.session_state[key])
        self.st.session_state[PREFIX+'_draft_widgets'] = draft


def _geometry_fields(ui, station, i, *, automatic):
    st = ui.st
    key = 'stations.'+str(i)+'.'
    s = deepcopy(station)
    st.caption('Par '+str(i+1)+': duas chapas simétricas; posição física em relação ao eixo do apoio esquerdo.')
    s['station_id'] = ui.text(key+'station_id', 'Identificação do par', s['station_id'])
    s['x_mm'] = ui.number(key+'x_mm', 'Posição x do par [mm]', s['x_mm'])
    mode = ui.choice(key+'requirements', 'Detalhe e requisitos de execução deste par',
        ADOPTED if automatic else PRESERVED, {
            PRESERVED: 'Preservar exatamente os requisitos informados/importados',
            ADOPTED: 'Especificar o detalhe adotado: Q.E., K/CJP, goivagem, inspeção e acabamento'})
    p, w, c = s['pair'], s['web_fillet'], s['cjp']
    just_adopted = mode == ADOPTED and ui.previous.get(key+'requirements') != ADOPTED
    for name, label in (
        ('thickness_mm', 'Espessura tp da chapa, na direção longitudinal [mm]'),
        ('outstand_mm', 'Largura saliente de cada chapa, desde a face da alma [mm]'),
        ('bottom_z_mm', 'Cota inferior da chapa, desde a face externa da mesa inferior [mm]'),
        ('cope_radius_mm', 'Raio real do recorte circular côncavo [mm]'),
        ('required_root_clearance_mm', 'Folga física mínima recorte–raiz, para acesso [mm]')):
        p[name] = ui.number(key+'pair.'+name, label, p[name])
    w['leg_mm'] = ui.number(key+'web_fillet.leg_mm', 'Perna real dos filetes contínuos da alma [mm]', w['leg_mm'])
    w['lower_setback_mm'] = ui.number(key+'web_fillet.lower_setback_mm',
        'Recuo do ponto mais baixo do metal de solda em relação à borda inferior da chapa [mm]', w['lower_setback_mm'])
    st.caption('A folga inferior é entre o pé real da concordância inferior e o ponto mais baixo do metal '
        'depositado: z_chapa + recuo − (tf + r). Deve permanecer entre 4tw e 6tw, incluindo tolerâncias; '
        'não é medida a partir da mesa nem de um comprimento efetivo de solda.')
    for name, label in (
        ('reinforcement_leg_mm', 'Perna física do reforço reentrante da CJP [mm], sem ganho de garganta'),
        ('bevel_angle_deg', 'Ângulo do chanfro K com a face vertical da chapa [graus]'),
        ('root_face_mm', 'Nariz central não chanfrado da junta K [mm]'),
        ('root_gap_mm', 'Abertura física da raiz CJP [mm]')):
        c[name] = ui.number(key+'cjp.'+name, label, c[name])
    st.caption('O chanfro removido e o depósito que o recompõe são volumes reais. A abertura da raiz '
        'acrescenta metal; a folga do recorte não vira um filete equivalente gigante. A garganta CJP '
        'não é a perna do reforço: é limitada pelas espessuras conectadas.')
    with st.expander('Tolerâncias geométricas do par '+str(i+1), expanded=False):
        for part, fields in ((p, ('bottom_tolerance_mm', 'cope_radius_tolerance_mm')),
                (w, ('endpoint_tolerance_mm',)),
                (c, ('root_gap_tolerance_mm', 'reinforcement_leg_tolerance_mm'))):
            part_name = 'pair' if part is p else 'web_fillet' if part is w else 'cjp'
            labels = {'bottom_tolerance_mm':'Tolerância da cota inferior da chapa',
                'cope_radius_tolerance_mm':'Tolerância do raio do recorte',
                'endpoint_tolerance_mm':'Tolerância do ponto inferior da solda',
                'root_gap_tolerance_mm':'Tolerância da abertura da raiz CJP',
                'reinforcement_leg_tolerance_mm':'Tolerância da perna do reforço CJP'}
            for name in fields:
                part[name] = ui.number(key+part_name+'.'+name, labels[name]+' [±mm]', part[name])
        st.caption('Zero é uma dimensão exata adotada no modelo, não uma tolerância de fabricação presumida.')
    with st.expander('Especificação de fabricação do par '+str(i+1), expanded=False):
        if just_adopted:
            # One explicit adoption action may supply missing REQUIREMENTS,
            # never overwrite a supplied procedure/source or fabricate results.
            requirements = {
                'web_fillet': {'procedure_id':'EPS dos filetes: qualificação exigida antes da execução',
                    'compatibility_basis':'Exigir compatibilidade com os aços da viga e das chapas.',
                    'qe_end_zone_length_mm':None if p['thickness_mm'] is None else 10*p['thickness_mm']},
                'cjp': {'procedure_id':'EPS da junta K/CJP: qualificação exigida antes da execução',
                    'compatibility_basis':'Exigir depósito compatível para recomposição integral da seção.',
                    'access_description':'Exigir acesso pelos dois lados para goivagem e ressoldagem da raiz.',
                    'inspection_acceptance':'Exigir aceitação para solicitação cíclica conforme AWS D1.1.',
                    'procedure_status':'qualified', 'inspection_method':'UT'}}
            for part_name, replacements in requirements.items():
                part = s[part_name]
                for name, value in replacements.items():
                    field = key+part_name+'.'+name
                    existing = st.session_state.get(PREFIX+field, ui.previous.get(field, part[name]))
                    if existing in (None, '', 'unspecified'):
                        part[name] = value
                        st.session_state[PREFIX+field] = value
        if mode == ADOPTED:
            p['cope_finish'] = 'ground'
            w.update(dict.fromkeys(WEB_REQUIREMENTS, True))
            c.update(dict.fromkeys(CJP_REQUIREMENTS, True))
            w['continuous'] = True
            c.update(permanent_backing=False, root_method='backgouged_and_welded')
            st.caption(REQUIREMENTS)
        else:
            p['cope_finish'] = ui.choice(key+'pair.cope_finish', 'Acabamento exigido do recorte', p['cope_finish'],
                {'ground':'Esmerilhado', 'machined':'Usinado', 'unspecified':'Não especificado no registro'})
            st.caption('As declarações importadas permanecem inalteradas. Escolher o detalhe adotado '
                'acima especifica o conjunto de requisitos; não confirma sua execução.')
        p['thermally_cut'] = ui.choice(key+'pair.thermally_cut', 'Processo previsto para o recorte',
            p['thermally_cut'], {False:'Sem corte térmico', True:'Com corte térmico'})
        if p['thermally_cut']:
            p['thermal_cut_roughness_um'] = ui.number(key+'pair.thermal_cut_roughness_um',
                'Rugosidade máxima especificada para o corte térmico [µm]',
                25. if automatic and p['thermal_cut_roughness_um'] is None else p['thermal_cut_roughness_um'])
        w['qe_end_zone_length_mm'] = ui.number(key+'web_fillet.qe_end_zone_length_mm',
            'Comprimento Q.E. exigido em cada extremidade dos filetes [mm], mínimo 10tp',
            10*p['thickness_mm'] if automatic and p['thickness_mm'] is not None else w['qe_end_zone_length_mm'])
        for part_name, part in (('web_fillet', w), ('cjp', c)):
            joint = 'filetes da alma' if part_name == 'web_fillet' else 'K/CJP superior'
            for name, label in (('procedure_id','Identificação/requisito da EPS'), ('compatibility_basis','Base exigida de compatibilidade dos materiais')):
                part[name] = ui.text(key+part_name+'.'+name, label+' · '+joint, part[name]) or None
        status = c['procedure_status']
        if mode == ADOPTED and status == 'unspecified':
            status = 'qualified'
        c['procedure_status'] = ui.choice(key+'cjp.procedure_status',
            'Condição de EPS exigida em projeto, não comprovada nesta tela', status,
            {'qualified':'Exigir EPS qualificada', 'prequalified':'Exigir EPS pré-qualificada aplicável',
             'unspecified':'Condição não especificada no registro'})
        c['inspection_method'] = ui.choice(key+'cjp.inspection_method', 'Inspeção volumétrica especificada para a CJP',
            'UT' if mode == ADOPTED and c['inspection_method'] is None else c['inspection_method'],
            {'UT':'Exigir UT', 'RT':'Exigir RT', None:'Método não especificado no registro'})
        for name, label in (('access_description','Acesso exigido para executar a raiz e a CJP'),
                ('inspection_acceptance','Critério exigido de aceitação da inspeção CJP')):
            c[name] = ui.text(key+'cjp.'+name, label, c[name]) or None
    return s


def _materials(ui, raw, stations):
    st = ui.st
    steels = {v['material_id']:deepcopy(v) for v in raw['plate_materials']}
    welds = {v['material_id']:deepcopy(v) for v in raw['weld_consumables']}
    for i, s in enumerate(stations):
        with st.expander('Materiais associados ao par '+str(i+1), expanded=False):
            for part, inventory, label in (('pair', steels, 'Aço das chapas'),
                    ('web_fillet', welds, 'Consumível dos filetes da alma'), ('cjp', welds, 'Consumível da CJP')):
                key = 'stations.'+str(i)+'.'+part+'.material.'
                material = s[part]['material']
                selected = ui.choice(key+'material_id', label, material['material_id'], {x:x for x in inventory})
                material['material_id'] = selected
                material['density_kg_m3'] = ui.number(key+'density_kg_m3',
                    'Massa específica · '+label+' [kg/m³]', material['density_kg_m3'])
    used_steels = {s['pair']['material']['material_id'] for s in stations}
    used_welds = {s[k]['material']['material_id'] for s in stations for k in ('web_fillet', 'cjp')}
    cjp_ids = {s['cjp']['material']['material_id'] for s in stations}
    for inventory, used, is_steel in ((steels, used_steels, True), (welds, used_welds, False)):
        for material_id, data in inventory.items():
            if material_id not in used:
                continue
            key = ('plate_materials.' if is_steel else 'weld_consumables.')+material_id+'.'
            with st.expander(('Aço das chapas: ' if is_steel else 'Depósito de solda: ')+material_id, expanded=False):
                st.caption('Propriedades próprias do material identificado; não são herdadas automaticamente do aço da viga.')
                fields = (('fy_mpa','fy da chapa'), ('fu_mpa','fu da chapa'), ('E_mpa','E da chapa')) if is_steel else (
                    ('fyw_mpa','fyw do depósito, para a recomposição da CJP'),
                    ('fuw_mpa','fuw do depósito'), ('E_mpa','E do depósito'))
                if not is_steel and material_id not in cjp_ids:
                    fields = (('fuw_mpa', 'fuw do depósito dos filetes'),)
                for name, label in fields:
                    data[name] = ui.number(key+name, label+' [MPa]', data[name])
                name = 'grade' if is_steel else 'consumable_id'
                data[name] = ui.text(key+name, 'Designação do aço' if is_steel else 'Designação do consumível', data[name])
                data['specification_source'] = ui.text(key+'specification_source',
                    'Fonte ou requisito adotado no cálculo, sem afirmar certificado', data['specification_source'])
    for s in stations:
        for part in ('web_fillet', 'cjp'):
            s[part]['consumable_id'] = welds[s[part]['material']['material_id']]['consumable_id']
    raw['plate_materials'] = tuple(v for k, v in steels.items() if k in used_steels)
    raw['weld_consumables'] = tuple(v for k, v in welds.items() if k in used_welds)


def render_intermediate_inputs(st, project, current=None):
    """Return typed physical input, or None for absent/invalid (see state flag).

    ``current`` accepts typed IntermediateInputs or its exact physical dict;
    omission reads project.intermediates, including legacy projects with None.
    Returning an input never mutates the project or changes its route/schema.
    On rejection, ``session_state[PREFIX+'input_valid']`` is False, so a future
    caller must not reinterpret rejection as an approved unstiffened project.
    """
    state = st.session_state
    state[PREFIX+'input_valid'] = False
    st.caption('TOP · Enrijecedores intermediários somente para estabilização de painéis ao cortante e peso próprio. '
        'Não são apoio, enrijecedor de apoio/bearing, transferência de roda, travamento/contraventamento, '
        'restrição de FLT nem detalhe UNDER. Esta tela não ativa nenhuma rota de cálculo.')
    try:
        supplied = current if current is not None else getattr(project, 'intermediates', None)
        supplied_raw = supplied.to_dict() if isinstance(supplied, IntermediateInputs) else deepcopy(supplied)
        if supplied_raw is not None:
            IntermediateInputs.from_dict(supplied_raw)  # Never repair malformed imported inventories.
        incoming = _token(supplied_raw)
        old_incoming = state.get(PREFIX+'_incoming')
        imported = (old_incoming is not None and incoming != old_incoming
            and incoming != state.get(PREFIX+'_last_output'))
        if imported:
            for key in list(state):
                if key.startswith(PREFIX):
                    del state[key]
        if PREFIX+'_automatic' not in state:
            state[PREFIX+'_automatic'] = supplied_raw is None
        state[PREFIX+'_incoming'] = incoming
        automatic = state[PREFIX+'_automatic']
        ui = _Fields(st, automatic)
        mode = ui.choice('mode', 'Presença física de pares intermediários TOP',
            'absent' if supplied_raw is None else 'present',
            {'absent':'Sem intermediários neste detalhe', 'present':'Com pares intermediários: editar geometria e requisitos'})
        if mode == 'absent':
            state[PREFIX+'input_valid'] = True
            state[PREFIX+'_last_output'] = _token(None)
            ui.save()
            return None
        section = section_from_profile(project.section_catalog_id)
        raw = _defaults(project, section) if automatic else deepcopy(supplied_raw)
        beam = raw['layout']['beam']
        st.caption('Perfil selecionado: '+project.section_catalog_id+'. Origem x=0 no apoio esquerdo; '
            'vão entre eixos = '+str(project.structure.span_m*1000)+' mm. '
            'O raio equivalente obtido de d, tf e altura livre do catálogo não é raio real medido pelo fabricante.')
        with st.expander('Raiz física da seção e fonte do detalhe', expanded=True):
            beam['root_radius_mm'] = ui.number('beam.root_radius_mm', 'Raio circular físico da concordância da viga [mm]', beam['root_radius_mm'])
            beam['root_radius_source'] = ui.text('beam.root_radius_source',
                'Fonte/dado físico do raio, ou adoção geométrica sintética explicitamente identificada', beam['root_radius_source'])
            st.caption('O dado físico deve conciliar exatamente a altura livre resistente do perfil selecionado. '
                'Alterar apenas o raio para caber no recorte não é permitido; não há conversão automática de raio equivalente em medição.')
            for name, label in (('root_radius_tolerance_mm','Tolerância do raio físico'),
                    ('flange_thickness_tolerance_mm','Tolerância da espessura da mesa'),
                    ('web_thickness_tolerance_mm','Tolerância da espessura da alma')):
                beam[name] = ui.number('beam.'+name, label+' [±mm]', beam[name])
            raw['detail_source'] = ui.text('detail_source', 'Fonte ou requisito do detalhe adotado no cálculo', raw['detail_source'])
        st.caption(REQUIREMENTS)
        count = ui.number('count', 'Quantidade de pares intermediários', len(raw['layout']['stations']), integer=True)
        if type(count) is not int or count < 1:
            raise ValueError('Informe uma quantidade inteira positiva de pares intermediários.')
        stations = []
        originals = raw['layout']['stations']
        for i in range(count):
            station = deepcopy(originals[i] if i < len(originals) else originals[0])
            if automatic or i >= len(originals):
                station['station_id'] = 'I'+str(i+1)
                station['x_mm'] = project.structure.span_m*1000*(i+1)/(count+1)
            with st.expander('Par intermediário '+str(i+1), expanded=i == 0):
                stations.append(_geometry_fields(ui, station, i,
                    automatic=automatic or i >= len(originals)))
        _materials(ui, raw, stations)
        raw['layout']['stations'] = tuple(stations)
        result = IntermediateInputs.from_dict(raw)
        result.validate_base_section(section, project.structure.span_m*1000)
        result.validate_base_material(project.material)
        result.validate_project_sources(project)
        for station in result.layout.stations:
            assessment = assess_detail(result.layout.beam, station)
            st.caption(station.station_id+': folga inferior real = '+format(assessment.gap_weld_mm, '.3f')+
                ' mm; envelope com tolerâncias = '+format(assessment.gap_weld_min_mm, '.3f')+' a '+
                format(assessment.gap_weld_max_mm, '.3f')+' mm; faixa exigida = '+
                format(assessment.required_gap_min_mm, '.3f')+' a '+format(assessment.required_gap_max_mm, '.3f')+' mm.')
            if not assessment.design_requirements_satisfied:
                st.warning(station.station_id+': há requisitos geométricos/de execução pendentes ('+
                    str(len(assessment.pending))+'). Revise folgas, filetes, Q.E., CJP e acabamento; '
                    'a entrada física não é aprovação resistente ou de fadiga.')
        cjp_ids = {s.cjp.material.material_id for s in result.layout.stations}
        if any(w.material_id in cjp_ids and (w.fyw_mpa is None or w.E_mpa is None) for w in result.weld_consumables):
            st.warning('Informe fyw e E próprios do depósito CJP para a verificação da recomposição; não se presume equivalência com a chapa.')
        state[PREFIX+'input_valid'] = True
        state[PREFIX+'_last_output'] = _token(result.to_dict())
        return result
    except (ValueError, TypeError, KeyError, AttributeError) as exc:
        state[PREFIX+'input_valid'] = False
        st.error('Entradas físicas do detalhe intermediário inválidas. Revise os dados; nenhuma rota foi alterada. '+str(exc))
        return None
    finally:
        if 'ui' in locals():
            ui.save()
