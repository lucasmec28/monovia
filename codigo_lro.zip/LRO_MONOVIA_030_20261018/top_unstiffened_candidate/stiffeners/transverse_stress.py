"""Isolated NBR 10084:2020 9.1.3.3-9.1.3.4 transverse-web scalar.

Units: N, mm, N mm and MPa (= N/mm²). This is NOT a station, beam, weld,
fatigue or physical-geometry qualification. The source applies to transverse
stiffeners welded to the web. ``stiffener_spacing_mm`` means the actual
spacing of adjacent transverse stiffeners, never a substituted service span.
``total_web_depth_mm`` is hw, not the clear depth used by the shear kernel.

The present domain has a NON-RIGID rail attachment. Supply only the upper
flange Saint-Venant torsion constant It, in mm⁴: neither rail It, a major/minor
axis second moment, nor the stiffener's Is is an interchangeable input. Scalar
numbers cannot prove those physical facts, so no user qualification flag is
accepted and no physical qualification is inferred from a calculation.

Figure 5 does not identify signed axes or physical web faces. The positive
coefficient, its algebraic product with T, its magnitude and the UNLABELED
candidates ±magnitude are deliberately separate. They are not a signed tensor
or two times in a fatigue history. The maximum-compression combination is a
separate static operation on a compatible compression-positive sigma0z.

Numeric domain: nonzero derived eta, coefficient, torque, stresses, static
combination terms and eccentricity-helper outputs must be finite NORMAL
binary64 values (absolute value >= sys.float_info.min, about 2.225e-308).
Coarsely rounded subnormals are rejected before reuse; exact zero actions and
stresses remain valid. Beta may be subnormal because its reciprocal is
eliminated algebraically from eta using original geometry. This restriction
prevents numerical amplification, not a new physical or normative limit.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal
from math import exp, expm1, frexp, fsum, isfinite, ldexp, nextafter, pi, sqrt, tanh
from numbers import Real
from sys import float_info


TRANSVERSE_STRESS_SOURCE = (
    "ABNT NBR 10084:2020, 9.1.3.3-9.1.3.4 and Figure 5, pp. 7-8 "
    "(source PDF pp. 11-12); isolated nominal-closure contract 2026-10-17"
)
CONTRACT_SHA256 = "305477d5e537232087489a5d3da42d695050995d6a23e9702492fb55b52f7eb9"

__all__ = [
    "TransverseWebStressResult",
    "PrescribedMaximumCompressionResult",
    "transverse_web_stress",
    "prescribed_max_compression",
    "flanged_wheel_eccentricity_mm",
    "guided_wheel_nonguided_side_eccentricity_mm",
]


def _finite_real(value: object, name: str) -> float:
    """Accept real numeric types, including Decimal/Fraction, never bool/text."""
    if isinstance(value, bool) or not isinstance(value, (Real, Decimal)):
        raise TypeError(f"{name} must be a real number, not {type(value).__name__}")
    try:
        number = float(value)
    except (OverflowError, ValueError) as exc:
        raise ValueError(f"{name} must be finite and representable") from exc
    if not isfinite(number):
        raise ValueError(f"{name} must be finite and representable")
    if number == 0.0 and value != 0:
        raise ValueError(f"{name} is nonzero but underflows the numeric domain")
    return number


def _positive_real(value: object, name: str) -> float:
    number = _finite_real(value, name)
    if number <= 0.0:
        raise ValueError(f"{name} must be strictly positive")
    return number


def _nonnegative_real(value: object, name: str) -> float:
    number = _finite_real(value, name)
    if number < 0.0:
        raise ValueError(f"{name} must be nonnegative")
    return number


def _normal_derived(value: float, name: str) -> float:
    """Reject coarse subnormal derived values before reuse or exposure.

    Zero actions/stresses are permitted. A nonzero subnormal result can lose
    a substantial relative fraction before later amplification, despite
    remaining finite. This numeric restriction is not a physical-domain
    boundary. Beta alone is exempt: its small-beta reciprocal is eliminated
    algebraically using original geometry before eta is calculated.
    """
    if not isfinite(value) or 0.0 < abs(value) < float_info.min:
        raise ValueError(f"{name} must be zero or a finite normal binary64 result; subnormal reuse is unsupported")
    return value


def _product_parts(
    numerators: tuple[float, ...], denominators: tuple[float, ...] = ()
) -> tuple[float, int]:
    """Represent a short positive product/quotient without intermediate overflow.

    Factors are already validated and positive. Only their mantissas are
    multiplied; the (possibly very large) exponent is a Python integer.
    """
    mantissa, exponent = 1.0, 0
    for value in numerators:
        part, power = frexp(value)
        mantissa *= part
        exponent += power
    for value in denominators:
        part, power = frexp(value)
        mantissa /= part
        exponent -= power
    mantissa, power = frexp(mantissa)
    return mantissa, exponent + power


def _from_parts(mantissa: float, exponent: int, name: str) -> float:
    try:
        value = ldexp(mantissa, exponent)
    except OverflowError as exc:
        raise ValueError(f"{name} exceeds the finite numeric domain") from exc
    if not isfinite(value) or value <= 0.0:
        raise ValueError(f"{name} is outside the finite positive numeric domain")
    return value


def _positive_product(
    numerators: tuple[float, ...], denominators: tuple[float, ...], name: str
) -> float:
    return _from_parts(*_product_parts(numerators, denominators), name)


def _sqrt_product(
    numerators: tuple[float, ...], denominators: tuple[float, ...], name: str
) -> float:
    mantissa, exponent = _product_parts(numerators, denominators)
    half_exponent, remainder = divmod(exponent, 2)
    return _from_parts(sqrt(ldexp(mantissa, remainder)), half_exponent, name)


def _signed_product(left: float, right: float, name: str) -> float:
    if left == 0.0 or right == 0.0:
        return 0.0
    magnitude = _positive_product((abs(left), abs(right)), (), name)
    return -magnitude if (left < 0.0) != (right < 0.0) else magnitude


def _hyperbolic_ratio_parts(beta: float) -> tuple[tuple[float, ...], tuple[float, ...]]:
    """Stable factors of sinh(beta)²/[sinh(2 beta)-2 beta].

    For 0 < beta <= 1/2, let x=4 beta² (0 <= x <= 1):
      N = sinh(beta)²/beta² = sum[n>=0] 2 x**n/(2n+2)!
      D = (sinh(2 beta)-2 beta)/(4 beta³/3)
        = sum[n>=0] 6 x**n/(2n+3)!
      ratio = (3/(4 beta)) N/D.
    We retain n=0..10. The omitted positive N tail is at most
    (2/24!)/(1-1/(25*26)) < 3.23e-24; the D tail is < 3.88e-25.
    Both sums are >=1. A one-ulp upward numerator and downward denominator
    guard against the systematic downward truncation bias. This is not a
    universal outward-rounded error bound: recurrence/product roundoff is
    separately tested. It is not a normative stress factor or physical bound.
    Underflow of x only removes terms far below binary64 resolution.

    For beta > 1/2, q=exp(-2 beta) and the EXACT scaled identity is
      ratio = (1-q)² / [2(1-q²-4 beta q)].
    Form q as exp(-beta)², and 4 beta q as 4*(beta*q): neither 2 beta nor
    sinh(2 beta) is formed, including for beta near the float maximum.
    1-q uses expm1. At the branch boundary the denominator is >0.129,
    avoiding the small-beta cancellation. Exponential underflow only drops
    corrections below binary64 resolution; no fitted asymptote is used.
    All remaining operations use binary64 rounding, tested independently.
    """
    if beta <= 0.5:
        x = (2.0 * beta) ** 2
        numerator_terms, denominator_terms = [1.0], [1.0]
        numerator_term = denominator_term = 1.0
        for n in range(10):
            numerator_term *= x / ((2*n + 3) * (2*n + 4))
            denominator_term *= x / ((2*n + 4) * (2*n + 5))
            numerator_terms.append(numerator_term)
            denominator_terms.append(denominator_term)
        numerator_upper = nextafter(fsum(numerator_terms), float("inf"))
        denominator_lower = nextafter(fsum(denominator_terms), 0.0)
        return (0.75, numerator_upper), (beta, denominator_lower)
    exp_minus_beta = exp(-beta)
    q = exp_minus_beta * exp_minus_beta
    one_minus_q = -expm1(-beta) * (1.0 + exp_minus_beta)
    denominator = one_minus_q * (1.0 + q) - 4.0 * (beta * q)
    ratio = 0.5 * one_minus_q * one_minus_q / denominator
    return (ratio,), ()


@dataclass(frozen=True)
class TransverseWebStressResult:
    """One source scalar response; candidate signs have no physical face labels."""

    stiffener_spacing_mm: float
    total_web_depth_mm: float
    web_thickness_mm: float
    upper_flange_saint_venant_mm4: float
    vertical_force_N: float
    eccentricity_mm: float
    torque_Nmm: float
    beta: float
    eta: float
    coefficient_MPa_per_Nmm: float
    sigmaT_algebraic_MPa: float
    sigmaT_magnitude_MPa: float
    bending_candidates_MPa: tuple[float, float]
    production_credit: bool = field(default=False, init=False)
    station_scope_evaluated: bool = field(default=False, init=False)
    physical_geometry_evaluated: bool = field(default=False, init=False)
    source_domain_qualified: bool = field(default=False, init=False)
    physical_face_mapping_evaluated: bool = field(default=False, init=False)
    fatigue_history_evaluated: bool = field(default=False, init=False)
    stiffener_forces_evaluated: bool = field(default=False, init=False)
    rail_basis: str = field(default="nonrigid_rail_upper_flange_It_only", init=False)
    source: str = field(default=TRANSVERSE_STRESS_SOURCE, init=False)
    contract_sha256: str = field(default=CONTRACT_SHA256, init=False)
    scope: str = field(default=(
        "Source scalar only for supplied actual stiffener spacing and upper-flange "
        "Saint-Venant It; transverse stiffeners welded to the web are the source "
        "physical domain, not qualified by these numbers. No rail torsional credit, "
        "global section-property credit, physical face assignment, fatigue history, "
        "stiffener/weld force distribution or complete station approval."
    ), init=False)


def transverse_web_stress(
    *,
    stiffener_spacing_mm: float,
    total_web_depth_mm: float,
    web_thickness_mm: float,
    upper_flange_saint_venant_mm4: float,
    vertical_force_N: float,
    eccentricity_mm: float,
) -> TransverseWebStressResult:
    """Evaluate beta, eta and sigmaT using NBR 10084 9.1.3.3 literally.

    beta = pi hw/a
    eta² = (0.75 a tw³/It) sinh(beta)² / (sinh(2 beta)-2 beta)
    T = Fz ey; sigmaT = [6/(a tw²)] eta tanh(eta) T.

    Signed force/eccentricity are algebraic inputs, NOT a claimed physical
    face convention. Actual spacing, welded attachments and the identity of
    It require external physical evidence; this pure calculation cannot
    certify them. No geometry, reaction, force split or stress history is
    inferred. Numeric under/overflow of a required nonzero output is rejected
    rather than silently converted into zero or infinity. Nonzero eta,
    coefficient, torque and stress outputs must be normal binary64 values:
    coarse subnormal rounding must not be amplified by a subsequent product.
    Subnormal beta is diagnostic only; its reciprocal is eliminated
    algebraically from eta using the original geometry.
    """
    a = _positive_real(stiffener_spacing_mm, "stiffener_spacing_mm")
    hw = _positive_real(total_web_depth_mm, "total_web_depth_mm")
    tw = _positive_real(web_thickness_mm, "web_thickness_mm")
    It = _positive_real(upper_flange_saint_venant_mm4, "upper_flange_saint_venant_mm4")
    force = _finite_real(vertical_force_N, "vertical_force_N")
    eccentricity = _finite_real(eccentricity_mm, "eccentricity_mm")
    beta = _positive_product((pi, hw), (a,), "beta")
    ratio_numerators, ratio_denominators = _hyperbolic_ratio_parts(beta)
    if beta <= 0.5:
        # Replace 1/beta algebraically by a/(pi*hw). In particular, a
        # representable subnormal beta can have coarse relative rounding;
        # do not propagate that rounding into the source eta expression.
        eta_numerators = (0.75, a, a, tw, tw, tw) + ratio_numerators
        eta_denominators = (It, pi, hw) + ratio_denominators[1:]
    else:
        eta_numerators = (0.75, a, tw, tw, tw) + ratio_numerators
        eta_denominators = (It,) + ratio_denominators
    eta = _normal_derived(_sqrt_product(eta_numerators, eta_denominators, "eta"), "eta")
    coefficient = _normal_derived(
        _positive_product((6.0, eta, tanh(eta)), (a, tw, tw), "coefficient"), "coefficient"
    )
    torque = _normal_derived(_signed_product(force, eccentricity, "torque_Nmm"), "torque_Nmm")
    algebraic = _normal_derived(
        _signed_product(coefficient, torque, "sigmaT_algebraic_MPa"), "sigmaT_algebraic_MPa"
    )
    magnitude = abs(algebraic)
    return TransverseWebStressResult(
        stiffener_spacing_mm=a,
        total_web_depth_mm=hw,
        web_thickness_mm=tw,
        upper_flange_saint_venant_mm4=It,
        vertical_force_N=force,
        eccentricity_mm=eccentricity,
        torque_Nmm=torque,
        beta=beta,
        eta=eta,
        coefficient_MPa_per_Nmm=coefficient,
        sigmaT_algebraic_MPa=algebraic,
        sigmaT_magnitude_MPa=magnitude,
        bending_candidates_MPa=(magnitude, -magnitude),
    )


@dataclass(frozen=True)
class PrescribedMaximumCompressionResult:
    """Static maximum compression only, not an admissibility or fatigue check."""

    sigma0z_compression_positive_MPa: float
    sigmaT_magnitude_MPa: float
    maximum_compression_MPa: float
    source_bending_factor: float = field(default=0.75, init=False)
    production_credit: bool = field(default=False, init=False)
    station_scope_evaluated: bool = field(default=False, init=False)
    physical_compatibility_evaluated: bool = field(default=False, init=False)
    is_signed_tensor_component: bool = field(default=False, init=False)
    fatigue_history_evaluated: bool = field(default=False, init=False)
    admissibility_evaluated: bool = field(default=False, init=False)
    source: str = field(default=TRANSVERSE_STRESS_SOURCE, init=False)
    scope: str = field(default=(
        "NBR 10084 9.1.3.4 static maximum compression: compatible "
        "compression-positive sigma0z + 0.75*abs(sigmaT). The caller must "
        "establish a compatible load case, location and source domain. "
        "No signed tensor, admissible stress comparison or fatigue reduction."
    ), init=False)


def prescribed_max_compression(
    sigma0z_compression_positive_MPa: float,
    transverse_result: TransverseWebStressResult,
) -> PrescribedMaximumCompressionResult:
    """Combine compatible compression-positive sigma0z with 0.75*|sigmaT|.

    Compression must be supplied as a nonnegative magnitude in MPa, not as
    an arbitrary signed tensor component. This function does not establish
    physical compatibility or the applicable NBR 8400 admissible stress.
    """
    sigma0z = _nonnegative_real(
        sigma0z_compression_positive_MPa, "sigma0z_compression_positive_MPa"
    )
    if not isinstance(transverse_result, TransverseWebStressResult):
        raise TypeError("transverse_result must be a TransverseWebStressResult")
    magnitude = _normal_derived(
        _nonnegative_real(transverse_result.sigmaT_magnitude_MPa, "sigmaT_magnitude_MPa"),
        "sigmaT_magnitude_MPa",
    )
    bending = _normal_derived(0.75 * magnitude, "prescribed_bending_contribution_MPa")
    maximum = _normal_derived(sigma0z + bending, "maximum_compression_MPa")
    return PrescribedMaximumCompressionResult(sigma0z, magnitude, maximum)


def flanged_wheel_eccentricity_mm(*, wheel_flange_clearance_mm: float) -> float:
    """NBR 10084 Figure 5: eccentricity magnitude ey = 0.5 fw (clearance)."""
    clearance = _nonnegative_real(wheel_flange_clearance_mm, "wheel_flange_clearance_mm")
    return 0.0 if clearance == 0.0 else _normal_derived(
        _positive_product((0.5, clearance), (), "eccentricity_mm"), "eccentricity_mm"
    )


def guided_wheel_nonguided_side_eccentricity_mm(*, rail_head_width_mm: float) -> float:
    """Guide-roller/non-guided side: ey = 0.25 br, with br = rail HEAD width.

    Rail-foot width bfr used in the local compression effective width is
    different and is intentionally not accepted by this helper.
    """
    width = _positive_real(rail_head_width_mm, "rail_head_width_mm")
    return _normal_derived(_positive_product((0.25, width), (), "eccentricity_mm"), "eccentricity_mm")
