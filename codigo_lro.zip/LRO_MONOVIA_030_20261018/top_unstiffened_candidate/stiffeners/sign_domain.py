"""Exact rational nominal sign gate, including complete spatial jump allowances.

This certifies the declared Macaulay/CISC nominal model, not a physical 3-D
stress field. Small compression is never rounded to zero. No station approval.
"""
from fractions import Fraction as F
from math import isfinite
from .fixed_point import fixed_point_resultant_bounds


def _real(v):
    if type(v) is F:
        return v  # Exact derived wall coordinates; no float branch crossing.
    if type(v) not in (int,float) or not isfinite(v): raise ValueError('Finite real coordinate required')
    return F(v)


def _ratio(v): return (v.numerator,v.denominator)


def _weight(c,y,z):
    s=c.project.section;flange=abs(z)>=F(s.d_mm)/2-F(s.tf_mm)
    if abs(z)>F(s.d_mm)/2 or abs(y)>(F(s.bf_mm)/2 if flange else F(s.tw_mm)/2):
        raise ValueError('Point outside nominal rectangular wall')
    if flange: return F(1) if z>=0 else F(0)
    return max(F(0),min(F(1),F(1,2)+z/F(c.h_mm)))


def _moment(L,x,a,p,c,left):
    return p*((L-a)*x/L-(x-a if left else 0))+c*(-x/L+int(left))


def exact_longitudinal_sign_bounds(c,x_m,y_mm,z_mm,*,cut_side='right'):
    base=fixed_point_resultant_bounds(c,x_m,cut_side=cut_side) # validates fresh prepared identity
    L,x=F(c.project.span_m),F(x_m);y,z=_real(y_mm),_real(z_mm);wt=_weight(c,y,z)
    events=tuple(F(*r) for r in base['event_exact_ratios']);indices={e:i for i,e in enumerate(events)}
    keys=(('vertical_kn','major_moment_knm'),('horizontal_kn','minor_moment_knm'),('horizontal_kn','minor_moment_knm'))
    fixed=[]
    for loads,q,(pk,ck) in zip((c.major_fixed,c.top_fixed,c.bottom_fixed),
            (c.udl.vertical_kn_per_m,c.top_udl.horizontal_kn_per_m,c.bottom_udl.horizontal_kn_per_m),keys):
        fixed.append(F(q)*x*(L-x)/2+sum((_moment(L,x,F(w.position_m),F(getattr(w,pk)),F(getattr(w,ck)),
            F(w.position_m)<x or (F(w.position_m)==x and cut_side=='right')) for w in loads),F(0)))
    nf=F(c.udl.longitudinal_kn_per_m)*(L-x)+sum((F(w.longitudinal_kn) for w in c.major_fixed
        if F(w.position_m)>x or (F(w.position_m)==x and cut_side=='left')),F(0))
    values=[]
    for row in base['candidate_states']:
        t=F(*row['translation_exact_ratio']);idx=indices[t];kind=row['limit_kind']
        rep=t if kind=='actual_event' else ((t+events[idx+1])/2 if kind=='right_open_cell_limit' else (events[idx-1]+t)/2)
        m=list(fixed);n=nf
        for trio in zip(c.source_wheels,c.top_wheels,c.bottom_wheels):
            off=F(trio[0].offset_m);ar=rep+off
            if not 0<=ar<=L: continue
            left=ar<x or (ar==x and cut_side=='right')
            for i,(w,(pk,ck)) in enumerate(zip(trio,keys)):
                m[i]+=_moment(L,x,t+off,F(getattr(w,pk)),F(getattr(w,ck)),left)
            if not left: n+=F(trio[0].longitudinal_kn)
        values.append(n*1000/F(c.properties.A_mm2)-m[0]*1000000*z/F(c.properties.Ix_mm4)+
            (wt*m[1]+(1-wt)*m[2])*1000000*y/F(c.flange_I_mm4))
    lo,hi=min(values),max(values)
    return dict(position_m=float(x),y_mm=float(y),z_mm=float(z),cut_side=cut_side,
        sigma_x_exact_ratio=(_ratio(lo),_ratio(hi)),no_nominal_compression=lo>=0,
        all_translations_covered=True,arithmetic='Exact rational operations on validated binary input values',
        nominal_wall_model_only=True,physical_3d_bound_claimed=False,station_qualified=False)


def _variation(c,loads,fixed,q,pk,ck,dx):
    L=F(c.project.span_m);all_loads=tuple(loads)+tuple(fixed)
    ps=sum((abs(F(getattr(w,pk))) for w in all_loads),F(0))
    cs=sum((abs(F(getattr(w,ck))) for w in all_loads),F(0))
    return (abs(F(q))*L/2+ps+cs/L)*dx+(cs if dx else F(0))


def exact_longitudinal_patch_sign(c,x_range_m,y_range_mm,z_range_mm):
    ranges=[]
    for r in (x_range_m,y_range_mm,z_range_mm):
        if type(r) not in (tuple,list) or len(r)!=2: raise ValueError('Explicit two-endpoint range required')
        a,b=map(_real,r)
        if a>b: raise ValueError('Reversed physical range')
        ranges.append((a,b))
    (xa,xb),(ya,yb),(za,zb)=ranges;L=F(c.project.span_m)
    if not 0<xa<=xb<L: raise ValueError('Intermediate interruption patch must lie strictly between support axes; support faces have separate checks')
    xc=F(float((xa+xb)/2));dx=max(abs(xa-xc),abs(xb-xc))
    s=c.project.section;zbk=F(s.d_mm)/2-F(s.tf_mm);zs={za,zb}
    # Each certificate covers ONE nominal wall. The CISC web interpolation
    # need not equal the flange recovery at its inner face. Never certify a
    # patch across that discontinuity from only one branch at the boundary.
    in_top=za>=zbk;in_bottom=zb<=-zbk
    in_web=(-zbk<za<=zb<zbk)
    if not (in_top or in_bottom or in_web):
        raise ValueError('Patch crosses nominal wall branches; split into separate physical-wall regions')
    if in_web and max(abs(ya),abs(yb))>F(s.tw_mm)/2:
        raise ValueError('Patch crosses void beside web; split by physical wall')
    dm=tuple(_variation(c,ls,fs,q,pk,ck,dx) for ls,fs,q,(pk,ck) in zip(
        (c.source_wheels,c.top_wheels,c.bottom_wheels),(c.major_fixed,c.top_fixed,c.bottom_fixed),
        (c.udl.vertical_kn_per_m,c.top_udl.horizontal_kn_per_m,c.bottom_udl.horizontal_kn_per_m),
        (('vertical_kn','major_moment_knm'),('horizontal_kn','minor_moment_knm'),('horizontal_kn','minor_moment_knm'))))
    dn=abs(F(c.udl.longitudinal_kn_per_m))*dx
    if dx: dn+=sum((abs(F(w.longitudinal_kn)) for w in (*c.source_wheels,*c.major_fixed)),F(0))
    lows=[];highs=[];points=[]
    for y in sorted({ya,yb}):
        for z in sorted(zs):
            wt=_weight(c,y,z);out=exact_longitudinal_sign_bounds(c,float(xc),y,z)
            lo,hi=(F(*r) for r in out['sigma_x_exact_ratio'])
            allowance=dn*1000/F(c.properties.A_mm2)+dm[0]*1000000*abs(z)/F(c.properties.Ix_mm4)+(
                wt*dm[1]+(1-wt)*dm[2])*1000000*abs(y)/F(c.flange_I_mm4)
            lows.append(lo-allowance);highs.append(hi+allowance)
            points.append(dict(y_mm=float(y),z_mm=float(z),fixed_point=out,spatial_allowance_exact_ratio=_ratio(allowance)))
    lo,hi=min(lows),max(highs)
    return dict(x_range_m=tuple(map(float,(xa,xb))),y_range_mm=tuple(map(float,(ya,yb))),z_range_mm=tuple(map(float,(za,zb))),
        sigma_x_exact_ratio=(_ratio(lo),_ratio(hi)),no_nominal_compression=lo>=0,
        all_translations_and_patch_covered=True,point_evidence=tuple(points),
        spatial_method='Complete derivative plus axial/couple jumps; corner extrema within nominal wall',
        arithmetic='Exact rational operations on validated binary input values',nominal_wall_model_only=True,
        physical_3d_bound_claimed=False,station_qualified=False)
