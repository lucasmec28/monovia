"""Assemble geometry/material/prescriptive CANDIDATES for the adopted TOP detail.

The frozen detail and shear kernels remain unmodified.  The scalar rectangular
plate inertia is diagnostic only: each station is checked with the least FINAL
physical section reported by ``assess_detail``, including its cope and specified
CJP refill.  Prepared plate, exterior weld reinforcement and web bearing strips
are not substituted for that final section.

This module consumes physical workflow inputs, not user qualification flags or
external stresses.  It neither evaluates the required longitudinal sign history,
actual selfweight transfer, fatigue nor the member.  Consequently even sufficient
geometry/material/prescriptive candidates retain the no-credit kv=5.34 result.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
from hashlib import sha256
import json
from math import isfinite, sqrt
from typing import TYPE_CHECKING

from .detail import DetailAssessment, assess_detail
from .inputs import IntermediateInputs, StiffenerSteel, _text
from .regions import NominalRegion, RegionInventory, StationLine
from .shear import (SHEAR_SOURCE, STIFFENER_SOURCE, SteelShearInput,
                    paired_stiffener_prescriptive, shear_resistance)

if TYPE_CHECKING:
    from ..project import TopWorkflowProject


ASSEMBLY_SCHEMA = "TOP_INTERMEDIATE_PRESCRIPTIVE_CANDIDATE_V1"
NORMAL_NBR_GAMMA_A1 = 1.1
COMPOSITOR_PENDING = (
    "Exact concurrent longitudinal sign/action histories at both bottom-flange edges and actual weld termination points",
    "Physical selfweight G transfer and every actual additional action through plate, base metal and joints",
    "Complete current normal-NBR action coverage and concurrent demand checks",
    "Nominal fatigue of every new detail and material plane, including the CJP receiver and both web-weld ends",
    "Complete applicable station and member checks; no automatic panel, global stiffness or FLT credit",
)


@dataclass(frozen=True)
class NominalMaterialAssessment:
    material_id: str
    role: str
    fy_mpa: float
    fu_mpa: float
    E_mpa: float
    specification: str
    specification_source: str
    source_status: str
    nominal_domain_satisfied: bool = field(default=True, init=False)
    certificate_or_as_built_verified: bool = field(default=False, init=False)


@dataclass(frozen=True)
class AdjacentPanelCheck:
    region_id: str
    left_station_id: str
    right_station_id: str
    panel_length_mm: float
    aspect_ratio: float
    j: float
    Irequired_mm4: float
    final_section_Is_mm4: float | None
    inertia_pass: bool


@dataclass(frozen=True)
class StationPrescriptiveCandidate:
    station_id: str
    x_mm: float
    status: str
    plate_material: NominalMaterialAssessment
    detail: DetailAssessment
    c_over_t: float
    c_over_t_limit: float
    stockiness_pass: bool
    rectangular_Is_diagnostic_only_mm4: float | None
    final_section_Is_mm4: float | None
    Irequired_mm4: float | None
    inertia_pass: bool | None
    adjacent_panels: tuple[AdjacentPanelCheck, ...]
    geometry_prescriptive_candidate_sufficient: bool
    reconstruction_material_compatible: bool
    pending: tuple[str, ...]
    station_qualified: bool = field(default=False, init=False)
    station_complete: bool = field(default=False, init=False)
    tension_side_sign_evaluated: bool = field(default=False, init=False)
    G_transfer_evaluated: bool = field(default=False, init=False)
    fatigue_qualified: bool = field(default=False, init=False)
    production_credit_enabled: bool = field(default=False, init=False)
    inertia_basis: str = field(default=(
        "Minimum final physical section from frozen assess_detail, with real cope "
        "and explicitly specified compatible CJP refill; no web strips or reinforcement credit"
    ), init=False)


@dataclass(frozen=True)
class RegionShearCandidate:
    region: NominalRegion
    no_credit_kv: float
    no_credit_VRd_N: float
    candidate_kv: float | None
    candidate_VRd_N: float | None
    candidate_benefit_N: float | None
    geometry_prescriptive_endpoints_sufficient: bool
    selected_kv: float
    selected_VRd_N: float
    pending: tuple[str, ...]
    applied_benefit_N: float = field(default=0.0, init=False)
    panel_kv_selected: bool = field(default=False, init=False)
    production_credit_enabled: bool = field(default=False, init=False)


@dataclass(frozen=True)
class PrescriptiveAssembly:
    status: str
    input_signature: str
    geometry_inputs_hash: str
    inventory: RegionInventory
    beam_material: NominalMaterialAssessment
    gamma_a1: float
    stations: tuple[StationPrescriptiveCandidate, ...]
    regions: tuple[RegionShearCandidate, ...]
    detail_requirements_all_specified: bool
    geometry_prescriptive_candidates_sufficient: bool
    pending: tuple[str, ...] = field(default=COMPOSITOR_PENDING, init=False)
    schema: str = field(default=ASSEMBLY_SCHEMA, init=False)
    station_qualified: bool = field(default=False, init=False)
    member_qualified: bool = field(default=False, init=False)
    production_credit_enabled: bool = field(default=False, init=False)
    global_stiffness_credit: bool = field(default=False, init=False)
    buckling_length_credit: bool = field(default=False, init=False)
    source: tuple[str, ...] = field(default=(SHEAR_SOURCE, STIFFENER_SOURCE,
        "Adopted TOP intermediate detail contract 2026-10-17; geometry and material specification only"), init=False)

    def to_dict(self):
        return asdict(self)


def _positive(value, name):
    if type(value) not in (int, float) or not isfinite(value) or value <= 0:
        raise ValueError(name + " must be finite positive numeric physical data")
    return float(value)


def _material_domain(fy, fu, E, name):
    fy, fu, E = (_positive(value, name + " " + key)
                 for key, value in (("fy", fy), ("fu", fu), ("E", E)))
    if E != 200000. or fy > 450. or fu / fy < 1.15:
        raise ValueError(name + " requires E=200000 MPa, fy<=450 MPa and fu/fy>=1.15")


def _validate_material_identity(project, inputs):
    """No grade inference from IDs, and no contradictory use of one identity."""
    beam = inputs.layout.beam
    m = project.material
    _material_domain(m.fy_mpa, m.fu_mpa, m.E_mpa, "Beam material")
    if _positive(m.gamma_a1, "gamma_a1") != NORMAL_NBR_GAMMA_A1:
        raise ValueError("Normal NBR branch requires gamma_a1=1.1, not a custom resistance factor")
    plate_ids = {p.material_id for p in inputs.plate_materials}
    weld_ids = {w.material_id for w in inputs.weld_consumables}
    if weld_ids & (plate_ids | {beam.material.material_id}):
        raise ValueError("Beam/plate base metal and weld consumable cannot share a material identity")
    for p in inputs.plate_materials:
        # Recheck the physical dataclass even when this is called without the
        # serializer, and keep beam versus plate nominal strengths separate.
        StiffenerSteel(**asdict(p))
        if p.material_id == beam.material.material_id and (
                p.fy_mpa, p.fu_mpa, p.E_mpa) != (m.fy_mpa, m.fu_mpa, m.E_mpa):
            raise ValueError("One material identity cannot have different beam and plate nominal properties")
    densities = {}
    for material in (beam.material, *(s.pair.material for s in inputs.layout.stations),
                     *(s.web_fillet.material for s in inputs.layout.stations),
                     *(s.cjp.material for s in inputs.layout.stations)):
        previous = densities.setdefault(material.material_id, material.density_kg_m3)
        if previous != material.density_kg_m3:
            raise ValueError("One material identity cannot have conflicting physical densities")


def _station_candidate(beam, station, material, inventory, consumable):
    detail = assess_detail(beam, station)
    # Full contour can be credited without a composite E-weighted model only
    # when the specified refill is not weaker/softer than the plate. Missing
    # deposit properties are not inferred from a consumable name or fuw.
    compatible = (consumable.fyw_mpa is not None and consumable.E_mpa is not None
        and consumable.fyw_mpa >= material.fy_mpa
        and consumable.fuw_mpa >= material.fu_mpa
        and consumable.E_mpa == material.E_mpa)
    final_Is = detail.final_section_minimum_Is_mm4 if compatible else None
    adjacent = inventory.adjacent_panels(station.station_id)
    pair = station.pair
    panels = ()
    rectangular_Is = required = inertia_pass = None
    # There is deliberately no dummy length for a single physical station.
    if adjacent:
        scalar = paired_stiffener_prescriptive(
            outstand_mm=pair.outstand_mm, plate_thickness_mm=pair.thickness_mm,
            web_thickness_mm=beam.web_thickness_mm,
            clear_web_depth_mm=beam.clear_web_depth_8800_mm,
            E_MPa=material.E_mpa, fy_MPa=material.fy_mpa,
            panel_lengths_mm=tuple(r.physical_panel_spacing_mm for r in adjacent))
        c_over_t, limit, stockiness = scalar.c_over_t, scalar.c_over_t_limit, scalar.stockiness_pass
        rectangular_Is, required = scalar.Is_mm4, scalar.Irequired_mm4
        panels = tuple(AdjacentPanelCheck(
            r.region_id, r.left_station_id, r.right_station_id,
            p.panel_length_mm, p.aspect_ratio, p.j, p.Irequired_mm4,
            final_Is,
            final_Is is not None and final_Is >= p.Irequired_mm4)
            for r, p in zip(adjacent, scalar.panels))
        inertia_pass = all(p.inertia_pass for p in panels)
    else:
        # Same NBR scalar c/t inequality, evaluated without inventing a panel
        # merely to satisfy the paired kernel's real-adjacent-panel contract.
        c_over_t = pair.outstand_mm / pair.thickness_mm
        limit = .56 * sqrt(material.E_mpa / material.fy_mpa)
        stockiness = c_over_t <= limit
    pending = list(detail.pending)
    if not stockiness:
        pending.append("Actual plate maximum outstand/thickness exceeds its own material c/t limit")
    if not compatible:
        pending.append("CJP refill requires explicit deposit fy/E and fu not weaker than plate; no reconstruction strength inferred from consumable ID")
    if final_Is is None:
        pending.append("Final physical section Is is unavailable without specified compatible full CJP reconstruction")
    if not adjacent:
        pending.append("No adjacent real two-station panel: detail-only result, no invented endpoint or Irequired")
    elif not inertia_pass:
        pending.append("Final physical minimum section Is does not satisfy every adjacent real panel")
    sufficient = bool(adjacent and detail.design_requirements_satisfied and compatible and stockiness and inertia_pass)
    status = ("DETAIL_ONLY_NO_REAL_PANEL" if not adjacent else
              "GEOMETRY_PRESCRIPTIVE_CANDIDATE_SUFFICIENT" if sufficient else
              "GEOMETRY_PRESCRIPTIVE_CANDIDATE_NOT_SUFFICIENT")
    return StationPrescriptiveCandidate(station.station_id, station.x_mm, status,
        material, detail, c_over_t, limit, stockiness, rectangular_Is,
        final_Is, required, inertia_pass, panels,
        sufficient, compatible, tuple(pending) + COMPOSITOR_PENDING)


def assemble_prescriptive(project: TopWorkflowProject) -> PrescriptiveAssembly:
    """Regenerate candidate geometry/material results from the physical project.

    No argument can grant a station or select the candidate panel resistance.
    Callers must not reinterpret ``candidate_sufficient`` as an action, transfer,
    fatigue or complete-station result. Final composition must regenerate and
    combine those checks rather than trust a serialized approval bit.
    """
    from ..project import TopWorkflowProject
    from lro_beams.catalog import section_from_profile

    if type(project) is not TopWorkflowProject:
        raise TypeError("A typed physical TopWorkflowProject is required")
    project.validate()
    inputs = project.intermediates
    if type(inputs) is not IntermediateInputs:
        raise ValueError("Present typed physical intermediate inputs are required")
    inputs.validate_base_section(section_from_profile(project.section_catalog_id),
                                 project.structure.span_m * 1000.)
    _validate_material_identity(project, inputs)
    beam, m = inputs.layout.beam, project.material
    material_source = project.sources["material"]
    _text(material_source.source,"Receiving beam material source")
    beam_material = NominalMaterialAssessment(beam.material.material_id,
        "beam_receiver_from_workflow_project", m.fy_mpa, m.fu_mpa, m.E_mpa,
        m.specification, material_source.source, material_source.status)
    plates = {p.material_id: NominalMaterialAssessment(p.material_id,
        "physical_plate_from_own_inventory", p.fy_mpa, p.fu_mpa, p.E_mpa,
        p.grade, p.specification_source, "specified_nominal_material")
        for p in inputs.plate_materials}
    inventory = RegionInventory(project.structure.span_m * 1000., tuple(
        StationLine(s.station_id, s.x_mm)
        for s in sorted(inputs.layout.stations, key=lambda s: s.x_mm)))
    consumables = {c.material_id:c for c in inputs.weld_consumables}
    stations = tuple(_station_candidate(beam, s, plates[s.pair.material.material_id], inventory, consumables[s.cjp.material.material_id])
                     for s in sorted(inputs.layout.stations, key=lambda s: s.x_mm))
    by_station = {s.station_id: s for s in stations}
    steel = SteelShearInput(beam.depth_mm, beam.web_thickness_mm,
        beam.clear_web_depth_8800_mm, m.E_mpa, m.fy_mpa, m.gamma_a1)
    regions = []
    for region in inventory.regions():
        # Explicitly never pass the scalar eligibility switch. A local pass
        # has not established the sign/action/transfer/fatigue prerequisites.
        result = shear_resistance(steel, panel_length_mm=region.physical_panel_spacing_mm)
        is_panel = region.physical_panel_spacing_mm is not None
        endpoints = bool(is_panel and all(by_station[sid].geometry_prescriptive_candidate_sufficient
            for sid in (region.left_station_id, region.right_station_id)))
        pending = COMPOSITOR_PENDING
        if not is_panel:
            pending = ("Ordinary end region: support/fork is not a second transverse plate; retain bare kv=5.34",)
        elif not endpoints:
            pending = ("One or both real panel endpoints lack sufficient geometry/prescriptive candidate checks",) + pending
        regions.append(RegionShearCandidate(region, result.baseline_kv, result.baseline_VRd_N,
            result.candidate_kv, result.candidate_VRd_N, result.candidate_benefit_N,
            endpoints, result.kv, result.VRd_N, pending))
    has_panel = any(r.region.physical_panel_spacing_mm is not None for r in regions)
    sufficient = has_panel and all(s.geometry_prescriptive_candidate_sufficient for s in stations)
    status = ("DETAIL_ONLY_NO_REAL_PANEL" if not has_panel else
              "GEOMETRY_PRESCRIPTIVE_CANDIDATE_SUFFICIENT" if sufficient else
              "GEOMETRY_PRESCRIPTIVE_CANDIDATE_NOT_SUFFICIENT")
    signature_input = dict(schema=ASSEMBLY_SCHEMA, intermediate_inputs=inputs.to_dict(),
        beam_material=asdict(m), material_source=asdict(material_source),
        section_catalog_id=project.section_catalog_id, span_mm=inventory.span_mm)
    signature = sha256(json.dumps(signature_input, sort_keys=True, separators=(",", ":"),
                                 allow_nan=False).encode()).hexdigest()
    return PrescriptiveAssembly(status, signature, inputs.physical_geometry_hash(),
        inventory, beam_material, m.gamma_a1, stations, tuple(regions),
        all(s.detail.design_requirements_satisfied for s in stations), sufficient)


__all__ = ["assemble_prescriptive", "PrescriptiveAssembly", "StationPrescriptiveCandidate",
           "RegionShearCandidate", "AdjacentPanelCheck", "NominalMaterialAssessment"]
