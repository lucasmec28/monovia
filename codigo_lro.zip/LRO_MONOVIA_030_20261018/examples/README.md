# Exemplos demonstrativos

Todos os arquivos são fictícios e servem para verificar o funcionamento, não para selecionar uma talha ou liberar obra.

1. `01_exemplo_ilustrativo.json`: dois eixos, quatro rodas opostas, vão 6 m, seção I geométrica 400×200×10×16, capacidade e carga útil 2 t. As dimensões não representam um catálogo aprovado. A memória `01_memoria_ilustrativa.docx` mostra o resultado dessa entrada na revisão entregue, incluindo pendências. Recalcule ao alterar qualquer dado ou código.
2. `02_exemplo_fadiga_W0.json`: mesma geometria, com adoções didáticas de grupo de componente E5, material A36, detalhe W0 e envelope κ=−1. Esses valores não foram deduzidos de CMAA, capacidade ou uso real. Não adote no projeto sem a classificação e o detalhe correspondentes.
3. `03_exemplo_horizontal_diagnostico.json`: ação lateral ilustrativa de 0,1 kN no primeiro par. Demonstra o torque excêntrico e a separação de reações físicas. A resistência combinada permanece fora do fechamento da versão 0.1, conforme o relatório.

Importe somente os arquivos de entradas. A memória Word não é importada como cálculo, e JSON de resultados não é recibo aceito para autorizar outra sessão.

## Complemento EN independente

Importe os arquivos EN somente na página **Complemento EN**. As classificações e os coeficientes da página NBR não são transferidos. Todas as declarações de fabricante, aço, fabricação, tenacidade e vínculos abaixo são sintéticas e explicitamente identificadas, não comprovação de um projeto real.

11. `11_EN_preenchido.json`: exemplo preenchido, com quatro contatos inferiores, ações laterais nos dois sentidos, translação longitudinal, içamento e ensaios estático/dinâmico. Permite exercitar todos os mecanismos implementados, sem esconder campos obrigatórios. A memória `11_EN_memoria_preenchida.docx` distingue variantes completas de referências verticais parciais diagnósticas. Critérios atendidos nesse exemplo não significam aprovação de instalação, fadiga EN ou cobertura de todo evento possível.
12. `12_EN_reprovado.json`: mesma ideia de geometria, mas carga útil nominal de 500 kN, deliberadamente desfavorável. Demonstra falhas nominais testemunhadas e majorantes excedidos, com exportação preservada. Não é uma talha comercial nem uma recomendação de capacidade.
13. `13_EN_fora_dominio.json`: alma de 4 mm no perfil geométrico sintético, para demonstrar os limites resistentes da rota. Uma resposta mecânica calculável não transforma uma seção fora do domínio em PASS, nem significa que a seção falha por todos os mecanismos.
14. `14_EN_vinculo_axial_pendente.json`: exemplo básico sem adoção do vínculo axial. Os casos com força longitudinal permanecem registrados como não calculados. Outros casos e verificações calculáveis são preservados. Gere sua memória após calcular, sem importar aprovação pronta.

Os arquivos de evidência completos estão no ZIP de evidências separado. O aplicativo deve recalcular as entradas; não aceita esse JSON de evidência como um projeto ou autorização de cálculo.
