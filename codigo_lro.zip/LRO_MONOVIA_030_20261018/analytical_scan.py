"""Fast isolated monorail response orchestration, preserving analytical kernels.

Exact spatial critical locations are reused from autonomous_critical. Nested
translation refinement is ENGINEERING NUMERICAL evidence, not a continuum
interval enclosure or a normative qualification. No FE receipt is fabricated.
Initial domain: straight single span, end forks, no projections. Hx requires
explicit equal opposed-contact allocation and an axial shear-centre restraint.
"""
from dataclasses import asdict, dataclass, replace
from hashlib import sha256
from pathlib import Path
import math
import time

from monorail.analysis import Case, case_loads, digest, source_receipt
from monorail.model import MonorailProject
from lro_beams.geometry import section_properties
from lro_beams.moving_beam import solve_position, translate_train
from lro_beams.beam_torsion import VlasovBeam, LateralTorqueLoad, solve_lateral_torsion, thin_wall_i_torsion_properties
from lro_beams.autonomous_response import ConcurrentResponse, CaseFactors
from lro_beams.autonomous_critical import coupled_critical_positions


@dataclass(frozen=True)
class Controls:
    initial_divisions: int = 8
    max_refinements: int = 5
    relative_tolerance: float = .005
    stable_passes: int = 2

    def validate(self):
        for key,low,high in [('initial_divisions',2,64),('max_refinements',2,8),('stable_passes',2,4)]:
            v=getattr(self,key)
            if type(v) is not int or not low<=v<=high:raise ValueError(key+' outside supported range')
        if isinstance(self.relative_tolerance,bool) or not isinstance(self.relative_tolerance,(float,int)) or not .0001<=self.relative_tolerance<=.02:
            raise ValueError('relative_tolerance outside supported range')
        return self


@dataclass(frozen=True)
class AxialTransfer:
    """Explicit physical idealization, not inferred from the end-fork label."""
    equal_opposed_contacts_confirmed: bool
    left_axial_restraint_at_shear_center_confirmed: bool
    right_axial_free_confirmed: bool
    source: str

    def validate(self):
        for key in ('equal_opposed_contacts_confirmed','left_axial_restraint_at_shear_center_confirmed','right_axial_free_confirmed'):
            if type(getattr(self,key)) is not bool or not getattr(self,key):
                raise ValueError('Explicit axial premise required: '+key)
        if not isinstance(self.source,str) or not self.source.strip():
            raise ValueError('Physical source for axial-transfer idealization required')
        if any(ord(ch)<32 and ch not in '\n\r\t' for ch in self.source):
            raise ValueError('Invalid axial-transfer source text')
        return self


# Numerical absolute floors only for convergence near zero; never resistances.
FLOORS=dict(Mstrong_Nmm=.1,Mweak_Nmm=.1,Fvertical_N=1e-4,Flateral_N=1e-4,N_N=1e-4,
    vertical_mm=1e-8,horizontal_mm=1e-8,contact_horizontal_mm=1e-8,B_Nmm2=100.,Tsv_Nmm=.1,Tw_Nmm=.1,T_Nmm=.1,theta_rad=1e-11,contact_vertical_left_mm=1e-8,contact_vertical_right_mm=1e-8)


def _validate(project,case,axial_transfer=None):
    if not isinstance(project,MonorailProject) or not isinstance(case,Case):raise ValueError('Typed monorail and explicit Case required')
    project.validate()
    if axial_transfer is not None:
        if not isinstance(axial_transfer,AxialTransfer):raise ValueError('Typed AxialTransfer required')
        axial_transfer.validate()
    if any(s.longitudinal_kn for s in project.stations) and axial_transfer is None:
        raise ValueError('Hx requires explicit equal opposed contacts and axial restraint at shear centre; transport is not omitted')
    if project.section.fabrication!='rolled':raise ValueError('Initial canonical recovery domain is rolled parallel I')
    if not project.end_forks_confirmed:raise ValueError('Actual end fork premise must be explicitly adopted')
    for key in ('support_factor','equipment_factor','payload_factor','retained_factor','horizontal_factor','extra_factor'):
        value=getattr(case,key)
        if isinstance(value,bool) or not isinstance(value,(float,int)) or not math.isfinite(value) or value<0:raise ValueError('Invalid explicit case factor: '+key)
    if case.transverse_sign not in (-1,1) or case.longitudinal_sign not in (-1,1):raise ValueError('Signed case directions required')


def response_factory(project,case,*,axial_transfer=None):
    """Construct lower-contact concurrent states without top-rail adapters."""
    _validate(project,case,axial_transfer)
    beam,train,udl,ledger=case_loads(project,case)
    s=project.section;m=project.material
    tp=thin_wall_i_torsion_properties(s.d_mm,s.bf_mm,s.tf_mm,s.tw_mm)
    torsion_beam=VlasovBeam(project.span_m*1000,m.E_mpa,m.G_mpa,tp['J_mm4'],tp['Cw_mm6'])
    g=replace(section_properties(s),J_mm4=tp['J_mm4'],Cw_mm6=tp['Cw_mm6'])
    z=s.tf_mm-s.d_mm/2
    # Metadata only: all loads were already computed by the exact Case ledger.
    cf=CaseFactors(case.id,case.support_factor,case.equipment_factor,
        case.retained_factor if not case.nominal_payload_only else case.payload_factor,
        case.horizontal_factor,case.horizontal_factor,case.source,extra_dead=case.extra_factor)
    def response(translation_m):
        if not project.travel_min_m<=translation_m<=project.travel_max_m:raise ValueError('Translation outside physical travel')
        loads=translate_train(beam,train,translation_m)
        vertical=solve_position(beam,loads,udl)
        lateral_loads=tuple(LateralTorqueLoad(w.position_m*1000,w.horizontal_kn*1000,
            w.horizontal_kn*1000*z,w.name) for w in loads)
        lateral=solve_lateral_torsion(torsion_beam,g.Iy_mm4,lateral_loads)
        return ConcurrentResponse(case.id,translation_m,case.transverse_sign,case.longitudinal_sign,
            vertical,lateral,g,cf,z,longitudinal_transfer_basis=(
                'Equal physical Hx at opposed lower contacts: Mz/B cancel; My=Hx*z retained. Axial restraint at left shear centre; right axially free.'
                if axial_transfer else 'Hx=0 explicitly; no axial/sectorial action discarded'))
    return response,dict(wheel_ledger=ledger,uniform_load=asdict(udl),properties=asdict(g),
        torque_properties_source='Preserved thin_wall_i_torsion_properties; canonical flange-sectorial Cw chosen BEFORE solving',
        original_case_ledger=asdict(case),contact_height_mm=z,
        axial_transfer=None if axial_transfer is None else asdict(axial_transfer))


def contact_vertical_critical_positions(response, contact_y_mm):
    """Reuse the preserved polynomial-plus-Vlasov derivative root algorithm.

    This auxiliary object is ONLY a root-search adapter: the lateral polynomial
    is populated with the already solved strong-plane loads/I, retaining the
    same torsional solution. The observed scalar is v_down + y*theta_Green.
    No new physical load, support or response is inserted in the actual beam.
    """
    lat=response.lateral_torsion
    v=response.vertical
    auxiliary_loads=tuple(LateralTorqueLoad(w.position_m*1000,
        w.vertical_kn*1000,0.,w.name,minor_couple_nmm=w.major_moment_knm*1e6)
        for w in v.all_loads)
    auxiliary_lateral=replace(lat,Iy_mm4=response.properties.Ix_mm4,
        loads=auxiliary_loads,uniform_horizontal_n_per_mm=v.udl.vertical_kn_per_m,
        brace_reactions=())
    auxiliary_response=replace(response,lateral_torsion=auxiliary_lateral,
        rail_level_mm=contact_y_mm)
    return coupled_critical_positions(auxiliary_response)


def _state_with_contacts(response,project,x,side):
    state=response.at(x,side)
    y=project.section.bf_mm/2-project.edge_to_contact_mm
    theta=state['torsion']['theta_rad']
    state['contact_vertical_left_mm']=state['vertical_mm']-y*theta
    state['contact_vertical_right_mm']=state['vertical_mm']+y*theta
    return state


def metrics(state):
    t=state['torsion']
    return dict(Mstrong_Nmm=state['Mx_knm']*1e6,Mweak_Nmm=state['My_knm']*1e6,
        Fvertical_N=state['Vy_kn']*1000,Flateral_N=state['Vx_kn']*1000,N_N=state['N_kn']*1000,
        vertical_mm=state['vertical_mm'],horizontal_mm=state['horizontal_mm'],contact_horizontal_mm=state['rail_horizontal_mm'],
        B_Nmm2=t['bimoment_nmm2'],Tsv_Nmm=t['saint_venant_torque_nmm'],Tw_Nmm=t['warping_torque_nmm'],
        T_Nmm=t['total_torque_nmm'],theta_rad=t['theta_rad'],
        **{k:state[k] for k in ('contact_vertical_left_mm','contact_vertical_right_mm') if k in state})


def physical_reactions(response):
    v=response.vertical.reactions;l=response.lateral_torsion
    return dict(Rs_left_N=v.longitudinal_left_kn*1000,Rs_right_N=v.longitudinal_right_kn*1000,
        Ry_left_N=l.horizontal_support_reactions_n[0],Ry_right_N=l.horizontal_support_reactions_n[1],
        Rz_left_N=v.vertical_left_kn*1000,Rz_right_N=v.vertical_right_kn*1000,
        Ms_left_Nmm=-l.torsion.support_torques_nmm[0],Ms_right_Nmm=-l.torsion.support_torques_nmm[1])


def translation_grid(project,divisions):
    a,b=project.travel_min_m,project.travel_max_m
    anchors={a,b}
    # All actual wheel events at supports/midspan within the declared travel.
    for wheel in project.stations:
        for x in (0.,project.span_m/2,project.span_m):
            q=x-wheel.offset_m
            if a<=q<=b:anchors.add(q)
    return tuple(sorted(anchors|{a+(b-a)*i/divisions for i in range(divisions+1)}))


def _record(extrema,key,value,translation,x,side):
    pair=extrema.setdefault(key,{})
    for mode in ('min','max'):
        old=pair.get(mode)
        if old is None or (value<old['value'] if mode=='min' else value>old['value']):
            pair[mode]=dict(value=value,translation_m=translation,position_m=x,side=side)


def _dependency_identity():
    return dict(preserved_and_baseline_fingerprint=source_receipt()['fingerprint'],
        orchestration_sha256=sha256(Path(__file__).read_bytes()).hexdigest())


def scan_case(project,case,controls=Controls(),progress=None,*,axial_transfer=None):
    """Return extrema, actual wheel-cut states and an honest numerical receipt."""
    controls.validate();factory,metadata=response_factory(project,case,axial_transfer=axial_transfer)
    return _scan_factory(project,case,factory,metadata,controls,progress)


def _scan_factory(project,case,factory,metadata,controls=Controls(),progress=None,*,source_guard=None):
    """Internal mechanical orchestration; action adapters must validate first.

    This function never qualifies an action basis. A non-NBR producer supplies
    an independent guard that is evaluated before and after the mechanical
    calculation. No imported status or factor aliases authorize resistance.
    """
    controls.validate();project.validate()
    sig=project.signature();deps=_dependency_identity();started=time.monotonic()
    case_data=asdict(case);input_identity=digest(dict(case=case_data,metadata=metadata))
    external_identity=source_guard() if source_guard is not None else None
    cache={};maxima={};reactions={};history=[];stable=0;previous=None
    max_residual=0.;evaluations=0
    for level in range(controls.max_refinements+1):
        translations=translation_grid(project,controls.initial_divisions*2**level)
        if progress:progress(dict(stage='refinement',level=level,translations=len(translations)))
        for a in translations:
            if a in cache:continue
            r=factory(a)
            positions=set(r.vertical.critical_positions())|set(coupled_critical_positions(r))
            contact_y=project.section.bf_mm/2-project.edge_to_contact_mm
            for y in (-contact_y,contact_y):positions.update(contact_vertical_critical_positions(r,y))
            jumps={w.position_m for w in r.vertical.all_loads}
            positions.update(jumps);positions.update((0.,project.span_m))
            rows=[];wheel_rows=[]
            for x in sorted(positions):
                sides=('right',) if x==0 else ('left',) if x==project.span_m else ('left','right') if x in jumps else ('right',)
                for side in sides:
                    state=_state_with_contacts(r,project,x,side);evaluations+=1
                    for key,value in metrics(state).items():_record(maxima,key,value,a,x,side)
                    if x in jumps:
                        station=next(s for s in project.stations if a+s.offset_m==x)
                        wheel_rows.append(dict(station_id=station.id,translation_m=a,state=state))
                    rows.append(state)
            pr=physical_reactions(r)
            for key,value in pr.items():_record(reactions,key,value,a,None,None)
            torsion=r.lateral_torsion.torsion
            residuals=(pr['Rz_left_N']+pr['Rz_right_N']-sum(w.vertical_kn*1000 for w in r.vertical.all_loads)-r.vertical.udl.vertical_kn_per_m*project.span_m*1000,
                pr['Ry_left_N']+pr['Ry_right_N']+sum(w.horizontal_kn*1000 for w in r.vertical.all_loads),
                pr['Ms_left_Nmm']+pr['Ms_right_Nmm']-sum(q.torque_nmm for q in torsion.point_torques),
                pr['Rs_left_N']+pr['Rs_right_N']+sum(w.longitudinal_kn*1000 for w in r.vertical.all_loads),
                -pr['Rz_right_N']*project.span_m*1000+sum(w.vertical_kn*1000*w.position_m*1000+w.major_moment_knm*1e6 for w in r.vertical.all_loads)+r.vertical.udl.vertical_kn_per_m*project.span_m*1000*project.span_m*500,
                pr['Ry_right_N']*project.span_m*1000+sum(w.horizontal_kn*1000*w.position_m*1000+w.minor_moment_knm*1e6 for w in r.vertical.all_loads))
            max_residual=max(max_residual,*map(abs,residuals))
            cache[a]=dict(wheel_rows=wheel_rows,physical_support_on_beam=pr,physical_beam_on_support={k:-v for k,v in pr.items()})
        current={key:{mode:v['value'] for mode,v in pair.items()} for key,pair in maxima.items()}
        current.update({key:{mode:v['value'] for mode,v in pair.items()} for key,pair in reactions.items()})
        change=None
        if previous is not None:
            change=max(abs(value-previous[key][mode])/max(abs(value),abs(previous[key][mode]),FLOORS.get(key,.1 if 'Nmm' in key else 1e-4))
                for key,pair in current.items() for mode,value in pair.items())
            stable=stable+1 if change<=controls.relative_tolerance else 0
        history.append(dict(level=level,translations=len(translations),unique_translations=len(cache),relative_change=change,stable_passes=stable))
        previous=current
        if stable>=controls.stable_passes:break
    if sig!=project.signature() or deps!=_dependency_identity() or input_identity!=digest(dict(case=asdict(case),metadata=metadata)):
        raise ValueError('Project, actions or source changed during calculation')
    if source_guard is not None and external_identity!=source_guard():raise ValueError('External action source changed during calculation')
    converged=stable>=controls.stable_passes
    result=dict(method='preserved analytical spatial roots plus nested physical-translation refinement',
        evidence_kind='analytical_space_nested_translation_converged' if converged else 'not_established',
        numerical_converged=converged,continuum_upper_bound_claimed=False,fixed_FE_receipt_claimed=False,
        action_basis_qualified_by_scanner=False,member_stability_qualified=False,whole_design_approved=False,
        project_signature=sig,case=case_data,controls=asdict(controls),dependencies=deps,metadata=metadata,
        external_source_identity=external_identity,mechanical_input_identity=input_identity,
        spatial_root_coordinate_tolerance_mm=max(1e-6,1e-9*project.span_m*1000),
        root_search_source='Preserved autonomous_critical.coupled_critical_positions; vertical contacts reuse same derivative chain with polynomial-plane adapter.',
        contact_vertical_definition='Downward contact displacement = centroidal downward displacement + y*theta_Green; y positive right in section.',
        extrema=maxima,physical_reaction_extrema=reactions,history=history,
        sampled_wheel_states=[row for a in sorted(cache) for row in cache[a]['wheel_rows']],
        reaction_states=[dict(translation_m=a,**{k:v for k,v in cache[a].items() if k!='wheel_rows'}) for a in sorted(cache)],
        max_equilibrium_residual=max_residual,section_evaluations=evaluations,translations=len(cache),seconds=time.monotonic()-started,
        limitations=['Equal opposed vertical wheels; Hx zero unless explicit equal-contact allocation and left shear-centre axial restraint are adopted; one span; end forks; free warping; no physical intermediate supports or projections.',
            'Registered nominal restraints do not alter this response. Resistance and actual restraint detailing remain separate.',
            'Cw uses the canonical flange-sectorial model and differs deliberately from the legacy total-Iy approximation.',
            'Exact spatial component extrema reuse the analytical kernel; translation convergence is numerical, not a certified global upper enclosure.',
            'Convergence of component extrema does not by itself qualify nonlinear local-observer extrema or a fatigue history.'])
    mapping={'N':('N_N',1),'My':('Mstrong_Nmm',-1),'Mz':('Mweak_Nmm',-1),
        'B':('B_Nmm2',-1),'Fy':('Flateral_N',1),'Fz':('Fvertical_N',-1),
        'Tsv':('Tsv_Nmm',-1),'Tw_equilibrated':('Tw_Nmm',-1)}
    result['right_hand_resultant_intervals']={name:dict(
        lower=maxima[key]['min' if sign>0 else 'max']['value']*sign,
        upper=maxima[key]['max' if sign>0 else 'min']['value']*sign,
        source_component=key,sign_multiplier=sign) for name,(key,sign) in mapping.items()}
    result['result_signature']=digest(result)
    return result



def assert_scan_current(project,result,case=None,*,source_guard=None):
    """Reject stale or mutated mechanics before a resistance/export consumer."""
    if not isinstance(result,dict) or 'result_signature' not in result:
        raise ValueError('Owned numerical response result required')
    payload={k:v for k,v in result.items() if k!='result_signature'}
    if digest(payload)!=result['result_signature']:raise ValueError('Numerical response was changed after calculation')
    if project.signature()!=result.get('project_signature') or _dependency_identity()!=result.get('dependencies'):
        raise ValueError('Mechanical project or source changed after calculation')
    if case is not None and asdict(case)!=result.get('case'):raise ValueError('Different action case')
    if digest(dict(case=result['case'],metadata=result['metadata']))!=result.get('mechanical_input_identity'):
        raise ValueError('Different mechanical action ledger')
    external=result.get('external_source_identity')
    if external is not None and source_guard is None:
        raise ValueError('Independent action-source guard required for this result')
    if source_guard is not None and source_guard()!=external:
        raise ValueError('External action source differs from calculated source')
    return result
