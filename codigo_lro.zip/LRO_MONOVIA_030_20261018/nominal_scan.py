"""Nominal NBR fatigue mechanisms from genuine analytical FAT8400 receipts.

This is independent of EN C.2 and never transforms EN/ULS actions into fatigue.
A complete set of regenerated FAT8400 cases is required. Signed component boxes
cover each fixed nominal point conservatively; no temporal history is created.
"""
from dataclasses import asdict, dataclass
from hashlib import sha256
from pathlib import Path
import math

from monorail.analysis import generate_cases,digest
from analytical_scan import assert_scan_current,response_factory,AxialTransfer
from prototype import fatigue_nominal_prototype,canonical_section
from underslung_runway_candidate.section_stress.recovery import bottom_contact
from underslung_runway_candidate.fatigue.nbr_member import ACTION_BASIS


@dataclass(frozen=True)
class NumericalAcceptance:
    maximum_relative_tolerance: float
    source: str

    def validate(self):
        value=self.maximum_relative_tolerance
        if isinstance(value,bool) or not isinstance(value,(int,float)):
            raise ValueError('Explicit finite numerical acceptance tolerance required')
        try:value=float(value)
        except (ValueError,OverflowError) as exc:raise ValueError('Invalid numerical acceptance tolerance') from exc
        if not math.isfinite(value) or not .0001<=value<=.02:raise ValueError('Numerical acceptance tolerance outside supported range')
        if not isinstance(self.source,str) or not self.source.strip():raise ValueError('Documented numerical acceptance required')
        return self


def _owned_fatigue_scans(project,scans,acceptance):
    project.validate();acceptance.validate()
    expected={c.id:c for c in generate_cases(project) if c.family=='FAT8400'}
    actual={s['case']['id']:s for s in scans}
    if len(actual)!=len(scans) or set(actual)!=set(expected):
        raise ValueError('Exactly all regenerated FAT8400 cases required, including loaded/empty and every prescribed horizontal direction')
    pending=[];receipts=[]
    for id_,case in expected.items():
        scan=actual[id_];assert_scan_current(project,scan,case)
        raw=scan['metadata'].get('axial_transfer');axial=None if raw is None else AxialTransfer(**raw)
        _,metadata=response_factory(project,case,axial_transfer=axial)
        if metadata!=scan['metadata']:raise ValueError('Fatigue mechanical load/section ledger differs from regenerated actions')
        if scan['evidence_kind']!='analytical_space_nested_translation_converged' or scan['numerical_converged'] is not True:
            pending.append(id_+': numerical translation refinement is not converged')
        if scan['fixed_FE_receipt_claimed'] is not False or scan['continuum_upper_bound_claimed'] is not False:
            raise ValueError('Analytical receipt cannot be an FE certificate or continuum enclosure')
        if scan['controls']['relative_tolerance']>acceptance.maximum_relative_tolerance:
            pending.append(id_+': numerical tolerance exceeds the declared engineering acceptance')
        if not scan['history'] or scan['history'][-1]['stable_passes']<2:
            pending.append(id_+': at least two stable nested passes required')
        receipts.append(dict(case=asdict(case),signature=scan['result_signature'],controls=scan['controls'],history=scan['history'],
            dependencies=scan['dependencies'],root_coordinate_tolerance_mm=scan['spatial_root_coordinate_tolerance_mm']))
    return expected,actual,pending,receipts


def evaluate_nbr_fatigue_scans(project,scans,*,material,duty,detail,method,acceptance):
    """Return individual nominal planar results, not a whole-member approval.

    Material/group/detail/kappa policy are inherited typed inputs. A failed
    sufficient box is BOUND_EXCEEDED, never a physical fatigue failure. The
    ordinary web remains PENDING when its retained Fy shear makes it nonplanar.
    Lower close-wheel/end/root/contact domains are never silently extended.
    """
    consumer_identity={Path(path).name:sha256(Path(path).read_bytes()).hexdigest() for path in (__file__,str(Path(__file__).with_name('prototype.py')))}
    if not isinstance(acceptance,NumericalAcceptance):raise ValueError('Typed NumericalAcceptance required')
    cases,actual,pending,receipts=_owned_fatigue_scans(project,scans,acceptance)
    fields={'N':'N','My':'My','Mz':'Mz','B_equilibrated':'B','Fy':'Fy','Fz':'Fz','Tsv':'Tsv','Tw_equilibrated':'Tw_equilibrated'}
    bounds={name:dict(lower=min(s['right_hand_resultant_intervals'][key]['lower'] for s in scans),
                     upper=max(s['right_hand_resultant_intervals'][key]['upper'] for s in scans)) for name,key in fields.items()}
    section=canonical_section(project);wheels=[]
    for station in project.stations:
        actions=[]
        for scan in scans:
            row=next(row for row in scan['metadata']['wheel_ledger'] if row['station_id']==station.id)
            actions.append(row['individual_wheel_kn']*1000)
        for side in ('left','right'):
            c=bottom_contact(section,project.edge_to_contact_mm,side)
            wheels.append(dict(id=station.id+'/'+side,offset_mm=station.offset_m*1000,
                y_mm=c['y_mm'],z_mm=c['z_mm'],omega_mm2=c['omega_mm2'],
                downward_N=dict(lower=min(actions),upper=max(actions))))
    end=min(min(project.travel_min_m+s.offset_m,project.span_m-project.travel_max_m-s.offset_m) for s in project.stations)*1000
    raw=fatigue_nominal_prototype(project,resultant_bounds=bounds,wheel_vertical_actions=wheels,
        minimum_distance_to_physical_end_mm=end,action_basis=ACTION_BASIS,
        action_source='Exact regenerated FAT8400 cases: '+', '.join(cases),
        factors_source='; '.join(sorted({c.source+'; '+c.formula for c in cases.values()})),
        bounds_source='Signed union of all genuine FAT8400 analytical spatial-extrema/nested-translation receipts; numerical engineering convergence, not a mathematical continuum enclosure',
        nominal_model_source='Preserved three-rectangle/Vlasov recovery; canonical J/Cw selected before every scan; nominal ordinary walls and source-prescribed P0/P1/P2 faces only',
        material=material,duty=duty,detail=detail,method=method)
    checks=[]
    for plane,diagnostic in zip(raw['planes'],raw['conditional_kernel_diagnostics']):
        bound=diagnostic.get('bound')
        local_pending=list(pending)+list(diagnostic.get('pending',[]))+list(diagnostic.get('errors',[]))
        status='PENDING' if local_pending or not bound else ('PASS' if bound['sufficient_bound_satisfied'] else 'BOUND_EXCEEDED')
        checks.append(dict(id='nbr_fatigue/'+plane.region_id+'/'+plane.point_id+'/'+plane.face,status=status,
            region=plane.region_id,point_id=plane.point_id,face=plane.face,plane=plane.plane,
            utilization=bound['combined_utilization_upper_bound'] if bound else None,
            reasons=local_pending,evidence='component_box_over_complete_numerically_converged_FAT8400_cases',
            source=diagnostic['source_contract']['standard']+'; '+diagnostic['source_contract']['interaction'],
            formula=bound['formula'] if bound else None,capacity=1. if bound else None,unit='1',kernel_result=diagnostic,
            actual_failure_proven=False,created_temporal_histories=0,whole_design_approved=False))
    if raw['local_receipt'] is None:
        checks.append(dict(id='nbr_fatigue/lower_local_domain',status='PENDING',
            source='ABNT NBR10084:2020 section9.1.4; ABNT NBR8400-2:2019 AnnexD',
            reasons=[x for x in raw['pending'] if x.startswith('Lower-flange nominal fatigue domain')],
            actual_failure_proven=False,whole_design_approved=False))
    _owned_fatigue_scans(project,scans,acceptance)
    if consumer_identity!={Path(path).name:sha256(Path(path).read_bytes()).hexdigest() for path in (__file__,str(Path(__file__).with_name('prototype.py')))}:
        raise ValueError('Nominal fatigue consumer changed during evaluation')
    result=dict(kind='NBR_nominal_fatigue_from_analytical_scan',checks=checks,
        mechanical_source_qualified=not pending,all_generated_fatigue_cases_included=True,
        equipment_action_coverage_qualified=False,physical_input_sources_independently_verified=False,
        numerical_acceptance=asdict(acceptance),mechanical_receipts=receipts,
        resultant_intervals=bounds,physical_wheel_intervals=wheels,minimum_physical_end_distance_mm=end,
        global_nominal_receipt=raw['global_receipt'],local_nominal_receipt=raw['local_receipt'],
        web_out_of_plane_tau_xy_bound_mpa=raw['web_out_of_plane_tau_xy_bound_mpa'],
        planes=[asdict(p) for p in raw['planes']],created_temporal_histories=0,
        continuum_upper_bound_claimed=False,whole_design_approved=False,
        stability_qualified=False,contact_root_fatigue_qualified=False,
        pending=pending+['Generated FAT8400 cases cover the declared equipment actions only; normal guidance/rolling reactions and equipment-wide action completeness require separate physical-source review.',
            'First-order elastic mechanics is the adopted response model; these fatigue checks do not establish second-order/member-stability adequacy.',
            'Actual root/contact/disturbed connection fatigue remains outside this nominal model.',
            'Planar component results do not qualify stability or the entire member.'],
        source_dependencies=consumer_identity)
    result['result_signature']=digest(result)
    return result
