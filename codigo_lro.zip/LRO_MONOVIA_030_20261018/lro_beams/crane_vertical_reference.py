"""Bounded vertical-only screening; no physical G/Q reconstruction.

For a straight one-span simply supported Euler-Bernoulli beam, downward wheel
forces in [0,Pmax] and fixed actual wheel offsets, all-Pmax pointwise dominates
major moment and vertical displacement. Although it does NOT pointwise dominate
signed shear, V decreases between RA and -RB; the global absolute shear is bounded
by maximum support reaction. Each reaction has nonnegative wheel influence.
This proves the three scalar bounds for the relaxed independent-wheel load set.
It does NOT prove torsion, lateral restraint actions, combined stress, buckling,
fatigue, local resistance, or a whole-crane load qualification. Source Pmax must
bound the total static wheel force for the optional factor scenarios to apply.
"""
from __future__ import annotations
import math
from .moving_beam import BeamModel, MovingWheel, scan_moving_train, SearchTolerance
from .autonomous_actions import DYNAMIC_SOURCE, MX_SOURCE, ULS_SOURCE, SLS_SOURCE


def _positive(value, label):
    if isinstance(value,bool) or not isinstance(value,(float,int)) or not math.isfinite(value) or value <= 0:
        raise ValueError(label+' deve ser positivo e finito.')
    return float(value)


def vertical_catalog_screen(record, *, support_span_m, E_mpa, Ix_mm4,
                            numerical_relative_tolerance=.02, max_refinements=6):
    """Return total-wheel-only demand evidence, never a structural pass.

    The existing beam solver supplies conservative discretization bounds, which
    remain valid if target convergence is not reached. Source/model uncertainty
    is distinct from numerical error. No catalogue geometry is interpolated.
    """
    L=_positive(support_span_m,'Vão entre apoios')
    E=_positive(E_mpa,'Módulo de elasticidade');I=_positive(Ix_mm4,'Inércia major')
    P=_positive(record.get('pmax_kN'),'Carga total máxima publicada por roda')
    d=_positive(record.get('wheelbase_m'),'Entre-eixos real do registro')
    if record.get('wheels_per_rail') != 2:
        raise ValueError('Triagem implementada somente para duas rodas por caminho com entre-eixos documentado.')
    if not record.get('record_id') or not record.get('source_url'):
        raise ValueError('Identificação e fonte do registro são obrigatórias.')
    rel=_positive(numerical_relative_tolerance,'Tolerância de busca')
    beam=BeamModel(L,E,I,I)
    wheels=(MovingWheel(0.,P),MovingWheel(d,P))
    scan=scan_moving_train(beam,wheels,initial_intervals=24,max_refinements=max_refinements,
                           tolerance=SearchTolerance(relative=rel))
    # Independently derived exact whole-passage two-equal-wheel suprema.
    reaction=P*(2-d/L) if d<L else P
    two_moment=P*(2*L-d)**2/(8*L) if d <= 2*L/3 else 0.
    moment=max(P*L/4,two_moment)
    oracle_tolerance=1e-8*max(1.,reaction,moment)
    if abs(scan.maximum('Vy_kn').upper_bound-reaction)>oracle_tolerance:
        raise ArithmeticError('Cortante do motor diverge do oráculo independente de duas rodas.')
    if not scan.maximum('Mx_knm').absolute_value-oracle_tolerance <= moment <= scan.maximum('Mx_knm').upper_bound+oracle_tolerance:
        raise ArithmeticError('Momento do motor não contém o oráculo independente de duas rodas.')
    disp=scan.maximum('vertical_mm')
    qualified=record.get('pmax_unfactored_static_confirmed') is True
    result=dict(record_id=record['record_id'],source_url=record['source_url'],
        source_pdf_page=record.get('source_pdf_page'),source_bridge_span_m=record.get('bridge_span_m'),
        support_span_m=L,wheelbase_m=d,wheels_per_rail=2,published_total_pmax_kn=P,
        load_basis='total_wheel_action_not_physical_G_Q',
        source_static_basis_confirmed=qualified,source_declares_static=qualified or record.get('pmax_static_confirmed') is True,
        source_variant_applicability_confirmed=qualified,dynamic_basis=record.get('dynamic_basis','not specified'),
        numerical_search_converged=scan.converged,
        numerical_relative_tolerance=rel,translation_samples=len(scan.samples),
        vertical_crane_only_demand=dict(reaction_max_kn=reaction,global_shear_abs_upper_kn=reaction,
            major_moment_max_knm=moment,vertical_deflection_sample_mm=disp.absolute_value,
            vertical_deflection_upper_mm=disp.upper_bound,
            vertical_deflection_error_bound_mm=disp.discretization_error_bound),
        full_compliance=False,status='TRIAGEM VERTICAL PRELIMINAR',
        scope=('Somente ações verticais da ponte: máximo global de momento major, reação/cortante e flecha incremental da viga biapoiada.',
               'O peso próprio da viga, trilho, enrijecedores e outros permanentes do suporte não está incluído nesta comparação.',
               'Pmax é ação TOTAL equivalente de cada roda. Não representa massa zero da ponte, carga içada isolada nem repartição G/Q.',
               'A caixa 0 ≤ Pi ≤ Pmax relaxa a correlação física entre rodas; os máximos são limites de resposta, não um estado simultâneo de equilíbrio de toda a ponte.',
               'A prova não se estende a torção, restrições laterais, estabilidade, fadiga, interação de tensões, soldas, trilho, enrijecedores ou efeitos locais.',
               'A geometria é a do registro escolhido. O envelope de vários registros cobre somente esses registros, não configurações interpoladas ou outros fabricantes.',
               'Não usar estes máximos escalares separados como esforços concomitantes em uma interação.'),
        factor_scenarios=[])
    # These scale TOTAL wheel force; do not dilute tare in ELS. They are only
    # conditional mathematical bounds and do not certify source load meaning.
    for key,label,scale,condition in (
        ('published','Ação total publicada, sem nova amplificação',1.,'Cenário numérico do valor publicado; definição dinâmica do catálogo continua pendente se ausente.'),
        ('service_static_total','ELS vertical: 100% do total estático',1.,'Requer que Pmax limite a ação estática total de cada roda; não aplicar ψ de combinação reduzindo o peso da ponte.'),
        ('case_i_total_bound','Limite vertical caso I: 1,20 × 2,22 × Ptotal',1.2*2.22,'Condicional a Pmax ≥ G+Q estático, G/Q não negativos e dinâmica normal dentro das classes HC/HD implementadas; exclui eventos específicos.'),
        ('uls_total_bound','Limite vertical ELU: 1,50 × 2,22 × Ptotal',1.5*2.22,'Condicional a Pmax ≥ G+Q estático e coeficientes γG≤1,50, γQ≤1,50, Ψ≤2,22; não é determinação de G/Q.'),
    ):
        result['factor_scenarios'].append(dict(id=key,label=label,total_wheel_multiplier=scale,
            source_basis_qualified=qualified,condition=condition,
            factor_source=(DYNAMIC_SOURCE+'; '+MX_SOURCE if key=='case_i_total_bound' else
                           DYNAMIC_SOURCE+'; '+ULS_SOURCE if key=='uls_total_bound' else
                           'NBR10084:2020, seção10; '+SLS_SOURCE if key=='service_static_total' else record['source_url']),
            reaction_max_kn=reaction*scale,major_moment_max_knm=moment*scale,
            vertical_deflection_upper_mm=disp.upper_bound*scale))
    if not qualified:
        result['source_pending']=('O catálogo identifica Pmax estático para a família, mas sua correspondência com esta opção de talha não está demonstrada. Os cenários amplificados são sensibilidades condicionais, não um limite comprovado da ponte real.'
            if record.get('pmax_static_confirmed') is True else
            'O catálogo não confirma se Pmax é estático sem fatores. Os cenários amplificados são sensibilidades condicionais, não um limite comprovado da ponte real.')
    return result
