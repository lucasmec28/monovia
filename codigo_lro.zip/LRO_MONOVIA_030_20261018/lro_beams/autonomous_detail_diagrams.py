"""Read-only, dynamic dimensional guide for the legacy input editor.

This module draws the user's data, not a design proposal. Coordinates of the
main elevation are affine in longitudinal x. A transverse cut never represents
longitudinal plate thickness: t is dimensioned only in the x-y plan detail.
No analysis, correction, Streamlit state access or project mutation occurs.
"""
from __future__ import annotations

from html import escape
import math
from numbers import Real
from typing import Mapping

__all__ = ["render_detail_diagrams", "build_detail_diagrams", "diagram_geometry"]

INK = "#19334a"
MUTED = "#52677a"
STEEL = "#dce5ed"
STEEL_EDGE = "#688297"
PLATE = "#f6b657"
PLATE_EDGE = "#a46000"
WELD = "#007b86"
SUPPORT = "#8ac8d0"
DANGER = "#b9382c"
FULL_HEIGHT = {"paired_full_height_uniform", "paired_full_height_supports"}


def _get(obj, name, default=None):
    return obj.get(name, default) if isinstance(obj, Mapping) else getattr(obj, name, default)


def _number(value, *, zero=False):
    if isinstance(value, bool) or not isinstance(value, Real):
        return None
    try:
        value = float(value)
    except (OverflowError, ValueError):
        return None
    if not math.isfinite(value) or value < 0 or (not zero and value == 0):
        return None
    return value


def _fmt(value):
    if value is None:
        return "inválido"
    if value != 0 and (abs(value) < .01 or abs(value) >= 1e7):
        return f"{value:.4g}".replace(".", ",")
    return f"{value:.2f}".replace(".", ",")


def diagram_geometry(p):
    """Return sanitized display metadata without changing any incoming value.

    Pair stations reproduce autonomous_local.stiffener_positions_mm for its
    supported domain, including the last shorter bay. Invalid meshes are not
    replaced with a plausible-but-invented uniform arrangement.
    """
    names = ("span_m", "stiffener_spacing_m", "stiffener_thickness_mm",
             "support_bearing_length_mm", "beam_end_left_mm", "beam_end_right_mm",
             "stiffener_outstand_mm")
    values = {name: _number(_get(p, name), zero=name.startswith("beam_end_")) for name in names}
    invalid = [name for name, value in values.items() if value is None]
    section = _get(p, "section", {})
    s = {name: _number(_get(section, name)) for name in ("d_mm", "bf_mm", "tf_mm", "tw_mm")}
    # Section's public properties preserve the legacy zero-as-top convention.
    s["bottom_width"] = _number(_get(section, "bottom_width", _get(section, "bottom_bf_mm") or _get(section, "bf_mm")))
    s["bottom_thickness"] = _number(_get(section, "bottom_thickness", _get(section, "bottom_tf_mm") or _get(section, "tf_mm")))
    section_valid = all(v is not None for v in s.values())
    if section_valid:
        section_valid = (s["d_mm"] > s["tf_mm"] + s["bottom_thickness"] and
                         min(s["bf_mm"], s["bottom_width"]) > s["tw_mm"])
    layout = _get(p, "stiffener_layout", "none_or_unknown")
    connection = _get(p, "stiffener_connection", "other_or_unknown")
    span = values["span_m"]
    length = span * 1000 if span is not None else None
    if length is not None and not math.isfinite(length):
        length = None
        invalid.append("span_m")
    positions = ()
    position_issue = ""
    if layout in FULL_HEIGHT and length is not None:
        if layout == "paired_full_height_supports":
            positions = (0.0, length)
        else:
            spacing = values["stiffener_spacing_m"]
            pitch = spacing * 1000 if spacing is not None else None
            ratio = length / pitch if pitch and math.isfinite(pitch) else math.inf
            if not math.isfinite(ratio) or ratio > 10000:
                position_issue = "Malha não desenhada: espaçamento inválido ou mais de 10.000 painéis."
            else:
                positions = tuple([0.0] + [i * pitch for i in range(1, math.ceil(ratio))] + [length])
    elif layout in FULL_HEIGHT:
        position_issue = "Posições não desenhadas: informe um vão positivo e finito."
    if layout not in FULL_HEIGHT:
        position_issue = "Sem enrijecedores ou disposição desconhecida: nenhuma chapa presumida."
    physical = None
    left, right = values["beam_end_left_mm"], values["beam_end_right_mm"]
    if length is not None and left is not None and right is not None:
        extent = length + left + right
        if math.isfinite(extent) and extent > 0:
            physical = (-left, length + right)
    bearing = values["support_bearing_length_mm"]
    contact_known = _get(p, "support_contact", "other_or_unknown") == "centered_under_web"
    footprints = ()
    if contact_known and length is not None and bearing is not None:
        footprints = ((-bearing / 2, bearing / 2), (length - bearing / 2, length + bearing / 2))
    outstand = values["stiffener_outstand_mm"]
    valid_plate = layout in FULL_HEIGHT and outstand is not None and values["stiffener_thickness_mm"] is not None
    if valid_plate:
        # A finite imported scalar can still overflow intermediate display
        # extents. Omit that geometry rather than emitting NaN SVG coordinates.
        valid_plate = (math.isfinite(6 * values["stiffener_thickness_mm"]) and
                       math.isfinite((s["tw_mm"] or 0) + 2 * outstand))
    overflow = bool(section_valid and outstand is not None and
                    outstand > (min(s["bf_mm"], s["bottom_width"]) - s["tw_mm"]) / 2)
    return {"values": values, "section": s, "section_valid": section_valid,
            "layout": layout, "connection": connection, "length_mm": length,
            "pair_positions_mm": positions, "position_issue": position_issue,
            "physical_limits_mm": physical, "bearing_footprints_mm": footprints,
            "contact_known": contact_known, "plate_valid": valid_plate,
            "outstand_overflow": overflow, "invalid_fields": tuple(dict.fromkeys(invalid))}


class _SVG:
    def __init__(self, title, height):
        self.height = height
        self.parts = [f'<svg xmlns="http://www.w3.org/2000/svg" width="1120" height="{height}" viewBox="0 0 1120 {height}" role="img" aria-label="{escape(title)}">',
            '<defs><marker id="arrow" markerWidth="7" markerHeight="7" refX="3.5" refY="3.5" orient="auto-start-reverse" markerUnits="strokeWidth"><path d="M0,0 L7,3.5 L0,7 Z" fill="#19334a"/></marker></defs>',
            '<rect x="1" y="1" width="1118" height="%s" rx="14" fill="#ffffff" stroke="#d8e2e9"/>' % (height - 2)]
        self.text(26, 34, title, size=20, bold=True)

    def text(self, x, y, value, *, size=17, color=INK, anchor="start", bold=False, **data):
        attrs = " ".join(f'data-{k.replace("_", "-")}="{escape(str(v))}"' for k, v in data.items())
        self.parts.append(f'<text x="{x:.3f}" y="{y:.3f}" font-family="DejaVu Sans,Arial,sans-serif" font-size="{size}" fill="{color}" text-anchor="{anchor}" font-weight="{700 if bold else 400}" {attrs}>{escape(str(value))}</text>')

    def line(self, x1, y1, x2, y2, *, color=INK, width=1.6, dash=None, arrow=False, **data):
        attrs = " ".join(f'data-{k.replace("_", "-")}="{escape(str(v))}"' for k, v in data.items())
        self.parts.append(f'<line x1="{x1:.6f}" y1="{y1:.6f}" x2="{x2:.6f}" y2="{y2:.6f}" stroke="{color}" stroke-width="{width}"' + (f' stroke-dasharray="{dash}"' if dash else '') + (' marker-start="url(#arrow)" marker-end="url(#arrow)"' if arrow else '') + f' {attrs}/>')

    def rect(self, x, y, w, h, *, fill=STEEL, stroke=STEEL_EDGE, width=1.5, **data):
        attrs = " ".join(f'data-{k.replace("_", "-")}="{escape(str(v))}"' for k, v in data.items())
        self.parts.append(f'<rect x="{x:.6f}" y="{y:.6f}" width="{max(0, w):.6f}" height="{max(0, h):.6f}" fill="{fill}" stroke="{stroke}" stroke-width="{width}" {attrs}/>')

    def dim(self, a, b, y, *, from_y=None, label=None, label_y=None, label_x=None, **data):
        # External arrows at very small widths remain legible; endpoints stay exact.
        if from_y is not None:
            for x in (a, b):
                self.line(x, from_y, x, y + 6, color=MUTED, width=1)
        if abs(b - a) >= 28:
            self.line(a + 4, y, b - 4, y, arrow=True, **data)
        else:
            self.line(a - 15, y, b + 15, y, color=MUTED, width=1, **data)
        for x in (a, b):
            self.line(x - 3, y + 5, x + 3, y - 5)
        if label:
            self.text((a + b) / 2 if label_x is None else label_x,
                      y - 10 if label_y is None else label_y, label, anchor="middle")

    def finish(self):
        return "".join(self.parts) + "</svg>"


def _elevation(g):
    s = _SVG("ELEVAÇÃO · posições ao longo da viga", 390)
    v = g["values"]
    s.text(26, 60, "Laranja = pares de chapas vistos de lado. Traço vertical = eixo de cada apoio.", color=MUTED)
    length, limits = g["length_mm"], g["physical_limits_mm"]
    if length is None or limits is None:
        s.text(26, 128, "Geometria longitudinal não desenhada: revise vão e projeções.", color=DANGER)
        s.text(26, 163, "Os valores dos campos foram preservados; nenhum comprimento foi corrigido.", color=MUTED)
    else:
        lower, upper = limits
        # Include the genuine contact footprint even when it exceeds the beam end.
        domain_low = min([lower, *(f[0] for f in g["bearing_footprints_mm"])])
        domain_high = max([upper, *(f[1] for f in g["bearing_footprints_mm"])])
        scale = 940 / (domain_high - domain_low)
        x = lambda u: 90 + (u - domain_low) * scale
        ya, yb = 138, 226
        s.rect(x(lower), ya, (upper - lower) * scale, yb - ya, fill="#eff3f6", beam="physical", start_mm=lower, end_mm=upper)
        s.rect(x(lower), ya, (upper - lower) * scale, 8)
        s.rect(x(lower), yb - 8, (upper - lower) * scale, 8)
        for at in g["pair_positions_mm"] if g["plate_valid"] else ():
            t = v["stiffener_thickness_mm"]
            s.rect(x(at - t / 2), ya + 8, t * scale, yb - ya - 16,
                   fill=PLATE, stroke=PLATE_EDGE, width=.75, role="pair", x_mm=at, thickness_mm=t)
        for name, at in (("A", 0.0), ("B", length)):
            xx = x(at)
            s.line(xx, 114, xx, 254, color=MUTED, dash="6 4", axis=name, x_mm=at)
            s.text(xx, 109, name, anchor="middle", bold=True)
        for i, (a, b) in enumerate(g["bearing_footprints_mm"]):
            s.rect(x(a), yb + 2, (b - a) * scale, 13, fill=SUPPORT, stroke=WELD,
                   role="bearing", support="AB"[i], start_mm=a, end_mm=b)
        s.dim(x(0), x(length), 87, label="Vão entre apoios = " + _fmt(v["span_m"]) + " m", label_y=81,
              role="support-span", start_mm=0, end_mm=length)
        # Separate end labels never overlap support letters or short projection dimensions.
        s.line(x(lower), ya, 56, 129, color=MUTED, width=1)
        s.line(x(upper), ya, 1064, 129, color=MUTED, width=1)
        s.text(26, 126, "Ponta física", size=15, color=MUTED)
        s.text(1094, 126, "Ponta física", size=15, anchor="end", color=MUTED)
        positions = g["pair_positions_mm"]
        if g["layout"] == "paired_full_height_uniform" and len(positions) > 2:
            a, b = positions[:2]
            s.dim(x(a), x(b), 272, from_y=yb, role="spacing", start_mm=a, end_mm=b)
            s.text(26, 310, "Espaçamento de enrijecedores (m): " + _fmt(v["stiffener_spacing_m"]), bold=True)
            s.text(26, 336, "Cota entre eixos dos pares. Último intervalo: " + _fmt((positions[-1] - positions[-2]) / 1000) + " m.", color=MUTED)
            s.text(26, 362, f"{len(positions)} pares nas posições reais; desenhos auxiliares abaixo em outras escalas.", color=MUTED)
        elif g["layout"] == "paired_full_height_supports":
            s.text(26, 296, "Disposição: pares de altura total somente nos apoios A e B.", bold=True)
            s.text(26, 324, "Espaçamento informado = " + _fmt(v["stiffener_spacing_m"]) + " m; não cria pares intermediários nesta opção.", color=MUTED)
        elif positions:
            s.text(26, 296, "Espaçamento informado = " + _fmt(v["stiffener_spacing_m"]) + " m; não há par intermediário.", bold=True)
            s.text(26, 324, "O único intervalo é o vão entre os pares dos apoios.", color=MUTED)
        else:
            s.text(26, 296, g["position_issue"], color=MUTED)
        if g["layout"] in FULL_HEIGHT and not g["plate_valid"]:
            s.text(26, 362, "Chapas não desenhadas: espessura ou largura saliente inválida.", color=DANGER)
    return s.finish()


def _section_and_plan(g):
    s = _SVG("CORTE E PLANTA · duas dimensões diferentes da chapa", 500)
    v, sec = g["values"], g["section"]
    s.line(560, 64, 560, 397, color="#d8e2e9", width=1)
    s.text(26, 68, "CORTE S–S · plano y–z (x constante)", bold=True)
    s.text(586, 68, "PLANTA · plano x–y, mesas omitidas", bold=True)
    s.text(26, 94, "Olhar na direção longitudinal da viga.", size=16, color=MUTED)
    s.text(586, 94, "Olhar de cima, no mesmo par de chapas.", size=16, color=MUTED)
    if not g["section_valid"]:
        s.text(26, 157, "Seção inválida: corte não desenhado.", color=DANGER)
        s.text(26, 187, "Revise mesas, alma e altura total.", color=MUTED)
    else:
        d, tw, bt, bb, tt, tb = (sec[k] for k in ("d_mm", "tw_mm", "bf_mm", "bottom_width", "tf_mm", "bottom_thickness"))
        c = v["stiffener_outstand_mm"] if g["plate_valid"] else 0
        outer = max(bt, bb, tw + 2 * c)
        k = min(190 / d, 360 / outer)
        cx, top = 281, 132
        bottom = top + d * k
        web_left, web_right = cx - tw * k / 2, cx + tw * k / 2
        s.rect(web_left, top + tt * k, tw * k, (d - tt - tb) * k, role="web-cut")
        s.rect(cx - bt * k / 2, top, bt * k, tt * k, role="top-flange")
        s.rect(cx - bb * k / 2, bottom - tb * k, bb * k, tb * k, role="bottom-flange")
        if g["plate_valid"]:
            for side, a in (("left", web_left - c * k), ("right", web_right)):
                s.rect(a, top + tt * k, c * k, (d - tt - tb) * k,
                       fill=PLATE, stroke=DANGER if g["outstand_overflow"] else PLATE_EDGE,
                       role="plate-cut", side=side, outstand_mm=c, plane="yz")
                if g["connection"] in {"web_only_welded", "web_and_both_flanges_welded"}:
                    wx = web_left if side == "left" else web_right
                    s.line(wx, top + tt * k, wx, bottom - tb * k, color=WELD, width=3,
                           role="connection", to="web", side=side)
                if g["connection"] == "web_and_both_flanges_welded":
                    for yy, which in ((top + tt * k, "top-flange"), (bottom - tb * k, "bottom-flange")):
                        s.line(a, yy, a + c * k, yy, color=WELD, width=3,
                               role="connection", to=which, side=side)
            s.dim(web_left - c * k, web_left, 350, from_y=bottom, role="outstand-left", origin="web-face", value_mm=c)
            s.dim(web_right, web_right + c * k, 350, from_y=bottom, role="outstand-right", origin="web-face", value_mm=c)
            s.text(26, 382, "Largura saliente de cada chapa (mm): " + _fmt(c), bold=True, size=16)
            s.text(26, 406, "Da face da alma até a borda livre; uma chapa por lado.", size=16, color=MUTED)
        else:
            s.text(26, 362, "Nenhuma chapa presumida nesta vista.", color=MUTED)

        # In plan the longitudinal thickness is horizontal (x); c is transverse (y).
        if g["plate_valid"]:
            t = v["stiffener_thickness_mm"]
            py_extent = tw + 2 * c
            plan_x_extent = max(6 * t, py_extent * .95)
            pk = min(290 / plan_x_extent, 185 / py_extent)
            pcx, pcy = 830, 230
            pleft, pright = pcx - t * pk / 2, pcx + t * pk / 2
            s.rect(pcx - plan_x_extent * pk / 2, pcy - tw * pk / 2,
                   plan_x_extent * pk, tw * pk, role="web-plan")
            for side, py in (("left", pcy - tw * pk / 2 - c * pk), ("right", pcy + tw * pk / 2)):
                s.rect(pleft, py, t * pk, c * pk, fill=PLATE, stroke=PLATE_EDGE,
                       role="plate-plan", side=side, thickness_mm=t, outstand_mm=c, plane="xy")
            s.line(pcx, 120, pcx, 342, color=MUTED, dash="5 4", role="section-plane", plane="yz")
            s.text(pcx + 8, 140, "S", size=16, color=MUTED)
            s.text(pcx + 8, 335, "S", size=16, color=MUTED)
            s.dim(pleft, pright, 112, from_y=pcy - py_extent * pk / 2,
                  role="thickness", direction="x", value_mm=t)
            s.text(586, 382, "Espessura de enrijecedores (mm): " + _fmt(t), bold=True, size=16)
            s.text(586, 406, "t é medida ao longo de x, não na largura saliente.", size=16, color=MUTED)
            # A small axis key outside the geometry is independent of proportions.
            s.line(998, 276, 1066, 276, color=INK)
            s.line(1061, 272, 1066, 276)
            s.line(1061, 280, 1066, 276)
            s.text(1032, 262, "x", anchor="middle", bold=True)
            s.line(998, 276, 998, 322, color=INK)
            s.line(994, 317, 998, 322)
            s.line(1002, 317, 998, 322)
            s.text(1011, 319, "y", bold=True)
        else:
            s.text(586, 200, "Chapas não desenhadas.", color=MUTED)
            s.text(586, 230, "A espessura t seria medida ao longo de x.", color=MUTED)
    if g["layout"] not in FULL_HEIGHT:
        legend = "Disposição sem chapas ou desconhecida: ligação não presumida."
    elif g["connection"] == "web_and_both_flanges_welded":
        legend = "Ligação: soldadas à alma e às duas mesas. Azul marca as interfaces indicadas."
    elif g["connection"] == "web_only_welded":
        legend = "Ligação: soldadas somente à alma. Não se presume solda às mesas."
    else:
        legend = "Ligação outra ou desconhecida: nenhuma solda representada como definida."
    s.text(26, 446, legend, size=17, bold=True)
    s.text(26, 475, "Esquema dimensional; sem símbolo de penetração, dimensão de solda ou aprovação de fabricação.", color=MUTED, size=16)
    return s.finish()


def _support_details(g):
    s = _SVG("APOIOS A E B · projeção não é comprimento de apoio", 380)
    v = g["values"]
    s.text(26, 62, "Projeção: do eixo até a ponta física. Comprimento de apoio: pegada de contato sob a mesa.", color=MUTED)
    s.line(560, 84, 560, 304, color="#d8e2e9", width=1)
    for i, name in enumerate(("A", "B")):
        origin = 26 + i * 560
        end = v["beam_end_left_mm" if i == 0 else "beam_end_right_mm"]
        bearing = v["support_bearing_length_mm"]
        s.text(origin, 97, "Apoio " + name + " · detalhe longitudinal x–z", bold=True)
        if end is None:
            s.text(origin, 151, "Projeção inválida: detalhe não desenhado.", color=DANGER)
            continue
        if not g["contact_known"] or bearing is None:
            s.text(origin, 151, "Contato não definido: pegada não presumida.", color=MUTED)
            s.text(origin, 184, "Projeção além do apoio " + name + " = " + _fmt(end) + " mm")
            continue
        # Local scale includes the full pad, even if it projects beyond the end.
        extent = max(end, bearing / 2, 1.0)
        local_min = -1.0 if i == 0 else -1.25
        k = (420 / 2.25) / extent
        # Normalize before subtracting so even extreme finite imports cannot
        # overflow the displayed local interval or create NaN coordinates.
        x = lambda at: origin + 42 + (at / extent - local_min) * (420 / 2.25)
        axis = x(0)
        tip = x(-end if i == 0 else end)
        inner = origin + 42 + (420 if i == 0 else 0)
        a, b = sorted((tip, inner))
        s.rect(a, 168, b - a, 37, fill="#eff3f6", role="support-beam", support=name)
        s.rect(a, 197, b - a, 8, role="support-flange", support=name)
        s.line(axis, 120, axis, 272, color=MUTED, dash="6 4", axis=name)
        s.text(axis + 8, 163, "eixo " + name, size=15, color=MUTED)
        s.rect(x(-bearing / 2), 207, bearing * k, 19, fill=SUPPORT, stroke=WELD,
               role="bearing-detail", support=name, start_relative_mm=-bearing / 2, end_relative_mm=bearing / 2)
        if end < bearing / 2:
            outside_a, outside_b = ((-bearing / 2, -end) if i == 0 else (end, bearing / 2))
            s.rect(x(outside_a), 207, (outside_b - outside_a) * k, 19, fill="#f8d5d0", stroke=DANGER,
                   role="uncovered-bearing", support=name)
        s.dim(min(tip, axis), max(tip, axis), 132, from_y=168,
              role="projection", support=name, value_mm=end)
        s.text(origin, 294, "Projeção além do apoio " + name + " (mm): " + _fmt(end), bold=True, size=16)
        s.dim(x(-bearing / 2), x(bearing / 2), 254, from_y=226,
              role="bearing-length", support=name, value_mm=bearing)
    s.text(26, 330, "Comprimento de apoio (mm): " + _fmt(v["support_bearing_length_mm"]) + " · contato centrado em cada eixo, quando definido.", bold=True, size=17)
    uncovered = (v["support_bearing_length_mm"] is not None and
                 any(v[key] is not None and v[key] < v["support_bearing_length_mm"] / 2
                     for key in ("beam_end_left_mm", "beam_end_right_mm")))
    if uncovered and g["contact_known"]:
        s.text(26, 359, "Vermelho: parte da pegada informada fica fora da viga. Valor preservado; revisar compatibilidade.", color=DANGER, size=16)
    else:
        s.text(26, 359, "A pegada não foi alongada para coincidir com a projeção. Ampliações locais em escala própria.", color=MUTED, size=16)
    return s.finish()


def build_detail_diagrams(p):
    """Return self-contained SVGs in reading order; no optional libraries needed."""
    g = diagram_geometry(p)
    return {"elevation": _elevation(g), "section_plan": _section_and_plan(g),
            "support_details": _support_details(g)}


def render_detail_diagrams(st, p):
    """Show the live, read-only guide immediately below the detailing inputs."""
    st.markdown("**Guia visual dos campos · acompanha os valores informados**")
    st.caption("Cada desenho usa os campos atuais. Cotas em metros ou milímetros conforme os rótulos; vistas em escalas diferentes. O guia não altera entradas nem substitui a verificação do detalhe.")
    for svg in build_detail_diagrams(p).values():
        st.image(svg, width="stretch")
