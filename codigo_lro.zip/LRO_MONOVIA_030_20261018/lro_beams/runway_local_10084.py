"""Bounded, traceable LOCAL top-running runway effects, ABNT NBR 10084:2020.

Source: supplied standard, visually checked printed pp. 5-8 (PDF pp. 9-12).
This module neither uses Robot ELU rows nor applies dynamic/load multipliers.
Fz must already be the design wheel action for the stated NBR 10084 case I/II/III.
It does not select NBR 8400-2 allowable stresses or approve an entire structure.

Scope: straight, constant doubly symmetric steel I section; centered rail;
interior region with untruncated dispersion. All dimensions mm, forces kN,
inertias mm4, stresses MPa. Compression is positive ONLY for reported local
magnitudes; *_signed_mpa uses tension-positive convention for later combination.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
import math
from numbers import Real
from typing import Any


SOURCES = {
    "load_basis": {"standard": "ABNT NBR 10084:2020", "clause": "8; 9.1.3.1", "printed_pages": [3, 4, 5], "pdf_pages": [7, 8, 9]},
    "global": {"standard": "ABNT NBR 10084:2020", "clause": "9.1.1; 9.1.2", "printed_pages": [4, 5], "pdf_pages": [8, 9]},
    "compression": {"standard": "ABNT NBR 10084:2020", "clause": "9.1.3.1; Figures 1-3; Table 1", "printed_pages": [5, 6, 7], "pdf_pages": [9, 10, 11]},
    "shear": {"standard": "ABNT NBR 10084:2020", "clause": "9.1.3.2; Figure 4", "printed_pages": [7], "pdf_pages": [11]},
    "torsion": {"standard": "ABNT NBR 10084:2020", "clause": "9.1.3.3; Figure 5", "printed_pages": [7, 8], "pdf_pages": [11, 12]},
    "combined": {"standard": "ABNT NBR 10084:2020", "clause": "9.1.3.4", "printed_pages": [8], "pdf_pages": [12]},
    "multiwheel_bound": {"standard": "ABNT NBR 10084:2020; derivação adotada de envelope elástico superior", "clause": "9.1.3.1–9.1.3.4; desigualdade triangular dentro do modelo local normativo", "supporting_source": "Zauchner, Kettler, Unterweger (2023), 1.1, equations (1)-(4)", "url": "https://doi.org/10.1002/cepa.2526"},
}

MULTIWHEEL_MODEL_DECLARATION = (
    "Modelo local elástico simplificado da NBR 10084 adotado para seção/trilho uniformes, "
    "com o mesmo espaçamento real a e restrição efetiva à rotação nos enrijecedores transversais; "
    "trilho contínuo sem juntas/descontinuidades na região interior avaliada e todas as rodas "
    "relevantes do caso incluídas. A soma de máximos é limite superior do modelo normativo, "
    "não distribuição espacial nem validação universal das tensões reais de placa."
)


@dataclass
class Wheel10084:
    """One wheel, with x measured from the beam's left end; Fz downward positive."""
    name: str = "Roda 1"
    x_mm: float = 0.0
    fz_kn: float = 0.0


@dataclass
class Local10084Input:
    """Independent input contract; empty/default input deliberately cannot pass.

    rail_attachment: rigid / non_rigid / resilient_pad (Table 1 a/b/c).
    wheel_guidance: flanged / guide_roller_unguided_side. Guided side unsupported.
    torsion_it_scope: flange_only / flange_plus_rigid_rail. It is externally
    qualified, never the whole-beam J and never the bending inertia Irf.
    """
    name: str = "Efeitos locais NBR 10084"
    case: str = ""
    load_basis: str = ""
    actions_source: str = ""
    actions_ready_for_case: bool = False
    top_running: bool = False
    section_kind: str = "symmetric_i"
    d_mm: float = 0.0
    bf_mm: float = 0.0
    tf_mm: float = 0.0
    tw_mm: float = 0.0
    bottom_bf_mm: float | None = None
    bottom_tf_mm: float | None = None
    beam_length_mm: float = 0.0
    section_source: str = ""
    interior_region_confirmed: bool = False
    z_mm: float = 0.0
    rail_attachment: str = ""
    rail_bfr_mm: float = 0.0
    rail_hr_mm: float = 0.0
    rail_ir_mm4: float = 0.0
    rail_area_mm2: float | None = None
    rail_centroid_from_base_mm: float | None = None
    rail_properties_source: str = ""
    rail_offset_from_web_mm: float = 0.0
    rigid_fixing_verified: bool = False
    rail_and_flange_same_modulus: bool = False
    pad_thickness_mm: float = 0.0
    pad_is_resilient_elastomer: bool = False
    wheel_guidance: str = ""
    wheel_rail_clearance_fw_mm: float | None = None
    rail_head_width_br_mm: float | None = None
    eccentricity_source: str = ""
    transverse_stiffeners_welded_to_web: bool = False
    stiffener_spacing_a_mm: float | None = None
    top_assembly_it_mm4: float | None = None
    torsion_it_scope: str = ""
    torsion_it_source: str = ""
    multiwheel_envelope_method: str = ""  # optional: absolute_sum_nbr10084
    multiwheel_model_qualified: bool = False
    multiwheel_model_source: str = ""
    wheels: list[Wheel10084] = field(default_factory=list)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "Local10084Input":
        data = dict(data)
        data["wheels"] = [w if isinstance(w, Wheel10084) else Wheel10084(**w) for w in data.get("wheels", [])]
        return cls(**data)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def _finite(value: Any) -> bool:
    return isinstance(value, Real) and not isinstance(value, bool) and math.isfinite(value)


def _plain(value: Any) -> Any:
    """Strict-JSON-safe audit snapshot, even for invalid NaN/infinity input."""
    if isinstance(value, dict):
        return {str(k): _plain(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_plain(v) for v in value]
    if isinstance(value, Real) and not isinstance(value, bool):
        return value if math.isfinite(value) else str(value)
    return value


def _hyperbolic_ratio(u: float) -> float:
    """sinh(u)^2 / (sinh(2u)-2u), stable for very small/large positive u.

    The small-u expansion is the same expression, not a normative replacement.
    The large-u expression divides numerator/denominator by exp(2u).
    """
    if u < 1e-3:
        return 3.0 / (4.0 * u) * (1.0 + 2.0 * u * u / 15.0 - 2.0 * u**4 / 1575.0)
    if u > 20.0:
        q = math.exp(-2.0 * u)
        return 0.5 * (1.0 - 2.0 * q + q * q) / (1.0 - q * q - 4.0 * u * q)
    return math.sinh(u)**2 / (math.sinh(2.0 * u) - 2.0 * u)


def _uniform_envelope(wheels: list[Wheel10084], length: float, pressures: list[float]) -> dict[str, Any]:
    """Exact positive uniform-patch envelope, excluding zero-width touching.

    Evaluate each nonzero interval between patch ends. Adjacent patches which
    merely touch do not overlap: the standard requires spacing < dispersion.
    An interval, not an invented single wheel position, identifies the maximum.
    """
    ends = sorted({w.x_mm - length / 2.0 for w in wheels} | {w.x_mm + length / 2.0 for w in wheels})
    best_value, best_interval, best_active = -1.0, None, []
    overlap_present = False
    for left, right in zip(ends, ends[1:]):
        if right <= left:
            continue
        midpoint = (left + right) / 2.0
        active = [i for i, w in enumerate(wheels) if abs(midpoint - w.x_mm) < length / 2.0]
        overlap_present = overlap_present or len(active) > 1
        value = sum(pressures[i] for i in active)
        if value > best_value:
            best_value, best_interval, best_active = value, [left, right], active
    return {"maximum_mpa": max(best_value, 0.0), "critical_interval_x_mm": best_interval,
            "contributing_wheel_indices": best_active,
            "contributing_wheels": [wheels[i].name for i in best_active],
            "overlap_present": overlap_present,
            "method": "Envelope de parcelas uniformes; interseções com largura positiva; somas no mesmo intervalo."}


def _calculate_local_10084(data: Local10084Input | dict[str, Any]) -> dict[str, Any]:
    """Calculate local effects with explicit gates; always return a partial result.

    Only a single-wheel interior case has local_effects_complete=True.
    An explicitly adopted multiwheel bound can instead have
    local_effects_bound_complete=True. This is a sum-of-absolute-maxima upper
    envelope within the normative elastic model, never a simultaneous stress
    state or a signed pointwise result. No acceptance limit is assumed.
    """
    if isinstance(data, dict):
        try:
            data = Local10084Input.from_dict(data)
        except (TypeError, ValueError, KeyError) as exc:
            return {"status": "ENTRADA INVÁLIDA", "input_valid": False, "local_effects_complete": False, "local_effects_bound_complete": False,
                    "approval": False, "values": {}, "stresses": {}, "checks": [],
                    "pending": [f"Estrutura de entrada inválida: {exc}"], "sources": SOURCES.copy(), "audit": []}
    if not isinstance(data, Local10084Input):
        raise TypeError("Expected Local10084Input or its dictionary representation")
    out: dict[str, Any] = {
        "status": "RESULTADO PARCIAL", "input_valid": True, "local_effects_complete": False,
        "local_effects_bound_complete": False, "approval": False,
        "name": data.name, "case": data.case, "load_basis": data.load_basis,
        "input": _plain(asdict(data)), "units": {"length": "mm", "force": "kN", "inertia": "mm4", "stress": "MPa"},
        "sign_convention": "Magnitudes locais de compressão positivas; campos *_signed_mpa com tração positiva. Cisalhamento: extremos locais ±, sem combinação global automática.",
        "values": {}, "stresses": {}, "checks": [], "pending": [], "limitations": [], "sources": SOURCES.copy(), "audit": [],
    }
    invalid: list[str] = []
    unsupported: list[str] = []
    def record(identifier: str, status: str, message: str, source: str, **extra: Any) -> None:
        out["checks"].append({"id": identifier, "status": status, "message": message, "source": source, **extra})
    def audit(identifier: str, equation: str, inputs: dict[str, Any], value: Any, unit: str, source: str) -> None:
        out["audit"].append({"id": identifier, "equation": equation, "inputs": inputs, "value": value, "unit": unit, "source": source})
    positive = ("d_mm", "bf_mm", "tf_mm", "tw_mm", "beam_length_mm", "rail_bfr_mm", "rail_hr_mm", "rail_ir_mm4")
    nonnegative = ("z_mm", "pad_thickness_mm")
    optional = ("bottom_bf_mm", "bottom_tf_mm", "rail_area_mm2", "rail_centroid_from_base_mm", "wheel_rail_clearance_fw_mm", "rail_head_width_br_mm", "stiffener_spacing_a_mm", "top_assembly_it_mm4")
    for key in positive:
        if not _finite(getattr(data, key)) or getattr(data, key) <= 0:
            invalid.append(f"{key}: informar número finito positivo.")
    for key in nonnegative:
        if not _finite(getattr(data, key)) or getattr(data, key) < 0:
            invalid.append(f"{key}: informar número finito não negativo.")
    for key in optional:
        if getattr(data, key) is not None and not _finite(getattr(data, key)):
            invalid.append(f"{key}: valor deve ser finito quando informado.")
    if not _finite(data.rail_offset_from_web_mm):
        invalid.append("rail_offset_from_web_mm: valor deve ser finito.")
    if not isinstance(data.wheels, list) or not data.wheels:
        invalid.append("Informar ao menos uma roda.")
    else:
        names = []
        for i, wheel in enumerate(data.wheels):
            if not isinstance(wheel, Wheel10084):
                invalid.append(f"Roda {i}: usar Wheel10084.")
                continue
            names.append(wheel.name) if isinstance(wheel.name, str) else None
            if not isinstance(wheel.name, str) or not wheel.name.strip():
                invalid.append(f"Roda {i}: identificar a roda.")
            if not _finite(wheel.x_mm):
                invalid.append(f"Roda {i}: x_mm deve ser finito.")
            if not _finite(wheel.fz_kn) or wheel.fz_kn < 0:
                invalid.append(f"Roda {i}: Fz deve ser finito e não negativo; arrancamento não coberto.")
        if len(names) != len(set(names)):
            invalid.append("Nomes das rodas devem ser únicos.")
    for key in ("case", "load_basis", "actions_source", "section_source", "rail_properties_source", "rail_attachment", "section_kind", "wheel_guidance", "eccentricity_source", "torsion_it_scope", "torsion_it_source", "multiwheel_envelope_method", "multiwheel_model_source"):
        if not isinstance(getattr(data, key), str):
            invalid.append(f"{key}: informar texto.")
    for key in ("actions_ready_for_case", "top_running", "interior_region_confirmed", "rigid_fixing_verified", "rail_and_flange_same_modulus", "pad_is_resilient_elastomer", "transverse_stiffeners_welded_to_web", "multiwheel_model_qualified"):
        if not isinstance(getattr(data, key), bool):
            invalid.append(f"{key}: informar booleano explícito; textos como 'false' não qualificam o domínio.")
    if invalid:
        out.update(status="ENTRADA INVÁLIDA", input_valid=False)
        out["pending"] = invalid
        record("input", "INVÁLIDO", "; ".join(invalid), "global")
        return out
    if data.case not in {"I", "II", "III"}:
        unsupported.append("Selecionar explicitamente caso I, II ou III da NBR 10084.")
    if data.multiwheel_envelope_method not in {"", "absolute_sum_nbr10084"}:
        unsupported.append("Método de envelope multirrodas desconhecido; selecionar explicitamente absolute_sum_nbr10084 ou deixar vazio.")
    if data.load_basis != "nbr10084_case_design" or not data.actions_ready_for_case or not data.actions_source.strip():
        unsupported.append("Fz deve ser valor de projeto próprio do caso NBR 10084, com origem e confirmação dos fatores já aplicados; ELU Robot, serviço bruto e remajoração automática não são aceitos.")
    if not data.top_running:
        unsupported.append("Módulo restrito a rodas no trilho apoiado na mesa superior; não cobre monovia/mesa inferior.")
    if data.section_kind != "symmetric_i":
        unsupported.append("Somente seção I duplamente simétrica nesta implementação.")
    if data.bottom_bf_mm is None or data.bottom_tf_mm is None:
        unsupported.append("Informar dimensões reais de ambas as mesas para confirmar dupla simetria.")
    elif not (math.isclose(data.bottom_bf_mm, data.bf_mm, rel_tol=1e-9) and math.isclose(data.bottom_tf_mm, data.tf_mm, rel_tol=1e-9)):
        unsupported.append("Mesas desiguais fora do domínio qualificado deste módulo.")
    if not data.section_source.strip() or not data.rail_properties_source.strip():
        unsupported.append("Identificar a fonte da geometria da seção e das propriedades do trilho.")
    if data.d_mm <= 2.0 * data.tf_mm or data.bf_mm <= data.tw_mm:
        unsupported.append("Geometria I inválida: exigir d > 2tf e bf > tw.")
    if data.rail_bfr_mm > data.bf_mm or data.rail_offset_from_web_mm != 0.0:
        unsupported.append("Exigir patim integralmente apoiado e trilho centrado na alma; deslocamento geométrico do trilho não está coberto.")
    if not data.interior_region_confirmed:
        unsupported.append("Qualificar região afastada dos apoios; reação de apoio, dispersão inversa e regiões de apoio não estão implementadas.")
    if data.rail_attachment not in {"rigid", "non_rigid", "resilient_pad"}:
        unsupported.append("Selecionar fixação rigid/non_rigid/resilient_pad da Tabela 1.")
    if data.rail_attachment == "rigid":
        if not data.rigid_fixing_verified or not data.rail_and_flange_same_modulus:
            unsupported.append("Trilho rigidamente fixado exige ligação e compatibilidade de módulo do aço qualificadas para inércia combinada.")
        if data.rail_area_mm2 is None or data.rail_area_mm2 <= 0 or data.rail_centroid_from_base_mm is None or not 0 <= data.rail_centroid_from_base_mm <= data.rail_hr_mm:
            unsupported.append("Fixação rígida exige área do trilho e centroide medido da base, dentro da altura do trilho.")
    if data.rail_attachment == "resilient_pad" and (data.pad_thickness_mm < 6.0 or not data.pad_is_resilient_elastomer):
        unsupported.append("Caso (c) exige manta de elastômero resiliente com espessura >= 6 mm; não atribuir coeficiente 4,25 a manta não qualificada.")
    if unsupported:
        out["status"] = "FORA DO ESCOPO"
        out["pending"] = unsupported
        record("scope", "FORA DO ESCOPO", "; ".join(unsupported), "compression")
        return out
    hw = data.d_mm - 2.0 * data.tf_mm
    if not 0 <= data.z_mm <= hw:
        out.update(status="ENTRADA INVÁLIDA", input_valid=False)
        out["pending"] = ["Exigir 0 <= z <= hw; z parte da face inferior da mesa superior."]
        record("depth", "INVÁLIDO", out["pending"][0], "compression")
        return out
    record("actions", "QUALIFICADO", "Ações próprias do caso informado; multiplicador adicional exatamente 1,0. Não há conversão de esforços ELU.", "load_basis")
    bef = min(data.rail_bfr_mm + data.rail_hr_mm + data.tf_mm, data.bf_mm)
    ifef = bef * data.tf_mm**3 / 12.0
    out["values"].update(hw_mm=hw, bef_mm=bef, ifef_mm4=ifef, additional_load_multiplier=1.0)
    audit("bef", "min(bfr + hr + tf, bf)", {"bfr_mm": data.rail_bfr_mm, "hr_mm": data.rail_hr_mm, "tf_mm": data.tf_mm, "bf_mm": data.bf_mm}, bef, "mm", "compression")
    audit("ifef", "bef * tf^3 / 12 (rectangular effective flange, centroidal horizontal axis)", {"bef_mm": bef, "tf_mm": data.tf_mm}, ifef, "mm4", "compression")
    if data.rail_attachment == "rigid":
        af = bef * data.tf_mm
        ar = data.rail_area_mm2
        rail_y = data.tf_mm + data.rail_centroid_from_base_mm
        flange_y = data.tf_mm / 2.0
        ybar = (ar * rail_y + af * flange_y) / (ar + af)
        irf = data.rail_ir_mm4 + ar * (rail_y - ybar)**2 + ifef + af * (flange_y - ybar)**2
        inertia, coefficient = irf, 3.25
        out["values"].update(irf_mm4=irf, composite_centroid_above_flange_bottom_mm=ybar)
        audit("irf", "Ir + Ar*(yr-ybar)^2 + Ifef + Af*(yf-ybar)^2; ybar=sum(A*y)/sum(A)", {"ir_mm4": data.rail_ir_mm4, "ar_mm2": ar, "af_mm2": af, "yr_mm": rail_y, "yf_mm": flange_y, "ybar_mm": ybar, "ifef_mm4": ifef}, irf, "mm4", "compression")
    else:
        inertia = data.rail_ir_mm4 + ifef
        coefficient = 4.25 if data.rail_attachment == "resilient_pad" else 3.25
        audit("effective_inertia", "Ir + Ifef", {"ir_mm4": data.rail_ir_mm4, "ifef_mm4": ifef}, inertia, "mm4", "compression")
    lef = coefficient * (inertia / data.tw_mm)**(1.0 / 3.0)
    length_z = lef + 2.0 * data.z_mm
    factor_z = (1.0 - data.z_mm / hw)**2
    out["values"].update(lef_mm=lef, dispersion_length_at_z_mm=length_z, depth_reduction=factor_z, table_1_coefficient=coefficient)
    audit("lef", "coefficient * (effective_inertia / tw)^(1/3)", {"coefficient": coefficient, "effective_inertia_mm4": inertia, "tw_mm": data.tw_mm}, lef, "mm", "compression")
    audit("dispersion", "lef + 2*z", {"lef_mm": lef, "z_mm": data.z_mm}, length_z, "mm", "compression")
    audit("depth_reduction", "(1-z/hw)^2; interior region only", {"z_mm": data.z_mm, "hw_mm": hw}, factor_z, "1", "compression")
    for wheel in data.wheels:
        if wheel.x_mm - length_z / 2.0 < 0 or wheel.x_mm + length_z / 2.0 > data.beam_length_mm:
            unsupported.append(f"{wheel.name}: dispersão alcança a extremidade; redução/truncamento não qualificados.")
    if unsupported:
        out["status"] = "FORA DO ESCOPO"
        out["pending"] = unsupported
        record("dispersion_limits", "FORA DO ESCOPO", "; ".join(unsupported), "compression")
        return out
    rows, top_pressures, z_pressures = [], [], []
    for i, wheel in enumerate(data.wheels):
        fz_n = wheel.fz_kn * 1000.0
        sigma_top = fz_n / (lef * data.tw_mm)
        sigma_z = fz_n / (length_z * data.tw_mm) * factor_z
        tau_top = 0.2 * sigma_top
        tau_z = tau_top if data.z_mm <= 0.2 * hw else 0.0
        top_pressures.append(sigma_top)
        z_pressures.append(sigma_z)
        rows.append({"name": wheel.name, "x_mm": wheel.x_mm, "fz_kn": wheel.fz_kn,
                     "sigma0z_top_mpa": sigma_top, "sigma0z_at_z_mpa": sigma_z,
                     "sigma0z_top_signed_mpa": -sigma_top, "sigma0z_at_z_signed_mpa": -sigma_z,
                     "tau0xz_top_max_abs_mpa": tau_top, "tau0xz_at_z_max_abs_mpa": tau_z,
                     "tau0xz_at_z_candidates_mpa": [-tau_z, tau_z],
                     "shear_spatial_basis": "Máximo local em cada lado da roda; não é tensão no mesmo x do máximo de compressão."})
        audit(f"wheel_{i}_compression_top", "Fz*1000/(lef*tw)", {"fz_kn": wheel.fz_kn, "lef_mm": lef, "tw_mm": data.tw_mm}, sigma_top, "MPa", "compression")
        audit(f"wheel_{i}_compression_depth", "Fz*1000/((lef+2*z)*tw)*(1-z/hw)^2", {"fz_kn": wheel.fz_kn, "length_z_mm": length_z, "tw_mm": data.tw_mm, "depth_reduction": factor_z}, sigma_z, "MPa", "compression")
        audit(f"wheel_{i}_shear", "0.2*sigma0z_top if z <= 0.2*hw else 0", {"sigma0z_top_mpa": sigma_top, "z_mm": data.z_mm, "hw_mm": hw}, tau_z, "MPa", "shear")
    top_envelope = _uniform_envelope(data.wheels, lef, top_pressures)
    z_envelope = _uniform_envelope(data.wheels, length_z, z_pressures)
    out["stresses"].update(wheels=rows, vertical_top_envelope=top_envelope, vertical_at_z_envelope=z_envelope,
                           sigma0z_top_max_mpa=top_envelope["maximum_mpa"], sigma0z_at_z_max_mpa=z_envelope["maximum_mpa"])
    audit("wheel_superposition_top", "sum individual uniform pressures at same longitudinal interval; max over intervals", {"individual_mpa": top_pressures, "lef_mm": lef, "wheel_x_mm": [w.x_mm for w in data.wheels], "active_indices": top_envelope["contributing_wheel_indices"], "interval_x_mm": top_envelope["critical_interval_x_mm"]}, top_envelope["maximum_mpa"], "MPa", "compression")
    audit("wheel_superposition_depth", "sum individual dispersed/reduced pressures at same longitudinal interval; max over intervals", {"individual_mpa": z_pressures, "length_z_mm": length_z, "wheel_x_mm": [w.x_mm for w in data.wheels], "active_indices": z_envelope["contributing_wheel_indices"], "interval_x_mm": z_envelope["critical_interval_x_mm"]}, z_envelope["maximum_mpa"], "MPa", "compression")
    record("local_vertical", "CALCULADO", "Compressão vertical e superposição espacial das rodas calculadas; sem comparação com tensão admissível.", "compression")
    record("local_shear", "CALCULADO", "Máximo adicional de 20% por roda; não descartado em z = 0,2hw, somente para z > 0,2hw. Somar ao cisalhamento global concomitante após qualificar posição/sinal.", "shear")
    multiwheel_bound = (len(data.wheels) > 1
        and data.multiwheel_envelope_method == "absolute_sum_nbr10084"
        and data.multiwheel_model_qualified and bool(data.multiwheel_model_source.strip()))
    if multiwheel_bound:
        tau_top_bound = math.fsum(row["tau0xz_top_max_abs_mpa"] for row in rows)
        tau_z_bound = tau_top_bound if data.z_mm <= 0.2 * hw else 0.0
        out["stresses"].update(tau0xz_top_bound_mpa=tau_top_bound,
                              tau0xz_at_z_bound_mpa=tau_z_bound)
        out["values"].update(multiwheel_envelope_method="absolute_sum_nbr10084",
                            bound_exceedance_policy="requires_specific_assessment")
        audit("multiwheel_shear_bound", "sum(abs(tau0xz_i,max)); depth cutoff only for z > 0.2*hw", {"individual_top_mpa": [row["tau0xz_top_max_abs_mpa"] for row in rows], "z_mm": data.z_mm, "hw_mm": hw}, tau_z_bound, "MPa", "multiwheel_bound")
        record("multiwheel_model", "QUALIFICADO", MULTIWHEEL_MODEL_DECLARATION, "multiwheel_bound")
        out["limitations"].extend([
            "Envelope conservador somente dentro do modelo local simplificado adotado da NBR 10084; não é estado de tensões concomitantes e não recebe sinal/ponto crítico fictício.",
            "A literatura identifica possível subestimação de picos reais de flexão de placa pela fórmula normativa antiga. A soma limita a interação no modelo adotado; não corrige nem valida esse erro de modelo (Zauchner et al., 2023).",
            "Ultrapassar um limite usando este envelope exige avaliação específica mais refinada; o envelope sozinho não demonstra falha da estrutura. Um valor dentro do limite encerra apenas o critério/modelo explicitamente adotado.",
            "Sem aplicação a juntas de trilho, descontinuidades, apoios, variações de seção/espaçamento, enrijecedores sem restrição efetiva ou resposta não linear; não produz espectro de fadiga nem perfil de sigmaT em profundidade.",
        ])
    elif len(data.wheels) > 1 and data.multiwheel_envelope_method:
        out["pending"].append("Envelope multirrodas selecionado: confirmar aplicabilidade do modelo elástico local e informar sua fonte antes de qualificar o limite superior.")
    torsion_pending = []
    ey = None
    if not data.eccentricity_source.strip():
        torsion_pending.append("Identificar origem da folga/guia e da excentricidade.")
    if data.wheel_guidance == "flanged":
        if data.wheel_rail_clearance_fw_mm is None or data.wheel_rail_clearance_fw_mm < 0:
            torsion_pending.append("Roda flangeada: informar folga roda/trilho fw >= 0.")
        else:
            ey = 0.5 * data.wheel_rail_clearance_fw_mm
            audit("eccentricity", "0.5*fw (flanged wheel)", {"fw_mm": data.wheel_rail_clearance_fw_mm}, ey, "mm", "torsion")
    elif data.wheel_guidance == "guide_roller_unguided_side":
        if data.rail_head_width_br_mm is None or data.rail_head_width_br_mm <= 0 or data.rail_head_width_br_mm > data.rail_bfr_mm:
            torsion_pending.append("Lado não guiado com rolete-guia: informar largura da cabeça br > 0 e <= bfr; não usar largura do patim no lugar de br.")
        else:
            ey = 0.25 * data.rail_head_width_br_mm
            audit("eccentricity", "0.25*br (guide roller, unguided side only)", {"br_mm": data.rail_head_width_br_mm}, ey, "mm", "torsion")
    else:
        torsion_pending.append("Configuração de guiamento não coberta: somente roda flangeada ou lado não guiado com rolete-guia.")
    if not data.transverse_stiffeners_welded_to_web or data.stiffener_spacing_a_mm is None or data.stiffener_spacing_a_mm <= 0:
        torsion_pending.append("Fórmula de flexão local exige reforçadores transversais soldados à alma e espaçamento a > 0.")
    required_it_scope = "flange_plus_rigid_rail" if data.rail_attachment == "rigid" else "flange_only"
    if data.top_assembly_it_mm4 is None or data.top_assembly_it_mm4 <= 0 or not data.torsion_it_source.strip() or data.torsion_it_scope != required_it_scope:
        torsion_pending.append(f"Informar It de Saint-Venant com fonte, positivo e escopo {required_it_scope}; J da viga inteira ou Irf de flexão não substituem It.")
    if torsion_pending:
        out["pending"].extend(torsion_pending)
        record("local_web_bending_torsion", "PENDENTE", "; ".join(torsion_pending), "torsion")
        record("combined_local_compression", "PENDENTE", "Sigma_cz não calculada enquanto sigma_T estiver pendente.", "combined")
    else:
        a, it = data.stiffener_spacing_a_mm, data.top_assembly_it_mm4
        u = math.pi * hw / a
        ratio = _hyperbolic_ratio(u)
        eta = math.sqrt((0.75 * a * data.tw_mm**3 / it) * ratio)
        out["values"].update(ey_mm=ey, u_pi_hw_over_a=u, hyperbolic_ratio=ratio, eta=eta, top_assembly_it_mm4=it)
        audit("eta", "sqrt((0.75*a*tw^3/It)*sinh(pi*hw/a)^2/(sinh(2*pi*hw/a)-2*pi*hw/a))", {"a_mm": a, "tw_mm": data.tw_mm, "it_mm4": it, "hw_mm": hw, "u": u, "hyperbolic_ratio": ratio}, eta, "1", "torsion")
        for i, (wheel, row) in enumerate(zip(data.wheels, rows)):
            torque_nmm = wheel.fz_kn * 1000.0 * ey
            sigma_t = 6.0 * torque_nmm / (a * data.tw_mm**2) * eta * math.tanh(eta)
            combined_isolated = row["sigma0z_top_mpa"] + 0.75 * sigma_t
            row.update(torque_nmm=torque_nmm, sigmaT_mpa=sigma_t, sigma_cz_isolated_mpa=combined_isolated,
                       sigma_cz_isolated_signed_mpa=-combined_isolated,
                       combined_scope="Roda isolada, borda superior da alma; nenhum perfil em profundidade de sigmaT foi presumido.")
            audit(f"wheel_{i}_torque", "Fz*1000*ey", {"fz_kn": wheel.fz_kn, "ey_mm": ey}, torque_nmm, "N.mm", "torsion")
            audit(f"wheel_{i}_sigmaT", "6*T/(a*tw^2)*eta*tanh(eta)", {"torque_nmm": torque_nmm, "a_mm": a, "tw_mm": data.tw_mm, "eta": eta, "tanh_eta": math.tanh(eta)}, sigma_t, "MPa", "torsion")
            audit(f"wheel_{i}_sigma_cz_isolated", "sigma0z_top + 0.75*sigmaT (isolated wheel)", {"sigma0z_top_mpa": row["sigma0z_top_mpa"], "sigmaT_mpa": sigma_t}, combined_isolated, "MPa", "combined")
        record("local_web_bending_torsion", "CALCULADO", "Flexão local da alma por torção da aba superior, por roda. Não representa torção global/empenamento da viga.", "torsion")
        if len(data.wheels) == 1:
            out["stresses"].update(sigmaT_mpa=rows[0]["sigmaT_mpa"], sigma_cz_top_mpa=rows[0]["sigma_cz_isolated_mpa"],
                                  sigma_cz_top_signed_mpa=rows[0]["sigma_cz_isolated_signed_mpa"])
            out["local_effects_complete"] = True
            record("combined_local_compression", "CALCULADO", "Sigma_cz = sigma0z + 0,75 sigmaT, roda única; comparar com limite do mesmo caso pela NBR 8400-2.", "combined")
        elif multiwheel_bound:
            sigma_t_bound = math.fsum(abs(row["sigmaT_mpa"]) for row in rows)
            sigma_cz_bound = top_envelope["maximum_mpa"] + 0.75 * sigma_t_bound
            out["stresses"].update(sigmaT_top_bound_mpa=sigma_t_bound,
                                  sigma_cz_top_bound_mpa=sigma_cz_bound)
            out["local_effects_bound_complete"] = True
            audit("multiwheel_torsion_bound", "sum(abs(sigmaT_i,max)) within the adopted linear normative model", {"individual_sigmaT_mpa": [row["sigmaT_mpa"] for row in rows]}, sigma_t_bound, "MPa", "multiwheel_bound")
            audit("multiwheel_combined_bound", "max_x(sigma0z_top(x)) + 0.75*sum(abs(sigmaT_i,max))", {"sigma0z_top_envelope_mpa": top_envelope["maximum_mpa"], "sigmaT_top_bound_mpa": sigma_t_bound}, sigma_cz_bound, "MPa", "multiwheel_bound")
            record("combined_local_compression", "LIMITE SUPERIOR CALCULADO", "Envelope superior no topo da alma, sem ponto/sinal concomitante: sigma0z,max + 0,75 soma|sigmaT_i,max|. Comparar somente por rota de envelope explicitamente adotada.", "multiwheel_bound")
        else:
            record("combined_local_compression", "PENDENTE", "Rodas múltiplas: compressão vertical superposta disponível; a superposição espacial de torção/cisalhamento não foi qualificada. Valores isolados não encerram a verificação.", "combined")
    if len(data.wheels) > 1 and not out["local_effects_bound_complete"]:
        out["pending"].append("Rodas múltiplas: qualificar interação espacial de flexão local por torção e cisalhamento local, inclusive rodas sem sobreposição de pressão. Não somar extremos independentes como tensões concomitantes.")
    out["pending_requirements"] = [
        {"code":"local_admissible_comparison", "text":"Comparar tensões locais/combinadas com admissíveis da NBR 8400-2 no mesmo caso I/II/III."},
        {"code":"global_local_combination", "text":"Combinar efeitos globais e locais no mesmo ponto e face, ou por envelope conservador qualificado, incluindo todas as componentes pertinentes."},
    ]
    out["pending"].extend(item["text"] for item in out["pending_requirements"])
    out["limitations"] = out.get("limitations", []) + ["Este módulo fornece efeitos locais. Resistência, estabilidade, fadiga e transferência mesa–alma/soldas são avaliadas nas rotas correspondentes do projeto."]
    out["external_responsibilities"] = ["Projeto do trilho, contato roda–trilho, fixações e estrutura dos apoios: compatibilização externa com fabricante e projeto global."]
    return out


def calculate_local_10084(data: Local10084Input | dict[str, Any]) -> dict[str, Any]:
    """Public, strict-JSON-safe local-effects evaluator. See Local10084Input."""
    import json
    try:
        result = _calculate_local_10084(data)
        json.dumps(result, allow_nan=False)
        return result
    except (ArithmeticError, ValueError, TypeError) as exc:
        return {"status": "ENTRADA INVÁLIDA", "input_valid": False, "local_effects_complete": False, "local_effects_bound_complete": False,
                "approval": False, "values": {}, "stresses": {}, "checks": [],
                "pending": [f"Entrada fora do domínio numérico finito: {exc}"],
                "sources": SOURCES.copy(), "audit": []}


@dataclass
class Service10084Input:
    """Beam-only service checks: NBR 10084:2020 §10, Table 4(a,d).

    This deliberately excludes Table 4(c), the under-running monorail check.
    L is the beam length between its supports, NOT the bridge crane's rail gauge.
    Displacements are at rail top from the support's self-weight-only state.
    """
    name: str = "Flechas NBR 10084"
    case: str = ""
    top_running: bool = False
    span_mm: float = 0.0
    span_between_supports_confirmed: bool = False
    equipment_use: str = ""  # steelworks / other; not a CMAA or NBR duty group
    vertical_displacement_mm: float | None = None
    horizontal_displacement_mm: float | None = None
    impact_excluded: bool = False
    majoration_excluded: bool = False
    reference_self_weight_only: bool = False
    measured_at_rail_top: bool = False
    actions_source: str = ""
    span_source: str = ""


def _service_limits_10084(data: Service10084Input | dict[str, Any]) -> dict[str, Any]:
    """Qualify and compare ONLY metal top-running beam limits, Table 4(a,d).

    The supplied printed Table 4(d) gives L/600 for all three equipment/capacity
    lines, including <250 kN. This is kept exactly; no L/400 is imported from a
    different criterion. Vertical displacement has BOTH ratio and 25-mm cap.
    """
    source = {"standard": "ABNT NBR 10084:2020", "clause": "10; Table 4(a,d)",
              "printed_pages": [11, 12], "pdf_pages": [15, 16]}
    out: dict[str, Any] = {"status": "RESULTADO PARCIAL", "input_valid": True, "approval": False,
        "implemented_checks_complete": False, "values": {}, "stresses": {}, "checks": [], "pending": [],
        "sources": {"service": source}, "audit": []}
    if isinstance(data, dict):
        try:
            data = Service10084Input(**data)
        except TypeError as exc:
            out.update(status="ENTRADA INVÁLIDA", input_valid=False, pending=[str(exc)])
            return out
    if not isinstance(data, Service10084Input):
        raise TypeError("Expected Service10084Input or dictionary")
    out["input"] = _plain(asdict(data))
    out["case"] = data.case
    invalid = []
    if not _finite(data.span_mm) or data.span_mm <= 0:
        invalid.append("span_mm deve ser finito e positivo.")
    for key in ("vertical_displacement_mm", "horizontal_displacement_mm"):
        if getattr(data, key) is not None and not _finite(getattr(data, key)):
            invalid.append(f"{key} deve ser finito quando informado.")
    for key in ("top_running", "span_between_supports_confirmed", "impact_excluded", "majoration_excluded", "reference_self_weight_only", "measured_at_rail_top"):
        if not isinstance(getattr(data, key), bool):
            invalid.append(f"{key} deve ser booleano explícito.")
    for key in ("case", "equipment_use", "actions_source", "span_source"):
        if not isinstance(getattr(data, key), str):
            invalid.append(f"{key} deve ser texto.")
    if invalid:
        out.update(status="ENTRADA INVÁLIDA", input_valid=False, pending=invalid)
        return out
    gates = []
    if data.case not in {"I", "II"}:
        gates.append("Limites de vigas da Tabela 4(a,d) implementados somente para casos I e II.")
    if not data.top_running:
        gates.append("Somente viga metálica de rolamento superior; monovia/talha fora deste helper.")
    if not data.span_between_supports_confirmed or not data.span_source.strip():
        gates.append("Confirmar L entre apoios da viga e sua fonte; não usar vão transversal da ponte.")
    if data.equipment_use not in {"steelworks", "other"}:
        gates.append("Identificar aplicação siderúrgica ou demais equipamentos; não inferir por classe CMAA/grupo NBR.")
    if not data.impact_excluded or not data.majoration_excluded or not data.actions_source.strip():
        gates.append("Deslocamentos devem excluir impacto e coeficiente de majoração, com origem das ações identificada.")
    if not data.reference_self_weight_only or not data.measured_at_rail_top:
        gates.append("Medir no topo do trilho a partir da configuração da estrutura-suporte sob apenas seu peso próprio.")
    if gates:
        out.update(status="PENDENTE", pending=gates)
        return out
    ratio_z = 1000.0 if data.equipment_use == "steelworks" else 600.0
    limit_z = min(data.span_mm / ratio_z, 25.0)
    limit_y = data.span_mm / 600.0
    out["values"].update(vertical_ratio=ratio_z, vertical_absolute_cap_mm=25.0,
                         vertical_limit_mm=limit_z, horizontal_ratio=600.0, horizontal_limit_mm=limit_y)
    definitions = (
        ("vertical", "Flecha vertical no topo do trilho", data.vertical_displacement_mm, limit_z, f"min(L/{ratio_z:g},25 mm)", "Table 4(a)"),
        ("horizontal", "Flecha horizontal no topo do trilho", data.horizontal_displacement_mm, limit_y, "L/600", "Table 4(d)"),
    )
    for identifier, title, displacement, capacity, equation, clause in definitions:
        if displacement is None:
            out["pending"].append(f"Informar {title.lower()} na base de ações qualificada.")
            continue
        demand = abs(displacement)
        utilization = demand / capacity
        out["checks"].append({"id": f"service_10084_{identifier}", "title": title,
                              "status": "ATENDE" if utilization <= 1.0 else "NÃO ATENDE",
                              "demand": demand, "capacity": capacity, "unit": "mm", "utilization": utilization,
                              "source": f"ABNT NBR 10084:2020 §10; {clause}; impressas pp.11-12",
                              "equation": equation, "detail": "Base ELS qualificada; verificação limitada a esta deformação.",
                              "values": {"signed_displacement_mm": displacement, "span_mm": data.span_mm, "case": data.case}})
        out["audit"].append({"id": identifier, "equation": equation, "inputs": {"span_mm": data.span_mm, "equipment_use": data.equipment_use, "signed_displacement_mm": displacement}, "value": capacity, "unit": "mm", "source": "service"})
    out["implemented_checks_complete"] = len(out["checks"]) == 2
    if any(c["status"] == "NÃO ATENDE" for c in out["checks"]):
        out["status"] = "NÃO ATENDE AOS LIMITES IMPLEMENTADOS"
    out["external_responsibilities"] = [
        "Sistema global: diferenças entre vias/apoios, deslocamentos da estrutura e variações de vão, inclusive térmicas, nos demais itens aplicáveis da Tabela 4.",
        "Fabricante/contrato: tolerâncias de fabricação/montagem, folgas roda/trilho e requisitos específicos; nota 1 da Tabela 4. Nenhuma dispensa contratual foi presumida.",
    ]
    return out


def service_limits_10084(data: Service10084Input | dict[str, Any]) -> dict[str, Any]:
    """Strict-JSON-safe, beam-only Table 4(a,d) service evaluator."""
    import json
    try:
        result = _service_limits_10084(data)
        json.dumps(result, allow_nan=False)
        return result
    except (ArithmeticError, ValueError, TypeError) as exc:
        return {"status": "ENTRADA INVÁLIDA", "input_valid": False, "approval": False,
                "implemented_checks_complete": False, "values": {}, "stresses": {}, "checks": [],
                "pending": [f"Entrada fora do domínio numérico finito: {exc}"],
                "sources": {"service": {"standard": "ABNT NBR 10084:2020", "clause": "10; Table 4(a,d)",
                                        "printed_pages": [11, 12], "pdf_pages": [15, 16]}}, "audit": []}
