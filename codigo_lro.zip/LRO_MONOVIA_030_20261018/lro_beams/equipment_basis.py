"""Traceable equipment inputs, separate from runway support geometry.

Catalogs are references, not project certificates. The four-wheel model below
is explicit statics, not an inference of missing crane masses or mechanisms.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict, fields
import hashlib
import json
import math

G_KN_PER_METRIC_TONNE = 9.80665

@dataclass
class EquipmentBasis:
    status: str = 'manual'
    capacity_tf: float | None = None
    bridge_span_m: float | None = None
    reference_record_id: str = ''
    reference_source_url: str = ''
    reference_page: str = ''
    reference_capacity_metric_t: float | None = None
    reference_span_m: float | None = None
    reference_span_min_m: float | None = None
    reference_span_max_m: float | None = None
    reference_span_basis: str = 'exact'
    reference_hoist_model: str = ''
    load_model: str = 'manual_components'
    bridge_mass_kg: float | None = None
    trolley_mass_kg: float | None = None
    hook_approach_m: float | None = None
    wheelbase_m: float | None = None
    transverse_kn_per_wheel: float | None = None
    longitudinal_kn_per_wheel: float | None = None
    transverse_pattern: str = 'same_sign'
    horizontal_basis: str = 'manual'
    horizontal_scenario_id: str = ''
    horizontal_dynamic_factor: float | None = None
    rolling_kn_per_wheel: float | None = None
    assumption_note: str = ''
    classification_scenario: str = 'as_entered'
    applied_wheel_signature: str = ''


def equipment_basis_from_dict(raw):
    if not isinstance(raw, dict) or set(raw) != {f.name for f in fields(EquipmentBasis)}:
        raise ValueError('Campos inválidos na origem dos dados do equipamento.')
    result = EquipmentBasis(**raw)
    errors = equipment_basis_errors(result)
    if errors:
        raise ValueError('; '.join(errors))
    return result


def _finite(value):
    return not isinstance(value, bool) and isinstance(value, (int, float)) and math.isfinite(value) and abs(value) <= 1e12


def equipment_basis_errors(basis):
    if not isinstance(basis, EquipmentBasis):
        return ['Origem dos dados do equipamento inválida.']
    errors = []
    if basis.status not in ('manual', 'reference_only', 'adopted_assumption', 'project_confirmed'):
        errors.append('Situação da origem dos dados inválida.')
    if basis.load_model not in ('manual_components', 'symmetric_four_wheel_bridge'):
        errors.append('Modelo das cargas do equipamento inválido.')
    if basis.transverse_pattern not in ('same_sign','opposed_couple','combined_a','combined_b'):
        errors.append('Padrão das ações transversais inválido.')
    if basis.horizontal_basis not in ('manual','normal_reference'):
        errors.append('Base das ações horizontais inválida.')
    if basis.reference_span_basis not in ('exact','band'):
        errors.append('Base de vão da referência inválida.')
    if basis.classification_scenario not in ('as_entered', 'normative_upper_bounds', 'catalog_speed_hc4'):
        errors.append('Cenário de classificação inválido.')
    for name in ('capacity_tf', 'bridge_span_m', 'reference_capacity_metric_t', 'reference_span_m',
                 'reference_span_min_m', 'reference_span_max_m', 'bridge_mass_kg', 'trolley_mass_kg', 'hook_approach_m', 'wheelbase_m',
                 'transverse_kn_per_wheel', 'longitudinal_kn_per_wheel', 'horizontal_dynamic_factor', 'rolling_kn_per_wheel'):
        value = getattr(basis, name)
        if value is not None and (not _finite(value) or (value <= 0 if name in ('capacity_tf', 'bridge_span_m', 'reference_capacity_metric_t', 'reference_span_m', 'wheelbase_m') else value < 0)):
            errors.append('Equipamento: ' + name + ' fora da faixa.')
    for name in ('reference_record_id', 'reference_source_url', 'reference_page', 'reference_hoist_model', 'horizontal_scenario_id', 'assumption_note', 'applied_wheel_signature'):
        if not isinstance(getattr(basis, name), str) or len(getattr(basis, name)) > 10000:
            errors.append('Equipamento: texto inválido em ' + name + '.')
    if basis.horizontal_basis=='normal_reference':
        if basis.horizontal_scenario_id not in ('HT-A','HT-B') or basis.horizontal_dynamic_factor is None or not _finite(basis.horizontal_dynamic_factor) or basis.horizontal_dynamic_factor<1 or basis.rolling_kn_per_wheel is None:
            errors.append('Cenário horizontal de referência incompleto.')
    if basis.load_model=='symmetric_four_wheel_bridge':
        required=('capacity_tf','bridge_span_m','bridge_mass_kg','trolley_mass_kg','hook_approach_m','wheelbase_m','transverse_kn_per_wheel','longitudinal_kn_per_wheel')
        if any(getattr(basis,key) is None for key in required):
            errors.append('Modelo estático do equipamento exige todas as massas, geometria e ações horizontais declaradas.')
    if basis.reference_span_min_m is not None and basis.reference_span_max_m is not None and _finite(basis.reference_span_min_m) and _finite(basis.reference_span_max_m) and basis.reference_span_min_m>basis.reference_span_max_m:
        errors.append('Faixa de vão de referência invertida.')
    if basis.bridge_span_m is not None and basis.hook_approach_m is not None and _finite(basis.bridge_span_m) and _finite(basis.hook_approach_m):
        if not 0 <= basis.hook_approach_m <= basis.bridge_span_m / 2:
            errors.append('A aproximação do gancho ao caminho próximo deve estar entre zero e metade do vão da ponte.')
    return errors


def wheel_signature(wheels):
    return hashlib.sha256(json.dumps([asdict(w) for w in wheels], sort_keys=True, allow_nan=True).encode()).hexdigest()


def four_wheel_statics(*, capacity_tf, bridge_span_m, bridge_mass_kg, trolley_mass_kg,
                       hook_approach_m, wheelbase_m, transverse_kn_per_wheel, longitudinal_kn_per_wheel, transverse_pattern='same_sign'):
    """Return a correlated near-side wheel pair and independent equilibrium evidence.

    Bridge mass excludes trolley; bridge CG is on the transverse centreline.
    Trolley and payload share the declared transverse action line. Each end
    carriage distributes equally to its two longitudinal wheels. The model is
    one trolley position, not the entire crane's envelope or fatigue duty.
    """
    if transverse_pattern not in ('same_sign','opposed_couple'):
        raise ValueError('Use o construtor de cenários para combinar translação e guiamento.')
    values = locals().copy()
    b = EquipmentBasis(status='adopted_assumption', load_model='symmetric_four_wheel_bridge', **values)
    errors = equipment_basis_errors(b)
    if any(value is None for value in values.values()):
        errors.append('Informe separadamente massas, aproximação, entre-eixos e as duas ações horizontais por roda.')
    if errors:
        raise ValueError('; '.join(errors))
    from .autonomous_model import WheelInput
    ratio = 1.0 - hook_approach_m / bridge_span_m
    bridge_kn = bridge_mass_kg / 1000 * G_KN_PER_METRIC_TONNE
    trolley_kn = trolley_mass_kg / 1000 * G_KN_PER_METRIC_TONNE
    lifted_kn = capacity_tf * G_KN_PER_METRIC_TONNE
    near_dead = bridge_kn / 2 + trolley_kn * ratio
    far_dead = bridge_kn / 2 + trolley_kn * (1-ratio)
    near_lifted = lifted_kn * ratio
    far_lifted = lifted_kn * (1-ratio)
    wheels = [WheelInput(offset_m=x, dead_kn=near_dead/2, lifted_kn=near_lifted/2,
                         transverse_kn=transverse_kn_per_wheel, longitudinal_kn=longitudinal_kn_per_wheel)
              for x in (0.0, wheelbase_m)]
    if transverse_pattern=='opposed_couple':
        wheels[1].transverse_kn=-transverse_kn_per_wheel
    evidence = dict(near_dead_kn=near_dead, far_dead_kn=far_dead, near_lifted_kn=near_lifted,
                    far_lifted_kn=far_lifted, total_dead_kn=bridge_kn+trolley_kn,
                    total_lifted_kn=lifted_kn, near_ratio=ratio,
                    vertical_balance_residual_kn=(near_dead+far_dead-bridge_kn-trolley_kn)+(near_lifted+far_lifted-lifted_kn),
                    dead_moment_residual_kn_m=far_dead*bridge_span_m-(bridge_kn*bridge_span_m/2+trolley_kn*hook_approach_m),
                    lifted_moment_residual_kn_m=far_lifted*bridge_span_m-lifted_kn*hook_approach_m)
    return wheels, evidence


def equipment_basis_summary(project):
    b = project.equipment_basis
    if b.status == 'manual' and b.capacity_tf is None and not b.reference_record_id and b.classification_scenario=='as_entered':
        return []
    labels = {'manual': 'Dados informados diretamente', 'reference_only': 'Referência de catálogo; cargas não alteradas',
              'adopted_assumption': 'Hipótese de projeto adotada; não confirmada pelo fabricante',
              'project_confirmed': 'Dados declarados como confirmados para este projeto'}
    rows = [('Situação', labels[b.status])]
    if b.capacity_tf is not None:
        rows.append(('Capacidade nominal', f'{b.capacity_tf:g} tf = {b.capacity_tf*G_KN_PER_METRIC_TONNE:.3f} kN; tonelada-força métrica'))
        actions=project.action_applicability
        if b.status in ('adopted_assumption','project_confirmed') and actions.test_capacity_t is not None:
            same_capacity=math.isclose(actions.test_capacity_t,b.capacity_tf,rel_tol=1e-9,abs_tol=1e-8)
            rows.append(('Capacidade nominal declarada no ensaio',f'{actions.test_capacity_t:g} t métricas; '+('coincide com a capacidade adotada da ponte.' if same_capacity else f'DIVERGE da capacidade adotada de {b.capacity_tf:g} tf. Revisar antes de usar o ensaio; a adoção do catálogo não alterou este campo nem a sobrecarga p.')))
    if b.bridge_span_m is not None:
        rows.append(('Vão da ponte entre trilhos', f'{b.bridge_span_m:g} m; distinto do vão de {project.span_m:g} m entre apoios da viga'))
    if b.reference_record_id:
        rows.extend([('Registro de referência', b.reference_record_id),
                     ('Fonte', b.reference_source_url + (' · página ' + b.reference_page if b.reference_page else ''))])
        same_span = b.reference_span_m == b.bridge_span_m
        if b.reference_span_basis=='band':
            rows.append(('Faixa de vão da referência', f'{b.reference_span_min_m if b.reference_span_min_m is not None else "limite inferior não publicado"} a {b.reference_span_max_m} m; dados adotados da faixa, sem interpolação.'))
            same_span = same_span or (b.bridge_span_m is not None and b.reference_span_min_m is not None and b.reference_span_max_m is not None and b.reference_span_min_m<=b.bridge_span_m<=b.reference_span_max_m)
        if not same_span or b.reference_capacity_metric_t != b.capacity_tf:
            rows.append(('Correspondência', 'Registro de outra capacidade ou outro vão; sem interpolação ou extrapolação automática.'))
        if b.reference_hoist_model: rows.append(('Carro/talha da referência',b.reference_hoist_model))
    if b.load_model=='symmetric_four_wheel_bridge':
        rows.extend([('Massas adotadas',f'Estrutura SEM carro/talha: {b.bridge_mass_kg:g} kg; carro/talha: {b.trolley_mass_kg:g} kg.'),
                     ('Geometria adotada',f'Aproximação do gancho: {b.hook_approach_m:g} m; entre-eixos longitudinal: {b.wheelbase_m:g} m.')])
        try:
            from .crane_catalog import get_catalog_record,can_propose_physical_reference
            record=get_catalog_record(b.reference_record_id)
            expected=(record.get('bridge_only_mass_kg'),record.get('trolley_mass_kg'),record.get('wheelbase_m'),min(record['hook_approach_left_m'],record['hook_approach_right_m']))
            actual=(b.bridge_mass_kg,b.trolley_mass_kg,b.wheelbase_m,b.hook_approach_m)
            match=can_propose_physical_reference(record,b.capacity_tf,b.bridge_span_m) and all(x is not None and math.isclose(x,y,rel_tol=1e-9,abs_tol=1e-8) for x,y in zip(expected,actual))
        except (ValueError,TypeError,KeyError):match=False
        rows.append(('Origem dos parâmetros físicos','Massas, entre-eixos e aproximação conservam o registro correlacionado; repartição e centro de gravidade são hipóteses do modelo.' if match else 'Parâmetros físicos declarados/editados; não são reprodução integral do registro de catálogo. A base declarada deve justificar as diferenças.'))
    if b.load_model=='symmetric_four_wheel_bridge':
        rows.append(('Ações transversais',{'same_sign':'Mesmo sinal nas duas rodas','opposed_couple':'Binário: sinais opostos nas duas rodas','combined_a':'HT-A: translação do carro + binário (+/−)','combined_b':'HT-B: translação do carro + binário (−/+)'}[b.transverse_pattern]))
    if b.horizontal_basis=='normal_reference':
        rows.append(('Cenário horizontal analisado',b.horizontal_scenario_id+'; cenário complementar '+('HT-B' if b.horizontal_scenario_id=='HT-A' else 'HT-A')+' deve ser calculado separadamente. Sem envelope agregado de fadiga.'))
        rows.append(('Base vertical das ações horizontais','P = G+Q por roda adotado como hipótese de projeto para este cenário.'))
        rows.append(('Fator adicional horizontal',f'{b.horizontal_dynamic_factor:g}; 1 mantém as ações prescritas roda/trilho sem margem adicional. Não é um fator normativo extra obrigatório.'))
    if b.applied_wheel_signature:
        rows.append(('Cargas atuais', 'Conservam a proposta aplicada.' if b.applied_wheel_signature == wheel_signature(project.wheels)
                     else 'Editadas depois da proposta; os valores atuais prevalecem sobre o registro de referência.'))
    if b.classification_scenario == 'normative_upper_bounds':
        rows.append(('Classificação adotada', ('Envelope normativo proposto: A8, E8 e Ψ = 2,22; não é classificação certificada do equipamento.' if project.equipment_group=='A8' and project.fatigue.component_group=='E8_conservative' and project.dynamic_psi_override==2.22 else 'A proposta original era A8/E8/Ψ = 2,22; as classificações ou o fator foram editados depois. Os campos atuais de cálculo prevalecem.')))
    if b.classification_scenario=='catalog_speed_hc4':
        try:
            from .crane_catalog import get_catalog_record,catalog_speed_dynamic
            dynamic=catalog_speed_dynamic(get_catalog_record(b.reference_record_id))
            exact=project.hoist_class=='unselected' and project.drive_class=='unselected' and project.dynamic_psi_override==dynamic['psi'] and project.hoist_speed_m_s==dynamic['nominal_speed_m_s']
        except (ValueError,TypeError,KeyError):exact=False
        if exact:rows.append(('Dinâmica vertical adotada',f'HC4 como hipótese de classe superior; velocidade nominal máxima da referência {project.hoist_speed_m_s:.6g} m/s; Ψ = {project.dynamic_psi_override:.6g}. HC/HD físicos não inferidos; ensaio e grupos A/E permanecem independentes.'))
        else:rows.append(('Dinâmica vertical adotada','A proposta original usava HC4 e a velocidade de catálogo; os campos dinâmicos foram editados depois. Os fatores atuais de cálculo prevalecem.'))
    if b.assumption_note:
        rows.append(('Base declarada', b.assumption_note))
    return rows


def equipment_basis_premises(project):
    b = project.equipment_basis
    out = [label + ': ' + value for label, value in equipment_basis_summary(project)]
    if b.load_model == 'symmetric_four_wheel_bridge':
        out.append('Modelo de quatro rodas: massa da estrutura da ponte exclui o carro, centro de gravidade da estrutura no meio do vão; carro e carga na mesma linha transversal declarada; duas rodas por caminho com repartição longitudinal igual. Ações horizontais têm base própria declarada: entradas manuais ou hipótese normativa adotada, não valores confirmados pelo catálogo.')
        out.append('Cenário estático de um carro próximo ao caminho analisado. G permanece nesta posição nos trechos carregados e vazios do histórico; deslocamento transversal do carro, assimetria entre rodas e outras posições de operação requerem cenários próprios. Não representa envelope certificado de toda a ponte.')
    if b.horizontal_basis=='normal_reference':
        out.append('Ações horizontais de referência para operação normal: todas as rodas longitudinais adotadas como motrizes/freadas; aceleração do carro atribuída integralmente ao caminho analisado e dividida igualmente nas duas rodas; guiamento como binário de sinais opostos. São condições adotadas para fornecimento, não limite universal de qualquer ponte. Ensaio, frenagem de emergência, batente e enviesamento específico exigem qualificação própria. O fator horizontal adicional não substitui as condições físicas das expressões roda/trilho adotadas. O fornecedor deverá compatibilizar as ações efetivas, incluindo dinâmica aplicável, com o modelo contratado.')
    return out
