"""Explicit, fingerprinted coverage of existing calculations; no global approval.

Coverage is a responsible engineer's traceable statement, never inferred from
row existence, stress magnitude, or coincident labels. Local upper envelopes
are kept distinct from real concurrent stress states. The optional component
box uses the existing NBR 8400 material checker at the adverse sign corner;
it adds no action factor and does not repair or extend a structural formula.
"""
from __future__ import annotations
from .signatures import canonical_numbers

from dataclasses import asdict, dataclass, field, fields, is_dataclass
import hashlib
import json
import math
from typing import Any, get_type_hints

from .stress_8400 import elastic_allowables_8400, equivalent_plane_stress

COVERAGE_REVISION = 1
LOCAL_COVERAGE_REQUIREMENT_CODES = ("local_admissible_comparison", "global_local_combination")
CONCURRENT_CONFIRMATION_TEXT = (
    "Confirmo que a memória referenciada identifica os pontos, faces e sinais e demonstra que os casos de tensão selecionados "
    "incluem as parcelas locais calculadas e todos os efeitos globais aplicáveis, concomitantes no mesmo ponto, no mesmo caso "
    "e base de ações, sem nova majoração. A seleção abrange os locais críticos de compressão/torção e ambos os lados de "
    "cisalhamento; máximos de pontos distintos não foram somados como um estado real."
)
BOUND_CONFIRMATION_TEXT = (
    "Adoto explicitamente o envelope conservador para material base em estado plano na região superior da alma. "
    "Os eixos são x longitudinal e y transversal na alma. Os três limites absolutos globais informados abrangem todos os pontos/posições e efeitos aplicáveis (N, flexão biaxial, "
    "cisalhamento, torção e empenamento) no mesmo caso e base das ações locais, sem nova majoração. Valores zero significam "
    "efeitos globalmente nulos justificados na fonte. Confirmo aço/espessura e, se fy/fu>0,70, o ramo com referência 360/510 MPa. "
    "A excedência deste limite superior exige avaliação específica e não comprova falha real."
)
SCOPE_CONFIRMATION_TEXT = (
    "Confirmo que a referência de escopo identifica todos os casos, posições, segmentos, pontos e detalhes necessários ao "
    "escopo calculado declarado e que eles estão representados nos dados atuais. Responsabilidades externas de sistema, "
    "interfaces e ligações permanecem identificadas separadamente; esta declaração não constitui aprovação global."
)
SERVICE_RESPONSIBILITIES = {
    "global_system_service": "Sistema global: diferenças entre vias/apoios, deslocamentos da estrutura e variações de vão, inclusive térmicas (NBR 10084, Tabela 4).",
    "manufacturer_interface_service": "Fabricante/contrato: tolerâncias de fabricação e montagem, folgas roda/trilho e critérios aplicáveis (NBR 10084, Tabela 4, nota 1).",
}


@dataclass
class LocalStressCoverage:
    local_index: int = 0
    stress_indices: list[int] = field(default_factory=list)
    method: str = "concurrent_stress_rows"
    global_abs_sigma_x_mpa: float = 0.0
    global_abs_sigma_y_mpa: float = 0.0
    global_abs_tau_xy_mpa: float = 0.0
    evidence_source: str = ""
    confirmed: bool = False
    input_signature: str = ""


@dataclass
class ServiceExternalEvidence:
    service_index: int = 0
    responsibility: str = ""
    outcome: str = "unverified"
    evidence_source: str = ""
    confirmed: bool = False
    input_signature: str = ""


@dataclass
class ScopeCoverage:
    evidence_source: str = ""
    confirmed: bool = False
    input_signature: str = ""


def _dict(value: Any) -> dict:
    return asdict(value) if is_dataclass(value) else value


def _row_errors(value: Any, cls: type, path: str) -> list[str]:
    value = _dict(value)
    if not isinstance(value, dict) or set(value) != {f.name for f in fields(cls)}:
        return [f"{path}: campos ausentes ou desconhecidos."]
    errors = []
    for name, expected in get_type_hints(cls).items():
        v = value[name]
        ok = True
        if expected is bool:
            ok = type(v) is bool
        elif expected is int:
            ok = type(v) is int and 0 <= v < 100
        elif expected is str:
            ok = isinstance(v, str)
        elif expected is float:
            ok = type(v) in (int, float) and 0 <= v <= 1e12 and math.isfinite(v)
        elif expected == list[int]:
            ok = isinstance(v, list) and len(v) <= 100 and all(type(i) is int and 0 <= i < 100 for i in v)
            if ok:
                ok = len(set(v)) == len(v)
        if not ok:
            errors.append(f"{path}.{name}: tipo ou valor inválido.")
    return errors


def coverage_input_errors(data: Any) -> list[str]:
    if not isinstance(data, dict) or set(data) != {"local_stress", "service_external", "scope"}:
        return ["Cobertura: blocos ausentes ou desconhecidos."]
    errors = _row_errors(data["scope"], ScopeCoverage, "coverage.scope")
    for name, cls in (("local_stress", LocalStressCoverage), ("service_external", ServiceExternalEvidence)):
        rows = data[name]
        if not isinstance(rows, list) or len(rows) > 100:
            errors.append(f"coverage.{name}: lista limitada a 100 registros.")
            continue
        seen = set()
        for i, row in enumerate(rows):
            bad = _row_errors(row, cls, f"coverage.{name}[{i}]")
            errors.extend(bad)
            if bad:
                continue
            row = _dict(row)
            key = row["local_index"] if name == "local_stress" else (row["service_index"], row["responsibility"])
            if key in seen:
                errors.append(f"coverage.{name}: cobertura duplicada para {key}.")
            seen.add(key)
    return errors


def _coerce(value: Any, cls: type):
    errors = _row_errors(value, cls, cls.__name__)
    if errors:
        raise ValueError("; ".join(errors))
    return cls(**_dict(value))


def _evidence_payload(record: Any) -> dict:
    return {k: v for k, v in _dict(record).items() if k not in ("confirmed", "input_signature")}


def _input(blocks: dict, route: str, index: int) -> dict:
    if type(index) is not int or not isinstance(blocks, dict):
        raise ValueError("Referência de caso inválida.")
    rows = blocks.get(route)
    if not isinstance(rows, list) or index < 0 or index >= len(rows) or not isinstance(rows[index], dict):
        raise ValueError(f"Referência inexistente: {route}[{index}].")
    return rows[index]


def _hash(payload: dict, context: str) -> str:
    if not isinstance(context, str) or not context.strip():
        raise ValueError("Contexto atual do projeto obrigatório.")
    return hashlib.sha256(json.dumps(canonical_numbers({"revision": COVERAGE_REVISION, "context": context, **payload}),
                                   ensure_ascii=False, sort_keys=True, allow_nan=False).encode()).hexdigest()


def local_coverage_signature(record, blocks, context_signature: str) -> str:
    record = _coerce(record, LocalStressCoverage)
    return _hash({"kind": "local", "evidence": _evidence_payload(record),
                  "local_input": _input(blocks, "local_10084", record.local_index),
                  "stress_inputs": [_input(blocks, "stress_8400", i) for i in record.stress_indices]}, context_signature)


def service_evidence_signature(record, blocks, context_signature: str) -> str:
    record = _coerce(record, ServiceExternalEvidence)
    return _hash({"kind": "service", "evidence": _evidence_payload(record),
                  "service_input": _input(blocks, "service_10084", record.service_index)}, context_signature)


def scope_coverage_signature(record, blocks, context_signature: str, local_coverages=(), service_evidence=()) -> str:
    record = _coerce(record, ScopeCoverage)
    return _hash({"kind": "scope", "evidence": _evidence_payload(record), "blocks": blocks,
                  "local_coverages": [_dict(r) for r in local_coverages],
                  "service_evidence": [_dict(r) for r in service_evidence]}, context_signature)


def _result() -> dict:
    return {"input_valid": True, "status": "PENDENTE", "coverage_complete": False,
            "calculated_scope_complete": False, "externally_verified": False,
            "full_compliance": False, "approval": False, "errors": [], "pending": [], "checks": [],
            "values": {}, "resolved_requirement_codes": [], "limitations": ["Cobertura declarada e rastreável; não representa aprovação global da estrutura ou de suas ligações."]}


def _evaluated(outputs, blocks, route, index) -> dict:
    rows = [r for r in outputs if r.get("route") == route and r.get("index") == index]
    if len(rows) != 1 or rows[0].get("input") != _input(blocks, route, index):
        raise ValueError(f"Resultado ausente, ambíguo ou desatualizado: {route}[{index}].")
    result = rows[0].get("result", {})
    if result.get("input_valid") is not True or result.get("errors"):
        raise ValueError(f"Caso {route}[{index}] inválido ou incompatível com o projeto atual.")
    return result


def _qualify(record, expected_signature, out):
    if not record.evidence_source.strip():
        out["pending"].append("Identificar memória/relatório e localização da evidência de abrangência e combinação.")
    if record.confirmed is not True:
        out["pending"].append("Confirmação explícita da cobertura e das hipóteses obrigatória.")
    if not record.input_signature or record.input_signature != expected_signature:
        out["pending"].append("Evidência não vinculada aos dados atuais: revisar e requalificar a cobertura.")
    return not out["pending"]


def _summary_check(out, identifier, title, status, detail):
    out["checks"].append({"id": identifier, "title": title, "status": status,
                          "detail": detail, "source": "NBR 10084:2020, 9.1.2/9.1.3 e 10; NBR 8400-2:2019, 5.2.1"})


def evaluate_local_coverage(record, blocks, evaluated_outputs, *, context_signature: str, material: dict) -> dict:
    out = _result()
    try:
        record = _coerce(record, LocalStressCoverage)
        local = _input(blocks, "local_10084", record.local_index)
        result = _evaluated(evaluated_outputs, blocks, "local_10084", record.local_index)
        if not _qualify(record, local_coverage_signature(record, blocks, context_signature), out):
            return out
        if record.method == "concurrent_stress_rows":
            if result.get("local_effects_complete") is not True:
                out["pending"].append("Efeitos locais reais não completos; um limite multirrodas não é um estado concomitante.")
                return out
            if not record.stress_indices:
                out["pending"].append("Selecionar os casos de tensão que a memória vincula aos efeitos locais.")
                return out
            if any((record.global_abs_sigma_x_mpa, record.global_abs_sigma_y_mpa, record.global_abs_tau_xy_mpa)):
                out["pending"].append("Limites globais são exclusivos do método de envelope, não da cobertura de estados reais.")
                return out
            for index in record.stress_indices:
                stress = _input(blocks, "stress_8400", index)
                checked = _evaluated(evaluated_outputs, blocks, "stress_8400", index)
                if stress.get("load_case") != local.get("case"):
                    out["pending"].append(f"Caso de solicitação divergente no vínculo stress_8400[{index}].")
                if stress.get("thickness_mm") != local.get("tw_mm"):
                    out["pending"].append(f"Espessura do material divergente da alma local no vínculo stress_8400[{index}].")
                if not isinstance(material, dict) or any(stress.get(k) != material.get(k) for k in ("fy_mpa", "fu_mpa")):
                    out["pending"].append(f"Material divergente do projeto atual no vínculo stress_8400[{index}].")
                checks = checked.get("checks", [])
                if checked.get("pending") or {c.get("id") for c in checks} != {"sigma_x", "sigma_y", "tau_xy", "equivalent"}:
                    out["pending"].append(f"Verificação de tensões incompleta no vínculo stress_8400[{index}].")
                elif any(c.get("status") not in ("ATENDE", "ATENDE NO DOMÍNIO", "NÃO ATENDE") for c in checks):
                    out["pending"].append(f"Estado não qualificado no vínculo stress_8400[{index}].")
                out["checks"].extend({**c, "id": f"linked_stress_{index}_{c['id']}"} for c in checks)
            if out["pending"]:
                return out
            out["calculated_scope_complete"] = out["externally_verified"] = True
            failure = any(c["status"] == "NÃO ATENDE" for c in out["checks"])
            out["coverage_complete"] = not failure
            out["status"] = "NÃO ATENDE" if failure else "ATENDE À COBERTURA DECLARADA"
            if out["coverage_complete"]:
                out["resolved_requirement_codes"] = list(LOCAL_COVERAGE_REQUIREMENT_CODES)
            out["values"] = {"method": record.method, "local_index": record.local_index,
                             "stress_indices": record.stress_indices, "evidence_source": record.evidence_source}
            _summary_check(out, "local_stress_coverage", "Cobertura local/global declarada", "NÃO ATENDE" if failure else "REGISTRADO",
                           "Casos reais vinculados por memória externa explícita; nenhuma inclusão foi inferida por magnitude ou nome.")
            return out
        if record.method != "conservative_component_bounds":
            out["pending"].append("Método de cobertura não qualificado.")
            return out
        if record.stress_indices:
            out["pending"].append("Envelope usa limites globais explícitos; não reclassificar casos reais selecionados como envelopes.")
            return out
        stresses = result.get("stresses", {})
        if result.get("local_effects_bound_complete") is True:
            local_y = stresses.get("sigma_cz_top_bound_mpa")
            local_tau = stresses.get("tau0xz_top_bound_mpa")
        elif result.get("local_effects_complete") is True and len(stresses.get("wheels", [])) == 1:
            local_y = stresses.get("sigma_cz_top_mpa")
            local_tau = stresses["wheels"][0].get("tau0xz_top_max_abs_mpa")
        else:
            out["pending"].append("Exigir cálculo local completo ou limite multirrodas expressamente qualificado.")
            return out
        if any(type(v) not in (int, float) or not math.isfinite(v) or v < 0 for v in (local_y, local_tau)):
            out["pending"].append("Limites locais completos e finitos obrigatórios.")
            return out
        if not isinstance(material, dict) or not isinstance(material.get("specification"), str) or not material["specification"].strip():
            out["pending"].append("Material atual com fonte e propriedades qualificadas obrigatório.")
            return out
        limits = elastic_allowables_8400(material.get("fy_mpa"), material.get("fu_mpa"), local.get("case"))
        sx = record.global_abs_sigma_x_mpa
        sy = record.global_abs_sigma_y_mpa + local_y
        tau = record.global_abs_tau_xy_mpa + local_tau
        # Adverse opposite normal signs maximize the existing convex plane-stress
        # expression over the symmetric component box. This is not an actual point.
        equivalent = equivalent_plane_stress(sx, -sy, tau)
        for identifier, title, demand, capacity in (
            ("bound_sigma_x", "Limite absoluto normal longitudinal", sx, limits["sigma_a_mpa"]),
            ("bound_sigma_y", "Limite absoluto normal transversal", sy, limits["sigma_a_mpa"]),
            ("bound_tau", "Limite absoluto de cisalhamento", tau, limits["tau_a_mpa"]),
            ("bound_equivalent", "Envelope equivalente de sinais adversos", equivalent, limits["sigma_a_mpa"]),
        ):
            ok = demand <= capacity or math.isclose(demand, capacity, rel_tol=1e-12, abs_tol=1e-12)
            out["checks"].append({"id": identifier, "title": title, "status": "ATENDE" if ok else "PENDENTE",
                                  "demand": demand, "capacity": capacity, "unit": "MPa", "utilization": demand / capacity,
                                  "detail": "ATENDE AO ENVELOPE CONSERVADOR" if ok else "ENVELOPE EXCEDIDO: avaliação específica necessária; não comprova falha real.",
                                  "source": "NBR 10084, 9.1.2/9.1.3; NBR 8400-2, 5.2.1; desigualdade triangular e sinais adversos declarados.",
                                  **({"exceedance_policy": "requires_specific_assessment"} if not ok else {})})
        out["calculated_scope_complete"] = out["externally_verified"] = True
        out["coverage_complete"] = all(c["status"] == "ATENDE" for c in out["checks"])
        out["status"] = "ATENDE AO ENVELOPE CONSERVADOR" if out["coverage_complete"] else "PENDENTE — ENVELOPE EXCEDIDO"
        if out["coverage_complete"]:
            out["resolved_requirement_codes"] = list(LOCAL_COVERAGE_REQUIREMENT_CODES)
        if not out["coverage_complete"]:
            out["pending"].append("O limite superior excedeu a capacidade; fornecer análise específica de estados concomitantes antes de concluir sobre a resistência real.")
        out["values"] = {"method": record.method, "local_index": record.local_index, "local_sigma_y_bound_mpa": local_y,
                         "local_tau_bound_mpa": local_tau, "total_sigma_x_bound_mpa": sx, "total_sigma_y_bound_mpa": sy,
                         "total_tau_bound_mpa": tau, "equivalent_bound_mpa": equivalent,
                         "adverse_corner_mpa": [sx, -sy, tau], "additional_load_multiplier": 1,
                         "evidence_source": record.evidence_source, **limits}
        out["limitations"].append("Envelope superior da alma, material base e estado plano; não é tensão real, histórico de fadiga, verificação de solda ou torção global calculada.")
        return out
    except (ValueError, TypeError, KeyError, OverflowError) as exc:
        out.update(input_valid=False, status="ENTRADA INVÁLIDA")
        out["errors"].append(str(exc))
        return out


def evaluate_service_evidence(record, blocks, evaluated_outputs, *, context_signature: str) -> dict:
    out = _result()
    try:
        record = _coerce(record, ServiceExternalEvidence)
        result = _evaluated(evaluated_outputs, blocks, "service_10084", record.service_index)
        out["calculated_scope_complete"] = result.get("implemented_checks_complete") is True
        out["beam_local_status"] = "NÃO ATENDE" if any(c.get("status") == "NÃO ATENDE" for c in result.get("checks", [])) else ("CALCULADO" if out["calculated_scope_complete"] else "PENDENTE")
        if record.responsibility not in SERVICE_RESPONSIBILITIES:
            out["pending"].append("Responsabilidade externa não identificada.")
            return out
        if not _qualify(record, service_evidence_signature(record, blocks, context_signature), out):
            return out
        if record.outcome not in ("verified", "not_satisfied"):
            out["pending"].append("Resultado externo não verificado; uma fonte preenchida não equivale a atendimento.")
            return out
        out["externally_verified"] = out["coverage_complete"] = record.outcome == "verified"
        out["status"] = "VERIFICADO EXTERNAMENTE" if record.outcome == "verified" else "NÃO ATENDE — EVIDÊNCIA EXTERNA"
        out["values"] = {"service_index": record.service_index, "responsibility": record.responsibility,
                         "outcome": record.outcome, "evidence_source": record.evidence_source}
        _summary_check(out, "external_" + record.responsibility, SERVICE_RESPONSIBILITIES[record.responsibility],
                       "REGISTRADO" if out["externally_verified"] else "NÃO ATENDE", "Conclusão externa declarada; não calculada por este aplicativo. " + record.evidence_source)
        return out
    except (ValueError, TypeError, KeyError) as exc:
        out.update(input_valid=False, status="ENTRADA INVÁLIDA")
        out["errors"].append(str(exc))
        return out


def evaluate_scope_coverage(record, blocks, *, context_signature: str, required_scope_complete: bool,
                            checks, pending, local_coverages=(), service_evidence=()) -> dict:
    """Gate an explicitly declared *computed* scope; external duties stay separate.

    The caller must establish required route/applicability coverage. This helper
    deliberately does not infer FLT/torsion equivalence or completeness from the
    absence of failing rows. Pass every relevant computed check and open issue.
    """
    out = _result()
    try:
        record = _coerce(record, ScopeCoverage)
        signature = scope_coverage_signature(record, blocks, context_signature, local_coverages, service_evidence)
        if not _qualify(record, signature, out):
            return out
        if type(required_scope_complete) is not bool or not isinstance(checks, list) or not isinstance(pending, list):
            raise ValueError("Estado de cobertura do agregador inválido.")
        out["calculated_scope_complete"] = required_scope_complete
        if not required_scope_complete:
            out["pending"].append("Requisitos/casos do escopo calculado ainda incompletos ou fora de domínio.")
        if not checks:
            out["pending"].append("Nenhuma verificação calculada sustenta o escopo declarado.")
        out["pending"].extend(str(p) for p in pending)
        from .result_summary import summarize_checks
        aggregate = summarize_checks(checks, coverage_complete=required_scope_complete, coverage_gaps=out["pending"])
        failure = aggregate["counts"]["failed"] > 0
        out["values"]["scope_summary"] = aggregate
        if aggregate["counts"]["invalid"] or aggregate["counts"]["unsupported"] or aggregate["counts"]["pending"]:
            out["pending"].append("Há verificação pendente, inválida ou fora do domínio no escopo calculado.")
        if aggregate["counts"]["calculated"] == 0:
            out["pending"].append("Nenhuma comparação numérica válida sustenta o escopo declarado.")
        if failure:
            out["status"] = "NÃO ATENDE NO ESCOPO CALCULADO"
        elif aggregate["coverage_complete"] and not out["pending"]:
            out["coverage_complete"] = out["externally_verified"] = True
            out["status"] = "ATENDE AO ESCOPO CALCULADO DECLARADO"
        _summary_check(out, "declared_computed_scope", "Escopo calculado declarado", "NÃO ATENDE" if failure else ("REGISTRADO" if out["coverage_complete"] else "PENDENTE"),
                       "Abrangência confirmada para os dados atuais; responsabilidades externas permanecem separadas. " + record.evidence_source)
        return out
    except (ValueError, TypeError, KeyError) as exc:
        out.update(input_valid=False, status="ENTRADA INVÁLIDA")
        out["errors"].append(str(exc))
        return out
