"""Optional document identity, deliberately outside the numerical project schema."""
from __future__ import annotations
import hashlib
import json

DOCUMENT_FIELDS = {
    'project': 'Projeto / empreendimento',
    'client': 'Cliente',
    'location': 'Local',
    'document_code': 'Código da memória',
    'revision': 'Revisão',
    'element': 'Elemento / trecho verificado',
}


def validate_xml_text(value, label, *, max_length=10000, allow_linebreaks=True):
    """Reject malformed Unicode/XML before JSON signatures or DOCX creation."""
    if not isinstance(value,str) or len(value)>max_length:
        raise ValueError(label+': texto inválido.')
    for char in value:
        code=ord(char)
        allowed=(code in (9,10,13) and allow_linebreaks) or (0x20<=code<=0xD7FF) or (0xE000<=code<=0xFFFD) or (0x10000<=code<=0x10FFFF)
        if not allowed:
            raise ValueError(label+': caractere Unicode/XML não permitido.')
    return value


def validate_document_metadata(raw):
    if not isinstance(raw, dict) or set(raw) - set(DOCUMENT_FIELDS):
        raise ValueError('Identificação documental deve ser um objeto com campos reconhecidos.')
    clean = {}
    for key, value in raw.items():
        validate_xml_text(value,DOCUMENT_FIELDS[key],max_length=500,allow_linebreaks=False)
        if value.strip():
            clean[key] = value.strip()
    return clean


def unpack_project_document(raw):
    if not isinstance(raw, dict):
        raise ValueError('O arquivo deve conter um objeto de projeto JSON, não uma lista ou valor isolado.')
    if 'inputs' in raw:
        allowed={'format','version','inputs','results','document_metadata'}
        if set(raw)-allowed:
            raise ValueError('Campos desconhecidos no envelope do projeto.')
        if 'format' in raw or 'version' in raw:
            if raw.get('format') not in ('LRO_AUTONOMOUS_PROJECT','LRO_AUTONOMOUS_CALCULATION') or type(raw.get('version')) is not int or raw.get('version')!=1:
                raise ValueError('Formato ou versão do envelope de projeto não reconhecido.')
        if 'results' in raw and raw.get('format')!='LRO_AUTONOMOUS_CALCULATION':
            raise ValueError('Resultados só são aceitos no envelope de cálculo identificado; serão ignorados na importação.')
    metadata = validate_document_metadata(raw.get('document_metadata', {}))
    inputs = raw.get('inputs', raw)
    if not isinstance(inputs, dict):
        raise ValueError('O campo inputs deve conter um objeto de projeto JSON.')
    return inputs, metadata


def project_document(project, metadata=None):
    clean = validate_document_metadata({} if metadata is None else metadata)
    if not clean:
        return project.to_dict()
    return {'format': 'LRO_AUTONOMOUS_PROJECT', 'version': 1,
            'inputs': project.to_dict(), 'document_metadata': clean}


def word_cache_signature(input_signature, metadata=None):
    clean = validate_document_metadata({} if metadata is None else metadata)
    if not clean:
        return input_signature
    return input_signature + ':' + hashlib.sha256(json.dumps(clean, sort_keys=True, ensure_ascii=False).encode()).hexdigest()
