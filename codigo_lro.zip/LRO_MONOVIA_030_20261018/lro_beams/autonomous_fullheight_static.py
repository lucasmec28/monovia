"""Composition of the separate full-height nominal functions.

The prescriptive stabilizer does not inherit the old artificial six-resultant
transfer. Bearing is evaluated only at actual vertical support stations.
"""
from copy import deepcopy
from dataclasses import asdict
from math import isfinite
from .autonomous_result import Verification,input_signature
from .autonomous_fullheight_runtime import resolved_detail
from .autonomous_fullheight_detail import (fullheight_prescriptive,fullheight_selfweight_transfer,
    fullheight_bearing_geometry,fullheight_detail_assessment)
from .autonomous_local import stiffener_positions_mm

SOURCE='NBR8800 5.4.3.1.3/Er1 (painel), 5.7.9 (bearing), 6.1/6.2/6.5 (ligações e partes afetadas); detalhe full-height nominal declarado.'
CASE='Envelope ELU'

def _ratio(id_,title,demand,capacity,unit,source=SOURCE,case=CASE,evidence=None,bound=True,mechanism='stiffeners'):
    if any(type(v) not in (int,float) or not isfinite(v) for v in (demand,capacity)) or demand<0 or capacity<=0:raise ValueError('Comparação full-height inválida.')
    ratio=demand/capacity
    return Verification(id_,mechanism,title,'calculated',source,case,demand,capacity,unit,ratio,
        'Verificação executada; atendimento não demonstrado pelo limite suficiente adotado.' if bound and ratio>1 else '',
        dict(evidence or {},conservative_exceedance=bound and ratio>1))


def _summary(id_,title,complete,pending,**evidence):
    return Verification(id_,'stiffeners',title,'calculated' if complete else 'pending',SOURCE,CASE,
        reason='' if complete else '; '.join(pending) or 'Cobertura incompleta.',
        evidence=dict(evidence,verification_complete=complete))


def _component_title(row):
    key=row.get('check_id','componente')
    if 'flange_strip' in key:part='mesa superior' if 'top' in key else 'mesa inferior'
    elif 'receiver' in key:part='material receptor'
    elif 'CJP' in key:part='CJP superior'
    elif 'fillet' in key:part='filetes'
    elif 'block' in key:part='chapa, ruptura em bloco'
    elif 'core' in key or 'stability' in key:part='chapa, estabilidade do núcleo'
    else:part='cortes da chapa'
    if 'rupture' in key:criterion='ruptura'
    elif 'shear' in key or 'fillet_resultant' in key:criterion='cisalhamento'
    elif 'compression' in key:criterion='compressão'
    elif 'tension' in key:criterion='tração'
    elif 'normal' in key:criterion='tensão normal'
    else:criterion='resistência'
    return 'Ligação por peso próprio / mínimo local · '+part+' · '+criterion


def prepare_fullheight_static(p,structural_G_factor):
    d=resolved_detail(p);positions=stiffener_positions_mm(p)
    panels=[b-a for a,b in zip(positions,positions[1:])]
    if not panels:raise ValueError('Família full-height exige ao menos um painel físico.')
    pres=fullheight_prescriptive(d,panels)
    transfer=fullheight_selfweight_transfer(d,structural_G_factor,station_x_mm=0.,station_id='reference_station')
    return dict(kind='autonomous_fullheight_nominal_functions',project_signature=input_signature(p),
        detail=d.to_dict(),geometry_inputs_hash=d.input_signature,positions_mm=list(positions),panels_mm=panels,
        prescriptive=pres,selfweight_reference=transfer,structural_G_factor=structural_G_factor,
        fixed_project_detail=True,proposed_detail=True,station_based=False,approval=False,
        fullheight_function_based=True,source=SOURCE,origin_case_ids=[])


def fullheight_panel_restraint(p,fixed):
    if fixed.get('project_signature')!=input_signature(p):raise ValueError('Detalhe fixo pertence a outras entradas.')
    pres=fixed['prescriptive'];assessment=pres['attachment_assessment']
    checks=[c for connection in fixed['selfweight_reference']['connections'] for case in connection['cases'] for c in case['checks']]
    ready=bool(pres['section_rules_pass'] and pres['nominal_material_numeric_domain_pass'] and not assessment['pending']
        and all(c['passed'] for c in assessment['checks']) and checks and all(c['utilization']<=1 for c in checks))
    return dict(four_edges_supported=False,prescriptive_shear_endpoints_eligible=ready,panels_mm=fixed['panels_mm'],a_max_mm=max(fixed['panels_mm']),
        b_mm=p.section.d_mm-p.section.tf_mm-p.section.bottom_thickness,t_mm=p.section.tw_mm,
        restraint_evidence=dict(verified_by_calculation=False,source=SOURCE,
            supplemental_plate_boundary_pending='Is prescritivo de cisalhamento não demonstra quatro bordas Navier para compressão biaxial.',
            transverse_edges='Pares full-height de função estabilizadora, Is físico mínimo nos recortes e ligações declaradas à alma/mesas; nenhuma reação do trem atribuída ao par.',
            longitudinal_edges='Uniões contínuas alma–mesas: deslocamento local relativo; rotação não fixada.',
            bearing_minimum_not_used_for_panel=True,physical_specification_hash=fixed['geometry_inputs_hash']),
        no_bearing_minimum_applied_to_intermediate=True,stiffener=pres)


def finish_fullheight_static(p,fixed,station_envelope,sweeps,uls_cases):
    if fixed.get('project_signature')!=input_signature(p) or station_envelope.get('project_signature')!=input_signature(p):raise ValueError('Identidade full-height ELU inválida.')
    out=deepcopy(fixed);checks=[];d=resolved_detail(p);pres=out['prescriptive']
    expected={c.id for c in uls_cases}
    if not expected or not expected<=set(sweeps):raise ValueError('Casos ELU ausentes na composição full-height.')
    out['origin_case_ids']=sorted(expected);out['station_envelope']=deepcopy(station_envelope)
    checks.extend((_ratio('fullheight/panel_stockiness','Chapas estabilizadoras: esbeltez local',pres['c_over_t'],pres['c_over_t_limit'],'adimensional',evidence=pres,bound=False),
        _ratio('fullheight/panel_inertia','Chapas estabilizadoras: inércia mínima física nos recortes',pres['Irequired_mm4'],pres['Is_mm4'],'mm4',evidence=pres,bound=False)))
    detail=pres['attachment_assessment']
    checks.append(_summary('fullheight/detail_specification','Detalhamento e interfaces full-height',not detail['pending'] and all(q['passed'] for q in detail['checks']),detail['pending'],detail_assessment=detail))
    for connection in out['selfweight_reference']['connections']:
        for case in connection['cases']:
            for k,row in enumerate(case['checks']):
                checks.append(_ratio('fullheight/G/'+str(connection['side'])+'/'+case['case_id']+'/'+row['check_id'],
                    _component_title(row),
                    row['demand'],row['capacity'],row.get('units',row.get('unit','MPa')),row.get('basis',SOURCE),evidence=row,bound=True))
    expected_sides={-1,1};connections=out['selfweight_reference']['connections']
    g_complete=({q['side'] for q in connections}==expected_sides and len(connections)==2 and all(
        {c['case_id'] for c in q['cases']}=={'real_factored_G','connection_minimum_same_force_line'} and len(q['cases'])==2 and all(c['checks'] for c in q['cases']) for q in connections))
    if not g_complete:raise ValueError('Inventário de peso próprio/ligação mínima incompleto.')
    checks.append(_summary('fullheight/G/coverage','Cobertura da transferência real de peso e mínimo local',True,[],connection_count=2))
    # Same geometry at every station, actual vertical reaction only at supports.
    from .autonomous_local_resistance import bearing_stiffener
    bearing=fullheight_bearing_geometry(d);capacity=bearing_stiffener(p,at_end=True)
    out['bearing_stations']=[]
    for station in station_envelope['stations']:
        if station['kind']=='intermediate':continue
        item=dict(station,geometry=bearing,column_diagnostic=capacity)
        prefix='fullheight/bearing/'+station['station_id']
        checks.extend((_ratio(prefix+'/outstand','Enrijecedor de apoio: largura saliente mínima',bearing['minimum_outstand_mm'],bearing['actual_outstand_mm'],'mm',evidence=item,bound=False),
            _ratio(prefix+'/thickness','Enrijecedor de apoio: espessura mínima',bearing['minimum_thickness_mm'],bearing['actual_thickness_mm'],'mm',evidence=item,bound=False)))
        out['bearing_stations'].append(item)
    from .autonomous_fullheight_concurrent import evaluate_concurrent_fullheight,RESOLVED
    concurrent=evaluate_concurrent_fullheight(p,out,sweeps,uls_cases)
    out['concurrent_components']=concurrent
    checks.append(_summary('fullheight/concurrent/coverage','Cobertura da composição local e do membro',concurrent['complete'],concurrent['pending'],resolved_obligation_ids=list(RESOLVED)))
    for i,row in enumerate(concurrent['checks']):
        checks.append(_ratio('fullheight/concurrent/'+row['check_id'],'Interação nominal local · '+{'plate':'chapa','beam_web':'alma','beam_top_flange':'mesa superior','beam_bottom_flange':'mesa inferior'}[row['material_role']]+(' · tensão normal' if row['check_id'].endswith('/normal') else ' · cisalhamento'),row['demand'],row['capacity'],'MPa',row['source'],evidence=row,bound=True))
    unresolved=[v for v in out['selfweight_reference']['pending'] if v.split(':',1)[0] not in RESOLVED]
    pending=list(station_envelope.get('pending',[]))+unresolved
    reaction_receipt_complete=station_envelope.get('complete') is True and not station_envelope.get('pending')
    if not reaction_receipt_complete:pending.append('reaction_receipt: envoltória funcional incompleta, mesmo sem mensagem de pendência.')
    from .autonomous_stiffener_actions import stiffener_station_geometry
    from .autonomous_fullheight_actions import _bearing_interval
    if type(station_envelope.get('snapshot_count')) is not int or station_envelope['snapshot_count']<1:raise ValueError('Contagem da envoltória funcional ausente/inválida.')
    expected_stations={v['station_id']:v for v in stiffener_station_geometry(p)}
    rows=station_envelope.get('stations',[])
    if len(rows)!=len(expected_stations) or {r['station_id'] for r in rows}!=set(expected_stations):raise ValueError('Cobertura de estações ELU incompleta.')
    for r in rows:
        if r.get('project_signature')!=input_signature(p):raise ValueError('Estação ELU pertence a outras entradas.')
        e=expected_stations[r['station_id']]
        if r['x_m']!=e['x_m'] or r['kind']!=e['kind']:raise ValueError('Identidade física da estação ELU incompatível.')
        interval=_bearing_interval(r)
        if (interval is None)!=(e['kind']=='intermediate'):raise ValueError('Intervalo bearing incompatível com função física.')
        if interval is not None and interval[0]<0:
            reaction_receipt_complete=False
            pending.append(r['station_id']+': intervalo inclui arrancamento fora do bearing compressivo.')
        if r.get('complete') is not True or r.get('pending') or r.get('bearing_additional_actions') or r.get('receiver_additional_nominal_fields'):
            reaction_receipt_complete=False
            pending.append(r['station_id']+': recibo funcional incompleto ou ação adicional não coberta.')
    # Bearing consumer is a distinct function, never inferred for intermediates.
    try:
        from .autonomous_fullheight_bearing import evaluate_fullheight_bearing
    except ImportError:
        evaluate_fullheight_bearing=None
    for station in out['bearing_stations']:
        if evaluate_fullheight_bearing is None:
            pending.append(station['station_id']+': consumidor bearing nominal ainda não integrado.')
            continue
        bearing_result=evaluate_fullheight_bearing(d,station['bearing_abs_bound_kn']*1000,structural_G_factor=out['structural_G_factor'],station_id=station['station_id'],station_x_mm=station['x_m']*1000,gamma_a1=p.material.gamma_a1,
            reaction_source='Envoltória das reações verticais originais nos casos ELU completos, já incluindo G estacionário.')
        station['result']=bearing_result
        adapted=dict(out,selfweight_reference=dict(connections=[dict(side=side,cases=[q for q in bearing_result['plate_cases'] if q['side']==side]) for side in (-1,1)]))
        bearing_concurrent=evaluate_concurrent_fullheight(p,adapted,sweeps,uls_cases)
        station['concurrent_components']=bearing_concurrent
        resolved={'receiver_member_interaction','plate_normal_shear_interaction'}
        if reaction_receipt_complete:resolved.add('reaction_receipt')
        pending.extend(v for v in bearing_result.get('pending',[]) if v.split(':',1)[0] not in resolved)
        for j,row in enumerate(bearing_concurrent['checks']):
            checks.append(_ratio('fullheight/bearing/'+station['station_id']+'/concurrent/'+row['check_id'],'Apoio: interação local com o membro · '+{'plate':'chapa','beam_web':'alma','beam_top_flange':'mesa superior','beam_bottom_flange':'mesa inferior'}[row['material_role']],row['demand'],row['capacity'],'MPa',row['source'],evidence=row,bound=True))
        checks.append(_summary('fullheight/bearing/'+station['station_id']+'/coverage','Cobertura do apoio nominal',not any(v.split(':',1)[0] not in resolved for v in bearing_result.get('pending',[])),[v for v in bearing_result.get('pending',[]) if v.split(':',1)[0] not in resolved],reaction_bound_kn=station['bearing_abs_bound_kn'],project_signature=input_signature(p)))
        for i,row in enumerate(bearing_result.get('checks',[])):
            checks.append(_ratio('fullheight/bearing/'+station['station_id']+'/component/'+row['check_id'],'Enrijecedor de apoio · '+_component_title(row).replace('Ligação por peso próprio / mínimo local · ',''),row['demand'],row['capacity'],row.get('units','N'),row.get('source',SOURCE),evidence=row,bound=True))
    from .autonomous_fullheight_obligations import required_fullheight_static_ids
    required=set(required_fullheight_static_ids(p));present={c.id for c in checks}
    if not required<=present:raise ValueError('Comparações full-height obrigatórias ausentes: '+str(sorted(required-present)))
    out['pending']=list(dict.fromkeys(pending));out['checks']=[q.id for q in checks]
    out['complete']=not out['pending'];out['detail_feasible']=out['complete'] and all(q.utilization is None or q.utilization<=1 for q in checks)
    checks.append(_summary('coverage/stiffener_detail','Cobertura das funções reais dos enrijecedores',out['complete'],out['pending'],function_based=True))
    return out,checks


def fullheight_shear_verifications(p,case,sweep,fixed):
    from top_unstiffened_candidate.stiffeners.shear import SteelShearInput,shear_resistance
    s=p.section;m=p.material
    steel=SteelShearInput(d_mm=s.d_mm,web_thickness_mm=s.tw_mm,clear_web_depth_mm=s.d_mm-s.tf_mm-s.bottom_thickness,
        E_MPa=m.E_mpa,fy_MPa=m.fy_mpa,gamma_a1=m.gamma_a1)
    qualified=fullheight_panel_restraint(p,fixed)['prescriptive_shear_endpoints_eligible'];rows=[];checks=[]
    for i,a in enumerate(fixed['panels_mm']):
        metric='fullheight_panel_shear/'+str(i)
        if metric not in sweep.maxima:raise ValueError('Demanda regional de cisalhamento ausente: '+metric)
        demand=abs(sweep.maxima[metric].value)
        capacity=shear_resistance(steel,panel_length_mm=a,panel_stiffeners_prescriptively_eligible=qualified)
        rows.append(dict(panel_index=i,panel_length_mm=a,demand_kn=demand,capacity=asdict(capacity)))
    for side,length in (('left',p.beam_end_left_mm),('right',p.beam_end_right_mm)):
        if length:
            metric='fullheight_tail_shear/'+side
            if metric not in sweep.maxima:raise ValueError('Cisalhamento da projeção sem crédito ausente.')
            rows.append(dict(panel_index=side,panel_length_mm=length,demand_kn=abs(sweep.maxima[metric].value),capacity=asdict(shear_resistance(steel))))
    for row in rows:
        cap=row['capacity'];capacity=cap['VRd_N']/1000
        checks.append(_ratio('fullheight/shear/'+str(row['panel_index'])+'/'+case.id,'Cisalhamento vertical por região',row['demand_kn'],capacity,'kN',cap['source'],case.id,row,bound=True,mechanism='combined_yield'))
    critical=max(checks,key=lambda c:c.utilization)
    checks.append(_ratio('shear_vertical/'+case.id,'Cisalhamento vertical da alma: região governante',critical.demand,critical.capacity,'kN',critical.source,case.id,
        {'regions':rows,'both_qualified_boundaries_required':True,'outside_regions_without_stiffener_credit':True},bound=True,mechanism='combined_yield'))
    return checks
