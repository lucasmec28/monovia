"""Qualified exclusion of free-flange compression under true continuous restraint.

This is not a brace design or a calculated infinite LTB capacity. NBR8800
5.4.2.4 directs FLT demand to the greatest moment compressing the free flange;
the use here is an explicitly selected practical method under NBR8400-2 5.3.
Discrete lacing, rail clips and a mere short Lb never satisfy this contract.
"""
from dataclasses import dataclass,asdict
from .stress_8400 import _type_errors
from .normative_report_labels import LABELS

@dataclass
class ContinuousRestraint8400Input:
    name: str = 'Exclusão de FLT por contenção contínua'
    load_case: str = 'I'
    action_basis: str = 'unqualified'
    restraint_kind: str = 'unqualified'
    restrained_flange: str = 'top'
    moment_min_knm: float = 0.0
    moment_max_knm: float = 0.0
    axial_force_kn: float = 0.0
    moment_minor_knm: float = 0.0
    torsion_knm: float = 0.0
    member_segment: str = ''
    envelope_source: str = ''
    action_source: str = ''
    continuity_geometry_source: str = ''
    restraint_strength_source: str = ''
    restraint_stiffness_source: str = ''
    anchorage_source: str = ''
    method_selection_source: str = ''
    entire_segment_envelope_confirmed: bool = False
    action_case_qualified: bool = False
    factors_already_applied: bool = False
    actual_continuous_connection_confirmed: bool = False
    lateral_and_torsional_restraint_qualified: bool = False
    strength_stiffness_and_anchorage_verified: bool = False
    symmetric_i_confirmed: bool = False
    practical_method_selected: bool = False
    no_other_free_flange_compression_confirmed: bool = False


def calculate_continuous_restraint_8400(data):
    source='ABNT NBR 8400-2:2019, 5.3; método prático declarado: ABNT NBR 8800:2024, 5.4.2.4, pp.55–56'
    out={'input_valid':True,'status':'PENDENTE','checks':[],'pending':[],'errors':[],
         'source':source,'full_compliance':False,'intermediates':{},'input':{},
         'limitations':['Exclusão apenas da FLT associada à compressão da mesa livre, neste trecho e caso.',
                        'Não calcula resistência infinita nem dimensiona treliçamento ou suas ligações.',
                        'Tensões, estabilidade local, torção/distorção, rodas, fadiga e demais casos exigem verificações próprias.']}
    errors=_type_errors(data,ContinuousRestraint8400Input)
    if errors:out.update(input_valid=False,errors=errors,status='ENTRADA INVÁLIDA');return out
    out['input']=asdict(data)
    if data.moment_min_knm>data.moment_max_knm:
        out.update(input_valid=False,errors=['Mínimo do envelope deve ser menor ou igual ao máximo.'],status='ENTRADA INVÁLIDA');return out
    if data.load_case not in ('I','II','III') or data.restrained_flange not in ('top','bottom'):
        out.update(input_valid=False,errors=['Caso ou mesa desconhecido.'],status='ENTRADA INVÁLIDA');return out
    if data.restraint_kind!='continuous' or any(v!=0 for v in (data.axial_force_kn,data.moment_minor_knm,data.torsion_knm)):
        out.update(status='FORA DO DOMÍNIO',pending=['Exige contenção realmente contínua e N=My=T=0; treliçamento discreto não se enquadra.']);return out
    if data.action_basis!='nbr8400_cases':out['pending'].append('Qualificar ações próprias dos casos I/II/III, sem conversão de ELU.')
    for name,value in asdict(data).items():
        if name.endswith('_source') or name=='member_segment':
            if not value.strip():out['pending'].append('Informar evidência: '+LABELS.get(name,name)+'.')
        if isinstance(value,bool) and not value:out['pending'].append('Confirmação pendente: '+LABELS.get(name,name)+'.')
    free_demand=max(0.,-data.moment_min_knm) if data.restrained_flange=='top' else max(0.,data.moment_max_knm)
    out['intermediates']={'free_flange_compression_moment_knm':free_demand,'moment_min_knm':data.moment_min_knm,'moment_max_knm':data.moment_max_knm}
    if free_demand>0:
        out['pending'].append('Há momento que comprime a mesa livre. Esta exclusão de FLT não se aplica; verificar a mesa livre com seu comprimento destravado e condição de carga.')
    if out['pending']:return out
    out['status']='EXCLUSÃO QUALIFICADA NO CASO'
    out['checks'].append({'id':'continuous_free_flange','title':'Mesa livre sem compressão por flexão no envelope qualificado',
        'status':'INFORMATIVO','source':source,'demand':0.,'unit':'kN.m','capacity':None,'utilization':None,
        'equation':'Mesa superior contida: Mlivre=max(0,−Mmin); mesa inferior contida: Mlivre=max(0,Mmax).',
        'detail':'Envelope e contenção contínua qualificados externamente. O modo de FLT da mesa livre não é solicitado neste caso; não se atribui resistência infinita.'})
    return out
