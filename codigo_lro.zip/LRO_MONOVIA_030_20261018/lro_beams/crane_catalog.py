"""Correlated manufacturer references. No interpolation, inference or approval."""
from __future__ import annotations
from copy import deepcopy
from dataclasses import asdict
from functools import lru_cache
from pathlib import Path
import json
import math

@lru_cache(maxsize=1)
def _dataset():
    data = json.loads((Path(__file__).parent/'data'/'crane_catalog_records.json').read_text())
    ids = [r['record_id'] for r in data['records']]
    if len(ids) != len(set(ids)):
        raise ValueError('Identificadores duplicados no catálogo de pontes.')
    for row in data['records']:
        for key in ('capacity_metric_t', 'bridge_span_m', 'wheelbase_m'):
            if not isinstance(row.get(key), (int,float)) or isinstance(row[key],bool) or not math.isfinite(row[key]) or row[key] <= 0:
                raise ValueError('Registro de catálogo inválido: '+row['record_id'])
        if not row.get('source_url','').startswith('https://'):
            raise ValueError('Fonte do registro de catálogo ausente.')
    return data


def list_catalog_records():
    return deepcopy(_dataset()['records'])


def get_catalog_record(record_id):
    for row in _dataset()['records']:
        if row['record_id'] == record_id:
            return deepcopy(row)
    raise ValueError('Registro de ponte não encontrado: '+str(record_id))


def select_references(capacity_tf, bridge_span_m, *, allow_uprated=False):
    for value,name in ((capacity_tf,'Capacidade'),(bridge_span_m,'Vão da ponte')):
        if isinstance(value,bool) or not isinstance(value,(float,int)) or not math.isfinite(value) or value <= 0:
            raise ValueError(name+': informe um número positivo.')
    records = list_catalog_records()
    exact = [r for r in records if math.isclose(r['capacity_metric_t'], capacity_tf, abs_tol=1e-8)]
    if allow_uprated:
        # Only explicit neighboring rated comparisons, not an invented conversion.
        next_ratings = sorted({r['capacity_metric_t'] for r in records if r['capacity_metric_t'] > capacity_tf})
        if next_ratings:
            exact += [r for r in records if r['capacity_metric_t'] == next_ratings[0]]
    result = []
    for row in exact:
        row['capacity_match'] = math.isclose(row['capacity_metric_t'],capacity_tf,abs_tol=1e-8)
        row['span_match'] = span_is_supported(row,bridge_span_m)
        row['span_match_type'] = ('band' if row.get('bridge_span_is_row_upper_bound') and row.get('bridge_span_min_m') is not None else 'exact') if row['span_match'] else 'none'
        peers = [r['bridge_span_m'] for r in exact if r['manufacturer']==row['manufacturer'] and r['family']==row['family'] and r['capacity_metric_t']==row['capacity_metric_t']]
        row['project_within_series_span'] = min(peers) <= bridge_span_m <= max(peers)
        result.append(row)
    return sorted(result,key=lambda r:(not r['capacity_match'],not (r['span_match'] and r.get('physical_reference_inputs_complete')),not r['span_match'],abs(r['bridge_span_m']-bridge_span_m),r['manufacturer'],r['family'],r['record_id']))


def span_is_supported(record, span):
    if record.get('bridge_span_is_row_upper_bound'):
        lo,hi=record.get('bridge_span_min_m'),record.get('bridge_span_max_m')
        # '-20 ft' has no stated lower endpoint; only the explicit upper endpoint is used.
        return (lo is not None and lo-1e-8<=span<=hi+1e-8) or math.isclose(span,hi,abs_tol=1e-8)
    return math.isclose(record['bridge_span_m'],span,abs_tol=1e-8)


def can_propose_physical_reference(record, capacity_tf, span):
    return (record.get('physical_reference_inputs_complete') is True and
            math.isclose(record['capacity_metric_t'],capacity_tf,abs_tol=1e-8) and
            span_is_supported(record,span) and record.get('bridge_mass_excludes_trolley') is True and
            record.get('wheels_per_rail')==2 and not record.get('hoist_option_starred'))


def reference_rows(record):
    def fmt(value,unit='',digits=3):
        return 'Não informado' if value is None else f'{value:.{digits}f}'.rstrip('0').rstrip('.')+' '+unit
    return [
        ('Fabricante / família', record['manufacturer']+' / '+{'single_girder_top_running':'ponte univiga','double_girder_top_running':'ponte dupla-viga'}.get(record['family'],record['family'])),
        ('Capacidade do registro',fmt(record['capacity_metric_t'],'t métricas')),
        ('Vão da ponte no registro', (('Extremo superior publicado: '+fmt(record['bridge_span_max_m'],'m')+'; limite inferior ausente, sem extrapolação.') if record.get('bridge_span_min_m') is None else ('Faixa publicada: '+str(record.get('bridge_span_catalog_raw'))+'; limites numéricos '+str(record.get('bridge_span_min_m'))+' a '+str(record.get('bridge_span_max_m'))+' m')) if record.get('bridge_span_is_row_upper_bound') else fmt(record['bridge_span_m'],'m')),
        ('Modelo de carro/talha',record.get('hoist_model','Não informado')),
        ('Massa da estrutura SEM carro/talha',fmt(record.get('bridge_only_mass_kg'),'kg')),
        ('Massa do carro/talha',fmt(record.get('trolley_mass_kg'),'kg')),
        ('Entre-eixos longitudinal das rodas',fmt(record.get('wheelbase_m'),'m')),
        ('Massa indicada da ponte',fmt(record.get('crane_mass_kg'),'kg')),
        ('Definição da massa', {'Crane weight kg (approx); trolley inclusion not explicitly resolved':'Peso aproximado da ponte; inclusão do carro não esclarecida.'}.get(record.get('mass_definition'),record.get('mass_definition','Sem massa independente de estrutura/carro.'))),
        ('Carga de roda publicada',fmt(record.get('pmax_kN'),'kN')+' · referência, definição ver fonte'),
        ('Máxima estática da família',fmt(record.get('source_family_pmax_static_kN'),'kN')+' · variante de talha não identificada'),
        ('Rmín publicado',fmt(record.get('pmin_kN'),'kN')+' · não equivale à roda descarregada'),
        ('Aproximação do gancho esquerda / direita',fmt(record.get('hook_approach_left_m'),'m')+' / '+fmt(record.get('hook_approach_right_m'),'m')),
        ('Data / edição',str(record.get('source_date') or 'Não indicada')),
        ('Fonte',record['source_url']+' · página PDF '+str(record['source_pdf_page'])),
    ]


def make_reference_basis(project, record, capacity_tf, bridge_span_m):
    from .equipment_basis import EquipmentBasis
    return EquipmentBasis(status='reference_only',capacity_tf=capacity_tf,bridge_span_m=bridge_span_m,
        reference_record_id=record['record_id'],reference_source_url=record['source_url'],
        reference_page=str(record['source_pdf_page']),reference_capacity_metric_t=record['capacity_metric_t'],
        reference_span_m=record['bridge_span_m'],reference_span_min_m=record.get('bridge_span_min_m'),
        reference_span_max_m=record.get('bridge_span_max_m'),reference_span_basis='band' if record.get('bridge_span_is_row_upper_bound') and record.get('bridge_span_min_m') is not None else 'exact',
        reference_hoist_model=record.get('hoist_model',''),
        assumption_note='Referência correlacionada de catálogo. Nenhum peso, reação ou classe do fabricante foi convertido em carga de projeto. Entradas da viga preservadas.')


def project_diff(before,after):
    """Whole-field diff: arrays stay correlated; unknown data are never discarded."""
    a,b=before.to_dict(),after.to_dict()
    return [(key,a[key],b[key]) for key in a if a[key] != b[key]]


def catalog_reference_project(project, record, capacity_tf, bridge_span_m, *, scenario_id='HT-A', dynamic_factor=1.):
    """Explicit opt-in adopted reference, used by UI/QA; preserves support model."""
    from .equipment_basis import four_wheel_statics,wheel_signature
    from .crane_horizontal_reference import apply_horizontal_reference
    if not can_propose_physical_reference(record,capacity_tf,bridge_span_m):
        raise ValueError('Registro sem correspondência física/capacidade/faixa para esta proposta.')
    p=deepcopy(project)
    approach=min(record['hook_approach_left_m'],record['hook_approach_right_m'])
    p.wheels,evidence=four_wheel_statics(capacity_tf=capacity_tf,bridge_span_m=bridge_span_m,
        bridge_mass_kg=record['bridge_only_mass_kg'],trolley_mass_kg=record['trolley_mass_kg'],
        hook_approach_m=approach,wheelbase_m=record['wheelbase_m'],transverse_kn_per_wheel=0.,longitudinal_kn_per_wheel=0.)
    b=make_reference_basis(p,record,capacity_tf,bridge_span_m)
    b.status='adopted_assumption';b.load_model='symmetric_four_wheel_bridge'
    b.bridge_mass_kg=record['bridge_only_mass_kg'];b.trolley_mass_kg=record['trolley_mass_kg']
    b.hook_approach_m=approach;b.wheelbase_m=record['wheelbase_m']
    b.transverse_kn_per_wheel=0.;b.longitudinal_kn_per_wheel=0.;b.applied_wheel_signature=wheel_signature(p.wheels)
    b.assumption_note='Hipótese de fornecimento baseada em '+record['record_id']+'. Massas separadas publicadas; repartição simétrica, carro na linha do gancho e menor aproximação E/F. Vão na faixa publicada, sem interpolação. Equipamento real deve ser compatibilizado pelo fornecedor com as ações e condições adotadas.'
    p.equipment_basis=b
    p,horizontal=apply_horizontal_reference(p,scenario_id,dynamic_factor=dynamic_factor)
    return p,dict(vertical_equilibrium=evidence,horizontal=horizontal)


def catalog_speed_dynamic(record):
    """Upper HC class at the published maximum nominal hoist speed; not duty inference."""
    from .autonomous_actions import HoistDynamics,compute_hoist_dynamic
    speeds=record.get('hoist_speeds_m_min')
    if not isinstance(speeds,list) or not speeds or any(isinstance(v,bool) or not isinstance(v,(int,float)) or not math.isfinite(v) or v<=0 for v in speeds):
        raise ValueError('Este registro não fornece velocidade de elevação nominal utilizável.')
    vmax=max(speeds)/60.
    source=f"{record['record_id']} · {record['source_url']} · página {record['source_pdf_page']}"
    result=compute_hoist_dynamic(HoistDynamics('HC4','HD1',vmax,None,'HC4 e velocidade efetiva nominal adotadas como envelope: '+source))
    return dict(psi=result['psi'],nominal_speed_m_s=vmax,published_speed_options_m_min=list(speeds),
        adopted_hoist_class='HC4',effective_speed_m_s=result['effective_speed_m_s'],source=source,
        assumption='Classe HC4 adotada como limite superior entre HC1–HC4; velocidade nominal máxima publicada adotada como limite da velocidade efetiva normal. HD real não inferido; nenhuma conversão de classe da talha em grupo A/E.')


def apply_catalog_speed_dynamic(project,record):
    p=deepcopy(project);d=catalog_speed_dynamic(record)
    if p.equipment_basis.reference_record_id!=record['record_id']:
        raise ValueError('A velocidade deve pertencer ao mesmo registro físico da proposta.')
    p.dynamic_psi_override=d['psi'];p.hoist_class='unselected';p.drive_class='unselected'
    p.hoist_speed_m_s=d['nominal_speed_m_s'];p.creep_speed_m_s=0.
    p.factor_basis=(d['assumption']+' Velocidades publicadas (opções): '+', '.join(f'{x:g}' for x in d['published_speed_options_m_min'])+
        f" m/min; máximo adotado {d['nominal_speed_m_s']:.8g} m/s; Ψ = 1,20 + 0,68 × min(v, 1,5) = {d['psi']:.8g}. "+d['source']+
        '. HC4 é hipótese da sugestão operacional, não classe física certificada; campos físicos HC/HD permanecem não selecionados. Ensaios permanecem com elegibilidade, método e coeficiente próprios; eventos extraordinários não são inferidos.')
    p.equipment_basis.classification_scenario='catalog_speed_hc4'
    return p,d


def apply_catalog_test_speed_envelope(project,record,*,regular_lifting_adopted=False):
    """Explicit separate proposal; never copy operational Psi or event eligibility."""
    from dataclasses import replace
    from .autonomous_actions import HoistDynamics,compute_test_dynamic,TEST_CLASS_ENVELOPE_METHOD
    if regular_lifting_adopted is not True:
        raise ValueError('A proposta exige adoção explícita de elevação regular para o ensaio.')
    if project.equipment_basis.reference_record_id!=record['record_id']:
        raise ValueError('Adote primeiro este registro para a ponte; a velocidade de ensaio deve manter a mesma referência.')
    from .equipment_basis import four_wheel_statics
    basis=project.equipment_basis
    if (basis.status not in ('adopted_assumption','project_confirmed') or
            basis.load_model!='symmetric_four_wheel_bridge' or
            basis.capacity_tf is None or not math.isclose(basis.capacity_tf,record['capacity_metric_t'],rel_tol=1e-9)):
        raise ValueError('Adote primeiro as cargas da ponte desta capacidade e confira as rodas; uma referência documental ou rodas editadas não vinculam Q ao ensaio.')
    expected,_=four_wheel_statics(capacity_tf=basis.capacity_tf,bridge_span_m=basis.bridge_span_m,
        bridge_mass_kg=basis.bridge_mass_kg,trolley_mass_kg=basis.trolley_mass_kg,
        hook_approach_m=basis.hook_approach_m,wheelbase_m=basis.wheelbase_m,
        transverse_kn_per_wheel=0.,longitudinal_kn_per_wheel=0.)
    if len(project.wheels)!=len(expected) or any(not math.isclose(getattr(w,key),getattr(e,key),rel_tol=1e-9,abs_tol=1e-8)
            for w,e in zip(project.wheels,expected) for key in ('offset_m','dead_kn','lifted_kn')):
        raise ValueError('G/Q ou posições de roda divergem da estática da capacidade declarada. Revise a ponte antes da proposta de ensaio; ações H têm cenário independente.')
    p=deepcopy(project);d=catalog_speed_dynamic(record)
    source=(f"Velocidade nominal máxima de ensaio adotada {d['nominal_speed_m_s']:.8g} m/s, "
            'a partir das opções publicadas '+', '.join(f'{v:g}' for v in d['published_speed_options_m_min'])+' m/min; '+d['source']+
            '. Requisito de fornecimento para elevação regular; não é confirmação do equipamento instalado.')
    source+=f" Capacidade nominal adotada para o ensaio: {basis.capacity_tf:g} t métricas, vinculada à carga Q da proposta aplicada; sobrecarga p preservada."
    p.action_applicability=replace(p.action_applicability,test_dynamic_method=TEST_CLASS_ENVELOPE_METHOD,test_capacity_t=basis.capacity_tf,
        test_nominal_speed_m_s=d['nominal_speed_m_s'],test_speed_source=source,test_regular_lifting_adopted=True)
    dynamic=compute_test_dynamic(HoistDynamics(p.hoist_class,p.drive_class,d['nominal_speed_m_s'],source=source),TEST_CLASS_ENVELOPE_METHOD)
    return p,dynamic


def correlated_vertical_comparison(records, capacity_tf, bridge_span_m, support_span_m):
    """Cheap exact M/R for each correlated symmetric static reference, not approval.

    Two equal downward wheels on an isolated simply supported runway span.
    G+Q is reconstructed only from the physical row, never family Pmax.
    No dynamics, support selfweight, horizontal effects or interaction envelope.
    """
    from .equipment_basis import four_wheel_statics
    if isinstance(support_span_m,bool) or not isinstance(support_span_m,(int,float)) or not math.isfinite(support_span_m) or support_span_m<=0:
        raise ValueError('Vão entre apoios deve ser positivo e finito para comparar referências.')
    L=support_span_m;out=[]
    for row in records:
        if not can_propose_physical_reference(row,capacity_tf,bridge_span_m):continue
        wheels,_=four_wheel_statics(capacity_tf=capacity_tf,bridge_span_m=bridge_span_m,
            bridge_mass_kg=row['bridge_only_mass_kg'],trolley_mass_kg=row['trolley_mass_kg'],
            hook_approach_m=min(row['hook_approach_left_m'],row['hook_approach_right_m']),
            wheelbase_m=row['wheelbase_m'],transverse_kn_per_wheel=0.,longitudinal_kn_per_wheel=0.)
        G,Q=wheels[0].dead_kn,wheels[0].lifted_kn;P=G+Q;d=row['wheelbase_m']
        M=max(P*L/4.,P*(2*L-d)**2/(8*L) if d<=2*L/3 else 0.)
        out.append(dict(record_id=row['record_id'],family=row['family'],hoist_model=row['hoist_model'],
            dead_per_wheel_kn=G,lifted_per_wheel_kn=Q,static_per_wheel_kn=P,wheelbase_m=d,
            major_moment_max_knm=M,reaction_max_kn=P*max(1.,2-d/L),
            scope='Modelo simétrico correlacionado; vertical estático da ponte isolada, sem fatores nem peso da viga.'))
    return out
