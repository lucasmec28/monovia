"""Bounded bottom-flange nominal stresses with external concomitant fields.

NBR10084 §9.1.4 supplies the parallel-flange nominal local mechanics and its
local-X 0.75 combination in the NBR route. No EN plastic resistance or
EN factor is transferred to NBR. No implicit capacity-to-wheel conversion.
"""
from dataclasses import asdict
from copy import deepcopy
import math
from itertools import product
from .underslung_local_model import validate_project
from .underslung_flange_kernel import Geometry,Action,local_stresses,close_wheel_stresses,coefficients,DomainError
from .stress_8400 import Stress8400Input,calculate_stress_8400,equivalent_plane_stress,elastic_allowables_8400,_check as _nbr_check

SOURCE='ABNT NBR 10084:2020 §9.1.4, Tabela 2 (mesas paralelas); modelo nominal correspondente EN 1993-6:2007+AC:2009 §5.8'
LIMITATIONS=[
    'Resultado limitado aos pontos/estados ou ao domínio do envelope explicitamente fornecido; não aprova a viga completa nem demonstra por si que todos os casos críticos foram fornecidos.',
    'Permanecem separados: estabilidade global/local, torção/empenamento globais, continuidade, flechas, vibração e caminho de forças na alma e nas mesas.',
    'Suspensão por parafusos, efeito de alavanca, mesa superior, vigas de piso e suas ligações não são dimensionados nesta rota.',
    'Contato roda–mesa, pressão tridimensional, desgaste e folgas de passagem permanecem pendentes; o plano estrutural nominal não elimina pressão de contato.',
    'Fadiga exige histórias locais/globais no mesmo ponto e detalhes/ciclos qualificados; máximos estáticos não substituem essa avaliação.',
    'Enrijecedores parciais não recebem crédito de travamento ou de enrijecedor de altura total.',
]


def _criteria(project,state,total,point_label,*,bounding_vertex=False):
    """Evaluate a real tensor OR a mathematical corner of a qualified box.

    The latter is never a claimed physical simultaneous state: the caller proves
    set inclusion and the convex criteria are evaluated at its synthetic vertices.
    No physical-history claim or action factor follows from this internal call.
    """
    if state.action_basis=='nbr8400' and bounding_vertex:
        # Public numerical allowance and signed VM helpers, with wrapper guards;
        # no synthetic vertex is represented as a physically concurrent input.
        result=dict(checks=[],errors=[],pending=[],bounding_vertex=True)
        try:
            limits=elastic_allowables_8400(project.fy_mpa,project.fu_mpa,state.nbr_case)
            eq=equivalent_plane_stress(*total)
        except ValueError as exc:
            result['pending']=[str(exc)];return result
        if limits['fy_fu_ratio']>.70 and not project.high_ratio_route_confirmed:
            result['pending']=['Qualifique o ramo 5.2.1.1.2 com aço de referência 360/510 MPa.'];return result
        result['checks']=[
            _nbr_check('sigma_x','Tensão normal x',abs(total[0]),limits['sigma_a_mpa'],limits['formula'],limits['clause']),
            _nbr_check('sigma_y','Tensão normal y',abs(total[1]),limits['sigma_a_mpa'],limits['formula'],limits['clause']),
            _nbr_check('tau_xy','Cisalhamento xy',abs(total[2]),limits['tau_a_mpa'],'tau_a = sigma_a / sqrt(3)','5.2.1.2'),
            _nbr_check('equivalent','Envelope da tensão equivalente',eq,limits['sigma_a_mpa'],'VM nos vértices do retângulo de tensões','5.2.1.3')]
        result['intermediates']=dict(limits,sigma_eq_mpa=eq)
        return result
    if state.action_basis=='nbr8400':
        data=Stress8400Input(name=state.name,load_case=state.nbr_case,fy_mpa=project.fy_mpa,fu_mpa=project.fu_mpa,
            thickness_mm=project.bottom_tf_mm,sigma_x_mpa=total[0],sigma_y_mpa=total[1],tau_xy_mpa=total[2],
            point_id=point_label,material_source=project.material_source,
            stress_source=state.global_source+'; '+SOURCE+('; vértice matemático de envelope qualificado, não estado físico' if bounding_vertex else ''),
            action_basis='nbr8400_cases',action_source=state.combination_id+'; '+state.action_source,
            factors_source=state.factors_source,same_point_concurrent=state.same_state_confirmed,
            action_case_qualified=state.action_case_qualified,plane_stress_confirmed=project.plane_stress_nominal_confirmed,
            base_material_confirmed=project.base_material_points_confirmed,factors_already_applied=state.factors_already_applied,
            high_ratio_route_confirmed=project.high_ratio_route_confirmed)
        return calculate_stress_8400(data)
    allowable=project.fy_mpa/state.en_gamma_mser
    if not math.isfinite(allowable) or allowable<=0:
        return dict(checks=[],errors=[],pending=['Resistência admissível EN fora do domínio numérico finito; reveja material e gamma_M,ser.'])
    measures=(('sigma_x','Tensão normal x',abs(total[0]),allowable),('sigma_y','Tensão normal y',abs(total[1]),allowable),
        ('tau_xy','Cisalhamento xy',abs(total[2]),allowable/math.sqrt(3)),('equivalent','Tensão equivalente',equivalent_plane_stress(*total),allowable))
    checks=[dict(id=k,name=name,demand=d,capacity=c,utilization=d/c,unit='MPa',
        status='ATENDE NO DOMÍNIO' if d<=c or math.isclose(d,c,rel_tol=1e-12,abs_tol=1e-12) else 'NÃO ATENDE',
        source='EN 1993-6:2007 §7.5(3), 7.2a,b,d; '+state.en_gamma_source) for k,name,d,c in measures]
    return dict(checks=checks,errors=[],pending=[],allowable_mpa=allowable,gamma_mser=state.en_gamma_mser)


def calculate_local_project(project):
    validate_project(project)
    out=dict(input_signature=project.signature(),status='DADOS PENDENTES',whole_beam_complete=False,
        local_scope_complete=False,states=[],checks=[],pending=[],limitations=list(LIMITATIONS),
        sources=[SOURCE,'ABNT NBR 8400-2:2019, versão corrigida 2022, §5.2.1.1–3, quando explicitamente selecionada'],
        equipment_kind='underslung_bridge',factor_policy='A carga individual final é convertida de kN para N uma única vez. Nenhum fator dinâmico/de ação ou repartição é aplicado pelo adaptador.')
    missing=[name for name in ('bottom_b_mm','bottom_tf_mm','web_tw_mm','edge_to_contact_n_mm') if getattr(project,name) is None]
    if project.construction=='unselected':missing.append('construction')
    if project.construction=='rolled' and project.root_radius_mm is None:missing.append('root_radius_mm')
    if project.construction=='welded' and project.weld_throat_mm is None:missing.append('weld_throat_mm')
    if missing:
        out['pending']=['Geometria real ainda não informada: '+', '.join(missing)+'.'];return out
    try:
        # An inactive historical editor value is not part of the chosen section.
        geometry=Geometry(project.bottom_b_mm,project.web_tw_mm,project.bottom_tf_mm,project.edge_to_contact_n_mm,
            project.construction,(project.root_radius_mm or 0.) if project.construction=='rolled' else 0.,
            (project.weld_throat_mm or 0.) if project.construction=='welded' else 0.,project.straight_parallel_i_confirmed)
    except DomainError as exc:
        out['pending']=['Domínio geométrico: '+str(exc)];return out
    out['geometry']=dict(asdict(geometry),mu=geometry.mu,m_mm=geometry.m_mm)
    for index,state in enumerate(project.states):
        envelope=state.global_input_mode=='section_envelope'
        row=dict(name=state.name,state='pending',pending=[],local_stresses=[],combined_points=[],input=asdict(state),
            global_input_mode=state.global_input_mode,outstand_side='both' if envelope else state.outstand_side)
        out['states'].append(row)
        def pending(reason,point=None,face=None):
            text=state.name+': '+reason
            if text not in out['pending']:out['pending'].append(text)
            if reason not in row['pending']:row['pending'].append(reason)
            if point is not None:
                key=f'state/{index}/point/{point}/{face}/pending/{len(row["pending"])}'
                out['checks'].append(dict(id=key,state='pending',title='Combinação local/global',
                    state_name=state.name,point=point,face=face,demand=None,capacity=None,unit='MPa',utilization=None,reason=reason))
        if any(v is None for v in state.wheel_actions_kn) or state.distance_to_physical_end_mm is None:
            pending('Informe as ações individuais das rodas e a distância à extremidade física.');continue
        if not state.action_source.strip() or not state.combination_id.strip():
            pending('Identifique a fonte da carga e a combinação/estado concomitante.');continue
        provenance=state.combination_id+'; '+state.action_source+'; '+state.factors_source
        actions=[Action(v*1000.,'mechanical','mechanical',provenance) for v in state.wheel_actions_kn]
        try:
            if len(actions)==1:
                local=local_stresses(geometry,actions[0],distance_to_nearest_end_mm=state.distance_to_physical_end_mm,
                    symmetric_opposite_wheels_confirmed=state.equal_opposite_wheels_confirmed,
                    nearest_longitudinal_spacing_mm=state.nearest_longitudinal_spacing_mm,
                    isolated_longitudinal_station_confirmed=state.isolated_station_confirmed)
            else:
                if state.nearest_longitudinal_spacing_mm is None:
                    if not state.isolated_station_confirmed:raise DomainError('Confirme que o grupo contém todas as rodas próximas ou informe a distância à roda externa mais próxima.')
                elif state.nearest_longitudinal_spacing_mm<1.5*geometry.bottom_b_mm:
                    raise DomainError('Há roda externa próxima omitida do grupo; inclua todas as rodas dentro do agrupamento longitudinal.')
                if any(v is None for v in state.longitudinal_spacings_mm):raise DomainError('Espaçamentos reais do grupo de rodas ausentes.')
                local=close_wheel_stresses(geometry,actions,state.longitudinal_spacings_mm,
                    distance_to_nearest_end_mm=state.distance_to_physical_end_mm,
                    symmetric_opposite_wheels_confirmed=state.equal_opposite_wheels_confirmed)
        except (DomainError,ArithmeticError) as exc:
            pending('Domínio do modelo local: '+str(exc));continue
        if any(not math.isfinite(v) or abs(v)>1e12 for pair in local for v in pair):
            pending('Tensões locais fora do domínio numérico finito do modelo; reveja unidades/geometria/ações.');continue
        row['local_stresses']=[dict(point=i,sigma_x_mpa=sx,sigma_y_mpa=sy,face='bottom',top_face_rule='Ambas as componentes locais trocam de sinal.') for i,(sx,sy) in enumerate(local)]
        row['state']='mechanical_only'
        # Every wheel retains its correlated contact geometry. The absolute sum
        # is an adopted §5.8 nominal component bound, not a 3-D plate theorem.
        magnitudes=[(sum(abs(cx*a.individual_wheel_N/geometry.bottom_tf_mm**2) for a in actions),
                     sum(abs(cy*a.individual_wheel_N/geometry.bottom_tf_mm**2) for a in actions)) for cx,cy in coefficients(geometry.mu)]
        common=[]
        if state.action_basis not in ('nbr8400','en_service'):common.append('Selecione explicitamente a base de verificação; as tensões locais são apenas mecânicas.')
        if not project.supplemental_model_adopted:common.append('Adote explicitamente o modelo elástico nominal complementar e seu domínio restrito.')
        if not state.global_effects_complete:common.append('Qualifique o campo global incluindo todos os efeitos aplicáveis, inclusive torção/empenamento quando presentes.')
        if not state.global_source.strip():common.append('Informe a fonte do campo global externo.')
        if not project.material_source.strip() or project.fy_mpa is None:common.append('Informe material, fy e fonte para a espessura real.')
        if not project.plane_stress_nominal_confirmed or not project.base_material_points_confirmed:common.append('Qualifique os pontos de material-base e o plano de tensão nominal; contato e soldas permanecem separados.')
        if not state.factors_already_applied or not state.factors_source.strip() or not state.action_case_qualified:common.append('Qualifique o caso e registre os fatores já incluídos exatamente uma vez nas ações.')
        if len(actions)>1 and not state.cluster_component_envelope_adopted:common.append('Adote explicitamente o envelope de componentes locais do grupo conforme o modelo simplificado §5.8(8); a soma assinada isolada não qualifica cancelamento favorável.')
        if state.action_basis=='nbr8400' and project.fu_mpa is None:common.append('Informe fu para a verificação NBR 8400.')
        if state.action_basis=='en_service' and (state.en_gamma_mser is None or not state.en_gamma_source.strip()):common.append('Informe gamma_M,ser e sua fonte explícita para a rota EN de serviço.')
        if envelope:
            if not state.envelope_coverage_confirmed or not state.envelope_scope_source.strip():common.append('Qualifique a cobertura do envelope global: ambos os balanços, ambas as faces e todos os pontos/posições relevantes do mesmo caso.')
            if not state.envelope_load_geometry_confirmed:common.append('Qualifique as cargas individuais como limites superiores e a geometria/domínio em todas as posições cobertas pelo envelope.')
            if not state.coordinate_source.strip():common.append('Informe os eixos e sinais dos limites globais.')
            if any(v is None for bounds in state.global_component_bounds.values() for v in bounds):common.append('Informe mínimo e máximo assinados das três componentes globais.')
        else:
            if state.outstand_side=='unselected':common.append('Identifique o lado físico do balanço da mesa; os seis pontos não representam automaticamente o outro lado.')
            if not state.same_state_confirmed:common.append('Qualifique tensões globais concomitantes no mesmo estado físico.')
            if state.section_x_m is None or state.wheel_translation_m is None or not state.coordinate_source.strip():common.append('Identifique a seção física, posição longitudinal das rodas e eixos/sinais.')
        for reason in common:pending(reason)
        global_points={(r['point'],r['face']):r for r in state.global_points}
        for point,(lx,ly) in enumerate(local):
            for face,sign in ((('both',1.),) if envelope else (('bottom',1.),('top',-1.))):
                label=f'P{point}/{face}; '+state.coordinate_source
                if envelope:
                    if any(v is None for bounds in state.global_component_bounds.values() for v in bounds):continue
                    gb=state.global_component_bounds;mx,my=magnitudes[point]
                    bounds={'sigma_x_mpa':[gb['sigma_x_mpa'][0]-mx,gb['sigma_x_mpa'][1]+mx],
                        'sigma_y_mpa':[gb['sigma_y_mpa'][0]-my,gb['sigma_y_mpa'][1]+my],'tau_mpa':list(gb['tau_mpa'])}
                    combined=dict(point=point,face='both',outstand_side='both',envelope=True,
                        global_component_bounds=deepcopy(gb),local_component_bounds={'sigma_x_mpa':[-mx,mx],'sigma_y_mpa':[-my,my]},total_component_bounds=bounds,
                        local_combination_policy='Caixa local simétrica não reduzida contém a parcela longitudinal 0,75 da NBR; não presume cancelamento favorável.',
                        envelope_basis='Limites de componentes cobrindo ambos os balanços/faces; vértices matemáticos, não estados concomitantes ou história de fadiga.')
                else:
                    glob=global_points[(point,face)]
                    if any(glob[k] is None for k in ('sigma_x_mpa','sigma_y_mpa','tau_mpa')):
                        pending('Componente global ausente no ponto '+str(point)+' / face '+face+'.',point,face);continue
                    factor_x=0.75 if state.action_basis=='nbr8400' else 1.0
                    total=(glob['sigma_x_mpa']+factor_x*sign*lx,glob['sigma_y_mpa']+sign*ly,glob['tau_mpa'])
                    combined=dict(point=point,face=face,outstand_side=state.outstand_side,global_sigma_x_mpa=glob['sigma_x_mpa'],global_sigma_y_mpa=glob['sigma_y_mpa'],
                        global_tau_mpa=glob['tau_mpa'],local_sigma_x_mpa=sign*lx,local_sigma_y_mpa=sign*ly,
                        local_longitudinal_multiplier=factor_x,local_transverse_multiplier=1.0,
                        combination_source='NBR10084 §9.1.4: sigma_cx = sigma_x + 0.75 sigma_0x' if factor_x==0.75 else 'EN nominal unreduced combination',
                        sigma_x_mpa=total[0],sigma_y_mpa=total[1],tau_mpa=total[2],state_identity=dict(combination_id=state.combination_id,
                        section_x_m=state.section_x_m,wheel_translation_m=state.wheel_translation_m,coordinate_source=state.coordinate_source,outstand_side=state.outstand_side))
                    if len(actions)>1:
                        mx,my=magnitudes[point]
                        bounds={'sigma_x_mpa':[glob['sigma_x_mpa']-mx,glob['sigma_x_mpa']+mx],
                            'sigma_y_mpa':[glob['sigma_y_mpa']-my,glob['sigma_y_mpa']+my],'tau_mpa':[glob['tau_mpa']]*2}
                        combined.update(envelope=True,local_component_bounds={'sigma_x_mpa':[-mx,mx],'sigma_y_mpa':[-my,my]},total_component_bounds=bounds,
                            envelope_basis='Envelope das componentes locais do grupo: a soma algébrica é apenas diagnóstico, não cancelamento favorável qualificado.')
                row['combined_points'].append(combined)
                if common:combined['state']='diagnostic_only';continue
                if combined.get('envelope'):
                    corners=list(dict.fromkeys(product(bounds['sigma_x_mpa'],bounds['sigma_y_mpa'],bounds['tau_mpa'])))
                    checks_by_id={};vertices=[]
                    for corner in corners:
                        try:result=_criteria(project,state,corner,label,bounding_vertex=True)
                        except (ValueError,ArithmeticError) as exc:result=dict(checks=[],errors=[],pending=[str(exc)])
                        vertex=dict(sigma_x_mpa=corner[0],sigma_y_mpa=corner[1],tau_mpa=corner[2])
                        vertices.append(dict(vertex=vertex,method_result=result))
                        for reason in result['errors']+result['pending']:pending(reason,point,face)
                        for check in result['checks']:
                            old=checks_by_id.get(check['id'])
                            if old is None or check['utilization']>old['utilization']:checks_by_id[check['id']]=dict(check,governing_vertex=vertex)
                    checks=list(checks_by_id.values());combined['vertex_results']=vertices
                    combined['governing_vertices']={c['id']:c['governing_vertex'] for c in checks}
                else:
                    try:result=_criteria(project,state,total,label)
                    except (ValueError,ArithmeticError) as exc:result=dict(checks=[],errors=[],pending=[str(exc)])
                    combined['method_result']=result
                    for reason in result['errors']+result['pending']:pending(reason,point,face)
                    checks=result['checks']
                for check in checks:
                    verdict=check['status']
                    item=dict(id=f"state/{index}/point/{point}/{face}/"+check['id'],state='calculated',title=check['name'],
                        status=verdict,passed=verdict!='NÃO ATENDE',state_name=state.name,point=point,face=face,
                        outstand_side=combined['outstand_side'],demand=check['demand'],capacity=check['capacity'],unit=check['unit'],
                        utilization=check['utilization'],reason='Comparação local nominal nos estados/limites externos declarados; não qualifica a viga completa.',source=check['source'])
                    if 'governing_vertex' in check:item['governing_vertex']=check['governing_vertex']
                    out['checks'].append(item)
                combined['state']='calculated' if checks else 'pending'
        row['scope']='Envelope qualificado cobrindo ambos os balanços e faces no domínio documentado.' if envelope else 'Seis pontos/face no balanço '+state.outstand_side+'; o outro balanço exige estado próprio.'
        expected=3 if envelope else 6
        if not row['pending'] and len(row['combined_points'])==expected and all(x.get('state')=='calculated' for x in row['combined_points']):row['state']='calculated'
    out['local_scope_complete']=bool(out['states']) and all(s['state']=='calculated' for s in out['states'])
    failed=any(c['state']=='calculated' and c['status']=='NÃO ATENDE' for c in out['checks'])
    if failed:out['status']='RESULTADO LOCAL PARCIAL · NÃO ATENDE'
    elif any(c['state']=='calculated' for c in out['checks']):out['status']='RESULTADO LOCAL PARCIAL'
    elif any(s['local_stresses'] for s in out['states']):out['status']='TENSÕES LOCAIS MECÂNICAS · VERIFICAÇÃO PENDENTE'
    return out
