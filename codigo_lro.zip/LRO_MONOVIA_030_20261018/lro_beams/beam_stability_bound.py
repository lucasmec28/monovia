"""Lower elastic FLT reference bound retaining actual lateral brace geometry.

Pure major-flexure reference (N=0), not a general pre-twisted-state eigenvalue.
The physical energy is the sourced model in beam_stability.py. The numerical
bound is a derivation: finite-rank geometric operator + a Parseval/trace tail
norm, with exact Green compliance for lateral springs/constraints. It is NOT
an assumption that a converged finite Ritz eigenvalue is conservative.

Units N/mm/MPa. Rounding allowances are explicit engineering safeguards, not
an interval-arithmetic certificate. See review_autonomous_torsion.md §9.
"""
from functools import lru_cache
import math
import numpy as np
from .beam_torsion import VlasovBeam,LateralBrace,_point_kernel,_bending_green
from .beam_stability import _validate,conservative_reference_bound


class BraceBoundNumericalError(ValueError):
    """No numerical credit may be taken for this brace flexibility."""


@lru_cache(maxsize=2048)
def _moments_cached(shape,frequency_bytes,degree):
    frequency=np.frombuffer(frequency_bytes,dtype=np.float64).reshape(shape)
    result=_moments_uncached(frequency,degree)
    # Bytes-backed storage cannot be made writable by setflags(write=True).
    # Only small default-mode arrays enter this bounded geometry-only cache.
    return tuple(value.tobytes() for value in result)


def _moments(w,degree):
    """Reuse identical geometry-only integrals, preserving all floating bits."""
    frequency=np.asarray(w,dtype=float)
    if frequency.size>1024 or not 0<=degree<=4:
        return _moments_uncached(frequency,degree)
    stored=_moments_cached(frequency.shape,frequency.tobytes(),degree)
    # Each caller gets new immutable views; reshaping a returned array cannot
    # change another call's shape or poison the internal cache.
    return tuple(np.frombuffer(value,dtype=np.complex128).reshape(frequency.shape) for value in stored)


def _moments_uncached(w,degree):
    """Exact exponential polynomial integrals int_0^1 t^j exp(i*w*t) dt.

    A convergent Taylor evaluation near zero avoids recurrence cancellation.
    Away from zero integration by parts is stable for degree <=4.
    """
    w=np.asarray(w,dtype=float);out=[];small=np.abs(w)<1
    z=1j*w;safe=np.where(small,1j,z);ez=np.exp(z)
    prev=np.expm1(z)/safe
    for j in range(degree+1):
        if j:prev=ez/safe-j*prev/safe
        value=prev.copy();term=np.ones_like(z,dtype=complex);series=term/(j+1)
        for k in range(1,30):
            term=term*z/k;series+=term/(j+k+1)
        value=np.where(small,series,value);out.append(value)
    return out


def _cos_integral(coeff,w,phase,length):
    values=_moments(w,len(coeff)-1)
    return length*np.real(np.exp(1j*phase)*sum(c*v for c,v in zip(coeff,values)))


def _sin_products(coeff,x0,x1,ks):
    h=x1-x0
    difference=ks[:,None]-ks[None,:];total=ks[:,None]+ks[None,:]
    return .5*(_cos_integral(coeff,difference*h,difference*x0,h)-
               _cos_integral(coeff,total*h,total*x0,h))


def _tail_trace(beam,n):
    """Upper sum_{j>n} 1/(ECw*k_j^4+GJ*k_j^2), integral comparison."""
    L=beam.span_mm
    return min((L/math.pi)**4/(3*beam.ECw*n**3),
               (L/math.pi)**2/(beam.GJ*n))


def _point_modal_tail(beam,x,n,tail):
    """Positive upper bound of the omitted diagonal sine Green series.

    Gtail=(2/L) sum(j>n) sin(kj*x)^2/(ECw*kj^4+GJ*kj^2).
    sin^2<=1 gives 2*tail_trace/L. With delta=min(x,L-x),
    |sin(kj*x)|<=kj*delta and sum(j>n)j^-2<=1/n give
    2*delta^2*L/(ECw*pi^2*n). Both are upper bounds; take their
    minimum with the declared relative floating-point allowance. This avoids
    subtracting two nearly equal Green/modal values near a fork entirely.
    """
    L=beam.span_mm;delta=min(x,L-x)
    return min(2*tail/L,2*delta*delta*L/(beam.ECw*math.pi**2*n))*(1+1e-10)


def _point_sines(ks,x,L):
    """Sine modes reflected about the nearer fork before argument reduction."""
    if x<=L/2:return np.sin(ks*x)
    return np.sin(ks*(L-x))*np.where(np.arange(len(ks))%2==0,1.,-1.)


@lru_cache(maxsize=128)
def _structure(beam,Iy,braces,n):
    L=beam.span_mm;EI=beam.E_mpa*Iy
    ks=np.arange(1,n+1,dtype=float)*math.pi/L
    dv=EI*ks**4*L/2;dt=(beam.ECw*ks**4+beam.GJ*ks**2)*L/2
    if not np.all(np.isfinite(dv)) or not np.all(np.isfinite(dt)):raise ValueError('Nonfinite modal stiffness')
    T=np.eye(2*n);condition=1.;compliance_error=0.
    if braces:
        xs=np.array([b.x_mm for b in braces]);zs=np.array([b.height_from_cs_mm for b in braces])
        S=np.sin(ks[:,None]*xs)
        R=np.vstack((S/np.sqrt(dv[:,None]),S*zs/np.sqrt(dt[:,None])))
        F=np.array([[_bending_green(a.x_mm,b.x_mm,L)/EI+
            a.height_from_cs_mm*b.height_from_cs_mm*_point_kernel(beam,a.x_mm,b.x_mm)[0]
            for b in braces] for a in braces])
        for j,b in enumerate(braces):
            if b.stiffness_n_per_mm is not None:F[j,j]+=1/b.stiffness_n_per_mm
        scales=np.sqrt(np.diag(F));Fn=F/scales[:,None]/scales[None,:]
        condition=float(np.linalg.cond(Fn))
        if not np.all(np.isfinite(Fn)) or condition>1e8:
            raise BraceBoundNumericalError('Dependent or ill-conditioned physical brace constraints')
        try:chol=np.linalg.cholesky(Fn)
        except np.linalg.LinAlgError as exc:raise BraceBoundNumericalError('Physical brace flexibility is not positive definite') from exc
        Rn=R/scales
        W=np.linalg.solve(chol,Rn.T);X=np.linalg.solve(chol.T,W)
        T-=W.T@W
        # Positive majorant of the exact compliance compression. A residual
        # bound covers the linear solve. A disclosed 1e-12 relative kernel/
        # input allowance is propagated by the SPD inverse perturbation bound.
        # This is an engineering guard, not interval-certified libm arithmetic.
        f_norm=float(np.linalg.norm(Fn,ord='fro'));r_norm=float(np.linalg.norm(Rn,ord='fro'))
        f_error=1e-12*f_norm;r_error=1e-12*r_norm
        minimum=float(np.linalg.eigvalsh(Fn)[0])-100*np.finfo(float).eps*f_norm
        if minimum<=f_error:raise BraceBoundNumericalError('Brace inverse perturbation is not qualified')
        residual=float(np.linalg.norm(Fn@X-Rn.T,ord='fro'))
        solve_error=r_norm*residual/minimum+float(np.linalg.norm(W.T@W-Rn@X,ord='fro'))
        inverse_error=r_norm*r_norm*f_error/(minimum*(minimum-f_error))
        load_error=(2*r_norm*r_error+r_error*r_error)/(minimum-f_error)
        compliance_error=solve_error+inverse_error+load_error+1e-12
    T=(T+T.T)/2;ev,Z=np.linalg.eigh(T)
    if ev[0]<-compliance_error-1e-10 or ev[-1]>1+compliance_error+1e-10:
        raise BraceBoundNumericalError('Brace compliance lost positive contraction property')
    # T_true <= T_calculated + eT*I. Inflate BEFORE taking its square root;
    # an O(eT) eigenvalue allowance alone is unsafe near a null constraint.
    root=(Z*np.sqrt(np.maximum(ev+compliance_error,0)))@Z.T
    # Never mutate arrays shared by this cache.
    for a in (ks,dv,dt,root):a.setflags(write=False)
    return ks,dv,dt,root,condition,compliance_error


def _one_bound(beam,Iy,segments,points,lines,braces,n):
    L=beam.span_mm;EI=beam.E_mpa*Iy
    ks,dv,dt,Troot,condition,compliance_error=_structure(beam,Iy,braces,n)
    C=np.zeros((n,n));parseval=0.
    for s in segments:
        c=s.major_left_nmm;b=-3*c+4*s.major_mid_nmm-s.major_right_nmm
        a=2*c-4*s.major_mid_nmm+2*s.major_right_nmm
        coeff=np.array([c,b,a]);square=np.convolve(coeff,coeff)
        C+=_sin_products(coeff,s.x0_mm,s.x1_mm,ks)
        h=s.x1_mm-s.x0_mm
        sin2=.5*(h*sum(v/(j+1) for j,v in enumerate(square))-
                   _cos_integral(square,2*ks*h,2*ks*s.x0_mm,h))
        parseval+=float(np.sum(sin2/(EI*dt)))
    C*=math.sqrt(2/(EI*L))/np.sqrt(dt)[None,:]
    finite_squared=float(np.sum(C*C));M=max(s.max_abs_moment() for s in segments)
    tail=_tail_trace(beam,n);cross_tail=M*M/EI*tail
    allowance=1e-10*(abs(parseval)+finite_squared+cross_tail)
    remainder=parseval-finite_squared
    if remainder < -allowance:raise BraceBoundNumericalError('Parseval remainder is numerically negative; modal brace credit is not qualified')
    delta_cross=math.sqrt(max(0.,remainder)+cross_tail+allowance)
    Q=np.zeros((2*n,2*n));Q[:n,n:]=C;Q[n:,:n]=C.T
    height_tail=0.;height_terms=0
    for p in points:
        weight=max(0.,p.vertical_down_n*p.height_from_cs_mm)
        if not weight or p.x_mm in (0,L):continue
        u=_point_sines(ks,p.x_mm,L)/np.sqrt(dt);low=float(u@u)
        high=_point_modal_tail(beam,p.x_mm,n,tail)
        # Exact norm of [0, u*v'; v*u', v*v'] with orthogonal low/tail vectors.
        height_tail+=weight*.5*(high+math.hypot(high,2*math.sqrt(low*high)))
        Q[n:,n:]+=weight*np.outer(u,u);height_terms+=1
    for p in lines:
        weight=max(0.,p.vertical_down_n_per_mm*p.height_from_cs_mm)
        if not weight:continue
        I=_sin_products((1.,),p.x0_mm,p.x1_mm,ks)
        H=I/np.sqrt(dt[:,None]*dt[None,:]);low=max(0.,float(np.trace(H)))
        high=2*(p.x1_mm-p.x0_mm)/L*tail
        # Triangle/Cauchy bound on the integrated low/tail block operator.
        height_tail+=weight*(2*math.sqrt(low*high)+high)
        Q[n:,n:]+=weight*H;height_terms+=1
    if not np.all(np.isfinite(Q)):raise ValueError('Nonfinite geometric operator')
    reduced=Troot@Q@Troot;reduced=(reduced+reduced.T)/2
    projected=max(0.,float(np.linalg.eigvalsh(reduced)[-1]))
    matrix_rounding=max(1e-10,100*np.finfo(float).eps*condition)*float(np.linalg.norm(Q,ord='fro'))
    delta=delta_cross+height_tail+matrix_rounding
    upper=projected+delta
    if not all(math.isfinite(v) for v in (upper,projected,delta)):raise ValueError('Nonfinite operator bound')
    factor=1/upper if upper>0 else None
    return dict(modes_per_field=n,load_factor_lower_bound=factor,
        projected_reciprocal_factor=projected,tail_norm_upper=delta,
        cross_tail_norm_upper=delta_cross,height_tail_norm_upper=height_tail,
        inverse_factor_upper_bound=upper,height_terms=height_terms,brace_flexibility_condition=condition,
        matrix_rounding_allowance=matrix_rounding,compliance_error_upper_allowance=compliance_error,
        point_height_tail_policy='positive_sine_series_integral_bound_with_endpoint_reflection')


def conservative_braced_flexure_bound(beam:VlasovBeam,Iy_mm4:float,segments,
        height_points=(),height_lines=(),braces=(),base_modes=12):
    """Three finite-rank bounds with an explicit infinite-dimensional tail.

    Valid for every returned finite-rank level, independent of apparent Ritz
    convergence. The maximum with the old full-span bound is retained. N must
    be zero: use the separate member interaction for axial/torsional demands.
    Ideal/finite braces constrain actual v+z*theta, never an assumed fork.
    """
    segments,points,lines,braces=map(tuple,(segments,height_points,height_lines,braces))
    _validate(beam,Iy_mm4,Iy_mm4,1.,segments,points,lines,braces)
    if any(s.compression_n!=0 for s in segments):raise ValueError('Pure-flexure bound requires N=0')
    if isinstance(base_modes,bool) or not isinstance(base_modes,int) or not 4<=base_modes<=32:
        raise ValueError('base_modes must be an integer from4 through32')
    original=conservative_reference_bound(beam,Iy_mm4,Iy_mm4,1.,segments,points,lines)
    history=[_one_bound(beam,Iy_mm4,segments,points,lines,braces,n) for n in (base_modes,2*base_modes,4*base_modes)]
    values=[r['load_factor_lower_bound'] for r in history]+[original['load_factor_lower_bound']]
    selected=max((v for v in values if v is not None),default=None)
    M=original['Mmax_nmm']
    return dict(load_factor_lower_bound=selected,Mmax_nmm=M,
        major_critical_moment_lower_bound_nmm=selected*M if selected is not None else None,
        unbraced_analytic_bound=original,history=history,brace_count=len(braces),
        method='Green_constrained_finite_rank_plus_tail_norm',
        is_reference_lower_bound=True,is_design_resistance=False,
        bound_scope='pure-flexure straight elastic reference; actual lateral braces; no initial torque or local modes',
        rounding_policy='Parseval1e-10, Green/input1e-12 propagated through inverse+residual into a Loewner compliance majorant; ordinary floating-point, not interval arithmetic')
