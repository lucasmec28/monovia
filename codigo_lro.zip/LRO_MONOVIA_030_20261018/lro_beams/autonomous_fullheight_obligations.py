"""Independent check inventory of the fixed five-interface physical topology.

No calculated result, demand or pass flag is read to decide the obligations.
Changes to the topology require an explicit schema/inventory change.
"""
BASIC=('tension_gross_yield','compression_gross_yield','tension_effective_net_rupture','shear_gross_yield','shear_net_rupture')
NORMAL=('normal','shear',*BASIC)
G_CASES=('real_factored_G','connection_minimum_same_force_line')
BEARING_CASES=('actual_Rz_and_G','zero_reaction_bound_vertex_with_G','local_connection_minimum_once')


def _root(station,side):return station+':plate:'+('left' if side<0 else 'right')

def component_ids(station,side,*,gravity):
    root=_root(station,side);ids=[]
    for kind in ('web','bottom'):
        for face in (-1,1):
            ids.extend(root+f':{kind}:{face:+d}/'+v for v in ('fillet_resultant','receiver_normal','receiver_shear','plate_footprint_shear'))
    ids.extend(root+':top_cjp/'+v for v in ('CJP_normal','CJP_shear'))
    for cut in ('top_net_ligament','plate_connected_root'):ids.extend(cut+'/'+v for v in NORMAL)
    ids.append('plate_core_transverse_compression_stability')
    for cut in ('top_horizontal_plate_ligament',root+':top_cjp/flange_strip','bottom_horizontal_plate_ligament',root+':bottom:-1/flange_strip',root+':bottom:+1/flange_strip'):
        ids.extend(cut+'/'+v for v in BASIC)
    if gravity:ids.append('plate_root_top_block_bottom_resistance_omitted')
    return tuple(ids)


def concurrent_ids(station,cases):
    ids=[]
    for side in (-1,1):
        root=_root(station,side)
        lines=[root+':'+v for v in ('web:-1','web:+1','top_cjp','bottom:-1','bottom:+1')]
        sections=('plate_connected_root','top_horizontal_plate_ligament',root+':top_cjp/flange_strip','bottom_horizontal_plate_ligament',root+':bottom:-1/flange_strip',root+':bottom:+1/flange_strip')
        for case in cases:
            prefix=str(side)+'/'+case+'/'
            ids.extend(prefix+'footprint/'+line+'/receiver/'+end+'/'+v for line in lines for end in ('start','end') for v in ('normal','shear'))
            ids.extend(prefix+'section/'+cut+'/'+v for cut in sections for v in ('normal','shear'))
    return tuple(ids)


def bearing_component_ids(station):
    ids=['bearing_minimum_outstand','bearing_minimum_thickness','bearing_plate_stockiness','bearing_minimum_column',
         'bearing_loaded_plate_net_ligament_compression','bearing_web_two_real_vertical_cuts_shear']
    for side in (-1,1):
        for kind,terms in (('lower',('fillet_resultant','plate_footprint_shear')),('web',('fillet_resultant','plate_footprint_shear','web_footprint_shear'))):
            ids.extend(f'{station}:plate:{side:+d}:serial_{kind}/'+v for v in terms)
        for case in BEARING_CASES:
            ids.extend(f'{station}:{side:+d}:{case}/'+v for v in component_ids(station,side,gravity=False))
    return tuple(ids)


def required_fullheight_static_ids(project):
    from .autonomous_stiffener_actions import stiffener_station_geometry
    ids=[]
    for side in (-1,1):
        for case in G_CASES:
            ids.extend('fullheight/G/'+str(side)+'/'+case+'/'+v for v in component_ids('reference_station',side,gravity=True))
    ids.extend('fullheight/concurrent/'+v for v in concurrent_ids('reference_station',G_CASES))
    for station in stiffener_station_geometry(project):
        if station['kind']=='intermediate':continue
        sid=station['station_id'];prefix='fullheight/bearing/'+sid+'/'
        ids.extend(prefix+'component/'+v for v in bearing_component_ids(sid))
        ids.extend(prefix+'concurrent/'+v for v in concurrent_ids(sid,BEARING_CASES))
    if len(set(ids))!=len(ids):raise ValueError('Inventário independente full-height duplicado.')
    return tuple(ids)
