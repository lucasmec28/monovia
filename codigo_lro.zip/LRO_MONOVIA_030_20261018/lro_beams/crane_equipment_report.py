"""Client-readable equipment narrative and code-native plan, never a load solver.

The report uses adopted project fields, not substituted catalog maxima. A derived
G/Q explanation is shown only when the current wheel train matches that statics.
"""
from io import BytesIO
import math
from .equipment_basis import G_KN_PER_METRIC_TONNE, four_wheel_statics


def number(value, places=2):
    return f'{value:.{places}f}'.replace('.', ',')


def reference_record(project):
    try:
        from .crane_catalog import get_catalog_record
        return get_catalog_record(project.equipment_basis.reference_record_id)
    except (ValueError, KeyError, TypeError):
        return {}


def vertical_distribution(project):
    """Correlated rail totals only if the adopted statics match current G/Q."""
    b = project.equipment_basis
    if b.load_model != 'symmetric_four_wheel_bridge':
        return None
    try:
        expected, evidence = four_wheel_statics(capacity_tf=b.capacity_tf, bridge_span_m=b.bridge_span_m,
            bridge_mass_kg=b.bridge_mass_kg, trolley_mass_kg=b.trolley_mass_kg,
            hook_approach_m=b.hook_approach_m, wheelbase_m=b.wheelbase_m,
            transverse_kn_per_wheel=0., longitudinal_kn_per_wheel=0.)
        same = len(project.wheels) == 2 and all(
            math.isclose(getattr(actual, key), getattr(want, key), rel_tol=1e-9, abs_tol=1e-8)
            for actual, want in zip(project.wheels, expected)
            for key in ('offset_m', 'dead_kn', 'lifted_kn'))
        return evidence if same else None
    except (ValueError, TypeError, ArithmeticError):
        return None


def concise_basis_note(project):
    """Deduplicate only the exact built-in note; keep every custom addition."""
    b = project.equipment_basis
    original = b.assumption_note
    generated = ('Hipótese de fornecimento baseada em ' + b.reference_record_id +
        '. Massas separadas publicadas; repartição simétrica, carro na linha do gancho e menor aproximação E/F. '
        'Vão na faixa publicada, sem interpolação. Equipamento real deve ser compatibilizado pelo fornecedor com as ações e condições adotadas.')
    if not original.startswith(generated):
        return original
    remainder = original[len(generated):]
    if b.horizontal_basis == 'normal_reference' and b.horizontal_scenario_id in ('HT-A', 'HT-B'):
        other = 'HT-B' if b.horizontal_scenario_id == 'HT-A' else 'HT-A'
        horizontal = (' Cenário ' + b.horizontal_scenario_id + ': ações horizontais de referência normativas com hipóteses all-driven, caminho crítico integral e repartição igual. Exige análise complementar ' + other + '; não é certificado de ações do fabricante.')
        if remainder.startswith(horizontal):
            remainder = remainder[len(horizontal):]
    return 'Aproximação adotada: menor E/F da referência. Vão na faixa publicada, sem interpolação.' + remainder


def equipment_narrative(project):
    """Short MC prose. Missing values remain unknown and edits remain explicit."""
    b = project.equipment_basis
    record = reference_record(project)
    if not record and not b.reference_record_id and b.capacity_tf is None:
        return ['As ações da ponte rolante são informadas diretamente por roda, nas componentes G, Q, HT e HL apresentadas adiante. Fabricante, modelo e decomposição das massas do equipamento não foram vinculados a um catálogo neste registro.']
    paragraphs = []
    if b.reference_record_id:
        identity = record.get('manufacturer') or 'fabricante não identificado no registro'
        configuration_labels = {
            'Top running double girder': 'dupla-viga apoiada superiormente',
            'Top running single girder': 'monoviga apoiada superiormente',
        }
        if record.get('model') in configuration_labels:
            identity += ', configuração ' + configuration_labels[record['model']] + ' (' + record['model'] + ')'
        elif record.get('model'):
            identity += ', modelo ' + record['model']
        elif record.get('source_table'):
            identity += ', tabela ' + record['source_table']
        hoist = b.reference_hoist_model or record.get('hoist_model')
        if hoist:
            identity += ', carro/talha ' + hoist
        text = 'Para a definição da ponte rolante, foi selecionada a referência ' + identity + ' (registro ' + b.reference_record_id + ').'
        if record.get('source_table') and record.get('model'):
            text += ' A identificação de catálogo é “' + record['source_table'] + '”.'
        source = b.reference_source_url or record.get('source_url')
        page = b.reference_page or str(record.get('source_pdf_page') or '')
        if source:
            text += ' Fonte: ' + source + ('; página ' + page if page else '') + '.'
        paragraphs.append(text)
    else:
        paragraphs.append('A identificação da ponte e os parâmetros abaixo foram informados diretamente para este modelo, sem vínculo a um registro de catálogo.')
    data = []
    if b.capacity_tf is not None:
        data.append('capacidade nominal de ' + number(b.capacity_tf) + ' tf (' + number(b.capacity_tf * G_KN_PER_METRIC_TONNE) + ' kN de carga içada)')
    if b.bridge_span_m is not None:
        data.append('vão transversal S = ' + number(b.bridge_span_m) + ' m entre os caminhos de rolamento')
    if data:
        paragraphs.append('O modelo considera ' + ' e '.join(data) + '. O vão S da ponte é distinto do vão longitudinal L = ' + number(project.span_m) + ' m entre apoios da viga verificada.')
    masses = []
    for value, label in ((b.bridge_mass_kg, 'estrutura da ponte, excluído o carro/talha'), (b.trolley_mass_kg, 'conjunto carro/talha')):
        if value is not None:
            masses.append(label + ': ' + number(value) + ' kg, correspondentes a ' + number(value / 1000 * G_KN_PER_METRIC_TONNE) + ' kN')
    if masses:
        text = 'As massas adotadas são: ' + '; '.join(masses) + '.'
        geometry = []
        if b.hook_approach_m is not None:
            geometry.append('aproximação a = ' + number(b.hook_approach_m) + ' m da linha do gancho ao caminho analisado')
        if b.wheelbase_m is not None:
            geometry.append('entre-eixos b = ' + number(b.wheelbase_m) + ' m das rodas no sentido longitudinal')
        if geometry:
            text += ' A geometria considera ' + ' e '.join(geometry) + '.'
        paragraphs.append(text)
    missing = [label for value, label in ((b.bridge_span_m, 'vão da ponte'), (b.bridge_mass_kg, 'massa da ponte sem carro'),
        (b.trolley_mass_kg, 'massa do carro/talha'), (b.hook_approach_m, 'aproximação do gancho'), (b.wheelbase_m, 'entre-eixos das rodas')) if value is None]
    if missing:
        paragraphs.append('Não estão definidos neste registro: ' + ', '.join(missing) + '. Esses valores não foram deduzidos de uma carga máxima de roda nem preenchidos por estimativa automática.')
    evidence = vertical_distribution(project)
    if evidence:
        paragraphs.append('A distribuição vertical considera a estrutura da ponte centrada entre os caminhos, carro e carga na mesma linha transversal e duas rodas por caminho com repartição longitudinal igual. No caminho analisado, obtêm-se G = ' + number(evidence['near_dead_kn']) + ' kN e Q = ' + number(evidence['near_lifted_kn']) + ' kN, ou G = ' + number(evidence['near_dead_kn']/2) + ' kN e Q = ' + number(evidence['near_lifted_kn']/2) + ' kN por roda. No caminho oposto, os totais são G = ' + number(evidence['far_dead_kn']) + ' kN e Q = ' + number(evidence['far_lifted_kn']) + ' kN. São componentes características calculadas pelo modelo, antes da dinâmica e dos coeficientes das combinações; não são a leitura de Pmáx/Pmín do catálogo.')
    elif b.load_model == 'symmetric_four_wheel_bridge':
        paragraphs.append('O trem de rodas atual não reproduz integralmente a repartição simétrica proposta com esses parâmetros. Para o cálculo prevalecem as componentes G e Q efetivamente informadas na tabela de rodas; não se apresenta uma distribuição correlacionada entre os dois caminhos.')
    if b.status == 'reference_only':
        paragraphs.append('O catálogo foi registrado apenas como referência, sem confirmação do equipamento fornecido, e não alterou as ações por roda. A seleção do equipamento fornecido deverá ser compatível com os dados adotados no projeto.')
    elif b.status == 'adopted_assumption':
        paragraphs.append('Esses dados constituem a referência adotada para projeto, e não a identificação confirmada do equipamento fornecido. O fornecimento deverá ser compatível com as massas, geometria, ações e condições de operação aqui consideradas.')
    elif b.status == 'project_confirmed':
        paragraphs.append('Os dados do equipamento foram declarados como confirmados para este projeto.')
    return paragraphs


def equipment_schematic(project, image_format='png'):
    """Plan with actual S/a/b dimensions. PNG for Word, SVG available for reuse."""
    evidence = vertical_distribution(project)
    if evidence is None:
        return None
    if image_format not in ('png', 'svg'):
        raise ValueError('Use png ou svg.')
    from matplotlib.figure import Figure
    from matplotlib.backends.backend_agg import FigureCanvasAgg
    from matplotlib.patches import Rectangle, Circle
    b = project.equipment_basis
    ink, muted, teal, orange = '#17354A', '#587085', '#167B71', '#B85A36'
    fig = Figure(figsize=(8.2, 5.15), facecolor='white'); FigureCanvasAgg(fig)
    ax = fig.add_axes([.035, .24, .93, .64]); ax.set_xlim(0, 10); ax.set_ylim(0, 6.2); ax.axis('off')
    left, right, low, high, center = 1.2, 8.4, 1.65, 4.25, 2.95
    trolley = left + (right-left) * b.hook_approach_m / b.bridge_span_m
    for x in (left, right):
        ax.plot([x,x],[1.0,4.85],color='#C38A43',lw=3,zorder=1)
        ax.add_patch(Rectangle((x-.17,low),.34,high-low,facecolor='#9BB8CB',edgecolor=ink,lw=1.3,zorder=2))
        for y in (low,high):
            ax.add_patch(Circle((x,y),.115,facecolor='white',edgecolor=orange,lw=1.6,zorder=4))
    if reference_record(project).get('family') == 'double_girder_top_running':
        for y in (center-.21,center+.08):
            ax.add_patch(Rectangle((left,y),right-left,.13,facecolor='#D8E7EF',edgecolor=ink,lw=1.3,zorder=3))
    else:
        ax.add_patch(Rectangle((left,center-.18),right-left,.36,facecolor='#D8E7EF',edgecolor=ink,lw=1.4,zorder=3))
    ax.add_patch(Rectangle((trolley-.18,center-.29),.36,.58,facecolor='#D6EDE8',edgecolor=teal,lw=1.5,zorder=5))
    ax.plot([trolley],[center],marker='o',ms=3.5,color=teal,zorder=6)
    ax.plot([(left+right)/2],[center],marker='D',ms=4,color=ink,zorder=6)
    ax.text((left+right)/2,center+.48,'CG da ponte',ha='center',fontsize=9.5,color=ink)
    ax.annotate('Carro + carga\nna linha do gancho',xy=(trolley,center-.3),xytext=(3.3,1.5),ha='center',va='center',fontsize=9.5,color=teal,
        arrowprops=dict(arrowstyle='-',color=teal,lw=1.1,connectionstyle='angle,angleA=90,angleB=0,rad=0'))
    def dimension(p1,p2,label,text_at,rotation=0):
        ax.annotate('',xy=p2,xytext=p1,arrowprops=dict(arrowstyle='<->',color=muted,lw=1))
        ax.text(*text_at,label,ha='center',va='center',rotation=rotation,fontsize=10,color=ink)
    for x in (left,right): ax.plot([x,x],[4.9,5.65],color=muted,lw=.7)
    dimension((left,5.55),(right,5.55),'S = '+number(b.bridge_span_m)+' m · vão transversal da ponte (y)',((left+right)/2,5.95))
    for y in (low,high):ax.plot([.5,left-.25],[y,y],color=muted,lw=.7)
    dimension((.58,low),(.58,high),'b = '+number(b.wheelbase_m)+' m',(.18,center),90)
    ax.text(left,4.95,'Caminho analisado',ha='center',fontsize=9.5,color=ink)
    ax.text(right,4.95,'Caminho oposto',ha='center',fontsize=9.5,color=ink)
    for x in (left,trolley):ax.plot([x,x],[.65,1.18],color=muted,lw=.7)
    ax.plot([left,trolley],[.85,.85],color=muted,lw=1.1)
    ax.annotate('a = '+number(b.hook_approach_m)+' m',xy=((left+trolley)/2,.85),xytext=(3.1,.42),ha='center',fontsize=9.5,color=ink,
        arrowprops=dict(arrowstyle='-',color=muted,lw=.8))
    ax.annotate('',xy=(9.25,4.05),xytext=(9.25,1.85),arrowprops=dict(arrowstyle='->',color=muted,lw=1.2))
    ax.text(9.65,center,'x · translação da ponte',ha='center',va='center',rotation=90,fontsize=9,color=muted)
    fig.text(.06,.95,'PONTE ROLANTE  /  MODELO DE DISTRIBUIÇÃO VERTICAL',fontsize=12,color=ink,weight='bold')
    fig.text(.06,.91,'Planta esquemática; pesos e carga içada atuam na direção vertical z.',fontsize=9.5,color=muted)
    fig.text(.06,.19,'Massas: ponte sem carro = '+number(b.bridge_mass_kg)+' kg; carro/talha = '+number(b.trolley_mass_kg)+' kg.',fontsize=9.5,color=ink)
    fig.text(.06,.145,'Pesos: G ponte = '+number(evidence['total_dead_kn']-b.trolley_mass_kg/1000*G_KN_PER_METRIC_TONNE)+' kN; G carro = '+number(b.trolley_mass_kg/1000*G_KN_PER_METRIC_TONNE)+' kN; Q içada = '+number(evidence['total_lifted_kn'])+' kN.',fontsize=9.5,color=ink)
    fig.text(.06,.10,'Por roda no caminho analisado: G = '+number(evidence['near_dead_kn']/2)+' kN; Q = '+number(evidence['near_lifted_kn']/2)+' kN (antes dos fatores).',fontsize=9.5,color=ink)
    fig.text(.06,.052,'Duas rodas por caminho; escalas x/y independentes. Esquema analítico, não desenho de fabricação.',fontsize=8.7,color=muted)
    out=BytesIO();fig.savefig(out,format=image_format,dpi=200,facecolor='white');return out.getvalue()
