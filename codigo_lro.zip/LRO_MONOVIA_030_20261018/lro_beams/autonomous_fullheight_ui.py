"""Explicit editable physical detail, separate from analysis restraint inputs."""
from copy import deepcopy
from dataclasses import replace
from .autonomous_fullheight_detail import propose_fullheight_detail,fullheight_detail_from_mapping,resolve_fullheight_detail

PREFIX='autonomous_inputs:fullheight:'

def render_fullheight_detail(st,p):
    selected=st.checkbox('Usar família nominal full-height: CJP superior, filetes contínuos na alma e na mesa inferior',
        value=p.fullheight_nominal_detail is not None,key=PREFIX+'enabled',
        help='Separa chapas estabilizadoras e enrijecedores de apoio. Não cria apoios de análise nem transfere reações de travas às chapas.')
    if not selected:
        p.fullheight_nominal_detail=None
        return
    if p.restraint_application!='resistance_lengths_only':
        p.fullheight_nominal_detail={}
        st.error('Esta família exige o modo de comprimentos resistentes, sem novos apoios intermediários de análise.')
        return
    key=PREFIX+'physical_detail'
    if key not in st.session_state:
        try:
            st.session_state[key]=deepcopy(p.fullheight_nominal_detail) if p.fullheight_nominal_detail is not None else propose_fullheight_detail(p).to_dict()
        except (ValueError,TypeError,KeyError) as exc:
            p.fullheight_nominal_detail={}
            st.error(str(exc));return
    try:d=fullheight_detail_from_mapping(st.session_state[key])
    except (ValueError,TypeError,KeyError) as exc:
        st.error('Detalhe importado inválido: '+str(exc));p.fullheight_nominal_detail=deepcopy(st.session_state[key]);return
    st.caption('Detalhe de projeto editável, não confirmação de fabricação. Recortes de 25 mm e preparo K são a proposta inicial. CJP é penetração total, não filete aumentado. As dimensões principais continuam nos campos acima.')
    try:resolve_fullheight_detail(p,d)
    except (ValueError,TypeError) as exc:
        st.warning(str(exc))
        if st.button('Atualizar o detalhe para as dimensões atuais',key=PREFIX+'refresh'):
            # Explicit user action, never an import/reset side effect.
            try:
                d=propose_fullheight_detail(p)
                st.session_state[key]=d.to_dict()
                for k in list(st.session_state):
                    if isinstance(k,str) and k.startswith(PREFIX+'dimension:'):del st.session_state[k]
            except (ValueError,TypeError) as error:st.error(str(error))
    def number(label,value,name,minimum=0.):
        return st.number_input(label,min_value=minimum,value=float(value),step=.5,key=PREFIX+'dimension:'+name)
    cols=st.columns(2)
    with cols[0]:
        rt=number('Raio do recorte superior (mm)',d.upper_cope.radius_mm,'upper_radius')
        rb=number('Raio do recorte inferior (mm)',d.lower_cope.radius_mm,'lower_radius')
        sw=number('Perna dos filetes contínuos na alma (mm)',d.web_fillets.leg_mm,'web_leg')
    with cols[1]:
        sb=number('Perna dos filetes contínuos na mesa inferior (mm)',d.bottom_attachment.leg_mm,'bottom_leg')
        sr=number('Reforço geométrico da CJP superior (mm)',d.top_cjp.reinforcement_leg_mm,'top_reinforcement')
        clearance=number('Folga livre mínima no recorte (mm)',d.upper_cope.clearance_mm,'cope_clearance')
    st.caption('Qualidade especificada: CJP transversal superior QE; filetes inferiores QE; filetes da alma QC com terminações QE; juntas longitudinais K/CJP QC. Os requisitos de execução e inspeção acompanham o detalhe e não são certificados pelo cálculo.')
    raw=d.to_dict()
    raw['upper_cope'].update(radius_mm=rt,clearance_mm=clearance)
    raw['lower_cope'].update(radius_mm=rb,clearance_mm=clearance)
    raw['web_fillets']['leg_mm']=sw
    raw['bottom_attachment']['leg_mm']=sb
    raw['top_cjp']['reinforcement_leg_mm']=sr
    p.fullheight_nominal_detail=raw
    try:
        d=fullheight_detail_from_mapping(raw)
        st.session_state[key]=deepcopy(raw)
    except (ValueError,TypeError) as exc:
        # Keep the invalid edited input in the outgoing project. Never use the
        # previous valid geometry silently when a widget currently disagrees.
        st.error('Geometria do detalhe: '+str(exc))
