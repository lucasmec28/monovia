"""Isolated, explicit-input UI for the underslung local nominal-stress route.

No top-running example or catalogue data enter this editor. Empty numeric
widgets remain None; a mechanical/local result is never a whole-beam approval.
"""
from __future__ import annotations

from copy import deepcopy
import json

import streamlit as st

from .document_metadata import DOCUMENT_FIELDS, validate_document_metadata, word_cache_signature
from .underslung_local_model import (
    ExternalLocalState, UnderslungLocalProject, load_project, project_document,
    validate_project,
)

PREFIX = 'under_local:'
_BASIS = {
    'unselected': 'Selecionar a base das ações',
    'mechanical': 'Mecânica: somente tensões locais, sem aprovação normativa',
    'nbr8400': 'NBR 8400-2:2019: comparação nominal elástica local',
    'en_service': 'EN 1993-6: serviço local explicitamente adotado',
}
_CONSTRUCTION = {'unselected': 'Selecionar a fabricação', 'rolled': 'Perfil laminado', 'welded': 'Perfil soldado'}
_COVERAGE = (
    'Resistência e estabilidade globais: flexão, cisalhamento, torção/empenamento, '
    'flambagem, continuidade, vínculos e deslocamentos não são concluídos nesta rota.',
    'Suspensão: ligação da mesa superior às vigas de piso, parafusos, efeito de alavanca, '
    'soldas e resistência das vigas receptoras exigem verificações próprias.',
    'Contato e detalhe: pressão de contato, desgaste, esmagamento de borda, raiz/junção, '
    'soldas e efeitos tridimensionais não são aprovados pelo modelo nominal de tensão plana.',
    'Fadiga: requer histórias assinadas local + global no mesmo ponto material, '
    'contagem de ciclos e categoria de detalhe qualificada; o cálculo estático não a substitui.',
)


def _key(name):
    return PREFIX + name


def _clear_calculation(*, edited=False):
    st.session_state.pop(_key('result'), None)
    st.session_state.pop(_key('word'), None)
    st.session_state[_key('edited')] = edited


def _install_project(project, metadata):
    """Called only after a complete import validates: no partial state writes."""
    for key in list(st.session_state):
        if isinstance(key, str) and (key.startswith(_key('widget:')) or key.startswith(_key('document:'))):
            del st.session_state[key]
    st.session_state[_key('project')] = deepcopy(project)
    st.session_state[_key('document_metadata')] = dict(metadata)
    _clear_calculation()


def _number(label, name, value, *, signed=False, help=None):
    options = {} if signed else {'min_value': 0.0}
    return st.number_input(label, value=None if value is None else float(value),
                           step=0.1, format='%.6f', key=_key('widget:' + name),
                           placeholder='Não informado', help=help, **options)


def _text(label, name, value, *, multiline=False):
    method = st.text_area if multiline else st.text_input
    return method(label, value=value, max_chars=10000, key=_key('widget:' + name))


def _check(label, name, value):
    return st.checkbox(label, value=value, key=_key('widget:' + name))


def _select(label, name, value, choices):
    return st.selectbox(label, list(choices), index=list(choices).index(value),
                        format_func=choices.get, key=_key('widget:' + name))


def _identity():
    previous = st.session_state.get(_key('document_metadata'), {})
    metadata = {}
    with st.expander('Identificação da memória local'):
        st.caption('Identificação documental opcional; não altera as ações nem confirma atendimento estrutural.')
        for name, label in DOCUMENT_FIELDS.items():
            value = st.text_input(label, value=previous.get(name, ''), max_chars=500,
                                  key=_key('document:' + name)).strip()
            if value:
                metadata[name] = value
    metadata = validate_document_metadata(metadata)
    if metadata != previous:
        st.session_state.pop(_key('word'), None)
    st.session_state[_key('document_metadata')] = metadata
    return metadata


def _geometry(project):
    with st.expander('Equipamento, seção real e material', expanded=True):
        st.caption('Ponte suspensa: rodas na mesa inferior; mesa superior fixada sob as vigas de piso. '
                   'Não há geometria, peso, carga por roda ou catálogo de ponte apoiada preenchidos automaticamente.')
        project.capacity_tf = _number('Capacidade nominal informativa (tf)', 'capacity_tf', project.capacity_tf,
                                      help='A capacidade nominal não determina a reação individual de roda.')
        project.equipment_source = _text('Identificação e fonte do equipamento real', 'equipment_source', project.equipment_source)
        project.suspension_description = _text('Descrição da fixação às vigas de piso', 'suspension_description',
                                                project.suspension_description, multiline=True)
        cols = st.columns(2)
        for index, (name, label) in enumerate((
            ('bottom_b_mm', 'Largura da mesa inferior b (mm)'),
            ('bottom_tf_mm', 'Espessura da mesa inferior tf (mm)'),
            ('web_tw_mm', 'Espessura da alma tw (mm)'),
            ('edge_to_contact_n_mm', 'Borda livre até o centro do contato n (mm)'),
        )):
            with cols[index % 2]:
                setattr(project, name, _number(label, name, getattr(project, name)))
        st.caption('n é medido transversalmente da borda livre da mesa inferior até o centro de contato da roda. '
                   'A folga física até a raiz/solda é verificada separadamente pelo modelo.')
        project.construction = _select('Fabricação da seção', 'construction', project.construction, _CONSTRUCTION)
        if project.construction == 'rolled':
            project.root_radius_mm = _number('Raio real da concordância da raiz (mm)', 'root_radius_mm', project.root_radius_mm)
        elif project.construction == 'welded':
            project.weld_throat_mm = _number('Garganta real da solda alma–mesa (mm)', 'weld_throat_mm', project.weld_throat_mm)
        project.straight_parallel_i_confirmed = _check(
            'Confirmo seção I reta, com mesas paralelas, dentro do domínio geométrico do modelo local',
            'straight_parallel_i_confirmed', project.straight_parallel_i_confirmed)
        cols = st.columns(2)
        with cols[0]:
            project.fy_mpa = _number('Limite de escoamento fy da espessura real (MPa)', 'fy_mpa', project.fy_mpa)
        with cols[1]:
            project.fu_mpa = _number('Resistência à ruptura fu da espessura real (MPa)', 'fu_mpa', project.fu_mpa)
        project.material_source = _text('Fonte e qualificação do material', 'material_source', project.material_source)
        project.notes = _text('Observações do projeto', 'notes', project.notes, multiline=True)
    with st.expander('Qualificação explícita do modelo nominal local'):
        project.supplemental_model_adopted = _check(
            'Adoto o modelo nominal de mesas paralelas da NBR 10084 §9.1.4 (correspondente à EN 1993-6 §5.8)',
            'supplemental_model_adopted', project.supplemental_model_adopted)
        project.plane_stress_nominal_confirmed = _check(
            'Confirmo o escopo de tensões nominais planas; pressão de contato e efeitos tridimensionais ficam fora desta comparação',
            'plane_stress_nominal_confirmed', project.plane_stress_nominal_confirmed)
        project.base_material_points_confirmed = _check(
            'Confirmo que os pontos nominais comparados representam material-base qualificado, sem aprovar solda ou concentração local',
            'base_material_points_confirmed', project.base_material_points_confirmed)
        project.high_ratio_route_confirmed = _check(
            'Quando aplicável, confirmo a qualificação específica da rota NBR para material com fy/fu elevado',
            'high_ratio_route_confirmed', project.high_ratio_route_confirmed)
        st.caption('As confirmações não substituem evidência de geometria, material ou análise global. '
                   'Um resultado local numérico não aprova contato, soldas, estabilidade, suspensão ou fadiga.')


def _state_editor(state, index):
    prefix = f'state:{index}:'
    def name(field):
        return prefix + field
    with st.expander(f'Estado externo {index + 1} · {state.name}', expanded=index == 0):
        state.name = _text('Nome único do estado', name('name'), state.name)
        state.combination_id = _text('Combinação, seção e posição da ponte/rodas', name('combination_id'), state.combination_id)
        state.global_input_mode = _select('Modo de entrada das tensões globais', name('global_input_mode'),
            state.global_input_mode, {'point_states': 'Tensões concomitantes por ponto e face',
                                     'section_envelope': 'Intervalos conservadores globais da seção'})
        if state.global_input_mode == 'point_states':
            state.outstand_side = _select('Lado físico da mesa inferior representado por este estado',
                name('outstand_side'), state.outstand_side,
                {'unselected': 'Selecionar o lado físico', 'left': 'Balanço esquerdo da alma', 'right': 'Balanço direito da alma'})
            st.caption('Os seis pontos/faces deste estado pertencem somente ao balanço selecionado. '
                       'O outro lado da alma requer outro estado com suas próprias tensões globais concomitantes; '
                       'rodas opostas iguais não demonstram tensões globais iguais nos dois lados.')
        state.action_basis = _select('Base das ações e da comparação', name('action_basis'), state.action_basis, _BASIS)
        if state.action_basis == 'nbr8400':
            state.nbr_case = _select('Caso NBR 8400', name('nbr_case'), state.nbr_case,
                                     {'I': 'Caso I', 'II': 'Caso II', 'III': 'Caso III'})
            st.caption('Rota nominal elástica NBR 8400-2 com tensões locais da NBR 10084 §9.1.4; na combinação, aplica-se 0,75 somente à parcela local longitudinal. '
                       'A reação já deve conter os fatores do caso NBR uma única vez; não converter silenciosamente ELU NBR 8800. '
                       'Não se aplicam aqui γM,ser, γM0 nem a resistência plástica EN §6.7.')
        elif state.action_basis == 'en_service':
            state.en_gamma_mser = _number('γM,ser explicitamente adotado', name('en_gamma_mser'), state.en_gamma_mser)
            state.en_gamma_source = _text('Fonte e justificativa de γM,ser', name('en_gamma_source'), state.en_gamma_source)
        state.action_source = _text('Fonte das reações individuais de roda',
                                   name('action_source'), state.action_source, multiline=True)
        state.factors_source = _text('Memória dos fatores dinâmicos, de grupo e da combinação aplicados',
                                    name('factors_source'), state.factors_source, multiline=True)
        state.factors_already_applied = _check(
            'Confirmo que as reações finais já incluem os fatores declarados exatamente uma vez',
            name('factors_already_applied'), state.factors_already_applied)
        state.action_case_qualified = _check(
            'Confirmo a qualificação das ações e da combinação para a base normativa selecionada',
            name('action_case_qualified'), state.action_case_qualified)
        cols = st.columns(2)
        with cols[0]:
            state.section_x_m = _number('Coordenada longitudinal da seção verificada (m)',
                name('section_x_m'), state.section_x_m, signed=True)
        with cols[1]:
            state.wheel_translation_m = _number('Posição longitudinal do trem de rodas (m)',
                name('wheel_translation_m'), state.wheel_translation_m, signed=True)
        state.coordinate_source = _text('Origem, eixos e referência das coordenadas da seção e do trem',
                                         name('coordinate_source'), state.coordinate_source)
        st.caption('Informe as reações FINAIS individuais, em kN, em ordem longitudinal no MESMO lado da alma. '
                   'Ação aplicada não é capacidade admissível de roda ou de par indicada em catálogo; '
                   'não informe carga do trole inteiro ou capacidade nominal como carga por roda. '
                   'Os valores não recebem fatores de carga adicionais nesta tela.')
        count = st.number_input('Quantidade de rodas em sequência no mesmo lado', min_value=1, max_value=20,
                                value=len(state.wheel_actions_kn), step=1, key=_key('widget:' + name('wheel_count')))
        state.wheel_actions_kn = (state.wheel_actions_kn + [None] * count)[:count]
        state.longitudinal_spacings_mm = (state.longitudinal_spacings_mm + [None] * max(0, count - 1))[:count - 1]
        cols = st.columns(2)
        for wheel in range(count):
            with cols[0]:
                state.wheel_actions_kn[wheel] = _number(f'Ação aplicada final individual da roda {wheel + 1} (kN)',
                    name(f'wheel:{wheel}'), state.wheel_actions_kn[wheel])
            if wheel < count - 1:
                with cols[1]:
                    state.longitudinal_spacings_mm[wheel] = _number(
                        f'Espaçamento longitudinal entre rodas {wheel + 1} e {wheel + 2} (mm)',
                        name(f'spacing:{wheel}'), state.longitudinal_spacings_mm[wheel])
        if count > 1:
            state.cluster_component_envelope_adopted = _check(
                'Adoto a superposição simplificada das magnitudes locais do grupo de rodas próximas, conforme EN 1993-6 §5.8(8)',
                name('cluster_component_envelope_adopted'), state.cluster_component_envelope_adopted)
            st.caption('A comparação do grupo usa os quatro cantos locais σx/σy, ou o retângulo total, como limite conservador. '
                       'Não declara que as componentes extremas coexistem e não admite cancelamento favorável. '
                       'Sem adoção explícita, as somas locais são apenas resultados mecânicos.')
        state.nearest_longitudinal_spacing_mm = _number(
            ('Menor espaçamento longitudinal à roda/grupo EXTERNO ao grupo fornecido (mm)' if count > 1 else
             'Menor espaçamento longitudinal para outra estação de rodas, quando aplicável (mm)'),
            name('nearest_longitudinal_spacing_mm'), state.nearest_longitudinal_spacing_mm)
        state.isolated_station_confirmed = _check(
            ('Confirmo grupo completo, sem roda omitida próxima ao grupo fornecido' if count > 1 else
             'Confirmo estação isolada, sem outra estação longitudinal próxima'),
            name('isolated_station_confirmed'), state.isolated_station_confirmed)
        if count > 1:
            st.caption('A lista deve conter todas as rodas próximas do mesmo lado. Declare o grupo completo isolado '
                       'ou informe distância externa mínima de 1,5 b; adotar a soma local não confirma a ausência de rodas omitidas.')
        state.equal_opposite_wheels_confirmed = _check(
            'Confirmo roda oposta de igual reação em cada posição, no outro lado da alma',
            name('equal_opposite_wheels_confirmed'), state.equal_opposite_wheels_confirmed)
        st.caption('A hipótese de rodas opostas iguais deve corresponder ao equipamento real; não é inferida de simetria visual. '
                   'Espaçamento longitudinal não é a distância transversal entre rodas opostas.')
        state.distance_to_physical_end_mm = _number('Menor distância de qualquer roda à extremidade física (mm)',
            name('distance_to_physical_end_mm'), state.distance_to_physical_end_mm)
        st.markdown('**Campo global nominal do Robot ou de outra análise externa**')
        st.caption('σx deve incluir axial, flexões e empenamento aplicáveis; τ deve incluir os efeitos transversais '
                   'e de torção aplicáveis. Tração é positiva; mantenha os sinais de todas as componentes. '
                   'Valor ausente não equivale a zero.')
        state.global_source = _text('Fonte global, seção, posição, pontos/faces, eixos e convenção de sinais',
                                   name('global_source'), state.global_source, multiline=True)
        state.global_effects_complete = _check('Confirmo que as componentes globais incluem todos os efeitos aplicáveis, inclusive torção/empenamento',
                                               name('global_effects_complete'), state.global_effects_complete)
        if state.global_input_mode == 'point_states':
            st.caption('Exporte a MESMA combinação, seção, posição das rodas e convenção de eixos/sinais da reação acima. '
                       'Use os pontos físicos 0, 1 e 2 nas faces inferior E superior do balanço selecionado da mesa inferior. '
                       'Não use máximos independentes nem tensão de meio da espessura como tensão de face.')
            state.same_state_confirmed = _check('Confirmo que cargas locais e tensões globais pertencem ao mesmo estado físico e combinação',
                                                name('same_state_confirmed'), state.same_state_confirmed)
            rows = {(row['point'], row['face']): row for row in state.global_points}
            for point in range(3):
                for face, label in (('bottom', 'inferior'), ('top', 'superior')):
                    row = rows[(point, face)]
                    st.caption(f'Ponto {point} · face {label} da mesa inferior · lado ' +
                               {'left': 'esquerdo', 'right': 'direito', 'unselected': 'não selecionado'}[state.outstand_side])
                    cols = st.columns(3)
                    for col, field, symbol in zip(cols, ('sigma_x_mpa', 'sigma_y_mpa', 'tau_mpa'), ('σx', 'σy', 'τxy')):
                        with col:
                            row[field] = _number(f'{symbol} global · P{point} · face {label} (MPa)',
                                name(f'global:{point}:{face}:{field}'), row[field], signed=True)
        else:
            st.caption('Informe intervalos globais assinados [mínimo, máximo] do MESMO caso selecionado. '
                       'Devem envolver os dois balanços da alma, as duas faces, todos os pontos e posições cobertos. '
                       'O cálculo usa os vértices conservadores da caixa de componentes, sem afirmar que esses extremos '
                       'acontecem simultaneamente. Não é permitido inserir máximos independentes como se fossem uma tensão concomitante.')
            for field, symbol in (('sigma_x_mpa', 'σx'), ('sigma_y_mpa', 'σy'), ('tau_mpa', 'τxy')):
                cols = st.columns(2)
                for bound, label in enumerate(('mínimo', 'máximo')):
                    with cols[bound]:
                        state.global_component_bounds[field][bound] = _number(
                            f'{symbol} global {label} do intervalo (MPa)', name(f'bound:{field}:{bound}'),
                            state.global_component_bounds[field][bound], signed=True)
            state.envelope_scope_source = _text('Fonte e alcance da envoltória global: lados, faces, pontos, posições e caso',
                name('envelope_scope_source'), state.envelope_scope_source, multiline=True)
            state.envelope_coverage_confirmed = _check(
                'Confirmo que os intervalos cobrem ambos os balanços, ambas as faces e todos os pontos e posições do caso selecionado',
                name('envelope_coverage_confirmed'), state.envelope_coverage_confirmed)
            state.envelope_load_geometry_confirmed = _check(
                'Confirmo reações individuais como limites superiores e distâncias à extremidade/espaçamentos como limites inferiores em todas as posições cobertas',
                name('envelope_load_geometry_confirmed'), state.envelope_load_geometry_confirmed)
            st.caption('A confirmação também exige as mesmas dimensões b, tf, tw, n e raiz em todo o alcance, '
                       'mantendo a configuração de rodas opostas iguais. A fonte da envoltória deve comprovar '
                       'essas premissas e os limites globais; uma caixa de tensões não corrige cargas ou geometrias não abrangidas.')



def _coverage(result=None):
    with st.expander('Cobertura e pendências · não é aprovação da viga completa', expanded=True):
        st.write('Esta rota conclui apenas as verificações locais expressamente calculadas. '
                 'A viga completa e sua suspensão permanecem sem conclusão.')
        for text in _COVERAGE:
            st.write('• ' + text)
        if result:
            pending = list(result.get('pending', []))
            for state in result.get('states', []):
                pending.extend(f"{state.get('name', 'Estado')}: {item}" for item in state.get('pending', []))
            pending.extend(result.get('limitations', []))
            for item in dict.fromkeys(str(item) for item in pending):
                st.write('• ' + item)


def _is_failure(check):
    # Preserve the resistance evaluator's own verdict, including its boundary
    # policy. Presentation must not relax a failed check with a second tolerance.
    if check.get('passed') is False or check.get('status') == 'NÃO ATENDE':
        return True
    if check.get('passed') is True or check.get('status') == 'ATENDE':
        return False
    state = str(check.get('state', '')).upper()
    if state in ('FAIL', 'FAILED', 'NÃO ATENDE', 'NAO ATENDE', 'REPROVADO') or state.startswith('NÃO ATENDE'):
        return True
    utilization = check.get('utilization')
    return isinstance(utilization, (int, float)) and not isinstance(utilization, bool) and utilization > 1


def _results(project, result, metadata):
    status = str(result.get('status', 'Resultado local sem conclusão'))
    if any(_is_failure(check) for check in result.get('checks', [])):
        st.error('Verificação local não atendida. ' + status)
    elif result.get('local_scope_complete'):
        st.info('Escopo local calculado. ' + status + ' A viga completa não está aprovada.')
    else:
        st.warning('Escopo local parcial ou pendente. ' + status)
    checks = result.get('checks', [])
    if checks:
        st.markdown('**Verificações numéricas locais**')
        rows = []
        for check in checks:
            rows.append({
                'Estado de carga': check.get('state_name'), 'Verificação': check.get('title', check.get('id')),
                'Situação local': ('NÃO ATENDE LOCAL' if _is_failure(check) else
                    'ATENDE LOCAL' if check.get('state') == 'calculated' and check.get('utilization') is not None
                    else 'PENDENTE'), 'Ponto': check.get('point'),
                'Balanço': {'left': 'esquerdo', 'right': 'direito', 'both': 'ambos (envelope)'}.get(check.get('outstand_side'), check.get('outstand_side')),
                'Face': {'bottom': 'inferior', 'top': 'superior', 'both': 'ambas (envelope)'}.get(check.get('face'), check.get('face')),
                'Solicitação': check.get('demand'), 'Limite': check.get('capacity'), 'Unidade': check.get('unit'),
                'Utilização': check.get('utilization'), 'Motivo': check.get('reason'),
            })
        st.dataframe(rows, hide_index=True, width='stretch')
    for state in result.get('states', []):
        local = state.get('local_stresses', [])
        if local:
            with st.expander('Tensões locais mecânicas · ' + str(state.get('name', 'Estado'))):
                if state.get('scope'):
                    st.caption(str(state['scope']))
                st.caption('Coeficientes/tensões locais calculados no escopo indicado. '
                           'As duas componentes locais invertem juntas entre faces; não se escolhem sinais favoráveis independentes.')
                st.dataframe(local, hide_index=True, width='stretch')
    if st.button('Preparar memória Word local', key=_key('prepare_word')):
        from .underslung_local_report import export_local_word
        try:
            payload = export_local_word(project, result, document_metadata=metadata)
            st.session_state[_key('word')] = (word_cache_signature(project.signature(), metadata), payload)
        except (ValueError, TypeError, ArithmeticError) as exc:
            st.session_state.pop(_key('word'), None)
            st.error('Não foi possível preparar a memória local: ' + str(exc))
    word = st.session_state.get(_key('word'))
    if word and word[0] == word_cache_signature(project.signature(), metadata):
        st.download_button('Baixar memória Word local', word[1], 'LRO_ponte_suspensa_local.docx',
            'application/vnd.openxmlformats-officedocument.wordprocessingml.document', key=_key('download_word'))


def render_underslung_local():
    """Render the independent route without configuring the host page or running globally."""
    st.subheader('Ponte suspensa · flexão local da mesa inferior')
    st.info('Rota local com ações e tensões globais externas: não executa nem aprova o dimensionamento autônomo da viga completa. '
            'A ligação suspensa da mesa superior às vigas de piso não é verificada aqui.')
    if _key('project') not in st.session_state:
        st.session_state[_key('project')] = UnderslungLocalProject()
    with st.expander('Abrir ou salvar projeto local'):
        st.caption('Aceita somente JSON LRO_UNDERSLUNG_LOCAL. Dados desconhecidos são salvos como null. '
                   'Importar não converte projeto de ponte apoiada nem importa resultados antigos.')
        upload = st.file_uploader('Projeto local de ponte suspensa (JSON)', type=['json'], key=_key('upload'))
        if st.button('Abrir projeto local enviado', disabled=upload is None, key=_key('open')):
            try:
                loaded, metadata = load_project(upload.getvalue())
            except (ValueError, TypeError, KeyError, UnicodeError) as exc:
                st.error('Não foi possível abrir o projeto local: ' + str(exc))
            else:
                _install_project(loaded, metadata)
                st.rerun()
        if st.button('Novo projeto local vazio', key=_key('new')):
            _install_project(UnderslungLocalProject(), {})
            st.rerun()
    try:
        metadata = _identity()
    except ValueError as exc:
        st.session_state.pop(_key('word'), None)
        st.error(str(exc))
        return
    previous = st.session_state[_key('project')]
    project = deepcopy(previous)
    _geometry(project)
    st.markdown('**Estados externos e envoltórias declaradas**')
    for index, state in enumerate(project.states):
        _state_editor(state, index)
    st.session_state[_key('project')] = project
    if project != previous:
        _clear_calculation(edited=True)
    cols = st.columns(2)
    with cols[0]:
        add = st.button('Adicionar estado concomitante', disabled=len(project.states) >= 100, key=_key('add_state'))
    with cols[1]:
        remove = st.button('Remover último estado', disabled=len(project.states) <= 1, key=_key('remove_state'))
    if add or remove:
        if add:
            existing = {state.name for state in project.states}
            number = len(project.states) + 1
            while f'Estado {number}' in existing:
                number += 1
            project.states.append(ExternalLocalState(name=f'Estado {number}'))
        else:
            project.states.pop()
        _install_project(project, metadata)
        st.session_state[_key('edited')] = True
        st.rerun()
    try:
        validate_project(project)
        serialized = json.dumps(project_document(project, metadata), ensure_ascii=False, indent=2, allow_nan=False).encode('utf-8')
    except (ValueError, TypeError) as exc:
        _clear_calculation(edited=True)
        st.error('Confira as entradas: ' + str(exc))
        _coverage()
        return
    st.download_button('Salvar projeto local JSON', serialized, 'LRO_ponte_suspensa_local.json',
                       'application/json', key=_key('download_project'))
    st.caption('Campos vazios permanecem desconhecidos. Calcular com dados incompletos registra pendências, '
               'sem completar reações ou tensões globais por suposição.')
    if st.button('Calcular verificações locais', type='primary', key=_key('calculate')):
        from .underslung_local_adapter import calculate_local_project
        _clear_calculation()
        try:
            result = calculate_local_project(project)
            if result.get('input_signature') != project.signature():
                raise ValueError('Resultado sem vínculo válido com as entradas atuais.')
            st.session_state[_key('result')] = result
        except (ValueError, TypeError, ArithmeticError) as exc:
            st.error('O cálculo local não pôde ser concluído: ' + str(exc))
    result = st.session_state.get(_key('result'))
    if result is not None and result.get('input_signature') != project.signature():
        _clear_calculation(edited=True)
        result = None
    if st.session_state.get(_key('edited')):
        st.caption('Entradas alteradas: resultados e memória anteriores foram retirados. Recalcule para atualizá-los.')
    if result is not None:
        _results(project, result, metadata)
    _coverage(result)
