"""Qualified, supplemental NBR 8800 local-web checks for a top-running wheel.

This adapter reuses the audited §5.7 calculator; it does not convert the actions
of NBR 10084/8400 into ELU, design stiffeners, or solve combined plate buckling.
It intentionally does NOT relax WebPanel8400Input.no_transverse_compression.
All source page numbers below are the printed page numbers.
"""
from __future__ import annotations
from .signatures import canonical_numbers

from dataclasses import asdict, fields, replace
import hashlib
import json
from typing import Any

from .model import Project, RunwayLocalCase, Patch8800Qualification, validate


SOURCES = {
    "supplement": "ABNT NBR 10084:2020, 9.1.1, p. 4",
    "method_selection": "ABNT NBR 8400-2:2019, introdução do Anexo C (informativo), p. 46",
    "elu": "ABNT NBR 8800:2024, 4.8.7.2.1, pp. 21–22",
    "gamma": "ABNT NBR 8800:2024, 4.9.2.1 e Tabela 3, p. 25",
    "domain": "ABNT NBR 8800:2024, 5.7.1, pp. 63–64",
    "yield": "ABNT NBR 8800:2024, 5.7.3, pp. 64–65",
    "cripple": "ABNT NBR 8800:2024, 5.7.4, p. 65",
    "lateral": "ABNT NBR 8800:2024, 5.7.5, pp. 65–66",
    "opposed": "ABNT NBR 8800:2024, 5.7.6, p. 66",
    "ends": "ABNT NBR 8800:2024, 5.7.8, p. 67",
    "stiffeners": "ABNT NBR 8800:2024, 5.7.9, pp. 67–68",
    "panel": "ABNT NBR 8400-2:2019, C.2.1 e Tabela C.5, pp. 51–52",
    "lef": "ABNT NBR 10084:2020, 9.1.3.1 e Tabela 1, pp. 5–7",
}


def patch_input_signature(project: Project, case: RunwayLocalCase,
                          qualification: Patch8800Qualification | None = None) -> str:
    """Snapshot of engineering inputs/evidence, excluding the confirmation itself."""
    row = asdict(case)
    row.pop("patch_qualification", None)
    row.pop("notes", None)
    evidence = asdict(qualification if qualification is not None else case.patch_qualification)
    evidence.pop("inputs_current_confirmed", None)
    evidence.pop("qualified_input_signature", None)
    data = {"case": row, "span_m": project.span_m, "mode": project.mode,
            "robot_model": project.robot_model,
            "action_basis": project.action_basis, "section": asdict(project.section),
            "material": asdict(project.material),
            "segments": [asdict(s) for s in project.segments if s.name == case.segment],
            "qualification_evidence": evidence}
    return hashlib.sha256(json.dumps(canonical_numbers(data), sort_keys=True, ensure_ascii=False,
                                     allow_nan=False).encode("utf-8")).hexdigest()


def _result() -> dict[str, Any]:
    return {
        "kind": "local_web_patch_8800", "status": "PENDENTE",
        "local_web_status": "PENDENTE", "input_valid": True,
        "local_web_subset_verified": False, "full_compliance": False,
        "approval": False, "checks": [], "values": {}, "errors": [],
        "pending": [], "sources": dict(SOURCES),
        "remaining_assessments": [
            {"id": "combined_panel_buckling", "source": SOURCES["panel"],
             "detail": "O modelo C.2 implementado exclui compressão transversal de roda. Sua aplicabilidade e a suficiência do conjunto de verificações prescritivas devem ser justificadas pelo responsável. Esta limitação do software não estabelece exigência normativa universal de análise de cascas ou de uma equação adicional de interação."},
            {"id": "rail_flange_interface", "source": SOURCES["domain"],
             "detail": "Verificar separadamente trilho, contato roda-trilho, fixações e flexão transversal da mesa sob a distribuição real. A qualificação de ln não dimensiona essas interfaces."},
            {"id": "complete_runway_design", "source": SOURCES["supplement"],
             "detail": "Demais posições de rodas, apoios, estabilidade global, tensões locais/globais concomitantes, fadiga e deformações permanecem verificações próprias."},
        ],
    }


def qualify_local_web_8800(project: Project, case: RunwayLocalCase,
                           qualification: Patch8800Qualification | dict[str, Any]) -> dict[str, Any]:
    """Audit the four local web mechanisms, with independent normal-ELU input.

    The complete Project is validated before the numerical engine is called.
    No original object is mutated. The result is strict-JSON serializable even
    when malformed inputs or unrepresentable derived values are rejected.
    A successful local subset still has status RESULTADO PARCIAL and retains
    the named remaining assessments; it is never a complete 10084 approval.
    """
    out = _result()
    try:
        q = Patch8800Qualification.from_dict(qualification) if isinstance(qualification, dict) else qualification
    except (TypeError, ValueError) as exc:
        out.update(input_valid=False, status="ENTRADA INVÁLIDA", errors=[str(exc)])
        return out
    if not isinstance(q, Patch8800Qualification):
        out.update(input_valid=False, status="ENTRADA INVÁLIDA", errors=["Patch8800Qualification obrigatório."])
        return out
    for f in fields(q):
        value = getattr(q, f.name)
        required_bool = f.name in {"normal_elu_confirmed", "component_checks_method_selected", "bearing_at_flange_not_web_lef_confirmed", "nearest_end_distance_confirmed", "major_axis_first_yield_confirmed", "inputs_current_confirmed"}
        if required_bool and type(value) is not bool:
            out["errors"].append(f"{f.name}: booleano obrigatório.")
        elif not required_bool and not isinstance(value, str):
            out["errors"].append(f"{f.name}: texto obrigatório.")
    if not isinstance(project, Project) or not isinstance(case, RunwayLocalCase):
        out["errors"].append("Project e RunwayLocalCase obrigatórios; não utilizar Local10084Input ou carga de serviço.")
    if out["errors"]:
        out.update(input_valid=False, status="ENTRADA INVÁLIDA")
        return out
    # Substitute only the selected case for validation/calculation. Other
    # project inputs remain subject to the same central validation contract.
    scoped_case = replace(case, patch_qualification=q)
    scoped = replace(project, runway_local=[scoped_case])
    try:
        out["errors"] = validate(scoped)
    except (TypeError, ValueError, OverflowError, AttributeError) as exc:
        out["errors"] = ["Projeto não validável: " + str(exc)]
    if out["errors"]:
        out.update(input_valid=False, status="ENTRADA INVÁLIDA")
        return out
    out["input"] = {"case": asdict(case), "qualification": asdict(q)}
    if project.mode != "runway" or not project.section.doubly_symmetric:
        out.update(status="FORA DO DOMÍNIO", local_web_status="FORA DO DOMÍNIO")
        out["pending"].append("Adaptador restrito a viga de rolamento superior com seção I duplamente simétrica.")
        return out
    if q.stiffener_credit != "none":
        out.update(status="FORA DO DOMÍNIO", local_web_status="FORA DO DOMÍNIO")
        out["pending"].append("Não se atribui aumento de resistência a enrijecedores ou chapas de reforço. Dimensionamento externo conforme 5.7.9 não pode ser substituído pela declaração de sua existência.")
        return out
    gates = []
    if not q.inputs_current_confirmed or q.qualified_input_signature != patch_input_signature(project, case, q):
        gates.append("Reconfirmar a aplicação das referências aos dados atuais de geometria, material, carregamento e vínculos; os dados foram alterados ou ainda não foram vinculados à qualificação.")
    if not q.case_name.strip() or q.case_name != case.name:
        gates.append("Vincular a qualificação ao nome exato do caso local ELU.")
    if not q.normal_elu_confirmed:
        gates.append("Confirmar combinação última normal independente, com fatores de ação já aplicados e gamma_a1=1,10; não converter os casos I/II/III por fator presumido.")
    if q.first_yield_basis not in {"conservative_16E", "qualified_major_axis"}:
        gates.append("Selecionar Cr=16E conservador ou qualificar o início de escoamento por flexão no eixo forte.")
    elif q.first_yield_basis == "qualified_major_axis" and (not q.major_axis_first_yield_confirmed or not q.first_yield_source.strip()):
        gates.append("Para habilitar Cr=32E, demonstrar que fyWx representa o início de escoamento aplicável, sem contribuição relevante de N, My ou empenamento; identificar a verificação.")
    if not q.supplement_selection_source.strip():
        gates.append("Registrar a justificativa de adoção suplementar da NBR 8800 para o mecanismo local, conforme 10084 9.1.1.")
    if not q.component_checks_method_selected or not q.component_method_scope_source.strip():
        gates.append("Identificar origem, aplicabilidade e limites do método por verificações prescritivas NBR adotado para esta viga, conforme introdução do Anexo C da NBR 8400-2; não presumir suficiência apenas por haver enrijecedores.")
    if q.bearing_model not in {"physical_flange_contact", "qualified_rail_distribution"}:
        gates.append("Qualificar ln como comprimento da força na face externa da mesa: contato físico ou distribuição pelo trilho calculada externamente.")
    if not q.bearing_at_flange_not_web_lef_confirmed:
        gates.append("Confirmar que ln não é automaticamente o lef de pressão da alma da NBR 10084; evitar dupla dispersão pela mesa.")
    if not q.nearest_end_distance_confirmed:
        gates.append("Confirmar a distância da força à extremidade física mais próxima.")
    if case.distance_to_end_mm > project.span_m * 500 + 1e-8:
        gates.append("Distância à extremidade mais próxima excede metade do vão; revisar geometria do domínio simplesmente delimitado.")
    if case.bearing_length_mm > project.span_m * 1000:
        gates.append("Comprimento carregado excede o vão; não representa o caso localizado deste domínio.")
    if not q.lateral_length_source.strip():
        gates.append("Identificar o maior comprimento destravado envolvendo o ponto de força, considerando ambas as mesas (5.7.5.2).")
    if not q.restraint_detail_source.strip():
        gates.append("Identificar o detalhe que fundamenta deslocamento relativo e rotação da mesa; trilho não é travamento automático.")
    if q.support_end_condition not in {"torsion_restrained_or_web_connected", "externally_verified_full_depth_stiffeners"} or not q.support_end_source.strip():
        gates.append("Qualificar apoios/extremidades conforme 5.7.8: restrição de rotação/ligação da alma, ou enrijecedores de altura total soldados às mesas e à alma verificados externamente.")
    if project.section.fabrication == "welded" and (not case.flange_web_transfer_verified or not q.flange_web_transfer_source.strip()):
        gates.append("Identificar verificação da solda mesa-alma para transferir a força localizada ELU (5.7.1/5.4.5).")
    if case.opposed_compression_pair and not q.opposed_pair_force_source.strip():
        gates.append("Identificar o par na mesma seção e demonstrar que a força informada representa cada força do par; reação total e roda isolada não são intercambiáveis.")
    if gates:
        out["pending"] = gates
        return out
    from .engine import _runway_local_checks_core, runway_local_resistances
    try:
        all_checks = _runway_local_checks_core(scoped)
        checks = [asdict(c) for c in all_checks if not c.id.endswith(("_rail", "_transfer"))]
        if any(c["id"].endswith("_domain") for c in checks):
            out.update(checks=checks, pending=[c["detail"] for c in checks])
            return out
        values = runway_local_resistances(scoped, scoped_case)
        values.update(gamma_a1=project.material.gamma_a1, demand_elu_kn=case.uls_load_kn,
                      action_multiplier_applied=1.0, stiffener_capacity_credit=0.0)
        for c in checks:
            suffix = c["id"].rsplit("_", 1)[-1]
            c["source"] = SOURCES.get(suffix, SOURCES["domain"])
        json.dumps({"checks": checks, "values": values}, allow_nan=False)
    except (ArithmeticError, ValueError) as exc:
        out.update(input_valid=False, status="ENTRADA INVÁLIDA", errors=["Resultado numérico não representável: " + str(exc)])
        return out
    out.update(checks=checks, values=values)
    statuses = {c["status"] for c in checks}
    good = {"ATENDE", "NÃO APLICÁVEL NO DOMÍNIO"}
    if "NÃO ATENDE" in statuses:
        out.update(status="NÃO ATENDE", local_web_status="NÃO ATENDE")
    elif any(s.startswith("FORA") for s in statuses):
        out.update(status="FORA DO DOMÍNIO", local_web_status="FORA DO DOMÍNIO")
    elif len(checks) == 4 and statuses <= good:
        out.update(status="RESULTADO PARCIAL", local_web_status="ATENDE NO DOMÍNIO LOCAL",
                   local_web_subset_verified=True)
    else:
        out["pending"].extend(c["detail"] for c in checks if c["status"] not in good)
    # Never consume or modify any 8400/10084 input, including its panel gates.
    return out
