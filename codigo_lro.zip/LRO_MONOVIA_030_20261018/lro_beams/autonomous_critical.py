"""Stationary cuts of the already solved coupled beam, without a spatial mesh.

My and lateral displacement reuse exact piecewise-polynomial beam roots with
actual brace reactions. Between load/couple events, B solves B''=k²B−m and
B' is a sum of two real exponentials, hence has at most one zero. Recursive
monotone-interval isolation therefore finds the roots of B, theta', and the
rail slope v'+z theta' (cubic polynomial plus two exponentials). Functions and
derivatives are analytic; root coordinates have an explicit bisection tolerance.

These cuts address individual response extrema, not every nonlinear stress or
resistance interaction. Train translation still requires the existing numerical
convergence study. No extra brace fixity or load-distribution assumption is made.
"""
import math
from collections import namedtuple
from .moving_beam import BeamModel,PointLoad,UniformLoad,solve_position


def _monotone_roots(function,left,right,turning_points=(),*,tolerance):
    """Roots of a continuous function given ALL derivative roots in interval."""
    nodes=sorted({left,right,*(x for x in turning_points if left<x<right)})
    values=[function(x) for x in nodes]
    if any(not math.isfinite(v) for v in values):raise ValueError('Nonfinite stationary-cut derivative')
    scale=max(map(abs,values),default=0.)
    # Include numerically tangent roots at known derivative zeros. Extra cuts
    # are harmless; they do not remove ordinary sign-changing roots.
    roots={x for x,y in zip(nodes,values) if y==0 or (scale and abs(y)<=1e-11*scale)}
    for a,b,fa,fb in zip(nodes,nodes[1:],values,values[1:]):
        if fa==0 or fb==0 or (fa>0)==(fb>0):continue
        for _ in range(80):
            mid=(a+b)/2
            if b-a<=tolerance or mid in (a,b):break
            fm=function(mid)
            if not math.isfinite(fm):raise ValueError('Nonfinite stationary-cut derivative')
            if fm==0:a=b=mid;break
            if (fa>0)==(fm>0):a,fa=mid,fm
            else:b,fb=mid,fm
        roots.add((a+b)/2)
    return tuple(sorted(x for x in roots if left<x<right))


_Derivatives=namedtuple('_Derivatives','theta_prime_per_mm bimoment_nmm2 warping_torque_nmm')


def _propagate_torsion_derivatives(beam,anchor,x_mm,uniform_torque):
    """Evaluate the same solution inside a load-free interval from its midpoint.

    Stable series avoid subtracting m/k² for small k. The caller limits |k dx|
    to two, avoiding exponential error magnification in long stiff intervals.
    """
    delta=x_mm-anchor.x_mm;u=beam.k*delta;u2=u*u
    if abs(u)<.01:
        sinhc=1+u2*(1/6+u2*(1/120+u2*(1/5040+u2/362880)))
        c2=.5+u2*(1/24+u2*(1/720+u2*(1/40320+u2/3628800)))
        s3=1/6+u2*(1/120+u2*(1/5040+u2*(1/362880+u2/39916800)))
        cosh=1+u2*c2
    else:
        sinhc=math.sinh(u)/u;cosh=math.cosh(u)
        c2=2*math.sinh(u/2)**2/u2;s3=(sinhc-1)/u2
    B0=anchor.bimoment_nmm2;W0=anchor.warping_torque_nmm;m=uniform_torque
    B=B0*cosh+W0*delta*sinhc-m*delta*delta*c2
    W=(beam.GJ/beam.ECw*B0-m)*delta*sinhc+W0*cosh
    tp=anchor.theta_prime_per_mm-(B0*delta*sinhc+W0*delta*delta*c2-m*delta**3*s3)/beam.ECw
    return _Derivatives(tp,B,W)


def lateral_polynomial_solution(response):
    """Exact lateral plane, including brace forces and point minor couples."""
    lat=response.lateral_torsion;b=lat.beam
    # Keep the original physical metre endpoint. Multiplication to mm and
    # back can move it by one ulp; no geometric tolerance is enlarged.
    L=response.vertical.beam.span_m
    model=BeamModel(L,b.E_mpa,lat.Iy_mm4,lat.Iy_mm4)
    loads=tuple(PointLoad(0. if q.x_mm==0 else L if q.x_mm==b.span_mm else q.x_mm/1000,0.,q.horizontal_n/1000,q.name,
                          minor_moment_knm=q.minor_couple_nmm/1e6) for q in lat.loads)
    return solve_position(model,loads,UniformLoad(horizontal_kn_per_m=lat.uniform_horizontal_n_per_mm)).horizontal


def coupled_critical_positions(response,*,position_tolerance_mm=None):
    """Return metre coordinates of analytic-response extrema and load events.

    Default root-coordinate tolerance is max(1e−6 mm, 1e−9*span). End one-sided
    limits are taken inside each event interval, including sectorial-couple B
    jumps. Zero functions need only their interval endpoints.
    """
    lat=response.lateral_torsion;tor=lat.torsion;b=lat.beam;L=b.span_mm
    tolerance=max(1e-6,1e-9*L) if position_tolerance_mm is None else position_tolerance_mm
    if isinstance(tolerance,bool) or not isinstance(tolerance,(int,float)) or not math.isfinite(tolerance) or tolerance<=0:
        raise ValueError('Positive finite root-coordinate tolerance required')
    plane=lateral_polynomial_solution(response)
    def metres(x):return 0. if x==0 else response.vertical.beam.span_m if x==L else x/1000
    events=sorted({0.,L,*(q.x_mm for q in lat.loads),*(q.x_mm for q in tor.point_torques),
                   *(q.x_mm for q in tor.point_bimoments)})
    positions={metres(x) for x in events}|set(plane.critical_positions())
    if not (tor.uniform_torque_nmm_per_mm or any(q.torque_nmm for q in tor.point_torques)
            or any(q.sectorial_couple_nmm2 for q in tor.point_bimoments)):
        return tuple(sorted(positions))
    EI=b.E_mpa*lat.Iy_mm4;ECw=b.ECw;k2=b.GJ/ECw
    m=tor.uniform_torque_nmm_per_mm;h=response.rail_level_mm
    state_cache={}
    for left,right in zip(events,events[1:]):
        if right-left<=tolerance:continue
        anchor=tor.at((left+right)/2) if b.k*(right-left)<=4 else None
        def state(x):
            side='left' if x==right else 'right'
            key=(x,side)
            if key not in state_cache:
                state_cache[key]=_propagate_torsion_derivatives(b,anchor,x,m) if anchor is not None else tor.at(x,side)
            return state_cache[key]
        def roots(f,turns=()):
            return _monotone_roots(f,left,right,turns,tolerance=tolerance)
        # Tw=B' is A exp(kx)+B exp(-kx), at most one zero between events.
        tw_roots=roots(lambda x:state(x).warping_torque_nmm)
        b_roots=roots(lambda x:state(x).bimoment_nmm2,tw_roots)
        theta_roots=roots(lambda x:state(x).theta_prime_per_mm,b_roots)
        # Stationary Tw, since B''=k²B−m. Saint-Venant torque extrema use B=0.
        tw_stationary=roots(lambda x:k2*state(x).bimoment_nmm2-m,tw_roots)
        positions.update(metres(x) for x in (*tw_roots,*b_roots,*theta_roots,*tw_stationary))
        if h:
            # f=rail slope. f'''' is proportional to Tw. Work down the exact
            # derivative chain, retaining all monotonic subintervals.
            f3_roots=roots(lambda x:lat.uniform_horizontal_n_per_mm/EI+h*(m-k2*state(x).bimoment_nmm2)/ECw,tw_roots)
            f2_roots=roots(lambda x:-plane.shear_kn(metres(x),'left' if x==right else 'right')*1000/EI-h*state(x).warping_torque_nmm/ECw,f3_roots)
            f1_roots=roots(lambda x:-plane.moment_knm(metres(x),'left' if x==right else 'right')*1e6/EI-h*state(x).bimoment_nmm2/ECw,f2_roots)
            f0_roots=roots(lambda x:plane.slope_rad(metres(x))+h*state(x).theta_prime_per_mm,f1_roots)
            positions.update(metres(x) for x in f0_roots)
    return tuple(sorted(positions))
