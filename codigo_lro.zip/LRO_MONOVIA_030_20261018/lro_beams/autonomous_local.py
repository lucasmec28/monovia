"""Automatic, source-traceable local effects for the autonomous runway model.

No legacy qualification flag is manufactured. This is a separate physical
adapter and conservative envelope of the NBR 10084 simplified elastic model,
not a plate FE solution, resistance check, fatigue history or fabrication release.
Coordinates: x from support A, z downward from the top clear-web edge, mm.
Sources: supplied NBR 10084:2020, printed pp.5–8, visually checked.
"""
from __future__ import annotations
from dataclasses import replace
import math
from .autonomous_model import AutonomousProject, validate_autonomous
from .autonomous_actions import ActionFactors
from .autonomous_response import CaseFactors, case_loads,fixed_permanent_loads
from .moving_beam import BeamModel, translate_train, solve_position
from .runway_local_10084 import Wheel10084, _uniform_envelope, _hyperbolic_ratio

COMPRESSION_SOURCE = 'ABNT NBR 10084:2020, 9.1.3.1, Tabela 1(b), Figuras 1–3, pp.5–7'
TORSION_SOURCE = 'ABNT NBR 10084:2020, 9.1.3.2–9.1.3.4, pp.7–8'
RECTANGLE_SOURCE = ('S. Haanappel, Forming of UD fibre reinforced thermoplastics, University of Twente, '
                    '2013, §4.3, Eq.(4.9), p.77; https://ris.utwente.nl/ws/files/6062044/thesis_S_Haanappel.pdf')


def rectangle_torsion_constant(width_mm: float, thickness_mm: float) -> float:
    """Saint-Venant rectangle constant with a conservative bounded series tail.

    After odd n<=199, sum omitted tanh/n^5 <= integral_199^infinity x^-5 dx.
    Subtracting that upper bound makes J slightly smaller, never artificially
    stiffer. This is flange-only J, not whole-section J or flexural Irf.
    """
    if any(isinstance(v,bool) or not isinstance(v,(int,float)) or not math.isfinite(v) or v<=0
           for v in (width_mm,thickness_mm)):
        raise ValueError('Dimensões do retângulo devem ser positivas e finitas.')
    b,t=max(width_mm,thickness_mm),min(width_mm,thickness_mm)
    series=math.fsum(math.tanh(n*math.pi*b/(2*t))/n**5 for n in range(1,200,2))
    return b*t**3/3*(1-192*t/(math.pi**5*b)*(series+1/(4*199**4)))


def stiffener_positions_mm(p: AutonomousProject) -> tuple[float,...]:
    """Actual uniform layout, including both supports and the final shorter bay."""
    length=p.span_m*1000
    if p.stiffener_layout=='none_or_unknown':return ()
    if p.stiffener_layout=='paired_full_height_supports':return (0.,length)
    spacing=p.stiffener_spacing_m*1000
    if not math.isfinite(spacing) or spacing<=0:raise ValueError('Espaçamento de enrijecedores inválido.')
    if length/spacing>10000:raise ValueError('Malha de enrijecedores excede 10.000 painéis.')
    return tuple([0.]+[i*spacing for i in range(1,math.ceil(length/spacing))]+[length])


def _patch_bound(patches):
    """Maximum sum of base pressures over maximal 45-degree influence intervals.

    A patch at any web depth is contained in this interval and its pressure is
    no greater than the supplied base pressure. This tightens the triangle
    bound by excluding patches which can NEVER reach the same x at any depth.
    """
    ends=sorted({point for left,right,_ in patches for point in (left,right)})
    probes=ends+[(a+b)/2 for a,b in zip(ends,ends[1:]) if b>a]
    return max((math.fsum(value for a,b,value in patches if a<=x<=b) for x in probes),default=0.)


def _calculate_local_components(p: AutonomousProject, factors: ActionFactors, translation_m: float,
                               *, wheel_vertical_kn=None, longitudinal_sign: int=1, _physical_uls=False, supplemental_fan=False) -> dict:
    """Concurrent local envelope; all loads already use ONE 10084 action case.

    wheel_vertical_kn, when supplied, replaces the complete G2+dynamic-Q load of
    each wheel (e.g. an actual test reaction). It is never multiplied again.
    The top/bottom transverse-compression bound includes actual concurrent
    reactions. Dropping the interior relief and the spreading benefit is an
    upper bound of the adopted positive 45-degree pressure model: every patch
    has width >= its complete base footprint. A truncated BASE footprint is
    outside this derivation. No support capacity or stiffener credit is taken.
    """
    if not isinstance(supplemental_fan,bool):raise ValueError('O estudo complementar do leque deve ser booleano.')
    if not isinstance(p,AutonomousProject):raise TypeError('Projeto autônomo obrigatório.')
    errors=validate_autonomous(p)
    if errors:raise ValueError('; '.join(errors))
    uls=_physical_uls and isinstance(factors,ActionFactors) and factors.basis.startswith('nbr8800_uls_normal')
    if not isinstance(factors,ActionFactors) or (not uls and factors.basis not in ('nbr10084_8400_admissible','nbr8400_fatigue_case_i_without_mx')):
        raise ValueError('Efeitos locais exigem vetor de ações NBR 10084/8400, separado do ELU 8800.')
    if not uls and factors.code not in ('I','II','fatigue_8400') and not factors.code.startswith('III:'):
        raise ValueError('Identifique o caso I, II ou evento III.')
    if isinstance(translation_m,bool) or not isinstance(translation_m,(int,float)) or not math.isfinite(translation_m):
        raise ValueError('Posição do trem deve ser finita.')
    cf=CaseFactors(factors.code,factors.dead_support,factors.dead_equipment,factors.lifted,
                   factors.transverse,factors.longitudinal,factors.source,extra_dead=factors.extra_dead)
    g,udl,train=case_loads(p,cf,longitudinal_sign=longitudinal_sign)
    if wheel_vertical_kn is not None:
        if len(wheel_vertical_kn)!=len(train) or any(isinstance(v,bool) or not isinstance(v,(int,float)) or
                not math.isfinite(v) or v<0 for v in wheel_vertical_kn):
            raise ValueError('Informe uma força vertical total não negativa por roda.')
        train=tuple(replace(w,vertical_kn=float(v)) for w,v in zip(train,wheel_vertical_kn))
    beam=BeamModel(p.span_m,p.material.E_mpa,g.Ix_mm4,g.Iy_mm4)
    loads=translate_train(beam,train,translation_m)
    solution=solve_position(beam,loads,udl,fixed_loads=fixed_permanent_loads(p,cf,udl))
    reactions=(solution.reactions.vertical_left_kn,solution.reactions.vertical_right_kn)
    s=p.section;r=p.rail;tw=s.tw_mm;hw=s.d_mm-s.tf_mm-s.bottom_thickness
    lower=-p.beam_end_left_mm;upper=p.span_m*1000+p.beam_end_right_mm
    pending=[];audit=[]
    result={'case':factors.code,'translation_m':translation_m,'basis':factors.basis,'approval':False,
            'input_valid':True,'local_effects_bound_complete':False,'compression_bound_complete':False,
            'prescribed_scope_complete':False,'local_model':'nbr10084_prescribed_nominal',
            'values':{},'stresses':{},'wheels':[],'pending':pending,'audit':audit,
            'sources':{'compression':COMPRESSION_SOURCE,'torsion':TORSION_SOURCE,'flange_J':RECTANGLE_SOURCE},
            'reactions_kn':{'A':reactions[0],'B':reactions[1]},'physical_limits_mm':[lower,upper],
            'limitations':['Envelope de máximos do modelo elástico simplificado; não é estado simultâneo em um ponto.',
                'Não verifica resistência de chapas, enrijecedores, soldas, apoio ou esmagamento/flambagem local NBR 8800.',
                'Não utilizar o envelope como histórico assinado de fadiga.',
                'NBR 10084 solicita a combinação com tensões globais e limite admissível do mesmo caso.',
                'A continuidade física além dos apoios não acrescenta automaticamente um balanço carregado.']}
    def issue(text):pending.append(text)
    if abs(r.offset_from_web_mm)>1e-9:issue('Dispersão local desta implementação exige trilho centrado sobre a alma; offset físico não nulo.')
    if r.local_attachment!='non_rigid':issue('Tabela 1(b) exige fixação não rígida declarada; outros vínculos precisam de propriedades próprias.')
    if r.continuity!='continuous_no_joint':issue('Junta/descontinuidade do trilho altera a dispersão; modelo contínuo não aplicável.')
    if r.width_mm<=0 or r.height_mm<=0 or r.inertia_cm4<=0:issue('Trilho precisa de dimensões e inércia vertical positivas para a Tabela 1.')
    if r.width_mm>s.bf_mm:issue('Base do trilho excede a largura da mesa superior.')
    if p.support_contact!='centered_under_web':issue('Dispersão da reação exige contato inferior centrado sob a alma.')
    if min(reactions)<-1e-9:issue('Reação de arrancamento requer outro caminho de forças; contato compressivo não basta.')
    excluded=[]
    for w in train:
        x=(translation_m+w.offset_m)*1000
        if x<0 or x>p.span_m*1000:
            boundary_limit=min(abs(x),abs(x-p.span_m*1000))<=1e-7
            geometric_overlap=lower<=x<=upper and w.vertical_kn>0
            on_projection=geometric_overlap and not boundary_limit and p.wheel_travel_scope=='including_physical_projections'
            excluded.append({'name':w.name,'x_mm':x,'fz_kn':w.vertical_kn,'on_physical_projection':on_projection,
                'geometrically_over_projection':geometric_overlap,'boundary_limit':boundary_limit,
                'reason':'Fora do intervalo de passagem modelado entre eixos dos apoios.'})
            if on_projection:issue(w.name+': posição externa ao vão sobre a projeção física; carga de balanço não resolvida pelo modelo biapoiado.')
    result['excluded_wheels']=excluded
    if pending:return result
    bef=min(r.width_mm+r.height_mm+s.tf_mm,s.bf_mm)
    ifef=bef*s.tf_mm**3/12
    lef=3.25*((r.inertia_cm4*10000+ifef)/tw)**(1/3)
    support_length=p.support_bearing_length_mm
    result['values'].update(bef_mm=bef,Ifef_mm4=ifef,lef_mm=lef,hw_mm=hw,
                            support_footprint_mm=support_length,beam_self_weight_in_reactions=True)
    audit.append({'equation':'lef = 3.25 ((Ir + bef tf³/12)/tw)^(1/3)','value':lef,'unit':'mm','source':COMPRESSION_SOURCE})
    wheel_rows=[]
    for w in loads:
        x=w.position_m*1000
        complete=(x-lef/2>=lower-1e-9 and x+lef/2<=upper+1e-9)
        if not complete:issue(w.name+': pegada lef cortada pela extremidade física; não usar correção de borda não demonstrada.')
        wheel_rows.append({'name':w.name,'x_mm':x,'fz_kn':w.vertical_kn,'footprint_complete':complete,
                           'sigma0z_top_mpa':w.vertical_kn*1000/(lef*tw)})
    for x,name in ((0.,'A'),(p.span_m*1000,'B')):
        if x-support_length/2<lower-1e-9 or x+support_length/2>upper+1e-9:
            issue('Apoio '+name+': pegada inferior cortada pela extremidade física.')
    result['wheels']=wheel_rows
    if pending:return result
    uniform=[Wheel10084(w['name'],w['x_mm'],w['fz_kn']) for w in wheel_rows]
    pressures=[w['sigma0z_top_mpa'] for w in wheel_rows]
    top=_uniform_envelope(uniform,lef,pressures) if uniform else {'maximum_mpa':0.,'overlap_present':False,'critical_interval_x_mm':None}
    # For any x,z, triangle inequality and positive force conservation:
    # p_wheel(x,z)<=Fi/(lef*tw); p_support(x,z)<=Ri/(ln*tw).
    # No far-from-support factor (1-z/hw)^2 and no favourable subtraction.
    wheel_patches=[(w['x_mm']-lef/2-hw,w['x_mm']+lef/2+hw,w['sigma0z_top_mpa']) for w in wheel_rows]
    support_patches=[(x-support_length/2-hw,x+support_length/2+hw,max(0.,v)*1000/(support_length*tw))
                     for x,v in zip((0.,p.span_m*1000),reactions)]
    wheel_bound=_patch_bound(wheel_patches)
    reaction_bound=_patch_bound(support_patches)
    compression=_patch_bound(wheel_patches+support_patches)
    result['compression_patches']=[{'kind':kind,'left_mm':a,'right_mm':b,'pressure_mpa':value}
        for kind,patches in (('wheel',wheel_patches),('support',support_patches)) for a,b,value in patches]
    result['compression_bound_complete']=True
    result['nominal_model_complete']=True
    result['elastic_field_upper_bound_proven']=False
    result['stresses'].update(wheel_top_envelope_mpa=top['maximum_mpa'],wheel_compression_bound_mpa=wheel_bound,
        support_compression_bound_mpa=reaction_bound,transverse_compression_bound_mpa=compression,
        wheel_local_shear_bound_mpa=.2*math.fsum(pressures),
        longitudinal_local_compression_bound_mpa=compression if supplemental_fan else 0.,
        local_shear_complete_bound_mpa=max(compression,.2*math.fsum(pressures)) if supplemental_fan else .2*math.fsum(pressures))
    result['fan_model']={'applied':supplemental_fan,'required_by_nbr10084':False,'complete':True,'nominal_model_complete':True,'elastic_field_upper_bound_proven':False,
        'qualification':'Limites provados dentro do leque nominal positivo adotado; o equilíbrio não prova majorante do campo elástico tridimensional real.',
        'hypothesis':'Leques positivos de compressão, direções das bielas limitadas a ±45°; modelo racional complementar à dispersão da NBR 10084, não campo normativo exato.',
        'derivation':'Para cada biela: σx=σz tan²θ e |τxz|=σz |tanθ|. Como σz≥0 e |tanθ|≤1, soma positiva implica σx,compressão≤C e |τxz|≤C. Tensão longitudinal adicional pertence a [−C,0].',
        'source':COMPRESSION_SOURCE,
        'longitudinal_interval_mpa':[-compression,0.],
        'shear_abs_bound_mpa':max(compression,.2*math.fsum(pressures))}
    result['top_patch_envelope']=top
    result['values']['near_support_wheels']=[w['name'] for w in wheel_rows
        if min(w['x_mm'],p.span_m*1000-w['x_mm'])<=hw+(lef+support_length)/2]
    audit.append({'equation':'sigma_z,bound = max_x Σ [base pressure_i · indicator(maximal 45° influence interval_i)]',
        'wheel_mpa':wheel_bound,'support_mpa':reaction_bound,'value':compression,'unit':'MPa',
        'derivation':'Em uma dispersão positiva a 45°, a largura nunca é menor que a pegada completa de base. Fi/(lef tw) e Rj/(ln tw) são limites superiores em MPa. Usam-se intervalos de influência de largura base+2hw; parcelas incapazes de alcançar o mesmo x são excluídas. Soma de máximas positivas, sem alívio (1-z/hw)² perto do apoio.',
        'source':COMPRESSION_SOURCE})
    result['limitations'].append('Rota nominal NBR10084: σz da dispersão de rodas e reação; τlocal=0,20σ0z das rodas, conservadoramente mantido em toda a altura. A norma não exige σx=C nem τ=C adicionais; o leque racional fica documentado como estudo complementar, aplicado somente quando solicitado explicitamente no código.')
    if r.wheel_guidance=='flanged':ey=r.wheel_rail_clearance_mm/2
    elif r.wheel_guidance=='guide_roller_unguided_side' and r.head_width_mm>0:ey=r.head_width_mm/4
    else:
        issue('Selecione a guia física da roda e sua folga ou largura de cabeça; a excentricidade informada não inventa esses dados.')
        return result
    ey=max(ey,abs(r.lateral_eccentricity_mm))
    positions=stiffener_positions_mm(p)
    result['values']['stiffener_positions_mm']=positions
    if not positions or p.stiffener_connection not in ('web_and_both_flanges_welded','web_only_welded') or p.stiffener_outstand_mm<=0:
        issue('Flexão local exige enrijecedores transversais de geometria declarada soldados à alma.')
        return result
    if p.stiffener_outstand_mm>(min(s.bf_mm,s.bottom_width)-tw)/2:
        issue('Largura saliente dos enrijecedores excede o espaço sob as mesas; ajustar a geometria da ligação.')
        return result
    spacings=tuple(b-a for a,b in zip(positions,positions[1:]))
    it=rectangle_torsion_constant(s.bf_mm,s.tf_mm)
    coefficients=[]
    for a in spacings:
        eta=math.sqrt(.75*a*tw**3/it*_hyperbolic_ratio(math.pi*hw/a))
        coefficients.append(6/(a*tw**2)*eta*math.tanh(eta))
    coefficient=max(coefficients)
    sigma_tv=math.fsum(w['fz_kn']*1000*ey*coefficient for w in wheel_rows)
    horizontal_lever=r.height_mm+s.tf_mm/2
    sigma_th=math.fsum(abs(w.horizontal_kn)*1000*horizontal_lever*coefficient for w in loads)
    sigma_t=sigma_tv+sigma_th
    result['values'].update(ey_envelope_mm=ey,top_flange_J_mm4=it,panel_lengths_mm=spacings,
                           governing_torsion_coefficient_per_mm3=coefficient,horizontal_local_lever_mm=horizontal_lever)
    result['stresses'].update(sigmaT_bound_mpa=sigma_t,sigmaT_vertical_bound_mpa=sigma_tv,
        sigmaT_horizontal_bound_mpa=sigma_th,sigma_cz_bound_mpa=compression+.75*sigma_tv+sigma_th,
        transverse_prescribed_design_interval_mpa=[-(compression+.75*sigma_tv+sigma_th),sigma_t],
        transverse_full_component_interval_mpa=[-(compression+sigma_t),sigma_t])
    audit.append({'equation':'sigma_T,bound = Σ |Fi ey| max_panel[6 η tanh(η)/(a tw²)]',
                  'value':sigma_tv,'unit':'MPa','source':TORSION_SOURCE})
    audit.append({'equation':'sigma_T,H,bound = Σ |Hi| (hr+tf/2) max_panel[6 η tanh(η)/(a tw²)]',
        'value':sigma_th,'unit':'MPa','source':'Extensão racional por linearidade do modelo local de torção da aba, NBR10084 9.1.3.3.',
        'derivation':'Binário horizontal relativo ao eixo médio da mesa superior; não altera o torque global. Sem redução 0,75 desta parcela independente.'})
    result['local_effects_bound_complete']=True
    result['prescribed_scope_complete']=True
    result['prescribed_scope']='NBR10084 9.1.3: compressão nominal de rodas/reação, cisalhamento local das rodas e flexão local Fz·ey; combinação com os efeitos globais do mesmo caso. Não é majorante do campo elástico tridimensional.'
    result['horizontal_local_extension']={'applied':sigma_th>0,'required_explicitly_by_9_1_3_3':False,
        'sigmaT_bound_mpa':sigma_th,'model':'Extensão racional linear do modelo de distorção local da mesa/alma, sob H·(hr+tf/2).',
        'separation_from_global_torsion':'A torção global de Vlasov usa a seção transversal indeformável; esta parcela é flexão transversal local da alma pela rotação da mesa e não acrescenta torque ao equilíbrio global.'}
    result['limitations'].append('σcz inclui compressão das rodas/reações + 0,75 σT,Fz + σT,H. A soma de máximos é conservadora dentro do modelo normativo, sem benefício resistente dos enrijecedores.')
    return result


def combine_local_global_bounds(local: dict, *, longitudinal_abs_mpa: float,
                                global_shear_bound_mpa: float, fy_mpa: float, fu_mpa: float) -> dict:
    """Conservative elastic combination, not a fabricated point stress tensor.

    Uses FULL sigmaT for the transverse normal component. The 0.75 coefficient
    belongs only to the specific 10084 sigma_cz check and is not a reduction of
    the tensor component in von Mises. The opposite-sign cross term +SX*SZ
    bounds either sign of global longitudinal stress. A failed upper-bound
    check requests a refined assessment; it does not prove actual failure.
    Caller must supply global bounds for the SAME case and train position.
    """
    from .autonomous_fatigue import elastic_allowables_autonomous
    for value in (longitudinal_abs_mpa,global_shear_bound_mpa):
        if isinstance(value,bool) or not isinstance(value,(int,float)) or not math.isfinite(value) or value<0:
            raise ValueError('Limites de tensão devem ser magnitudes finitas não negativas.')
    if not local.get('local_effects_bound_complete'):
        return {'calculated':False,'approval':False,'checks':[],'pending':list(local.get('pending',[]))}
    case=local['case'].split(':')[0]
    caps=elastic_allowables_autonomous(fy_mpa,fu_mpa,case)
    sx=longitudinal_abs_mpa+local['stresses'].get('longitudinal_local_compression_bound_mpa',0.)
    sz=local['stresses']['transverse_compression_bound_mpa']+local['stresses']['sigmaT_bound_mpa']
    tau=global_shear_bound_mpa+local['stresses'].get('local_shear_complete_bound_mpa',local['stresses']['wheel_local_shear_bound_mpa'])
    vm=math.sqrt(sx*sx+sz*sz+sx*sz+3*tau*tau)
    checks=[]
    for identifier,demand,capacity,formula in (
        ('local_transverse_10084',local['stresses']['sigma_cz_bound_mpa'],caps['sigma_a_mpa'],'sigma_cz = C + 0.75 sigmaT,Fz + sigmaT,H'),
        ('global_local_web_equivalent',vm,caps['sigma_a_mpa'],'sqrt(SX² + SZ² + SX SZ + 3 (tau_global,bound + tau_roda,bound)²)'),
        ('global_local_web_shear',tau,caps['tau_a_mpa'],'tau_global,bound + tau_roda,bound')):
        checks.append({'id':identifier,'demand_mpa':demand,'capacity_mpa':capacity,'utilization':demand/capacity,
            'status':'within_adopted_bound' if demand<=capacity else 'envelope_exceeded',
            'conservative_envelope':True,'formula':formula,
            'source':'ABNT NBR 10084:2020, 9.1.1–9.1.3; ABNT NBR 8400-2:2019, 5.2.1; '+caps['clause']})
    return {'calculated':True,'approval':False,'case':local['case'],'translation_m':local['translation_m'],
        'longitudinal_abs_mpa':sx,'transverse_abs_bound_mpa':sz,'combined_shear_bound_mpa':tau,
        'von_mises_bound_mpa':vm,'capacities':caps,'checks':checks,
        'limitations':['Combinação de limites de componentes no mesmo caso/posição, sem afirmar coincidência espacial dos máximos.',
                       'Superar um envelope conservador exige refinamento; por si só não prova falha do estado físico.',
                       'Reação inferior incluída na compressão nominal; σx/τ adicionais do leque somente no estudo complementar explicitamente ativado. Soldas usam a transferência em função da garganta proposta.'],
        'remaining_methods':[
            {'id':'biaxial_web_panel_buckling','reason':'Integrar limite energético em autonomous_panel com quatro bordas qualificadas por cálculo.'},
            {'id':'stiffener_stability_and_connections','reason':'Integrar autonomous_local_resistance: rigidez, compressão do par e detalhe fixo de soldas.'},
            
            {'id':'support_contact_local_mechanisms','reason':'Mecanismos prescritivos de carga concentrada/apoio NBR8800 e ligações requerem verificações próprias com vetor ELU independente.'}]}


def local_bounds_at_section(record: dict, x_m: float) -> dict:
    """Bounds at one longitudinal cut, still enveloping all clear-web depths.

    Each pressure acts only in its maximal 45-degree influence interval. Local
    flexural sigmaT retains the whole-train upper bound until a tighter signed
    solution is proved. This is not a pointwise through-depth stress recovery.
    """
    if isinstance(x_m,bool) or not isinstance(x_m,(int,float)) or not math.isfinite(x_m):
        raise ValueError('Posição longitudinal deve ser finita, em metros.')
    if not record.get('local_effects_bound_complete'):
        return {'complete':False,'pending':list(record.get('pending',[]))}
    x=x_m*1000
    active=[r for r in record.get('compression_patches',[]) if r['left_mm']<=x<=r['right_mm']]
    wheel=math.fsum(r['pressure_mpa'] for r in active if r['kind']=='wheel')
    support=math.fsum(r['pressure_mpa'] for r in active if r['kind']=='support')
    C=wheel+support;T=record['stresses']['sigmaT_bound_mpa']
    cz=C+.75*record['stresses'].get('sigmaT_vertical_bound_mpa',T)+record['stresses'].get('sigmaT_horizontal_bound_mpa',0.)
    return {'complete':True,'x_m':x_m,'active_patch_count':len(active),
        'wheel_compression_bound_mpa':wheel,'support_compression_bound_mpa':support,
        'transverse_compression_bound_mpa':C,'longitudinal_local_compression_bound_mpa':C if record.get('fan_model',{}).get('applied') else 0.,
        'sigmaT_bound_mpa':T,'sigma_cz_bound_mpa':cz,
        'transverse_prescribed_design_interval_mpa':[-cz,T],
        'transverse_full_component_interval_mpa':[-(C+T),T],
        'wheel_local_shear_bound_mpa':.2*wheel,'local_shear_complete_bound_mpa':max(C,.2*wheel) if record.get('fan_model',{}).get('applied') else .2*wheel,
        'prescribed_scope_complete':record.get('prescribed_scope_complete',False),
        'nominal_model_complete':True,'elastic_field_upper_bound_proven':False,
        'scope':'Alma inteira no corte informado, no modelo nominal adotado; σT ainda é limite global da passagem, sem prova de majorante elástico3D.'}


def calculate_autonomous_local(p, factors, translation_m, *, wheel_vertical_kn=None,longitudinal_sign=1,supplemental_fan=False):
    """NBR10084/8400 action family; public backward-compatible physical adapter."""
    return _calculate_local_components(p,factors,translation_m,wheel_vertical_kn=wheel_vertical_kn,longitudinal_sign=longitudinal_sign,supplemental_fan=supplemental_fan)


def calculate_physical_local_8800(p,factors,translation_m,*,wheel_vertical_kn=None,longitudinal_sign=1,supplemental_fan=False):
    """Same linear physical stress model under a separate NBR8800 ULS vector.

    This does not convert an admissible resistance or add Mx. The 10084 sources
    describe the physical dispersion/torsion model only; any resistance must be
    an independent 8800 resistance. This explicit adapter is for weld transfer.
    """
    if not isinstance(factors,ActionFactors) or not factors.basis.startswith('nbr8800_uls_normal'):
        raise ValueError('Componentes físicos ELU exigem vetor normal NBR8800.')
    result=_calculate_local_components(p,factors,translation_m,wheel_vertical_kn=wheel_vertical_kn,
        longitudinal_sign=longitudinal_sign,_physical_uls=True,supplemental_fan=supplemental_fan)
    result['resistance_check_included']=False
    result['action_basis_note']='Modelo físico linear de dispersão e flexão local, com ações ELU 8800 independentes; sem Mx e sem resistência admissível 10084.'
    return result
