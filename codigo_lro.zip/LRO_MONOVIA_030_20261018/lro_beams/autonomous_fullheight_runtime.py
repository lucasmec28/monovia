"""Physical-data adapters for the explicit full-height nominal family.

Caches are keyed by the complete serialized physical specification; they do
not accept external results or change the numerical response algorithm.
"""
from functools import lru_cache
from copy import deepcopy
import json
from math import fsum
from .autonomous_fullheight_actions import enabled


def _json(p):
    if not enabled(p):raise ValueError('Família full-height não selecionada.')
    return json.dumps(p.fullheight_nominal_detail,sort_keys=True,separators=(',',':'),allow_nan=False)


@lru_cache(maxsize=32)
def _detail(payload):
    from .autonomous_fullheight_detail import fullheight_detail_from_mapping
    return fullheight_detail_from_mapping(json.loads(payload))


def resolved_detail(p):
    if p.material.gamma_a1!=1.1:raise ValueError('Família full-height: coeficiente gamma_a1 = 1,1 da base NBR8800 normal; outra base requer consumidor próprio.')
    from .autonomous_fullheight_detail import resolve_fullheight_detail
    return resolve_fullheight_detail(p,_detail(_json(p)))


@lru_cache(maxsize=64)
def _pair_mass(payload):
    from .autonomous_fullheight_detail import fullheight_mass_ledger
    return fullheight_mass_ledger(_detail(payload),0.,station_id='reference_station')


def pair_mass(p):
    resolved_detail(p)
    return deepcopy(_pair_mass(_json(p)))


@lru_cache(maxsize=64)
def _longitudinal_mass(payload,start_mm,end_mm):
    from .autonomous_fullheight_detail import longitudinal_mass_ledger
    return longitudinal_mass_ledger(_detail(payload),start_mm,end_mm)


def longitudinal_mass(p):
    resolved_detail(p)
    return deepcopy(_longitudinal_mass(_json(p),-p.beam_end_left_mm,p.span_m*1000+p.beam_end_right_mm))


def longitudinal_extra_udl_kn_m(p):
    ledger=longitudinal_mass(p)
    L=p.span_m+(p.beam_end_left_mm+p.beam_end_right_mm)/1000
    return -ledger['Fz_N']/1000/L


def stationary_radius_terms_nmm(p,dead_factor):
    """Adverse-only each FINAL station body; no top/bottom cancellation.

    Continuous longitudinal deposits are already over-enveloped at rail height
    by the global permanent UDL used by the reference adapter. Add only the
    conservative positive groove-refill envelope not already in that net G.
    This extra favorable-removal-free term may double count some permanent
    height action, but never reduces the declared destabilizing bound.
    """
    from .autonomous_local import stiffener_positions_mm
    if not enabled(p):return ()
    pair=pair_mass(p);count=len(stiffener_positions_mm(p))
    terms=[max(0.,-q['Fz_N']*q['z_mm'])*dead_factor*count for q in pair['points']]
    long=longitudinal_mass(p)
    terms += [max(0.,-q['Fz_N']*q['z_mm'])*dead_factor for q in long['D_adverse_only_points']]
    return tuple(terms)
