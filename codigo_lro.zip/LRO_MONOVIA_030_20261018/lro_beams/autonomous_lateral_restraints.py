"""Physical horizontal restraints whose stabilizing LTB credit is forgone.

A rigid discrete restraint imposes v+z*theta=0; an elastic one supplies the
force R=-k*(v+z*theta). Neither individually imposes theta=0. Two independent
rigid heights at the same section can jointly make a fork. The global
resistance reference intentionally omits these extra constraints; the actual
first-order response, reactions and stress histories retain them.

The external trellis/connection is not sized here. Its name does not establish
rigidity: positions, attachment level and discrete rigid/elastic idealization
must be selected, with a positive supplied stiffness for the elastic model.
"""
import math
from .beam_torsion import LateralBrace
from .autonomous_restraint_mode import resistance_lengths_only,analysis_brace_positions

SOURCE='Compatibilidade elástica de Vlasov: v+z*theta=-R/k; vínculo rígido como limite k infinito. Sem crédito adicional em Mcr/Lb de FLT.'
PREFIX='Contenção horizontal sem crédito FLT: '
LEVEL_LABELS={'shear_center':'eixo/centro de cisalhamento','upper_flange':'mesa superior','lower_flange':'mesa inferior'}


def lateral_restraint_errors(p):
    errors=[];positions=getattr(p,'lateral_only_braces_m',[])
    level=getattr(p,'lateral_only_brace_level','shear_center')
    model=getattr(p,'lateral_only_brace_model','unselected')
    stiffness=getattr(p,'lateral_only_brace_stiffness_kn_per_mm',None)
    if not isinstance(positions,list):return ['Contenções horizontais: lista de posições obrigatória.']
    if level not in LEVEL_LABELS:errors.append('Nível físico da contenção horizontal desconhecido.')
    if model not in ('unselected','rigid_discrete','elastic_discrete'):errors.append('Modelo da contenção horizontal desconhecido.')
    valid_span=not isinstance(p.span_m,bool) and isinstance(p.span_m,(int,float)) and math.isfinite(p.span_m) and p.span_m>0
    valid_positions=valid_span and all(not isinstance(x,bool) and isinstance(x,(int,float)) and math.isfinite(x) and 0<x<p.span_m for x in positions)
    if not valid_positions:errors.append('Contenções horizontais adicionais devem estar estritamente entre os eixos dos apoios.')
    if positions and model=='unselected' and not resistance_lengths_only(p):errors.append('Selecione a idealização rígida ou a rigidez elástica das contenções horizontais.')
    valid_k=not isinstance(stiffness,bool) and isinstance(stiffness,(int,float)) and math.isfinite(stiffness) and stiffness>0
    if positions and model=='elastic_discrete' and not valid_k:errors.append('Apoio lateral elástico exige rigidez finita positiva em kN/mm.')
    if stiffness is not None and not valid_k:errors.append('Rigidez lateral informada inválida.')
    if valid_k and not math.isfinite(stiffness*1000):errors.append('Rigidez lateral excede o domínio numérico em N/mm.')
    valid_existing=all(isinstance(rows,list) and all(not isinstance(x,bool) and isinstance(x,(int,float)) and math.isfinite(x) for x in rows) for rows in (p.upper_braces_m,p.lower_braces_m))
    if valid_positions and positions and model=='rigid_discrete' and valid_existing and not resistance_lengths_only(p):
        upper=set(p.upper_braces_m);lower=set(p.lower_braces_m)
        if level=='upper_flange' and upper.intersection(positions) or level=='lower_flange' and lower.intersection(positions):
            errors.append('Não duplicar na mesma mesa uma contenção rígida já informada com crédito FLT; suas reações individuais seriam indeterminadas.')
        if level=='shear_center' and upper.intersection(lower).intersection(positions):
            errors.append('Três contenções rígidas em alturas distintas da mesma seção são redundantes; informe um único sistema físico ou rigidez elástica.')
    return errors


def lateral_only_braces(p):
    errors=lateral_restraint_errors(p)
    if errors:raise ValueError('; '.join(errors))
    positions=sorted(set(analysis_brace_positions(p,'lateral_only_braces_m')))
    if not positions:return ()
    level=p.lateral_only_brace_level;h0=p.section.d_mm-p.section.tf_mm
    z={'shear_center':0.,'upper_flange':h0/2,'lower_flange':-h0/2}[level]
    k=p.lateral_only_brace_stiffness_kn_per_mm*1000 if p.lateral_only_brace_model=='elastic_discrete' else None
    return tuple(LateralBrace(x*1000,z,k,PREFIX+LEVEL_LABELS[level]) for x in positions)


def physical_lateral_braces(p):
    if resistance_lengths_only(p):return ()
    h0=p.section.d_mm-p.section.tf_mm
    existing=tuple(LateralBrace(x*1000,h0/2,None,'Mesa superior') for x in sorted(set(p.upper_braces_m)) if 0<x<p.span_m)
    existing+=tuple(LateralBrace(x*1000,-h0/2,None,'Mesa inferior') for x in sorted(set(p.lower_braces_m)) if 0<x<p.span_m)
    return existing+lateral_only_braces(p)


def all_lateral_positions(p):
    return tuple(sorted(set(analysis_brace_positions(p,'upper_braces_m'))|set(analysis_brace_positions(p,'lower_braces_m'))|set(analysis_brace_positions(p,'lateral_only_braces_m'))))


def lateral_restraint_policy(p):
    extra=lateral_only_braces(p);all_braces=physical_lateral_braces(p)
    at={}
    for b in all_braces:
        if b.stiffness_n_per_mm is None:at.setdefault(b.x_mm,set()).add(b.height_from_cs_mm)
    return dict(applicable=bool(extra),source=SOURCE,
        positions_m=[b.x_mm/1000 for b in extra],level=getattr(p,'lateral_only_brace_level','shear_center'),
        model=getattr(p,'lateral_only_brace_model','unselected'),
        stiffness_n_per_mm=extra[0].stiffness_n_per_mm if extra else None,
        physical_count=len(extra),ltb_reference_credit=False,shortens_flt_Lb=False,
        imposed_twist_fixity=False,
        combined_two_height_rigid_sections_m=[x/1000 for x,z in sorted(at.items()) if len(z)>1],
        scope='Resposta da viga e reações de interfaces externas. Reação transmitida à seção sem distorção local pela ligação fornecida; não representa uma carga pontual na alma cuja introdução local tenha sido dimensionada. Cada k representa uma mola translacional independente em relação à referência fixa, igual nos pontos informados; rigidez distribuída ou matriz acoplada de uma treliça não são inferidas. Rigidez do treliçamento fornecida como modelo físico; resistência do treliçamento e sua ligação externa não dimensionadas.')


def accumulate_lateral_restraint_evidence(evidence,p,response):
    """Audit EACH computed train position; retain separate reaction envelopes."""
    expected=lateral_only_braces(p)
    if not expected:return evidence
    if not evidence:
        evidence.update(lateral_restraint_policy(p),complete=True,pending=[],checked_translations=0,
            max_compatibility_relative_residual=0.,reactions=[])
        for b in expected:evidence['reactions'].append(dict(x_m=b.x_mm/1000,height_from_cs_mm=b.height_from_cs_mm,
            stiffness_n_per_mm=b.stiffness_n_per_mm,reaction_min_kn=0.,reaction_max_kn=0.,reaction_abs_max_kn=0.,
            torque_abs_max_knm=0.,critical_translation_m=None,interface='external_axis_attachment' if b.height_from_cs_mm==0 else 'flange_attachment'))
    rows=[r for r in response.lateral_torsion.brace_reactions if r.get('name','').startswith(PREFIX)]
    pending=evidence['pending'];evidence['checked_translations']+=1
    if len(rows)!=len(expected):pending.append('A resposta omitiu ou duplicou uma reação de contenção horizontal declarada.')
    for b,target in zip(expected,evidence['reactions']):
        matches=[r for r in rows if r.get('x_mm')==b.x_mm and r.get('height_from_cs_mm')==b.height_from_cs_mm and r.get('stiffness_n_per_mm')==b.stiffness_n_per_mm]
        if len(matches)!=1:
            pending.append('Reação não vinculada à posição/altura/rigidez da contenção horizontal.');continue
        row=matches[0];R=row.get('horizontal_reaction_n');T=row.get('torque_reaction_nmm')
        if any(isinstance(v,bool) or not isinstance(v,(int,float)) or not math.isfinite(v) for v in (R,T)):
            pending.append('Reação de contenção não finita.');continue
        # A rigid compatibility equation cannot identify R on its own. Tie
        # the exported reaction to the actual Green-function load in BOTH
        # solved fields; this also survives physical projection condensation.
        load_name='Brace: '+b.name
        field_loads=[load for load in response.lateral_torsion.loads
                     if load.name==load_name and load.x_mm==b.x_mm]
        field_torques=[load for load in response.lateral_torsion.torsion.point_torques
                       if load.name==load_name and load.x_mm==b.x_mm]
        if (len(field_loads)!=1 or len(field_torques)!=1 or
            field_loads[0].horizontal_n!=R or field_loads[0].torque_nmm!=T or
            field_torques[0].torque_nmm!=T):
            pending.append('Reação de contenção diverge das cargas usadas nos campos de flexão/torção.');continue
        state=response.lateral_torsion.at(b.x_mm)
        attach=state['horizontal_mm']+b.height_from_cs_mm*state['torsion']['theta_rad']
        expected_displacement=0. if b.stiffness_n_per_mm is None else -R/b.stiffness_n_per_mm
        residual=abs(attach-expected_displacement)/max(1.,abs(expected_displacement))
        torque_residual=abs(T-R*b.height_from_cs_mm)/max(1.,abs(T),abs(R*b.height_from_cs_mm))
        evidence['max_compatibility_relative_residual']=max(evidence['max_compatibility_relative_residual'],residual,torque_residual)
        if not math.isfinite(residual) or residual>1e-8 or torque_residual>1e-10:
            pending.append('Compatibilidade/equilíbrio do vínculo horizontal não qualificados.')
        target['reaction_min_kn']=min(target['reaction_min_kn'],R/1000)
        target['reaction_max_kn']=max(target['reaction_max_kn'],R/1000)
        if abs(R)/1000>=target['reaction_abs_max_kn']:
            target['reaction_abs_max_kn']=abs(R)/1000;target['critical_translation_m']=response.translation_m
        target['torque_abs_max_knm']=max(target['torque_abs_max_knm'],abs(T)/1e6)
    evidence['pending']=list(dict.fromkeys(pending));evidence['complete']=not evidence['pending']
    return evidence


def lateral_restraint_evidence_complete(p,sweep):
    """Fail closed if a case summary lacks the declared physical constraints."""
    expected=lateral_only_braces(p);e=getattr(sweep,'lateral_restraint_evidence',None)
    if not expected:return False
    if not isinstance(e,dict) or e.get('complete') is not True or e.get('pending') or e.get('errors'):return False
    from .autonomous_result import input_signature
    if e.get('case_id')!=getattr(sweep,'case_id',None) or e.get('project_signature')!=input_signature(p):return False
    if getattr(sweep,'project_signature',None)!=e['project_signature']:return False
    count=e.get('checked_translations');responses=getattr(sweep,'responses',None)
    if isinstance(count,bool) or not isinstance(count,int) or count<=0 or count!=responses:return False
    policy=lateral_restraint_policy(p)
    for key in ('positions_m','level','model','stiffness_n_per_mm','physical_count','ltb_reference_credit','shortens_flt_Lb','source'):
        if e.get(key)!=policy[key]:return False
    if e.get('ltb_reference_credit') is not False or e.get('shortens_flt_Lb') is not False:return False
    residual=e.get('max_compatibility_relative_residual')
    if isinstance(residual,bool) or not isinstance(residual,(int,float)) or not math.isfinite(residual) or not 0<=residual<=1e-8:return False
    rows=e.get('reactions')
    if not isinstance(rows,list) or len(rows)!=len(expected):return False
    for b,row in zip(expected,rows):
        if not isinstance(row,dict):return False
        if (row.get('x_m'),row.get('height_from_cs_mm'),row.get('stiffness_n_per_mm'))!=(b.x_mm/1000,b.height_from_cs_mm,b.stiffness_n_per_mm):return False
        keys=('reaction_min_kn','reaction_max_kn','reaction_abs_max_kn','torque_abs_max_knm','critical_translation_m')
        if any(isinstance(row.get(k),bool) or not isinstance(row.get(k),(int,float)) or not math.isfinite(row[k]) for k in keys):return False
        if row['reaction_min_kn']>0 or row['reaction_max_kn']<0 or row['torque_abs_max_knm']<0:return False
        peak=max(abs(row['reaction_min_kn']),abs(row['reaction_max_kn']))
        if not math.isclose(peak,row['reaction_abs_max_kn'],rel_tol=1e-10,abs_tol=1e-12):return False
        if not math.isclose(row['torque_abs_max_knm'],peak*abs(b.height_from_cs_mm)/1000,rel_tol=1e-10,abs_tol=1e-12):return False
    return True
