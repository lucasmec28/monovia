"""Input-driven runway drawings, independent of the structural solver.

Global drawing coordinates are x (along the span), y (transverse), z (up),
with x=0 at support A and z=0 on the underside of the bottom flange.
Only the section view is at equal scale. Longitudinal views use independent
axis scales, and the axonometric compresses the span. Dimensions always report
actual inputs. Wheels, supports, restraints and the rail envelope are schematic;
none of these drawings qualifies a connection or authorizes fabrication.
"""
from __future__ import annotations

from dataclasses import dataclass
from io import BytesIO
import math
from numbers import Real
import textwrap
from typing import Sequence

from matplotlib.backends.backend_agg import FigureCanvasAgg
from matplotlib.figure import Figure
from matplotlib.lines import Line2D
from matplotlib.patches import Ellipse, Polygon, Rectangle

__all__ = ["ViewGeometry", "elevation_png", "plan_png", "section_png", "isometric_png"]

INK = "#17354A"
STEEL = "#D8E7EF"
STEEL_DARK = "#9BB8CB"
MUTED = "#587085"
LIGHT = "#D9E2E9"
RAIL = "#C38A43"
WHEEL = "#B85A36"
BRACE = "#167B71"
LATERAL_ONLY = "#7956A3"
HIGHLIGHT = "#F1BC56"
BACKGROUND = "#FFFFFF"
WELD = "#7956A3"


def _positive(name: str, value: float, *, zero: bool = False) -> float:
    if isinstance(value, bool) or not isinstance(value, Real):
        raise ValueError(f"{name} must be a finite number")
    value = float(value)
    if not math.isfinite(value) or value < 0 or (not zero and value == 0):
        raise ValueError(f"{name} must be finite and {'nonnegative' if zero else 'positive'}")
    return value


@dataclass(frozen=True)
class ViewGeometry:
    """Validated drawing inputs; lengths in the units indicated by field names.

    A zero rail height AND width means no rail. Bottom flange thickness defaults
    to the top flange thickness. Position order is retained, including coincident
    wheels; caller-supplied lists are copied to immutable tuples.
    """

    span_m: float
    depth_mm: float
    top_width_mm: float
    bottom_width_mm: float
    flange_thickness_mm: float
    web_thickness_mm: float
    rail_height_mm: float = 65.0
    rail_width_mm: float = 65.0
    wheel_positions_m: Sequence[float] = ()
    brace_positions_m: Sequence[float] = ()
    lower_brace_positions_m: Sequence[float] = ()
    lateral_only_positions_m: Sequence[float] = ()
    lateral_only_level: str = 'shear_center'
    rail_profile_label: str = ''
    rail_head_width_mm: float = 0.0
    rail_web_thickness_mm: float = 0.0
    rail_head_height_mm: float = 0.0
    rail_foot_height_mm: float = 0.0
    highlighted_segment: tuple[float, float] | None = None
    bottom_flange_thickness_mm: float | None = None
    rail_offset_mm: float = 0.0
    wheel_lateral_offset_mm: float = 0.0
    beam_end_left_mm: float = 0.0
    beam_end_right_mm: float = 0.0
    stiffener_positions_m: Sequence[float] = ()
    stiffener_thickness_mm: float = 0.0
    stiffener_outstand_mm: float = 0.0
    # Optional presentation metadata. No default force, wheelbase or bridge span
    # is inferred from crane capacity or from the runway support span.
    wheel_loads_kN: Sequence[float] = ()
    wheel_labels: Sequence[str] = ()
    wheel_load_basis: str = ""
    bridge_span_m: float | None = None
    wheelbase_m: float | None = None
    view_case_label: str = ""
    flange_web_weld_mm: float = 0.0
    weld_note: str = ""

    def __post_init__(self) -> None:
        wheel_offset = self.wheel_lateral_offset_mm
        if isinstance(wheel_offset, bool) or not isinstance(wheel_offset, Real) or not math.isfinite(wheel_offset):
            raise ValueError("wheel_lateral_offset_mm must be finite")
        offset = self.rail_offset_mm
        if isinstance(offset, bool) or not isinstance(offset, Real) or not math.isfinite(offset):
            raise ValueError("rail_offset_mm must be a finite signed number")
        object.__setattr__(self, "rail_offset_mm", float(offset))
        for name in ("span_m", "depth_mm", "top_width_mm", "bottom_width_mm",
                     "flange_thickness_mm", "web_thickness_mm"):
            object.__setattr__(self, name, _positive(name, getattr(self, name)))
        for name in ("rail_height_mm", "rail_width_mm", "beam_end_left_mm", "beam_end_right_mm", "stiffener_thickness_mm", "stiffener_outstand_mm", "rail_head_width_mm", "rail_web_thickness_mm", "rail_head_height_mm", "rail_foot_height_mm"):
            object.__setattr__(self, name, _positive(name, getattr(self, name), zero=True))
        bottom = self.bottom_flange_thickness_mm
        bottom = self.flange_thickness_mm if bottom is None else _positive("bottom_flange_thickness_mm", bottom)
        object.__setattr__(self, "bottom_flange_thickness_mm", bottom)
        if self.flange_thickness_mm + bottom >= self.depth_mm:
            raise ValueError("Flange thicknesses must leave a positive clear web height")
        if self.web_thickness_mm > min(self.top_width_mm, self.bottom_width_mm):
            raise ValueError("Web thickness cannot exceed either flange width")
        if any((self.rail_head_width_mm,self.rail_web_thickness_mm,self.rail_head_height_mm,self.rail_foot_height_mm)):
            if not (0<self.rail_web_thickness_mm<=self.rail_head_width_mm<=self.rail_width_mm and 0<self.rail_foot_height_mm and 0<self.rail_head_height_mm and self.rail_head_height_mm+self.rail_foot_height_mm<self.rail_height_mm):
                raise ValueError('Invalid schematic rail profile dimensions')
        if bool(self.rail_height_mm) != bool(self.rail_width_mm):
            raise ValueError("Rail height and width must both be zero or both positive")
        for name in ("wheel_positions_m", "brace_positions_m", "lower_brace_positions_m", "lateral_only_positions_m", "stiffener_positions_m"):
            try:
                positions = tuple(_positive(name, v, zero=True) for v in getattr(self, name))
            except TypeError as exc:
                raise ValueError(f"{name} must be a sequence of finite positions") from exc
            if any(v > self.span_m for v in positions):
                raise ValueError(f"{name} positions must lie within [0, span_m]")
            object.__setattr__(self, name, positions)
        if isinstance(self.wheel_loads_kN, (str, bytes)) or isinstance(self.wheel_labels, (str, bytes)):
            raise ValueError("Wheel loads and labels must be sequences, not strings")
        try:
            loads = tuple(_positive("wheel_loads_kN", value, zero=True) for value in self.wheel_loads_kN)
            labels = tuple(str(value).strip() for value in self.wheel_labels)
        except TypeError as exc:
            raise ValueError("Wheel loads and labels must be sequences") from exc
        if loads and len(loads) != len(self.wheel_positions_m):
            raise ValueError("wheel_loads_kN must match the supplied wheel positions")
        object.__setattr__(self, "wheel_loads_kN", loads)
        if labels and (len(labels) != len(self.wheel_positions_m) or any(not value for value in labels)):
            raise ValueError("wheel_labels must contain one nonempty label per wheel")
        object.__setattr__(self, "wheel_labels", labels)
        for name in ("wheel_load_basis", "view_case_label", "weld_note"):
            if not isinstance(getattr(self, name), str):
                raise ValueError(f"{name} must be text")
        for name in ("bridge_span_m", "wheelbase_m"):
            if getattr(self, name) is not None:
                object.__setattr__(self, name, _positive(name, getattr(self, name), zero=name == "wheelbase_m"))
        object.__setattr__(self, "flange_web_weld_mm", _positive("flange_web_weld_mm", self.flange_web_weld_mm, zero=True))
        if self.flange_web_weld_mm > min((self.top_width_mm-self.web_thickness_mm)/2,
                                         (self.bottom_width_mm-self.web_thickness_mm)/2,
                                         (self.depth_mm-self.flange_thickness_mm-bottom)/2):
            raise ValueError("flange_web_weld_mm exceeds the section drawing envelope")
        if self.lateral_only_level not in ('shear_center','upper_flange','lower_flange'):
            raise ValueError('Unknown lateral restraint application level')
        if self.stiffener_positions_m:
            if self.stiffener_thickness_mm<=0 or self.stiffener_outstand_mm<=0:
                raise ValueError("Stiffener positions require positive physical plate dimensions")
            if self.stiffener_outstand_mm>(min(self.top_width_mm,self.bottom_width_mm)-self.web_thickness_mm)/2:
                raise ValueError("Stiffener outstand exceeds available flange width")
        if self.highlighted_segment is not None:
            try:
                start, end = self.highlighted_segment
            except (TypeError, ValueError) as exc:
                raise ValueError("highlighted_segment must contain start and end positions") from exc
            start = _positive("segment start", start, zero=True)
            end = _positive("segment end", end, zero=True)
            if not 0 <= start < end <= self.span_m:
                raise ValueError("Highlighted segment must satisfy 0 <= start < end <= span_m")
            object.__setattr__(self, "highlighted_segment", (start, end))

    @property
    def physical_start_m(self):
        return -self.beam_end_left_mm / 1000

    @property
    def physical_length_m(self):
        return self.span_m + (self.beam_end_left_mm + self.beam_end_right_mm) / 1000

    @property
    def has_rail(self) -> bool:
        return self.rail_height_mm > 0


def _fmt(value: float) -> str:
    """Readable dimension without rounding a positive small input to zero."""
    return f"{value:.9g}".replace(".", ",")


def _stations(label: str, values: Sequence[float]) -> str:
    if not values:
        return f"{label}: nenhuma posição informada."
    return f"{label} ({len(values)}): x = " + "; ".join(_fmt(v) for v in values) + " m."


def _sheet(number: str, title: str, subtitle: str, *, notes: Sequence[str] = (),
           square: bool = False) -> tuple[Figure, object]:
    """A4-friendly white sheet. Physical font sizes survive a 16-cm Word embed."""
    lines = []
    for note in notes:
        lines.extend(textwrap.wrap(note, width=103, break_long_words=False) or [""])
    footer_height = 0.18 * max(1, len(lines)) + 0.23
    drawing_height = 4.15 if square else 3.65
    sublines = textwrap.wrap(subtitle, width=110, break_long_words=False)
    header_height = max(.86, .63+.16*len(sublines))
    height = drawing_height + header_height + footer_height
    fig = Figure(figsize=(8.2, height), dpi=180, facecolor=BACKGROUND)
    FigureCanvasAgg(fig)
    ax = fig.add_axes((0.065, (footer_height + .12) / height, .88,
                       (drawing_height - .16) / height))
    fig.text(.055, 1 - .23 / height, f"{number}  /  {title}", fontsize=13,
             fontweight="bold", color=INK, va="top")
    for i, line in enumerate(sublines):
        fig.text(.055, 1 - (.53 + i*.16) / height, line, fontsize=9.3, color=MUTED, va="top")
    fig.add_artist(Line2D([.055, .945], [footer_height/height]*2,
                         transform=fig.transFigure, color=LIGHT, linewidth=.8))
    for i, line in enumerate(lines):
        fig.text(.055, (footer_height - .13 - i * .18) / height, line,
                 fontsize=9.0, color=MUTED, va="top")
    ax.set_axis_off()
    return fig, ax


def _wheel_name(g: ViewGeometry, index: int) -> str:
    return g.wheel_labels[index] if g.wheel_labels else f"R{index+1}"


def _wheel_note(g: ViewGeometry) -> str:
    if not g.wheel_positions_m:
        return "Rodas: nenhuma posição informada."
    entries = []
    for i, x in enumerate(g.wheel_positions_m):
        load = f"; P = {_fmt(g.wheel_loads_kN[i])} kN" if g.wheel_loads_kN else ""
        entries.append(f"{_wheel_name(g, i)}: x = {_fmt(x)} m{load}")
    return "Rodas no trecho mostrado: " + " | ".join(entries) + "."


def _span_notes(g: ViewGeometry) -> list[str]:
    notes = []
    if g.bridge_span_m is not None:
        notes.append(f"Vão transversal da ponte entre trilhos = {_fmt(g.bridge_span_m)} m; não é o vão L da viga nem a distância entre rodas.")
    if g.wheelbase_m is not None:
        notes.append(f"Entre-eixos longitudinal informado do equipamento = {_fmt(g.wheelbase_m)} m; as cotas Δx indicam só as rodas presentes nesta vista.")
    return notes


def _spaced_labels(xs, xmin, xmax, gap):
    """Separate display labels only; never modify physical wheel positions."""
    if not xs:
        return []
    order = sorted(range(len(xs)), key=lambda i: (xs[i], i))
    gap = min(gap, (xmax-xmin)/max(len(xs)-1, 1))
    places = [min(xmax, max(xmin, xs[i])) for i in order]
    for i in range(1, len(places)):
        places[i] = max(places[i], places[i-1]+gap)
    if places[-1] > xmax:
        places[-1] = xmax
        for i in range(len(places)-2, -1, -1):
            places[i] = min(places[i], places[i+1]-gap)
    result = [0.] * len(xs)
    for i, value in zip(order, places):
        result[i] = value
    return result


def _finish(fig: Figure, dpi: int) -> bytes:
    if isinstance(dpi, bool) or not isinstance(dpi, Real) or not math.isfinite(dpi) or not 40 <= dpi <= 600:
        raise ValueError("dpi must be a finite number between 40 and 600")
    output = BytesIO()
    fig.savefig(output, format="png", dpi=dpi, facecolor=fig.get_facecolor())
    fig.clear()
    return output.getvalue()


def _dim_h(ax, x1, x2, y, reference_y, label, *, color=MUTED, fontsize=10, align="center", above=False):
    for x in (x1, x2):
        ax.plot([x, x], [reference_y, y], color=LIGHT, linewidth=.8, zorder=1)
    ax.annotate("", (x1, y), (x2, y), arrowprops={"arrowstyle": "|-|", "color": color, "lw": .9}, zorder=8)
    ax.annotate(label, ((x1 + x2) / 2, y), xytext=(0, 5 if above else -7), textcoords="offset points",
                ha=align, va="bottom" if above else "top", color=color, fontsize=fontsize,
                bbox={"facecolor": BACKGROUND, "edgecolor": "none", "pad": 1.5}, zorder=9)


def _dim_v(ax, y1, y2, x, reference_x, label):
    for y in (y1, y2):
        ax.plot([reference_x, x], [y, y], color=LIGHT, linewidth=.8, zorder=1)
    ax.annotate("", (x, y1), (x, y2), arrowprops={"arrowstyle": "|-|", "color": MUTED, "lw": .9})
    ax.annotate(label, (x, (y1 + y2) / 2), xytext=(-9, 0), textcoords="offset points",
                rotation=90, va="center", ha="right", color=MUTED, fontsize=10,
                bbox={"facecolor": BACKGROUND, "edgecolor": "none", "pad": 1.5})


def _triad(ax, horizontal: str, vertical: str, *, origin=(.89, .81), scale=1.0):
    x, y = origin
    for end, label, delta in (((x + .075*scale, y), horizontal, (4, 0)),
                              ((x, y + .13*scale), vertical, (0, 5))):
        ax.annotate("", end, (x, y), xycoords="axes fraction", textcoords="axes fraction",
                    arrowprops={"arrowstyle": "->", "lw": 1, "color": MUTED})
        ax.annotate(label, end, xycoords="axes fraction", xytext=delta,
                    textcoords="offset points", fontsize=9, color=MUTED, ha="center", va="center")


def _support(ax, x, base_z, length, depth, roller=False):
    hw, h = length * .013, depth * .18
    ax.add_patch(Polygon([[x, base_z], [x - hw, base_z - h], [x + hw, base_z - h]],
                         facecolor="white", edgecolor=INK, lw=1.1, zorder=5))
    y = base_z - h
    if roller:
        for dx in (-hw * .5, hw * .5):
            ax.add_patch(Ellipse((x + dx, y - h * .16), hw * .35, h * .24,
                                 facecolor="white", edgecolor=INK, lw=.8, zorder=5))
        y -= h * .32
    ax.plot([x - hw * 1.45, x + hw * 1.45], [y - h * .13] * 2, color=INK, lw=1)


def _station_align(midpoint: float, span: float) -> str:
    # A short segment can sit against either end; its label may be much wider
    # than the segment. Anchor toward the interior rather than clipping it.
    return "left" if midpoint < .2 * span else "right" if midpoint > .8 * span else "center"


def _highlight(ax, g, y, height):
    if g.highlighted_segment:
        start, end = g.highlighted_segment
        ax.add_patch(Rectangle((start, y), end - start, height, facecolor=HIGHLIGHT,
                               edgecolor="none", alpha=.17, zorder=0))


def _elevation_figure(g: ViewGeometry) -> Figure:
    d, t, tb, r = (g.depth_mm/1000, g.flange_thickness_mm/1000,
                    g.bottom_flange_thickness_mm/1000, g.rail_height_mm/1000)
    h = max(d+r, d*1.15)
    notes = [_wheel_note(g)]
    ordered_wheels=sorted(enumerate(g.wheel_positions_m),key=lambda item:(item[1],item[0]))
    spacings=[(i,j,b-a) for (i,a),(j,b) in zip(ordered_wheels[:-1],ordered_wheels[1:])]
    crowded=bool(spacings) and (len(g.wheel_positions_m)>5 or any(dx<.10*g.span_m for _,_,dx in spacings))
    if crowded:
        notes.append("Espaçamentos longitudinais Δx: "+" | ".join(
            f"{_wheel_name(g,i)}–{_wheel_name(g,j)} = {_fmt(dx)} m" for i,j,dx in spacings)+".")
    if g.wheel_loads_kN:
        notes.append(g.wheel_load_basis or "P: cargas verticais fornecidas para esta figura; a base do caso não foi informada.")
    if g.stiffener_positions_m:
        notes.append(_stations("Enrijecedores em pares", g.stiffener_positions_m) +
                     f" Chapas t × largura saliente = {_fmt(g.stiffener_thickness_mm)} × {_fmt(g.stiffener_outstand_mm)} mm.")
    notes += _span_notes(g)
    notes += [f"Projeções além de A / B: {_fmt(g.beam_end_left_mm)} / {_fmt(g.beam_end_right_mm)} mm; rodas modeladas apenas entre os apoios.",
              "x longitudinal · z vertical. Escalas independentes; rodas e vínculos simbólicos. Cotas do modelo, não desenho de fabricação."]
    subtitle = g.view_case_label or "Geometria e posições informadas · esta vista não identifica por si só o caso crítico"
    fig, ax = _sheet("01", "ELEVAÇÃO E TREM DE RODAS", subtitle, notes=notes)
    _highlight(ax, g, -.02*h, 1.05*h)
    ax.add_patch(Rectangle((g.physical_start_m, tb), g.physical_length_m, d-t-tb,
                           facecolor=STEEL, edgecolor=INK, lw=1))
    for y, thickness in ((0, tb), (d-t, t)):
        ax.add_patch(Rectangle((g.physical_start_m, y), g.physical_length_m, thickness,
                               facecolor=STEEL_DARK, edgecolor=INK, lw=1))
    if g.has_rail:
        ax.add_patch(Rectangle((g.physical_start_m, d), g.physical_length_m, r,
                               facecolor="#F2E2C8", edgecolor=RAIL, lw=1))
    for x in g.stiffener_positions_m:
        ax.add_patch(Rectangle((x-g.stiffener_thickness_mm/2000, tb),
                               g.stiffener_thickness_mm/1000, d-t-tb,
                               facecolor="#A5C4C0", edgecolor=BRACE, lw=.75, zorder=4))
    count = len(g.wheel_positions_m)
    positions = _spaced_labels(g.wheel_positions_m, 0, g.span_m, .17*g.span_m)
    # A force arrow ends at the wheel contact. Symbol sizes are explicitly schematic.
    for i, (x, label_x) in enumerate(zip(g.wheel_positions_m, positions)):
        contact_z = d+r
        ax.plot([x,x], [contact_z,contact_z+.25*h], color=WHEEL, lw=.8, ls=(0,(3,3)), zorder=6)
        ax.add_patch(Ellipse((x,contact_z+.075*h), .022*g.span_m, .15*h,
                             facecolor="white", edgecolor=WHEEL, lw=1.3, zorder=7))
        ax.plot(x,contact_z+.075*h,'.', color=WHEEL, ms=3, zorder=8)
        if g.wheel_loads_kN:
            ax.annotate("", (x,contact_z+.01*h), (x,contact_z+.41*h),
                        arrowprops={"arrowstyle":"-|>","color":WHEEL,"lw":1.2}, zorder=9)
        label = textwrap.shorten(_wheel_name(g,i),width=16,placeholder="…")
        if g.wheel_loads_kN and count <= 4:
            label += f"  {_fmt(g.wheel_loads_kN[i])} kN"
        label_z = contact_z+(.54+(i%2)*.20 if count>4 else .54)*h
        ax.annotate(label, (x,contact_z+.42*h), xytext=(label_x,label_z),
                    ha="center", va="bottom", fontsize=9.7, color=WHEEL, fontweight="bold",
                    arrowprops={"arrowstyle":"-","color":WHEEL,"lw":.7},
                    bbox={"facecolor":"white","edgecolor":"none","pad":1.5}, zorder=10)
    # Wheel spacings are exact differences along x, never transverse bridge span.
    ordered = sorted(set(g.wheel_positions_m))
    for i,(a,b) in enumerate(zip(ordered[:-1],ordered[1:])):
        if not crowded and count <= 5 and b-a >= .10*g.span_m:
            _dim_h(ax,a,b,d+r+1.05*h,d+r+.80*h,f"Δx = {_fmt(b-a)} m",color=WHEEL,fontsize=9.6,above=True)
    if crowded:
        ax.text(.5,.96,"Espaçamentos Δx discriminados na legenda",transform=ax.transAxes,
                ha="center",va="top",fontsize=9.4,color=WHEEL)
    _support(ax,0,0,g.span_m,h)
    _support(ax,g.span_m,0,g.span_m,h,True)
    for x,label,align in ((0,"A · x = 0","left"),(g.span_m,f"B · x = {_fmt(g.span_m)} m","right")):
        ax.text(x,-.29*h,label,color=INK,ha=align,va="top",fontsize=10,fontweight="bold")
    _dim_h(ax,0,g.span_m,-.65*h,-.47*h,f"L = {_fmt(g.span_m)} m · vão entre apoios")
    _dim_v(ax,0,d,g.physical_start_m-.055*g.physical_length_m,g.physical_start_m,
           f"d = {_fmt(g.depth_mm)} mm")
    _triad(ax,"x","z",origin=(.87,.025),scale=.52)
    ax.set_xlim(g.physical_start_m-.13*g.physical_length_m,
                g.physical_start_m+1.09*g.physical_length_m)
    ax.set_ylim(-1.10*h,d+r+1.40*h)
    return fig


def elevation_png(geometry: ViewGeometry, *, dpi: int = 160) -> bytes:
    """Dimensioned x/z view including every supplied wheel and both supports."""
    return _finish(_elevation_figure(geometry), dpi)


def _plan_figure(g: ViewGeometry) -> Figure:
    b = max(g.top_width_mm, g.bottom_width_mm, g.rail_width_mm + 2 * abs(g.rail_offset_mm),
            2*abs(g.rail_offset_mm+g.wheel_lateral_offset_mm)) / 1000
    offset = g.rail_offset_mm / 1000
    bt, bb, rw = g.top_width_mm / 1000, g.bottom_width_mm / 1000, g.rail_width_mm / 1000
    notes = [_stations("Triângulos verdes · travas superiores", g.brace_positions_m),
             _stations("Triângulos verdes · travas inferiores", g.lower_brace_positions_m),
             _stations("Círculos roxos · contenções laterais, sem redução de Lb para FLT",g.lateral_only_positions_m),
             f"Projeções A/B: {_fmt(g.beam_end_left_mm)} / {_fmt(g.beam_end_right_mm)} mm. Linha da roda relativa ao trilho: {_fmt(g.wheel_lateral_offset_mm)} mm.",
             "x longitudinal · y transversal. Símbolos são vínculos do modelo, não ligações aprovadas. Escalas independentes.",
             "Trilho sem crédito de seção composta. Planta de uma viga: o vão transversal da ponte não está representado."]
    if g.lateral_only_positions_m:
        level_label = {'shear_center':'eixo / centro de cisalhamento (nível esquemático)',
                       'upper_flange':'mesa superior','lower_flange':'mesa inferior'}[g.lateral_only_level]
        notes.insert(3, "Nível das contenções laterais: " + level_label + ".")
    fig, ax = _sheet("02", "PLANTA DE TRAVAMENTOS", f"Mesmos x da elevação · y = 0 no centro da alma · trilho em y = {_fmt(g.rail_offset_mm)} mm", notes=notes)
    _highlight(ax, g, -1.1 * b, 2.35 * b)
    # Bottom flange outline remains visible for unequal flange inputs.
    if not math.isclose(bt, bb):
        ax.add_patch(Rectangle((g.physical_start_m, -bb / 2), g.physical_length_m, bb, facecolor="none", edgecolor=MUTED,
                              linestyle=(0, (5, 4)), lw=.9, zorder=3))
    ax.add_patch(Rectangle((g.physical_start_m, -bt / 2), g.physical_length_m, bt, facecolor=STEEL, edgecolor=INK, lw=1.2, zorder=2))
    if g.has_rail:
        ax.add_patch(Rectangle((g.physical_start_m, offset - rw / 2), g.physical_length_m, rw, facecolor="#EAD8BC", edgecolor=RAIL, lw=.9, zorder=4))
    ax.plot([-.025 * g.span_m, 1.025 * g.span_m], [0, 0], color=MUTED, ls=(0, (8, 3, 2, 3)), lw=.8, zorder=5)
    if g.has_rail and offset:
        ax.plot([g.physical_start_m,g.physical_start_m+g.physical_length_m], [offset,offset],
                color=RAIL,ls=(0,(3,3)),lw=.65,zorder=5)
    for x in g.wheel_positions_m:
        ax.plot(x, offset + g.wheel_lateral_offset_mm / 1000, marker="o", markersize=5.5, markerfacecolor="white", markeredgecolor=WHEEL, markeredgewidth=1.3, zorder=7)
    for x in g.brace_positions_m:
        y = bt / 2
        ax.plot([x, x], [y, y + b * .32], color=BRACE, lw=1.1, zorder=6)
        ax.add_patch(Polygon([(x, y), (x - g.span_m * .012, y + b * .22),
                              (x + g.span_m * .012, y + b * .22)], facecolor="white",
                             edgecolor=BRACE, lw=1.3, zorder=7))
    for x in g.lower_brace_positions_m:
        y=-bb/2
        ax.plot(x,y-b*.22,marker='v',ms=7,mfc='white',mec=BRACE,zorder=8)
        ax.plot([x,x],[y,y-b*.32],color=BRACE,lw=1.1,zorder=6)
    for x in g.lateral_only_positions_m:
        y=-max(bt,bb)/2-b*.48
        anchor_y = {'upper_flange':bt/2,'lower_flange':-bb/2,'shear_center':0.}[g.lateral_only_level]
        ax.plot([x,x],[anchor_y,y],color=LATERAL_ONLY,lw=1.1,zorder=8)
        ax.plot(x,y,marker='o',ms=6,mfc='white',mec=LATERAL_ONLY,zorder=9)
    for x, label in ((0, "A"), (g.span_m, "B")):
        ax.plot([x, x], [-.68 * b, .68 * b], color=INK, lw=1, ls=(0, (3, 3)))
        ax.text(x, .91 * b, label, ha="center", va="bottom", fontsize=10, fontweight="bold", color=INK,
                bbox={"facecolor":"white","edgecolor":"none","pad":1.4})
    _dim_h(ax, 0, g.span_m, -1.25 * b, -.71 * b, f"L = {_fmt(g.span_m)} m · vão entre apoios")
    _dim_v(ax, -bt / 2, bt / 2, g.physical_start_m - .055 * g.physical_length_m, g.physical_start_m, f"b sup = {_fmt(g.top_width_mm)} mm")
    if g.highlighted_segment:
        a, c = g.highlighted_segment
        _dim_h(ax, a, c, 1.48 * b, 1.16 * b, f"Trecho destacado = {_fmt(c-a)} m", color="#926718", fontsize=9.5,
               align=_station_align((a + c) / 2, g.span_m), above=True)
    _triad(ax, "x", "y", origin=(.86, .02),scale=.55)
    ax.set_xlim(g.physical_start_m - .11 * g.physical_length_m, g.physical_start_m + 1.09 * g.physical_length_m)
    ax.set_ylim(-1.80 * b, 2.12 * b)
    return fig


def plan_png(geometry: ViewGeometry, *, dpi: int = 160) -> bytes:
    """Dimensioned x/y view with discrete lateral-restraint symbols."""
    return _finish(_plan_figure(geometry), dpi)


def _section_rectangles(g: ViewGeometry):
    """Physical rectangles in y/z mm; shared by section and axonometric views."""
    return ((-g.bottom_width_mm / 2, 0, g.bottom_width_mm, g.bottom_flange_thickness_mm),
            (-g.web_thickness_mm / 2, g.bottom_flange_thickness_mm, g.web_thickness_mm,
             g.depth_mm - g.flange_thickness_mm - g.bottom_flange_thickness_mm),
            (-g.top_width_mm / 2, g.depth_mm - g.flange_thickness_mm,
             g.top_width_mm, g.flange_thickness_mm))


def _rail_outline(g):
    """Schematic contour only, never used to derive catalog properties."""
    b,h,o,z=g.rail_width_mm,g.rail_height_mm,g.rail_offset_mm,g.depth_mm
    if not g.rail_web_thickness_mm:
        return [(o-b/2,z),(o+b/2,z),(o+b/2,z+h),(o-b/2,z+h)]
    t,br,hh,hf=g.rail_web_thickness_mm,g.rail_head_width_mm,g.rail_head_height_mm,g.rail_foot_height_mm
    pts=[(-b/2,0),(b/2,0),(t/2,hf),(t/2,h-hh),(br/2,h-hh),(br/2,h),(-br/2,h),(-br/2,h-hh),(-t/2,h-hh),(-t/2,hf)]
    return [(o+y,z+zz) for y,zz in pts]


def _section_figure(g: ViewGeometry) -> Figure:
    wheel_y = g.rail_offset_mm+g.wheel_lateral_offset_mm
    extent = max(g.depth_mm+g.rail_height_mm,g.top_width_mm,g.bottom_width_mm,
                 g.rail_width_mm+2*abs(g.rail_offset_mm),2*abs(wheel_y))
    notes = ["Seção em escala geométrica igual · cotas em mm · y transversal · z vertical · x saindo do plano.",
             f"Eixo do trilho / alma: {_fmt(g.rail_offset_mm)} mm. Linha da roda / trilho: {_fmt(g.wheel_lateral_offset_mm)} mm; roda / alma: {_fmt(wheel_y)} mm.",
             ("Trilho " + g.rail_profile_label + ": contorno sem raios." if g.has_rail and g.rail_profile_label else
              "Trilho: envelope retangular informado." if g.has_rail else "Trilho não informado nesta geometria.") +
             " Sem crédito de resistência como seção composta."]
    if g.flange_web_weld_mm:
        notes.append(f"Filete alma–mesa: perna = {_fmt(g.flange_web_weld_mm)} mm, conforme detalhe fornecido. " +
                     (g.weld_note or "Representação geométrica; consultar verificação das soldas na memória."))
    else:
        notes.append("Soldas, fixações do trilho e raios não dimensionados nesta vista. Não é um detalhe de fabricação.")
    fig,ax = _sheet("03","SEÇÃO TRANSVERSAL","Seção de aço e trilho separados · mesas superior e inferior independentes",notes=notes,square=True)
    for y,z,w,h in _section_rectangles(g):
        ax.add_patch(Rectangle((y,z),w,h,facecolor=STEEL,edgecolor=INK,lw=1.25,zorder=3))
    if g.has_rail:
        ax.add_patch(Polygon(_rail_outline(g),facecolor="#F2E2C8",edgecolor=RAIL,lw=1.2,zorder=4))
    # Fillets are shown only when an actual fixed detail has been supplied.
    # Neither an unselected minimum nor an automatically guessed weld is drawn.
    a=g.flange_web_weld_mm
    if a:
        for sign in (-1,1):
            y=sign*g.web_thickness_mm/2
            for z,direction in ((g.bottom_flange_thickness_mm,1),(g.depth_mm-g.flange_thickness_mm,-1)):
                ax.add_patch(Polygon([(y,z),(y+sign*a,z),(y,z+direction*a)],
                                     facecolor=WELD,edgecolor=WELD,lw=.5,zorder=5))
    width=max(g.top_width_mm,g.bottom_width_mm,g.rail_width_mm+2*abs(g.rail_offset_mm),2*abs(wheel_y))
    ax.plot([0,0],[-.08*extent,g.depth_mm+g.rail_height_mm+.07*extent],
            color=MUTED,ls=(0,(8,3,2,3)),lw=.8,zorder=4)
    if g.wheel_positions_m:
        top=g.depth_mm+g.rail_height_mm
        ax.annotate("",(wheel_y,top),(wheel_y,top+.18*extent),
                    arrowprops={"arrowstyle":"-|>","color":WHEEL,"lw":1.1},zorder=7)
    _dim_h(ax,-g.top_width_mm/2,g.top_width_mm/2,
           g.depth_mm+g.rail_height_mm+.32*extent,g.depth_mm,f"b sup = {_fmt(g.top_width_mm)}",above=True)
    _dim_h(ax,-g.bottom_width_mm/2,g.bottom_width_mm/2,-.18*extent,0,
           f"b inf = {_fmt(g.bottom_width_mm)}")
    _dim_v(ax,0,g.depth_mm,-width/2-.18*extent,-width/2,f"d = {_fmt(g.depth_mm)}")
    tx=width/2+.31*extent
    lane_z=[g.depth_mm/2+k*.21*extent for k in (1.5,.5,-.5,-1.5)]
    callouts=[
        ((g.rail_profile_label+" · " if g.rail_profile_label else "Trilho · ")+f"{_fmt(g.rail_width_mm)} × {_fmt(g.rail_height_mm)}" if g.has_rail else "Sem trilho",
         (g.rail_offset_mm+g.rail_width_mm/2,g.depth_mm+g.rail_height_mm/2),RAIL),
        (f"tf sup = {_fmt(g.flange_thickness_mm)}",(g.top_width_mm/2,g.depth_mm-g.flange_thickness_mm/2),INK),
        (f"tw = {_fmt(g.web_thickness_mm)}",(g.web_thickness_mm/2,g.depth_mm/2),INK),
        (f"tf inf = {_fmt(g.bottom_flange_thickness_mm)}",(g.bottom_width_mm/2,g.bottom_flange_thickness_mm/2),INK)]
    for (label,anchor,color),z in zip(callouts,lane_z):
        if label=="Sem trilho":
            continue
        ax.annotate(label,anchor,xytext=(tx,z),fontsize=10,color=color,ha="left",va="center",
                    arrowprops={"arrowstyle":"-","color":color,"lw":.8,
                                "connectionstyle":"angle,angleA=180,angleB=90,rad=0"},zorder=6,
                    bbox={"facecolor":"white","edgecolor":"none","pad":2})
    if a:
        anchor=(g.web_thickness_mm/2+a*.3,g.bottom_flange_thickness_mm+a*.3)
        ax.annotate(f"perna = {_fmt(a)}",anchor,xytext=(tx,-.17*extent),
                    fontsize=9.5,color=WELD,ha="left",va="bottom",
                    arrowprops={"arrowstyle":"-","color":WELD,"lw":.8},zorder=7,
                    bbox={"facecolor":"white","edgecolor":"none","pad":1.5})
    _triad(ax,"y","z",origin=(.87,.055),scale=.72)
    ax.set_xlim(-width/2-.44*extent,tx+.95*extent)
    ax.set_ylim(min(-.36*extent,lane_z[-1]-.12*extent),
                max(g.depth_mm+g.rail_height_mm+.52*extent,lane_z[0]+.16*extent))
    ax.set_aspect("equal",adjustable="box")
    return fig


def section_png(geometry: ViewGeometry, *, dpi: int = 160) -> bytes:
    """Equal-scale y/z section preserving both flange widths and thicknesses."""
    return _finish(_section_figure(geometry), dpi)


def _isometric_figure(g: ViewGeometry) -> Figure:
    size = max(g.depth_mm + g.rail_height_mm, g.top_width_mm, g.bottom_width_mm, g.rail_width_mm + 2 * abs(g.rail_offset_mm))
    transverse_scale = 1.45 / size

    def project(x, y, z):
        # All views share the same physical coordinates; only display scales differ.
        u = 7.9 * (x - g.physical_start_m) / g.physical_length_m
        return u + .65 * y * transverse_scale, .20 * u - .32 * y * transverse_scale + z * transverse_scale

    def prism(y, z, width, height, color, end=INK, start=None, finish=None, alpha=1):
        start = g.physical_start_m if start is None else start
        finish = g.physical_start_m + g.physical_length_m if finish is None else finish
        faces = [([(start, y, z), (finish, y, z), (finish, y, z + height), (start, y, z + height)], color),
                 ([(start, y, z + height), (finish, y, z + height), (finish, y + width, z + height), (start, y + width, z + height)], "#C1D6E3" if color == STEEL else color),
                 ([(start, y, z), (start, y + width, z), (start, y + width, z + height), (start, y, z + height)], "#A6BFCE" if color == STEEL else color)]
        for pts, fill in faces:
            ax.add_patch(Polygon([project(*pt) for pt in pts], facecolor=fill, edgecolor=end, lw=.85, alpha=alpha))

    notes = [f"L = {_fmt(g.span_m)} m · d = {_fmt(g.depth_mm)} mm · mesas sup/inf = {_fmt(g.top_width_mm)} / {_fmt(g.bottom_width_mm)} mm.",
             "x longitudinal · y transversal · z vertical. Axonometria esquemática, comprimento comprimido; rodas e contenções simbólicas.",
             "Triângulos verdes: travas cadastradas. Círculos roxos: contenção lateral, sem redução de Lb para FLT.",
             "Trilho sem crédito de seção composta. Fixações e ligações não detalhadas; esta vista não autoriza fabricação."]
    if g.stiffener_positions_m:
        notes.insert(1,f"Pares de enrijecedores: {len(g.stiffener_positions_m)} posições; chapas t = {_fmt(g.stiffener_thickness_mm)} mm × {_fmt(g.stiffener_outstand_mm)} mm de largura saliente. Mesmas posições x da elevação.")
    if g.lateral_only_positions_m:
        level_label={'upper_flange':'mesa superior','lower_flange':'mesa inferior',
                     'shear_center':'eixo / centro de cisalhamento (nível esquemático)'}[g.lateral_only_level]
        notes.append("Contenção lateral aplicada em: "+level_label+".")
    fig, ax = _sheet("04", "VISTA AXONOMÉTRICA", "Mesma origem e mesmas posições de rodas e travamentos das vistas 01/02", notes=notes)
    for y, z, w, h in _section_rectangles(g):
        prism(y, z, w, h, STEEL)
    if g.has_rail:
        contour=_rail_outline(g)
        start=g.physical_start_m;end=start+g.physical_length_m
        for (y,z),(yy,zz) in zip(contour,contour[1:]+contour[:1]):
            ax.add_patch(Polygon([project(start,y,z),project(end,y,z),project(end,yy,zz),project(start,yy,zz)],facecolor="#EAD8BC",edgecolor=RAIL,lw=.6))
        ax.add_patch(Polygon([project(start,y,z) for y,z in contour],facecolor="#DCC29D",edgecolor=RAIL,lw=.8))
    for x in reversed(g.stiffener_positions_m):
        for y in (-g.web_thickness_mm/2-g.stiffener_outstand_mm,g.web_thickness_mm/2):
            prism(y,g.bottom_flange_thickness_mm,g.stiffener_outstand_mm,
                g.depth_mm-g.flange_thickness_mm-g.bottom_flange_thickness_mm,"#A5C4C0",BRACE,
                start=x-g.stiffener_thickness_mm/2000,finish=x+g.stiffener_thickness_mm/2000)
    if g.highlighted_segment:
        a, b = g.highlighted_segment
        points = [project(a, -g.web_thickness_mm / 2 - 1, g.bottom_flange_thickness_mm),
                  project(b, -g.web_thickness_mm / 2 - 1, g.bottom_flange_thickness_mm),
                  project(b, -g.web_thickness_mm / 2 - 1, g.depth_mm - g.flange_thickness_mm),
                  project(a, -g.web_thickness_mm / 2 - 1, g.depth_mm - g.flange_thickness_mm)]
        ax.add_patch(Polygon(points, facecolor=HIGHLIGHT, edgecolor="none", alpha=.5, zorder=5))
    for i,x in enumerate(g.wheel_positions_m):
        contact = project(x, g.rail_offset_mm + g.wheel_lateral_offset_mm, g.depth_mm + g.rail_height_mm)
        ax.add_patch(Ellipse((contact[0], contact[1] + .14), .22, .28,
                             facecolor="white", edgecolor=WHEEL, lw=1.5, zorder=7))
        ax.plot(contact[0], contact[1] + .14, ".", color=WHEEL, ms=3, zorder=8)
        if len(g.wheel_positions_m)<=4:
            ax.text(contact[0],contact[1]+.43,textwrap.shorten(_wheel_name(g,i),width=12,placeholder="…"),ha="center",va="bottom",fontsize=9.5,color=WHEEL,fontweight="bold",zorder=10)
    for x in g.brace_positions_m:
        point = project(x, g.top_width_mm / 2, g.depth_mm)
        edge = project(x, g.top_width_mm / 2 + size * .22, g.depth_mm)
        ax.plot([point[0], edge[0]], [point[1], edge[1]], color=BRACE, lw=1.5, zorder=8)
        ax.plot(edge[0], edge[1], marker="^", ms=6, mfc="white", mec=BRACE, zorder=9)
    for positions,level,color,marker in ((g.lower_brace_positions_m,'lower_flange',BRACE,'v'),(g.lateral_only_positions_m,g.lateral_only_level,LATERAL_ONLY,'o')):
        z={'upper_flange':g.depth_mm-g.flange_thickness_mm/2,'lower_flange':g.bottom_flange_thickness_mm/2,'shear_center':g.depth_mm/2}[level]
        for x in positions:
            anchor_y={'upper_flange':-g.top_width_mm/2,'lower_flange':-g.bottom_width_mm/2,'shear_center':-g.web_thickness_mm/2}[level]
            point=project(x,anchor_y,z)
            edge=project(x,anchor_y-size*.22,z)
            ax.plot([point[0],edge[0]],[point[1],edge[1]],color=color,lw=1.3,zorder=8)
            ax.plot(edge[0],edge[1],marker=marker,ms=6,mfc='white',mec=color,zorder=9)
    for x, label in ((0, "A"), (g.span_m, "B")):
        u, v = project(x, 0, 0)
        ax.add_patch(Polygon([(u, v - .015), (u - .13, v - .23), (u + .13, v - .23)],
                             facecolor="white", edgecolor=INK, lw=1, zorder=8))
        ax.text(u, v - .32, label, ha="center", va="top", color=INK, fontsize=9, fontweight="bold")
    # Length dimension runs parallel to the actual projected longitudinal axis.
    p1 = project(0, -g.bottom_width_mm / 2, 0)
    p2 = project(g.span_m, -g.bottom_width_mm / 2, 0)
    a, b = (p1[0], p1[1] - .70), (p2[0], p2[1] - .70)
    for start, end in ((p1, a), (p2, b)):
        ax.plot([start[0], end[0]], [start[1] - .1, end[1]], color=LIGHT, lw=.8)
    ax.annotate("", b, a, arrowprops={"arrowstyle": "|-|", "color": MUTED, "lw": .9})
    ax.annotate(f"L = {_fmt(g.span_m)} m · entre apoios", ((a[0] + b[0]) / 2, (a[1] + b[1]) / 2),
                xytext=(0, -12), textcoords="offset points", ha="center", color=MUTED, fontsize=10,
                bbox={"facecolor": BACKGROUND, "edgecolor": "none", "pad": 2})
    origin = (.89, .13)
    for end, label in (((.965, .18), "x"), ((.945, .07), "y"), ((.89, .31), "z")):
        ax.annotate("", end, origin, xycoords="axes fraction", textcoords="axes fraction",
                    arrowprops={"arrowstyle": "->", "lw": 1, "color": MUTED})
        ax.annotate(label, end, xycoords="axes fraction", xytext=(4, 3), textcoords="offset points",
                    color=MUTED, fontsize=9)
    ax.set_xlim(-1.05, 9.3)
    ax.set_ylim(-1.15, 4.15)
    ax.set_aspect("equal", adjustable="box")
    return fig


def isometric_png(geometry: ViewGeometry, *, dpi: int = 160) -> bytes:
    """Axonometric overview; the longitudinal compression is explicitly disclosed."""
    return _finish(_isometric_figure(geometry), dpi)
