"""Exact first-order vertical response of a uniformly loaded end projection.

No wheels travel outside the support axes. The main span determines its actual
support rotation; this is not a falsely clamped cantilever. q is the same
factored permanent line load used in the main span. These formulas alone do
not qualify lateral stability, torsional compatibility or a service limit.
"""
import math


def vertical_projection_state(length_m,q_kn_per_m,EI_knm2,support_slope_rad,outward_sign,distance_m):
    for value in (length_m,q_kn_per_m,EI_knm2,support_slope_rad,distance_m):
        if isinstance(value,bool) or not isinstance(value,(int,float)) or not math.isfinite(value):
            raise ValueError('Projection inputs must be finite real numbers')
    if length_m<0 or q_kn_per_m<0 or EI_knm2<=0 or not 0<=distance_m<=length_m or outward_sign not in (-1,1) or isinstance(outward_sign,bool):
        raise ValueError('Invalid vertical projection domain')
    a,u,q,EI=length_m,distance_m,q_kn_per_m,EI_knm2
    outward_slope=outward_sign*support_slope_rad
    deflection=1000*(outward_slope*u+q/EI*(a*a*u*u/4-a*u**3/6+u**4/24))
    slope_out=outward_slope+q/(6*EI)*(a**3-(a-u)**3)
    return dict(distance_from_support_m=u,Mx_knm=-q*(a-u)**2/2,
                Vy_kn=outward_sign*q*(a-u),vertical_mm=deflection,
                slope_rad=outward_sign*slope_out)


def vertical_projection_extrema(length_m,q_kn_per_m,EI_knm2,support_slope_rad,outward_sign):
    root=vertical_projection_state(length_m,q_kn_per_m,EI_knm2,support_slope_rad,outward_sign,0.)
    tip=vertical_projection_state(length_m,q_kn_per_m,EI_knm2,support_slope_rad,outward_sign,length_m)
    points=[root,tip]
    if q_kn_per_m and length_m:
        cube=length_m**3+6*EI_knm2*outward_sign*support_slope_rad/q_kn_per_m
        if 0<cube<length_m**3:
            u=length_m-math.cbrt(cube)
            points.append(vertical_projection_state(length_m,q_kn_per_m,EI_knm2,support_slope_rad,outward_sign,u))
    peak=max(points,key=lambda row:abs(row['vertical_mm']))
    return dict(root=root,tip=tip,critical_points=tuple(points),
                vertical_maximum_abs_mm=abs(peak['vertical_mm']),vertical_critical=peak,
                root_moment_abs_knm=abs(root['Mx_knm']),root_shear_abs_kn=abs(root['Vy_kn']),
                equilibrium_and_vertical_kinematics_complete=True,
                lateral_stability_qualified=False,service_limit_qualified=False,
                source='Integração exata de -EI v"=M; M=-q(a-u)^2/2, rotação real do apoio e extremidade livre.')
