"""Conservative resultants for a fixed full-height stiffener weld detail.

Components bound load introduction and actual support/brace reactions about
the section shear centre. The weld-group adapter transports those resultants
to each interface. Global span bending moments are not concentrated loads on
every stiffener. Multiple brace reactions are bounded by their absolute sum. Applied horizontal
loads/torques are then added to the reaction envelope, so coincident introduction
and a paired upper/lower attachment cannot lose force or reactive torque.

This six-resultant transfer model does not assert restraint of warping, nor
convert a sectorial bimoment into a classical torque. A separately specified
warping-restraint detail needs its own transfer/stress assessment.
"""
import math

KEYS=('force_longitudinal_kn','force_transverse_kn','force_vertical_kn',
      'moment_about_longitudinal_knm','moment_about_transverse_knm','moment_about_vertical_knm')


def _validate_bounds(row):
    if not isinstance(row,dict) or set(row)!=set(KEYS):
        raise ValueError('Componentes do grupo de solda incompletos.')
    if any(isinstance(v,bool) or not isinstance(v,(int,float)) or not math.isfinite(v) or v<0 for v in row.values()):
        raise ValueError('Limites de ações no grupo de soldas inválidos.')


def stiffener_action_bounds(p,response):
    """Envelope applied resultants and reactions, with kN and kNm outputs.

    ``solve_lateral_torsion`` stores original point loads first and appends one
    load for each brace reaction. Names are user-facing labels, not type tags.
    The complete absolute brace sum is retained even when several attachments
    share one physical stiffener pair; no favorable sharing is assumed.
    """
    v=response.vertical;lat=response.lateral_torsion;reac=v.reactions
    braces=lat.brace_reactions
    if len(lat.loads)!=len(v.loads)+len(braces):
        raise ValueError('Cardinalidade das cargas físicas e reações de travamento inconsistente.')
    real=lat.loads[:len(v.loads)]
    for point,coupled in zip(v.loads,real):
        if not (math.isclose(coupled.x_mm,point.position_m*1000,rel_tol=1e-12,abs_tol=1e-9)
                and math.isclose(coupled.horizontal_n,point.horizontal_kn*1000,rel_tol=1e-12,abs_tol=1e-9)
                and math.isclose(coupled.minor_couple_nmm,point.minor_moment_knm*1e6,rel_tol=1e-12,abs_tol=1e-6)):
            raise ValueError('Ordenação/ações das cargas físicas acopladas inconsistente.')
    result={
        'force_longitudinal_kn':max(math.fsum(abs(q.longitudinal_kn) for q in v.loads)+abs(v.udl.longitudinal_kn_per_m)*p.span_m,abs(reac.longitudinal_left_kn),abs(reac.longitudinal_right_kn)),
        'force_transverse_kn':math.fsum(abs(q.horizontal_n) for q in real)/1000+abs(lat.uniform_horizontal_n_per_mm)*p.span_m+
            max(*(abs(x)/1000 for x in lat.horizontal_support_reactions_n),math.fsum(abs(b['horizontal_reaction_n']) for b in braces)/1000),
        'force_vertical_kn':max(math.fsum(abs(q.vertical_kn) for q in v.all_loads)+abs(v.udl.vertical_kn_per_m)*p.span_m,abs(reac.vertical_left_kn),abs(reac.vertical_right_kn)),
        'moment_about_longitudinal_knm':math.fsum(abs(q.torque_nmm) for q in real)/1e6+abs(lat.torsion.uniform_torque_nmm_per_mm)*p.span_m/1000+
            max(*(abs(x)/1e6 for x in lat.torsion.support_torques_nmm),math.fsum(abs(b['torque_reaction_nmm']) for b in braces)/1e6),
        'moment_about_transverse_knm':math.fsum(abs(q.major_moment_knm) for q in v.loads),
        'moment_about_vertical_knm':math.fsum(abs(q.minor_moment_knm) for q in v.loads),
    }
    _validate_bounds(result)
    return result


def envelope_action_bounds(records):
    rows=list(records)
    if not rows:raise ValueError('Envoltória de grupos de solda vazia.')
    for row in rows:_validate_bounds(row)
    return {k:max(r[k] for r in rows) for k in KEYS}
