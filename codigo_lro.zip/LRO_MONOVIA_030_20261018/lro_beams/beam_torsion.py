"""First-order Vlasov torsion and compatible lateral braces, explicit N/mm units.

Straight uniform bisymmetric open beam; end forks, free warping.  This is an
elastic action solver, NOT a strength, second-order or buckling verification.
SCI P385 (2011), sections 2.1-2.2 and Appendix C cases 3/4 provide the theory.
The Green-function form and brace flexibility assembly are derived equivalents.

x longitudinal, y lateral, z upward. Positive theta moves +z toward +y.
Wheel torque about this axis is H_y*z + P_down*e_y. B=-E*Cw*theta''.
Point load positions and all geometry are mm; forces N; torques N.mm;
uniform torque N.mm/mm; E,G MPa; J mm4; Cw mm6; B N.mm2.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict
import math
import sys
from functools import cached_property
from typing import Sequence

SOURCE = "SCI P385, 2011, 2.1-2.2 and Appendix C, cases 3/4; linear Green-function compatibility"


def _number(value, name, positive=False):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f"{name}: finite real number required")
    if not math.isfinite(value) or (positive and value <= 0):
        raise ValueError(f"{name}: finite {'positive ' if positive else ''}number required")


@dataclass(frozen=True)
class VlasovBeam:
    span_mm: float
    E_mpa: float
    G_mpa: float
    J_mm4: float
    Cw_mm6: float

    def __post_init__(self):
        for name, value in asdict(self).items():
            _number(value, name, True)
        if not all(math.isfinite(v) and v > 0 for v in (self.ECw, self.GJ, self.k, self.k*self.span_mm)):
            raise ValueError("Derived torsion stiffness outside finite positive domain")

    # These stiffness values depend only on this frozen beam's five fields.
    # Retain the exact original arithmetic once per immutable instance; no
    # shared project/load/result cache and no stale-value invalidation needed.
    @cached_property
    def ECw(self): return self.E_mpa*self.Cw_mm6
    @cached_property
    def GJ(self): return self.G_mpa*self.J_mm4
    @cached_property
    def k(self): return math.sqrt(self.GJ/self.ECw)


@dataclass(frozen=True)
class PointTorque:
    x_mm: float
    torque_nmm: float
    name: str = ""


@dataclass(frozen=True)
class PointBimoment:
    """Generalized couple C conjugate to theta'(x), units N.mm².

    It produces a +C jump in internal B. A top-flange axial transfer has
    C=-Fx*e*h0/2, from virtual work u_warp=-omega*theta'.
    """
    x_mm: float
    sectorial_couple_nmm2: float
    name: str = ""


@dataclass(frozen=True)
class TorsionState:
    x_mm: float
    side: str
    theta_rad: float
    theta_prime_per_mm: float
    bimoment_nmm2: float
    saint_venant_torque_nmm: float
    warping_torque_nmm: float
    total_torque_nmm: float



def _torsion_state_dict(state):
    """Exact shallow serialization of the scalar-only TorsionState record."""
    return dict(x_mm=state.x_mm,side=state.side,theta_rad=state.theta_rad,
                theta_prime_per_mm=state.theta_prime_per_mm,
                bimoment_nmm2=state.bimoment_nmm2,
                saint_venant_torque_nmm=state.saint_venant_torque_nmm,
                warping_torque_nmm=state.warping_torque_nmm,
                total_torque_nmm=state.total_torque_nmm)


def _log_sinhc(x):
    """log(sinh(x)/x), stable at zero and at large positive x."""
    if x == 0: return 0.0
    if x < 0.05:
        y = x*x
        return y*(1/6 + y*(-1/180 + y*(1/2835 - y/37800)))
    if x < 20: return math.log(math.sinh(x)/x)
    return x-math.log(2*x)+math.log1p(-math.exp(-2*x))


def _log_cosh(x):
    x = abs(x)
    if x < 0.05:
        y = x*x
        return y*(0.5 + y*(-1/12 + y*(1/45 - 17*y/2520)))
    if x < 20: return math.log(math.cosh(x))
    return x-math.log(2)+math.log1p(math.exp(-2*x))


def _position(x, length, side):
    _number(x, "x_mm")
    if not 0 <= x <= length or side not in ("left", "right"):
        raise ValueError("Station must lie on beam and side must be left/right")


def _point_kernel(beam, x, p, side="right"):
    """theta, theta', B and B' per unit applied torque; no load factors."""
    L, k = beam.span_mm, beam.k
    left = x < p or (x == p and side == "left")
    m, n = min(x,p), L-max(x,p)
    g = m*n/L
    log_h_ratio = _log_sinhc(k*m)+_log_sinhc(k*n)-_log_sinhc(k*L)
    h = g*math.exp(log_h_ratio)
    theta = -g*math.expm1(log_h_ratio)/beam.GJ
    if left:
        gp = (L-p)/L
        log_hp_ratio = _log_cosh(k*x)+_log_sinhc(k*(L-p))-_log_sinhc(k*L)
    else:
        gp = -p/L
        log_hp_ratio = _log_sinhc(k*p)+_log_cosh(k*(L-x))-_log_sinhc(k*L)
    hp = gp*math.exp(log_hp_ratio)
    theta_p = -gp*math.expm1(log_hp_ratio)/beam.GJ
    return theta, theta_p, h, hp


def _bimoment_kernel(beam,x,p,side="right"):
    """Load-position derivative of torque Green: theta, theta', B and B'.

    Reciprocity gives dG(x,p)/dp=dG(p,x)/d(first coordinate). The regular
    mixed derivative of H is -k*cosh(k min)*cosh(k(L-max))/sinh(kL).
    The distributional B jump is C; B' here is its physical one-sided value.
    """
    left=x<p or (x==p and side=='left')
    reciprocal=_point_kernel(beam,p,x,'right' if left else 'left')
    L,k=beam.span_mm,beam.k
    log_ratio=_log_cosh(k*min(x,p))+_log_cosh(k*(L-max(x,p)))-_log_sinhc(k*L)
    mixed=-math.exp(log_ratio)/L
    theta_prime=math.expm1(log_ratio)/(L*beam.GJ)
    return reciprocal[1],theta_prime,reciprocal[3],mixed


def _uniform_kernel(beam, x):
    """Full-span uniform torque kernel, per N.mm/mm."""
    L, k = beam.span_mm, beam.k
    t, s = k*L, x/L-0.5
    if t < 0.1:
        # Ratio cosh(t*s)/cosh(t/2), expanded before cancellation.
        r, rp = [1.0], [0.0]
        for m in range(1, 9):
            denominator = [0.5**(2*j)/math.factorial(2*j) for j in range(m+1)]
            r.append(s**(2*m)/math.factorial(2*m)-sum(denominator[j]*r[m-j] for j in range(1,m+1)))
            rp.append(s**(2*m-1)/math.factorial(2*m-1)-sum(denominator[j]*rp[m-j] for j in range(1,m+1)))
        theta = L**4/beam.ECw*math.fsum(r[m]*t**(2*m-4) for m in range(2,9))
        theta_p = L**3/beam.ECw*math.fsum(rp[m]*t**(2*m-4) for m in range(2,9))
        B = -L**2*math.fsum(r[m]*t**(2*m-2) for m in range(1,9))
        Bp = -L*math.fsum(rp[m]*t**(2*m-2) for m in range(1,9))
    else:
        lr = _log_cosh(t*s)-_log_cosh(t/2)
        ratio = math.exp(lr)
        B = -math.expm1(lr)/k**2
        Bp = -math.tanh(t*s)*ratio/k
        theta = (x*(L-x)/2-B)/beam.GJ
        theta_p = ((L-2*x)/2-Bp)/beam.GJ
    return theta, theta_p, B, Bp


@dataclass(frozen=True)
class TorsionSolution:
    beam: VlasovBeam
    point_torques: tuple[PointTorque, ...] = ()
    uniform_torque_nmm_per_mm: float = 0.0
    point_bimoments: tuple[PointBimoment, ...] = ()

    def __post_init__(self):
        if not isinstance(self.beam, VlasovBeam): raise ValueError("VlasovBeam required")
        _number(self.uniform_torque_nmm_per_mm, "uniform_torque_nmm_per_mm")
        object.__setattr__(self, "point_torques", tuple(self.point_torques))
        for load in self.point_torques:
            if not isinstance(load, PointTorque): raise ValueError("PointTorque required")
            _position(load.x_mm, self.beam.span_mm, "right")
            _number(load.torque_nmm, "torque_nmm")
        object.__setattr__(self,"point_bimoments",tuple(self.point_bimoments))
        for load in self.point_bimoments:
            if not isinstance(load,PointBimoment):raise ValueError("PointBimoment required")
            _position(load.x_mm,self.beam.span_mm,"right")
            _number(load.sectorial_couple_nmm2,"sectorial_couple_nmm2")

    @property
    def support_torques_nmm(self):
        """Applied support reaction torques (opposite to positive loading)."""
        L, q = self.beam.span_mm, self.uniform_torque_nmm_per_mm
        couple=math.fsum(p.sectorial_couple_nmm2 for p in self.point_bimoments)/L
        return (-math.fsum(p.torque_nmm*(L-p.x_mm)/L for p in self.point_torques)-q*L/2+couple,
                -math.fsum(p.torque_nmm*p.x_mm/L for p in self.point_torques)-q*L/2-couple)

    def at(self, x_mm: float, side: str = "right") -> TorsionState:
        _position(x_mm, self.beam.span_mm, side)
        terms = [[load.torque_nmm*v for v in _point_kernel(self.beam,x_mm,load.x_mm,side)] for load in self.point_torques]
        terms.extend([load.sectorial_couple_nmm2*v for v in _bimoment_kernel(self.beam,x_mm,load.x_mm,side)] for load in self.point_bimoments)
        if self.uniform_torque_nmm_per_mm:
            terms.append([self.uniform_torque_nmm_per_mm*v for v in _uniform_kernel(self.beam,x_mm)])
        theta, tp, B, Tw = [math.fsum(t[i] for t in terms) for i in range(4)]
        Ts = self.beam.GJ*tp
        values = (theta,tp,B,Tw,Ts,Ts+Tw)
        if not all(math.isfinite(v) for v in values): raise ValueError("Nonfinite torsion response")
        return TorsionState(x_mm,side,theta,tp,B,Ts,Tw,Ts+Tw)


def wheel_torque_nmm(vertical_down_n, horizontal_y_n, rail_height_from_cs_mm, eccentricity_y_mm):
    """Transport actual wheel forces once; no dynamic or safety factors."""
    for name,value in locals().copy().items(): _number(value,name)
    result = horizontal_y_n*rail_height_from_cs_mm+vertical_down_n*eccentricity_y_mm
    _number(result,"derived wheel torque")
    return result


def thin_wall_i_torsion_properties(depth_mm, flange_width_mm, flange_thickness_mm, web_thickness_mm):
    """Ideal rectangular thin-wall I model; no fillets or composite rail credit."""
    d,b,tf,tw = depth_mm,flange_width_mm,flange_thickness_mm,web_thickness_mm
    for name,value in zip(("d","b","tf","tw"),(d,b,tf,tw)): _number(value,name,True)
    if d <= 2*tf or b <= tw: raise ValueError("Invalid symmetric I geometry")
    h,hw = d-tf,d-2*tf
    result = dict(h0_mm=h, J_mm4=(2*b*tf**3+hw*tw**3)/3,
                  Cw_mm6=tf*b**3*h**2/24, omega_tip_mm2=b*h/4,
                  sectorial_first_moment_junction_mm4=tf*h*b**2/16,
                  Iy_mm4=(2*tf*b**3+hw*tw**3)/12)
    if not all(math.isfinite(v) and v>0 for v in result.values()): raise ValueError("Nonfinite section property")
    return result


def torsion_stress_bounds(beam: VlasovBeam, state: TorsionState, flange_width_mm,
                          flange_thickness_mm, web_thickness_mm, flange_centroid_spacing_mm):
    """Magnitude bounds, NOT a simultaneous full stress tensor.

    omega=y*z with z=+/-h0/2. Warping normal maximum is at flange tips;
    warping shear maximum is at the web junction, where omega=0.
    Saint-Venant stress is the thin-strip surface value Ts*t/J.
    """
    b,tf,tw,h = flange_width_mm,flange_thickness_mm,web_thickness_mm,flange_centroid_spacing_mm
    for name,value in zip(("b","tf","tw","h0"),(b,tf,tw,h)): _number(value,name,True)
    omega, Sw = b*h/4, tf*h*b*b/16
    normal = abs(state.bimoment_nmm2)*omega/beam.Cw_mm6
    warp_shear = abs(state.warping_torque_nmm)*Sw/(beam.Cw_mm6*tf)
    sv_flange = abs(state.saint_venant_torque_nmm)*tf/beam.J_mm4
    sv_web = abs(state.saint_venant_torque_nmm)*tw/beam.J_mm4
    result=dict(warping_normal_tip_abs_mpa=normal, warping_shear_flange_junction_abs_mpa=warp_shear,
                saint_venant_shear_flange_surface_abs_mpa=sv_flange,
                saint_venant_shear_web_surface_abs_mpa=sv_web,
                flange_torsion_shear_upper_bound_mpa=warp_shear+sv_flange,
                warping_flange_moment_abs_nmm=abs(state.bimoment_nmm2)/h)
    if not all(math.isfinite(v) for v in result.values()): raise ValueError("Nonfinite torsion stress bound")
    return result


@dataclass(frozen=True)
class LateralTorqueLoad:
    x_mm: float
    horizontal_n: float = 0.0
    torque_nmm: float = 0.0  # already transported to shear centre
    name: str = ""
    minor_couple_nmm: float = 0.0  # positive work C*v'; positive jump in minor moment
    sectorial_couple_nmm2: float = 0.0  # work C*theta'; positive jump in B


@dataclass(frozen=True)
class LateralBrace:
    x_mm: float
    height_from_cs_mm: float
    stiffness_n_per_mm: float | None = None  # None means ideal rigid restraint
    name: str = ""


def _bending_green(x,p,L):
    if x <= p:
        b=L-p
        return x*b*(L*L-b*b-x*x)/(6*L)
    b=L-x
    return p*b*(L*L-p*p-b*b)/(6*L)


def _bending_couple_green(x,p,L):
    """Derivative of force Green function with respect to its load position.

    Positive C is conjugate to v'(p): the limit of +C/d at p+d/2 and
    -C/d at p-d/2. End couples are permitted on the freely rotating supports.
    """
    if x <= p:
        b=L-p
        return -x*(L*L-3*b*b-x*x)/(6*L)
    b=L-x
    return b*(L*L-3*p*p-b*b)/(6*L)


def _cholesky_solve(matrix, rhs):
    """Small positive-definite flexibility system; no silent regularization."""
    n=len(rhs)
    if not n: return []
    scale=max(matrix[i][i] for i in range(n))
    if not math.isfinite(scale) or scale<=0: raise ValueError("Invalid brace flexibility matrix")
    lower=[[0.0]*n for _ in range(n)]
    for i in range(n):
        for j in range(i+1):
            v=matrix[i][j]-math.fsum(lower[i][k]*lower[j][k] for k in range(j))
            if i==j:
                if v<=scale*1e-13: raise ValueError("Dependent or ill-conditioned brace constraints")
                lower[i][j]=math.sqrt(v)
            else: lower[i][j]=v/lower[j][j]
    y=[]
    for i in range(n): y.append((rhs[i]-math.fsum(lower[i][j]*y[j] for j in range(i)))/lower[i][i])
    solution=[0.0]*n
    for i in range(n-1,-1,-1):
        solution[i]=(y[i]-math.fsum(lower[j][i]*solution[j] for j in range(i+1,n)))/lower[i][i]
    return solution


@dataclass(frozen=True)
class LateralTorsionSolution:
    beam: VlasovBeam
    Iy_mm4: float
    loads: tuple[LateralTorqueLoad,...]
    torsion: TorsionSolution
    uniform_horizontal_n_per_mm: float
    brace_reactions: tuple[dict,...]

    def at(self,x_mm,side="right"):
        _position(x_mm,self.beam.span_mm,side)
        x,L,w=x_mm,self.beam.span_mm,self.uniform_horizontal_n_per_mm
        v=math.fsum(p.horizontal_n*_bending_green(x,p.x_mm,L)+p.minor_couple_nmm*_bending_couple_green(x,p.x_mm,L) for p in self.loads)/(self.beam.E_mpa*self.Iy_mm4)
        v+=w*x*(L**3-2*L*x*x+x**3)/(24*self.beam.E_mpa*self.Iy_mm4)
        M=math.fsum(p.horizontal_n*min(x,p.x_mm)*(L-max(x,p.x_mm))/L for p in self.loads)+w*x*(L-x)/2
        V=math.fsum(p.horizontal_n*((L-p.x_mm)/L-(1 if x>p.x_mm or (x==p.x_mm and side=="right") else 0)) for p in self.loads)+w*(L/2-x)
        M+=math.fsum(p.minor_couple_nmm*((1 if x>p.x_mm or (x==p.x_mm and side=="right") else 0)-x/L) for p in self.loads)
        V-=math.fsum(p.minor_couple_nmm for p in self.loads)/L
        if not all(math.isfinite(a) for a in (v,M,V)): raise ValueError("Nonfinite lateral response")
        return {"x_mm":x,"side":side,"horizontal_mm":v,"minor_moment_nmm":M,
                "horizontal_shear_n":V,"torsion":_torsion_state_dict(self.torsion.at(x,side))}

    @property
    def horizontal_support_reactions_n(self):
        L,w=self.beam.span_mm,self.uniform_horizontal_n_per_mm
        return (-math.fsum(p.horizontal_n*(L-p.x_mm)/L-p.minor_couple_nmm/L for p in self.loads)-w*L/2,
                -math.fsum(p.horizontal_n*p.x_mm/L+p.minor_couple_nmm/L for p in self.loads)-w*L/2)


def _compatibility_roundoff_row(terms,field_residual,brace_count):
    """Unit-consistent backward residual, without a physical absolute floor.

    gamma_n uses a conservative assembly/kernel operation budget, not a
    certified transcendental-function error bound. It permits only rounding
    relative to the uncombined equation terms, never a fraction of a load or
    displacement chosen independently of the actual compatibility equation.
    """
    terms=tuple(terms)
    scale=math.fsum(abs(term) for term in terms);residual=math.fsum(terms)
    operation_budget=32*(1+len(terms)+brace_count)
    n_epsilon=operation_budget*sys.float_info.epsilon
    limit=n_epsilon/(1-n_epsilon)*scale
    if not all(math.isfinite(v) for v in (scale,residual,field_residual,limit)):
        raise ValueError('Nonfinite compatibility roundoff audit')
    return dict(residual=residual,field_residual=field_residual,uncancelled_scale=scale,
        backward_error=abs(residual)/scale if scale else 0.,
        roundoff_operation_budget=operation_budget,roundoff_limit=limit,
        passed=max(abs(residual),abs(field_residual))<=limit)


def _brace_compatibility_roundoff_row(solution,brace,index,brace_count):
    """Audit one physical brace row, retaining each uncancelled load term."""
    beam=solution.beam;L=beam.span_mm;x=brace.x_mm;z=brace.height_from_cs_mm
    EI=beam.E_mpa*solution.Iy_mm4;torsion=solution.torsion
    terms=[p.horizontal_n*_bending_green(x,p.x_mm,L)/EI for p in solution.loads]
    terms.extend(p.minor_couple_nmm*_bending_couple_green(x,p.x_mm,L)/EI for p in solution.loads)
    terms.extend(z*p.torque_nmm*_point_kernel(beam,x,p.x_mm)[0] for p in torsion.point_torques)
    terms.extend(z*p.sectorial_couple_nmm2*_bimoment_kernel(beam,x,p.x_mm)[0] for p in torsion.point_bimoments)
    if torsion.uniform_torque_nmm_per_mm:
        terms.append(z*torsion.uniform_torque_nmm_per_mm*_uniform_kernel(beam,x)[0])
    w=solution.uniform_horizontal_n_per_mm
    if w:terms.append(w*x*(L**3-2*L*x*x+x**3)/(24*EI))
    spring=solution.brace_reactions[index]['horizontal_reaction_n']/brace.stiffness_n_per_mm if brace.stiffness_n_per_mm else 0.
    terms.append(spring)
    field=solution.at(x)
    field_residual=math.fsum((field['horizontal_mm'],z*field['torsion']['theta_rad'],spring))
    return dict(kind='lateral_brace',index=index,x_mm=x,equation_units='mm',
                **_compatibility_roundoff_row(terms,field_residual,brace_count))


def solve_lateral_torsion(beam: VlasovBeam, Iy_mm4: float, loads: Sequence[LateralTorqueLoad]=(),
                          braces: Sequence[LateralBrace]=(), uniform_horizontal_n_per_mm: float=0.0,
                          uniform_torque_nmm_per_mm: float=0.0) -> LateralTorsionSolution:
    """Exact first-order brace compatibility v(xb)+zb*theta(xb) = -R/k.

    A top-flange lateral brace is not a fork. Vertical bending is independent
    only in this small-displacement first-order model. Brace strength and LTB
    stabilization are not established by solving these compatibility equations.
    """
    _number(Iy_mm4,"Iy_mm4",True)
    _number(uniform_horizontal_n_per_mm,"uniform_horizontal_n_per_mm")
    _number(uniform_torque_nmm_per_mm,"uniform_torque_nmm_per_mm")
    loads,braces=tuple(loads),tuple(braces)
    if len(braces)>100: raise ValueError("At most 100 brace constraints supported")
    for p in loads:
        if not isinstance(p,LateralTorqueLoad): raise ValueError("LateralTorqueLoad required")
        _position(p.x_mm,beam.span_mm,"right")
        _number(p.horizontal_n,"horizontal_n"); _number(p.torque_nmm,"torque_nmm")
        _number(p.minor_couple_nmm,"minor_couple_nmm");_number(p.sectorial_couple_nmm2,"sectorial_couple_nmm2")
    for b in braces:
        if not isinstance(b,LateralBrace): raise ValueError("LateralBrace required")
        _number(b.x_mm,"brace x"); _number(b.height_from_cs_mm,"brace height")
        if not 0<b.x_mm<beam.span_mm: raise ValueError("Brace must be strictly inside the fork-supported span")
        if b.stiffness_n_per_mm is not None: _number(b.stiffness_n_per_mm,"brace stiffness",True)
    basic_torsion=TorsionSolution(beam,tuple(PointTorque(p.x_mm,p.torque_nmm,p.name) for p in loads),uniform_torque_nmm_per_mm,
        tuple(PointBimoment(p.x_mm,p.sectorial_couple_nmm2,p.name) for p in loads if p.sectorial_couple_nmm2))
    basic=LateralTorsionSolution(beam,Iy_mm4,loads,basic_torsion,uniform_horizontal_n_per_mm,())
    matrix=[]; rhs=[]
    for i,bi in enumerate(braces):
        row=[]
        response=basic.at(bi.x_mm)
        rhs.append(-response["horizontal_mm"]-bi.height_from_cs_mm*response["torsion"]["theta_rad"])
        for j,bj in enumerate(braces):
            f=_bending_green(bi.x_mm,bj.x_mm,beam.span_mm)/(beam.E_mpa*Iy_mm4)
            f+=bi.height_from_cs_mm*bj.height_from_cs_mm*_point_kernel(beam,bi.x_mm,bj.x_mm)[0]
            if i==j and bi.stiffness_n_per_mm is not None: f+=1/bi.stiffness_n_per_mm
            row.append(f)
        matrix.append(row)
    reactions=_cholesky_solve(matrix,rhs)
    augmented=loads+tuple(LateralTorqueLoad(b.x_mm,R,R*b.height_from_cs_mm,"Brace: "+b.name) for b,R in zip(braces,reactions))
    records=tuple({"name":b.name,"x_mm":b.x_mm,"height_from_cs_mm":b.height_from_cs_mm,
                   "horizontal_reaction_n":R,"torque_reaction_nmm":R*b.height_from_cs_mm,
                   "stiffness_n_per_mm":b.stiffness_n_per_mm,
                   "attachment_displacement_mm":-R/b.stiffness_n_per_mm if b.stiffness_n_per_mm is not None else 0.0}
                  for b,R in zip(braces,reactions))
    torsion=TorsionSolution(beam,tuple(PointTorque(p.x_mm,p.torque_nmm,p.name) for p in augmented),uniform_torque_nmm_per_mm,
        tuple(PointBimoment(p.x_mm,p.sectorial_couple_nmm2,p.name) for p in augmented if p.sectorial_couple_nmm2))
    solution=LateralTorsionSolution(beam,Iy_mm4,augmented,torsion,uniform_horizontal_n_per_mm,records)
    # Check compatibility rather than masking singular/poorly resolved systems.
    for index,(b,record) in enumerate(zip(braces,records)):
        state=solution.at(b.x_mm)
        residual=state["horizontal_mm"]+b.height_from_cs_mm*state["torsion"]["theta_rad"]-record["attachment_displacement_mm"]
        if not math.isfinite(residual):
            raise ValueError("Brace compatibility residual exceeds numerical tolerance")
        # The assembled equation A R = rhs is already available. Check it at
        # every action scale: a fixed mm tolerance alone can admit a wrong
        # small-load reaction. No new kernel evaluation is needed normally.
        assembled=_compatibility_roundoff_row(
            [matrix[index][j]*R for j,R in enumerate(reactions)]+[-rhs[index]],
            residual,len(braces))
        if abs(residual)>1e-8*max(1.0,abs(record["attachment_displacement_mm"])) or not assembled['passed']:
            # Keep the original absolute test, but allow only independently
            # verified machine roundoff in the uncombined physical equation.
            # This also resolves cancellation within a nearly zero RHS.
            if not _brace_compatibility_roundoff_row(solution,b,index,len(braces))['passed']:
                raise ValueError("Brace compatibility residual exceeds numerical tolerance")
    return solution
