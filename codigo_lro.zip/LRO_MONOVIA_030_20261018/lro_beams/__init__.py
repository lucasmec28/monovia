"""LRO Viga de rolamento: cálculo autônomo no domínio documentado."""
__version__ = "0.4.3"
