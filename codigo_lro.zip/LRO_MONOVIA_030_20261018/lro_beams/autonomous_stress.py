"""Nominal global stresses for a bisymmetric prismatic I beam.

NORMAL STRESS is signed and belongs to one material point, section face, train
position and load case. It may supply a longitudinal nominal stress history.
SHEAR is an explicitly unsigned magnitude bound WITHIN THE SECTION MODEL below;
it is not a signed shear history or a certified 3-D/local stress upper bound.
It must never supply rainflow input. Local wheel patch, weld, fillet, connection,
load-introduction, cross-section distortion and re-entrant-corner effects are
excluded. No resistance or fatigue-detail qualification is made here.

Section model and derivation (b=bf, tf=flange thickness, h=d-2tf, h0=d-tf):
* sigma_x = N/A - Mx*z/Ix + My*y/Iy + B*omega/Cw. In a flange,
  omega=y*(+/-h0/2), constant across its thickness; omega=0 in the web.
* Vertical web shear is Jourawski Vz*Qz/(Ix*tw), where
  Qz=b*tf*h0/2 + tw*(h²/8-z²/2). Vertical shear through a flange is
  Vz*((d/2)²-z²)/(2Ix). Their integrated vertical resultant is Vz when
  Ix equals the three-rectangle inertia.
* Vertical load also produces the flange's tangential thin-wall shear flow:
  |tau_xy|=|Vz|*(h0/2)*(b/2-|y|)/Ix. Its left/right flows are opposite;
  there is no net horizontal resultant. This is a wall-midline recovery, not
  a finite-thickness junction solution. The through-thickness and tangential
  vertical-load descriptions overlap: their sum is an engineering magnitude
  envelope of separate transfer idealizations, NOT a compatible elastic tensor
  satisfying pointwise longitudinal equilibrium everywhere in a flange. It
  cannot by itself close a requirement for actual local stress.
* Lateral shear uses a parabolic rectangular-plate field in EACH flange and
  in the finite web: |tau_xy|=|Vy|*(width²/8-y²/2)/Iy, with width=b or tw.
  This follows from d(tau_xy)/dy=-Vy*y/Iy and zero traction at each plate's
  free side. Integrating both flanges and the web returns Vy exactly for the
  three-rectangle Iy. The web correction tends to zero as tw -> 0. It replaces
  the unsupported Qy/(Iy*h) vertical-cut average previously called a bound.
* Warping shear: |Tw|*|Sw|/(Cw*t), with
  Sw=tf*h0*(b²/4-y²)/4 in a flange and zero in the idealized web.
* Saint-Venant surface bound: |Ts|*t/J, even at a wall-interior sample.
  Source: SCI P385 (2011), 2.1-2.2, pp.8-11. That source explicitly warns of
  local increases at re-entrant corners and the need for separate fatigue study.

The Euclidean shear magnitude is bounded by the sum of the absolute modeled
components (triangle inequality); sqrt(sigma_x²+3*tau_bound²) then bounds the
modeled uniaxial-plus-shear von Mises stress. It does not cover missing transverse
normal stresses or local concentrations. Catalog A/I may be used for normal
stress. For catalog sections, additional symmetric material is bounded without
inventing a fillet radius: if DeltaA=Acatalog-Arect>=0 and the nominal rectangles
are contained in the section, |DeltaQz|<=DeltaA*d/4 and
|DeltaQy|<=DeltaA*b/4. This follows by bounding the positive-half first moment
by (DeltaA/2)*maximum_coordinate. Division by nominal wall thickness is safe
within this model because added fillet material cannot reduce that thickness.
A sqrt(2) factor bounds two unknown perpendicular shear components. These
positive reserves are added to the rectangular-field magnitudes using catalog
inertias. If a positive-area completion is unavailable, the same inequality
using ALL area supplies a broader nominal shear envelope. Neither procedure
claims a 3-D elasticity bound or creates an extra fatigue concentration factor.
A matching nominal-stress fatigue-detail category accounts for the detail's
specified local concentration; do not multiply it by an unrequested hot-spot
factor or compare a 3-D weld peak directly with that nominal category.
"""
from __future__ import annotations
from dataclasses import dataclass
from functools import lru_cache
from types import SimpleNamespace, MappingProxyType
import math
from .autonomous_response import ConcurrentResponse
from .autonomous_model import AutonomousProject

SHEAR_MODEL = 'three_rectangle_Jourawski_and_plate_parabolas_plus_thin_wall_torsion'
TORSION_SOURCE = 'SCI P385 (2011), 2.1-2.2, pp.8-11; Appendix B.2.1'
SHEAR_DERIVATION = 'Equilíbrio longitudinal dM/dx=V; q=VQ/I; campos parabólicos por retângulo; desigualdade triangular.'


@dataclass(frozen=True)
class MaterialPoint:
    id: str
    component: str
    y_mm: float
    z_mm: float
    omega_mm2: float


def _finite(value, name):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        raise ValueError(name + ': número real finito obrigatório.')


def _dimensions(p):
    s = p.section
    if not s.doubly_symmetric:
        raise ValueError('Recuperação setorial limitada a I duplamente simétrico.')
    for key in ('d_mm', 'bf_mm', 'tf_mm', 'tw_mm'):
        _finite(getattr(s, key), key)
        if getattr(s, key) <= 0:
            raise ValueError('Dimensão da seção deve ser positiva.')
    if s.d_mm <= 2*s.tf_mm or s.bf_mm <= s.tw_mm:
        raise ValueError('Geometria do I inválida.')
    return s.d_mm, s.bf_mm, s.tf_mm, s.tw_mm, s.d_mm-2*s.tf_mm, s.d_mm-s.tf_mm


def material_points(p: AutonomousProject):
    """Nominal stress samples including every rectangle corner and wall centre.

    Both flange faces are needed when normal-stress components cancel. Both web
    faces are needed for finite-web minor bending. These points contain extrema
    of the modeled longitudinal normal stress over the section at a GIVEN x.
    They do not necessarily contain the combined von Mises maximum and are not
    a substitute for selecting the actual fatigue/weld detail and hot-spot point.
    Existing outer-flange and web-centre IDs remain stable.
    """
    return _material_points_cached(_dimensions(p))


@lru_cache(maxsize=128)
def _material_points_cached(dimensions):
    # Frozen points and immutable dimension keys cannot become stale when the
    # editable project changes. No response/action data are cached here.
    d, b, tf, tw, h, h0 = dimensions
    result = []
    for flange, sign in (('superior', 1), ('inferior', -1)):
        zc = sign*h0/2
        for face, z in (('', sign*d/2), ('interna_', sign*h/2)):
            for edge, y in (('esquerda', -b/2), ('centro', 0.), ('direita', b/2)):
                result.append(MaterialPoint(flange+'_'+face+edge, 'flange', y, z, y*zc))
    for label, z in (('superior', h/2), ('meio', 0.), ('inferior', -h/2)):
        for suffix, y in (('', 0.), ('_esquerda', -tw/2), ('_direita', tw/2)):
            result.append(MaterialPoint('alma_'+label+suffix, 'web', y, z, 0.))
    return tuple(result)


def _validate_point(point, dimensions):
    d, b, tf, tw, h, h0 = dimensions
    if not isinstance(point, MaterialPoint):
        raise ValueError('Ponto material deve ser MaterialPoint.')
    for key in ('y_mm', 'z_mm', 'omega_mm2'):
        _finite(getattr(point, key), key)
    y, z = point.y_mm, point.z_mm
    if point.component == 'web':
        inside = abs(y) <= tw/2 and abs(z) <= h/2
        omega = 0.0
    elif point.component == 'flange':
        inside = abs(y) <= b/2 and h/2 <= abs(z) <= d/2
        omega = y*math.copysign(h0/2, z)
    else:
        raise ValueError('Componente desconhecido.')
    if not inside:
        raise ValueError('Ponto material fora do componente informado.')
    if not math.isclose(point.omega_mm2, omega, rel_tol=1e-10, abs_tol=1e-10):
        raise ValueError('Coordenada setorial incompatível com o ponto e o modelo de parede fina.')


def _shear_geometry(p, properties):
    dimensions = _dimensions(p)
    for name, value in (("A", properties.A_mm2), ("Ix", properties.Ix_mm4), ("Iy", properties.Iy_mm4)):
        _finite(value, name)
        if value <= 0:
            raise ValueError('Propriedade da seção deve ser positiva: '+name)
    # Return a fresh dict; public qualification metadata must never mutate the
    # immutable shared geometry cache.
    return dict(_shear_geometry_cached(dimensions, p.section.property_basis,
                properties.A_mm2, properties.Ix_mm4, properties.Iy_mm4))


@lru_cache(maxsize=256)
def _shear_geometry_cached(dimensions, property_basis, area_actual, ix_actual, iy_actual):
    d, b, tf, tw, h, h0 = dimensions
    area = 2*b*tf+h*tw
    ix = 2*(b*tf**3/12+b*tf*(h0/2)**2)+tw*h**3/12
    iy = (2*tf*b**3+h*tw**3)/12
    exact_rectangles = all(math.isclose(a, b, rel_tol=1e-9) for a, b in
                           ((area, area_actual), (ix, ix_actual), (iy, iy_actual)))
    delta_area = area_actual-area
    if exact_rectangles:
        mode = 'consistent_three_rectangles'
    elif property_basis == 'catalog' and delta_area > 0:
        mode = 'catalog_positive_area_completion_bound'
    else:
        mode = 'whole_section_first_moment_bound'
    return tuple(dict(mode=mode, rectangle_area_mm2=area, rectangle_ix_mm4=ix,
                rectangle_iy_mm4=iy, extra_area_mm2=max(0.0, delta_area),
                vertical_resultant_ratio=ix/ix_actual,
                horizontal_resultant_ratio=iy/iy_actual).items())


def nominal_shear_components(p: AutonomousProject, properties, point: MaterialPoint,
                             vertical_kn: float, horizontal_kn: float) -> dict:
    """Unsigned force-shear components of the documented nominal section field.

    The flange vertical-through-thickness and tangent terms describe distinct,
    overlapping transfer idealizations. Their positive sum is an engineering
    reserve, not a compatible 3-D stress tensor or a local-stress proof.
    Returned fields have no fatigue sign.
    """
    dimensions = _dimensions(p)
    _validate_point(point, dimensions)
    d, b, tf, tw, h, h0 = dimensions
    for key in ('Ix_mm4', 'Iy_mm4'):
        _finite(getattr(properties, key), key)
        if getattr(properties, key) <= 0:
            raise ValueError('Inércia elástica deve ser positiva.')
    _finite(vertical_kn, 'Vy'); _finite(horizontal_kn, 'Vx')
    return _nominal_shear_prepared(dimensions, properties, point, vertical_kn,
                                    horizontal_kn, _shear_geometry(p, properties))


def _nominal_shear_prepared(dimensions, properties, point, vertical_kn, horizontal_kn, geometry):
    d, b, tf, tw, h, h0 = dimensions
    vv, vh = abs(vertical_kn)*1000, abs(horizontal_kn)*1000
    y, z = point.y_mm, point.z_mm
    if point.component == 'web':
        q = b*tf*h0/2 + tw*(h*h/8-z*z/2)
        vertical_thickness = vv*q/(properties.Ix_mm4*tw)
        vertical_tangent = 0.0
        horizontal = vh*max(0.0, tw*tw/8-y*y/2)/properties.Iy_mm4
    else:
        vertical_thickness = vv*max(0.0, d*d/4-z*z)/(2*properties.Ix_mm4)
        vertical_tangent = vv*(h0/2)*(b/2-abs(y))/properties.Ix_mm4
        horizontal = vh*max(0.0, b*b/8-y*y/2)/properties.Iy_mm4
    wall_t = tw if point.component == 'web' else tf
    reserve_v = reserve_h = 0.0
    if geometry['mode'] == 'catalog_positive_area_completion_bound':
        # For symmetric added material, the positive-half first moments cannot
        # exceed DeltaA*d/4 and DeltaA*b/4. Triangle inequality includes this
        # unknown contribution without pretending an equivalent radius is exact.
        extra = geometry['extra_area_mm2']
        reserve_v = math.sqrt(2)*vv*extra*d/(4*properties.Ix_mm4*wall_t)
        reserve_h = math.sqrt(2)*vh*extra*b/(4*properties.Iy_mm4*wall_t)
    elif geometry['mode'] == 'whole_section_first_moment_bound':
        # Available area does not justify a positive-addition reconstruction.
        # Bound the complete nominal flow using A/2 at its maximum coordinate.
        full_v = math.sqrt(2)*vv*properties.A_mm2*d/(4*properties.Ix_mm4*wall_t)
        full_h = math.sqrt(2)*vh*properties.A_mm2*b/(4*properties.Iy_mm4*wall_t)
        reserve_v = max(0.0, full_v-vertical_thickness-vertical_tangent)
        reserve_h = max(0.0, full_h-horizontal)
    return dict(vertical_bound_mpa=vertical_thickness+vertical_tangent+reserve_v,
                vertical_through_thickness_bound_mpa=vertical_thickness,
                vertical_tangent_bound_mpa=vertical_tangent,
                vertical_unmodeled_area_bound_mpa=reserve_v,
                horizontal_rectangular_field_bound_mpa=horizontal,
                horizontal_unmodeled_area_bound_mpa=reserve_h,
                horizontal_bound_mpa=horizontal+reserve_h)


def _section_model_qualification(p, g, torsion_beam):
    d, b, tf, tw, h, h0 = _dimensions(p)
    rectangle_ix = 2*(b*tf**3/12+b*tf*(h0/2)**2)+tw*h**3/12
    rectangle_iy = (2*tf*b**3+h*tw**3)/12
    expected_j = (2*b*tf**3+h*tw**3)/3
    expected_cw = tf*b**3*h0*h0/24
    for name, value in (('A', g.A_mm2), ('Ix', g.Ix_mm4), ('Iy', g.Iy_mm4),
                        ('J', torsion_beam.J_mm4), ('Cw', torsion_beam.Cw_mm6)):
        _finite(value, name)
        if value <= 0:
            raise ValueError('Propriedade da seção deve ser positiva: '+name)
    torsion_consistent = (math.isclose(expected_j, torsion_beam.J_mm4, rel_tol=1e-9)
                          and math.isclose(expected_cw, torsion_beam.Cw_mm6, rel_tol=1e-9))
    if not torsion_consistent:
        raise ValueError('J/Cw da resposta incompatíveis com a recuperação setorial nominal.')
    geometry = _shear_geometry(p, g)
    return dict(qualified_nominal_shear_model=True,
                shear_geometry=geometry,
                vertical_resultant_ratio=geometry['vertical_resultant_ratio'],
                horizontal_resultant_ratio=geometry['horizontal_resultant_ratio'],
                resultant_ratios_are_before_area_reserve=True,
                compatible_elastic_shear_tensor=False,
                flange_vertical_terms_are_overlapping_transfer_idealizations=True,
                torsion_properties_consistent=torsion_consistent,
                scope='Campo nominal de três retângulos ou seu envelope conservador por primeiros momentos de área; torção de parede fina.',
                assumptions=('Seção bisimétrica dentro do retângulo d por bf e espessuras nominais positivas.',
                             'Na rota de catálogo com área adicional: retângulos nominais contidos na seção, acréscimos simétricos e sem redução da espessura de parede.',
                             'Limite nominal de fluxo de cisalhamento, sem pretensão de limite 3D para a região de introdução de carga.',
                             'As parcelas verticais de mesa somam idealizações de transferência sobrepostas; a reserva não é um tensor elástico compatível nem prova de tensão local.'),
                reason='Área adicional de catálogo limitada analiticamente, sem inferir raio de filete.' if geometry['mode']=='catalog_positive_area_completion_bound' else geometry['mode'])


def _prepare_state(p, r, x_m, side, prepared_state=None, prepared_geometry=None):
    _finite(x_m, 'Posição da seção')
    if side not in ('left', 'right'):
        raise ValueError('Face da seção inválida.')
    geometry_matches = (isinstance(prepared_geometry, _PreparedEnvelopeGeometry)
                        and prepared_geometry.signature == _envelope_geometry_signature(p, r))
    dimensions = prepared_geometry.dimensions if geometry_matches else _dimensions(p)
    g = r.properties
    if prepared_state is None:
        v = r.at(x_m, side)
    else:
        # Internal hot path: caller supplies the exact r.at(x_m, side) already
        # evaluated in its observer. Position/face are checked; the caller owns
        # response identity (case/translation are not present in legacy at()).
        if (not isinstance(prepared_state, dict)
                or prepared_state.get('position_m') != x_m
                or prepared_state.get('side') != side):
            raise ValueError('Estado preparado deve corresponder à mesma posição e face da resposta.')
        v = prepared_state
    beam = r.lateral_torsion.beam
    qualification = prepared_geometry.qualification if geometry_matches else _section_model_qualification(p, g, beam)
    for key in ('N_kn', 'Mx_knm', 'My_knm', 'Vy_kn', 'Vx_kn'):
        _finite(v[key], key)
    for key in ('bimoment_nmm2', 'saint_venant_torque_nmm', 'warping_torque_nmm'):
        _finite(v['torsion'][key], key)
    return dimensions, g, v, beam, qualification


def _recover_prepared(p, r, x_m, point, side, prepared, point_checked=False):
    dimensions, g, v, beam, qualification = prepared
    if not point_checked:
        _validate_point(point, dimensions)
    d, b, tf, tw, h, h0 = dimensions
    torsion = v['torsion']
    axial = v['N_kn']*1000/g.A_mm2
    major = -v['Mx_knm']*1e6*point.z_mm/g.Ix_mm4
    minor = v['My_knm']*1e6*point.y_mm/g.Iy_mm4
    warping = torsion['bimoment_nmm2']*point.omega_mm2/beam.Cw_mm6
    sigma = axial+major+minor+warping
    components = _nominal_shear_prepared(dimensions, g, point, v['Vy_kn'], v['Vx_kn'], qualification['shear_geometry'])
    ts, torque_warp = abs(torsion['saint_venant_torque_nmm']), abs(torsion['warping_torque_nmm'])
    thickness = tw if point.component == 'web' else tf
    if point.component == 'flange':
        sw = tf*h0*(b*b/4-point.y_mm**2)/4
        warp_shear = torque_warp*sw/(beam.Cw_mm6*tf)
    else:
        warp_shear = 0.0
    sv = ts*thickness/beam.J_mm4
    components.update(saint_venant_bound_mpa=sv, warping_bound_mpa=warp_shear)
    shear = components['vertical_bound_mpa']+components['horizontal_bound_mpa']+warp_shear+sv
    # Qualification concerns this explicitly scoped nominal field. It is not
    # a section resistance, local-wheel or fatigue-detail approval.
    return dict(point=dict(id=point.id, component=point.component, y_mm=point.y_mm,
                          z_mm=point.z_mm, omega_mm2=point.omega_mm2),
                x_m=x_m, side=side, sigma_longitudinal_mpa=sigma,
                sigma_components_mpa=dict(axial=axial, major=major, minor=minor, warping=warping),
                shear_magnitude_upper_bound_mpa=shear, shear_components=components,
                von_mises_upper_bound_mpa=math.sqrt(sigma*sigma+3*shear*shear),
                section_model_qualification=qualification,
                shear_is_signed_history=False,
                shear_bound_scope='Limite pela desigualdade triangular somente dos componentes do modelo nominal declarado; não é limite superior 3D/local.',
                von_mises_bound_scope='Somente sigma_x e cisalhamentos modelados; sem tensões normais transversais locais.',
                case=r.case_name, translation_m=r.translation_m,
                local_wheel_effects_included=False,
                fatigue_detail_qualified=False,
                normal_stress_is_nominal=True,
                normal_property_source=p.section.property_source,
                sources=(SHEAR_DERIVATION, TORSION_SOURCE),
                limitations=('Sem tensões locais de roda, solda, filetes, introdução de carga e distorção da seção.',
                             'Reserva de mesa soma idealizações de fluxo sobrepostas; não é tensor elástico compatível para fechar exigência de tensão local real.',
                             'Cisalhamento sem sinal e von Mises limitado não constituem históricos para contagem de fadiga.',
                             'Categorias de fadiga nominal já representam a concentração do detalhe correspondente; não acrescentar fator local sem método compatível.',
                             'A aproximação não resolve efeitos locais adicionais não cobertos pela categoria de detalhe ou pela análise global.',
                             'Os pontos amostrados cobrem extremos da normal nominal, não garantem o extremo da interação equivalente.'),
                basis='Normal longitudinal assinada no mesmo ponto; cisalhamento por três retângulos e torção de parede fina, com qualificação explícita do modelo.')



def recover_point(p: AutonomousProject, r: ConcurrentResponse, x_m: float,
                  point: MaterialPoint, side='right'):
    """Recover one signed material-point normal and unsigned nominal shear bound."""
    return _recover_prepared(p, r, x_m, point, side, _prepare_state(p, r, x_m, side))



_SHEAR_TERMS = ('vertical_through_thickness_bound_mpa', 'vertical_tangent_bound_mpa',
                'vertical_unmodeled_area_bound_mpa', 'horizontal_rectangular_field_bound_mpa',
                'horizontal_unmodeled_area_bound_mpa', 'saint_venant_bound_mpa', 'warping_bound_mpa')


@lru_cache(maxsize=256)
def _envelope_geometry(dimensions, area, ix, iy, shear_geometry):
    """Load-independent extrema selectors for the SAME nominal section field.

    Each unsigned shear term is a nonnegative geometry function multiplied by
    one absolute resultant. Its maximizing material point is load independent,
    including the whole-area reserve (the complement of the rectangle field).
    Cache keys include every property entering that selection; no project or
    action object is retained. Normal extrema still use all original points.
    """
    g=SimpleNamespace(A_mm2=area,Ix_mm4=ix,Iy_mm4=iy)
    geometry=dict(shear_geometry);result=[]
    for component in ('flange','web'):
        points=tuple(q for q in _material_points_cached(dimensions) if q.component==component)
        fields=tuple(_nominal_shear_prepared(dimensions,g,q,1.,1.,geometry) for q in points)
        selected=[]
        for key in _SHEAR_TERMS[:5]:
            i=max(range(len(points)),key=lambda i:fields[i][key])
            if i not in selected:selected.append(i)
        result.append((component,points,tuple(points[i] for i in selected)))
    return tuple(result)



@dataclass(frozen=True)
class _PreparedEnvelopeGeometry:
    signature: tuple
    dimensions: tuple
    qualification: object


def _envelope_geometry_signature(p, r):
    # Include type as well as value: True must not alias a valid dimension 1.
    # The response properties are authoritative for stress recovery. Geometry
    # edits, material-property changes affecting J/Cw, and catalog switches
    # invalidate this internal context without caching any load or response.
    s=p.section;g=r.properties;b=r.lateral_torsion.beam
    values=(s.d_mm,s.bf_mm,s.tf_mm,s.tw_mm,s.bottom_bf_mm,s.bottom_tf_mm,
            s.property_basis,g.A_mm2,g.Ix_mm4,g.Iy_mm4,b.J_mm4,b.Cw_mm6)
    return tuple((type(v),v) for v in values)


def _prepare_envelope_geometry(p, r):
    """Validate one case's immutable geometry; no load-state checks are skipped.

    This is an internal observer optimization, never a user-supplied approval.
    A different signature takes the ordinary validation path. Nested geometry
    metadata is read-only and no returned envelope aliases this context.
    """
    dimensions=_dimensions(p)
    qualification=_section_model_qualification(p,r.properties,r.lateral_torsion.beam)
    qualification['shear_geometry']=MappingProxyType(qualification['shear_geometry'])
    return _PreparedEnvelopeGeometry(_envelope_geometry_signature(p,r),dimensions,
                                     MappingProxyType(qualification))


def _envelope_output(by_component):
    return dict(by_component=by_component,
        sigma_abs_upper_bound_mpa=max(row['sigma_abs_upper_bound_mpa'] for row in by_component.values()),
        shear_magnitude_upper_bound_mpa=max(row['shear_magnitude_upper_bound_mpa'] for row in by_component.values()),
        von_mises_upper_bound_mpa=max(row['von_mises_upper_bound_mpa'] for row in by_component.values()),
        is_signed_history=False, material_point_components_are_simultaneous=False,
        covers_cross_section_coordinates_within_nominal_model=True,
        covers_longitudinal_or_translation_search=False,
        basis='Extremos da normal afim nos cantos de cada retângulo; soma dos máximos não negativos das parcelas de cisalhamento; desigualdade triangular.')


def recover_envelope(p: AutonomousProject, r: ConcurrentResponse, x_m: float, side='right', *, prepared_state=None, prepared_geometry=None):
    """Return exactly recover_section's nominal envelope without point reports.

    This only avoids constructing 21 detailed dictionaries that an envelope
    observer discards. The original material coordinates, action signs, model
    qualification and nonnegative term-wise maxima are retained. It is never a
    signed fatigue history. Geometry selectors are immutable and load-free.
    """
    dimensions,g,v,beam,qualification=_prepare_state(p,r,x_m,side,prepared_state,prepared_geometry)
    d,b,tf,tw,h,h0=dimensions;t=v['torsion'];geometry=qualification['shear_geometry']
    selected=_envelope_geometry(dimensions,g.A_mm2,g.Ix_mm4,g.Iy_mm4,tuple(geometry.items()))
    axial=v['N_kn']*1000/g.A_mm2
    ts=abs(t['saint_venant_torque_nmm']);torque_warp=abs(t['warping_torque_nmm'])
    by_component={}
    for component,points,shear_points in selected:
        normals=tuple(axial-v['Mx_knm']*1e6*q.z_mm/g.Ix_mm4
                      +v['My_knm']*1e6*q.y_mm/g.Iy_mm4
                      +t['bimoment_nmm2']*q.omega_mm2/beam.Cw_mm6 for q in points)
        minimum=min(normals);maximum=max(normals);sigma_bound=max(abs(minimum),abs(maximum))
        fields=tuple(_nominal_shear_prepared(dimensions,g,q,v['Vy_kn'],v['Vx_kn'],geometry) for q in shear_points)
        terms={key:max(row[key] for row in fields) for key in _SHEAR_TERMS[:5]}
        terms['saint_venant_bound_mpa']=ts*(tw if component=='web' else tf)/beam.J_mm4
        # Warping flange flow is maximal at y=0, present on both flange faces.
        sw=tf*h0*(b*b/4)/4
        terms['warping_bound_mpa']=torque_warp*sw/(beam.Cw_mm6*tf) if component=='flange' else 0.
        shear_bound=sum(terms.values())
        by_component[component]=dict(sigma_min_mpa=minimum,sigma_max_mpa=maximum,
            sigma_abs_upper_bound_mpa=sigma_bound,shear_term_maxima_mpa=terms,
            shear_magnitude_upper_bound_mpa=shear_bound,
            von_mises_upper_bound_mpa=math.sqrt(sigma_bound*sigma_bound+3*shear_bound*shear_bound))
    return _envelope_output(by_component)

def recover_section(p: AutonomousProject, r: ConcurrentResponse, x_m: float, side='right', *, prepared_state=None):
    """Recover all material points with one structural response evaluation.

    The additional envelope separately maximizes normal stress and every
    nonnegative shear term WITHIN each component (flanges/web), then combines
    their maxima. The result safely bounds the modeled equivalent stress over
    cross-section coordinates even where the actual von Mises maximum lies
    between sampled points. Its terms are NOT simultaneous material-point
    stresses, and the envelope is NOT a signed fatigue history. It says nothing
    about unsampled longitudinal sections or train positions.

    prepared_state is an internal optimization: it must be the unmodified
    r.at(x_m, side) from this SAME response/case/translation. It avoids a second
    structural evaluation and is never a deserialized or cross-case cache.
    Geometry caches contain only immutable section data, never load states.
    """
    prepared = _prepare_state(p, r, x_m, side, prepared_state)
    points = tuple(_recover_prepared(p, r, x_m, point, side, prepared, point_checked=True)
                   for point in _material_points_cached(prepared[0]))
    shear_terms = ('vertical_through_thickness_bound_mpa', 'vertical_tangent_bound_mpa',
                   'vertical_unmodeled_area_bound_mpa', 'horizontal_rectangular_field_bound_mpa',
                   'horizontal_unmodeled_area_bound_mpa', 'saint_venant_bound_mpa', 'warping_bound_mpa')
    by_component = {}
    for component in ('flange', 'web'):
        rows = tuple(row for row in points if row['point']['component'] == component)
        minimum = min(row['sigma_longitudinal_mpa'] for row in rows)
        maximum = max(row['sigma_longitudinal_mpa'] for row in rows)
        sigma_bound = max(abs(minimum), abs(maximum))
        term_maxima = {key: max(row['shear_components'][key] for row in rows) for key in shear_terms}
        shear_bound = sum(term_maxima.values())
        by_component[component] = dict(sigma_min_mpa=minimum, sigma_max_mpa=maximum,
            sigma_abs_upper_bound_mpa=sigma_bound,
            shear_term_maxima_mpa=term_maxima, shear_magnitude_upper_bound_mpa=shear_bound,
            von_mises_upper_bound_mpa=math.sqrt(sigma_bound*sigma_bound+3*shear_bound*shear_bound))
    envelope = _envelope_output(by_component)
    return dict(points=points, envelope=envelope,
                section_model_qualification=prepared[4], state=prepared[2],
                x_m=x_m, side=side, case=r.case_name, translation_m=r.translation_m)
