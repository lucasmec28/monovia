"""Truthful summary of declared-scope coverage, independent of any calculator.

The caller owns the coverage manifest and its case/segment/point matching. An
empty pending list, an audit record, or a populated alternative-route list is
never evidence of complete coverage here. External responsibilities are retained
for presentation; missing inputs to an in-scope calculation must remain blockers.
"""
from __future__ import annotations

from collections.abc import Iterable, Mapping
import math
from typing import Any


_FAILURE = {'NÃO ATENDE', 'EXCEDE LIMIAR COMPLEMENTAR'}
_INVALID = {'INVALID', 'INVÁLIDO', 'INVALIDO', 'ENTRADA INVÁLIDA', 'DADOS INVÁLIDOS'}
_UNSUPPORTED = {'FORA DO DOMÍNIO', 'FORA DO ESCOPO', 'FORA DO DOMÍNIO DE RESISTÊNCIA'}
_PENDING = {'PENDENTE'}
_EXTERNAL = {'RESPONSABILIDADE EXTERNA'}
_ACCEPTED_NONNUMERIC = {
    'INFORMATIVO', 'CALCULADO', 'VÁLIDO', 'NO DOMÍNIO', 'REGISTRADO',
    'NÃO SOLICITADA', 'NÃO APLICÁVEL NO DOMÍNIO', 'DISPENSADA NO DOMÍNIO',
    'EXCLUSÃO QUALIFICADA NO CASO', 'ATENDE NO DOMÍNIO LOCAL',
}
_NUMERIC_PASS = {'ATENDE', 'ATENDE NO DOMÍNIO'}
_TOLERANCE = 1e-10
_SPECIFIC_ASSESSMENT = 'requires_specific_assessment'


def _get(record: Any, field: str, default=None):
    return record.get(field, default) if isinstance(record, Mapping) else getattr(record, field, default)


def _finite_number(value: Any) -> bool:
    if type(value) not in (int, float):
        return False
    try:
        return math.isfinite(value)
    except (OverflowError, ValueError):
        return False


def _texts(values: Iterable[str] | str) -> list[str]:
    if isinstance(values, str):
        values = (values,)
    return list(dict.fromkeys(str(value).strip() for value in values if str(value).strip()))


def _numerical_comparison(record: Any, status: str) -> tuple[bool, bool, bool]:
    """Return (valid comparison, numerical exceedance, malformed comparison).

    A pass label without its numerical evidence is not enough. Qualified domain
    exclusions and information-only records need not have a utilization index.
    """
    utilization = _get(record, 'utilization')
    attempted = utilization is not None or status in _NUMERIC_PASS
    if not attempted:
        return False, False, False
    demand, capacity = _get(record, 'demand'), _get(record, 'capacity')
    if not all(_finite_number(v) for v in (demand, capacity, utilization)):
        return False, False, True
    if demand < 0 or capacity <= 0 or utilization < 0:
        return False, False, True
    try:
        calculated = demand/capacity
    except (OverflowError, ZeroDivisionError):
        return False, False, True
    if not math.isfinite(calculated) or not math.isclose(utilization, calculated, rel_tol=1e-8, abs_tol=_TOLERANCE):
        return False, False, True
    return True, utilization > 1.+_TOLERANCE or calculated > 1.+_TOLERANCE, False


def summarize_checks(
    checks: Iterable[Any], *, coverage_complete: bool = False,
    coverage_gaps: Iterable[str] = (), external_responsibilities: Iterable[str] = (),
) -> dict[str, Any]:
    """Summarize normalized Check objects/mappings plus an explicit scope manifest.

    Args:
        checks: Existing Check objects or mappings with id/status and, for a
            numerical comparison, finite demand/capacity/utilization values.
            Output-only exceedance_policy='requires_specific_assessment' is
            accepted exclusively for a coherent PENDENTE comparison: exceeding
            that conservative envelope requires assessment, not an inferred
            failure. No title/detail wording is used to infer this policy.
        coverage_complete: Exactly True only after the evaluator has matched all
            required declared cases/segments/points and their selected methods.
        coverage_gaps: Unresolved in-scope coverage requirements from that evaluator.
        external_responsibilities: Named Robot/manufacturer/project obligations
            outside the declared calculation scope. These remain visible and do
            not turn into missing arithmetic. They cannot erase a blocking Check.

    Returns:
        status, summary, effective coverage_complete, counts, categorized check
        IDs, coverage_gaps and external_responsibilities. Failure wins over every
        other status. Otherwise incomplete/invalid/unsupported remains partial.
    """
    groups = {name: [] for name in ('failed', 'invalid', 'unsupported', 'pending')}
    gaps = _texts(coverage_gaps)
    external = _texts(external_responsibilities)
    calculated = passed = 0
    for index, check in enumerate(checks):
        identifier = str(_get(check, 'id') or f'check_{index}')
        raw_status = _get(check, 'status')
        status = raw_status.strip().upper() if isinstance(raw_status, str) else ''
        valid_numeric, exceeded, malformed = _numerical_comparison(check, status)
        policy = _get(check, 'exceedance_policy', '')
        assessment_pending = (policy == _SPECIFIC_ASSESSMENT and type(policy) is str
                              and status == 'PENDENTE' and valid_numeric)
        invalid_policy = type(policy) is not str or (policy != '' and not assessment_pending)
        if valid_numeric and (status in _NUMERIC_PASS | _FAILURE or assessment_pending):
            calculated += 1
        # A declared actual failure is never downgraded, even by malformed or
        # misplaced policy metadata. Unknown policies are invalid, not waivers.
        if status in _FAILURE or (exceeded and type(policy) is str and policy == ''):
            groups['failed'].append(identifier)
        elif valid_numeric and status in _NUMERIC_PASS and not invalid_policy:
            passed += 1
        if malformed or invalid_policy or status in _INVALID or not status:
            groups['invalid'].append(identifier)
        elif status in _UNSUPPORTED:
            groups['unsupported'].append(identifier)
        elif status in _PENDING:
            groups['pending'].append(identifier)
        elif status in _EXTERNAL:
            note = _get(check, 'detail') or _get(check, 'title') or identifier
            external.append(str(note))
        elif status not in _FAILURE | _NUMERIC_PASS | _ACCEPTED_NONNUMERIC:
            # Future/unrecognized statuses must not accidentally make a scope green.
            groups['pending'].append(identifier)
    if type(coverage_complete) is not bool:
        gaps.append('Declaração de cobertura inválida: informar um booleano explícito.')
    gaps, external = _texts(gaps), _texts(external)
    counts = {'calculated': calculated, 'passed': passed,
              **{name: len(ids) for name, ids in groups.items()},
              'coverage_gaps': len(gaps), 'external_responsibilities': len(external)}
    complete = (coverage_complete is True and calculated > 0 and not gaps
                and not any(groups.values()))
    if groups['failed']:
        status = 'NÃO ATENDE NAS VERIFICAÇÕES CALCULADAS'
        summary = f'{counts["failed"]} verificação(ões) calculada(s) excede(m) o limite.'
    elif complete:
        status = 'ATENDE AO ESCOPO DECLARADO'
        summary = (f'Concluídas {calculated} comparação(ões) numérica(s), sem excedências, '
                   'para os casos, pontos, trechos e métodos cobertos pelo escopo declarado.')
    else:
        status = 'RESULTADO PARCIAL'
        summary = (f'{passed} comparação(ões) numérica(s) atendem.' if passed else
                   'Nenhuma comparação numérica válida foi concluída como atendida.')
        if coverage_complete is not True and not gaps:
            summary += ' A cobertura do escopo ainda não foi declarada completa.'
    details = []
    for category, label in (('invalid', 'entrada(s)/resultado(s) inválido(s)'),
                            ('unsupported', 'caso(s) fora do domínio/escopo implementado'),
                            ('pending', 'pendência(s) de cálculo/qualificação'),
                            ('coverage_gaps', 'lacuna(s) na cobertura declarada')):
        if counts[category]:
            details.append(f'{counts[category]} {label}')
    if details:
        summary += ' Restam: '+ '; '.join(details)+'.'
    if external:
        summary += f' Responsabilidades externas: {len(external)} item(ns) listado(s) separadamente.'
    return {'status': status, 'summary': summary, 'coverage_complete': complete,
            'counts': counts, 'check_ids': groups, 'coverage_gaps': gaps,
            'external_responsibilities': external}
