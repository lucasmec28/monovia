"""UI-only detail limits, with separate physical and method provenance.

Never repairs inputs or grants resistance/qualification. An incompatible current
value remains editable and visible; removing a widget bound is intentional, since
Streamlit resets values carried across newly incompatible min/max parameters.
"""
from __future__ import annotations

import math

import streamlit as st

from .autonomous_local_resistance import STIFFENER_SOURCE, WELD_SOURCE, _weld_leg_limits

FULL_HEIGHT_LAYOUTS = {"paired_full_height_uniform", "paired_full_height_supports"}


def _positive_finite(*values):
    return all(isinstance(v, (int, float)) and not isinstance(v, bool)
               and math.isfinite(v) and v > 0 for v in values)


def stiffener_detail_limits(p):
    """Metadata for the existing full-height, paired-bearing-stiffener branch."""
    s = p.section
    applicable = p.stiffener_layout in FULL_HEIGHT_LAYOUTS
    valid_widths = _positive_finite(s.bf_mm, s.bottom_width, s.tw_mm)
    physical_max = (min(s.bf_mm, s.bottom_width) - s.tw_mm) / 2 if valid_widths else None
    min_c = max(s.bf_mm, s.bottom_width) / 3 - s.tw_mm / 2 if valid_widths else None
    min_t = max(max(s.tf_mm, s.bottom_thickness) / 2, p.stiffener_outstand_mm / 16) if _positive_finite(
        s.tf_mm, s.bottom_thickness, p.stiffener_outstand_mm) else None
    return {"applicable": applicable, "physical_max_mm": physical_max,
            "method_min_outstand_mm": min_c, "method_min_thickness_mm": min_t,
            "physical_source": "Geometria das chapas de altura total entre as mesas: c ≤ [min(bf,sup; bf,inf) − tw]/2.",
            "method_source": STIFFENER_SOURCE}


def render_preserving_number(label, value, *, key, minimum=0.0, maximum=None,
                             step=1.0, help=None):
    """Constrain valid new input, never clamp an imported/current invalid input.

    A bound incompatible with the *current* value is omitted before registering
    the widget. The field re-acquires its normal bound after explicit correction.
    No callback writes values and no rounded/suggested value replaces the input.
    """
    current = st.session_state[key] if key in st.session_state else value
    finite = isinstance(current, (int, float)) and not isinstance(current, bool) and math.isfinite(current)
    lower = float(minimum) if minimum is not None else None
    upper = float(maximum) if maximum is not None and math.isfinite(maximum) else None
    if lower is not None and upper is not None and upper < lower:
        upper = None
    below = finite and lower is not None and current < lower
    above = finite and upper is not None and current > upper
    answer = st.number_input(label, min_value=None if below else lower,
        max_value=None if above else upper,
        value=None if key in st.session_state or not finite else float(current),
        step=float(step), format="%.2f", key=key, help=help)
    if below or above:
        direction, bound = ("mínimo", lower) if below else ("máximo", upper)
        st.warning(f"Valor mantido: {current:g} mm; {direction} aplicável ao detalhe atual: {bound:g} mm. "
                   "Revise explicitamente o campo. Nenhum valor importado ou já informado foi ajustado.")
    return math.nan if answer is None else answer


def render_stiffener_conditions(p):
    limits = stiffener_detail_limits(p)
    if not limits["applicable"]:
        st.caption("Limites das chapas de altura total não aplicados: a disposição está sem enrijecedores ou é desconhecida. Isso não qualifica outro modelo de enrijecimento.")
        return
    maximum = limits["physical_max_mm"]
    if maximum is not None and maximum > 0:
        st.caption(f"Limite físico desta geometria: 0 < c ≤ {maximum:g} mm. " + limits["physical_source"])
    else:
        st.warning("Não há intervalo físico positivo determinável para a chapa de altura total com estas mesas/alma. Os valores permanecem visíveis; revise a seção.")
    min_c, min_t = limits["method_min_outstand_mm"], limits["method_min_thickness_mm"]
    if min_c is not None and min_t is not None:
        st.caption(f"Condições do método de apoio/enrijecedor: c ≥ {min_c:g} mm "
            f"[max(bf)/3 − tw/2] e t ≥ {min_t:g} mm [max(tf,max/2; c/16)]. "
            "São condições deste método resistente, não mínimos físicos universais nem aprovação do detalhe. "
            "Fonte do ramo existente: " + limits["method_source"] + ".")
        if p.stiffener_outstand_mm < min_c or p.stiffener_thickness_mm < min_t:
            st.warning("Uma condição dimensional do método de apoio/enrijecedor não foi atendida. "
                "A entrada foi preservada; o cálculo deve registrar a falha ou pendência aplicável, "
                "sem transformar esta condição em bloqueio global da memória de cálculo ou do Word.")


def weld_detail_limits(p, attr):
    """Read the existing weld proposal's bound; zero continues to mean automatic."""
    s = p.section
    specs = {
        "flange_web_weld_min_leg_mm": ("flange_web", (s.tw_mm, s.tf_mm, s.bottom_thickness), s.fabrication != "rolled"),
        "stiffener_flange_weld_min_leg_mm": ("mesa", (p.stiffener_thickness_mm, s.tf_mm, s.bottom_thickness), p.stiffener_layout in FULL_HEIGHT_LAYOUTS),
        "stiffener_web_weld_min_leg_mm": ("alma", (p.stiffener_thickness_mm, s.tw_mm), p.stiffener_layout in FULL_HEIGHT_LAYOUTS),
    }
    connection, dimensions, applicable = specs[attr]
    if not applicable or not _positive_finite(*dimensions):
        return None
    # The existing helper also reads the user's minimum. Invalid input must not
    # make UI metadata fail; its maximum depends only on the thinner plate.
    requested = getattr(p, attr)
    if not isinstance(requested, (int, float)) or isinstance(requested, bool) or not math.isfinite(requested) or requested < 0:
        return None
    return _weld_leg_limits(p, connection, min(dimensions))


def render_weld_minimum(p, attr, label, *, key):
    limits = weld_detail_limits(p, attr)
    maximum = limits["maximum_leg_mm"] if limits else None
    value = render_preserving_number(label, getattr(p, attr), key=key, maximum=maximum, step=.5,
        help="Perna do filete, não garganta. Zero mantém a proposta automática. O máximo pertence ao detalhe de filete adotado, não a todos os tipos de ligação. Valores anteriores incompatíveis permanecem visíveis para revisão explícita.")
    if limits:
        st.caption(f"0 = automático; máximo do detalhe adotado = {maximum:g} mm; "
                   f"mínimo normativo da proposta = {limits['normative_minimum_leg_mm']:g} mm. "
                   "O mínimo informado não substitui a verificação resistente.")
    return value


WELD_LIMIT_SOURCE = WELD_SOURCE


def projection_footprint_limits(p):
    """Necessary coverage geometry only; not local-model qualification or a solve."""
    s, r = p.section, p.rail
    if (p.wheel_travel_scope != "between_support_axes" or r.local_attachment != "non_rigid"
            or r.continuity != "continuous_no_joint" or p.support_contact != "centered_under_web"
            or not isinstance(r.offset_from_web_mm, (int, float))
            or not math.isfinite(r.offset_from_web_mm) or abs(r.offset_from_web_mm) > 1e-9
            or not _positive_finite(r.width_mm, r.height_mm, r.inertia_cm4, s.tf_mm,
                s.bf_mm, s.bottom_width, s.bottom_thickness, s.d_mm, s.tw_mm,
                p.span_m, p.support_bearing_length_mm)
            or s.tw_mm >= min(s.bf_mm, s.bottom_width)
            or s.d_mm <= s.tf_mm + s.bottom_thickness
            or r.width_mm > s.bf_mm):
        return None
    try:
        bef = min(r.width_mm + r.height_mm + s.tf_mm, s.bf_mm)
        lef = 3.25 * ((r.inertia_cm4 * 10000 + bef * s.tf_mm ** 3 / 12) / s.tw_mm) ** (1 / 3)
    except (OverflowError, ValueError):
        return None
    if not math.isfinite(lef):
        return None
    return {"wheel_half_footprint_mm": lef / 2,
            "support_half_footprint_mm": p.support_bearing_length_mm / 2,
            "source": "ABNT NBR 10084:2020, 9.1.3.1, Tabela 1(b), Figuras 1–3"}


def render_projection_coverage_hint(p):
    limits = projection_footprint_limits(p)
    if limits is None:
        return
    wheel = limits["wheel_half_footprint_mm"]
    support = limits["support_half_footprint_mm"]
    st.caption(f"Domínio de cobertura local, sem correção de borda: para rodas até os eixos dos apoios, "
        f"a meia pegada da roda é lef/2 = {wheel:.3f} mm; a meia pegada do apoio é {support:.3f} mm. "
        "lef = 3,25 [(Ir + bef·tf³/12)/tw]^(1/3), bef = min(br + hr + tf; bf). "
        "Estes valores são requisitos de cobertura do modelo local atual, não mínimos físicos ou normativos universais. "
        "Fonte: " + limits["source"] + ".")
    needed = max(wheel, support)
    short = [name for name, value in (("A", p.beam_end_left_mm), ("B", p.beam_end_right_mm))
             if isinstance(value, (int, float)) and math.isfinite(value) and value < needed]
    if short:
        st.warning("Projeção nos apoios " + ", ".join(short) + " menor que a cobertura exigida pelo modelo local atual. "
            "Entrada e trecho de passagem preservados; a pegada cortada deve ficar como pendência do modelo, "
            "sem presumir uma correção de borda ou impossibilidade física da dimensão.")
