"""Modelo de dados rastreável. Unidades de entrada constam de cada nome.

O motor recebe esforços concomitantes ELU prontos: não combina nem majora ações.
"""
from __future__ import annotations
from dataclasses import dataclass, field, asdict, fields
from typing import Any, get_type_hints, get_origin, get_args
import json
import math

SCHEMA_VERSION = 1

@dataclass
class Material:
    fy_mpa: float = 345.0
    fu_mpa: float = 450.0
    E_mpa: float = 200000.0
    G_mpa: float = 77000.0
    gamma_a1: float = 1.10
    specification: str = "Aço informado pelo responsável; confirmar certificado"

@dataclass
class Section:
    name: str = "I soldado 400 x 200 x 8 x 12"
    fabrication: str = "welded"
    d_mm: float = 400.0
    bf_mm: float = 200.0
    tw_mm: float = 8.0
    tf_mm: float = 12.0
    root_radius_mm: float = 0.0
    property_basis: str = "rectangles"
    property_source: str = "A/I/W/Z por três retângulos; J e Cw aproximados de parede fina; sem raios ou soldas"
    catalog: dict[str, float] = field(default_factory=dict)
    catalog_id: str = ""
    bottom_bf_mm: float = 0.0  # zero: igual à mesa superior (compatibilidade v1)
    bottom_tf_mm: float = 0.0

    @property
    def bottom_width(self): return self.bottom_bf_mm or self.bf_mm

    @property
    def bottom_thickness(self): return self.bottom_tf_mm or self.tf_mm

    @property
    def doubly_symmetric(self):
        return math.isclose(self.bf_mm,self.bottom_width,rel_tol=1e-10) and math.isclose(self.tf_mm,self.bottom_thickness,rel_tol=1e-10)

@dataclass
class Segment:
    name: str = "T1"
    start_m: float = 0.0
    end_m: float = 6.0
    top_lb_m: float = 6.0
    bottom_lb_m: float = 6.0
    cb_top: float = 1.0
    cb_bottom: float = 1.0
    brace_stiffness_verified: bool = False
    torsion_rotation_restrained_at_ends: bool = False
    load_application_qualified: bool = False
    stability_basis: str = ""
    top_restraint: str = "Apenas nos apoios"
    bottom_restraint: str = "Apenas nos apoios"
    note: str = "Confirmar vínculos e aplicação das cargas do modelo global"

@dataclass
class ULSCase:
    name: str = "ELU 01"
    segment: str = "T1"
    position_m: float = 3.0
    N_kn: float = 0.0
    Mx_knm: float = 65.0
    My_knm: float = 0.0
    Vy_kn: float = 45.0
    Vx_kn: float = 0.0
    T_knm: float = 0.0

@dataclass
class ServiceCase:
    name: str = "ELS 01"
    vertical_mm: float = 6.0
    horizontal_mm: float = 2.0
    span_m: float = 6.0
    vertical_ratio: float = 600.0
    horizontal_ratio: float = 400.0
    criterion_source: str = "Critério informado pelo projetista; confirmar norma ou especificação contratual"
    combination_source: str = "Robot: combinação de serviço a identificar"
    criterion_kind: str = "custom"
    vertical_impact_excluded: bool = False

@dataclass
class WheelCase:
    name: str = "Roda 01"
    service_load_kn: float = 20.0
    basis: str = "service_dynamic_included"
    dynamic_basis: str = "Confirmar coeficiente dinâmico já incluído na carga desta roda"
    contact_length_mm: float = 30.0
    contact_width_mm: float = 20.0
    eccentricity_mm: float = 0.0
    horizontal_force_kn: float = 0.0
    horizontal_lever_mm: float = 0.0
    wheel_spacing_mm: float = 500.0
    rail_height_mm: float = 0.0
    rail_width_mm: float = 0.0
    notes: str = "Carga por roda, não capacidade total da talha ou da ponte"

@dataclass
class Patch8800Qualification:
    """External qualification of one local-web ELU case; no automatic credit."""
    case_name: str = ""
    normal_elu_confirmed: bool = False
    supplement_selection_source: str = ""
    component_method_scope_source: str = ""
    component_checks_method_selected: bool = False
    bearing_model: str = "unqualified"
    bearing_at_flange_not_web_lef_confirmed: bool = False
    nearest_end_distance_confirmed: bool = False
    lateral_length_source: str = ""
    restraint_detail_source: str = ""
    support_end_condition: str = "unqualified"
    support_end_source: str = ""
    flange_web_transfer_source: str = ""
    opposed_pair_force_source: str = ""
    stiffener_credit: str = "none"
    first_yield_basis: str = "conservative_16E"
    major_axis_first_yield_confirmed: bool = False
    first_yield_source: str = ""
    inputs_current_confirmed: bool = False
    qualified_input_signature: str = ""

    @classmethod
    def from_dict(cls, raw: dict[str, Any]) -> "Patch8800Qualification":
        if not isinstance(raw, dict):
            raise ValueError("Qualificação local deve ser um objeto.")
        unknown = set(raw) - {f.name for f in fields(cls)}
        if unknown:
            raise ValueError("Campos de qualificação desconhecidos: " + ", ".join(sorted(map(str, unknown))))
        return cls(**raw)


@dataclass
class RunwayLocalCase:
    name: str = "Roda ELU 01"
    segment: str = "T1"
    uls_load_kn: float = 50.0
    basis: str = "robot_elu"
    action_source: str = ""
    bearing_length_mm: float = 100.0
    bearing_source: str = ""
    distance_to_end_mm: float = 1000.0
    weld_leg_parallel_web_mm: float = 0.0
    concomitant_Mx_knm: float = 0.0
    load_centered_on_web: bool = False
    load_on_top_compression: bool = False
    flange_web_transfer_verified: bool = False
    relative_lateral_displacement_prevented: bool = False
    loaded_flange_rotation_restrained: bool = False
    restraint_state_confirmed: bool = False
    opposed_compression_pair: bool = False
    opposed_pair_status_confirmed: bool = False
    no_overlapping_bearing_zones: bool = False
    notes: str = "Sem crédito automático de dispersão do trilho ou de enrijecedores"
    patch_qualification: Patch8800Qualification = field(default_factory=Patch8800Qualification)

@dataclass
class MonorailLocalCase:
    name: str = "Roda local monovia 01"
    service_load_kn: float = 3.6
    load_basis: str = "service_dynamic_included"
    load_source: str = ""
    b_mm: float = 23.95
    longitudinal_service_stress_mpa: float = 100.0
    longitudinal_stress_source: str = ""
    same_outstand_spacing_mm: float = 500.0
    distance_to_end_mm: float = 1000.0
    straight_parallel_flange: bool = False
    fixed_flange_root: bool = False
    no_relevant_shear_or_torsion: bool = False
    wheel_loads_isolated: bool = False
    notes: str = "Método elástico complementar de Dowswell 2013; sem coeficiente de resistência ABNT"

@dataclass
class FatigueBlock:
    name: str = "Bloco 01"
    cycles: int = 100000
    stress_min_mpa: float = 0.0
    stress_max_mpa: float = 50.0
    detail: str = "Detalhe e categoria ainda não selecionados"
    basis: str = "service_stress_range"
    category: str = "C"
    detail_reference: str = ""
    cycle_source: str = ""
    stress_source: str = ""
    constant_amplitude: bool = False
    same_point_confirmed: bool = False
    fatigue_combination_confirmed: bool = False
    fabrication_requirements_confirmed: bool = False
    corrosion_protected: bool = False
    temperature_c: float = 20.0

@dataclass
class ActionReview:
    criterion_document: str = ""
    manufacturer_load_sheet: str = ""
    service_group_source: str = ""
    temperature_status: str = "pending"
    temperature_basis: str = ""
    wheel_positions_confirmed: bool = False
    horizontal_actions_confirmed: bool = False
    dynamic_factors_confirmed: bool = False
    torsion_warping_confirmed: bool = False
    notes: str = ""

@dataclass
class Project:
    schema_version: int = SCHEMA_VERSION
    project: str = "Exemplo didático de viga suporte"
    member: str = "VR 01"
    responsible: str = ""
    mode: str = "runway"
    span_m: float = 6.0
    robot_model: str = ""
    action_basis: str = "robot_elu"
    simultaneous_actions_confirmed: bool = False
    sign_convention_confirmed: bool = False
    supplement_global_8800: bool = True
    supplement_service_8800: bool = True
    supplement_fatigue_8800: bool = True
    supplement_selection_source: str = ""
    normative_context: str = ""
    normative_inputs: dict[str, Any] = field(default_factory=lambda: {"stress_8400":[],"fatigue_8400":[],"local_10084":[],"service_10084":[],"web_panel_8400":[],"continuous_restraint_8400":[],"flt_8400":[],"flange_outstand_8400":[],"runway_torsion_8400":[]})
    coverage_inputs: dict[str, Any] = field(default_factory=lambda: {"local_stress":[],"service_external":[],"scope":{"evidence_source":"","confirmed":False,"input_signature":""}})
    actions_review: ActionReview = field(default_factory=ActionReview)
    material: Material = field(default_factory=Material)
    section: Section = field(default_factory=Section)
    segments: list[Segment] = field(default_factory=lambda: [Segment()])
    uls: list[ULSCase] = field(default_factory=lambda: [ULSCase()])
    service: list[ServiceCase] = field(default_factory=lambda: [ServiceCase()])
    wheels: list[WheelCase] = field(default_factory=list)
    monorail_local: list[MonorailLocalCase] = field(default_factory=list)
    runway_local: list[RunwayLocalCase] = field(default_factory=list)
    fatigue: list[FatigueBlock] = field(default_factory=list)
    notes: str = "Exemplo de uso. Não representa uma viga de obra aprovada."

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), ensure_ascii=False, indent=2, allow_nan=False)

    @classmethod
    def from_dict(cls, raw: dict) -> "Project":
        if not isinstance(raw, dict):
            raise ValueError("O projeto JSON deve ser um objeto.")
        raw=dict(raw)
        raw.setdefault("actions_review",asdict(ActionReview()))
        for field_name in ("supplement_global_8800", "supplement_service_8800", "supplement_fatigue_8800"):
            raw.setdefault(field_name, True)
        raw.setdefault("supplement_selection_source", "")
        raw.setdefault("normative_context", "")
        raw.setdefault("coverage_inputs", {"local_stress":[],"service_external":[],"scope":{"evidence_source":"","confirmed":False,"input_signature":""}})
        raw.setdefault("normative_inputs", {"stress_8400":[],"fatigue_8400":[],"local_10084":[],"service_10084":[],"web_panel_8400":[],"continuous_restraint_8400":[],"flt_8400":[],"flange_outstand_8400":[],"runway_torsion_8400":[]})
        if isinstance(raw["normative_inputs"],dict):
            raw["normative_inputs"].setdefault("service_10084",[])
            raw["normative_inputs"].setdefault("web_panel_8400",[])
            raw["normative_inputs"].setdefault("continuous_restraint_8400",[])
            raw["normative_inputs"].setdefault("flt_8400",[])
            raw["normative_inputs"].setdefault("flange_outstand_8400",[])
            raw["normative_inputs"].setdefault("runway_torsion_8400",[])
            if isinstance(raw["normative_inputs"].get("local_10084"),list):
                for row in raw["normative_inputs"]["local_10084"]:
                    if isinstance(row,dict):
                        row.setdefault("multiwheel_envelope_method", "")
                        row.setdefault("multiwheel_model_qualified", False)
                        row.setdefault("multiwheel_model_source", "")
            if isinstance(raw["normative_inputs"].get("fatigue_8400"),list):
                for row in raw["normative_inputs"]["fatigue_8400"]:
                    if isinstance(row,dict):
                        row.setdefault("positive_kappa_route", "unqualified")
                        row.setdefault("conservative_envelope_selected", False)
            if isinstance(raw["normative_inputs"].get("flt_8400"),list):
                for row in raw["normative_inputs"]["flt_8400"]:
                    if isinstance(row,dict):
                        row.setdefault("resistance_route","bounded_elastic")
                        row.setdefault("omega_method_source","")
                        row.setdefault("omega_curve_method_qualified",False)
                        for field_name in ("W_minor_mm3", "bimoment_knm2"):
                            row.setdefault(field_name, 0.0)
                        for field_name in ("biaxial_method_source", "torsion_warping_source", "major_pattern_id", "minor_pattern_id", "critical_pattern_id"):
                            row.setdefault(field_name, "")
                        for field_name in ("biaxial_method_qualified", "same_pattern_segment_envelope_confirmed", "no_torsion_warping_load_path_confirmed", "minor_axis_compactness_confirmed"):
                            row.setdefault(field_name, False)
        required = {f.name for f in fields(cls)}
        missing = required - set(raw)
        if missing:
            raise ValueError(f"Campos obrigatórios ausentes: {', '.join(sorted(missing))}")
        unknown = set(raw) - required
        if unknown:
            raise ValueError(f"Campos desconhecidos no projeto: {', '.join(sorted(unknown))}")
        if raw.get("schema_version") != SCHEMA_VERSION:
            raise ValueError("Versão do projeto não suportada. Esperada schema_version=1.")
        data = dict(raw)
        for key, typ in (("material", Material), ("section", Section), ("actions_review", ActionReview)):
            if key not in data or not isinstance(data[key], dict):
                raise ValueError(f"Bloco obrigatório ausente/inválido: {key}")
            data[key] = _strict_dataclass(typ, data[key])
        for key, typ in (("segments", Segment), ("uls", ULSCase), ("service", ServiceCase), ("wheels", WheelCase), ("fatigue", FatigueBlock), ("runway_local", RunwayLocalCase), ("monorail_local", MonorailLocalCase)):
            if key not in data or not isinstance(data[key], list):
                raise ValueError(f"Lista obrigatória ausente/inválida: {key}")
            data[key] = [_strict_dataclass(typ, x) for x in data[key]]
        project = cls(**data)
        errors = validate(project)
        if errors:
            raise ValueError("\n".join(errors))
        return project

    @classmethod
    def from_json(cls, text: str | bytes) -> "Project":
        if len(text) > 5_000_000:
            raise ValueError("Projeto maior que 5 MB não aceito.")
        return cls.from_dict(json.loads(text, parse_constant=lambda x: (_ for _ in ()).throw(ValueError(f"Número inválido: {x}"))))


def _strict_dataclass(typ, raw):
    if not isinstance(raw, dict):
        raise ValueError(f"{typ.__name__}: objeto inválido")
    if typ is Section:
        raw = dict(raw)
        raw.setdefault("catalog_id", "")
        raw.setdefault("bottom_bf_mm", 0.0)
        raw.setdefault("bottom_tf_mm", 0.0)
    if typ is RunwayLocalCase:
        raw = dict(raw)
        raw["patch_qualification"] = Patch8800Qualification.from_dict(raw.get("patch_qualification", {}))
    allowed = {f.name for f in fields(typ)}
    unknown = set(raw) - allowed
    missing = allowed - set(raw)
    if unknown or missing:
        raise ValueError(f"{typ.__name__}: campos desconhecidos={sorted(unknown)}; ausentes={sorted(missing)}")
    return typ(**raw)


def finite_number(value: Any) -> bool:
    if not isinstance(value, (float, int)) or isinstance(value, bool):
        return False
    try:
        return math.isfinite(value)
    except (OverflowError, ValueError):
        return False


def validate(p: Project) -> list[str]:
    errors: list[str] = []
    # Check types before numerical comparisons or .strip() calls. JSON and editable
    # tables are untrusted input; malformed values produce diagnostics, not crashes.
    def type_errors(obj, expected, path):
        if not isinstance(obj, expected):
            errors.append(f"{path}: bloco {expected.__name__} obrigatório.")
            return
        for name, annotation in get_type_hints(expected).items():
            value = getattr(obj, name)
            label = f"{path}.{name}"
            origin = get_origin(annotation)
            if annotation is str and not isinstance(value, str):
                errors.append(f"{label}: texto obrigatório.")
            elif annotation is bool and type(value) is not bool:
                errors.append(f"{label}: valor booleano obrigatório.")
            elif annotation is int and type(value) is not int:
                errors.append(f"{label}: inteiro obrigatório.")
            elif annotation is float:
                if not finite_number(value):
                    errors.append(f"{label}: número finito obrigatório.")
                elif abs(value)>1e60 or (value != 0 and abs(value)<1e-60):
                    errors.append(f"{label}: magnitude fora da faixa computacional; confira unidades.")
            elif origin is list:
                if not isinstance(value, list):
                    errors.append(f"{label}: lista obrigatória.")
                elif len(value) > 10000:
                    errors.append(f"{label}: máximo de 10000 registros.")
                else:
                    for i, item in enumerate(value):
                        type_errors(item, get_args(annotation)[0], f"{label}[{i}]")
            elif origin is dict and not isinstance(value, dict):
                errors.append(f"{label}: objeto obrigatório.")
            elif isinstance(annotation, type) and hasattr(annotation, '__dataclass_fields__'):
                type_errors(value, annotation, label)
    type_errors(p, Project, 'Projeto')
    if errors:
        return errors
    def positive(x, name, zero=False):
        if not finite_number(x) or x < 0 or (x == 0 and not zero):
            errors.append(f"{name}: informar número finito {'não negativo' if zero else 'positivo'}.")
    def numeric_fields(obj, names):
        for name in names:
            if not finite_number(getattr(obj, name)):
                errors.append(f"{obj.__class__.__name__}.{name}: número finito obrigatório.")
    if p.schema_version != SCHEMA_VERSION:
        errors.append("Versão do esquema incompatível.")
    if p.mode not in ("runway", "monorail"):
        errors.append("Modalidade desconhecida.")
    if p.action_basis != "robot_elu":
        errors.append("Somente esforços ELU já combinados do Robot são aceitos neste motor. Não aplicar novos fatores.")
    for key in ("simultaneous_actions_confirmed", "sign_convention_confirmed"):
        if type(getattr(p, key)) is not bool:
            errors.append(f"{key}: valor booleano obrigatório.")
    from .normative import input_errors
    errors.extend(input_errors(p.normative_inputs))
    from .coverage_10084 import coverage_input_errors
    errors.extend(coverage_input_errors(p.coverage_inputs))
    if not isinstance(p.normative_context,str):errors.append("Contexto normativo inválido.")
    if p.actions_review.temperature_status not in ("pending","included","not_applicable"):
        errors.append("Situação da temperatura inválida.")
    positive(p.span_m, "Vão (m)")
    s, m = p.section, p.material
    for key in ("d_mm", "bf_mm", "tw_mm", "tf_mm"):
        positive(getattr(s, key), key)
    positive(s.root_radius_mm, "Raio de concordância", True)
    positive(s.bottom_bf_mm, "Largura da mesa inferior", True)
    positive(s.bottom_tf_mm, "Espessura da mesa inferior", True)
    for key in ("fy_mpa", "fu_mpa", "E_mpa", "G_mpa", "gamma_a1"):
        positive(getattr(m, key), key)
    if errors:
        return errors
    if m.fu_mpa < m.fy_mpa:
        errors.append("fu não pode ser menor que fy.")
    if not (190000 <= m.E_mpa <= 210000 and 70000 <= m.G_mpa <= 85000):
        errors.append("E/G fora da faixa de aço estrutural qualificada neste motor (E 190–210 GPa; G 70–85 GPa).")
    if not (100 <= m.fy_mpa <= 450):
        errors.append("fy fora do domínio implementado de 100 a 450 MPa.")
    if not math.isclose(m.gamma_a1, 1.10, rel_tol=0, abs_tol=1e-12):
        errors.append("Esta versão cobre ELU normal com gamma_a1=1,10. Outra combinação requer qualificação específica.")
    if s.d_mm <= s.tf_mm+s.bottom_thickness + 2*s.root_radius_mm or min(s.bf_mm,s.bottom_width) <= s.tw_mm + 2*s.root_radius_mm:
        errors.append("Seção incompatível: alma livre e abas devem ter dimensões positivas.")
    if s.fabrication == "welded" and s.root_radius_mm != 0:
        errors.append("Perfil soldado não admite raio de concordância de laminado; h é a distância entre faces internas das mesas.")
    if s.fabrication not in ("welded", "rolled"):
        errors.append("Somente I duplamente simétrico soldado ou laminado é aceito.")
    if s.property_basis not in ("rectangles", "catalog"):
        errors.append("Base de propriedades desconhecida.")
    if s.property_basis == "rectangles" and (s.fabrication != "welded" or s.root_radius_mm != 0):
        errors.append("A base de três retângulos com J/Cw aproximados é aceita apenas para I soldado sem raio. Para laminado, usar propriedades de catálogo rastreável.")
    if s.catalog_id:
        from .catalog import section_from_profile
        try:
            original=section_from_profile(s.catalog_id)
            if asdict(s)!=asdict(original):
                errors.append("Perfil vinculado ao catálogo foi alterado. Reaplique o catálogo ou converta explicitamente em seção manual.")
        except ValueError:
            errors.append("Identificador de catálogo não reconhecido.")
    if not s.doubly_symmetric and (s.fabrication != "welded" or s.property_basis != "rectangles"):
        errors.append("Mesas diferentes: somente geometria soldada por retângulos é aceita nesta versão.")
    if s.property_basis == "catalog":
        required = {"A_mm2", "Ix_mm4", "Iy_mm4", "Wx_mm3", "Wy_mm3", "Zx_mm3", "Zy_mm3", "J_mm4", "Cw_mm6"}
        if not isinstance(s.catalog, dict) or set(s.catalog) != required:
            errors.append("Catálogo deve conter exatamente A, Ix, Iy, Wx, Wy, Zx, Zy, J e Cw nas unidades indicadas.")
        else:
            for name, val in s.catalog.items():
                positive(val, name)
            if all(finite_number(v) and v > 0 for v in s.catalog.values()):
                for W, I, h in (("Wx_mm3", "Ix_mm4", s.d_mm), ("Wy_mm3", "Iy_mm4", s.bf_mm)):
                    if not math.isclose(s.catalog[W], 2*s.catalog[I]/h, rel_tol=0.025):
                        errors.append(f"Catálogo inconsistente: {W} difere de 2I/dimensão em mais de 2,5%. Confira unidades cm³→mm³ e cm⁴→mm⁴.")
                if s.catalog["Zx_mm3"] < s.catalog["Wx_mm3"] or s.catalog["Zy_mm3"] < s.catalog["Wy_mm3"]:
                    errors.append("Módulo plástico não pode ser inferior ao elástico na seção simétrica.")
        if not isinstance(s.property_source, str) or len(s.property_source.strip()) < 8:
            errors.append("Identifique a fonte das propriedades de catálogo.")
    if not errors:
        # Protect previews as well as the calculation against numerical overflow.
        try:
            from .geometry import section_properties
            values=section_properties(s).to_dict()
            if any(not finite_number(v) or v<=0 for v in values.values()):
                errors.append("Propriedades não representáveis numericamente; confira dimensões, catálogo e unidades.")
        except (OverflowError,ZeroDivisionError,ValueError):
            errors.append("Geometria fora da faixa computacional; confira dimensões, catálogo e unidades.")
    if not p.segments:
        errors.append("Cadastrar ao menos um trecho de travamento.")
    names = [x.name for x in p.segments]
    if len(set(names)) != len(names) or any(not isinstance(n, str) or not n.strip() for n in names):
        errors.append("Os trechos devem ter nomes únicos não vazios.")
    for seg in p.segments:
        for key in ("start_m", "end_m", "top_lb_m", "bottom_lb_m", "cb_top", "cb_bottom"):
            positive(getattr(seg, key), f"{seg.name}: {key}", key=="start_m")
        for key in ("brace_stiffness_verified", "torsion_rotation_restrained_at_ends", "load_application_qualified"):
            if type(getattr(seg, key)) is not bool:
                errors.append(f"{seg.name}: {key} deve ser booleano.")
        if seg.load_application_qualified and not str(seg.stability_basis).strip():
            errors.append(f"{seg.name}: registrar a origem do Cb e o tratamento da altura da carga.")
        if all(finite_number(getattr(seg, k)) for k in ("start_m", "end_m", "top_lb_m", "bottom_lb_m", "cb_top", "cb_bottom")):
            if seg.start_m >= seg.end_m or seg.end_m > p.span_m + 1e-9:
                errors.append(f"{seg.name}: intervalo do trecho inválido ou fora do vão.")
            if seg.top_lb_m > p.span_m or seg.bottom_lb_m > p.span_m:
                errors.append(f"{seg.name}: Lb maior que o vão. Modelar o comprimento efetivo real antes de usar este domínio.")
            if seg.cb_top <= 0 or seg.cb_bottom <= 0:
                errors.append(f"{seg.name}: Cb deve ser positivo e possuir origem qualificada.")
    if not errors:
        ordered = sorted(p.segments, key=lambda x:x.start_m)
        if abs(ordered[0].start_m) > 1e-8 or abs(ordered[-1].end_m-p.span_m)>1e-8:
            errors.append("Os trechos devem cobrir o vão integral, começando em 0.")
        for left, right in zip(ordered, ordered[1:]):
            if abs(left.end_m-right.start_m) > 1e-8:
                errors.append("Trechos sobrepostos ou com lacuna. Use intervalos contíguos.")
    if not p.uls:
        errors.append("Cadastrar ao menos uma linha de esforços ELU concomitantes.")
    if len(p.uls) > 10000:
        errors.append("Máximo de 10000 linhas ELU por projeto.")
    for c in p.uls:
        numeric_fields(c, ("position_m", "N_kn", "Mx_knm", "My_knm", "Vx_kn", "Vy_kn", "T_knm"))
        if c.segment not in names:
            errors.append(f"{c.name}: trecho {c.segment} não cadastrado.")
        elif finite_number(c.position_m):
            seg = p.segments[names.index(c.segment)]
            if all(finite_number(v) for v in (seg.start_m, seg.end_m)) and not (seg.start_m-1e-8 <= c.position_m <= seg.end_m+1e-8):
                errors.append(f"{c.name}: posição fora do trecho informado.")
    for c in p.service:
        numeric_fields(c, ("vertical_mm", "horizontal_mm"))
        for key in ("span_m", "vertical_ratio", "horizontal_ratio"):
            positive(getattr(c, key), f"{c.name}: {key}")
        if c.criterion_kind not in ("custom", "runway_light", "runway_moderate", "runway_heavy", "runway_severe"):
            errors.append(f"{c.name}: tipo de critério ELS desconhecido.")
        if type(c.vertical_impact_excluded) is not bool:
            errors.append(f"{c.name}: declaração de impacto deve ser booleana.")
        if not c.criterion_source.strip() or not c.combination_source.strip():
            errors.append(f"{c.name}: identifique critério ELS e origem da combinação.")
    for w in p.wheels:
        for key in ("service_load_kn", "contact_length_mm", "contact_width_mm", "wheel_spacing_mm"):
            positive(getattr(w, key), f"{w.name}: {key}")
        for key in ("rail_height_mm", "rail_width_mm"):
            positive(getattr(w, key), f"{w.name}: {key}", True)
        numeric_fields(w, ("eccentricity_mm", "horizontal_force_kn", "horizontal_lever_mm"))
        if w.basis not in ("service_dynamic_included", "service_static"):
            errors.append(f"{w.name}: não inserir carga ELU no bloco de rodas de serviço.")
    for q in p.monorail_local:
        for field in ("service_load_kn", "b_mm", "same_outstand_spacing_mm", "distance_to_end_mm"):
            positive(getattr(q,field),f"{q.name}: {field}")
        numeric_fields(q,("longitudinal_service_stress_mpa",))
        if q.load_basis != "service_dynamic_included":
            errors.append(f"{q.name}: a avaliação elástica local exige carga de serviço com tratamento dinâmico declarado, não ELU.")
        for field in ("straight_parallel_flange", "fixed_flange_root", "no_relevant_shear_or_torsion", "wheel_loads_isolated"):
            if type(getattr(q,field)) is not bool:
                errors.append(f"{q.name}: {field} deve ser booleano.")
    for q in p.runway_local:
        for field in ("uls_load_kn", "bearing_length_mm"):
            positive(getattr(q, field), f"{q.name}: {field}")
        for field in ("distance_to_end_mm", "weld_leg_parallel_web_mm"):
            positive(getattr(q, field), f"{q.name}: {field}", True)
        numeric_fields(q, ("concomitant_Mx_knm",))
        if q.segment not in names:
            errors.append(f"{q.name}: trecho local não cadastrado.")
        if q.basis != "robot_elu":
            errors.append(f"{q.name}: efeitos locais NBR 8800 exigem força ELU já combinada, independente do cadastro de serviço.")
        for field in ("load_centered_on_web", "load_on_top_compression", "flange_web_transfer_verified", "relative_lateral_displacement_prevented", "loaded_flange_rotation_restrained", "restraint_state_confirmed", "opposed_compression_pair", "opposed_pair_status_confirmed", "no_overlapping_bearing_zones"):
            if type(getattr(q, field)) is not bool:
                errors.append(f"{q.name}: {field} deve ser booleano.")
    for f in p.fatigue:
        if type(f.cycles) is not int or f.cycles <= 0:
            errors.append(f"{f.name}: ciclos deve ser inteiro positivo.")
        numeric_fields(f, ("stress_min_mpa", "stress_max_mpa"))
        if f.category not in ("A", "B", "B'", "C", "D", "E", "E'"):
            errors.append(f"{f.name}: categoria de fadiga fora do domínio A a E'.")
        numeric_fields(f, ("temperature_c",))
        for key in ("constant_amplitude", "same_point_confirmed", "fatigue_combination_confirmed", "fabrication_requirements_confirmed", "corrosion_protected"):
            if type(getattr(f, key)) is not bool:
                errors.append(f"{f.name}: {key} deve ser booleano.")
        if f.basis != "service_stress_range":
            errors.append(f"{f.name}: fadiga exige histórico de serviço, não esforços ELU.")
        if all(finite_number(v) for v in (f.stress_min_mpa, f.stress_max_mpa)) and f.stress_max_mpa < f.stress_min_mpa:
            errors.append(f"{f.name}: tensão máxima menor que a mínima; preserve o sinal das tensões.")
    return errors
