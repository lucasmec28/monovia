"""Independent linear-elastic simply-supported moving-load beam solver.

No external structural solver and no load factors are hidden here. Inputs are
already concurrent, signed actions for ONE combination. Units are kN, m, MPa,
mm^4; output displacements are mm. Positive vertical load/deflection is downward;
positive horizontal load/deflection is +y. Mx is sagging (top compression), My is
the analogous signed horizontal-plane moment; Vy and Vx are left-face shears.

Domain: straight prismatic Euler-Bernoulli beam, constant E/I, end simple supports
in both flexural planes, small displacements. Axial restraint is at the left end
only; the right end slides longitudinally. Torsion, shear deformation, axial
deformation, P-delta, support settlement and intermediate translational supports
are NOT represented. brace_positions_m delimit Cb segments ONLY: they do not insert
lateral supports or confer brace stiffness or load-height qualification.

For a fixed train position, reactions and diagrams are analytical Macaulay
expressions. Spatial extrema use polynomial stationary points (cubic roots are
bracketed to floating-point precision), not a section mesh. Moving-position
search is explicitly numerical: exact entry/exit events and nested grids are
used, with certified mathematical discretization upper bounds, not an 'exact'
claim for the sampled maximum. Floating-point roundoff is not interval-certified.
"""
from __future__ import annotations

from dataclasses import dataclass
from math import ceil, isfinite, nextafter
from typing import Iterable, Literal

Side = Literal["left", "right"]
Axis = Literal["vertical", "horizontal"]
METRICS = ("Mx_knm", "My_knm", "Vy_kn", "Vx_kn", "N_kn", "vertical_mm", "horizontal_mm")


def _finite(value: float, name: str) -> None:
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not isfinite(value):
        raise ValueError(f"{name} must be a finite real number")


@dataclass(frozen=True)
class BeamModel:
    span_m: float
    E_mpa: float
    Ix_mm4: float
    Iy_mm4: float
    brace_positions_m: tuple[float, ...] = ()

    def __post_init__(self):
        for name in ("span_m", "E_mpa", "Ix_mm4", "Iy_mm4"):
            _finite(getattr(self, name), name)
            if getattr(self, name) <= 0:
                raise ValueError(f"{name} must be positive")
        for inertia in (self.Ix_mm4, self.Iy_mm4):
            stiffness = self.E_mpa*inertia*1e-9
            if not isfinite(stiffness) or stiffness <= 0:
                raise ValueError("derived flexural stiffness must be finite and positive")
        positions = tuple(self.brace_positions_m)
        for x in positions:
            _finite(x, "brace position")
            if not 0 <= x <= self.span_m:
                raise ValueError("brace position must be on the beam")
        object.__setattr__(self, "brace_positions_m", tuple(sorted(set(positions))))

    @property
    def segments_m(self) -> tuple[tuple[float, float], ...]:
        nodes = sorted({0.0, self.span_m, *self.brace_positions_m})
        return tuple(zip(nodes[:-1], nodes[1:]))


@dataclass(frozen=True)
class PointLoad:
    position_m: float
    vertical_kn: float
    horizontal_kn: float = 0.0
    name: str = ""
    longitudinal_kn: float = 0.0  # positive toward the right, axial support at left
    major_moment_knm: float = 0.0  # applied global +y couple; causes +Mx jump
    minor_moment_knm: float = 0.0  # applied global +z couple; causes +My jump

    def __post_init__(self):
        for key in ("position_m", "vertical_kn", "horizontal_kn", "longitudinal_kn", "major_moment_knm", "minor_moment_knm"):
            _finite(getattr(self, key), key)


@dataclass(frozen=True)
class MovingWheel:
    offset_m: float
    vertical_kn: float
    horizontal_kn: float = 0.0
    name: str = ""
    longitudinal_kn: float = 0.0
    major_moment_knm: float = 0.0
    minor_moment_knm: float = 0.0

    def __post_init__(self):
        for key in ("offset_m", "vertical_kn", "horizontal_kn", "longitudinal_kn", "major_moment_knm", "minor_moment_knm"):
            _finite(getattr(self, key), key)


@dataclass(frozen=True)
class UniformLoad:
    vertical_kn_per_m: float = 0.0
    horizontal_kn_per_m: float = 0.0
    longitudinal_kn_per_m: float = 0.0

    def __post_init__(self):
        _finite(self.vertical_kn_per_m, "vertical UDL")
        _finite(self.horizontal_kn_per_m, "horizontal UDL")
        _finite(self.longitudinal_kn_per_m, "longitudinal UDL")

    def __add__(self, other: UniformLoad) -> UniformLoad:
        return UniformLoad(self.vertical_kn_per_m + other.vertical_kn_per_m,
                           self.horizontal_kn_per_m + other.horizontal_kn_per_m,
                           self.longitudinal_kn_per_m + other.longitudinal_kn_per_m)


def self_weight(area_mm2: float, unit_weight_kn_per_m3: float = 78.5) -> UniformLoad:
    """Physical unfactored beam self-weight; caller explicitly combines/factors it."""
    for name, value in (("area_mm2", area_mm2), ("unit_weight_kn_per_m3", unit_weight_kn_per_m3)):
        _finite(value, name)
        if value < 0:
            raise ValueError(f"{name} must be nonnegative")
    return UniformLoad(area_mm2 * 1e-6 * unit_weight_kn_per_m3)


@dataclass(frozen=True)
class Reactions:
    vertical_left_kn: float
    vertical_right_kn: float
    horizontal_left_kn: float
    horizontal_right_kn: float
    longitudinal_left_kn: float = 0.0  # signed global +x direction
    longitudinal_right_kn: float = 0.0


@dataclass(frozen=True)
class SectionActions:
    position_m: float
    side: Side
    Mx_knm: float
    My_knm: float
    Vy_kn: float
    Vx_kn: float
    vertical_mm: float
    horizontal_mm: float
    N_kn: float = 0.0  # positive tension


@dataclass(frozen=True)
class CbResult:
    start_m: float
    end_m: float
    axis: Axis
    cb: float
    maximum_abs_moment_knm: float
    quarter_abs_moments_knm: tuple[float, float, float]
    maximum_position_m: float
    # Formula evaluation alone does not qualify top-flange load height or braces.
    method: str = "12.5 Mmax / (2.5 Mmax + 3 MA + 4 MB + 3 MC)"


def _polyval(coefficients: tuple[float, ...], x: float) -> float:
    result = 0.0
    for c in reversed(coefficients):
        result = result * x + c
    return result


def _roots_in_unit_interval(coefficients: tuple[float, ...]) -> tuple[float, ...]:
    """Real roots of degree <=3 in [0,1], including repeated stationary roots.

    Recursive derivative partitions isolate each monotonic polynomial piece.
    Coefficients are interval-scaled by the caller. Bisection is deliberately
    used instead of cancellation-prone closed-form cubic expressions.
    """
    c = list(coefficients)
    while len(c) > 1 and c[-1] == 0:
        c.pop()
    if len(c) <= 1:
        return ()
    if len(c) == 2:
        root = -c[0] / c[1]
        return (root,) if 0 <= root <= 1 else ()
    derivative = tuple(i * c[i] for i in range(1, len(c)))
    dividers = sorted({0.0, 1.0, *_roots_in_unit_interval(derivative)})
    scale = max(abs(v) for v in c)
    tolerance = scale * 2e-14
    roots = [x for x in dividers if abs(_polyval(tuple(c), x)) <= tolerance]
    for lo, hi in zip(dividers[:-1], dividers[1:]):
        flo, fhi = _polyval(tuple(c), lo), _polyval(tuple(c), hi)
        if flo == 0 or fhi == 0 or (flo > 0) == (fhi > 0):
            continue
        for _ in range(60):
            mid = (lo + hi) / 2
            fmid = _polyval(tuple(c), mid)
            if fmid == 0 or mid == lo or mid == hi:
                lo = hi = mid
                break
            if (flo > 0) == (fmid > 0):
                lo, flo = mid, fmid
            else:
                hi = mid
        roots.append((lo + hi) / 2)
    return tuple(sorted(set(roots)))


@dataclass(frozen=True)
class PlaneSolution:
    span_m: float
    EI_knm2: float
    point_loads: tuple[tuple[float, float], ...]
    udl_kn_per_m: float
    left_reaction_kn: float
    right_reaction_kn: float
    integration_constant_knm2: float
    point_moments: tuple[tuple[float, float], ...] = ()

    def _check_x(self, x: float):
        _finite(x, "section position")
        if not 0 <= x <= self.span_m:
            raise ValueError("section position must be on the beam")

    def shear_kn(self, x: float, side: Side = "right") -> float:
        """Shear excluding end reactions at the cut itself.

        For physical internal end sections use (0,'right') and (L,'left').
        The other endpoint side is provided for explicit moving-load limits,
        not a section outside the member.
        """
        self._check_x(x)
        if side not in ("left", "right"):
            raise ValueError("side must be 'left' or 'right'")
        return self.left_reaction_kn - self.udl_kn_per_m * x - sum(
            p for a, p in self.point_loads if a < x or (a == x and side == "right"))

    def moment_knm(self, x: float, side: Side = "right") -> float:
        self._check_x(x)
        if side not in ("left", "right"):
            raise ValueError("side must be 'left' or 'right'")
        # A couple applied at an end produces a NONZERO inner end moment;
        # only the unloaded outer side is zero. Never forcibly zero that couple.
        return (self.left_reaction_kn * x - self.udl_kn_per_m * x*x/2
                - sum(p * max(x-a, 0.0) for a, p in self.point_loads)
                + sum(c for a, c in self.point_moments if a < x or (a == x and side == "right")))

    def slope_rad(self, x: float) -> float:
        self._check_x(x)
        return (self.integration_constant_knm2 - self.left_reaction_kn*x*x/2
                + self.udl_kn_per_m*x**3/6
                + sum(p * max(x-a, 0.0)**2/2 for a, p in self.point_loads)
                - sum(c * max(x-a, 0.0) for a, c in self.point_moments)) / self.EI_knm2

    def deflection_mm(self, x: float) -> float:
        self._check_x(x)
        if x == 0 or x == self.span_m:
            return 0.0
        return 1000 * (self.integration_constant_knm2*x - self.left_reaction_kn*x**3/6
                       + self.udl_kn_per_m*x**4/24
                       + sum(p * max(x-a, 0.0)**3/6 for a, p in self.point_loads)
                       - sum(c * max(x-a, 0.0)**2/2 for a, c in self.point_moments)) / self.EI_knm2

    def critical_positions(self, start_m: float = 0.0, end_m: float | None = None) -> tuple[float, ...]:
        """Endpoints, loads, moment extrema and deflection extrema in an interval."""
        end_m = self.span_m if end_m is None else end_m
        self._check_x(start_m)
        self._check_x(end_m)
        if end_m <= start_m:
            raise ValueError("critical interval must have positive length")
        nodes = sorted({start_m, end_m, *(a for a, _ in self.point_loads if start_m < a < end_m)})
        result = set(nodes)
        q = self.udl_kn_per_m
        for left, right in zip(nodes[:-1], nodes[1:]):
            width = right-left
            # M(left+t) = M(left)+V(left+)t-q*t^2/2.
            v = self.shear_kn(left, "right")
            if q:
                root = left + v/q
                if left < root < right:
                    result.add(root)
            # EI*y'(left+t) = EI*y'(left)-M(left)t-V(left+)t²/2+q*t³/6.
            coefficients = (self.slope_rad(left)*self.EI_knm2,
                            -self.moment_knm(left)*width,
                            -v*width**2/2, q*width**3/6)
            for root in _roots_in_unit_interval(coefficients):
                result.add(left + root*width)
        return tuple(sorted(result))


def _solve_plane(beam: BeamModel, loads: tuple[PointLoad, ...], udl: UniformLoad, axis: Axis) -> PlaneSolution:
    if axis == "vertical":
        points = tuple((p.position_m, p.vertical_kn) for p in loads)
        moments = tuple((p.position_m, p.major_moment_knm) for p in loads)
        q, inertia = udl.vertical_kn_per_m, beam.Ix_mm4
    elif axis == "horizontal":
        points = tuple((p.position_m, p.horizontal_kn) for p in loads)
        moments = tuple((p.position_m, p.minor_moment_knm) for p in loads)
        q, inertia = udl.horizontal_kn_per_m, beam.Iy_mm4
    else:
        raise ValueError("axis must be 'vertical' or 'horizontal'")
    length = beam.span_m
    # MPa * mm^4 -> kN*m² = 10^-9.
    ei = beam.E_mpa * inertia * 1e-9
    left = q*length/2 + sum(p*(length-a)/length for a, p in points) - sum(c for _, c in moments)/length
    right = q*length/2 + sum(p*a/length for a, p in points) + sum(c for _, c in moments)/length
    c1 = (left*length**3/6 - q*length**4/24 - sum(p*(length-a)**3/6 for a, p in points)
          + sum(c*(length-a)**2/2 for a, c in moments))/length
    return PlaneSolution(length, ei, points, q, left, right, c1, moments)


@dataclass(frozen=True)
class BeamSolution:
    beam: BeamModel
    loads: tuple[PointLoad, ...]
    udl: UniformLoad
    vertical: PlaneSolution
    horizontal: PlaneSolution
    fixed_loads: tuple[PointLoad, ...] = ()

    @property
    def all_loads(self):
        """Actual moving loads plus non-translating equivalent actions."""
        return self.loads+self.fixed_loads

    @property
    def reactions(self) -> Reactions:
        return Reactions(self.vertical.left_reaction_kn, self.vertical.right_reaction_kn,
                         self.horizontal.left_reaction_kn, self.horizontal.right_reaction_kn,
                         -self.udl.longitudinal_kn_per_m*self.beam.span_m-sum(p.longitudinal_kn for p in self.all_loads), 0.0)

    def axial_force_kn(self, position_m: float, side: Side = "right") -> float:
        """N positive in tension; left axial anchor and right sliding support."""
        self.vertical._check_x(position_m)
        if side not in ("left", "right"):
            raise ValueError("side must be 'left' or 'right'")
        return self.udl.longitudinal_kn_per_m*(self.beam.span_m-position_m) + sum(
            p.longitudinal_kn for p in self.all_loads
            if p.position_m > position_m or (p.position_m == position_m and side == "left"))

    def at(self, position_m: float, side: Side = "right") -> SectionActions:
        """All actions are concurrent at the SAME train position and section."""
        return SectionActions(position_m, side,
                              self.vertical.moment_knm(position_m, side), self.horizontal.moment_knm(position_m, side),
                              self.vertical.shear_kn(position_m, side), self.horizontal.shear_kn(position_m, side),
                              self.vertical.deflection_mm(position_m), self.horizontal.deflection_mm(position_m),
                              self.axial_force_kn(position_m, side))

    def critical_positions(self) -> tuple[float, ...]:
        return tuple(sorted({*self.vertical.critical_positions(), *self.horizontal.critical_positions(),
                             *self.beam.brace_positions_m}))

    def critical_sections(self) -> tuple[SectionActions, ...]:
        """Exact flexural/shear/displacement candidates, not interaction extrema.

        Nonlinear resistance interactions may have additional stationary points;
        callers must not claim this set certifies all combined-stress checks.
        """
        wheels = {p.position_m for p in self.all_loads}
        result = []
        for x in self.critical_positions():
            if x == 0:
                sides = ("right",)
            elif x == self.beam.span_m:
                sides = ("left",)
            elif x in wheels:
                sides = ("left", "right")
            else:
                sides = ("right",)
            result.extend(self.at(x, side) for side in sides)
        return tuple(result)

    def linear_response_critical_sections(self, *, Mx_factor: float = 0.0, My_factor: float = 0.0,
                                          N_factor: float = 0.0) -> tuple[SectionActions, ...]:
        """Extrema candidates of Mx_factor*Mx + My_factor*My + N_factor*N.

        Useful for EACH signed elastic fiber stress (for example 1/A and 1/W,
        with the required kN/m to N/mm conversions in the factors). The weighted
        response is quadratic between point loads. Includes both sides of axial
        jumps. It does not cover bimoment, nonlinear interactions or resistance.
        """
        for value in (Mx_factor, My_factor, N_factor):
            _finite(value, "linear response factor")
        nodes = sorted({0.0, self.beam.span_m, *(p.position_m for p in self.all_loads)})
        result = set(nodes)
        q = Mx_factor*self.udl.vertical_kn_per_m + My_factor*self.udl.horizontal_kn_per_m
        for a, b in zip(nodes[:-1], nodes[1:]):
            derivative = (Mx_factor*self.vertical.shear_kn(a, "right")
                          + My_factor*self.horizontal.shear_kn(a, "right")
                          - N_factor*self.udl.longitudinal_kn_per_m)
            if q:
                root = a+derivative/q
                if a < root < b:
                    result.add(root)
        sections = []
        for x in sorted(result):
            sides = ("right",) if x == 0 else (("left",) if x == self.beam.span_m else ("left", "right"))
            sections.extend(self.at(x, side) for side in sides)
        return tuple(sections)

    def cb(self, start_m: float, end_m: float, axis: Axis = "vertical") -> CbResult:
        if axis not in ("vertical", "horizontal"):
            raise ValueError("axis must be 'vertical' or 'horizontal'")
        plane = self.vertical if axis == "vertical" else self.horizontal
        candidates = plane.critical_positions(start_m, end_m)
        def sides_at(x):
            # Cb uses the member side of segment boundaries, both faces of an
            # interior applied couple. At a quarter point use the larger |M|,
            # which gives the smaller (conservative) Cb for a discontinuity.
            return ("right",) if x == start_m else (("left",) if x == end_m else ("left", "right"))
        x_max, maximum = max(((x, abs(plane.moment_knm(x, side))) for x in candidates for side in sides_at(x)), key=lambda pair: pair[1])
        quarters = tuple(max(abs(plane.moment_knm(start_m + (end_m-start_m)*f, side)) for side in ("left", "right")) for f in (.25, .5, .75))
        cb = 1.0 if maximum == 0 else 12.5*maximum/(2.5*maximum + 3*quarters[0] + 4*quarters[1] + 3*quarters[2])
        return CbResult(start_m, end_m, axis, cb, maximum, quarters, x_max)

    def cb_segments(self, axis: Axis = "vertical") -> tuple[CbResult, ...]:
        return tuple(self.cb(a, b, axis) for a, b in self.beam.segments_m)


def solve_position(beam: BeamModel, loads: Iterable[PointLoad] = (), udl: UniformLoad | None = None, *, fixed_loads: Iterable[PointLoad] = ()) -> BeamSolution:
    """Solve one load position; off-span loads must be filtered by translate_train."""
    loads = tuple(sorted(loads, key=lambda p: p.position_m))
    udl = UniformLoad() if udl is None else udl
    fixed_loads = tuple(sorted(fixed_loads,key=lambda p:p.position_m))
    all_loads = loads+fixed_loads
    for p in all_loads:
        if not 0 <= p.position_m <= beam.span_m:
            raise ValueError("point load outside beam; use translate_train for entry/exit")
    return BeamSolution(beam, loads, udl, _solve_plane(beam, all_loads, udl, "vertical"),
                        _solve_plane(beam, all_loads, udl, "horizontal"),fixed_loads)


def translate_train(beam: BeamModel, wheels: Iterable[MovingWheel], translation_m: float) -> tuple[PointLoad, ...]:
    """x_i = translation_m + offset_i; wheels off the span contribute NOTHING."""
    _finite(translation_m, "train translation")
    return tuple(PointLoad(translation_m+w.offset_m, w.vertical_kn, w.horizontal_kn, w.name, w.longitudinal_kn, w.major_moment_knm, w.minor_moment_knm)
                 for w in wheels if 0 <= translation_m+w.offset_m <= beam.span_m)


@dataclass(frozen=True)
class SearchTolerance:
    relative: float = 0.005
    force_kn: float = 0.001
    moment_knm: float = 0.001
    deflection_mm: float = 0.001

    def __post_init__(self):
        for name in ("relative", "force_kn", "moment_knm", "deflection_mm"):
            value = getattr(self, name)
            _finite(value, name)
            if value < 0:
                raise ValueError("search tolerances must be nonnegative")

    def absolute_for(self, metric: str) -> float:
        if metric.endswith("_knm"):
            return self.moment_knm
        return self.force_kn if metric.endswith("_kn") else self.deflection_mm


@dataclass(frozen=True)
class MovingSample:
    translation_m: float
    solution: BeamSolution


@dataclass(frozen=True)
class EnvelopeMaximum:
    metric: str
    absolute_value: float
    signed_value: float
    translation_m: float
    section: SectionActions
    upper_bound: float
    discretization_error_bound: float


@dataclass(frozen=True)
class MovingSearchResult:
    samples: tuple[MovingSample, ...]
    maxima: tuple[EnvelopeMaximum, ...]
    converged: bool
    refinements: int
    max_translation_gap_m: float
    translation_range_m: tuple[float, float]
    method: str = "event-aligned nested translation grid; analytic spatial extrema; bounded discretization error"
    limitations: tuple[str, ...] = (
        "Envelope maxima belong to different cases; never combine them as simultaneous actions.",
        "Bounds cover the listed scalar flexural responses only, not Cb-dependent resistance or interaction ratios.",
        "Numerical roundoff is not interval-certified; no torsional, shear-deformation or second-order response.",
    )

    def maximum(self, metric: str) -> EnvelopeMaximum:
        return next(item for item in self.maxima if item.metric == metric)


def _shear_supremum(beam: BeamModel, wheels: tuple[MovingWheel, ...], udl: UniformLoad,
                    events: list[float], axis: str, fixed_loads=()) -> float:
    """Exact supremum of absolute shear over motion, including entry/exit limits.

    Between wheel entry/exit events, each shear at each wheel side/support is
    affine in translation. Its absolute maximum is at an interval endpoint.
    Both sides at endpoint wheels represent limits from INSIDE that interval.
    """
    result = 0.0
    for a, b in zip(events[:-1], events[1:]):
        mid = (a+b)/2
        active = tuple(w for w in wheels if 0 < mid+w.offset_m < beam.span_m)
        for translation in (a, b):
            loads = tuple(PointLoad(min(beam.span_m, max(0.0, translation+w.offset_m)),
                                    w.vertical_kn, w.horizontal_kn, w.name, w.longitudinal_kn, w.major_moment_knm, w.minor_moment_knm) for w in active)
            solution = solve_position(beam, loads, udl,fixed_loads=fixed_loads)
            force = solution.axial_force_kn if axis == "longitudinal" else (solution.vertical if axis == "vertical" else solution.horizontal).shear_kn
            nodes = {0.0, beam.span_m, *(p.position_m for p in solution.all_loads)}
            def interior_limit(x,side):
                value=force(x,side)
                # The outer-side convention is used only for MOVING wheel
                # entry/exit limits. A fixed endpoint load never crosses its
                # support: retain its physical inner-side contribution.
                component={'vertical':'vertical_kn','horizontal':'horizontal_kn','longitudinal':'longitudinal_kn'}[axis]
                if x==0 and side=='left':
                    value-=sum(getattr(p,component) for p in fixed_loads if p.position_m==0)
                elif x==beam.span_m and side=='right':
                    value+=sum(getattr(p,component) for p in fixed_loads if p.position_m==beam.span_m)
                return value
            result = max(result, *(abs(interior_limit(x, side)) for x in nodes for side in ("left", "right")))
    # Include actual event values, including possible isolated zero-range motion.
    for translation in events:
        solution = solve_position(beam, translate_train(beam, wheels, translation), udl,fixed_loads=fixed_loads)
        force = solution.axial_force_kn if axis == "longitudinal" else (solution.vertical if axis == "vertical" else solution.horizontal).shear_kn
        result = max(result, *(abs(force(s.position_m, s.side)) for s in solution.critical_sections()))
    return result


def scan_moving_train(beam: BeamModel, wheels: Iterable[MovingWheel], udl: UniformLoad | None = None,
                      *, translation_range_m: tuple[float, float] | None = None,
                      initial_intervals: int = 24, max_refinements: int = 6,
                      tolerance: SearchTolerance | None = None, fixed_loads: Iterable[PointLoad] = ()) -> MovingSearchResult:
    """Search complete train passage, including partial entry and exit.

    Default range is [-max(offset), L-min(offset)]. Point offsets may be signed,
    duplicated or unsorted. Vertical/horizontal signs remain paired at each
    wheel and sample. `converged=False` explicitly means the requested certified
    discretization tolerance was NOT met; the upper bounds remain available.

    For each point load the moment influence line has |dM/da|<=|P|, including
    off-span extension by zero. Hence the maximum absolute moment is Lipschitz
    with K=sum|P|. The Dirichlet inverse for -y''=M/EI bounds the deflection
    Lipschitz constant by 1000*sum|P|*L²/(8EI). A nearest sampled translation is
    at most half the largest gap away. Shear is not Lipschitz at train entry:
    its separate piecewise-affine supremum includes one-sided event limits.
    Moving point couples require event-interval one-sided cover radii: moment
    Lipschitz K is sum|P|+max|V|, and deflection K gains 1000*sum|C|*L/(4EI).
    The event value itself is also solved, so end-applied couples are retained.
    """
    wheels = tuple(wheels)
    fixed_loads = tuple(fixed_loads)
    udl = UniformLoad() if udl is None else udl
    tolerance = SearchTolerance() if tolerance is None else tolerance
    if isinstance(initial_intervals, bool) or not isinstance(initial_intervals, int) or initial_intervals < 1:
        raise ValueError("initial_intervals must be a positive integer")
    if isinstance(max_refinements, bool) or not isinstance(max_refinements, int) or max_refinements < 0:
        raise ValueError("max_refinements must be a nonnegative integer")
    if translation_range_m is None:
        translation_range_m = ((-max(w.offset_m for w in wheels), beam.span_m-min(w.offset_m for w in wheels))
                               if wheels else (0.0, beam.span_m))
    low, high = translation_range_m
    _finite(low, "translation range lower end")
    _finite(high, "translation range upper end")
    if high < low:
        raise ValueError("translation range must be increasing")
    events = sorted({low, high, *(x for w in wheels for x in (-w.offset_m, beam.span_m-w.offset_m) if low <= x <= high)})
    shear_upper = {"Vy_kn": _shear_supremum(beam, wheels, udl, events, "vertical",fixed_loads),
                   "Vx_kn": _shear_supremum(beam, wheels, udl, events, "horizontal",fixed_loads),
                   "N_kn": _shear_supremum(beam, wheels, udl, events, "longitudinal",fixed_loads)}
    potentially_active = tuple(w for w in wheels if high+w.offset_m > 0 and low+w.offset_m < beam.span_m)
    kv = sum(abs(w.vertical_kn) for w in potentially_active)
    kh = sum(abs(w.horizontal_kn) for w in potentially_active)
    cv = sum(abs(w.major_moment_knm) for w in potentially_active)
    ch = sum(abs(w.minor_moment_knm) for w in potentially_active)
    # A moving couple makes moment discontinuous at its moving station. Follow
    # each wheel face: derivative <= sum|P|+max|V|. Other moment extrema have
    # derivative <=sum|P|. These bounds hold within each fixed-active-set event
    # interval; entry/exit is handled with separate one-sided interior samples.
    constants = {"Mx_knm": kv + (shear_upper["Vy_kn"] if cv else 0.0),
                 "My_knm": kh + (shear_upper["Vx_kn"] if ch else 0.0),
                 "vertical_mm": 1000*(kv*beam.span_m**2/8+cv*beam.span_m/4)/(beam.E_mpa*beam.Ix_mm4*1e-9),
                 "horizontal_mm": 1000*(kh*beam.span_m**2/8+ch*beam.span_m/4)/(beam.E_mpa*beam.Iy_mm4*1e-9)}
    cache: dict[float, MovingSample] = {}
    base_grid = set(events)
    if high > low:
        spacing = (high-low)/initial_intervals
        for a, b in zip(events[:-1], events[1:]):
            n = max(1, ceil((b-a)/spacing))
            base_grid.update(a+(b-a)*i/n for i in range(1, n))
            # Witness near each discontinuous shear limit, explicitly still a
            # real interior train position, rather than a fictitious endpoint cut.
            epsilon = min((b-a)*1e-6, beam.span_m*1e-9)
            just_after = max(nextafter(a, b), a+epsilon)
            just_before = min(nextafter(b, a), b-epsilon)
            if not a < just_after < b or not a < just_before < b:
                raise ValueError("translation event interval is below floating-point resolution")
            base_grid.update((just_after, just_before))
    positions = sorted(base_grid)
    maxima: tuple[EnvelopeMaximum, ...] = ()
    converged = False
    gap = 0.0
    for refinement in range(max_refinements+1):
        for translation in positions:
            if translation not in cache:
                cache[translation] = MovingSample(translation, solve_position(beam, translate_train(beam, wheels, translation), udl,fixed_loads=fixed_loads))
        best: dict[str, tuple[float, float, SectionActions]] = {}
        for translation in positions:
            for section in cache[translation].solution.critical_sections():
                for metric in METRICS:
                    value = getattr(section, metric)
                    if metric not in best or abs(value) > abs(best[metric][0]):
                        best[metric] = (value, translation, section)
        gap = max((b-a for a, b in zip(positions[:-1], positions[1:])), default=0.0)
        # Couples cause entry/exit jumps. A sample from the OTHER side of an
        # event cannot control that interval. Compute its interior cover radius.
        cover = gap/2
        if cv or ch:
            cover = 0.0
            for a, b in zip(events[:-1], events[1:]):
                interior = [x for x in positions if a < x < b]
                if interior:
                    cover = max(cover, interior[0]-a, b-interior[-1],
                                max((y-x for x, y in zip(interior[:-1], interior[1:])), default=0.0)/2)
        items = []
        for metric in METRICS:
            value, translation, section = best[metric]
            upper = max(abs(value), shear_upper[metric]) if metric in shear_upper else abs(value)+constants[metric]*cover
            items.append(EnvelopeMaximum(metric, abs(value), value, translation, section, upper, max(0.0, upper-abs(value))))
        maxima = tuple(items)
        converged = all(item.discretization_error_bound <= tolerance.absolute_for(item.metric)+tolerance.relative*item.absolute_value for item in maxima)
        if converged or refinement == max_refinements:
            break
        positions = sorted({*positions, *((a+b)/2 for a, b in zip(positions[:-1], positions[1:]))})
    return MovingSearchResult(tuple(cache[x] for x in positions), maxima, converged, refinement, gap, (low, high))
