"""Editable, self-contained exports of the exact autonomous result snapshot."""
from io import BytesIO,StringIO
import csv,json
from dataclasses import asdict
from .autonomous_result import AutonomousResult

MECHANISM_LABELS={'actions':'ações e combinações','equilibrium':'equilíbrio','moving_envelope':'envoltória móvel','vertical_bending':'flexão vertical','horizontal_bending':'flexão horizontal','axial_force':'força axial','torsion_warping':'torção e empenamento','combined_yield':'tensões combinadas','global_stability':'estabilidade global da viga','local_stability':'estabilidade local','wheel_local_effects':'efeitos locais das rodas','support_local_effects':'efeitos locais dos apoios','stiffeners':'enrijecedores','fatigue':'fadiga','vertical_service':'flecha vertical','horizontal_service':'flecha horizontal','rail_service':'deslocamento do trilho'}

LABELS=('Verificação','Solicitação','Resistência / limite','Unidade','Utilização','Resultado','Caso crítico','Referência','Observação')

def decimal(value):
    return '' if value is None else f'{value:.2f}'.replace('.',',')

def summary_checks(result):
    """One governing real case per check/base/state; JSON retains every case."""
    selected={}
    for c in result.checks:
        if c.id.startswith('coverage/') and c.state=='calculated' and c.evidence.get('verification_complete') is True:
            continue
        key=(c.mechanism,c.title,c.source,c.state,c.unit,c.reason if c.state in ('pending','unsupported') else '')
        old=selected.get(key)
        score=c.utilization if c.utilization is not None else c.evidence.get('relative_change',0) or 0
        old_score=(old.utilization if old and old.utilization is not None else old.evidence.get('relative_change',0) or 0) if old else -1
        if old is None or score>old_score:selected[key]=c
    return list(selected.values())

def case_label(result,case_id):
    if case_id=='FAT8400_LIFETIME':return 'Fadiga · passagens e sinais da vida útil no cenário analisado'
    if case_id in ('EnvelopeELU','Envelope ELU'):return 'Envoltória das combinações ELU'
    for case in result.cases:
        if case.get('id')==case_id:
            label=case.get('description') or case_id
            label=label.replace('Resistência complementar8800','Resistência complementar NBR 8800').replace('uls_normal/','combinação normal · ').replace('GsD','peso próprio desfavorável').replace('GsF','peso próprio favorável').replace('GeD','ponte desfavorável').replace('GeF','ponte favorável').replace('/Gx0','').replace('/',' · ')
            signs=[]
            for axis,name in (('HT','HT'),('HL','HL')):
                for token in case_id.split('/'):
                    if token.startswith(axis) and token[len(axis):] in ('+1','-1'):signs.append(name+' '+token[len(axis):])
            return label+(' · '+', '.join(signs) if signs else '')
    return case_id

def critical_description(result,check):
    location=check.evidence.get('critical_location')
    if not isinstance(location,dict):return ''
    pieces=[];identifier=location.get('station_id')
    if identifier:
        stations=result.numerical_evidence.get('fixed_stiffener_weld_detail',{}).get('stations',[])
        station=next((row for row in stations if row.get('station_id')==identifier),None)
        pieces.append('enrijecedor em x = '+decimal(station['x_m'])+' m' if station else str(identifier))
    interface=location.get('interface_id')
    if interface:pieces.append({'top':'interface com a mesa superior','bottom':'interface com a mesa inferior','web':'interface com a alma','top:beam':'mesa superior da viga','bottom:beam':'mesa inferior da viga','web:beam':'alma da viga','web:stiffener':'chapa do enrijecedor'}.get(interface,str(interface)))
    if 'translation_m' in location:pieces.append('posição do trem = '+decimal(location['translation_m'])+' m')
    return 'Local governante: '+', '.join(pieces)+'.' if pieces else ''

_FULLHEIGHT_REGION_LABELS = {
    'web_ordinary':'alma, trecho ordinário',
    'flange_top_ordinary':'mesa superior, trecho ordinário',
    'flange_bottom_ordinary':'mesa inferior, trecho ordinário',
    'web_straight':'alma, trecho reto da solda do enrijecedor',
    'web_termination_top':'alma, término superior da solda',
    'web_termination_bottom':'alma, término inferior da solda',
    'top_cjp_receiver':'mesa superior, pé da CJP do enrijecedor',
    'bottom_fillet_receiver':'mesa inferior, pé do filete do enrijecedor',
    'longitudinal_web_top':'alma, junta longitudinal superior',
    'longitudinal_web_bottom':'alma, junta longitudinal inferior',
    'longitudinal_flange_top':'mesa superior, junta longitudinal',
    'longitudinal_flange_bottom':'mesa inferior, junta longitudinal',
    'longitudinal_cjp_throat_top':'garganta da CJP longitudinal superior',
    'longitudinal_cjp_throat_bottom':'garganta da CJP longitudinal inferior',
    'bearing_plate_lower':'apoio, chapa junto à mesa inferior',
    'bearing_weld_lower':'apoio, garganta dos filetes inferiores',
    'bearing_plate_web':'apoio, chapa junto à alma',
    'bearing_plate_top':'apoio, chapa junto à mesa superior',
    'bearing_weld_web':'apoio, garganta dos filetes da alma',
    'bearing_weld_top':'apoio, CJP superior',
    'bearing_receiver_web_composition':'apoio, alma receptora',
    'bearing_receiver_top_composition':'apoio, mesa superior receptora',
    'bearing_receiver_bottom_composition':'apoio, mesa inferior receptora',
}
_SUFFICIENT_EXCEEDANCE_REASON = 'Verificação executada; atendimento não demonstrado pelo limite suficiente adotado.'


def _exact_bearing_geometry_key(check):
    import re
    match=re.fullmatch(r'fullheight/bearing/stiffener/(\d+)/(?:outstand|component/bearing_minimum_outstand)',check.id)
    return ('bearing_outstand',match[1]) if match else None


def sufficient_bound_exceeded(check):
    # Presentation only. Never infer this classification from a large utilization,
    # a missing result, or an arbitrary occurrence of the word "conservador".
    return check.verdict=='NÃO ATENDE' and _exact_bearing_geometry_key(check) is None and (
        check.reason==_SUFFICIENT_EXCEEDANCE_REASON or
        check.evidence.get('conservative_exceedance') is True)


def display_verdict(check):
    return 'INCONCLUSIVO' if sufficient_bound_exceeded(check) else check.verdict


def result_outcome_summary(result):
    direct=[c for c in result.checks if c.verdict=='NÃO ATENDE' and not sufficient_bound_exceeded(c)]
    bounds=sum(sufficient_bound_exceeded(c) for c in result.checks)
    passed=sum(c.verdict=='ATENDE' for c in result.checks)
    pending=sum(c.state in ('pending','unsupported') for c in result.checks)
    geometric=bool(direct) and all(_exact_bearing_geometry_key(c) is not None for c in direct)
    direct_label=(str(len({_exact_bearing_geometry_key(c) for c in direct}))+' critérios geométricos reprovados ('+str(len(direct))+' registros)' if geometric else str(len(direct))+' critérios diretamente não atendidos')
    text=f'Registros desta execução: {passed} atendimentos, '+direct_label+f', {bounds} limites suficientes excedidos (inconclusivos) e {pending} pendências.'
    if bounds:
        text+=' A excedência de um limite suficiente não demonstra falha física: a seção não foi comprovada por esse critério conservador. As pendências indicam verificações ainda sem conclusão, e não resultados aprovados.'
    return text


def display_title(title):
    title=title.replace("projeção física left", "projeção física esquerda").replace("projeção física right", "projeção física direita")
    prefix='Cobertura de fadiga: fullheight_'
    if title.startswith(prefix):
        body,sep,station=title[len(prefix):].partition('/stiffener/')
        if body in _FULLHEIGHT_REGION_LABELS:
            title='Cobertura de fadiga: '+_FULLHEIGHT_REGION_LABELS[body]+(' · estação '+station if sep else '')
    return title

def result_rows(result):
    return [[display_title(c.title),decimal(c.demand),decimal(c.capacity),('—' if c.unit in ('adimensional','ratio','relative') else c.unit),decimal(c.utilization),c.verdict,case_label(result,c.case),c.source,' '.join(x for x in (c.reason,critical_description(result,c)) if x)] for c in summary_checks(result)]

def export_csv(project,result):
    result.validate_current(project)
    out=StringIO(newline='');w=csv.writer(out,delimiter=';',lineterminator='\r\n')
    w.writerow(('RESULTADO GERAL',result.status))
    w.writerow(LABELS);w.writerows(result_rows(result))
    if result.missing_mechanisms:
        w.writerow(('COBERTURA PENDENTE',', '.join(MECHANISM_LABELS.get(k,k) for k in result.missing_mechanisms)))
    for issue in result.coverage_issues:
        scope=result.required_check_scopes.get(issue['id'],{})
        w.writerow(('OBRIGAÇÃO PENDENTE',MECHANISM_LABELS.get(scope.get('mechanism'),'Cobertura de cálculo'),scope.get('case',''),issue['reason']))
    for e in result.errors:w.writerow(('ERRO',e))
    return out.getvalue().encode('utf-8-sig')

def export_calculation_json(project,result,*,document_metadata=None):
    result.validate_current(project)
    from .document_metadata import validate_document_metadata
    metadata=validate_document_metadata({} if document_metadata is None else document_metadata)
    payload={'format':'LRO_AUTONOMOUS_CALCULATION','version':1,'inputs':project.to_dict(),'results':result.to_dict()}
    from .autonomous_numerical_controls import validate_recorded_calculation_controls
    controls=validate_recorded_calculation_controls(project,result)
    if controls is not None:
        payload.update(version=2,calculation_controls=controls)
    if metadata:payload['document_metadata']=metadata
    return json.dumps(payload,ensure_ascii=False,allow_nan=False,indent=2).encode('utf-8')

# The Word report is deliberately a reviewable engineering extract. Machine-readable
# exports retain the complete precision, every case and all numerical evidence.
_REPORT_FAMILY_LABELS = {
    'I':'NBR 10084/8400 · I', 'III':'NBR 10084/8400 · III',
    'ULS8800':'NBR 8800 · ELU', 'SLS10084':'NBR 10084 · serviço',
    'SLS8800':'NBR 8800 · serviço', 'FAT8400':'NBR 8400 · fadiga',
    'FAT8800':'NBR 8800 · fadiga', 'FAT8400_LIFETIME':'Fadiga · vida útil',
}
_PROBLEM_VERDICTS = ('NÃO ATENDE','PENDENTE','FORA DO DOMÍNIO')


def _case_family(result,check):
    if check.case in ('EnvelopeELU','Envelope ELU'):return 'ULS8800'
    if check.case=='FAT8400_LIFETIME':return check.case
    return next((row.get('family','') for row in result.cases if row.get('id')==check.case),check.case.split('/')[0] if check.case else 'Geral')


def report_checks(result):
    """Envelope by physical family/base, plus EVERY distinct adverse criterion.

    A smaller passing table never hides a failed/pending criterion behind a more
    severe row in the same mechanism. Different states, sources, units and physical
    fatigue regions remain independent. Exact cases stay available in JSON/CSV.
    """
    selected={}
    adverse={}
    def score_of(row):return row.utilization if row.utilization is not None else row.evidence.get('relative_change',-1.) or 0.
    for c in result.checks:
        if c.id.startswith('coverage/') and c.verdict=='ATENDE':continue
        region=c.title.split(' · ')[0] if c.mechanism=='fatigue' else ''
        key=(c.mechanism,_case_family(result,c),c.state,region)
        old=selected.get(key)
        score=score_of(c)
        if old is None or score>score_of(old):selected[key]=c
        if c.verdict in _PROBLEM_VERDICTS:
            key=(c.mechanism,c.title,c.source,c.state,c.unit,_case_family(result,c),c.reason if c.state in ('pending','unsupported') else '')
            old=adverse.get(key)
            if old is None or score>score_of(old):adverse[key]=c
    rows={c.id:c for c in (*selected.values(),*adverse.values())}
    order={key:i for i,key in enumerate(MECHANISM_LABELS)}
    return sorted(rows.values(),key=lambda c:(order[c.mechanism],_case_family(result,c),c.title,c.state,c.id))


def _coverage_rows(result):
    """Group absent obligations, never drop their mechanism or reason."""
    groups={}
    for issue in result.coverage_issues:
        scope=result.required_check_scopes.get(issue['id'],{})
        key=(scope.get('mechanism',''),issue['reason'])
        groups[key]=groups.get(key,0)+1
    return [(MECHANISM_LABELS.get(m,'Matriz de verificação').capitalize(),reason,count) for (m,reason),count in groups.items()]


def _unique(values):
    return list(dict.fromkeys(value.strip() for value in values if value and value.strip()))


def _concise_reason(check):
    """Remove only known repeated boilerplate; engineering qualifications remain."""
    if check.verdict=='NÃO ATENDE' and _exact_bearing_geometry_key(check) is not None:
        return 'Largura saliente mínima não atendida: '+decimal(check.demand)+' mm requeridos e '+decimal(check.capacity)+' mm informados.'
    text=check.reason
    for prefix in (
        'Não atende ao critério conservador adotado. Redimensionar ou empregar uma avaliação refinada; este limite não constitui prova de ruptura física. ',
        'Não atende ao critério conservador adotado; não constitui prova de ruptura física; redimensionar ou adotar método refinado.',
    ):
        if text.startswith(prefix):text=text[len(prefix):].strip()
    import re
    # Presentation only: exact audit strings remain in CSV/JSON.
    text='; '.join(_unique(text.split('; ')))
    text=text.replace('sqrt((|N|/A+|Mx|/Wx+|My|/Wy+|B|omega/Cw)^2+3*tau_bound^2)<=fy/gamma',
                      '√[(|N|/A + |Mx|/Wx + |My|/Wy + |B|ω/Cw)² + 3 τenv²] ≤ fy/γ')
    text=text.replace('N/(chi NR/gamma)+k Mmajor/(chiLT MR/gamma)+k Mminor/(MR/gamma)+1.4 B/(BR/gamma)<=1',
                      'N/(χ NR/γ) + k Mmajor/(χLT MR/γ) + k Mminor/(MR/γ) + 1,4 B/(BR/γ) ≤ 1')
    text=re.sub(r'Estação stiffener/\d+ em (-?\d+\.\d+) m\.',lambda m:'Enrijecedor em x = '+m[1].replace('.',',')+' m.',text)
    text=re.sub(r'(posição do trem )(-?\d+\.\d+)( m)',lambda m:m[1]+m[2].replace('.',',')+m[3],text)
    text=re.sub(r'FAT8400/(carregada|vazia)/HT([+-]?\d)/HL([+-]?\d)',lambda m:'Fadiga NBR 8400, '+('com carga içada' if m[1]=='carregada' else 'sem carga içada')+', HT '+m[2]+', HL '+m[3],text)
    return text


def export_word(project,result,views=(),*,document_metadata=None):
    """Editable MC-ready report of the exact snapshot, with fail-closed summaries."""
    result.validate_current(project)
    from .autonomous_numerical_controls import validate_recorded_calculation_controls
    controls=validate_recorded_calculation_controls(project,result)
    from docx import Document
    from docx.shared import Inches,Pt,Cm,RGBColor
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn
    from docx.image.image import Image
    from .autonomous_response import stiffener_self_weight_metadata

    from .document_metadata import DOCUMENT_FIELDS, validate_document_metadata
    metadata=validate_document_metadata({} if document_metadata is None else document_metadata)
    d=Document();sec=d.sections[0]
    sec.page_width=Inches(8.5);sec.page_height=Inches(11)
    sec.top_margin=sec.bottom_margin=Cm(1.7);sec.left_margin=sec.right_margin=Cm(1.7)
    sec.footer_distance=Cm(.6)
    width_cm=(sec.page_width-sec.left_margin-sec.right_margin)/360000
    normal=d.styles['Normal'];normal.font.name='Arial';normal.font.size=Pt(9)
    normal.paragraph_format.space_after=Pt(5);normal.paragraph_format.line_spacing=1.08
    for name,size in (('Title',19),('Subtitle',10),('Heading 1',12),('Heading 2',10)):
        style=d.styles[name];style.font.name='Arial';style.font.size=Pt(size);style.font.color.rgb=RGBColor(0,0,0)
        style.paragraph_format.space_before=Pt(12 if name.startswith('Heading') else 0)
        style.paragraph_format.space_after=Pt(6)
        if name.startswith('Heading'):style.paragraph_format.keep_with_next=True
    # Some installed default templates give Title an inherited blue border.
    # This is an MC section, not a decorated cover. Remove paragraph borders.
    for node in list(d.styles.element.iter(qn('w:pBdr'))):node.getparent().remove(node)
    for name in ('Caption','Header','Footer'):
        d.styles[name].font.name='Arial';d.styles[name].font.size=Pt(8);d.styles[name].font.color.rgb=RGBColor(0,0,0)
    d.core_properties.title='Memória de cálculo da viga de rolamento'
    d.core_properties.subject='Modelo estrutural, ações, verificações e conclusão'
    d.core_properties.author='';d.core_properties.last_modified_by=''

    def paragraph(text='',bold=False):
        p=d.add_paragraph();p.add_run(text).bold=bold;return p

    def table(headers,rows,widths=None,numeric=()):
        widths=widths or [width_cm/len(headers)]*len(headers)
        # All widths are relative so table geometry always fits the page.
        widths=[v*width_cm/sum(widths) for v in widths]
        t=d.add_table(rows=1,cols=len(headers));t.autofit=False
        pr=t._tbl.tblPr
        borders=OxmlElement('w:tblBorders')
        for side in ('top','left','bottom','right','insideH','insideV'):
            e=OxmlElement('w:'+side);e.set(qn('w:val'),'single');e.set(qn('w:sz'),'4');e.set(qn('w:color'),'D9D9D9');borders.append(e)
        pr.append(borders)
        margin=OxmlElement('w:tblCellMar')
        for side,value in (('top',65),('bottom',65),('left',85),('right',85)):
            e=OxmlElement('w:'+side);e.set(qn('w:w'),str(value));e.set(qn('w:type'),'dxa');margin.append(e)
        pr.append(margin)
        header=OxmlElement('w:tblHeader');t.rows[0]._tr.get_or_add_trPr().append(header)
        for values in rows:
            cells=t.add_row().cells
            for cell,value in zip(cells,values):cell.text=str(value) if value is not None else '—'
        for cell,text in zip(t.rows[0].cells,headers):cell.text=text
        for col,w in zip(t.columns,widths):col.width=Cm(w)
        for ri,row in enumerate(t.rows):
            trpr=row._tr.get_or_add_trPr();trpr.append(OxmlElement('w:cantSplit'))
            for ci,(cell,w) in enumerate(zip(row.cells,widths)):
                cell.width=Cm(w);cell.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
                fill='203D53' if ri==0 else ('F2F5F7' if ri%2==0 else 'FFFFFF')
                shading=OxmlElement('w:shd');shading.set(qn('w:fill'),fill);cell._tc.get_or_add_tcPr().append(shading)
                for p in cell.paragraphs:
                    p.paragraph_format.space_before=Pt(0);p.paragraph_format.space_after=Pt(0)
                    p.paragraph_format.line_spacing=1.05
                    # Keep short engineering tables together. A row at the exact
                    # page boundary can otherwise disappear in LibreOffice's
                    # cantSplit layout despite remaining in the DOCX XML.
                    p.paragraph_format.keep_with_next=(ri < len(t.rows)-1 if len(t.rows)<=10 else ri==0)
                    if ci in numeric:p.alignment=WD_ALIGN_PARAGRAPH.CENTER
                    for run in p.runs:
                        run.font.size=Pt(8.2);run.font.bold=ri==0 or cell.text in _PROBLEM_VERDICTS
                        run.font.color.rgb=RGBColor(255,255,255) if ri==0 else RGBColor(0,0,0)
        after=d.add_paragraph();after.paragraph_format.space_after=Pt(0);after.paragraph_format.space_before=Pt(0)
        after.paragraph_format.line_spacing=1;after.add_run('').font.size=Pt(2)
        return t

    source_codes={};case_codes={}
    def source_code(source):
        if not source:return '—'
        if source not in source_codes:source_codes[source]='R'+str(len(source_codes)+1)
        return source_codes[source]
    def case_code(case):
        if not case:return 'Geral'
        if case not in case_codes:case_codes[case]='C'+str(len(case_codes)+1)
        return case_codes[case]

    views=tuple(views)
    def add_view(index,title,png):
        stream=BytesIO(png);im=Image.from_blob(png)
        image_width=min(width_cm,(13.0 if index==1 else 13.6)*im.px_width/im.px_height)
        p=d.add_paragraph();p.alignment=WD_ALIGN_PARAGRAPH.CENTER
        p.paragraph_format.keep_with_next=True
        p.add_run().add_picture(stream,width=Cm(image_width))
        caption=d.add_paragraph('Figura '+str(index)+'  '+title,style='Caption')
        caption.paragraph_format.keep_with_next=False;caption.paragraph_format.space_after=Pt(7)
        # A readable accessible label survives copying the figure into a larger MC.
        d.inline_shapes[-1]._inline.docPr.set('descr',title)

    d.add_paragraph('Memória de cálculo da viga de rolamento',style='Title')
    if metadata:
        table(('Identificação documental','Valor informado'),[(label,metadata[key]) for key,label in DOCUMENT_FIELDS.items() if key in metadata],(6.3,11.9))
    paragraph('Verificação da viga, do trilho no modelo estrutural e dos detalhes de enrijecimento para as ações e condições descritas a seguir. As bases NBR 10084/8400 e NBR 8800 são mantidas separadas.')
    paragraph('Síntese do cálculo: '+result.status+'.',bold=True)
    paragraph(result_outcome_summary(result))
    if project.demonstration:
        paragraph('Base de demonstração: seção, apoios e condições exemplificativos; não corresponde a um projeto real.')
    d.add_heading('1 Modelo estrutural e geometria',1)
    paragraph('Configuração analisada: ponte apoiada, com rodas sobre trilho na mesa superior da viga de rolamento. Esta memória não abrange ponte suspensa com rodas na mesa inferior nem sua ligação suspensa às vigas de piso.')
    paragraph('Viga de um vão, com análise elástica de pequenos deslocamentos. O eixo longitudinal x tem origem no apoio A; o apoio B situa-se em x = '+decimal(project.span_m)+' m. Os desenhos representam o modelo adotado, e não detalhamento de fabricação.')
    if views:add_view(1,*views[0])
    positions=lambda values:', '.join(decimal(x) for x in values)+' m' if values else 'Somente nos apoios'
    table(('Parâmetro','Valor adotado'),(
        ('Vão entre eixos / comprimento físico',decimal(project.span_m)+' / '+decimal(project.span_m+(project.beam_end_left_mm+project.beam_end_right_mm)/1000)+' m'),
        ('Perfil / fabricação',project.section.name+' / '+{'rolled':'laminado','welded':'soldado'}.get(project.section.fabrication,project.section.fabrication)),
        ('Altura / espessura da alma',decimal(project.section.d_mm)+' / '+decimal(project.section.tw_mm)+' mm'),
        ('Mesa superior / mesa inferior',decimal(project.section.bf_mm)+' × '+decimal(project.section.tf_mm)+' / '+decimal(project.section.bottom_width)+' × '+decimal(project.section.bottom_thickness)+' mm'),
        ('Projeções esquerda / direita',decimal(project.beam_end_left_mm)+' / '+decimal(project.beam_end_right_mm)+' mm'),
        ('Comprimento de contato no apoio',decimal(project.support_bearing_length_mm)+' mm'),
        ('Travamentos da mesa superior',positions(project.upper_braces_m)),
        ('Travamentos da mesa inferior',positions(project.lower_braces_m)),
    ),(6.3,11.9))
    # Keep the remaining figures at readable width rather than distorting them.
    for index,(title,png) in enumerate(views[1:],2):add_view(index,title,png)

    d.add_heading('2 Dados e premissas adotados',1)
    try:
        plate_weight=stiffener_self_weight_metadata(project)
        plate_weight_text=str(plate_weight['pair_count'])+' pares; '+decimal(plate_weight['weight_total_kn'])+' kN'
    except (ValueError,ZeroDivisionError):
        if not result.errors:raise
        plate_weight_text='Não calculado devido a entradas inválidas'
    class_name=lambda value:'Não definido' if value in ('unselected','') else value
    dynamic_text=' / '.join(class_name(value) for value in (project.hoist_class,project.drive_class,project.equipment_group))
    if project.dynamic_psi_override is not None:dynamic_text+='; Ψ direto = '+decimal(project.dynamic_psi_override)
    inputs=[
        ('Propriedades do perfil',project.section.property_source,'Catálogo selecionado' if project.section.property_basis=='catalog' else 'Modelo geométrico da seção'),
        ('Aço / fy / fu',project.material_grade+' / '+decimal(project.material.fy_mpa)+' / '+decimal(project.material.fu_mpa)+' MPa',project.material.specification),
        ('Módulos E / G',decimal(project.material.E_mpa)+' / '+decimal(project.material.G_mpa)+' MPa','Valores adotados no modelo'),
        ('Trilho: largura / altura / inércia',decimal(project.rail.width_mm)+' mm / '+decimal(project.rail.height_mm)+' mm / '+decimal(project.rail.inertia_cm4)+' cm⁴',project.rail.property_source),
        ('Trilho: massa / excentricidade lateral',decimal(project.rail.mass_kg_per_m)+' kg/m / '+decimal(project.rail.lateral_eccentricity_mm)+' mm','Dados do trilho e posição adotada'),
        ('Carga permanente adicional',decimal(project.extra_dead_kn_per_m)+' kN/m','Entrada do projeto'),
        ('Chapas dos enrijecedores',plate_weight_text,'Peso próprio nas posições reais'),
        ('Vida / utilizações por ano',decimal(project.fatigue.life_years)+' anos / '+decimal(project.fatigue.uses_per_year),'Cenário de utilização adotado'),
        ('Passagens por uso: carregadas / vazias',decimal(project.fatigue.loaded_passages_per_use)+' / '+decimal(project.fatigue.empty_passages_per_use),'Cenário de utilização adotado'),
        ('Grupo de fadiga solicitado',project.fatigue.component_group.replace('E8_conservative','E8 conservador').replace('P4_cycles_conservative','P4 com grupo por ciclos'),project.fatigue.group_source or 'Premissa de cálculo; não inferida da capacidade nominal'),
        ('Dinâmica / grupo do equipamento',dynamic_text,('Classes e fator adotados' if project.dynamic_psi_override is not None else 'Classes adotadas')+'; velocidade de elevação '+decimal(project.hoist_speed_m_s)+' m/s'),
    ]
    from .autonomous_actions import APPLICABILITY_OPTIONS
    inputs.append(('Ensaio de carga neste trecho',
        APPLICABILITY_OPTIONS['test_location'][project.action_applicability.test_location],
        'Aplicabilidade informada; NBR 10084:2020, 8.3(c). Não dispensa o ensaio do equipamento nem altera as cargas operacionais.'))
    table(('Dado','Valor ou definição','Origem e condição'),inputs,(4.4,7.3,6.5))
    # The catalog workflow supplies explicit provenance; its absence never implies
    # that manually entered actions have been certified by a manufacturer.
    basis=getattr(project,'equipment_basis',None)
    if basis is not None:
        _add_equipment_basis(d,table,paragraph,project,lambda title,png:add_view(len(views)+1,title,png))
    else:
        paragraph('Ações do equipamento: '+('valores sintéticos de demonstração.' if project.demonstration else 'componentes informadas no projeto; este registro não comprova certificação do fabricante.'))
    premise_rows=[]
    for i,text in enumerate(_unique(result.assumptions),1):
        # Demo status is already prominent above, so it is stated only once.
        if text.startswith('EXEMPLO SINTÉTICO:'):continue
        if basis is not None:
            from .equipment_basis import equipment_basis_summary
            if text in {label+': '+value for label,value in equipment_basis_summary(project)}:continue
            # These provenance labels were renamed while the input values and
            # calculation stayed unchanged. Their current wording is above.
            if basis.horizontal_basis=='normal_reference' and text.startswith('Multiplicador horizontal adotado:'):continue
            if basis.horizontal_basis=='normal_reference' and text.startswith('Ações horizontais de referência para operação normal:'):continue
            if basis.load_model=='symmetric_four_wheel_bridge' and text.startswith('Modelo de quatro rodas:'):continue
        premise_rows.append((str(len(premise_rows)+1),text))
    if premise_rows:
        d.add_heading('Premissas do modelo',2)
        table(('Item','Condição adotada'),premise_rows,(1.2,17.0),(0,))
    from .autonomous_restraint_mode import resistance_lengths_only
    from .autonomous_nominal_lengths import resolve_nominal_lengths
    if resistance_lengths_only(project):
        plan=resolve_nominal_lengths(project)
        paragraph('Travamentos usados somente na resistência: não são apoios intermediários da análise. Solicitações e flechas mantêm o modelo bi-garfo original, sem novas reações ou redistribuição.')
        table(('Modo resistente','Comprimento adotado'),[('Flexão no eixo forte',decimal(plan.major_flexural_mm)+' mm'),('Flexão no eixo fraco',decimal(plan.minor_flexural_mm)+' mm'),('Torção axial',decimal(plan.torsional_mm)+' mm'),('Maior trecho FLT',decimal(max(b-a for a,b in plan.ltb_intervals_mm))+' mm')],(9.1,9.1))
        paragraph('As contenções central e superior coincidentes são requisitos eficazes e independentes para a referência FLT. Não se verifica a resistência/rigidez dos dispositivos nem se presume que os esforços-base envolvam toda redistribuição física possível.')
    if project.lateral_only_braces_m and not resistance_lengths_only(project):
        level={'shear_center':'centro de cisalhamento','upper_flange':'mesa superior','lower_flange':'mesa inferior'}.get(project.lateral_only_brace_level,project.lateral_only_brace_level)
        model={'unselected':'não selecionada','rigid_discrete':'apoio lateral rígido','elastic_discrete':'mola horizontal'}.get(project.lateral_only_brace_model,project.lateral_only_brace_model)
        value=positions(project.lateral_only_braces_m)+'; nível: '+level+'; idealização: '+model
        if project.lateral_only_brace_stiffness_kn_per_mm is not None:value+='; '+decimal(project.lateral_only_brace_stiffness_kn_per_mm)+' kN/mm por apoio'
        paragraph('Contenções horizontais sem crédito de redução de comprimento de flambagem: '+value+'.')

    d.add_heading('3 Ações e combinações',1)
    from .autonomous_actions import test_envelope_summary
    test_rows=test_envelope_summary(project.action_applicability)
    if test_rows:
        table(('Premissa do ensaio','Hipótese e fonte'),test_rows,(4.4,13.8))
        paragraph('O coeficiente de ensaio é uma envoltória de engenharia entre HC1–HC4 na velocidade nominal própria do ensaio, com limite de 1,5 m/s na fórmula. Não confirma a classe física HC4 nem substitui a elegibilidade, o local e a sobrecarga de ensaio. Fonte: NBR 8400-5, 4.1; NBR 8400-1, 6.2.2.1, Tabelas 12/13. Quando p = 1,30 for adotado, ele limita os mínimos tabelados, não uma sobrecarga real maior.')
    horizontal_text=('As componentes horizontais seguem o cenário e a repartição documentados na seção 2.' if basis is not None and basis.horizontal_basis=='normal_reference' else 'As forças horizontais incluem a dinâmica horizontal e a distribuição adotadas na entrada.')
    paragraph('As componentes por roda são características. G é a parcela permanente do equipamento, Q é a carga içada, HT é a ação transversal e HL é a ação longitudinal. '+horizontal_text)
    table(('Roda','Posição\n(m)','G\n(kN)','Q\n(kN)','HT\n(kN)','HL\n(kN)'),[(str(i+1),decimal(w.offset_m),decimal(w.dead_kn),decimal(w.lifted_kn),decimal(w.transverse_kn),decimal(w.longitudinal_kn)) for i,w in enumerate(project.wheels)],(1.2,2.2,3.2,3.2,3.2,3.2),range(6))
    paragraph('Os multiplicadores abaixo já contêm a dinâmica vertical aplicável; não se aplica novamente o impacto. O cálculo varre posições e sentidos das rodas. Cada linha mantém sua própria base de ações e resistências.')
    factors=[];seen=set()
    for case in result.cases:
        f=case.get('factors',{});keys=('dead_support','dead_equipment','lifted','transverse','longitudinal')
        key=(case.get('family'),*(f.get(k) for k in keys),f.get('source'))
        if key in seen:continue
        seen.add(key)
        label=_REPORT_FAMILY_LABELS.get(case.get('family'),case.get('family',''))
        factors.append((label,*(decimal(f.get(k)) for k in keys),source_code(f.get('source',''))))
    if factors:table(('Base','G viga','G ponte','Q içada','HT','HL','Ref.'),factors,(6.0,2,2,2,2,2,1.6),range(1,7))
    if project.factor_basis:paragraph('Base de seleção dos coeficientes: '+project.factor_basis+'.')

    d.add_heading('4 Resultados das verificações',1)
    paragraph('A utilização η é a razão entre solicitação e resistência ou limite na mesma base. O atendimento numérico corresponde a η ≤ 1,00. Os valores são arredondados apenas para apresentação; a classificação usa a precisão integral.')
    selected=[c for c in report_checks(result) if not (c.mechanism in ('actions','equilibrium','moving_envelope') and c.verdict=='ATENDE')]
    family_rows=[]
    for mechanism,label in MECHANISM_LABELS.items():
        checks=[c for c in result.checks if c.mechanism==mechanism]
        adverse=[c for c in checks if c.verdict in _PROBLEM_VERDICTS]
        state=('NÃO ATENDE' if any(c.verdict=='NÃO ATENDE' and not sufficient_bound_exceeded(c) for c in checks) else 'INCONCLUSIVO' if any(sufficient_bound_exceeded(c) for c in checks) else 'FORA DO DOMÍNIO' if any(c.state=='unsupported' for c in checks) else 'PENDENTE' if not checks or any(c.state=='pending' for c in checks) else 'NÃO SE APLICA' if all(c.state=='not_applicable' for c in checks) else 'ATENDE')
        # A missing independent obligation takes precedence over an apparently
        # passing sample, including when other rows in that family were computed.
        missing=any(result.required_check_scopes.get(issue['id'],{}).get('mechanism')==mechanism for issue in result.coverage_issues)
        if missing and state in ('ATENDE','NÃO SE APLICA'):state='PENDENTE'
        max_eta=max((c.utilization for c in checks if c.utilization is not None),default=None)
        counts=[]
        if adverse:counts.append(str(len({(c.title,c.state) for c in adverse}))+(' critério com restrição' if len({(c.title,c.state) for c in adverse})==1 else ' critérios com restrição'))
        if missing:counts.append('cobertura incompleta')
        family_rows.append((label.capitalize(),decimal(max_eta) if max_eta is not None else '—',state,'; '.join(counts) or (str(len(checks))+(' registro' if len(checks)==1 else ' registros') if checks else 'Sem registro')))
    table(('Família de verificação','η máx.','Situação','Cobertura'),family_rows,(7.3,1.6,3.2,6.1),(1,2))
    d.add_heading('Critérios governantes',2)
    paragraph('São apresentados os máximos por família e base de combinação, acrescidos de todos os critérios distintos não atendidos, pendentes ou fora do domínio. O CSV reúne os critérios individuais governantes; todos os casos permanecem no JSON de cálculo. C identifica o caso e R identifica a referência, relacionados ao final.').paragraph_format.keep_with_next=True
    rows=[]
    for c in selected:
        trace=_unique((_REPORT_FAMILY_LABELS.get(_case_family(result,c),_case_family(result,c)),case_code(c.case),source_code(c.source)))
        label=display_title(c.title)+'\n'+' · '.join(trace)
        unit='—' if c.unit in ('','adimensional','ratio','relative') else c.unit
        rows.append((label,report_decimal(c.demand),report_decimal(c.capacity),unit,('<0,01' if c.utilization is not None and 0<c.utilization<.005 else report_decimal(c.utilization)),display_verdict(c)))
    if rows:table(('Critério e rastreabilidade','Solicitação','Resistência\nou limite','Unid.','η','Resultado'),rows,(8.3,2,2.2,1.3,1.3,3.1),(1,2,3,4,5))
    if result.errors:
        d.add_heading('Entradas que precisam de correção',2)
        for text in _unique(result.errors):paragraph(text)
    coverage=_coverage_rows(result)
    if coverage:
        d.add_heading('Cobertura ainda necessária',2)
        table(('Família','Pendência','Qtde.'),coverage,(5.0,11.7,1.5),(2,))
    # Only material conditions are repeated alongside results. Generic messages
    # and successful computational bookkeeping stay in the audit exports.
    notes=[]
    for c in selected:
        location=critical_description(result,c)
        reason=_concise_reason(c)
        if c.verdict in _PROBLEM_VERDICTS and (reason or location):
            note=' '.join(x for x in (reason,location) if x)
            notes.append((c.title,note))
    if notes:
        d.add_heading('Condições dos critérios com restrição',2)
        grouped={}
        for title,note in notes:grouped.setdefault(note,[]).append(title)
        for note,titles in grouped.items():
            p=paragraph();p.add_run(_group_titles(titles)+': ').bold=True;p.add_run(note)

    d.add_heading('5 Detalhes de enrijecedores e soldas',1)
    detail=result.numerical_evidence.get('fixed_stiffener_weld_detail',{})
    from .autonomous_fullheight_actions import enabled as fullheight_enabled
    if fullheight_enabled(project):
        from .autonomous_fullheight_runtime import resolved_detail,pair_mass,longitudinal_mass
        physical=resolved_detail(project);mass=pair_mass(project);longmass=longitudinal_mass(project)
        paragraph('Família de projeto de altura total em perfil I soldado. Os intermediários estabilizam os painéis; os pares dos apoios recebem a função bearing separada. As contenções intermediárias ligam diretamente à mesa e entram somente nos comprimentos resistentes, sem novas reações de análise nos enrijecedores.')
        table(('Componente','Detalhe especificado'),[
            ('Chapas',decimal(physical.plate_thickness_mm)+' mm × '+decimal(physical.outstand_mm)+' mm salientes por lado'),
            ('Recortes superior / inferior',decimal(physical.upper_cope.radius_mm)+' / '+decimal(physical.lower_cope.radius_mm)+' mm; folga '+decimal(physical.upper_cope.clearance_mm)+' mm; acabamento sem entalhes'),
            ('União superior do enrijecedor','CJP com preparo K e goivagem; qualidade QE; reforço geométrico '+decimal(physical.top_cjp.reinforcement_leg_mm)+' mm'),
            ('União à alma','Dois filetes contínuos, perna '+decimal(physical.web_fillets.leg_mm)+' mm; QC no trecho reto e QE nas terminações'),
            ('União à mesa inferior','Dois filetes contínuos, perna '+decimal(physical.bottom_attachment.leg_mm)+' mm; QE; sem contato ajustado presumido'),
            ('Juntas longitudinais alma–mesas','CJP com preparo K e goivagem; qualidade '+physical.section.longitudinal_top.quality.grade+' superior e '+physical.section.longitudinal_bottom.quality.grade+' inferior'),
            ('Peso próprio adicionado','Par físico: '+decimal(mass['total_mass_kg'])+' kg por estação; juntas longitudinais: incremento '+decimal(longmass['total_mass_kg'])+' kg no comprimento físico'),
        ],(5.0,13.2))
        paragraph('Recortes, preparo, soldas e controle de qualidade são especificações editáveis desta proposta de projeto, não comprovação de execução. O piso local de 45 kN é verificado uma vez por ligação de chapa, sem adicioná-lo à gravidade global ou à faixa de fadiga. Não se credita aumento de rigidez global por essas chapas.')
    else:
        connections={x.get('connection'):x for x in detail.get('connections',[])}
        weld_rows=[]
        for label,requested,record,applicable in (
            ('Contínua alma–mesa',project.flange_web_weld_min_leg_mm,result.numerical_evidence.get('fixed_flange_web_weld_detail',{}),project.section.fabrication=='welded'),
            ('Enrijecedor–mesas',project.stiffener_flange_weld_min_leg_mm,connections.get('mesa',{}),True),
            ('Enrijecedor–alma',project.stiffener_web_weld_min_leg_mm,connections.get('alma',{}),True),
        ):
            design=record.get('design') or record.get('limiting_design')
            adopted='Não aplicável' if not applicable else decimal(design['leg_mm'])+' mm'+(' · geometria limite' if not record.get('design') else '') if design else 'Não definida'
            weld_rows.append((label,decimal(requested)+' mm' if requested else 'Automático',adopted))
        table(('Ligação','Perna mínima solicitada','Perna adotada'),weld_rows,(6.1,5.2,6.9),(1,2))
        paragraph('O detalhe fixo é usado tanto na resistência quanto na fadiga. Uma geometria limite é apresentada apenas para diagnóstico; sua adoção depende do atendimento dos critérios indicados nos resultados.')

    d.add_heading('6 Conclusão',1)
    paragraph(result.status+'.',bold=True)
    paragraph(result_outcome_summary(result))
    if result.errors:
        paragraph('As entradas listadas na seção de resultados devem ser corrigidas antes da utilização desta memória como verificação do elemento.')
    failed=[c for c in summary_checks(result) if c.verdict=='NÃO ATENDE']
    unresolved=[c for c in summary_checks(result) if c.state in ('pending','unsupported')]
    if failed:
        paragraph('Os seguintes critérios exigem revisão da solução ou avaliação complementar compatível com o projeto:')
        conclusion_rows=[]
        for mechanism in MECHANISM_LABELS:
            titles=_unique(display_title(c.title) for c in failed if c.mechanism==mechanism)
            if titles:
                conclusion_rows.append((MECHANISM_LABELS[mechanism].capitalize(),'; '.join(_criterion_lines(titles))+'.'))
        table(('Família','Critérios não atendidos ou não comprovados'),conclusion_rows,(4.4,13.8))
        if any(sufficient_bound_exceeded(c) for c in failed):
            paragraph('Nas verificações por limites conservadores, a excedência indica não atendimento ao critério adotado, e não uma demonstração de ruptura física. O atendimento não pode ser declarado sem resolver essas excedências.')
    if unresolved:
        conclusion_rows=[]
        for mechanism in MECHANISM_LABELS:
            titles=_unique(display_title(c.title)+' ('+c.verdict.lower()+')' for c in unresolved if c.mechanism==mechanism)
            if titles:
                conclusion_rows.append((MECHANISM_LABELS[mechanism].capitalize(),'; '.join(_criterion_lines(titles))+'.'))
        table(('Família','Critérios pendentes ou fora do domínio'),conclusion_rows,(4.4,13.8))
    pending_families=_unique([row[0] for row in coverage]+[MECHANISM_LABELS[m].capitalize() for m in result.missing_mechanisms])
    if pending_families:paragraph('A cobertura ainda deve ser concluída em: '+', '.join(pending_families)+'. As pendências e obrigações correspondentes estão discriminadas na seção 4.')
    if result.complete and not failed:
        paragraph('A viga atende às verificações implementadas para o modelo, os dados e os detalhes aqui declarados. A conclusão não se estende a alterações de geometria, cargas, vínculos ou detalhes, nem a elementos externos ao escopo desta memória.')
    elif not result.complete:
        paragraph('A verificação permanece incompleta; resultados atendidos isoladamente não constituem aprovação global da viga.')
    if basis is not None and getattr(basis,'status','manual') in ('adopted_assumption','reference_only'):
        paragraph('A conclusão está condicionada às premissas do equipamento documentadas na seção 2.')
    if basis is not None and getattr(basis,'horizontal_basis','manual')=='normal_reference':
        paragraph('Esta conclusão refere-se ao cenário horizontal '+basis.horizontal_scenario_id+'. O cenário complementar deve ser verificado separadamente; este relatório não combina os dois históricos de fadiga.')
    if project.demonstration:paragraph('Por se tratar de base demonstrativa, este resultado não deve ser usado como verificação de uma ponte real.')

    d.add_heading('7 Referências e rastreabilidade',1)
    if case_codes:
        table(('Caso','Descrição'),[(code,case_label(result,case)) for case,code in case_codes.items()],(1.2,17.0))
    if source_codes:
        if len(source_codes)<=3:
            for source,code in source_codes.items():paragraph(code+'  '+display_source(source))
        else:
            table(('Ref.','Base normativa ou método'),[(code,display_source(source)) for source,code in source_codes.items()],(1.2,17.0))
    numerical=[v for v in result.numerical_evidence.values() if isinstance(v,dict) and 'converged' in v]
    if controls is not None:
        control=result.numerical_evidence['calculation_controls']
        paragraph('Orçamento numérico: até '+str(control['max_refinements'])+' refinamentos; tolerância '+f"{100*control['sampling_tolerance']:g}".replace('.',',')+'%; 2 rodadas estáveis sucessivas; parada antecipada por convergência.')
    if numerical:
        paragraph('Controle numérico: '+str(len(numerical))+' casos, '+str(sum(bool(row['converged']) for row in numerical))+' com convergência. Maior variação relativa final: '+decimal(max((row.get('relative_change') or 0) for row in numerical)*100)+'%.')
    from . import __version__
    footer=sec.footer.paragraphs[0]
    footer.paragraph_format.space_after=Pt(0);footer.paragraph_format.line_spacing=1
    footer.add_run('LRO '+__version__+' · projeto formato '+str(project.schema_version)+'\nIdentificador das entradas: '+result.input_signature).font.size=Pt(7)
    out=BytesIO();d.save(out);return out.getvalue()


def report_decimal(value):
    """Do not print a positive small demand/limit as zero."""
    if value is None:return '—'
    if 0<abs(value)<.005:return f'{value:.2e}'.replace('.',',')
    return decimal(value)


def display_source(source):
    return (source.replace('gamma_a1','γa1').replace('sigma_a','σa').replace('gamma>=','γ ≥ ')
            .replace('gross yielding only; stability separate','somente escoamento da área bruta; estabilidade verificada separadamente').replace('and 5.2.5(a): An=Ag, Ct=1 for this wholly directly connected no-hole section','e 5.2.5(a): An=Ag, Ct=1 para esta seção integralmente conectada e sem furos').replace('BEARING_FATIGUE_DETAIL_ADDENDUM 2026-10-17','detalhe nominal de apoio adotado em 17/10/2026').replace('chi<=','χ ≤ ').replace('nu_E','νE').replace('nu,','ν,').replace('max(1.10,','max(1,10; '))


def _criterion_lines(titles):
    titles=_unique(titles)
    fatigue_regions=[t for t in titles if t.startswith('Cobertura de fadiga: ')]
    if len(fatigue_regions)>3:
        titles=[t for t in titles if t not in fatigue_regions]+[str(len(fatigue_regions))+' regiões de fadiga dos enrijecimentos, discriminadas nos critérios governantes da seção 4']
    groups={}
    for title in _unique(titles):
        head,separator,tail=display_title(title).partition(' · ')
        groups.setdefault(head,[])
        if separator:groups[head].append(tail)
    return [head+(': '+'; '.join(_unique(tails)) if tails else '') for head,tails in groups.items()]


def _group_titles(titles):
    return '; '.join(_criterion_lines(titles))


def _add_equipment_basis(document,table,paragraph,project,add_figure=None):
    """Use catalog provenance without turning a reference into certification."""
    from .equipment_basis import equipment_basis_summary
    from .crane_equipment_report import equipment_narrative,equipment_schematic,concise_basis_note
    basis=project.equipment_basis
    rows=equipment_basis_summary(project)
    if not rows:
        if not project.demonstration:
            document.add_heading('Ponte rolante: dados do equipamento',2)
            for text in equipment_narrative(project):paragraph(text)
        return
    document.add_heading('Ponte rolante: referência e ações adotadas',2)
    for text in equipment_narrative(project):paragraph(text)
    png=equipment_schematic(project) if add_figure else None
    if png:add_figure('Ponte, carro e distribuição vertical entre os caminhos de rolamento',png)
    # Summary retains exact capacity/span matching and post-proposal edits.
    import re
    numeric_labels=('Capacidade nominal','Vão da ponte entre trilhos','Faixa de vão da referência','Classificação adotada','Dinâmica vertical adotada','Multiplicador horizontal adotado','Fator adicional horizontal')
    narrative_labels=('Situação','Capacidade nominal','Vão da ponte entre trilhos','Registro de referência','Fonte','Carro/talha da referência','Massas adotadas','Geometria adotada','Base vertical das ações horizontais')
    rows=[(label,concise_basis_note(project) if label=='Base declarada' else re.sub(r'(?<=\d)\.(?=\d)',',',value) if label in numeric_labels else value) for label,value in rows if label not in narrative_labels]
    if basis.load_model=='symmetric_four_wheel_bridge':
        for name,label,unit in (
            ('transverse_kn_per_wheel','Parcela transversal do carro por roda' if basis.horizontal_basis=='normal_reference' else 'Ação horizontal transversal por roda','kN'),
            ('longitudinal_kn_per_wheel','Ação horizontal longitudinal por roda','kN'),
        ):
            value=getattr(basis,name,None)
            rows.append((label,decimal(value)+' '+unit if value is not None else 'Não informado'))
        if basis.horizontal_basis=='normal_reference':
            from .crane_horizontal_reference import SOURCE_ACCELERATION,SOURCE_ROLLING
            rows.extend([
                ('Parcela de guiamento por roda',decimal(basis.rolling_kn_per_wheel)+' kN; sinais opostos nas duas rodas'),
                ('Base da proposta horizontal','Antes do fator adicional: HL = 0,25 P e guiamento = λP. P = G + Q por roda adotado como hipótese de projeto para este cenário.'),
                ('Composição horizontal','HT = parcela do carro ± guiamento; os sinais e valores resultantes do cenário constam na tabela de rodas. HL considera todas as rodas motrizes/freadas.'),
                ('Repartição adotada','100% da resultante transversal do carro no caminho analisado, repartida igualmente nas suas duas rodas.'),
                ('Escopo das ações horizontais','Operação normal nas condições adotadas. Ensaio, frenagem de emergência, batente, parada com oscilação da carga e outros efeitos fora dessas hipóteses exigem qualificação própria; não se trata de limite universal de todos os eventos.'),
                ('Referências das ações horizontais',SOURCE_ACCELERATION+'; '+SOURCE_ROLLING),
            ])
    if rows:
        document.add_heading('Condições complementares do equipamento',2)
        table(('Dado','Origem ou valor adotado'),rows,(5.6,12.6))
