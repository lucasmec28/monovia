"""Nominal full-height welded-I fatigue: audited bounds in distinct bodies.

This consumer never calls a moving-load producer, constructs a time history,
converts a rolled/CISC field, or upgrades a selected duty or weld quality.
Every rectangular box below is an absolute-bound relaxation at EACH fixed
material point in the declared finite region, not a physical stress history.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from math import isfinite, sqrt
import json

from .autonomous_cases import generate_basic_cases
from .autonomous_fatigue import elastic_allowables_autonomous
from .autonomous_result import Verification, input_signature
from .autonomous_stiffener_actions import stiffener_station_geometry
from .autonomous_fullheight_bearing import bearing_reaction_unit_field
from .autonomous_fullheight_detail import (
    FullHeightNominalDetail, resolve_fullheight_detail, fullheight_geometry,
    fullheight_detail_assessment, fullheight_bearing_geometry,
)
from .stress_8400 import HIGH_GRADES, LOW_GRADES, W0_HIGH_MPA, W0_LOW_MPA, K0_MPA, K4_MPA
from top_unstiffened_candidate.stiffeners.fatigue import K1_MPA, K3_MPA
from underslung_runway_candidate.fatigue.nbr_member import (
    ACTION_BASIS, KAPPA_POLICY, SOURCE_SHA256, d5_interval_bound,
)

# Corrected primary Table D.1, printed p.60/PDF71. Parenthesized theoretical
# values stay capped by 0.75fu and the Case-I elastic limit; no second 4/3.
K2_MPA = (271.4, 220.3, 178.8, 145.1, 117.8, 95.6, 77.6, 63.0)
METRICS = ('web_sigma_abs_upper_bound_mpa', 'flange_sigma_abs_upper_bound_mpa',
    'web_shear_magnitude_upper_bound_mpa', 'flange_shear_magnitude_upper_bound_mpa',
    'local_transverse_bound_mpa', 'local_shear_bound_mpa',
    'local_longitudinal_compression_bound_mpa', 'combined_web_longitudinal_bound_mpa',
    'combined_web_shear_bound_mpa')
CASE = 'FAT8400_LIFETIME'
SOURCE = ('ABNT NBR 8400-2:2019 corrigida 20.10.2022, D.1/Tabela D.1 p.60, '
    'D.2.2–D.2.3/D.5 pp.62–63, D.3.1 p.65, D.3/Tabela D.3 p.67, '
    'D.5 K0,31/K0,33 p.69; K1,2 p.70; K2,2 p.72; K2,41 p.73; '
    'K3,21 p.74; K3,35/K3,41 p.75; K4,41/K4,5 p.77; K2,5 p.73; FULLHEIGHT_DETAIL_CONTRACT 2026-10-17')
BOUND_SOURCE = ('Limites globais/locais previamente auditados do produtor autônomo NBR10084/Vlasov, '
    'reutilizados como limite espacial uniforme em cada ponto dos pés finitos. '
    'Máximos de componentes são uma relaxação conservadora, não história assinada nem tensor coexistente.')
FLANGE_ZERO_SOURCE = ('Recuperação nominal de flexão longitudinal da mesa xy no modelo autônomo: '
    'a segunda normal não é uma componente calculada deste modelo. Inatividade nominal explícita, '
    'não afirmação de sigma_y física nula; transferência transversal adicional exige ramo próprio.')
TABLES = {'K0,31': K0_MPA, 'K0,33': K0_MPA, 'K1,2': K1_MPA, 'K2,2': K2_MPA,
          'K2,41': K2_MPA, 'K3,21': K3_MPA, 'K3,35': K3_MPA, 'K3,41': K3_MPA, 'K4,41': K4_MPA, 'K4,5': K4_MPA, 'K2,5': K2_MPA}
REGION_IDS = ('fullheight_web_ordinary', 'fullheight_flange_top_ordinary',
    'fullheight_flange_bottom_ordinary', 'fullheight_web_straight',
    'fullheight_web_termination_top', 'fullheight_web_termination_bottom',
    'fullheight_top_cjp_receiver', 'fullheight_bottom_fillet_receiver',
    'fullheight_longitudinal_web_top', 'fullheight_longitudinal_web_bottom',
    'fullheight_longitudinal_flange_top', 'fullheight_longitudinal_flange_bottom',
    'fullheight_longitudinal_cjp_throat_top', 'fullheight_longitudinal_cjp_throat_bottom')


_BASE_CHECKS = ('normal_longitudinal', 'shear', 'combined')
_TWO_NORMAL_REGIONS = frozenset(('fullheight_web_ordinary', 'fullheight_web_straight',
    'fullheight_web_termination_top', 'fullheight_web_termination_bottom',
    'fullheight_longitudinal_web_top', 'fullheight_longitudinal_web_bottom',
    'fullheight_longitudinal_cjp_throat_top', 'fullheight_longitudinal_cjp_throat_bottom'))
REGION_CHECKS = {key: (('normal_longitudinal', 'normal_transverse', 'shear', 'combined')
    if key in _TWO_NORMAL_REGIONS else _BASE_CHECKS) +
    (('weld_static_comparison',) if 'cjp_throat' in key else ()) for key in REGION_IDS}
BEARING_REGION_CHECKS = {'fullheight_bearing_plate_lower': _BASE_CHECKS,
    'fullheight_bearing_weld_lower': _BASE_CHECKS+('weld_static_comparison',),
    'fullheight_bearing_plate_web': _BASE_CHECKS,
    'fullheight_bearing_plate_top': _BASE_CHECKS,
    'fullheight_bearing_weld_web': _BASE_CHECKS+('weld_static_comparison',),
    'fullheight_bearing_weld_top': _BASE_CHECKS+('weld_static_comparison',),
    'fullheight_bearing_receiver_web_composition': ('local_global_composition',),
    'fullheight_bearing_receiver_top_composition': ('local_global_composition',),
    'fullheight_bearing_receiver_bottom_composition': ('local_global_composition',)}
RECEIVER_SCOPE_SHA256 = 'b27b53819571e7b88382a0abd656179ce3b1504d0dae02d654bd476d32bb2b42'
RECEIVER_SCOPE_SOURCE = ('BEARING_RECEIVER_FATIGUE_SCOPE_QUALIFICATION 2026-10-17; '
    'Fisher/Van de Pas 2002 pp.68–69; detalhes nominais direcionais e transferência própria em série')
REACTION_BOUND_BASIS = 'absolute_total_CaseI_reaction_bound'

BEARING_EXIT_PREFIXES = tuple(k for k in BEARING_REGION_CHECKS if not k.endswith('_lower'))
BEARING_ADDENDUM_SHA256 = 'a15839068bb0bf5fac43e1df6ee5db402f175fdeb36de73f9ee224e932bdcf22'
BEARING_EXIT_SOURCE = ('BEARING_FATIGUE_DETAIL_ADDENDUM 2026-10-17 §§7.1/7.3; '
    'K4,5 D.5 p.77/PDF89 e K2,5 p.73/PDF85; D.3 p.65/PDF77; '
    'grupo nominal de saída em série, Rz real, momento da banda inferior preservado')
BEARING_SOURCE = ('BEARING_FATIGUE_DETAIL_ADDENDUM 2026-10-17 §§1–2/7.3; '
    'NBR8400-2 D.5 K4,41 p.77/PDF89, correspondência geométrica local T por rotação x→y; '
    'D.4.2.1.1 pp.79–80 e D.3.1 pp.65; reação original do apoio, sem P/2 de rodas')


def required_fullheight_fatigue_regions(project):
    """Independent physical inventory, never inferred from calculated output."""
    return tuple(REGION_IDS)+tuple(prefix+'/'+v['station_id']
        for v in stiffener_station_geometry(project) if v['kind'] != 'intermediate'
        for prefix in BEARING_REGION_CHECKS)


def required_fullheight_fatigue_checks(project):
    """Stable coverage IDs; only a vanished QC interior permits non-applicability."""
    rows = []
    for region in required_fullheight_fatigue_regions(project):
        checks = REGION_CHECKS.get(region)
        if checks is None:
            checks = next(v for prefix, v in BEARING_REGION_CHECKS.items() if region.startswith(prefix+'/'))
        for check in checks:
            rows.append(dict(id='fatigue/'+region+'/'+check+'/'+CASE, region=region, check_id=check,
                mechanism='fatigue', case=CASE, summary=False,
                allow_not_applicable=region == 'fullheight_web_straight'))
    return tuple(rows)


@dataclass(frozen=True)
class FullHeightRegionIdentity:
    """One physical line/face plus finite support of the nominal bound."""
    body: str
    station_id: str
    line_id: str
    face: str
    weld_axis: str
    plane: str
    bounds_mm: tuple[tuple[float, float], tuple[float, float], tuple[float, float]]
    material_id: str
    thickness_mm: float
    geometry_weld_hash: str
    quality: str
    detail_source: str

    def __post_init__(self):
        for key in ('body', 'station_id', 'line_id', 'face', 'weld_axis', 'plane',
                    'material_id', 'geometry_weld_hash', 'quality', 'detail_source'):
            _text(getattr(self, key), key)
        if self.plane not in ('xz', 'xy', 'yz'):
            raise ValueError('Plano nominal não suportado.')
        _number(self.thickness_mm, 'Espessura física', positive=True)
        if type(self.bounds_mm) is not tuple or len(self.bounds_mm) != 3:
            raise ValueError('Três intervalos espaciais físicos obrigatórios.')
        for pair in self.bounds_mm:
            if type(pair) is not tuple or len(pair) != 2:
                raise ValueError('Intervalo espacial inválido.')
            lo, hi = (_number(v, 'Coordenada', signed=True) for v in pair)
            if lo > hi:
                raise ValueError('Limites espaciais invertidos.')


def _number(value, label, *, positive=False, signed=False):
    if type(value) not in (int, float) or not isfinite(value) or abs(value) > 1e50:
        raise ValueError(label+': número finito obrigatório; bool não é número.')
    if positive and value <= 0 or not signed and value < 0:
        raise ValueError(label+': sinal fora do domínio.')
    return float(value)


def _text(value, label):
    if type(value) is not str or not value.strip():
        raise ValueError(label+': fonte/descrição explícita obrigatória.')
    return value


def _pending(output, ident, reason, *, evidence=None):
    if reason not in output['pending']:
        output['pending'].append(reason)
    output['verifications'].append(Verification('fatigue/'+ident+'/'+CASE, 'fatigue',
        'Full-height · domínio nominal', 'pending', SOURCE, CASE, reason=reason,
        evidence=evidence or {}))


def _quality_issues(assessment, prefixes):
    return [reason for reason in assessment['pending']
            if any(reason.startswith(prefix+':') for prefix in prefixes)]


def _region_result(project, detail, name, identities, demands, classes, *,
                   group_selection, quality_pending=(), weld=False, transfer=None,
                   material=None, capacity_materials=(), component_axes=None,
                   weld_normal_perpendicular_first=False):
    """Directional capacities and the existing D.5 vertex kernel, κ=-1 only."""
    s, m = detail.section, material or detail.section.material
    fy = min(v.fy_mpa for v in (m,)+tuple(capacity_materials))
    fu = min(v.fu_mpa for v in (m,)+tuple(capacity_materials))
    group = group_selection['component_group']; index = int(group[1:])-1
    grade = m.material_id
    pending = list(quality_pending)
    if not identities:
        return dict(kind='fullheight_directional_nominal_region', domain_complete=True,
            checks=[], pending=[], domain_pending=[], errors=[], criterion_exceedances=[],
            status='NOT_APPLICABLE_NO_STRAIGHT_INTERIOR', locations=[],
            reason='Zonas Q.E. dos términos sobrepostas; nenhum interior reto fora delas.')
    if grade not in LOW_GRADES+HIGH_GRADES or not 370 <= fu <= 520:
        raise ValueError('Material NBR8400 não suportado; não inferir equivalência de grau.')
    if any(row.thickness_mm > 50 for row in identities) and any(c != 'W0' for c in classes if c):
        pending.append('Chapa soldada acima de 50 mm exige qualificação especializada de fabricação/ensaios.')
    w0 = (W0_LOW_MPA if grade in LOW_GRADES else W0_HIGH_MPA)[index]
    elastic = elastic_allowables_autonomous(fy, fu, 'I')
    normal_cap = min(.75*fu, elastic['sigma_a_mpa'])
    cx = min(w0 if classes[0] == 'W0' else TABLES[classes[0]][index], normal_cap)
    cy = None if classes[1] is None else min(w0 if classes[1] == 'W0' else TABLES[classes[1]][index], normal_cap)
    ct = min(w0/sqrt(3), .75*fu/sqrt(3), elastic['tau_a_mpa'])
    transverse_static = None
    if weld:
        # D.3.1 and 5.2.2.3: deposited-metal shear, never W0/sqrt(3).
        transverse_static = min(113*fy/240, 170*fy/355, normal_cap)
        if cy is not None:
            cy = min(cy, transverse_static)
        if weld_normal_perpendicular_first:
            cx = min(cx, transverse_static)
        ct = min(K0_MPA[index]/sqrt(2), normal_cap/sqrt(2), transverse_static)
    sx, sz, tau = (_number(v, name+' demand') for v in demands)
    if cy is None and sz != 0:
        raise ValueError('Normal paralela não classificada não pode receber demanda apagada.')
    # The symmetric boxes are SET relaxations of supplied absolute bounds,
    # explicitly not a temporal cycle, stress range, or sign reconstruction.
    bound = d5_interval_bound((-sx, sx), (-sz, sz), (-tau, tau),
        normal_x_capacity_mpa=cx, normal_y_capacity_mpa=cx if cy is None else cy,
        shear_capacity_mpa=ct)
    if cy is None:
        bound['capacities_mpa']['sigma_y'] = None
        bound['inactive_parallel_normal_normalization_only'] = True
    checks = []
    values = [('normal_longitudinal', sx, cx, 'MPa'),
              ('shear', tau, ct, 'MPa'),
              ('combined', bound['combined_utilization_upper_bound'], 1., '—')]
    if cy is not None:
        values.insert(1, ('normal_transverse', sz, cy, 'MPa'))
    if weld:
        values.append(('weld_static_comparison', sqrt(sx*sx+sz*sz+sx*sz+2*tau*tau),
                       transverse_static, 'MPa'))
    for ident, demand, capacity, unit in values:
        exceeded = demand > capacity
        checks.append(dict(id=ident, name=ident, demand=demand, capacity=capacity,
            utilization=demand/capacity, unit=unit, source=SOURCE,
            status='ENVELOPE EXCEDIDO' if exceeded else 'ATENDE AO LIMITE SUFICIENTE',
            formula=bound['formula'] if ident == 'combined' else
                'sqrt(Sx²+Sz²+Sx*Sz+2T²) <= limite estático da solda' if ident == 'weld_static_comparison' else
                'limite absoluto / capacidade direcional em kappa=-1 <= 1',
            detail='Limite suficiente excedido; não prova falha física.' if exceeded else
                'Resultado nominal condicionado ao domínio e à fabricação especificados.',
            conservative_exceedance=exceeded, exceedance_policy='requires_specific_assessment'))
    return dict(kind='fullheight_directional_nominal_region', domain_complete=not pending,
        status='APPLICABILITY_PENDING' if pending else 'INCONCLUSIVE_SUFFICIENT_BOUND' if any(c['utilization'] > 1 for c in checks)
            else 'SUFFICIENT_NOMINAL_BOUND_SATISFIED',
        checks=checks, pending=pending, domain_pending=pending, errors=[],
        criterion_exceedances=[c['id'] for c in checks if c['utilization'] > 1],
        locations=[asdict(row) for row in identities], bound=bound,
        capacity=dict(normal_longitudinal_mpa=cx, normal_transverse_mpa=cy, shear_mpa=ct,
            normal_longitudinal_detail=classes[0], normal_transverse_detail=classes[1],
            shear_detail='K0/sqrt(2)_WELD' if weld else 'W0/sqrt(3)_BASE',
            component_group=group, adopted_resistance_kappa=-1., actual_history_kappa=None,
            thickness_mm=identities[0].thickness_mm, material=asdict(m),
            capacity_fy_mpa=fy, capacity_fu_mpa=fu, additional_capacity_materials=[asdict(v) for v in capacity_materials]),
        component_axes=component_axes or ('x', 'y' if identities[0].plane == 'xy' else 'z'),
        group_selection=dict(group_selection), source_contract=dict(source=SOURCE, primary_pdf_sha256=SOURCE_SHA256),
        transfer_stresses=transfer, input_bounds_mpa=dict(longitudinal=sx, transverse=sz, shear=tau),
        input_bound_kind='absolute_stress_bounds_not_ranges_or_histories',
        spatial_coverage_source=BOUND_SOURCE,
        nominal_zero_source=(FLANGE_ZERO_SOURCE if identities[0].plane == 'xy' else
            'Segunda normal inativa apenas no corte nominal identificado; não afirmação de ausência física em toda a chapa. Componentes reais adicionais são preservadas no domínio próprio.') if cy is None else None,
        static_075_factor_applied_to_fatigue=False, uses_fabricated_history=False,
        actual_failure_proven=False, concurrent_tensor_claimed=False,
        as_built_execution_verified=False, whole_station_qualified=False,
        weld_throat_fatigue_verified=bool(weld and not pending and not any(c['utilization'] > 1 for c in checks)),
        conditional_numeric_checks_retained=bool(pending))



def _append_region_result(out, key, result, detail_hash, group_selection, expected_checks):
    out['regions'][key] = result
    for check in result.get('checks', ()):
        exceeded = check['utilization'] is not None and check['utilization'] > 1
        receipt = check.get('dependency_receipt', False)
        state = 'pending' if receipt and not result['domain_complete'] else 'calculated'
        out['verifications'].append(Verification('fatigue/'+key+'/'+check['id']+'/'+CASE,
            'fatigue', key+' · '+check['name'], state, check.get('source', SOURCE), CASE,
            check['demand'], check['capacity'], check['unit'], check['utilization'], check['detail'],
            dict(region=key, conservative_envelope=True, conservative_exceedance=exceeded,
                actual_failure_proven=False, domain_complete=result['domain_complete'],
                physical_detail_hash=detail_hash, group_selection=dict(group_selection),
                adopted_resistance_kappa=-1., source_sha256=SOURCE_SHA256,
                formula=check['formula'], scope=result.get('scope', 'fullheight_nominal_distinct_body'),
                component_axes=result.get('component_axes'), verification_complete=result['domain_complete'] if receipt else None,
                nominal_dependency_receipt=receipt, dependency_check_refs=result.get('dependency_check_refs'),
                dependency_exceedances=result.get('dependency_exceedances'),
                three_dimensional_receiver_interaction_claimed=False if receipt else None)))
        if exceeded:
            out['criterion_exceedances'].append(dict(region=key, criterion=check['id'], utilization=check['utilization']))
    if not result.get('checks'):
        not_applicable = result.get('status') == 'NOT_APPLICABLE_NO_STRAIGHT_INTERIOR'
        reason = result.get('reason') or '; '.join(result.get('domain_pending', ())) or 'Região sem recibo calculável.'
        for check in expected_checks:
            out['verifications'].append(Verification('fatigue/'+key+'/'+check+'/'+CASE,
                'fatigue', key+' · '+check, 'not_applicable' if not_applicable else 'pending', SOURCE, CASE,
                reason=reason, evidence=dict(region=key, physical_detail_hash=detail_hash)))
    for i, reason in enumerate(result.get('domain_pending', ())):
        _pending(out, key+'/domain/'+str(i), reason)


def _unavailable_region(reason):
    return dict(domain_complete=False, checks=[], domain_pending=[reason], pending=[reason],
        errors=[], locations=[], criterion_exceedances=[], status='APPLICABILITY_PENDING',
        reason=reason, uses_fabricated_history=False, actual_failure_proven=False)


def _bearing_action_domain(project, station_id, action):
    sid, pending = station_id, []
    if not project.section.doubly_symmetric or project.support_contact != 'centered_under_web':
        pending.append(sid+': introdução Rz/2 requer par e seção simétricos com apoio centrado; não é válida para excentricidade.')
    extra = action.get('bearing_additional_actions')
    allowed = {'force_x_kn', 'force_y_kn', 'moment_x_knm', 'moment_y_knm', 'moment_z_knm',
               'normal_parallel_mpa', 'plate_shear_yz_mpa', 'source'}
    active_wrappers = set()

    def consume(record, path, depth=0):
        if type(record) is not dict:
            raise ValueError('bearing_additional_actions deve identificar componentes físicas adicionais: '+path)
        if depth > 64 or id(record) in active_wrappers:
            raise ValueError('Agregado records bearing recursivo/cíclico ou excessivamente profundo: '+path)
        if 'records' in record:
            # envelope_station_actions may compact envelopes recursively. A
            # wrapper is NOT itself a force component and cannot hide unknown
            # fields or mix in physical components outside its child records.
            if set(record)-{'records', 'source'}:
                raise ValueError('Componente bearing adicional desconhecida no agregado records: '+path)
            if 'source' in record:
                _text(record['source'], 'Fonte do agregado de ações bearing')
            rows = record['records']
            if type(rows) is not list or not rows:
                raise ValueError('Agregado records bearing deve conter lista não vazia de registros físicos: '+path)
            active_wrappers.add(id(record))
            try:
                for i, child in enumerate(rows):
                    consume(child, path+'/records/'+str(i), depth+1)
            finally:
                active_wrappers.remove(id(record))
            return
        if set(record)-allowed:
            raise ValueError('Componente bearing adicional desconhecida; não pode ser omitida: '+path)
        if record:
            _text(record.get('source'), 'Fonte das ações bearing adicionais')
        for component, value in record.items():
            if component == 'source':
                continue
            v = _number(value, component, signed=True)
            if v:
                pending.append(sid+': componente real adicional '+component+'='+str(v)+
                    ' em '+path+' não coberta pela introdução Rz centrada; transportar momento e preservar o plano/campo próprio, sem apagar a componente.')
    if extra is not None:
        consume(extra, 'bearing_additional_actions')
    inventory = action.get('function_inventory', {})
    if inventory.get('other_transfer') not in (None, 'not_applicable'):
        pending.append(sid+': other_transfer real exige resultantes/planos próprios além da introdução inferior Rz.')
    return pending


def _bearing_lower_regions(project, detail, station, action, group_selection, assessment):
    """The addendum's TWO-PLATE lower T introduction only, not all interfaces.

    R/2 is an explicitly adopted nominal introduction of the SAME support
    reaction through identical plates. It is neither a wheel split nor an
    elastic-distribution envelope of three connections. No R is sent to top CJP.
    """
    d, sec, g = detail, detail.section, fullheight_geometry(detail)
    sid, x = station['station_id'], station['x_m']*1000
    names = {role: prefix+'/'+sid for role, prefix in (
        ('plate', 'fullheight_bearing_plate_lower'), ('weld', 'fullheight_bearing_weld_lower'))}
    if not action:
        reason = sid+': introdução inferior bearing requer recibo da mesma reação Rz real na família FAT.'
        return {key: _unavailable_region(reason) for key in names.values()}
    reaction = _number(action.get('bearing_abs_bound_kn'), 'Rz bearing da mesma estação')*1000
    interval = action.get('bearing_interval_kn')
    if type(interval) not in (tuple, list) or len(interval) != 2:
        raise ValueError('Intervalo auditado da reação bearing obrigatório.')
    lo, hi = (_number(v, 'Extremo Rz bearing', signed=True)*1000 for v in interval)
    if lo > hi or max(abs(lo), abs(hi)) > reaction+1e-7:
        raise ValueError('Limite Rz não cobre seus extremos na mesma estação.')
    b = _number(g['bottom_length_mm'], 'Ligamento real inferior', positive=True)
    L = _number(b-2*d.bottom_attachment.endpoint_tolerance_mm, 'Comprimento efetivo inferior', positive=True)
    a = _number(d.bottom_attachment.leg_mm/sqrt(2), 'Garganta real inferior', positive=True)
    pending = _quality_issues(assessment, ('bottom', 'bottom_interior', 'bottom_ends'))
    pending += _bearing_action_domain(project, sid, action)
    extra = action.get('bearing_additional_actions')
    # A nonzero known parallel normal or moment is retained above, never set to
    # zero by the scalar formula. Calculated R-only checks remain conditional.
    sigma_plate = reaction/(2*d.plate_thickness_mm*b)
    q = reaction/(4*L)
    sigma_throat = q/(sqrt(2)*a)
    plate_locations, weld_locations = [], []
    for side in (-1, 1):
        yw = side*sec.web_thickness_mm/2
        yy = tuple(sorted((yw+side*g['bottom_start_u_mm'], yw+side*d.outstand_mm)))
        load_y = side*(sec.web_thickness_mm/2+(g['bottom_start_u_mm']+d.outstand_mm)/2)
        plate_locations.append(FullHeightRegionIdentity('attached_bearing_plate', sid,
            sid+':lower_T_plate:'+str(side), str(side), 'y', 'yz',
            ((x-d.plate_thickness_mm/2, x+d.plate_thickness_mm/2), yy, (g['bottom_z_mm'],)*2),
            d.plate_material.material_id, d.plate_thickness_mm, d.input_signature,
            d.bottom_attachment.interior_quality.grade, d.bottom_attachment.source+'; '+BEARING_SOURCE))
        for face in (-1, 1):
            xx = x+face*d.plate_thickness_mm/2
            weld_locations.append(FullHeightRegionIdentity('deposited_lower_T_fillet', sid,
                sid+':lower_T_fillet:'+str(side)+':'+str(face), str(face), 'y', 'yz',
                (tuple(sorted((xx, xx+face*d.bottom_attachment.leg_mm))), yy, (g['bottom_z_mm'],)*2),
                d.bottom_attachment.material.material_id, a, d.input_signature,
                d.bottom_attachment.interior_quality.grade, d.bottom_attachment.source+'; '+BEARING_SOURCE))
    common = dict(reaction_abs_bound_n=reaction, reaction_interval_n=(lo, hi),
        reaction_source=action.get('source', BEARING_SOURCE), reaction_station_id=sid,
        force_per_plate_abs_bound_n=reaction/2, number_of_plates=2, number_of_fillet_lines=4,
        physical_length_each_mm=b, effective_length_each_mm=L, effective_throat_mm=a,
        plate_ligament_area_each_mm2=d.plate_thickness_mm*b,
        load_line_y_abs_mm=sec.web_thickness_mm/2+(g['bottom_start_u_mm']+d.outstand_mm)/2,
        load_line_basis='centroide do ligamento inferior/prisma exterior nominal, não centroide da chapa inteira',
        plate_normal_z_bound_mpa=sigma_plate, qz_each_line_n_per_mm=q,
        weld_normal_perpendicular_bound_mpa=sigma_throat,
        weld_shear_perpendicular_bound_mpa=sigma_throat,
        weld_shear_parallel_from_centered_R_mpa=0.,
        additional_actions_retained=extra, additional_actions_included_in_scalar_bounds=False,
        whole_interface_transfer_complete=False, top_cjp_R_assigned=False,
        web_R_assigned_by_this_consumer=False, fabricated_wheel_P_over_2=False,
        stationary_G_already_included_once=True, local_G_not_added_again=True,
        no_cycle_claim=True, minimum_45kn_added_to_fatigue=False,
        input_bound_kind=REACTION_BOUND_BASIS,
        equal_plate_split_basis='explicit nominal centered symmetric lower introduction, not proof of elastic redistribution',
        source=BEARING_SOURCE)
    plate = _region_result(project, d, names['plate'], plate_locations,
        (sigma_plate, 0., 0.), ('K4,41', None), group_selection=group_selection,
        quality_pending=pending, material=d.plate_material, component_axes=('z_perpendicular', 'y_parallel'), transfer=common)
    weld = _region_result(project, d, names['weld'], weld_locations,
        (sigma_throat, 0., sigma_throat), ('K4,41', None), group_selection=group_selection,
        quality_pending=pending, material=d.plate_material,
        capacity_materials=(sec.material, d.bottom_attachment.material),
        component_axes=('normal_perpendicular_to_throat', 'normal_parallel_to_weld'),
        weld=True, weld_normal_perpendicular_first=True, transfer=common)
    for result in (plate, weld):
        result['source_contract']['bearing_detail'] = BEARING_SOURCE
        result['source_contract']['bearing_addendum_sha256'] = BEARING_ADDENDUM_SHA256
        result['scope'] = 'Somente introdução inferior nominal centrada por reação Rz da própria estação; não saída web nem CJP superior.'
        result['geometric_correspondence_not_literal_stiffener_table_entry'] = True
        result['parallel_detail_class_claimed'] = False
        for check in result['checks']:
            check['source'] += '; '+BEARING_SOURCE
    return {names['plate']: plate, names['weld']: weld}


def _polynomial_abs_bound(coefficients, interval):
    """Exact supremum of the existing degree <=2 section functions, not samples."""
    if type(coefficients) not in (tuple, list) or not 1 <= len(coefficients) <= 3:
        raise ValueError('Função nominal deve ser polinômio existente de grau até dois.')
    c = tuple(_number(v, 'Coeficiente nominal', signed=True) for v in coefficients)
    lo, hi = (_number(v, 'Domínio do corte', signed=True) for v in interval)
    if lo >= hi:
        raise ValueError('Domínio contínuo do corte inválido.')
    points = [lo, hi]
    if len(c) == 3 and c[2]:
        critical = -c[1]/(2*c[2])
        if lo < critical < hi:
            points.append(critical)
    return max(abs(sum(v*t**i for i, v in enumerate(c))) for t in points)


def _bearing_exit_regions(project, detail, station, action, group_selection, assessment, metrics):
    """Consume the existing signed serial-group influence field, never a history.

    Own-plate sections and deposited metal have qualified 2-D consumers. The
    receiver's additional surface/strip field is retained separately because
    those qualifications do not create a 3-D D.5 interaction with the beam.
    """
    sid, d, sec = station['station_id'], detail, detail.section
    names = {prefix: prefix+'/'+sid for prefix in BEARING_EXIT_PREFIXES}
    if not action:
        reason = sid+': saída bearing requer a mesma reação Rz real da família FAT.'
        return {key: _unavailable_region(reason) for key in names.values()}, []
    reaction = _number(action.get('bearing_abs_bound_kn'), 'Rz bearing da saída em série')*1000
    shared_pending = _bearing_action_domain(project, sid, action)
    if d.web_fillets.endpoint_tolerance_mm:
        shared_pending.append(sid+': grupo de saída usa linha física web; dedução efetiva de término '+
            str(d.web_fillets.endpoint_tolerance_mm)+' mm ainda não representada no campo de influência.')
    x, g = station['x_m']*1000, fullheight_geometry(d)
    locations = {k: [] for k in BEARING_EXIT_PREFIXES}
    demands = {k: [0., 0., 0.] for k in BEARING_EXIT_PREFIXES if 'composition' not in k}
    fields, section_records, throat_records = [], [], []
    receiver_records = {k: [] for k in ('web', 'top', 'bottom')}

    def location(body, line, side, xyz, axis, material, thickness, quality, source):
        return FullHeightRegionIdentity(body, sid, line, str(side), axis, 'yz',
            tuple(tuple(sorted(v)) for v in xyz), material.material_id, thickness,
            d.input_signature, quality, source+'; '+BEARING_EXIT_SOURCE)

    for side in (-1, 1):
        unit = bearing_reaction_unit_field(d, side, station_id=sid)
        if (unit.get('geometry_inputs_hash') != d.input_signature or unit.get('pair_reaction_N') != 1.
                or unit.get('field_units') != 'MPa_per_N_of_original_pair_Rz'
                or unit.get('G_included') is not False or unit.get('connection_floor_included') is not False
                or unit.get('fatigue_history_created') is not False
                or unit.get('own_downward_G_N') != 0.
                or unit.get('equilibrium', {}).get('satisfied') is not True
                or unit.get('top_web_receiver_group', {}).get('equilibrium_satisfied') is not True):
            raise ValueError('Campo unitário bearing incompatível, sem equilíbrio ou com G/piso artificial.')
        fields.append({key: unit[key] for key in ('side', 'input_signature', 'geometry_inputs_hash',
            'field_units', 'pair_reaction_N', 'G_included', 'connection_floor_included',
            'lower_introduction_N', 'receiver_group_Fz_on_plate_N', 'lower_group',
            'top_web_receiver_group', 'section_results', 'equilibrium', 'nominal_stiffness_idealization')})
        fields[-1].update(scaling_input_bound_kind=REACTION_BOUND_BASIS,
            stationary_G_already_included_once=True, local_G_not_added_again=True, no_cycle_claim=True)
        funcs = unit['section_results']['nominal_section_stress_functions']
        known_roles = {'plate', 'beam_web', 'beam_top_flange', 'beam_bottom_flange'}
        for field in funcs+unit['section_results']['signed_interface_points']:
            if field.get('material_role') not in known_roles:
                raise ValueError('Corpo de campo nominal desconhecido; não pode ser descartado como diagnóstico.')
        for role, field_id, component, joint, axis in (
                ('web', 'plate_connected_root', 'sigma_yy', d.web_fillets, 'z'),
                ('top', 'top_horizontal_plate_ligament', 'sigma_zz', d.top_cjp, 'y')):
            matches = [v for v in funcs if v['field_id'] == field_id and v['material_role'] == 'plate']
            if len(matches) != 1 or matches[0]['plane'] != 'yz':
                raise ValueError('Seção própria bearing ausente, duplicada ou em plano incorreto.')
            f = matches[0]
            sigma = reaction*_polynomial_abs_bound(f[component+'_polynomial_ascending_mpa'], f['parameter_interval'])
            tau = reaction*_polynomial_abs_bound(f['tau_yz_polynomial_ascending_mpa'], f['parameter_interval'])
            prefix = 'fullheight_bearing_plate_'+role
            demands[prefix][0] = max(demands[prefix][0], sigma)
            demands[prefix][2] = max(demands[prefix][2], tau)
            xyz = ((x-d.plate_thickness_mm/2, x+d.plate_thickness_mm/2),
                (f['y_mm'], f['y_mm']) if role == 'web' else f['y_interval_mm'],
                f['z_interval_mm'] if role == 'web' else (f['z_mm'], f['z_mm']))
            quality = joint.interior_quality.grade if role == 'web' else joint.quality.grade
            locations[prefix].append(location('attached_bearing_plate', sid+':'+field_id+':'+str(side),
                side, xyz, axis, d.plate_material, d.plate_thickness_mm, quality, joint.source))
            section_records.append(dict(side=side, role=role, signed_unit_section_function=f,
                normal_absolute_bound_mpa=sigma, shear_absolute_bound_mpa=tau,
                continuous_domain_evaluated=True, discrete_samples_used_as_coverage=False))
        for line in unit['top_web_receiver_group']['lines']:
            interface = line['interface']; is_top = interface['weld_type'] == 'CJP'
            role, joint, axis = ('top', d.top_cjp, 'y') if is_top else ('web', d.web_fillets, 'z')
            endpoints = []
            for endpoint in (0, 1):
                ty = _number(line['ty'+str(endpoint)+'_mpa'], 'Tração ty unitária', signed=True)*reaction
                tz = _number(line['tz'+str(endpoint)+'_mpa'], 'Tração tz unitária', signed=True)*reaction
                normal, perp, parallel = (tz, ty, 0.) if is_top else (ty/sqrt(2), ty/sqrt(2), tz)
                endpoints.append(dict(endpoint=endpoint, normal_perpendicular_mpa=normal,
                    shear_perpendicular_mpa=perp, shear_parallel_mpa=parallel,
                    shear_resultant_mpa=sqrt(perp*perp+parallel*parallel)))
            prefix = 'fullheight_bearing_weld_'+role
            # Norm of an affine traction is convex on the entire physical line,
            # so its maximum is at an endpoint. This is continuous coverage.
            normal = max(abs(v['normal_perpendicular_mpa']) for v in endpoints)
            shear = max(v['shear_resultant_mpa'] for v in endpoints)
            demands[prefix][0] = max(demands[prefix][0], normal)
            demands[prefix][2] = max(demands[prefix][2], shear)
            xx = x+interface['x_from_station_mm']
            if is_top:
                xb = (x-d.plate_thickness_mm/2, x+d.plate_thickness_mm/2)
                quality = joint.quality.grade
            else:
                face = 1 if interface['x_from_station_mm'] > 0 else -1
                xb = (xx, xx+face*joint.leg_mm)
                quality = joint.interior_quality.grade+' with '+joint.end_quality.grade+' ends'
            locations[prefix].append(location('deposited_CJP_metal_top' if is_top else 'deposited_web_fillet',
                interface['interface_id'], side, (xb, (interface['y0_mm'], interface['y1_mm']),
                (interface['z0_mm'], interface['z1_mm'])), axis, joint.material,
                interface['effective_throat_mm'], quality, joint.source))
            throat_records.append(dict(side=side, role=role, interface=interface,
                signed_unit_traction=line, scaled_endpoints=endpoints,
                fillet_45_degree_transform_used=not is_top,
                continuous_line_maximum_basis='affine normal / convex norm of affine throat shear; endpoint extrema exact'))
        # Keep the actual signed receiver field, not its magnitude re-labelled
        # as the global web transverse stress or as an attached-plate stress.
        for role in ('web', 'top', 'bottom'):
            body = 'beam_web' if role == 'web' else 'beam_'+role+'_flange'
            points = [v for v in unit['section_results']['signed_interface_points'] if v['material_role'] == body]
            strips = [v for v in funcs if v['material_role'] == body]
            receiver_records[role].append(dict(side=side, signed_unit_interface_points=points,
                signed_unit_section_functions=strips, scale_original_pair_Rz_N=reaction,
                interface_component_absolute_bounds_mpa={component: reaction*max(
                    abs(v['tensor_components_mpa'].get(component, 0.)) for v in points)
                    for component in sorted({k for v in points for k in v['tensor_components_mpa']})},
                section_component_absolute_bounds_mpa={component: reaction*max((
                    _polynomial_abs_bound(v[component+'_polynomial_ascending_mpa'], v['parameter_interval'])
                    for v in strips if component+'_polynomial_ascending_mpa' in v), default=0.)
                    for component in ('sigma_yy', 'tau_yz')}))
            for v in points:
                locations['fullheight_bearing_receiver_'+role+'_composition'].append(location(body,
                    v['point_id'], side, (tuple(x+a for a in v['x_footprint_interval_from_station_mm']),
                        (v['y_mm'], v['y_mm']), (v['z_mm'], v['z_mm'])),
                    'z' if role == 'web' else 'y', sec.material,
                    sec.web_thickness_mm if role == 'web' else getattr(sec, role+'_flange_thickness_mm'),
                    'supplementary_receiver_field_diagnostic_only', d.source if hasattr(d, 'source') else sec.source))
    results = {}
    for role, classes, quality_prefixes, joint in (
            ('web', ('K4,5', None), ('web', 'web_interior', 'web_ends'), d.web_fillets),
            ('top', ('K2,5', None), ('top_cjp',), d.top_cjp)):
        for body in ('plate', 'weld'):
            prefix = 'fullheight_bearing_'+body+'_'+role
            weld = body == 'weld'
            transfer = dict(reaction_abs_bound_n=reaction, reaction_interval_kn=action['bearing_interval_kn'],
                reaction_source=action.get('source', BEARING_EXIT_SOURCE), reaction_station_id=sid,
                unit_field_signatures=[v['input_signature'] for v in fields],
                own_section_functions=[v for v in section_records if v['role'] == role] if not weld else [],
                throat_traction_fields=[v for v in throat_records if v['role'] == role] if weld else [],
                receiver_group_force_per_unit_pair_Rz_N=[v['top_web_receiver_group']['required_Fz_N'] for v in fields],
                receiver_group_moment_per_unit_pair_Rz_Nmm=[v['top_web_receiver_group']['required_Mx_about_group_Nmm'] for v in fields],
                actual_lower_load_line_moment_preserved=True, top_cjp_given_full_Rz=False,
                stationary_G_already_included_once=True, local_G_not_added_again=True,
                no_cycle_claim=True, minimum_45kn_added_to_fatigue=False,
                input_bound_kind=REACTION_BOUND_BASIS,
                additional_actions_retained=action.get('bearing_additional_actions'),
                additional_actions_included_in_bounds=False, whole_receiver_composition_complete=False,
                source=BEARING_EXIT_SOURCE)
            result = _region_result(project, d, names[prefix], locations[prefix], demands[prefix], classes,
                group_selection=group_selection, quality_pending=shared_pending+_quality_issues(assessment, quality_prefixes),
                weld=weld, transfer=transfer, material=d.plate_material,
                capacity_materials=(sec.material, joint.material) if weld else (),
                component_axes=('normal_perpendicular_to_throat', 'normal_parallel_to_weld') if weld else
                    (('y_perpendicular', 'z_inactive_in_section') if role == 'web' else ('z_perpendicular', 'y_inactive_in_section')),
                weld_normal_perpendicular_first=weld)
            result['scope'] = 'Saída em série nominal própria da chapa/garganta; reação/momento reais, não interação nova do receptor.'
            result['source_contract']['bearing_detail'] = BEARING_EXIT_SOURCE
            result['source_contract']['bearing_addendum_sha256'] = BEARING_ADDENDUM_SHA256
            result['spatial_coverage_source'] = 'Supremo algébrico dos polinômios nominais sobre o corte contínuo; gargantas afins sobre as linhas reais; caixa D.5 é relaxação conservadora, não história.'
            for check in result['checks']:
                check['source'] += '; '+BEARING_EXIT_SOURCE
            results[names[prefix]] = result
    for role in ('web', 'top', 'bottom'):
        prefix = 'fullheight_bearing_receiver_'+role+'_composition'
        body = 'alma da viga' if role == 'web' else 'mesa '+('superior' if role == 'top' else 'inferior')+' da viga'
        reason = (sid+': composição FAT local/global no receptor '+body+
            ': tração/normal transversal e cisalhamento yz do campo nominal de Rz nos pés/raízes finitos '
            'ainda não combinados com o campo global '+('xz' if role == 'web' else 'xy')+
            '; não converter qy em sigma_z, não copiar tensão da chapa e não criar D.5 tridimensional.')
        result = _unavailable_region(reason)
        result.update(locations=[asdict(v) for v in locations[prefix]], scope='receiver_local_global_composition_only',
            reaction_abs_bound_n=reaction, additional_receiver_fields=receiver_records[role],
            global_nominal_bounds_mpa=dict(metrics), source=BEARING_EXIT_SOURCE,
            own_plate_and_throat_classification_complete=True,
            normal_transverse_discarded=False, receiver_components_relabelled=False,
            signed_unit_coefficients_are_not_history=True, as_built_execution_verified=False)
        results[names[prefix]] = result
    return results, fields


def _receiver_additional_domain(action, role, _active_wrappers=None, _depth=0):
    """Explicit future independent fields reopen only their receiving body.

    Unknown bodies/components are never silently recast as the supplemental
    same-group strip diagnostic. This is a guard, not a new stress producer.
    """
    extra = action.get('receiver_additional_nominal_fields')
    if extra is None:
        return []
    if type(extra) is dict and 'records' in extra:
        active = set() if _active_wrappers is None else _active_wrappers
        if _depth > 64 or id(extra) in active:
            return ['Agregado records do receptor recursivo/cíclico ou excessivamente profundo.']
        if set(extra)-{'records', 'source'}:
            return ['Campo desconhecido no agregado records nominal independente do receptor.']
        if 'source' in extra:
            try:
                _text(extra['source'], 'Fonte do agregado de campos nominais do receptor')
            except ValueError as exc:
                return [str(exc)]
        records = extra['records']
        if type(records) is not list or not records:
            return ['Agregado records do receptor deve conter lista não vazia de registros físicos.']
        active.add(id(extra))
        pending = []
        try:
            for record in records:
                if type(record) is not dict:
                    pending.append('Registro nominal independente do receptor deve ser objeto físico explícito.')
                else:
                    pending.extend(_receiver_additional_domain({'receiver_additional_nominal_fields': record},
                        role, active, _depth+1))
        finally:
            active.remove(id(extra))
        return pending
    if type(extra) is not dict or set(extra)-{'web', 'top', 'bottom'}:
        return ['Campo nominal independente do receptor com corpo desconhecido ou inventário inválido.']
    field = extra.get(role)
    if field is None:
        return []
    allowed = {'source', 'sigma_x_mpa', 'sigma_y_mpa', 'sigma_z_mpa',
               'tau_xy_mpa', 'tau_xz_mpa', 'tau_yz_mpa'}
    try:
        if type(field) is not dict or set(field)-allowed:
            raise ValueError('Componente nominal independente desconhecida no receptor '+role+'.')
        source = _text(field.get('source'), 'Fonte nominal independente do receptor '+role)
        active = {k: _number(v, k, signed=True) for k, v in field.items() if k != 'source'}
        if not active:
            raise ValueError('Fonte independente sem componentes explícitas no receptor '+role+'.')
        if any(active.values()):
            return ['Receptor '+role+': campo nominal independente real requer classificação/combinação própria: '+
                str(active)+'; fonte '+source+'. Não é diagnóstico das faixas do mesmo grupo.']
    except (ValueError, TypeError) as exc:
        return [str(exc)]
    return []


def _qualify_receiver_receipts(project, detail, station, action, assessment, base_regions, station_regions):
    """Conditional nominal dependency receipts; no manufactured comparison."""
    sid = station['station_id']
    available = dict(base_regions, **station_regions)
    mapping = {
        'web': (('fullheight_web_straight', 'fullheight_web_termination_top', 'fullheight_web_termination_bottom'), 'web'),
        'top': (('fullheight_top_cjp_receiver',), 'top'),
        'bottom': (('fullheight_bottom_fillet_receiver',), 'lower'),
    }
    for role, (receiver_refs, own_role) in mapping.items():
        key = 'fullheight_bearing_receiver_'+role+'_composition/'+sid
        result = station_regions[key]
        # A missing or invalid group receipt remains pending. This qualifier
        # must not manufacture an available physical transfer out of a label.
        if not result.get('additional_receiver_fields'):
            continue
        own_refs = tuple('fullheight_bearing_'+body+'_'+own_role+'/'+sid for body in ('plate', 'weld'))
        longitudinal_refs = tuple('fullheight_longitudinal_'+body+'_'+role
            for body in ('flange', 'web', 'cjp_throat')) if role in ('top', 'bottom') else ()
        refs = tuple(receiver_refs)+own_refs+longitudinal_refs
        pending = _bearing_action_domain(project, sid, action)+_receiver_additional_domain(action, role)
        # Published local coverage is conditional on the actual full-height
        # detail, not on the failed, independently evaluated bearing c>=94.
        pending += list(assessment['pending'])
        pending += ['Detalhe construtivo publicado: requisito físico não atendido '+v['check_id']
                    for v in assessment['checks'] if not v['passed']]
        check_refs, exceedances, usages, nominal_locations = [], [], [], []
        for ref in refs:
            dep = available.get(ref)
            if not dep:
                pending.append('Dependência nominal ausente: '+ref)
                continue
            if dep.get('domain_complete') is not True or dep.get('errors'):
                pending.append('Dependência nominal não qualificada: '+ref)
            if dep.get('status') == 'NOT_APPLICABLE_NO_STRAIGHT_INTERIOR':
                if ref != 'fullheight_web_straight' or dep.get('domain_complete') is not True:
                    pending.append('Não aplicabilidade sem domínio válido: '+ref)
                else:
                    check_refs += ['fatigue/'+ref+'/'+c+'/'+CASE for c in REGION_CHECKS[ref]]
                continue
            expected = REGION_CHECKS.get(ref)
            if expected is None:
                prefix = next((p for p in BEARING_REGION_CHECKS if ref.startswith(p+'/')), None)
                expected = BEARING_REGION_CHECKS.get(prefix, ())
            checks = dep.get('checks', ())
            by_id = {c.get('id'): c for c in checks}
            if len(by_id) != len(checks) or set(by_id) != set(expected):
                pending.append('Inventário de checks dependentes incompleto/duplicado: '+ref)
            if ref in receiver_refs:
                matching = [v for v in dep.get('locations', ()) if v.get('station_id') == sid]
                if not matching:
                    pending.append('Região receptora não identifica os pés da estação: '+ref)
                nominal_locations += matching
            for name in expected:
                c = by_id.get(name)
                if c is None:
                    continue
                ident = 'fatigue/'+ref+'/'+name+'/'+CASE
                check_refs.append(ident)
                try:
                    usage = _number(c.get('utilization'), 'Utilização dependente '+ident)
                except ValueError as exc:
                    pending.append(str(exc))
                    continue
                usages.append(usage)
                if usage > 1:
                    exceedances.append(dict(region=ref, check_id=name, verification_id=ident, utilization=usage))
        pending = list(dict.fromkeys(pending))
        complete = not pending and bool(usages)
        usage = max(usages) if usages else None
        numeric_pass = complete and bool(usages) and not exceedances
        independent = action.get('receiver_additional_nominal_fields')
        try:
            json.dumps(independent, allow_nan=False)
        except (TypeError, ValueError):
            independent = {'invalid_input_repr': repr(independent)}
        diagnostic = result['locations']
        result.update(kind='nominal_receiver_dependency_receipt', domain_complete=complete,
            pending=pending, domain_pending=pending, errors=[],
            status='APPLICABILITY_PENDING' if not complete else
                'INCONCLUSIVE_SUFFICIENT_BOUND' if not numeric_pass else 'NOMINAL_DEPENDENCIES_SATISFIED',
            reason='Recibo condicional dos checks nominais e da configuração publicada; não equação FAT tridimensional.',
            nominal_receiver_region_refs=list(receiver_refs), own_transfer_region_refs=list(own_refs),
            longitudinal_region_refs=list(longitudinal_refs), dependency_check_refs=check_refs,
            dependency_exceedances=exceedances, numerical_dependencies_satisfied=numeric_pass,
            all_nominal_dependencies_satisfied=complete and numeric_pass,
            criterion_exceedances=['local_global_composition'] if exceedances else [],
            locations=nominal_locations, supplementary_diagnostic_locations=diagnostic,
            source=RECEIVER_SCOPE_SOURCE, source_contract=dict(source=RECEIVER_SCOPE_SOURCE,
                qualification_sha256=RECEIVER_SCOPE_SHA256),
            scope='nominal_receiver_and_published_detail_dependency_coverage',
            published_detail=dict(status='covered_by_adopted_published_detail' if complete else 'published_detail_domain_pending',
                source='Fisher/Van de Pas 2002 pp.68–69; full-height, CJP superior, filetes contínuos alma/inferior; CJP longitudinal superior reforçada',
                fitted_contact_credited=False, as_built_verified=False,
                geometric_minimum_bearing_check_is_separate=True),
            three_dimensional_receiver_interaction_claimed=False, whole_station_qualified=False,
            supplementary_receiver_fields_status='diagnostic_of_nonadopted_isolated_strip_model',
            supplementary_receiver_fields_added_to_member_fatigue=False,
            own_plate_and_throat_fields_are_diagnostic=False,
            independent_additional_nominal_fields=independent,
            input_bound_kind=REACTION_BOUND_BASIS, stationary_G_already_included_once=True,
            local_G_not_added_again=True, no_cycle_claim=True,
            checks=[dict(id='local_global_composition', name='cobertura nominal por dependências',
                dependency_receipt=True, demand=None, capacity=None, unit='', utilization=usage,
                source=RECEIVER_SCOPE_SOURCE, formula='utilização herdada=max(utilizações dos checks explicitamente referenciados); nenhuma equação/resistência nova',
                detail='; '.join(pending) if pending else
                    'Dependência nominal excedida; recibo não constitui aprovação.' if exceedances else
                    'Checks nominais e domínio construtivo especificado atendidos; não certificação as-built ou do apoio inteiro.')])


def evaluate_fullheight_family_bounds(project, metrics, *, group_selection, family_evidence,
                                     physical_detail, fixed_flange_detail=None, fixed_station_detail=None):
    """Consume, never regenerate, the adapter's audited complete FAT family.

    ``family_evidence`` is the existing adapter receipt (project_signature,
    exact case_ids, local_bending_bound_mpa). Optional fullheight_station_family
    carries real support reactions for the lower T introduction and qualified
    serial-group exit. Additional receiver composition remains explicit.
    ``complete`` concerns THIS nominal fatigue inventory, never entire design.
    """
    out = dict(case_id=CASE, verifications=[], regions={}, pending=[], errors=[],
        group_selection={}, design_requirements=[], complete=False, full_compliance=False,
        input_audit_complete=False, functions=[], criterion_exceedances=[], bearing_reaction_fields={},
        actual_failure_proven=False, uses_fabricated_history=False,
        as_built_execution_verified=False, adopted_resistance_kappa=-1.)
    try:
        d = resolve_fullheight_detail(project, physical_detail)
        if type(d) is not FullHeightNominalDetail:
            raise ValueError('FullHeightNominalDetail tipado obrigatório.')
        persisted = resolve_fullheight_detail(project, getattr(project, 'fullheight_nominal_detail', None))
        if persisted.input_signature != d.input_signature:
            raise ValueError('Detalhe físico difere do persistido: recalcular ações/recibos após mutação de geometria, qualidade ou fonte.')
        if d.section.material.material_id != project.material_grade:
            raise ValueError('Grau físico da seção não coincide com o grau do projeto; sem equivalência automática.')
        if (abs(project.rail.offset_from_web_mm) > 1e-9 or project.rail.local_attachment != 'non_rigid'
                or project.rail.continuity != 'continuous_no_joint' or project.support_contact != 'centered_under_web'):
            raise ValueError('Modelo nominal NBR10084 exige trilho centrado/contínuo não rígido e apoio compressivo centrado.')
        if project.restraint_application != 'resistance_lengths_only':
            raise ValueError('Rota full-height não cria reações de travamento na análise.')
        if not isinstance(metrics, dict) or set(metrics) != set(METRICS):
            raise ValueError('Inventário exato de métricas auditadas obrigatório; nenhuma componente desconhecida.')
        metrics = {k: _number(metrics[k], k) for k in METRICS}
        for combined, parts in (
            ('combined_web_longitudinal_bound_mpa', ('web_sigma_abs_upper_bound_mpa', 'local_longitudinal_compression_bound_mpa')),
            ('combined_web_shear_bound_mpa', ('web_shear_magnitude_upper_bound_mpa', 'local_shear_bound_mpa'))):
            if any(metrics[combined] < metrics[k]-1e-10*max(1., metrics[k]) for k in parts):
                raise ValueError('Limite combinado menor que parcela positiva: '+combined)
        if type(group_selection) is not dict:
            raise ValueError('Seleção explícita do grupo obrigatório.')
        group = group_selection.get('component_group')
        if group not in tuple('E'+str(i) for i in range(1, 9)) or group != project.fatigue.component_group:
            raise ValueError('Preservar exatamente o grupo E manual do projeto; sem promoção E8 ou P4 automática.')
        _text(group_selection.get('source'), 'Origem da seleção manual E')
        if type(family_evidence) is not dict or family_evidence.get('project_signature') != input_signature(project):
            raise ValueError('Família de fadiga não vinculada ao projeto atual.')
        expected = {c.id for c in generate_basic_cases(project) if c.family == 'FAT8400'}
        ids = family_evidence.get('case_ids')
        if not isinstance(ids, (list, tuple)) or len(ids) != len(set(ids)) or set(ids) != expected:
            raise ValueError('Família deve conter exatamente todos os casos FAT8400 gerados.')
        bending = _number(family_evidence.get('local_bending_bound_mpa'), 'sigmaT FAT auditada')
        if bending > metrics['local_transverse_bound_mpa']+1e-10:
            raise ValueError('sigmaT excede o limite transversal completo.')
        if family_evidence.get('kappa_policy', KAPPA_POLICY) != KAPPA_POLICY:
            raise ValueError('Somente adoção explícita de resistência kappa=-1 é implementada.')
        if family_evidence.get('action_basis', ACTION_BASIS) != ACTION_BASIS:
            raise ValueError('Base de ações deve ser FAT caso I sem Mx.')
        if 'metrics' in family_evidence and family_evidence['metrics'] != metrics:
            raise ValueError('Métricas diferem do recibo auditado da família.')
        g = fullheight_geometry(d); assessment = fullheight_detail_assessment(d)
        stations = stiffener_station_geometry(project)
        if not stations:
            raise ValueError('Família física full-height sem estações.')
        out.update(input_audit_complete=True, mechanical_evidence_verified_by_this_consumer=False,
            group_selection=dict(group_selection),
            audited_metrics=dict(metrics), audited_local_bending_bound_mpa=bending,
            family_evidence={k: v for k, v in family_evidence.items() if k != 'metrics'},
            physical_detail_hash=d.input_signature, geometry=g)
    except (ValueError, TypeError, KeyError, AttributeError, ArithmeticError) as exc:
        out['errors'].append(str(exc)); _pending(out, 'fullheight_input_domain', str(exc)); return out

    s, m = d.section, d.section.material
    all_x = (-d.beam_end_left_mm, project.span_m*1000+d.beam_end_right_mm)
    web_demands = (metrics['combined_web_longitudinal_bound_mpa'], metrics['local_transverse_bound_mpa'],
                   metrics['combined_web_shear_bound_mpa'])
    flange_demands = (metrics['flange_sigma_abs_upper_bound_mpa'], 0., metrics['flange_shear_magnitude_upper_bound_mpa'])
    inventories = {key: [] for key in REGION_IDS}
    def identity(body, station, line, face, axis, plane, xyz, thickness, quality, source):
        return FullHeightRegionIdentity(body, station, line, face, axis, plane, tuple(tuple(v) for v in xyz),
            m.material_id, thickness, d.input_signature, quality, source)
    def append(name, body, station, line, face, axis, plane, xyz, thickness, quality, source):
        inventories[name].append(identity(body, station, line, face, axis, plane, xyz, thickness, quality, source))

    for face in (-1, 1):
        yw = face*s.web_thickness_mm/2
        append('fullheight_web_ordinary', 'beam_web', 'whole_member', 'ordinary_excluding_welded_regions', str(face),
            'none', 'xz', (all_x, (yw, yw), (g['bottom_z_mm'], g['top_z_mm'])), s.web_thickness_mm, 'base', s.source)
    for end, tf, width, zz in (
        ('top', s.top_flange_thickness_mm, s.top_flange_width_mm, (g['top_z_mm'], s.depth_mm)),
        ('bottom', s.bottom_flange_thickness_mm, s.bottom_flange_width_mm, (0., g['bottom_z_mm']))):
        for face, z in zip(('lower_face', 'upper_face'), zz):
            append('fullheight_flange_'+end+'_ordinary', 'beam_'+end+'_flange', 'whole_member',
                'ordinary_excluding_all_welded_regions', face, 'none', 'xy', (all_x, (-width/2, width/2), (z, z)),
                tf, 'base', s.source)
        joint = getattr(s, 'longitudinal_'+end); z = g[end+'_z_mm']
        for face in (-1, 1):
            y = face*s.web_thickness_mm/2
            # Actual roots are separated from transverse lines by the unwelded
            # cope. At no point does an ordinary W0 declaration supersede them.
            for body, plane, thickness, transverse in (
                ('web', 'xz', s.web_thickness_mm, (y, y)),
                ('flange', 'xy', tf, tuple(sorted((y, y+face*joint.reinforcement_leg_mm))))):
                append('fullheight_longitudinal_'+body+'_'+end, 'beam_'+body+'_'+end,
                    'whole_member', 'longitudinal_'+end, str(face), 'x', plane,
                    (all_x, transverse, (z, z)), thickness, joint.quality.grade, joint.source)
        a = min(s.web_thickness_mm, tf)
        append('fullheight_longitudinal_cjp_throat_'+end, 'deposited_CJP_metal_'+end, 'whole_member',
            'longitudinal_'+end, 'fused_section', 'x', 'xz', (all_x, (-a/2, a/2), (z, z)),
            a, joint.quality.grade, joint.source)

    for station in stations:
        sid, x = station['station_id'], station['x_m']*1000
        for side in (-1, 1):
            yw = side*s.web_thickness_mm/2
            label = sid+':plate:'+('left' if side < 0 else 'right')
            for face in (-1, 1):
                xt = x+face*d.plate_thickness_mm/2
                xx = tuple(sorted((xt, xt+face*d.web_fillets.leg_mm)))
                length = min(g['web_length_mm'], d.web_fillets.qe_end_zone_length_mm)
                for key, zz, quality in (
                    ('fullheight_web_termination_bottom', (g['web_low_z_mm'], g['web_low_z_mm']+length), d.web_fillets.end_quality.grade),
                    ('fullheight_web_termination_top', (g['web_high_z_mm']-length, g['web_high_z_mm']), d.web_fillets.end_quality.grade),
                    ('fullheight_web_straight', (g['web_low_z_mm']+length, g['web_high_z_mm']-length), d.web_fillets.interior_quality.grade)):
                    if zz[0] >= zz[1]:
                        continue
                    append(key, 'beam_web', sid, label+':web:'+str(face), str(side), 'z', 'xz',
                        (xx, (yw, yw), zz), s.web_thickness_mm, quality, d.web_fillets.source)
                yy = tuple(sorted((yw+side*g['bottom_start_u_mm'], yw+side*d.outstand_mm)))
                xx = tuple(sorted((xt, xt+face*d.bottom_attachment.leg_mm)))
                append('fullheight_bottom_fillet_receiver', 'beam_bottom_flange', sid,
                    label+':bottom:'+str(face), 'upper_face', 'y', 'xy', (xx, yy, (g['bottom_z_mm'],)*2),
                    s.bottom_flange_thickness_mm, d.bottom_attachment.interior_quality.grade, d.bottom_attachment.source)
            half = d.plate_thickness_mm/2+d.top_cjp.reinforcement_leg_mm+d.top_cjp.reinforcement_tolerance_mm
            yy = tuple(sorted((yw+side*g['top_start_u_mm'], yw+side*d.outstand_mm)))
            append('fullheight_top_cjp_receiver', 'beam_top_flange', sid, label+':top_cjp', 'lower_face',
                'y', 'xy', ((x-half, x+half), yy, (g['top_z_mm'],)*2), s.top_flange_thickness_mm,
                d.top_cjp.quality.grade, d.top_cjp.source)

    classification = {
        'fullheight_web_ordinary': ('W0', 'W0'),
        'fullheight_flange_top_ordinary': ('W0', None),
        'fullheight_flange_bottom_ordinary': ('W0', None),
        'fullheight_web_straight': ('K3,21', 'K0,31'),
        'fullheight_web_termination_top': ('K3,21', 'K3,35'),
        'fullheight_web_termination_bottom': ('K3,21', 'K3,35'),
        'fullheight_top_cjp_receiver': ('K1,2', None),
        'fullheight_bottom_fillet_receiver': ('K2,2', None),
    }
    quality = {
        'fullheight_web_straight': _quality_issues(assessment, ('web_interior',)),
        'fullheight_web_termination_top': _quality_issues(assessment, ('web', 'web_ends')),
        'fullheight_web_termination_bottom': _quality_issues(assessment, ('web', 'web_ends')),
        'fullheight_top_cjp_receiver': _quality_issues(assessment, ('top_cjp',)),
        'fullheight_bottom_fillet_receiver': _quality_issues(assessment, ('bottom', 'bottom_interior', 'bottom_ends')),
    }
    for end in ('top', 'bottom'):
        joint = getattr(s, 'longitudinal_'+end)
        vertical = 'K2,41' if joint.quality.grade == 'QE' else 'K3,41'
        for role in ('web', 'cjp_throat', 'flange'):
            key = 'fullheight_longitudinal_'+role+'_'+end
            classification[key] = ('K0,33', None if role == 'flange' else vertical)
            quality[key] = _quality_issues(assessment, ('longitudinal_'+end,))

    for key in REGION_IDS:
        weld = 'cjp_throat' in key
        flange = key in ('fullheight_top_cjp_receiver', 'fullheight_bottom_fillet_receiver') or 'flange' in key
        demands = flange_demands if flange else web_demands
        transfer = None
        if weld:
            end = key.rsplit('_', 1)[1]
            thickness = getattr(s, end+'_flange_thickness_mm')
            a = min(s.web_thickness_mm, thickness)
            scale = s.web_thickness_mm/a
            # Equal-E fused longitudinal material shares the adjoining nominal
            # longitudinal field. Perpendicular/shear transfer uses q/t_eff.
            sx = max(web_demands[0], flange_demands[0])
            demands = (sx, web_demands[1]*scale, web_demands[2]*scale)
            transfer = dict(effective_thickness_mm=a, number_of_fused_sections_per_interface=1,
                normal_perpendicular_bound_mpa=demands[1], shear_parallel_bound_mpa=demands[2],
                line_vertical_n_per_mm=web_demands[1]*s.web_thickness_mm,
                line_longitudinal_n_per_mm=web_demands[2]*s.web_thickness_mm,
                fillet_45_degree_transform_used=False, reinforcement_strength_credit=False,
                source='CJP real: sigma_z=qz/t_eff, tau_xz=qx/t_eff; sigma_x nominal compatível em E igual.')
        try:
            r = _region_result(project, d, key, inventories[key], demands, classification[key],
                group_selection=group_selection, quality_pending=quality.get(key, ()), weld=weld, transfer=transfer)
            if 'ordinary' in key:
                r['excluded_regions'] = [v for v in REGION_IDS if 'ordinary' not in v]
                r['exclusion_policy'] = 'W0 somente no corpo livre; pés, recortes, soldas e acessórios estão excluídos, não sobrepostos a W0.'
            _append_region_result(out, key, r, d.input_signature, group_selection, REGION_CHECKS[key])
        except (ValueError, TypeError, KeyError, ArithmeticError) as exc:
            out['errors'].append(key+': '+str(exc)); _pending(out, key+'/invalid', str(exc))

    # A static fillet design is never recycled as a CJP detail merely because
    # the selected FAT label says CJP. Physical CJP geometry above is independent.
    if fixed_flange_detail is not None:
        joint = fixed_flange_detail.get('physical_joint') if isinstance(fixed_flange_detail, dict) else None
        if joint is None and isinstance(fixed_flange_detail, dict) and isinstance(fixed_flange_detail.get('design'), dict):
            joint = fixed_flange_detail['design'].get('physical_joint')
        if isinstance(fixed_flange_detail, dict) and fixed_flange_detail.get('project_signature') not in (None, input_signature(project)):
            reason = 'Detalhe longitudinal estático pertence a outro projeto.'
            out['errors'].append(reason); _pending(out, 'fullheight_longitudinal_stale_detail', reason)
        if joint != 'continuous_longitudinal_cjp_backgouged':
            reason = 'Detalhe longitudinal estático não identifica CJP real; filetes não podem ser relabelados em FAT.'
            out['errors'].append(reason); _pending(out, 'fullheight_longitudinal_type_conflict', reason)
    if fixed_station_detail is not None:
        out['fixed_station_detail_used_for_cyclic_transfer'] = False
        out['fixed_station_detail_scope'] = 'G/ELU separado; não transforma peso constante nem mínimo 45 kN em faixa FAT.'

    for i, c in enumerate(assessment['checks']):
        if not c['passed']:
            _pending(out, 'fullheight_detail_geometry/'+str(i), 'Geometria efetiva da interface insuficiente: '+c['check_id'], evidence=c)
    for i, reason in enumerate(assessment['pending']):
        if reason not in out['pending']:
            _pending(out, 'fullheight_fabrication/'+str(i), reason)
    if d.section.longitudinal_top.reinforcement_leg_mm-d.section.longitudinal_top.reinforcement_tolerance_mm <= 0:
        _pending(out, 'fullheight_longitudinal_local_mode',
            'Modo local cíclico da mesa carregada: falta reforço longitudinal físico para a variante publicada Fisher/Van de Pas 2002 p.68; checks nominais preservados.')

    family = family_evidence.get('fullheight_station_family')
    family_rows = {}
    if family is not None:
        try:
            if (type(family) is not dict or family.get('project_signature') != input_signature(project)
                    or family.get('complete') is not True or family.get('pending')
                    or not isinstance(family.get('stations'), list)):
                raise ValueError('Recibo de ações funcionais full-height incompleto ou de outro projeto.')
            rows = family['stations']
            if any(type(v) is not dict for v in rows):
                raise ValueError('Cada estação funcional deve ser um registro físico.')
            family_rows = {v.get('station_id'): v for v in rows}
            if set(family_rows) != {v['station_id'] for v in stations} or len(family_rows) != len(rows):
                raise ValueError('Recibo funcional omite ou duplica estação física.')
            for physical in stations:
                row = family_rows[physical['station_id']]
                if row.get('kind') != physical['kind'] or _number(row.get('x_m'), 'x da estação') != physical['x_m']:
                    raise ValueError('Recibo funcional não coincide com posição/função física da estação.')
                if row.get('complete') is not True or row.get('pending') or type(row.get('function_inventory')) is not dict:
                    raise ValueError('Inventário de funções da estação está incompleto.')
                _number(row.get('body_weight_kn'), 'G físico da estação')
                interval = row.get('bearing_interval_kn')
                support = physical['kind'] != 'intermediate'
                if not support:
                    if interval is not None:
                        raise ValueError('Reação bearing em intermediário exige caminho físico adicional próprio.')
                else:
                    if type(interval) not in (tuple, list) or len(interval) != 2:
                        raise ValueError('Apoio real deve preservar intervalo da mesma reação Rz, sem zerá-la.')
                    lo, hi = (_number(v, 'Rz físico', signed=True) for v in interval)
                    if lo > hi or lo < 0:
                        raise ValueError('Rz bearing exige intervalo ordenado compressivo; arrancamento não é apagado.')
                    bound = _number(row.get('bearing_abs_bound_kn'), 'Limite Rz físico')
                    if max(abs(lo), abs(hi)) > bound+1e-10*max(1., bound):
                        raise ValueError('Limite Rz não contém os extremos físicos.')
        except (ValueError, TypeError, KeyError, ArithmeticError) as exc:
            family_rows = {}
            out['errors'].append(str(exc))
            _pending(out, 'fullheight_station_family', str(exc))
    bearing = fullheight_bearing_geometry(d)
    for station in stations:
        sid = station['station_id']; support = station['kind'] != 'intermediate'
        row = family_rows.get(sid, {})
        functions = dict(station_id=sid, x_m=station['x_m'], station_kind=station['kind'],
            panel_stabilization=dict(status='covered_by_prescriptive_function',
                stress_is_zero_claimed=False, numerical_weld_fatigue_verification=False,
                source='NBR8800 5.4.3.1.3; static panel/detail gates remain independent'),
            selfweight_transfer=dict(status='constant_G_not_cyclic_range',
                artificial_range_added=False, minimum_45kn_added_to_fatigue=False),
            own_plate_and_transverse_welds=dict(status='covered_by_prescriptive_function' if not support else 'bearing_transfer_fatigue_pending',
                body='attached_stiffener_plate_not_beam_receiver', plane='yz',
                material=asdict(d.plate_material), thickness_mm=d.plate_thickness_mm,
                normal_detail_class=None, locations=('free_plate', 'own_toes', 'upper_cope', 'lower_cope'),
                stress_is_zero_claimed=False, throat_fatigue_verified=False,
                physical_interfaces=dict(top=dict(joint_type='CJP', effective_thickness_mm=g['CJP_effective_throat_mm'],
                    material=asdict(d.top_cjp.material), cyclic_demand=None),
                    web=dict(joint_type='fillet', effective_throat_mm=d.web_fillets.leg_mm/sqrt(2),
                    material=asdict(d.web_fillets.material), cyclic_demand=None),
                    bottom=dict(joint_type='fillet', effective_throat_mm=d.bottom_attachment.leg_mm/sqrt(2),
                    material=asdict(d.bottom_attachment.material), cyclic_demand=None))),
            vertical_bearing=dict(status='actual_support_function_pending' if support else 'not_applicable',
                source='Original support geometry and vertical Rz only, never inferred wheel share or fork wrench'),
            other_transfer=dict(status='not_attributed_without_physical_attachment',
                brace_coincidence_creates_load=False, fork_wrench_assigned=False))
        if support:
            functions['vertical_bearing']['geometry'] = bearing
            functions['vertical_bearing']['static_minimum_is_separate_fatigue_gate'] = True
            functions['vertical_bearing']['reaction_receipt'] = row.get('bearing_interval_kn')
            try:
                lower_results = _bearing_lower_regions(project, d, station, row, group_selection, assessment)
            except (ValueError, TypeError, ArithmeticError, KeyError) as exc:
                out['errors'].append(sid+': '+str(exc))
                lower_results = {prefix+'/'+sid: _unavailable_region(sid+': '+str(exc))
                    for prefix in BEARING_REGION_CHECKS if prefix.endswith('_lower')}
            try:
                exit_results, unit_fields = _bearing_exit_regions(project, d, station, row,
                    group_selection, assessment, metrics)
            except (ValueError, TypeError, ArithmeticError, KeyError) as exc:
                out['errors'].append(sid+': '+str(exc))
                exit_results = {prefix+'/'+sid: _unavailable_region(sid+': '+str(exc)) for prefix in BEARING_EXIT_PREFIXES}
                unit_fields = []
            out['bearing_reaction_fields'][sid] = unit_fields
            all_results = dict(lower_results, **exit_results)
            _qualify_receiver_receipts(project, d, station, row, assessment, out['regions'], all_results)
            for region, result in all_results.items():
                prefix = next(key for key in BEARING_REGION_CHECKS if region.startswith(key+'/'))
                _append_region_result(out, region, result, d.input_signature, group_selection, BEARING_REGION_CHECKS[prefix])
            lower_complete = all(v['domain_complete'] for v in lower_results.values())
            lower_satisfied = lower_complete and not any(v['criterion_exceedances'] for v in lower_results.values())
            exit_own = [v for key, v in exit_results.items() if 'receiver_' not in key]
            exit_complete = bool(exit_own) and all(v['domain_complete'] for v in exit_own)
            exit_satisfied = exit_complete and not any(v['criterion_exceedances'] for v in exit_own)
            receiver_results = [v for key, v in all_results.items() if 'receiver_' in key]
            receiver_complete = bool(receiver_results) and all(v['domain_complete'] for v in receiver_results)
            functions['vertical_bearing'].update(lower_introduction_complete=lower_complete,
                lower_introduction_bounds_satisfied=lower_satisfied, serial_exit_complete=exit_complete,
                serial_exit_bounds_satisfied=exit_satisfied, nominal_serial_group_field_available=bool(unit_fields),
                receiver_nominal_dependency_coverage_complete=receiver_complete,
                receiver_local_global_composition_complete=False, three_dimensional_receiver_interaction_claimed=False,
                reaction_bound_basis=REACTION_BOUND_BASIS, stationary_G_already_included_once=True,
                local_G_not_added_again=True, no_cycle_claim=True,
                status='nominal_serial_transfer_and_receiver_coverage_calculated' if lower_complete and exit_complete and receiver_complete
                    else 'nominal_serial_transfer_or_receiver_domain_pending')
            own = functions['own_plate_and_transverse_welds']
            own.update(status='own_serial_transfer_calculated' if lower_complete and exit_complete else 'bearing_transfer_fatigue_pending',
                normal_detail_class={'lower_plate': 'K4,41', 'web_root_plate': 'K4,5', 'top_plate': 'K2,5'},
                locations=('bottom_horizontal_plate_ligament', 'plate_connected_root', 'top_horizontal_plate_ligament'),
                cope_peak_elasticity_claimed=False,
                lower_introduction_complete=lower_complete, serial_exit_complete=exit_complete,
                throat_fatigue_verified=lower_satisfied and exit_satisfied)
            for interface, suffix in (('bottom', 'lower'), ('web', 'web'), ('top', 'top')):
                own['physical_interfaces'][interface].update(fatigue_region='fullheight_bearing_weld_'+suffix+'/'+sid,
                    cyclic_demand=None, absolute_reaction_bound_basis=REACTION_BOUND_BASIS,
                    stationary_G_already_included_once=True, local_G_not_added_again=True, no_cycle_claim=True)
            own['physical_interfaces']['top']['Rz_automatically_assigned'] = False
        if not support and row.get('bearing_additional_actions') is not None:
            try:
                additional_pending = _bearing_action_domain(project, sid, row)
            except (ValueError, TypeError, ArithmeticError, KeyError) as exc:
                out['errors'].append(sid+': '+str(exc))
                additional_pending = [sid+': '+str(exc)]
            for j, reason in enumerate(additional_pending):
                _pending(out, 'fullheight_intermediate_additional_transfer/'+sid+'/'+str(j), reason,
                    evidence=dict(station_id=sid, station_kind=station['kind'],
                        no_support_reaction_inferred=True, known_global_checks_preserved=True))
            if additional_pending:
                functions['other_transfer']['status'] = 'pending_actual_additional_transfer'
                functions['own_plate_and_transverse_welds']['status'] = 'prescriptive_stabilization_with_additional_transfer_pending'
        if not support and row.get('receiver_additional_nominal_fields') is not None:
            for role in ('web', 'top', 'bottom'):
                receiver_pending = _receiver_additional_domain(row, role)
                for j, reason in enumerate(receiver_pending):
                    _pending(out, 'fullheight_intermediate_receiver_field/'+sid+'/'+role+'/'+str(j),
                        sid+': '+reason, evidence=dict(station_id=sid, receiver_body=role,
                            no_support_reaction_inferred=True, known_global_checks_preserved=True))
                if receiver_pending:
                    functions['other_transfer']['status'] = 'pending_independent_receiver_nominal_field'
                    functions['own_plate_and_transverse_welds']['status'] = 'prescriptive_stabilization_with_independent_receiver_field_pending'
        if row.get('function_inventory', {}).get('other_transfer') not in (None, 'not_applicable'):
            functions['other_transfer']['status'] = 'pending_actual_additional_transfer'
            _pending(out, 'fullheight_additional_transfer/'+sid, sid+': ação de transferência adicional declarada exige seu consumidor próprio; não é apagada pelo estabilizador.')
        out['functions'].append(functions)
    out['design_requirements'] = [
        'Fontes, EPS/WPS e qualidade tipadas são requisitos de projeto, não certificação de execução/inspeção.',
        'Grupo '+group_selection['component_group']+' e capacidade kappa=-1 preservados; sem classificação operacional automática.',
        'sigmaT FAT integral; sem fator estático 0,75, história entre faces ou faixa cíclica fabricada de G.',
        'Bearing nominal em série: própria chapa K4,41/K4,5/K2,5 e gargantas D.3; receptor condicionado aos checks direcionais e detalhe publicado, sem interação 3D ou aprovação automática do apoio.',
        'Rz é limite absoluto da reação TOTAL Caso I, com G estacionário já incluído globalmente uma vez; não amplitude. G local não é novamente somado e sua alteração física exige recalcular a resposta global.',
        'Cobertura publicada local superior: Fisher/Van de Pas 2002 p.68, CJP longitudinal reforçada especificada; não tensor 3D universal.',
    ]
    out['numerical_bounds_satisfied'] = not out['criterion_exceedances'] and not out['errors']
    out['complete'] = bool(out['regions']) and not out['pending'] and not out['errors'] and all(r['domain_complete'] for r in out['regions'].values())
    out['all_nominal_bounds_satisfied'] = out['complete'] and out['numerical_bounds_satisfied']
    out['status'] = 'INVALID_INPUT' if out['errors'] else 'INCONCLUSIVE_SUFFICIENT_BOUND' if out['criterion_exceedances'] else 'NOMINAL_SCOPE_PENDING' if out['pending'] else 'NOMINAL_FATIGUE_COMPLETE'
    return out


__all__ = ['FullHeightRegionIdentity', 'evaluate_fullheight_family_bounds', 'REGION_IDS', 'REGION_CHECKS',
    'BEARING_REGION_CHECKS', 'required_fullheight_fatigue_regions', 'required_fullheight_fatigue_checks', 'METRICS', 'K2_MPA']
