"""Conservative supplemental EN 1993-1-1:2025 Annex C.2 member check.

Not native NBR 8800 resistance. NBR 8400 use requires declared engineering
adoption and its own consistent common resistance margin. Elastic strengths,
curve d, full-span axial lengths and upper interaction factors forgo benefits.
Pure-flexure Mcr may retain real lateral braces through an explicit lower bound.
The total-section stress check is only global N/M/B/shear, not local wheels.
"""
from dataclasses import dataclass,field,replace
from functools import lru_cache
from types import SimpleNamespace
import math

from .autonomous_nominal_lengths import NominalResistancePlan,nominal_ltb_reference
from .beam_torsion import VlasovBeam,LateralBrace,thin_wall_i_torsion_properties,_number
from .beam_stability import StabilitySegment,HeightPointLoad,HeightLineLoad,conservative_reference_bound
from .beam_stability_bound import conservative_braced_flexure_bound,BraceBoundNumericalError
from .stress_8400 import _check
from .beam_end_projection import projection_flexure_reference_bound

SOURCE="DIN EN 1993-1-1:2025, 7.5.2(10), 7.5.2(12), 8.2.1(4)-(5), 8.3.1.3, 8.3.1.4(2), 8.3.2.2(2), 8.3.2.3(2), Tables 7.3/7.4, 8.7/8.8/8.9 and Annex C.2; conservative envelope"


@dataclass
class EN2025C2Input:
    span_mm: float=0.
    E_mpa: float=210000.
    G_mpa: float=81000.
    fy_mpa: float=0.
    depth_mm: float=0.
    flange_width_mm: float=0.
    flange_thickness_mm: float=0.
    web_thickness_mm: float=0.
    area_mm2: float=0.
    major_inertia_mm4: float=0.
    minor_inertia_mm4: float=0.
    major_elastic_modulus_mm3: float=0.
    minor_elastic_modulus_mm3: float=0.
    axial_abs_max_n: float=0.
    compression_max_n: float=0.
    major_moment_max_nmm: float=0.
    minor_moment_max_nmm: float=0.
    bimoment_max_nmm2: float=0.
    shear_stress_bound_mpa: float=0.
    resistance_gamma: float=1.
    major_segments: tuple[StabilitySegment,...]=field(default_factory=tuple)
    height_points: tuple[HeightPointLoad,...]=field(default_factory=tuple)
    height_lines: tuple[HeightLineLoad,...]=field(default_factory=tuple)
    uniform_fork_free_warping_system: bool=False
    structural_steel_ambient: bool=False
    complete_same_case_envelopes: bool=False
    method_adoption_source: str=""
    section_resistance_mode: str="full_section"
    classification_segments: tuple[StabilitySegment,...]=field(default_factory=tuple)
    use_nbr8800_chi_cap: bool=False
    lateral_braces: tuple[LateralBrace,...]=field(default_factory=tuple)
    left_projection_mm: float=0.
    right_projection_mm: float=0.
    projection_vertical_n_per_mm: float=0.
    projection_load_height_mm: float=0.
    nominal_length_plan: NominalResistancePlan|None=None
    nominal_radius_sum_nmm: float=0.


class _ClassificationSegments:
    """Identity key retaining an immutable tuple of frozen StabilitySegments.

    dataclasses.replace shares this large tuple between reference positions.
    Identity avoids repeatedly hashing thousands of unchanged segment values;
    holding the tuple prevents id reuse. Other tuples cannot alias this cache,
    including bool-valued inputs that compare equal to numeric values.
    """
    __slots__=('segments',)
    def __init__(self,segments):self.segments=segments
    def __hash__(self):return id(self.segments)
    def __eq__(self,other):return isinstance(other,_ClassificationSegments) and self.segments is other.segments


@lru_cache(maxsize=16,typed=True)
def _web_class3_cached(fy,span,area,depth,tf,ix,segment_key):
    data=SimpleNamespace(fy_mpa=fy,span_mm=span,area_mm2=area,depth_mm=depth,
                         flange_thickness_mm=tf,major_inertia_mm4=ix,
                         classification_segments=segment_key.segments)
    return tuple(_web_class3_uncached(data).items())


def web_class3_limit(data):
    segments=data.classification_segments
    # Only the exact immutable carrier may use identity-based reuse. Preserve
    # the original validation path for lists/subclasses and malformed inputs.
    if type(segments) is not tuple or any(type(s) is not StabilitySegment for s in segments):
        return _web_class3_uncached(data)
    return dict(_web_class3_cached(data.fy_mpa,data.span_mm,data.area_mm2,
                data.depth_mm,data.flange_thickness_mm,data.major_inertia_mm4,
                _ClassificationSegments(segments)))


def _web_class3_uncached(data):
    """Worst concurrent web membrane gradient, exact within each N/M segment.

    B and weak-axis bending are zero on the web midline in the adopted
    thin-wall model. No low-stress epsilon enlargement (7.5.2(9)) is used:
    that enlargement is prohibited for member buckling by 7.5.2(10).
    Tension-side benefit beyond pure bending is deliberately discarded.
    """
    eps=math.sqrt(235/data.fy_mpa)
    if not data.classification_segments:
        return {'limit':38*eps,'psi':1.,'basis':'uniform_compression_sufficient_gate','segments':0}
    worst=None
    for seg in data.classification_segments:
        if not isinstance(seg,StabilitySegment):raise ValueError('Segmento de classificação inválido')
        for key,value in vars(seg).items():_number(value,key)
        if not 0<=seg.x0_mm<seg.x1_mm<=data.span_mm:raise ValueError('Segmento de classificação fora do vão')
        a=2*seg.major_left_nmm-4*seg.major_mid_nmm+2*seg.major_right_nmm
        b=-3*seg.major_left_nmm+4*seg.major_mid_nmm-seg.major_right_nmm
        c=seg.major_left_nmm
        values=[abs(c),abs(seg.major_right_nmm)]
        if a and 0<-b/(2*a)<1:values.append(abs(seg.moment(-b/(2*a))))
        if a:
            disc=b*b-4*a*c
            if disc>=0 and any(0<=(-b+sign*math.sqrt(disc))/(2*a)<=1 for sign in (-1,1)):values.append(0.)
        elif b and 0<=-c/b<=1:values.append(0.)
        moment=min(values) if seg.compression_n>0 else max(values)
        axial=seg.compression_n/data.area_mm2
        bend=moment*(data.depth_mm-2*data.flange_thickness_mm)/(2*data.major_inertia_mm4)
        high,low=axial+bend,axial-bend
        if high<=0:continue
        psi=max(-1.,min(1.,low/high))
        limit=121*eps if psi<=-1 else 38*eps/(.608+.343*psi+.049*psi*psi)
        if worst is None or limit<worst['limit']:
            worst={'limit':limit,'psi':psi,'compression_n':seg.compression_n,'major_abs_nmm':moment,
                   'maximum_compression_mpa':high,'minimum_compression_mpa':low}
    if worst is None:worst={'limit':None,'psi':None}
    return {**worst,'basis':'EN2025_Table7.3_concurrent_membrane_gradient','segments':len(data.classification_segments)}


def _chi_d(slenderness):
    phi=.5*(1+.76*(slenderness-.2)+slenderness**2)
    return min(1.,1/(phi+phi*math.sqrt(max(0.,1-(slenderness/phi)**2))))


def _chi_adopted(slenderness,cap_nbr):
    en=_chi_d(slenderness)
    if not cap_nbr:return en
    nbr=.658**(slenderness*slenderness) if slenderness<=1.5 else .877/(slenderness*slenderness)
    return min(en,nbr)


def _calculate_supplemental_c2(data: EN2025C2Input):
    result={"kind":"supplemental_en2025_c2","source":SOURCE,"input_valid":True,
        "status":"PENDENTE","full_compliance":False,"checks":[],"pending":[],"errors":[],
        "intermediates":{},"member_check_complete":False,"limitations":[
            "Verificação suplementar EN/adotada; não é fórmula nativa NBR 8800 nem aprovação integral da viga.",
            "Compressão com comprimentos integrais, resistências elásticas, curva d e fatores majorados; Mcr pode incluir vínculos laterais reais por limite inferior Green/modal, sem presumir garfo intermediário.",
            "Envoltórias do mesmo caso, sem alegação de concomitância entre máximos; seção retangular de paredes finas consistente para J/Cw.",
            "Tensões locais de rodas, flambagem local por cisalhamento/contato, fadiga, serviço e resistência dos apoios/travamentos permanecem separados.",
            "Não satisfazer um limite conservador exige outro dimensionamento/avaliação; não demonstra a carga física de colapso."]}
    if not isinstance(data,EN2025C2Input):
        result.update(input_valid=False,errors=["EN2025C2Input obrigatório."]);return result
    d=data
    try:
        positive=("span_mm","E_mpa","G_mpa","fy_mpa","depth_mm","flange_width_mm","flange_thickness_mm",
                  "web_thickness_mm","area_mm2","major_inertia_mm4","minor_inertia_mm4",
                  "major_elastic_modulus_mm3","minor_elastic_modulus_mm3","resistance_gamma")
        nonnegative=("axial_abs_max_n","compression_max_n","major_moment_max_nmm","minor_moment_max_nmm",
                     "bimoment_max_nmm2","shear_stress_bound_mpa","left_projection_mm","right_projection_mm","projection_vertical_n_per_mm")
        for key in positive: _number(getattr(d,key),key,True)
        for key in nonnegative:
            _number(getattr(d,key),key)
            if getattr(d,key)<0: raise ValueError(key+": magnitude não negativa obrigatória")
        _number(d.projection_load_height_mm,"projection_load_height_mm")
        if d.resistance_gamma<1: raise ValueError("resistance_gamma deve ser >=1")
        if d.area_mm2>d.depth_mm*d.flange_width_mm: raise ValueError("Área excede retângulo envolvente")
        if d.major_inertia_mm4<d.minor_inertia_mm4: raise ValueError("Eixo maior/menor inconsistente")
        if (d.major_inertia_mm4>d.area_mm2*d.depth_mm**2/4 or
            d.minor_inertia_mm4>d.area_mm2*d.flange_width_mm**2/4):
            raise ValueError("Inércia excede limite físico do retângulo envolvente")
        if d.axial_abs_max_n<d.compression_max_n: raise ValueError("Envelope axial absoluto menor que compressão")
        for key in ("uniform_fork_free_warping_system","structural_steel_ambient","complete_same_case_envelopes","use_nbr8800_chi_cap"):
            if type(getattr(d,key)) is not bool: raise ValueError(key+": booleano obrigatório")
        if not isinstance(d.method_adoption_source,str): raise ValueError("Fonte do método deve ser texto")
        if d.section_resistance_mode not in ('full_section','flanges_only'):raise ValueError('Modo resistente desconhecido')
        classification=web_class3_limit(d)
        p=thin_wall_i_torsion_properties(d.depth_mm,d.flange_width_mm,d.flange_thickness_mm,d.web_thickness_mm)
        if d.section_resistance_mode=='flanges_only':
            b,tf,h0=d.flange_width_mm,d.flange_thickness_mm,p['h0_mm']
            A=2*b*tf;Ix=2*(b*tf**3/12+b*tf*(h0/2)**2);Iy=2*tf*b**3/12
            d=replace(d,area_mm2=A,major_inertia_mm4=Ix,minor_inertia_mm4=Iy,
                      major_elastic_modulus_mm3=2*Ix/d.depth_mm,minor_elastic_modulus_mm3=2*Iy/b)
            p['J_ignored_web_mm4']=p['J_mm4']-2*b*tf**3/3
            p['J_mm4']=2*b*tf**3/3;p['Iy_mm4']=Iy
        beam=VlasovBeam(d.span_mm,d.E_mpa,d.G_mpa,p["J_mm4"],p["Cw_mm6"])
        for s in d.major_segments:
            _number(s.compression_n,"segment compression_n")
            if abs(s.compression_n)>d.axial_abs_max_n*(1+1e-10):
                raise ValueError("Envelope axial absoluto inferior ao diagrama")
        segments=tuple(replace(s,compression_n=0.) for s in d.major_segments)
        bound=conservative_reference_bound(beam,d.minor_inertia_mm4,d.major_inertia_mm4,d.area_mm2,
                                           segments,d.height_points,d.height_lines)
        # Preserve validation of the ORIGINAL diagram before replacing its
        # reference by a resistance-only segmented bound.
        if bound['Mmax_nmm']>d.major_moment_max_nmm*(1+1e-10):
            raise ValueError('Envelope M maior inferior ao diagrama de referência')
        if d.nominal_length_plan is not None:
            if type(d.nominal_length_plan) is not NominalResistancePlan or d.nominal_length_plan.analysis_span_mm!=d.span_mm:
                raise ValueError('Plano de comprimentos incompatível com o vão da análise.')
            d.nominal_length_plan.__post_init__()
            _number(d.nominal_radius_sum_nmm,'nominal_radius_sum_nmm')
            # This public boundary can independently reconstruct the vertical
            # adverse radius already present in its reference loads. Extra
            # lateral/stationary contributions remain the adapter's obligation.
            required_radius=math.fsum([max(0.,q.vertical_down_n*q.height_from_cs_mm) for q in d.height_points]+[max(0.,q.vertical_down_n_per_mm*q.height_from_cs_mm)*(q.x1_mm-q.x0_mm) for q in d.height_lines])
            if d.nominal_radius_sum_nmm<required_radius or d.nominal_radius_sum_nmm<0:
                raise ValueError('Raio nominal inferior às ações de altura da própria referência.')
            if d.lateral_braces:raise ValueError('Não combinar referência física de travas com o ramo nominal de comprimentos.')
            if d.nominal_length_plan.fork_positions_mm:
                bound=nominal_ltb_reference(d.nominal_length_plan,EIweak_Nmm2=d.E_mpa*d.minor_inertia_mm4,ECw_Nmm4=beam.ECw,
                    moment_abs_bound_Nmm=d.major_moment_max_nmm,global_radius_bound_Nmm=d.nominal_radius_sum_nmm)
        if d.lateral_braces:
            try:
                bound=conservative_braced_flexure_bound(beam,d.minor_inertia_mm4,segments,
                            d.height_points,d.height_lines,d.lateral_braces,base_modes=8)
            except BraceBoundNumericalError as exc:
                bound['brace_credit_numerical_fallback']=str(exc)
                result['limitations'].append('Condicionamento dos vínculos não qualificado para benefício em Mcr; mantido limite inferior integral sem crédito: '+str(exc))
        if d.left_projection_mm or d.right_projection_mm:
            tails=[projection_flexure_reference_bound(beam,d.minor_inertia_mm4,a,
                        d.projection_vertical_n_per_mm,d.projection_load_height_mm)
                   for a in (d.left_projection_mm,d.right_projection_mm)]
            main_factor=bound['load_factor_lower_bound']
            factors=[x for x in [main_factor,*(r['load_factor_lower_bound'] for r in tails)] if x is not None]
            bound={**bound,'main_span_load_factor_lower_bound':main_factor,
                'load_factor_lower_bound':min(factors) if factors else None,
                'main_span_Mmax_nmm':bound['Mmax_nmm'],
                'Mmax_nmm':max(bound['Mmax_nmm'],*(r['major_moment_bound_nmm'] for r in tails)),
                'physical_projection_reference_bounds':tails,
                'physical_projection_combination':'Geometric energy / elastic energy <= max(mu_span,mu_left,mu_right); free root warping in reference, continuity relaxed conservatively.'}
            result['limitations'].append('Projeções físicas sem rodas, força axial ou torque externo: flexão pelo peso distribuído incluída; referência elástica combina o vão e as caudas pelo máximo dos coeficientes energéticos. Empenamento livre nas pontas físicas; rigidez favorável das caudas não creditada no Mcr do vão.')
        if bound["Mmax_nmm"]>d.major_moment_max_nmm*(1+1e-10): raise ValueError("Envelope M maior inferior ao diagrama de referência")
        if any(s.compression_n>d.compression_max_n*(1+1e-10) for s in d.major_segments):
            raise ValueError("Envelope N inferior ao diagrama de referência")
    except (ValueError,TypeError,OverflowError,AttributeError) as exc:
        result.update(input_valid=False,errors=[str(exc)]);return result
    for flag,msg in ((d.uniform_fork_free_warping_system,"Domínio físico: I simétrico reto/uniforme, garfos nos eixos finais, pontas físicas livres e sem distorção/aberturas não qualificado."),
                     (d.structural_steel_ambient,"Material de aço estrutural à temperatura ambiente não qualificado."),
                     (d.complete_same_case_envelopes,"Envoltórias completas do mesmo caso e bases de ação não qualificadas.")):
        if not flag: result["pending"].append(msg)
    if not d.method_adoption_source.strip(): result["pending"].append("Adoção e margem resistente do método suplementar não identificadas.")
    if not 200<=d.fy_mpa<=700: result["pending"].append("fy fora do domínio de aço estrutural adotado de 200–700 MPa.")
    # Full compression is an intentionally conservative sufficient class-3 gate.
    # Failure of this gate is not a claim that the actual combined state is class4.
    eps=math.sqrt(235/d.fy_mpa)
    flange_ratio=(d.flange_width_mm-d.web_thickness_mm)/(2*d.flange_thickness_mm)
    web_ratio=(d.depth_mm-2*d.flange_thickness_mm)/d.web_thickness_mm
    flange_ok=flange_ratio<=14*eps
    web_ok=classification['limit'] is None or web_ratio<=classification['limit']
    if not flange_ok:
        result['pending'].append('Gate suficiente de classe 1–3 das mesas sob compressão uniforme não atendido.')
    if d.section_resistance_mode=='full_section' and not web_ok:
        result['pending'].append('Gate suficiente de classe 1–3 da alma não atendido para o gradiente concomitante disponível.')
    if d.section_resistance_mode=='flanges_only':
        result['limitations'].append('EN 7.5.2(12): alma atribuída somente ao cisalhamento; A/I/W resistentes e rigidez de referência somente das mesas, inclusive J sem parcela da alma; Cw setorial das mesas inalterado. Verificação local/por cisalhamento da alma permanece separada.')
    fy,g,L=d.fy_mpa,d.resistance_gamma,d.span_mm
    NR=d.area_mm2*fy;MRx=d.major_elastic_modulus_mm3*fy;MRy=d.minor_elastic_modulus_mm3*fy
    BR=p["Cw_mm6"]*fy/p["omega_tip_mm2"]
    Ny=math.pi**2*d.E_mpa*d.major_inertia_mm4/L**2
    analysis_Nz=math.pi**2*d.E_mpa*d.minor_inertia_mm4/L**2
    minor_length=d.nominal_length_plan.minor_flexural_mm if d.nominal_length_plan is not None else L
    Nz=math.pi**2*d.E_mpa*d.minor_inertia_mm4/minor_length**2
    if d.nominal_length_plan is not None and d.compression_max_n>min(Ny,analysis_Nz)/25:
        result["pending"].append("Gate de análise de primeira ordem: Ncomp excede min(Ncr,forte,Ncr,fraco)/25 com o vão integral; reduzir comprimento resistente não altera esse limite.")
    NT=(beam.GJ+beam.ECw*math.pi**2/L**2)/((d.major_inertia_mm4+d.minor_inertia_mm4)/d.area_mm2)
    ly,lz,lT=math.sqrt(NR/Ny),math.sqrt(NR/Nz),math.sqrt(NR/NT)
    chiy,chiz,chiT=(_chi_adopted(l,d.use_nbr8800_chi_cap) for l in (ly,lz,lT))
    chiz_used=min(chiz,chiT)
    Mcr=bound["load_factor_lower_bound"]*bound["Mmax_nmm"] if bound["load_factor_lower_bound"] is not None else None
    if d.major_moment_max_nmm>0 and (Mcr is None or Mcr<=0):
        result["pending"].append("Diagrama de momento/altura não permite obter Mcr de flexão para C.2.")
        chiLT=None;llt=None
    else:
        llt=math.sqrt(MRx/Mcr) if Mcr else 0.;chiLT=_chi_adopted(llt,d.use_nbr8800_chi_cap)
    b_ratio=d.bimoment_max_nmm2/BR
    if b_ratio>.3*(1+1e-12): result["pending"].append("Fora do domínio C.2(2): BEd/BRk excede 0,30.")
    sigma=d.axial_abs_max_n/d.area_mm2+d.major_moment_max_nmm/d.major_elastic_modulus_mm3+d.minor_moment_max_nmm/d.minor_elastic_modulus_mm3+d.bimoment_max_nmm2*p["omega_tip_mm2"]/p["Cw_mm6"]
    equivalent=math.hypot(sigma,math.sqrt(3)*d.shear_stress_bound_mpa)
    check=_check("en2025_c2_global_section_bound","Seção global: limite elástico conservador N/M/B/cisalhamento",equivalent,fy/g,
        "sqrt((|N|/A+|Mx|/Wx+|My|/Wy+|B|omega/Cw)^2+3*tau_bound^2)<=fy/gamma","8.2.1(4)-(5)")
    check["source"]=SOURCE;result["checks"].append(check)
    result["intermediates"].update(p)
    result["intermediates"].update(NRk_n=NR,major_MRk_nmm=MRx,minor_MRk_nmm=MRy,BRk_nmm2=BR,
        Ncr_major_n=Ny,Ncr_minor_n=Nz,Ncr_torsional_n=NT,lambda_major=ly,lambda_minor=lz,lambda_torsion=lT,
        chi_major=chiy,chi_minor=chiz,chi_torsion=chiT,chi_minor_used=chiz_used,
        nbr8800_chi_cap_applied=d.use_nbr8800_chi_cap,chi_major_en_d=_chi_d(ly),chi_minor_en_d=_chi_d(lz),chi_torsion_en_d=_chi_d(lT),
        Mcr_lower_bound_nmm=Mcr,lambda_LT=llt,chi_LT=chiLT,bimoment_characteristic_ratio=b_ratio,
        flange_c_over_t=flange_ratio,web_c_over_t=web_ratio,class3_flange_limit=14*eps,class3_web_limit=classification["limit"],
        web_classification=classification,web_class3_sufficient=web_ok,flange_class3_sufficient=flange_ok,
        section_resistance_mode=d.section_resistance_mode,area_used_mm2=d.area_mm2,major_inertia_used_mm4=d.major_inertia_mm4,
        minor_inertia_used_mm4=d.minor_inertia_mm4,major_modulus_used_mm3=d.major_elastic_modulus_mm3,minor_modulus_used_mm3=d.minor_elastic_modulus_mm3,
        normal_stress_bound_mpa=sigma,equivalent_stress_bound_mpa=equivalent,elastic_reference_bound=bound)
    if d.nominal_length_plan is not None:
        result["intermediates"].update(nominal_resistance_lengths=d.nominal_length_plan.evidence(),analysis_Ncr_major_n=Ny,analysis_Ncr_minor_n=analysis_Nz,analysis_axial_gate_limit_n=min(Ny,analysis_Nz)/25,analysis_axial_gate_satisfied=d.compression_max_n<=min(Ny,analysis_Nz)/25)
        result["limitations"].append("Comprimentos resistentes nominais; a análise mantém apenas os garfos finais. Posições não geram reações, redistribuição nem redução de vãos de serviço. Eficácia e ligação das contenções são requisitos externos, não dimensionados aqui.")
    if not result["pending"]:
        ny=d.compression_max_n/(chiy*NR/g);nz=d.compression_max_n/(chiz_used*NR/g)
        my=d.major_moment_max_nmm/(chiLT*MRx/g);mz=d.minor_moment_max_nmm/(MRy/g)
        # Upper bounds of both elastic and plastic table columns for Cm<=1.
        kyy=1+.8*ny;kzz=1+1.4*nz;kyz=kzz;kzy=max(1.,.8*kyy)
        torsion=1.4*d.bimoment_max_nmm2/(BR/g) # kw=.7, kzw=1, kalpha=2
        U1=ny+kyy*my+kyz*mz+torsion;U2=nz+kzy*my+kzz*mz+torsion
        result["intermediates"].update(ny=ny,nz=nz,my=my,mz=mz,kyy=kyy,kzz=kzz,kyz=kyz,kzy=kzy,
                                      kw=.7,kzw=1.,kalpha=2.,torsion_term=torsion,C1_bound=U1,C2_bound=U2)
        for id_,name,value in (("en2025_c2_major_interaction","C.1: estabilidade combinada, limite superior",U1),
                               ("en2025_c2_minor_interaction","C.2: estabilidade combinada, limite superior",U2)):
            check=_check(id_,name,value,1.,"N/(chi NR/gamma)+k Mmajor/(chiLT MR/gamma)+k Mminor/(MR/gamma)+1.4 B/(BR/gamma)<=1","Annex C.2")
            check.update(source=SOURCE,unit="adimensional");result["checks"].append(check)
    if not all(math.isfinite(c["demand"]) and math.isfinite(c["capacity"]) for c in result["checks"]):
        result.update(input_valid=False,errors=["Resultado numérico não finito"],checks=[]);return result
    result["member_check_complete"]=not result["pending"]
    result["status"]="RESULTADO SUPLEMENTAR PARCIAL" if not result["pending"] else "PENDENTE"
    if any(c["status"]=="NÃO ATENDE" for c in result["checks"]): result["status"]+=" — NÃO ATENDE AO LIMITE ADOTADO"
    return result


def calculate_supplemental_c2(data: EN2025C2Input):
    """Return a qualified conservative EN/adopted-method member envelope.

    No force conversion or automatic action/resistance factor is performed.
    Invalid numeric inputs/derived overflow fail closed without partial checks.
    """
    try:
        result=_calculate_supplemental_c2(data)
        def finite(value):
            if isinstance(value,float): return math.isfinite(value)
            if isinstance(value,dict): return all(finite(v) for v in value.values())
            if isinstance(value,(tuple,list)): return all(finite(v) for v in value)
            return True
        if not finite(result): raise ValueError("Resultado numérico não finito")
        return result
    except (ValueError,TypeError,OverflowError,ZeroDivisionError,AttributeError) as exc:
        return {"kind":"supplemental_en2025_c2","source":SOURCE,"input_valid":False,
                "status":"PENDENTE","full_compliance":False,"member_check_complete":False,
                "checks":[],"pending":[],"errors":[str(exc)],"intermediates":{},"limitations":[]}
