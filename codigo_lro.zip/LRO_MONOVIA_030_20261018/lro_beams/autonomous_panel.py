"""Sufficient elastic stability bound for one four-edge-supported web panel.

This is an explicitly derived supplementary plate method, not the simplified
uniaxial-plus-shear interaction printed in NBR 8400-2 C.2.2. It includes both
in-plane compression directions. It takes no plastic/postbuckling benefit.

For the SAME simply supported rectangular Kirchhoff plate, write elastic
bending energy K and X=t*integral(w_x²), Z=t*integral(w_z²). The exact uniform
compression eigenvalues imply X<=K/sigma_crx and Z<=K/sigma_crz. For a
SPATIALLY VARIABLE shear stress, Cauchy gives
|t*integral(tau(x,z)*w_x*w_z)| <= tau_max*t*integral(|w_x*w_z|)
<= tau_max*sqrt(XZ). Therefore arbitrary spatial in-plane stress fields
bounded IN ABSOLUTE VALUE by sx,sz,tau have destabilizing work <= K*q, where
q=sx/sigma_crx+sz/sigma_crz+2*tau/sqrt(sigma_crx*sigma_crz). q<1 is sufficient.
The bound deliberately overestimates interaction and uses no favourable
stress gradient. Edges must actually sustain transverse panel displacement.
It says nothing about global member buckling, attachment fatigue, or distortion.

Both normal inputs are ABSOLUTE envelopes over the same panel, including
tension. Treating them as compression everywhere is conservative for geometric
work; their absolute character is essential for the equivalent-stress check.
The entire safety-factored load path is kept elastic by limiting its equivalent
stress to the proportional limit. This certifies the requested safety factor,
without claiming that a higher calculated elastic eigenvalue is attainable
before plasticity. This avoids inventing an
inelastic extension for the biaxial interaction. NBR 8400-2 5.4/Table13 maximum
flat-element factors 1.70/1.50/1.35 are used for cases I/II/III respectively.
"""
import math

SOURCE='Modelo energético complementar de placa retangular apoiada nas quatro bordas; NBR 8400-2, 5.4, Anexo C.2.1 e Tabela 13; Navier/Rayleigh e desigualdade de Cauchy'
MECHANICS_SOURCE='MIT 2.081J Plates and Shells (2007), Lecture Notes, 4.3: https://ocw.mit.edu/courses/2-081j-plates-and-shells-spring-2007/1bd32d641a2b41ca518591d981405393_lecturenote.pdf'


def _positive(value,name,zero=False):
    if isinstance(value,bool) or not isinstance(value,(float,int)) or not math.isfinite(value) or (value<0 if zero else value<=0):
        raise ValueError(name+': valor finito '+('não negativo' if zero else 'positivo')+' obrigatório.')


def uniform_compression_critical(a_mm,b_mm,t_mm,E_mpa,poisson=.3):
    """Exact minimum over integer Navier modes, compression along a."""
    for name,value in [('a',a_mm),('b',b_mm),('t',t_mm),('E',E_mpa)]:_positive(value,name)
    if isinstance(poisson,bool) or not math.isfinite(poisson) or not -1<poisson<.5:raise ValueError('Poisson fora do domínio elástico.')
    alpha=a_mm/b_mm
    modes={max(1,math.floor(alpha)),max(1,math.ceil(alpha))}
    m=min(modes,key=lambda j:(j/alpha+alpha/j)**2)
    k=(m/alpha+alpha/m)**2
    stress=k*math.pi**2*E_mpa/(12*(1-poisson**2))*(t_mm/b_mm)**2
    return {'critical_mpa':stress,'mode_m':m,'mode_n':1,'k':k,'aspect_ratio':alpha}


def evaluate_panel_bound(*,a_mm,b_mm,t_mm,E_mpa,fy_mpa,sigma_longitudinal_abs_bound_mpa,
                         sigma_transverse_abs_bound_mpa,shear_bound_mpa,load_case,
                         four_edges_supported,restraint_evidence,poisson=.3):
    """Sufficient ideal thin-plate certificate using absolute stress envelopes.

    The caller establishes the four-edge local displacement idealization and
    applicable thin-plate geometry. Finite boundary flexibility, residual stress,
    initial imperfections and member/global-distortional modes are not solved
    here; a generic ``verified`` flag is not their mechanical derivation.
    """
    for name,value in [('fy',fy_mpa),('sx',sigma_longitudinal_abs_bound_mpa),('sz',sigma_transverse_abs_bound_mpa),('tau',shear_bound_mpa)]:
        _positive(value,name,zero=name!='fy')
    result={'source':SOURCE,'complete':False,'checks':[],'pending':[],'intermediates':{},'scope':'Estabilidade elástica local do painel; modos globais e distorcionais não incluídos.'}
    if (four_edges_supported is not True or not isinstance(restraint_evidence,dict)
            or restraint_evidence.get('verified_by_calculation') is not True
            or not isinstance(restraint_evidence.get('source'),str)
            or not restraint_evidence['source'].strip()):
        result['pending'].append('Faltam evidências calculadas de sustentação das quatro bordas do painel.');return result
    if load_case not in ('I','II','III'):raise ValueError('Caso admissível I, II ou III obrigatório; não converter ELU implicitamente.')
    x=uniform_compression_critical(a_mm,b_mm,t_mm,E_mpa,poisson)
    z=uniform_compression_critical(b_mm,a_mm,t_mm,E_mpa,poisson)
    sx=sigma_longitudinal_abs_bound_mpa;sz=sigma_transverse_abs_bound_mpa;tau=shear_bound_mpa
    q=sx/x['critical_mpa']+sz/z['critical_mpa']+2*tau/math.sqrt(x['critical_mpa']*z['critical_mpa'])
    nu={'I':1.70,'II':1.50,'III':1.35}[load_case]
    proportional=190. if fy_mpa==240 else 290. if fy_mpa==355 else .76*fy_mpa
    # Opposite normal signs yield the greatest plane-stress equivalent stress
    # within the supplied absolute envelopes. Compression-only maxima could
    # not establish this material-domain check.
    equivalent=math.sqrt(sx*sx+sz*sz+sx*sz+3*tau*tau)
    result['intermediates']={'longitudinal_critical':x,'transverse_critical':z,'q':q,'nu_v':nu,'proportional_limit_mpa':proportional,'equivalent_bound_mpa':equivalent,'restraint_evidence':restraint_evidence}
    result['checks']=[{'id':'panel_energy','title':'Flambagem biaxial do painel — limite energético','demand':nu*q,'capacity':1.,'unit':'adimensional'},
                      {'id':'panel_elastic_domain','title':'Domínio elástico conservador do painel','demand':nu*equivalent,'capacity':proportional,'unit':'MPa'}]
    for c in result['checks']:c['utilization']=c['demand']/c['capacity'];c['sufficient_pass']=c['utilization']<=1+1e-12
    result['complete']=all(c['sufficient_pass'] for c in result['checks'])
    if not result['complete']:result['pending'].append('O limite suficiente foi excedido; exige refinamento do modelo, não comprova falha física.')
    return result
