"""Project binding for explicitly evidenced cross-module coverage."""
from .signatures import canonical_numbers
from dataclasses import asdict
import hashlib
import json
from .coverage_10084 import evaluate_local_coverage,evaluate_service_evidence,evaluate_scope_coverage


def project_coverage_context(project):
    payload=project.to_dict()
    payload.pop('coverage_inputs',None)
    return hashlib.sha256(json.dumps(canonical_numbers(payload),sort_keys=True,ensure_ascii=False,allow_nan=False).encode()).hexdigest()


def evaluate_project_coverage(project,outputs):
    context=project_coverage_context(project)
    local=[];external=[]
    for record in project.coverage_inputs['local_stress']:
        result=evaluate_local_coverage(record,project.normative_inputs,outputs,context_signature=context,material=asdict(project.material))
        local.append({'input':record,'result':result})
    for record in project.coverage_inputs['service_external']:
        result=evaluate_service_evidence(record,project.normative_inputs,outputs,context_signature=context)
        external.append({'input':record,'result':result})
    return {'context':context,'local':local,'external':external}


def resolved_local_requirements(block,coverage):
    if block['route']!='local_10084':return set()
    result=next((r['result'] for r in coverage['local'] if r['input']['local_index']==block['index']),None)
    if not result:return set()
    allowed=set(result.get('resolved_requirement_codes',[]))
    return {r['text'] for r in block['result'].get('pending_requirements',[]) if r['code'] in allowed}


def coverage_checks(coverage):
    rows=[]
    for i,block in enumerate(coverage['local']):
        record,result=block['input'],block['result'];prefix=f'local_coverage_{record["local_index"]}'
        for c in result.get('checks',[]):
            if c['id'].startswith('linked_stress_'):continue # already reported in the source route
            rows.append({**c,'id':prefix+'_'+c['id'],'case':f'Local {record["local_index"]+1}'})
        pending=result.get('errors',[])+result.get('pending',[])
        if pending:rows.append({'id':prefix+'_pending','title':'Cobertura das tensões locais e globais','status':'PENDENTE','detail':'; '.join(pending)})
        rows.append({'id':prefix+'_audit','title':'Vínculo local/global e dados utilizados','status':'INFORMATIVO','values':{'entradas':record,'intermediarios':result.get('values',{}),'limites_do_metodo':result.get('limitations',[])}})
    for i,block in enumerate(coverage['external']):
        record,result=block['input'],block['result'];prefix=f'external_service_{i}'
        for c in result.get('checks',[]):rows.append({**c,'id':prefix+'_'+c['id']})
        pending=result.get('errors',[])+result.get('pending',[])
        if pending:rows.append({'id':prefix+'_unverified','title':'Evidência externa ainda não confirmada','status':'RESPONSABILIDADE EXTERNA','detail':'; '.join(pending)})
    return rows


def final_scope_assessment(project,checks):
    from .normative import evaluate
    from .stability_coverage import evaluate_stability_coverage
    from .result_summary import summarize_checks
    outputs=evaluate(project.normative_inputs,project)
    coverage=evaluate_project_coverage(project,outputs)
    stability=evaluate_stability_coverage(project,outputs)
    local_indices={r['input']['local_index'] for r in coverage['local'] if r['result'].get('coverage_complete')}
    expected=set(range(len(project.normative_inputs['local_10084'])))
    required_routes=('stress_8400','fatigue_8400','local_10084','service_10084','web_panel_8400','flange_outstand_8400')
    required=bool(expected) and local_indices==expected and stability['coverage_complete'] and all(project.normative_inputs[r] for r in required_routes)
    computed=[c for c in checks if c.status!='RESPONSABILIDADE EXTERNA']
    scope=evaluate_scope_coverage(project.coverage_inputs['scope'],project.normative_inputs,
        context_signature=coverage['context'],required_scope_complete=required,checks=computed,
        pending=stability['gaps'],local_coverages=project.coverage_inputs['local_stress'],service_evidence=project.coverage_inputs['service_external'])
    gaps=list(dict.fromkeys(scope.get('errors',[])+scope.get('pending',[])))
    summary=summarize_checks(checks,coverage_complete=scope.get('coverage_complete') is True,coverage_gaps=gaps)
    summary['stability_coverage']=stability
    summary['scope_evidence']=scope
    return summary
