from .autonomous_restraint_mode import analysis_has_lateral_restraints
"""Independent declared obligation matrix for the autonomous runway domain.

Build this from physical inputs and the complete generated case family BEFORE
accepting result rows. Never derive it by iterating checks already returned by
an adapter: doing that would make omissions invisible. A summary is a typed
completeness record, not an extra resistance comparison or a user approval.
"""
from dataclasses import asdict

FATIGUE_FAMILY='FAT8400_LIFETIME'
FATIGUE_COMMON_REGIONS=('web_homogeneous','flange_nominal_homogeneous')
FATIGUE_WELDED_REGIONS=('web_adjacent_fillet','flange_web_weld_throat')
FATIGUE_STIFFENER_REGIONS=('stiffener_adjacent_base','stiffener_plate_base',
                         'stiffener_weld_mesa','stiffener_weld_alma')
FATIGUE_BASE_CHECKS=('fatigue_bound_longitudinal','fatigue_bound_transverse','fatigue_bound_shear','fatigue_bound_combined')
FATIGUE_WELD_CHECKS=('weld_longitudinal','weld_transverse','weld_shear','weld_combined','weld_static_comparison')
ANALYZED_FAMILIES=('I','III','ULS8800','SLS10084','SLS8800','FAT8400')


def required_fatigue_regions(project):
    from .autonomous_fullheight_actions import enabled
    if enabled(project):
        from .autonomous_fullheight_fatigue import required_fullheight_fatigue_regions
        return required_fullheight_fatigue_regions(project)
    result=list(FATIGUE_COMMON_REGIONS)
    if project.section.fabrication=='welded':result.extend(FATIGUE_WELDED_REGIONS)
    if project.stiffener_layout!='none_or_unknown':result.extend(FATIGUE_STIFFENER_REGIONS)
    return tuple(result)


def coverage_requirements(project,cases=None):
    """Return stable id/mechanism/case/summary requirements.

    Required new summaries:
      coverage/stability/<case> : complete adopted combined member route;
      coverage/local_8800/<case>: complete wheel/support/stiffener components;
      coverage/stiffener_detail: fixed ULS six-resultant plates and welds;
      coverage/fatigue_family and coverage/fatigue_region/<region>:
        entire loaded/empty/directional lifetime family, never one passage.

    All numeric IDs listed here must also exist. A summary alone cannot replace
    a missing C.1/C.2, panel, service, section or weld comparison. Conversely,
    mere numeric rows cannot replace a qualified domain/family summary.
    """
    from .autonomous_cases import generate_basic_cases
    expected=tuple(generate_basic_cases(project))
    supplied=expected if cases is None else tuple(cases)
    if len({c.id for c in supplied})!=len(supplied):raise ValueError('Casos gerados duplicados.')
    if {c.id:asdict(c) for c in supplied}!={c.id:asdict(c) for c in expected}:
        raise ValueError('Matriz exige todos os casos gerados para as entradas atuais, sem omissão ou alteração.')
    rows=[]
    def add(id_,mechanism,case='',summary=False,allow_not_applicable=False):
        rows.append(dict(id=id_,mechanism=mechanism,case=case,summary=summary,
                         allow_not_applicable=allow_not_applicable))
    add('special_actions','actions',summary=True)
    add('characteristic_components','actions',summary=True)
    add('equilibrium','equilibrium','Todos os casos analisados')
    from .autonomous_fullheight_actions import enabled as fullheight_enabled
    nominal_fullheight=fullheight_enabled(project)
    paired=project.stiffener_layout!='none_or_unknown'
    add('coverage/stiffener_detail','stiffeners','Envelope ELU',summary=True,allow_not_applicable=not paired)
    if nominal_fullheight:
        from .autonomous_fullheight_obligations import required_fullheight_static_ids
        for ident in required_fullheight_static_ids(project):add(ident,'stiffeners','Envelope ELU')
        for ident in ('panel_stockiness','panel_inertia','detail_specification','G/coverage','concurrent/coverage'):
            add('fullheight/'+ident,'stiffeners','Envelope ELU',summary=ident in ('detail_specification','G/coverage','concurrent/coverage'))
        from .autonomous_stiffener_actions import stiffener_station_geometry
        for row in stiffener_station_geometry(project):
            if row['kind']!='intermediate':
                add('fullheight/bearing/'+row['station_id']+'/outstand','stiffeners','Envelope ELU')
                add('fullheight/bearing/'+row['station_id']+'/thickness','stiffeners','Envelope ELU')
                add('fullheight/bearing/'+row['station_id']+'/coverage','stiffeners','Envelope ELU',summary=True)
    elif paired:
        add('stiffener_combined_elastic','stiffeners','Envelope ELU')
        add('stiffener_column','stiffeners','Envelope ELU')
        add('stiffener_energy_stability','stiffeners','Envelope ELU')
        add('stiffener_combined_normal_stability','stiffeners','Envelope ELU')
        add('stiffener_combined_shear_stability','stiffeners','Envelope ELU')
        for interface in ('mesa','alma'):add('stiffener_weld_group/'+interface,'stiffeners','Envelope ELU')
    if project.section.fabrication=='welded':add('flange_web_weld','stiffeners','Envelope ELU')
    for c in supplied:
        family,case=c.family,c.id
        if family not in ANALYZED_FAMILIES:continue
        add('convergence/'+case,'moving_envelope',case,summary=True)
        if analysis_has_lateral_restraints(project):add('coverage/lateral_restraints/'+case,'horizontal_bending',case,summary=True)
        if family=='ULS8800':
            for prefix,mechanism in (
                ('major/','vertical_bending'),('minor/','horizontal_bending'),('local/','local_stability'),
                ('shear_vertical/','combined_yield'),('shear_horizontal/','combined_yield'),
                ('normal/','combined_yield'),('shear_combined/','torsion_warping'),('axial_component/','axial_force')):
                add(prefix+case,mechanism,case,summary=prefix=='local/')
            add('coverage/local_8800/'+case,'support_local_effects',case,summary=True)
        elif family in ('I','III'):
            for prefix,mechanism in (('local_combined/','wheel_local_effects'),('local_normal_prescribed/','wheel_local_effects'),('support_stress/','support_local_effects'),('equivalent_nominal/','combined_yield')):
                add(prefix+case,mechanism,case,summary=prefix=='support_stress/')
        elif family=='SLS10084':
            for prefix,mechanism in (('service_vertical/','vertical_service'),('service_rail/','rail_service'),('service_horizontal/','horizontal_service')):
                add(prefix+case,mechanism,case)
        elif family=='SLS8800':
            add('service8800_vertical/'+case,'vertical_service',case)
            add('service8800_horizontal/'+case,'horizontal_service',case)
            for side,length in (('left',project.beam_end_left_mm),('right',project.beam_end_right_mm)):
                if length:
                    add('service8800_projection_vertical/'+side+'/'+case,'vertical_service',case)
                    add('service8800_projection_horizontal/'+side+'/'+case,'horizontal_service',case)
        if family in ('I','III','ULS8800'):
            # The legacy optional Navier model is not an extra normative state
            # limit for the published full-height prescriptive route.  This does
            # not waive FLA/FLM, regional shear, local bearing or global stability.
            if not nominal_fullheight:
                add('panel_energy/'+case,'local_stability',case)
                add('panel_elastic/'+case,'local_stability',case)
            add('coverage/stability/'+case,'global_stability',case,summary=True)
            for name in ('en2025_c2_global_section_bound','en2025_c2_major_interaction','en2025_c2_minor_interaction'):
                add('stability/'+case+'/'+name,'global_stability',case)
    add('coverage/fatigue_family','fatigue',FATIGUE_FAMILY,summary=True)
    if nominal_fullheight:
        from .autonomous_fullheight_fatigue import required_fullheight_fatigue_checks
        for region in required_fatigue_regions(project):
            add('coverage/fatigue_region/'+region,'fatigue',FATIGUE_FAMILY,summary=True)
        for row in required_fullheight_fatigue_checks(project):
            add(row['id'],row['mechanism'],row['case'],summary=row['summary'],allow_not_applicable=row['allow_not_applicable'])
    else:
        for region in required_fatigue_regions(project):
            add('coverage/fatigue_region/'+region,'fatigue',FATIGUE_FAMILY,summary=True)
            checks=FATIGUE_WELD_CHECKS if region=='flange_web_weld_throat' or region.startswith('stiffener_weld_') else FATIGUE_BASE_CHECKS
            for check in checks:add('fatigue/'+region+'/'+check+'/'+FATIGUE_FAMILY,'fatigue',FATIGUE_FAMILY)
    if len({row['id'] for row in rows})!=len(rows):raise ValueError('Matriz interna duplicou uma obrigação.')
    return rows
