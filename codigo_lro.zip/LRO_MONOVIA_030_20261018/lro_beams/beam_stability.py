"""Elastic reference eigenvalue for a straight fork-supported Vlasov beam.

This is a converged Ritz calculation, NOT a conservative resistance or a check
of a pre-twisted beam under general N/My/Mz/T/B. See MODEL_LIMITATIONS.
Units: N, mm, MPa. Every reference action scales by the same positive lambda;
brace stiffness does not scale. Positive compression_n is compression.

Sources: Sahraei/Pezeshky/Mohareb, CSCE 2017 EMM635, Eq.2 (M and load
height); Soltani et al., Nanomaterials 2021 11(8), Eq.17 (axial energy);
Pan et al., Nanomaterials 2022 12,538 Eq.12-14 (axial Wagner term).
The full-span lower bound is explicitly derived by Cauchy/Wirtinger, rather
than presented as a code formula. It ignores stabilizing braces and tension.
"""
from __future__ import annotations

from dataclasses import dataclass
import math
from typing import Sequence
import numpy as np

from .beam_torsion import VlasovBeam, LateralBrace, _number

MODEL_LIMITATIONS = (
    "Elastic reference about the straight configuration; no prebuckling lateral deformation or twist.",
    "Major-axis bending, axial force and actual vertical dead-load height included; minor-axis prestress, initial torque/bimoment and follower loads excluded.",
    "Rigid cross-section Vlasov model; local/distortional buckling, plasticity and imperfections excluded.",
    "A converged finite Ritz eigenvalue is an upper approximation, not a guaranteed lower bound or design resistance.",
)


@dataclass(frozen=True)
class StabilitySegment:
    """Exact quadratic major M through left/mid/right; constant axial N.

    Use the right face at x0 and left face at x1 where point couples jump.
    Contiguous segments must cover the complete span. Compression is positive.
    """
    x0_mm: float
    x1_mm: float
    major_left_nmm: float = 0.0
    major_mid_nmm: float = 0.0
    major_right_nmm: float = 0.0
    compression_n: float = 0.0

    def moment(self, xi):
        return (2*xi*xi-3*xi+1)*self.major_left_nmm + 4*xi*(1-xi)*self.major_mid_nmm + (2*xi*xi-xi)*self.major_right_nmm

    def max_abs_moment(self):
        a=2*self.major_left_nmm-4*self.major_mid_nmm+2*self.major_right_nmm
        b=-3*self.major_left_nmm+4*self.major_mid_nmm-self.major_right_nmm
        values=[abs(self.major_left_nmm),abs(self.major_right_nmm)]
        if a and 0 < -b/(2*a) < 1: values.append(abs(self.moment(-b/(2*a))))
        return max(values)


@dataclass(frozen=True)
class HeightPointLoad:
    x_mm: float
    vertical_down_n: float
    height_from_cs_mm: float


@dataclass(frozen=True)
class HeightLineLoad:
    x0_mm: float
    x1_mm: float
    vertical_down_n_per_mm: float
    height_from_cs_mm: float


def _validate(beam,Iy,Ix,A,segments,points,lines,braces):
    if not isinstance(beam,VlasovBeam): raise ValueError("VlasovBeam required")
    for name,value in (("Iy",Iy),("Ix",Ix),("A",A)): _number(value,name,True)
    L=beam.span_mm
    if not segments: raise ValueError("At least one complete-span stability segment required")
    end=0.0
    for s in segments:
        if not isinstance(s,StabilitySegment): raise ValueError("StabilitySegment required")
        for key,value in vars(s).items(): _number(value,key)
        if s.x0_mm != end or not s.x0_mm<s.x1_mm<=L:
            raise ValueError("Segments must be ordered, contiguous and cover span exactly")
        end=s.x1_mm
    if end != L: raise ValueError("Stability segments must cover full span")
    for p in points:
        if not isinstance(p,HeightPointLoad): raise ValueError("HeightPointLoad required")
        for key,value in vars(p).items(): _number(value,key)
        if not 0<=p.x_mm<=L: raise ValueError("Height load outside span")
    for p in lines:
        if not isinstance(p,HeightLineLoad): raise ValueError("HeightLineLoad required")
        for key,value in vars(p).items(): _number(value,key)
        if not 0<=p.x0_mm<p.x1_mm<=L: raise ValueError("Line load outside span")
    for b in braces:
        if not isinstance(b,LateralBrace): raise ValueError("LateralBrace required")
        _number(b.x_mm,"brace position");_number(b.height_from_cs_mm,"brace height")
        if not 0<b.x_mm<L: raise ValueError("Brace must be interior")
        if b.stiffness_n_per_mm is not None: _number(b.stiffness_n_per_mm,"brace stiffness",True)
    if len(braces)>100: raise ValueError("At most 100 braces supported")


def conservative_reference_bound(beam: VlasovBeam,Iy_mm4: float,Ix_mm4: float,area_mm2: float,
        segments: Sequence[StabilitySegment],height_points: Sequence[HeightPointLoad]=(),
        height_lines: Sequence[HeightLineLoad]=()):
    """Proved lower bound for THIS reference model, ignoring all brace benefit.

    It is not a bound for unmodelled initial torsion, distortion or local modes.
    Positive height products are retained and beneficial products discarded.
    """
    _validate(beam,Iy_mm4,Ix_mm4,area_mm2,segments,height_points,height_lines,())
    L=beam.span_mm;EI=beam.E_mpa*min(Iy_mm4,Ix_mm4)
    M=max(s.max_abs_moment() for s in segments)
    P=max(0.0,max(s.compression_n for s in segments))
    r2=(Ix_mm4+Iy_mm4)/area_mm2
    # Trace inequality |theta(a)|^2 <= a(L-a)/L * integral(theta'^2).
    height=math.fsum(max(0,p.vertical_down_n*p.height_from_cs_mm)*p.x_mm*(L-p.x_mm)/L for p in height_points)
    # Uniform density bound; summation is safe even for overlapping intervals.
    height+=math.fsum(max(0,p.vertical_down_n_per_mm*p.height_from_cs_mm) for p in height_lines)*L*L/math.pi**2
    alpha=P*L*L/(math.pi**2*EI)
    a=M*M*L*L/(EI*math.pi**2)
    b=P*r2+height
    c=beam.GJ+beam.ECw*math.pi**2/(L*L)
    if not all(math.isfinite(v) for v in (alpha,a,b,c)): raise ValueError("Nonfinite reference bound")
    if a==b==alpha==0: factor=None
    elif a==0:
        candidates=([1/alpha] if alpha else [])+([c/b] if b else [])
        factor=min(candidates)
    elif alpha==0:
        factor=2*c/(b+math.sqrt(b*b+4*a*c))
    else:
        lo,hi=0.,1/alpha
        for _ in range(100):
            mid=(lo+hi)/2
            if mid==lo or mid==hi: break
            if b*mid+a*mid*mid/(1-alpha*mid)<c: lo=mid
            else: hi=mid
        factor=lo
    return {"load_factor_lower_bound":factor,"Mmax_nmm":M,"compression_max_n":P,
            "alpha_axial":alpha,"quadratic_a":a,"linear_b":b,"torsional_c":c,
            "bound_scope":"straight elastic reference model only; full span; no brace/tension credit"}


def _assemble(beam,Iy,Ix,A,segments,points,lines,braces,n):
    L=beam.span_mm;ks=np.arange(1,n+1,dtype=float)*math.pi/L
    # v = lateral displacement; theta = twist; w = strong-plane perturbation.
    diag=np.concatenate((beam.E_mpa*Iy*ks**4*L/2,
                         (beam.ECw*ks**4+beam.GJ*ks**2)*L/2,
                         beam.E_mpa*Ix*ks**4*L/2))
    if not np.all(np.isfinite(diag)) or np.any(diag<=0): raise ValueError("Nonfinite modal stiffness")
    D=1/np.sqrt(diag);K=np.eye(3*n);G=np.zeros((3*n,3*n));r2=(Ix+Iy)/A
    def quadrature(x0,x1):
        order=max(24,int(math.ceil(3*n*(x1-x0)/L))+8)
        z,w=np.polynomial.legendre.leggauss(order)
        return x0+(z+1)*(x1-x0)/2,w*(x1-x0)/2
    for s in segments:
        x,w=quadrature(s.x0_mm,s.x1_mm)
        S=np.sin(x[:,None]*ks);C=np.cos(x[:,None]*ks)*ks
        moment=s.moment((x-s.x0_mm)/(s.x1_mm-s.x0_mm))
        cross=-(ks**2)[:,None]*(S.T@((w*moment)[:,None]*S))
        G[:n,n:2*n]+=cross;G[n:2*n,:n]+=cross.T
        axial=-(C.T@((w*s.compression_n)[:,None]*C))
        G[:n,:n]+=axial;G[n:2*n,n:2*n]+=r2*axial;G[2*n:,2*n:]+=axial
    for p in points:
        s=np.sin(ks*p.x_mm)
        G[n:2*n,n:2*n]-=p.vertical_down_n*p.height_from_cs_mm*np.outer(s,s)
    for p in lines:
        x,w=quadrature(p.x0_mm,p.x1_mm);S=np.sin(x[:,None]*ks)
        G[n:2*n,n:2*n]-=p.vertical_down_n_per_mm*p.height_from_cs_mm*(S.T@(w[:,None]*S))
    G=G*D[:,None]*D[None,:]
    constraints=[]
    for b in braces:
        s=np.sin(ks*b.x_mm);r=np.concatenate((s,b.height_from_cs_mm*s,np.zeros(n)))*D
        if b.stiffness_n_per_mm is None:
            constraints.append(r/np.linalg.norm(r))
        else: K+=b.stiffness_n_per_mm*np.outer(r,r)
    Z=np.eye(3*n)
    if constraints:
        C=np.asarray(constraints)
        _,sv,Vh=np.linalg.svd(C,full_matrices=True)
        rank=int(np.sum(sv>sv[0]*1e-11))
        if rank!=len(constraints): raise ValueError("Dependent brace constraints or insufficient modes")
        Z=Vh[rank:].T
    Kr=Z.T@K@Z;Gr=Z.T@G@Z
    if not np.all(np.isfinite(Kr)) or not np.all(np.isfinite(Gr)): raise ValueError("Nonfinite stability matrix")
    chol=np.linalg.cholesky(Kr)
    B=np.linalg.solve(chol,np.linalg.solve(chol,-Gr).T).T
    B=(B+B.T)/2
    values,vectors=np.linalg.eigh(B)
    e=float(values[-1]);scale=float(np.max(np.abs(values)))
    if e<=0 or e<=scale*1e-12: return None,0.,None
    factor=1/e
    y=np.linalg.solve(chol.T,vectors[:,-1]);q=Z@y
    residual=np.linalg.norm(Kr@y+factor*Gr@y)/max(np.linalg.norm(Kr@y),1e-300)
    mode=q*D
    return factor,float(residual),mode


def solve_elastic_reference(beam: VlasovBeam,Iy_mm4: float,Ix_mm4: float,area_mm2: float,
        segments: Sequence[StabilitySegment],height_points: Sequence[HeightPointLoad]=(),
        height_lines: Sequence[HeightLineLoad]=(),braces: Sequence[LateralBrace]=(),
        base_modes: int=12,relative_tolerance: float=1e-4):
    """n/2n/4n Ritz study; return data, never label this a resistance pass.

    Strong-plane axial buckling is retained even when lateral braces stiffen v.
    Every load diagram, axial load and height action is scaled proportionally.
    Callers must separately establish equilibrium of the supplied reference data.
    """
    segments,points,lines,braces=map(tuple,(segments,height_points,height_lines,braces))
    _validate(beam,Iy_mm4,Ix_mm4,area_mm2,segments,points,lines,braces)
    if isinstance(base_modes,bool) or not isinstance(base_modes,int) or not 2<=base_modes<=64:
        raise ValueError("base_modes must be an integer from 2 through 64")
    _number(relative_tolerance,"relative tolerance",True)
    if relative_tolerance>.01: raise ValueError("Convergence tolerance must not exceed 1 percent")
    history=[];mode=None
    for n in (base_modes,2*base_modes,4*base_modes):
        factor,residual,mode=_assemble(beam,Iy_mm4,Ix_mm4,area_mm2,segments,points,lines,braces,n)
        history.append({"modes_per_field":n,"load_factor":factor,"relative_eigen_residual":residual})
    factors=[r["load_factor"] for r in history]
    allfinite=all(v is not None and math.isfinite(v) and v>0 for v in factors)
    changes=[abs(factors[i]/factors[i+1]-1) for i in (0,1)] if allfinite else []
    monotone=all(factors[i+1]<=factors[i]*(1+1e-8) for i in (0,1)) if allfinite else all(v is None for v in factors)
    converged=allfinite and monotone and max(changes)<=relative_tolerance and max(r["relative_eigen_residual"] for r in history)<1e-7
    bound=conservative_reference_bound(beam,Iy_mm4,Ix_mm4,area_mm2,segments,points,lines)
    if allfinite and bound["load_factor_lower_bound"] is not None and bound["load_factor_lower_bound"]>factors[-1]*(1+1e-7):
        raise ValueError("Ritz eigenvalue fell below the mathematical lower bound")
    M=max(s.max_abs_moment() for s in segments)
    return {"method":"sine_Ritz_elastic_reference", "load_factor":factors[-1],
            "major_critical_reference_moment_nmm":factors[-1]*M if allfinite else None,
            "reference_includes_axial":any(s.compression_n!=0 for s in segments),
            "converged":converged,"monotone_refinement":monotone,
            "relative_changes":changes,"history":history,"lower_bound":bound,
            "is_design_resistance":False,"is_guaranteed_conservative":False,
            "model_limitations":list(MODEL_LIMITATIONS)}
