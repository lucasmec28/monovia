"""LRO navy browser shell. No model, calculation, drawing or export dependency.

The palette matches the connections catalogue. Native Streamlit surfaces and
semantic status colours are retained so light/dark themes remain legible, even
when a theme changes without a Python rerun. This module owns one visual key.
"""
from html import escape
from types import MappingProxyType

TOKENS = MappingProxyType({
    'navy': '#0a2342', 'navy_accent': '#12365b', 'background': '#f3f6fa',
    'surface': '#ffffff', 'text': '#172b43', 'muted': '#50637b',
    'border': '#d7e1ec', 'focus': '#2a70aa', 'radius': '12px',
    'font': '"Segoe UI", Roboto, Arial, sans-serif',
})
THEME_KEY = 'lro_runway_navy'


def shell_css():
    """Only branded elements are recoloured; native inputs/status/plots are not."""
    t = TOKENS
    return f'''<style>
.stApp {{ font-family: {t['font']}; }}
.block-container {{ max-width: 1500px; padding-top: 2rem; }}
.lro-shell-header {{ padding: 1.35rem 1.65rem; margin: 0 0 1.1rem;
 background: {t['navy']}; color: white; border-radius: {t['radius']}; }}
.lro-shell-header h1 {{ color: white; font-size: 1.65rem; margin: 0; padding: 0;
 letter-spacing: -.025em; font-weight: 750; }}
.lro-shell-header p {{ color: #dce8f6; margin: .4rem 0 0; font-size: .95rem; }}
.lro-shell-eyebrow {{ color: #dce8f6; font-size: .72rem; letter-spacing: .14em;
 text-transform: uppercase; margin-bottom: .35rem; }}
.lro-shell-project {{ border-left: 4px solid {t['navy']}; padding: .65rem 1rem;
 margin: .8rem 0 1rem; border-radius: 0 6px 6px 0;
 background: rgba(80, 99, 123, .08); color: inherit; }}
[data-testid="stBaseButton-primary"] {{ background: {t['navy']}; border-color: {t['navy']}; color: white; }}
[data-testid="stBaseButton-primary"]:hover {{ background: {t['navy_accent']}; border-color: {t['navy_accent']}; color: white; }}
[data-testid="stBaseButton-primary"]:focus-visible {{ outline: 3px solid {t['focus']}; outline-offset: 2px; }}
@media (max-width: 640px) {{
 .lro-shell-header {{ padding: 1.1rem; }}
 .lro-shell-header h1 {{ font-size: 1.4rem; }}
}}
</style>'''


def render_app_header(st, version):
    """A reversible presentation-only toggle, outside input/reset namespaces."""
    enabled = st.sidebar.toggle('Identidade LRO · marinho', value=True, key=THEME_KEY)
    subtitle = str(version) + ' · cálculo autônomo de um vão biapoiado'
    if not enabled:
        st.title('Viga de rolamento')
        st.caption(subtitle)
        return
    st.markdown(shell_css(), unsafe_allow_html=True)
    st.markdown('<div class="lro-shell-header"><div class="lro-shell-eyebrow">LRO · Engenharia estrutural</div>'
                '<h1>Viga de rolamento</h1><p>' + escape(subtitle) + '</p></div>',
                unsafe_allow_html=True)
    st.markdown('<div class="lro-shell-project"><strong>Projeto atual</strong> · '
                'Entradas, vistas e verificações da viga de rolamento.</div>',
                unsafe_allow_html=True)
