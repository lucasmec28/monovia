"""Compact, import-safe Streamlit input editor for the autonomous model.

No calculation or approval is performed here. Call reset_autonomous_inputs()
BEFORE rendering after an explicit file reload (including identical JSON).
Otherwise distinct imported projects are detected automatically. The caller
owns the returned project and any subsequent analysis/serialization.
"""
from __future__ import annotations

from copy import deepcopy
from dataclasses import asdict
import hashlib
import json
import math
import re

import pandas as pd
import streamlit as st

from .autonomous_model import AutonomousProject, WheelInput, physical_premises, validate_autonomous
from .autonomous_restraint_mode import resistance_lengths_only
from .autonomous_nominal_lengths import resolve_nominal_lengths
from .autonomous_fatigue_choices_ui import render_component_group_choice, render_fatigue_detail_choice
from .autonomous_detail_limits_ui import (stiffener_detail_limits, render_preserving_number,
    render_stiffener_conditions, render_weld_minimum, render_projection_coverage_hint, WELD_LIMIT_SOURCE)
from .autonomous_detail_diagrams import render_detail_diagrams
from .autonomous_dynamic_choices_ui import render_dynamic_class_help, hc_label, hd_label, equipment_group_label
from .autonomous_ui_actions import render_action_applicability
from .autonomous_ui_rail import render_rail_section
from .autonomous_actions import (HoistDynamics, compute_hoist_dynamic, factors_8800, mx_for_equipment_group,
                                 DYNAMIC_SOURCE, ULS_SOURCE, MX_SOURCE)
from .catalog import CATALOG_FAMILIES, FAMILY_LABELS, get_profile, list_profiles, section_from_profile

__all__ = ["render_autonomous_inputs", "reset_autonomous_inputs"]
_PREFIX = "autonomous_inputs:"


def _key(name):
    return _PREFIX + name


def reset_autonomous_inputs() -> None:
    """Clear only this editor's state; call before rendering, on explicit import."""
    for key in list(st.session_state):
        if isinstance(key, str) and key.startswith(_PREFIX):
            del st.session_state[key]


def _signature(project):
    # Invalid unfinished table cells remain visible/invalid, rather than reverting
    # to an older valid project. NaNs are allowed only in this private fingerprint.
    raw = json.dumps(project.to_dict(), sort_keys=True, ensure_ascii=False, allow_nan=True)
    return hashlib.sha256(raw.encode()).hexdigest()


def _prepare(initial):
    signature = _signature(initial)
    known = {st.session_state.get(_key("source_signature")), st.session_state.get(_key("output_signature"))}
    if signature not in known:
        reset_autonomous_inputs()
        st.session_state[_key("source_signature")] = signature
        st.session_state[_key("base")] = deepcopy(initial)
        st.session_state[_key("section")] = deepcopy(initial.section)
        st.session_state[_key("wheel_seed")] = [asdict(w) for w in initial.wheels]
    return deepcopy(st.session_state[_key("base")])


def _number(label, value, name, *, minimum=None, step=.1, help=None, format="%.2f"):
    return st.number_input(label, min_value=minimum,
                           value=None if _key(name) in st.session_state else float(value), step=float(step),
                           format=format, key=_key(name), help=help)


def _parse_positions(text: str) -> list[float]:
    if not text.strip():
        return []
    try:
        result = [float(token.replace(",", ".")) for token in re.split(r"[;\s]+", text.strip()) if token]
    except ValueError as exc:
        raise ValueError("Use posições em metros separadas por ponto e vírgula, por exemplo 0; 1,5; 3.") from exc
    if any(not math.isfinite(x) or x < 0 for x in result):
        raise ValueError("As posições devem ser números finitos e não negativos.")
    return result


def _wheel_inputs(frame) -> list[WheelInput]:
    result = []
    for record in frame.to_dict(orient="records"):
        row = {}
        for name in ("offset_m", "dead_kn", "lifted_kn", "longitudinal_kn", "transverse_kn"):
            try:
                row[name] = float(record.get(name))
            except (TypeError, ValueError):
                row[name] = math.nan
        result.append(WheelInput(**row))
    return result


def _render_section(p):
    st.subheader("1 · Vão e perfil")
    p.span_m = _number("Vão entre apoios (m)", p.span_m, "span", minimum=0.0, step=.1)
    modes = ("Seção personalizada", "Catálogo · 552 perfis")
    selected = st.session_state[_key("section")]
    mode = st.radio("Perfil da viga", modes, index=int(bool(selected.catalog_id)), horizontal=True,
                    key=_key("section_mode"))
    previous = st.session_state.get(_key("previous_mode"), mode)
    if previous != mode and mode == modes[0]:
        # Re-seed every custom dimension from the profile just selected. Old
        # custom widgets must not resurrect dimensions from an earlier profile.
        for name in ("d", "bt", "bb", "tt", "tb", "tw", "fabrication", "radius"):
            st.session_state.pop(_key("section_" + name), None)
    st.session_state[_key("previous_mode")] = mode
    if mode == modes[1]:
        seed_family = get_profile(selected.catalog_id)["family"] if selected.catalog_id else "W"
        cols = st.columns([1, 2])
        with cols[0]:
            family = st.selectbox("Família", CATALOG_FAMILIES, index=CATALOG_FAMILIES.index(seed_family),
                                  format_func=lambda f: FAMILY_LABELS[f], key=_key("family"))
        records = list_profiles(family)
        ids = [item["id"] for item in records]
        if st.session_state.get(_key("profile")) not in ids:
            st.session_state.pop(_key("profile"), None)
        index = ids.index(selected.catalog_id) if selected.catalog_id in ids else 0
        with cols[1]:
            chosen = st.selectbox("Perfil", ids, index=index, key=_key("profile"))
        p.section = section_from_profile(chosen)
        s = p.section
        st.caption(f"d = {s.d_mm:g} mm · mesas = {s.bf_mm:g} mm · tf = {s.tf_mm:g} mm · tw = {s.tw_mm:g} mm. Dimensões preservadas do catálogo.")
    else:
        s = deepcopy(selected)
        columns = st.columns(3)
        with columns[0]:
            depth = _number("Altura total d (mm)", s.d_mm, "section_d", minimum=0.0, step=10)
            web = _number("Espessura da alma tw (mm)", s.tw_mm, "section_tw", minimum=0.0, step=.5)
        with columns[1]:
            top = _number("Largura da mesa superior (mm)", s.bf_mm, "section_bt", minimum=0.0, step=10)
            tf = _number("Espessura da mesa superior (mm)", s.tf_mm, "section_tt", minimum=0.0, step=.5)
        with columns[2]:
            bottom = _number("Largura da mesa inferior (mm)", s.bottom_width, "section_bb", minimum=0.0, step=10)
            tbf = _number("Espessura da mesa inferior (mm)", s.bottom_thickness, "section_tb", minimum=0.0, step=.5)
        changed = (depth, web, top, tf, bottom, tbf) != (s.d_mm, s.tw_mm, s.bf_mm, s.tf_mm, s.bottom_width, s.bottom_thickness)
        if changed or s.catalog_id:
            s.d_mm, s.tw_mm, s.bf_mm, s.tf_mm = depth, web, top, tf
            s.bottom_bf_mm, s.bottom_tf_mm = bottom, tbf
            s.catalog_id, s.catalog = "", {}
            s.property_basis = "rectangles"
            s.property_source = "Seção customizada: propriedades por retângulos, sem contribuição do trilho."
            s.name = f"I personalizado {depth:g} × {top:g}/{bottom:g} × {web:g} × {tf:g}/{tbf:g}"
        p.section = s
    st.session_state[_key("section")] = deepcopy(p.section)


def _render_wheels(p):
    st.subheader("2 · Rodas e cargas")
    st.caption("G: carregamento permanente da ponte por roda, incluindo carro, gancho e demais componentes. Q: sobrecarga por roda. Informe valores característicos, antes dos fatores. A distância é o deslocamento relativo no trem de rodas; o motor deslocará o conjunto sobre o vão.")
    config = {
        "offset_m": st.column_config.NumberColumn("Distância (m)", min_value=0, format="%.2f", required=True, help="Deslocamento relativo no trem de rodas; não é a posição fixa sobre a viga."),
        "dead_kn": st.column_config.NumberColumn("G · permanente por roda (kN)", min_value=0, format="%.2f", required=True, help="Carregamento permanente da ponte por roda, incluindo carro, gancho e demais componentes; não inclui novamente o peso próprio da viga/trilho."),
        "lifted_kn": st.column_config.NumberColumn("Q · sobrecarga por roda (kN)", min_value=0, format="%.2f", required=True, help="Sobrecarga característica por roda, antes do dinâmico Ψ e da majoração ELU."),
        "longitudinal_kn": st.column_config.NumberColumn("H longitudinal (kN)", format="%.2f", required=True),
        "transverse_kn": st.column_config.NumberColumn("H transversal (kN)", format="%.2f", required=True),
    }
    frame = pd.DataFrame(st.session_state[_key("wheel_seed")], columns=list(config))
    revision = st.session_state.get(_key("wheel_revision"), 0)
    editor_key = _key("wheels" if revision == 0 else f"wheels:{revision}")
    edited = st.data_editor(frame, column_config=config, column_order=list(config), hide_index=True,
                            num_rows="dynamic", width="stretch", key=editor_key)
    p.wheels = _wheel_inputs(edited)
    if st.button("Replicar cargas da primeira roda", key=_key("replicate_wheels"), disabled=len(p.wheels) < 2,
                 help="Copia G, Q e as duas componentes H para as demais rodas; mantém cada distância."):
        first = p.wheels[0]
        st.session_state[_key("wheel_seed")] = [asdict(WheelInput(w.offset_m, first.dead_kn, first.lifted_kn,
            first.transverse_kn, first.longitudinal_kn)) for w in p.wheels]
        st.session_state[_key("wheel_revision")] = revision + 1
        st.rerun()
    _render_factors(p)
    p.extra_dead_kn_per_m = _number("Carga permanente adicional (kN/m)", p.extra_dead_kn_per_m,
                                    "extra_dead", minimum=0.0, step=.1,
                                    help="O peso próprio do perfil, do trilho e das chapas dos enrijecedores já é incluído automaticamente. Informe aqui apenas outras cargas permanentes.")


def _restore_suggested_factors():
    for name in ("psi", "gamma_g", "gamma_q"):
        st.session_state[_key("factor_manual_" + name)] = False
        st.session_state.pop(_key("factor_value_" + name), None)


def _mark_factor_manual(name):
    st.session_state[_key("factor_manual_" + name)] = True


def _render_factors(p):
    st.markdown("**Fatores de majoração · sugestões conforme a norma**")
    # Advanced widgets may be displayed later, but their latest browser values
    # already exist here. A change of HC/HD/speed refreshes automatic Ψ immediately.
    values = {name: st.session_state.get(_key(key), getattr(p, name)) for name, key in
              (("hoist_class", "hoist_class"), ("drive_class", "drive_class"),
               ("hoist_speed_m_s", "hoist_speed"), ("creep_speed_m_s", "creep_speed"))}
    error = None
    try:
        dynamic = compute_hoist_dynamic(HoistDynamics(values["hoist_class"], values["drive_class"],
            values["hoist_speed_m_s"], values["creep_speed_m_s"], p.factor_basis))
        suggestion = dynamic["psi"]
    except ValueError as exc:
        suggestion, error = None, str(exc)
    basic = factors_8800("uls_normal", psi=1.0)
    specs = (("psi", "dynamic_psi_override", "Dinâmico Ψ", suggestion, DYNAMIC_SOURCE),
             ("gamma_g", "gamma_g_override", "γG · permanente", basic.dead_equipment, ULS_SOURCE),
             ("gamma_q", "gamma_q_override", "γQ · sobrecarga", basic.lifted, ULS_SOURCE))
    for col, (name, attr, label, suggested, source) in zip(st.columns(3), specs):
        with col:
            manual_key = _key("factor_manual_" + name)
            if manual_key not in st.session_state:
                st.session_state[manual_key] = getattr(p, attr) is not None
            manual = st.session_state[manual_key]
            value_key = _key("factor_value_" + name)
            if not manual:
                st.session_state[value_key] = suggested
            elif value_key not in st.session_state:
                st.session_state[value_key] = getattr(p, attr)
            value = st.number_input(label, min_value=1.0, value=None, step=.01, format="%.2f", key=value_key,
                on_change=_mark_factor_manual, args=(name,),
                help="Edite para informar outro valor. O valor completo é preservado no cálculo; a exibição usa duas casas.")
            if manual and value is None:
                st.error("Informe " + label + " ou restaure a sugestão automática.")
                value = math.nan
            setattr(p, attr, value if manual else None)
            st.caption("Informado pelo usuário" if manual else "Sugerido automaticamente")
    if error and not st.session_state[_key("factor_manual_psi")]:
        st.warning("Não há sugestão automática de Ψ com estes dados: " + error + " Informe Ψ diretamente ou ajuste os dados avançados.")
    if st.session_state[_key("factor_manual_psi")] and p.dynamic_psi_override is None:
        st.error("Informe o coeficiente dinâmico Ψ ou restaure a sugestão automática.")
        p.dynamic_psi_override = math.nan
    st.button("Restaurar fatores sugeridos", key=_key("restore_factors"), on_click=_restore_suggested_factors)
    st.caption("Ψ atua uma vez sobre a sobrecarga Q. γG e γQ pertencem às combinações ELU 8800; Mx da NBR 8400 é apresentado separadamente nas opções avançadas.")
    st.caption("Fonte de Ψ: " + DYNAMIC_SOURCE + ". Fontes de γG/γQ: " + ULS_SOURCE + ".")


def _render_rail_braces(p):
    st.subheader("3 · Trilho e travamentos")
    modes={"physical_response":"Apoios intermediários na análise física (modo anterior)",
           "resistance_lengths_only":"Somente comprimentos resistentes, sem redistribuir esforços"}
    p.restraint_application=st.radio("Como considerar os travamentos intermediários",list(modes),
        index=list(modes).index(p.restraint_application),format_func=modes.get,key=_key("restraint_application"))
    nominal=resistance_lengths_only(p)
    if nominal:
        st.caption("As posições abaixo delimitam apenas comprimentos de resistência. Os esforços, as reações e as flechas continuam da viga com garfos somente nas extremidades. As contenções devem ser eficazes e independentes; o app não dimensiona seus dispositivos nem cria transmissão ao enrijecedor por coincidência de posição.")
    p.rail = render_rail_section(p.rail)
    p.rail.lateral_eccentricity_mm = _number("Linha da carga relativa ao trilho (mm)", p.rail.lateral_eccentricity_mm,
                                           "rail_eccentricity", step=1)
    st.caption("A linha de carga da roda pode ser excêntrica mesmo com o trilho centrado. A posição física do trilho e a folga da roda são editáveis abaixo.")
    for attr, label in (("upper_braces_m", "Travamentos da mesa superior (m)"),
                        ("lower_braces_m", "Travamentos da mesa inferior (m)")):
        raw = st.text_input(label, value="; ".join(f"{v:g}" for v in getattr(p, attr)), key=_key(attr),
                            help="Posições a partir do apoio A, separadas por ;. Vazio significa sem travamentos intermediários informados.")
        try:
            setattr(p, attr, _parse_positions(raw))
        except ValueError as exc:
            st.error(f"{label}: {exc}")
            setattr(p, attr, [math.nan])  # Caller validation cannot approve stale valid inputs.
    if not nominal:
        st.caption("As travas de mesa acima participam da resposta e da estabilidade lateral. Não representam automaticamente um vínculo que impeça a rotação de torção.")
    st.markdown("**Contenção no centro da seção para comprimento fraco**" if nominal else "**Contenção horizontal sem crédito de redução de FLT**")
    raw = st.text_input("Posições de contenção lateral central (m)" if nominal else "Apoios laterais adicionais (m)", value="; ".join(f"{v:g}" for v in p.lateral_only_braces_m),
        key=_key("lateral_only_braces_m"), help="Posições de apoios laterais efetivos, contadas a partir do apoio A. Não informe nós de uma treliça como apoios fixos sem que ofereçam essa contenção real.")
    try:
        p.lateral_only_braces_m = _parse_positions(raw)
    except ValueError as exc:
        st.error(str(exc)); p.lateral_only_braces_m = [math.nan]
    if p.lateral_only_braces_m:
        levels = {"shear_center": "No eixo da seção / centro de cisalhamento", "upper_flange": "Na mesa superior", "lower_flange": "Na mesa inferior"}
        models = {"unselected": "Selecione a idealização física", "rigid_discrete": "Apoios laterais efetivamente rígidos", "elastic_discrete": "Apoios elásticos com rigidez conhecida"}
        cols = st.columns(2)
        with cols[0]:
            p.lateral_only_brace_level = st.selectbox("Nível de aplicação da contenção", list(levels), index=list(levels).index(p.lateral_only_brace_level), format_func=levels.get, key=_key("lateral_only_brace_level"))
        with cols[1]:
            p.lateral_only_brace_model = st.selectbox("Idealização dos apoios laterais", list(models), index=list(models).index(p.lateral_only_brace_model), format_func=models.get, key=_key("lateral_only_brace_model"))
        if p.lateral_only_brace_model == "elastic_discrete":
            p.lateral_only_brace_stiffness_kn_per_mm = st.number_input("Rigidez horizontal por apoio (kN/mm)", min_value=0.0,
                value=p.lateral_only_brace_stiffness_kn_per_mm, step=1.0, format="%.2f", key=_key("lateral_only_brace_stiffness"))
        if not nominal:
            st.caption("O apoio restringe o deslocamento horizontal no nível informado, sem impor giro de torção nulo. Sua influência física entra nos esforços e deslocamentos; por opção conservadora, não reduz Lb nem recebe crédito na referência de FLT. O treliçamento e suas ligações não são dimensionados aqui.")
    if nominal:
        try:
            plan=resolve_nominal_lengths(p)
            st.caption(f"Comprimentos resistentes: forte = {plan.major_flexural_mm:g} mm; fraco = {plan.minor_flexural_mm:g} mm; torcional axial = {plan.torsional_mm:g} mm; maior trecho FLT = {max(b-a for a,b in plan.ltb_intervals_mm):g} mm.")
            st.caption("Só a contenção central não reduz FLT. A referência FLT por trechos usa apenas a coincidência exata de contenções eficazes superior e central; não impõe apoio vertical, momento nulo ou empenamento impedido nesses pontos.")
        except ValueError as exc:
            st.error(str(exc))



def _render_advanced(p):
    seed = st.session_state[_key("base")]
    with st.expander("Avançado · material, trilho, vida útil e premissas"):
        st.markdown("**Ponte e ações**")
        st.caption("Selecione as características do equipamento conforme seu funcionamento e a classificação adotada. A ajuda abaixo explica as opções; a capacidade nominal não determina HC, HD ou grupo A. HC/HD podem ficar não informados quando Ψ operacional é informado diretamente.")
        cols = st.columns(3)
        with cols[0]:
            hc_options = ["unselected", *[f"HC{i}" for i in range(1, 5)]]
            p.hoist_class = st.selectbox("Classe de elevação HC", hc_options,
                index=hc_options.index(p.hoist_class), key=_key("hoist_class"),
                format_func=hc_label,
                help="Classe de elevação usada na avaliação dinâmica, conforme as características e a classificação adotada para o equipamento. Veja a ajuda abaixo.")
            p.hoist_speed_m_s = _number("Velocidade nominal de elevação (m/s)", p.hoist_speed_m_s,
                "hoist_speed", minimum=0.0, step=.01)
        with cols[1]:
            hd_options = ["unselected", *[f"HD{i}" for i in range(1, 6)]]
            p.drive_class = st.selectbox("Classe do acionamento HD", hd_options,
                index=hd_options.index(p.drive_class), key=_key("drive_class"),
                format_func=hd_label,
                help="Classe do acionamento e do controle de elevação, conforme o funcionamento real do equipamento. Veja a ajuda abaixo.")
            p.creep_speed_m_s = _number("Velocidade lenta de elevação (m/s)", p.creep_speed_m_s,
                "creep_speed", minimum=0.0, step=.01)
        with cols[2]:
            p.equipment_group = st.selectbox("Grupo do equipamento A", [f"A{i}" for i in range(1, 9)],
                index=int(p.equipment_group[-1]) - 1, key=_key("equipment_group"), format_func=equipment_group_label,
                help="Classificação do equipamento conforme utilização e estado de carregamento; não é o grupo E de fadiga do componente. Veja a ajuda abaixo.")
            classes = ["light", "moderate", "heavy", "severe"]
            names = dict(zip(classes, ["Leve", "Moderado", "Pesado", "Severo"]))
            p.service_class = st.selectbox("Classe de serviço · limites de deslocamento (ELS)", classes, index=classes.index(p.service_class),
                format_func=names.get, key=_key("service_class"),
                help="Seleciona o preset de limites de deslocamento da NBR 8800; não corresponde às classes de serviço CMAA A–D.")
        render_dynamic_class_help(st, p)
        p.equipment_use = st.selectbox("Aplicação do equipamento", ["other", "steelworks"],
            index=int(p.equipment_use == "steelworks"), key=_key("equipment_use"),
            format_func=lambda v: "Uso siderúrgico" if v == "steelworks" else "Demais usos",
            help="NBR 10084, seção 10 e Tabela 4: afeta o limite de deslocamento vertical; não se infere da capacidade nominal.")
        p.factor_basis = st.text_input("Origem dos fatores informados", value=p.factor_basis,
            key=_key("factor_basis"), help="Ex.: ficha do fabricante ou hipótese de projeto. Os valores sugeridos mantêm sua referência normativa acima.")
        st.caption(f"Mx automático = {mx_for_equipment_group(p.equipment_group):.2f} · {MX_SOURCE}. Mx não é multiplicado novamente nas combinações ELU 8800.")
        p.action_applicability = render_action_applicability(p.action_applicability)
        st.markdown("**Material da viga**")
        grades = ['ASTM A36','ASTM A572 GR50','S235','S275','S355','custom']
        p.material_grade = st.selectbox("Designação do aço", grades, index=grades.index(p.material_grade),
            format_func=lambda v: "Outro aço especificado" if v == "custom" else v, key=_key("material_grade"),
            help="Designação declarada na especificação. Selecionar o nome não modifica fy/fu nem comprova certificado de material.")
        cols = st.columns(3)
        material_fields = (("fy_mpa", "fy (MPa)", 5), ("fu_mpa", "fu (MPa)", 5),
                           ("E_mpa", "E (MPa)", 1000), ("G_mpa", "G (MPa)", 1000),
                           ("gamma_a1", "Coeficiente γa1", .01))
        for i, (name, label, step) in enumerate(material_fields):
            with cols[i % 3]:
                setattr(p.material, name, _number(label, getattr(p.material, name), "material_" + name,
                                                   minimum=0.0, step=step))
        if not p.section.catalog_id:
            cols = st.columns(2)
            with cols[0]:
                p.section.fabrication = st.selectbox("Fabricação do perfil", ["welded", "rolled"],
                    index=int(p.section.fabrication == "rolled"), format_func=lambda s: "Soldado" if s == "welded" else "Laminado",
                    key=_key("section_fabrication"))
            with cols[1]:
                p.section.root_radius_mm = _number("Raio de concordância (mm)", p.section.root_radius_mm,
                                                   "section_radius", minimum=0.0, step=.5)
        st.markdown("**Fixação e posição do trilho**")
        cols = st.columns(2)
        with cols[0]:
            p.rail.offset_from_web_mm = _number("Centro do trilho relativo à alma (mm)", p.rail.offset_from_web_mm,
                "rail_offset_from_web", step=1)
            guidance = {"unselected": "Guia da roda ainda não definida", "flanged": "Roda flangeada",
                        "guide_roller_unguided_side": "Rolo-guia · lado sem guia"}
            p.rail.wheel_guidance = st.selectbox("Guia da roda", list(guidance), index=list(guidance).index(p.rail.wheel_guidance),
                format_func=guidance.get, key=_key("wheel_guidance"))
            p.rail.wheel_rail_clearance_mm = _number("Folga lateral total roda–trilho fw (mm)", p.rail.wheel_rail_clearance_mm,
                "wheel_clearance", minimum=0.0, step=1)
        with cols[1]:
            attachments = {"unselected": "Fixação local ainda não definida", "non_rigid": "Não rígida · trilho e mesa sem ação composta"}
            p.rail.local_attachment = st.selectbox("Fixação para dispersão local", list(attachments),
                index=list(attachments).index(p.rail.local_attachment), format_func=attachments.get, key=_key("local_attachment"))
            continuity = {"continuous_no_joint": "Trilho contínuo, sem junta no trecho", "joint_or_unknown": "Junta presente ou continuidade desconhecida"}
            p.rail.continuity = st.selectbox("Continuidade do trilho", list(continuity), index=list(continuity).index(p.rail.continuity),
                format_func=continuity.get, key=_key("rail_continuity"))
        st.caption("A guia da roda e a folga adotadas são as informadas acima. NBR 10084, 9.1.3.3: ey = fw/2 ou br/4 no lado sem rolo-guia. O campo da linha de carga não é usado para inventar a folga; o envelope local usa a maior excentricidade aplicável.")
        st.markdown("**Vida útil e utilização**")
        cols = st.columns(2)
        for i, (name, label, step) in enumerate((("life_years", "Vida útil (anos)", 1),
                ("uses_per_year", "Utilizações por ano", 100),
                ("loaded_passages_per_use", "Passagens carregadas por utilização", 1),
                ("empty_passages_per_use", "Passagens vazias por utilização", 1))):
            with cols[i % 2]:
                setattr(p.fatigue, name, _number(label, getattr(p.fatigue, name), "fatigue_" + name, minimum=0.0, step=step))
        p.fatigue.component_group = render_component_group_choice(st,p.fatigue.component_group,key=_key("fatigue_group"))
        if p.fatigue.component_group == "E8_conservative":
            st.caption("Nesta opção, a classificação de fadiga pela NBR 8400 adota E8 independentemente da vida informada. A verificação separada pela história de vida usa os dados de vida útil e passagens declarados; ciclos por utilização não são obrigatórios para a hipótese E8.")
        elif p.fatigue.component_group != "P4_cycles_conservative":
            st.caption("Grupo E selecionado no cálculo. Ciclos por utilização são opcionais nesta seleção; são obrigatórios somente para obter o grupo automaticamente por ciclos.")
        p.fatigue.stress_cycles_per_use = st.number_input("Ciclos de tensão no ponto por utilização", min_value=0.0,
            value=p.fatigue.stress_cycles_per_use, step=1.0, format="%.2f", key=_key("fatigue_stress_cycles"),
            placeholder="Informar a relação física do componente",
            help="Obrigatório somente no método de grupo por ciclos informados. NBR 8400-1, 6.1.4.2: depende do ponto e do componente; não é atribuído automaticamente a partir de rodas ou passagens.")
        # Preserve imported documentation for its original group, without a
        # mandatory source textbox. Changing the letter is a fresh manual choice,
        # never evidence that an imported classification also covers that group.
        original_fatigue=st.session_state[_key("base")].fatigue
        if p.fatigue.component_group in [f"E{i}" for i in range(1, 9)] and p.fatigue.component_group!=original_fatigue.component_group:
            p.fatigue.group_source=''
        p.fatigue.detail = render_fatigue_detail_choice(st,p.fatigue.detail,key=_key("fatigue_detail"))
        st.caption("A seleção de um detalhe não cobre todos os detalhes da viga. Aplicam-se os requisitos de fabricação H.6 e os limites de corrosão/temperatura H.2.7; não há equivalência automática entre as categorias das duas normas.")
        st.markdown("**Apoios e enrijecedores**")
        cols = st.columns(3)
        for col, (name, label, step) in zip(cols, (("stiffener_spacing_m", "Espaçamento de enrijecedores (m)", .1),
                   ("stiffener_thickness_mm", "Espessura de enrijecedores (mm)", 1),
                   ("support_bearing_length_mm", "Comprimento de apoio (mm)", 10))):
            with col:
                setattr(p, name, _number(label, getattr(p, name), name, minimum=0.0, step=step))
        layouts = {"paired_full_height_uniform": "Pares de altura total nos apoios e ao longo do vão",
                   "paired_full_height_supports": "Pares de altura total somente nos apoios",
                   "none_or_unknown": "Sem enrijecedores ou disposição desconhecida"}
        p.stiffener_layout = st.selectbox("Disposição dos enrijecedores", list(layouts), index=list(layouts).index(p.stiffener_layout),
            format_func=layouts.get, key=_key("stiffener_layout"))
        connections = {"web_and_both_flanges_welded": "Soldados à alma e às duas mesas",
                       "web_only_welded": "Soldados somente à alma", "other_or_unknown": "Outra ligação ou desconhecida"}
        p.stiffener_connection = st.selectbox("Ligação das chapas dos enrijecedores", list(connections),
            index=list(connections).index(p.stiffener_connection), format_func=connections.get, key=_key("stiffener_connection"))
        detail_limits = stiffener_detail_limits(p)
        cols = st.columns(3)
        for col, (attr, label) in zip(cols, (("stiffener_outstand_mm", "Largura saliente de cada chapa (mm)"),
                ("beam_end_left_mm", "Projeção além do apoio A (mm)"), ("beam_end_right_mm", "Projeção além do apoio B (mm)"))):
            with col:
                if attr == "stiffener_outstand_mm":
                    maximum = detail_limits["physical_max_mm"] if detail_limits["applicable"] else None
                    setattr(p, attr, render_preserving_number(label, getattr(p, attr), key=_key(attr),
                        maximum=maximum, step=5, help="Limite físico das chapas de altura total: (menor largura de mesa − tw)/2. A condição mínima do método resistente aparece separadamente e não altera a entrada."))
                else:
                    setattr(p, attr, _number(label, getattr(p, attr), attr, minimum=0.0, step=5))
        # Reserve the guide directly below its fields, but render it after all
        # controlling selectors so a contact change appears in the same rerun.
        detail_diagrams_slot = st.container()
        render_stiffener_conditions(p)
        st.markdown("**Pernas mínimas dos filetes de solda**")
        st.caption("0 = proposta automática pelo ELU. Um mínimo maior permite reforçar o mesmo detalhe para nova verificação de fadiga; não dispensa conferir os resultados. A proposta respeita mínimos normativos, máximos geométricos e passos de 0,5 mm. O campo alma–mesa contínua não se aplica ao perfil laminado.")
        cols = st.columns(3)
        for col, (attr, label) in zip(cols, (
                ("flange_web_weld_min_leg_mm", "Alma–mesa contínua · mínimo (mm)"),
                ("stiffener_flange_weld_min_leg_mm", "Enrijecedor–mesa · mínimo (mm)"),
                ("stiffener_web_weld_min_leg_mm", "Enrijecedor–alma · mínimo (mm)"))):
            with col:
                setattr(p, attr, render_weld_minimum(p, attr, label, key=_key(attr)))
        st.caption("Fonte dos limites da proposta de filete existente: " + WELD_LIMIT_SOURCE + ". Não qualifica outras ligações. A validação existente do mínimo informado permanece aplicável.")
        contacts = {"centered_under_web": "Contato inferior centrado sob a alma", "other_or_unknown": "Outro contato ou desconhecido"}
        p.support_contact = st.selectbox("Posição do contato de apoio", list(contacts), index=list(contacts).index(p.support_contact),
            format_func=contacts.get, key=_key("support_contact"))
        travel = {"between_support_axes": "Somente entre os eixos dos apoios · projeções sem rodas",
                  "including_physical_projections": "As rodas também passam pelas projeções"}
        p.wheel_travel_scope = st.selectbox("Trecho de passagem das rodas", list(travel), index=list(travel).index(p.wheel_travel_scope),
            format_func=travel.get, key=_key("wheel_travel_scope"))
        if p.wheel_travel_scope == "between_support_axes":
            st.caption("As projeções são continuidade física sem passagem de rodas além dos apoios. As verificações das chapas, das soldas propostas e dos apoios dos painéis aparecem nos resultados.")
        else:
            st.warning("Passagem de rodas nas projeções está fora do domínio deste motor. Selecione o trecho entre os eixos somente se essa for a condição real.")
        render_projection_coverage_hint(p)
        with detail_diagrams_slot:
            render_detail_diagrams(st, p)
        st.markdown("**Premissas do modelo ativo**")
        for premise in physical_premises(p):
            st.write("• " + premise)


def render_autonomous_inputs(initial: AutonomousProject) -> AutonomousProject:
    """Render friendly input groups and return edits without mutating ``initial``.

    Invalid unfinished cells/position strings remain invalid in the returned
    object and produce a visible error. Call validate_autonomous before analysis.
    No imported effort, administrative approval, or analysis widget is introduced.
    """
    if not isinstance(initial, AutonomousProject):
        raise TypeError("initial must be an AutonomousProject")
    p = _prepare(initial)
    _render_section(p)
    _render_wheels(p)
    _render_rail_braces(p)
    _render_advanced(p)
    from .autonomous_fullheight_ui import render_fullheight_detail
    render_fullheight_detail(st,p)
    st.session_state[_key("section")] = deepcopy(p.section)
    errors = validate_autonomous(p)
    if errors:
        st.error("Confira os dados antes de calcular: " + " · ".join(errors))
    st.session_state[_key("output_signature")] = _signature(p)
    return p
