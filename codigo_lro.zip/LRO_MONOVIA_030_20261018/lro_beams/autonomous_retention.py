"""Lossless retention reduction after ULS station-action evaluation.

These are algebraic envelopes of already evaluated samples. No sample, response,
physical action or numerical convergence level is omitted from calculation.
Fatigue's complete observer/sample history is deliberately outside this helper.
"""
from .autonomous_stiffener_actions import envelope_stiffener_stations


def compact_stiffener_case(local_records,project_signature):
    """Retain one identical station envelope instead of every ULS body."""
    if not isinstance(project_signature,str) or not project_signature:
        raise ValueError('Assinatura do projeto obrigatória na compactação ELU.')
    records=[]
    for row in local_records:
        if row.get('project_signature')!=project_signature:
            raise ValueError('Registro ELU não pertence ao projeto da compactação.')
        pending=list(row.get('stiffener_station_pending',[]))
        errors=row.get('errors',[])
        if errors:pending.extend('Erro no registro ELU: '+str(error) for error in errors)
        records.append(dict(complete=row.get('stiffener_station_complete') is True and not errors,
            pending=pending,stations=row.get('stiffener_stations'),project_signature=project_signature))
    return envelope_stiffener_stations(records)
