"""Inputs of the autonomous runway model; no imported forces or approvals.

Loads are characteristic components before case factors. Demonstration values
are synthetic. Internal coordinates: longitudinal s, lateral y, vertical z.
"""
from __future__ import annotations
from dataclasses import dataclass,field,asdict,fields
import json,math
from .model import Section,Material
from .autonomous_rail import RECTANGULAR_SOURCE,rail_definition_errors,migrate_legacy_rail_fields
from .autonomous_lateral_restraints import lateral_restraint_errors
from .autonomous_restraint_mode import MODES,resistance_lengths_only
from .autonomous_actions import ActionApplicability,action_applicability_errors,action_applicability_dict,TEST_CLASS_ENVELOPE_FIELDS,TEST_CLASS_ENVELOPE_METHOD
from .equipment_basis import EquipmentBasis,equipment_basis_errors,equipment_basis_premises

@dataclass
class WheelInput:
    offset_m: float=0.0
    dead_kn: float=10.0
    lifted_kn: float=25.0
    transverse_kn: float=2.0
    longitudinal_kn: float=0.0

@dataclass
class RailInput:
    width_mm: float=60.0
    height_mm: float=40.0
    inertia_cm4: float=32.0
    mass_kg_per_m: float=18.84
    lateral_eccentricity_mm: float=5.0
    shape: str='rectangular_demonstration'
    catalog_id: str=''
    property_source: str=RECTANGULAR_SOURCE
    attachment: str='non_composite'
    offset_from_web_mm: float=0.0
    wheel_guidance: str='flanged'
    wheel_rail_clearance_mm: float=10.0
    head_width_mm: float=60.0
    local_attachment: str='non_rigid'
    continuity: str='continuous_no_joint'

@dataclass
class FatigueUse:
    life_years: float=20.0
    uses_per_year: float=2000.0
    loaded_passages_per_use: float=1.0
    empty_passages_per_use: float=1.0
    component_group: str='E8_conservative'
    detail: str='automatic_section_preset'
    stress_cycles_per_use: float|None=None
    group_source: str=''

@dataclass
class AutonomousProject:
    schema_version: int=5
    analysis_mode: str='autonomous_runway'
    demonstration: bool=True
    span_m: float=6.0
    section: Section=field(default_factory=Section)
    material: Material=field(default_factory=Material)
    material_grade: str='ASTM A572 GR50'
    wheels: list[WheelInput]=field(default_factory=lambda:[WheelInput(),WheelInput(offset_m=2.0)])
    rail: RailInput=field(default_factory=RailInput)
    fatigue: FatigueUse=field(default_factory=FatigueUse)
    dynamic_psi_override: float|None=None
    gamma_g_override: float|None=None
    gamma_q_override: float|None=None
    factor_basis: str='Valores sugeridos pelas normas; confirmar aplicação ao equipamento'
    hoist_class: str='HC2'
    drive_class: str='HD1'
    hoist_speed_m_s: float=0.1
    creep_speed_m_s: float=0.0
    equipment_group: str='A5'
    service_class: str='moderate'
    equipment_use: str='other'
    action_applicability: ActionApplicability=field(default_factory=ActionApplicability)
    extra_dead_kn_per_m: float=0.0
    fullheight_nominal_detail: dict|None=None
    restraint_application: str='physical_response'
    upper_braces_m: list[float]=field(default_factory=list)
    lower_braces_m: list[float]=field(default_factory=list)
    lateral_only_braces_m: list[float]=field(default_factory=list)
    lateral_only_brace_level: str="shear_center"
    lateral_only_brace_model: str="unselected"
    lateral_only_brace_stiffness_kn_per_mm: float|None=None
    stiffener_spacing_m: float=1.0
    stiffener_thickness_mm: float=16.0
    flange_web_weld_min_leg_mm: float=0.0
    stiffener_flange_weld_min_leg_mm: float=0.0
    stiffener_web_weld_min_leg_mm: float=0.0
    support_bearing_length_mm: float=150.0
    beam_end_left_mm: float=150.0
    beam_end_right_mm: float=150.0
    wheel_travel_scope: str='between_support_axes'
    support_contact: str='centered_under_web'
    stiffener_layout: str='paired_full_height_uniform'
    stiffener_connection: str='web_and_both_flanges_welded'
    stiffener_outstand_mm: float=90.0
    support_model: str='simple_forks_free_warping'
    axial_support: str='left_fixed_right_sliding'
    load_input_basis: str='characteristic_components'
    sampling_tolerance: float=0.005
    equipment_basis: EquipmentBasis=field(default_factory=EquipmentBasis)

    def to_dict(self):
        result=asdict(self)
        result['action_applicability']=action_applicability_dict(self.action_applicability)
        return result
    def to_json(self):return json.dumps(self.to_dict(),ensure_ascii=False,indent=2,allow_nan=False)
    @classmethod
    def from_json(cls,payload):
        if isinstance(payload,bytes):payload=payload.decode('utf-8')
        raw=json.loads(payload,parse_constant=lambda x:(_ for _ in ()).throw(ValueError('Número não finito: '+x)))
        if not isinstance(raw,dict) or type(raw.get('schema_version')) is not int or raw.get('schema_version') not in (2,3,4,5) or raw.get('analysis_mode')!='autonomous_runway':
            raise ValueError('Este arquivo não é um projeto autônomo de rolamento (formatos legados 2/3/4 ou formato 5 atual). Os projetos anteriores permanecem no app 0.3.1.')
        legacy_schema=raw['schema_version']==2
        pre_mode_schema=raw['schema_version'] in (2,3)
        pre_detail_schema=raw['schema_version'] in (2,3,4)
        def obj(t,v):
            if t is ActionApplicability and isinstance(v,dict):
                complete={f.name for f in fields(t)}
                if set(v)==complete-TEST_CLASS_ENVELOPE_FIELDS and v.get('test_dynamic_method')!=TEST_CLASS_ENVELOPE_METHOD:
                    v=dict(v,test_nominal_speed_m_s=None,test_speed_source='',test_regular_lifting_adopted=False)
            if legacy_schema and t is RailInput and isinstance(v,dict) and set(v)=={f.name for f in fields(t)}-{'catalog_id','property_source'}:
                v=migrate_legacy_rail_fields(v)
            if not isinstance(v,dict) or set(v)!={f.name for f in fields(t)}:raise ValueError('Campos inválidos em '+t.__name__)
            return t(**v)
        raw=dict(raw)
        current_expected={f.name for f in fields(cls)}
        expected=current_expected-({'restraint_application'} if pre_mode_schema else set())-({'fullheight_nominal_detail'} if pre_detail_schema else set())
        lateral_added={'lateral_only_braces_m','lateral_only_brace_level','lateral_only_brace_model','lateral_only_brace_stiffness_kn_per_mm'}
        old_weld={'flange_web_weld_min_leg_mm','stiffener_flange_weld_min_leg_mm','stiffener_web_weld_min_leg_mm'}
        # Exact legacy schema migration: only known complete predecessors may omit metadata.
        legacy_expected=expected-{'equipment_basis'}
        if raw['schema_version']==2:
            if set(raw) not in (legacy_expected, legacy_expected-old_weld, legacy_expected-lateral_added, legacy_expected-lateral_added-old_weld):
                raise ValueError('Campos incompatíveis com o projeto legado de formato 2.')
            raw['equipment_basis']=asdict(EquipmentBasis())
            raw['schema_version']=3
        if legacy_schema and set(raw) in (expected-lateral_added, expected-lateral_added-old_weld):
            raw.update(lateral_only_braces_m=[], lateral_only_brace_level='shear_center', lateral_only_brace_model='unselected', lateral_only_brace_stiffness_kn_per_mm=None)
        added={'flange_web_weld_min_leg_mm','stiffener_flange_weld_min_leg_mm','stiffener_web_weld_min_leg_mm'}
        # Explicit migration of the immediately preceding format-2 schema only.
        # Partial/truncated new files and unrelated omissions remain errors.
        if legacy_schema and set(raw)==expected-added:
            raw.update({name:0.0 for name in added})
        if set(raw)!=expected:raise ValueError('Campos desconhecidos ou ausentes no projeto.')
        if pre_mode_schema:
            raw['restraint_application']='physical_response'
        if pre_detail_schema:
            raw['fullheight_nominal_detail']=None
            raw['schema_version']=5
        if isinstance(raw.get('action_applicability'),dict) and isinstance(raw['action_applicability'].get('test_wheel_vertical_kn'),list):
            raw['action_applicability']=dict(raw['action_applicability'],test_wheel_vertical_kn=tuple(raw['action_applicability']['test_wheel_vertical_kn']))
        for name,t in [('section',Section),('material',Material),('rail',RailInput),('fatigue',FatigueUse),('action_applicability',ActionApplicability),('equipment_basis',EquipmentBasis)]:raw[name]=obj(t,raw[name])
        if not isinstance(raw['wheels'],list):raise ValueError('Lista de rodas inválida.')
        raw['wheels']=[obj(WheelInput,w) for w in raw['wheels']]
        if raw['fullheight_nominal_detail'] is not None:
            from .autonomous_fullheight_detail import fullheight_detail_from_mapping
            raw['fullheight_nominal_detail']=fullheight_detail_from_mapping(raw['fullheight_nominal_detail']).to_dict()
        result=cls(**raw);errors=validate_autonomous(result)
        if errors:raise ValueError('; '.join(errors))
        return result

def validate_autonomous(p):
    errors=list(action_applicability_errors(p.action_applicability))+equipment_basis_errors(p.equipment_basis)
    def numeric(v,label,minimum=0,positive=False):
        if isinstance(v,bool) or not isinstance(v,(int,float)) or not math.isfinite(v) or (v<=minimum if positive else v<minimum):errors.append(label+': valor numérico fora da faixa.');return False
        return True
    if type(p.schema_version) is not int or p.schema_version!=5:errors.append('O projeto atual deve usar formato 5; importe formatos anteriores pela migração.')
    if p.restraint_application not in MODES:errors.append('Modo de aplicação dos travamentos desconhecido.')
    if p.fullheight_nominal_detail is not None:
        if type(p.fullheight_nominal_detail) is not dict:errors.append('Detalhe full-height nominal deve ser objeto físico explícito.')
        elif p.restraint_application!='resistance_lengths_only':errors.append('Família full-height nominal exige o modo de comprimentos resistentes, sem novas reações intermediárias.')
    if type(p.demonstration) is not bool:errors.append('Indicador de demonstração inválido.')
    numeric(p.span_m,'Vão',positive=True)
    for name in ('extra_dead_kn_per_m','stiffener_spacing_m','stiffener_thickness_mm','support_bearing_length_mm','sampling_tolerance'):numeric(getattr(p,name),name,positive=name!='extra_dead_kn_per_m')
    for name in ('flange_web_weld_min_leg_mm','stiffener_flange_weld_min_leg_mm','stiffener_web_weld_min_leg_mm'):
        numeric(getattr(p,name),name)
    if not p.wheels or len(p.wheels)>20:errors.append('Informe entre uma e vinte rodas por caminho.')
    for i,w in enumerate(p.wheels):
        for name in ('offset_m','dead_kn','lifted_kn'):numeric(getattr(w,name),f'Roda {i+1}: {name}')
        for name in ('transverse_kn','longitudinal_kn'):
            v=getattr(w,name)
            if isinstance(v,bool) or not isinstance(v,(int,float)) or not math.isfinite(v):errors.append(f'Roda {i+1}: força horizontal inválida.')
    for name in ('upper_braces_m','lower_braces_m','lateral_only_braces_m'):
        data=getattr(p,name)
        if not isinstance(data,list):errors.append('Lista de travamentos inválida.');continue
        for x in data:
            if numeric(x,'Posição de travamento') and numeric(p.span_m,'Vão',positive=True) and x>p.span_m:errors.append('Travamento fora do vão.')
    if p.lateral_only_brace_level not in ('shear_center','upper_flange','lower_flange'):
        errors.append('Nível físico da contenção lateral inválido.')
    if p.lateral_only_brace_model not in ('unselected','rigid_discrete','elastic_discrete'):
        errors.append('Idealização da contenção lateral inválida.')
    if p.lateral_only_braces_m and p.lateral_only_brace_model=='unselected' and p.restraint_application=='physical_response':
        errors.append('Defina a idealização física dos apoios laterais: efetivamente rígidos ou elásticos.')
    if p.lateral_only_braces_m and p.lateral_only_brace_model=='elastic_discrete':
        numeric(p.lateral_only_brace_stiffness_kn_per_mm,'Rigidez lateral por apoio (kN/mm)',positive=True)
    elif p.lateral_only_brace_stiffness_kn_per_mm is not None:
        numeric(p.lateral_only_brace_stiffness_kn_per_mm,'Rigidez lateral por apoio (kN/mm)',positive=True)
    for name in ('width_mm','height_mm','inertia_cm4','mass_kg_per_m'):numeric(getattr(p.rail,name),'Trilho '+name)
    if (p.rail.width_mm==0)!=(p.rail.height_mm==0):errors.append('Largura e altura do trilho devem ser ambas positivas ou ambas zero.')
    for name in ('lateral_eccentricity_mm','offset_from_web_mm'):
        v=getattr(p.rail,name)
        if isinstance(v,bool) or not isinstance(v,(int,float)) or not math.isfinite(v):errors.append('Trilho '+name+': excentricidade inválida.')
    for name in ('wheel_rail_clearance_mm','head_width_mm'):numeric(getattr(p.rail,name),'Trilho '+name)
    for name in ('beam_end_left_mm','beam_end_right_mm','stiffener_outstand_mm'):numeric(getattr(p,name),name)
    if p.rail.wheel_guidance not in ('unselected','flanged','guide_roller_unguided_side'):errors.append('Tipo de guia da roda inválido.')
    if p.rail.local_attachment not in ('unselected','non_rigid'):errors.append('Fixação local do trilho não implementada.')
    if p.rail.continuity not in ('continuous_no_joint','joint_or_unknown'):errors.append('Continuidade do trilho inválida.')
    if p.support_contact not in ('centered_under_web','other_or_unknown'):errors.append('Contato do apoio inválido.')
    if p.wheel_travel_scope not in ('between_support_axes','including_physical_projections'):errors.append('Trecho de passagem das rodas inválido.')
    if p.stiffener_layout not in ('paired_full_height_uniform','paired_full_height_supports','none_or_unknown'):errors.append('Disposição dos enrijecedores inválida.')
    if p.stiffener_connection not in ('web_and_both_flanges_welded','web_only_welded','other_or_unknown'):errors.append('Ligação dos enrijecedores inválida.')
    for name in ('life_years','uses_per_year','loaded_passages_per_use','empty_passages_per_use'):numeric(getattr(p.fatigue,name),'Fadiga '+name)
    if not isinstance(p.fatigue.group_source,str):errors.append('Origem da classificação E deve ser texto.')
    if p.fatigue.stress_cycles_per_use is not None:numeric(p.fatigue.stress_cycles_per_use,'Ciclos de tensão por utilização',positive=True)
    if p.support_model!='simple_forks_free_warping':errors.append('Modelo de apoio ainda não implementado.')
    if p.axial_support!='left_fixed_right_sliding':errors.append('Modelo axial ainda não implementado.')
    if p.load_input_basis!='characteristic_components':errors.append('Separe as parcelas características antes de aplicar fatores.')
    s=p.section;m=p.material
    if p.material_grade not in ('ASTM A36','ASTM A572 GR50','S235','S275','S355','custom'):errors.append('Designação do aço inválida.')
    for name in ('d_mm','bf_mm','tw_mm','tf_mm'):numeric(getattr(s,name),'Perfil '+name,positive=True)
    for name in ('bottom_bf_mm','bottom_tf_mm','root_radius_mm'):numeric(getattr(s,name),'Perfil '+name)
    if all(isinstance(getattr(s,n),(int,float)) and not isinstance(getattr(s,n),bool) and math.isfinite(getattr(s,n)) for n in ('d_mm','tf_mm','bottom_tf_mm','bf_mm','tw_mm','bottom_bf_mm','root_radius_mm')):
        if s.d_mm<=s.tf_mm+s.bottom_thickness+2*s.root_radius_mm:errors.append('Altura livre da alma deve ser positiva.')
        if s.tw_mm>=min(s.bf_mm,s.bottom_width):errors.append('Alma deve ser mais estreita que as mesas.')
    thicknesses=(s.tw_mm,s.tf_mm,s.bottom_thickness,p.stiffener_thickness_mm)
    if all(isinstance(v,(int,float)) and not isinstance(v,bool) and math.isfinite(v) and v>0 for v in thicknesses):
        for name,label,thin,applicable in (
            ('flange_web_weld_min_leg_mm','Filete contínuo alma–mesa',min(s.tw_mm,s.tf_mm,s.bottom_thickness),s.fabrication=='welded'),
            ('stiffener_flange_weld_min_leg_mm','Filete enrijecedor–mesa',min(p.stiffener_thickness_mm,s.tf_mm,s.bottom_thickness),True),
            ('stiffener_web_weld_min_leg_mm','Filete enrijecedor–alma',min(p.stiffener_thickness_mm,s.tw_mm),True)):
            value=getattr(p,name);maximum=thin if thin<6.3 else thin-1.5
            if applicable and isinstance(value,(int,float)) and not isinstance(value,bool) and math.isfinite(value) and value>maximum:
                errors.append(f'{label}: mínimo informado {value:g} mm excede o máximo geométrico {maximum:g} mm; ajuste o mínimo ou a espessura das peças.')
            elif applicable and isinstance(value,(int,float)) and not isinstance(value,bool) and math.isfinite(value) and value>0 and math.ceil(value*2)/2>maximum:
                errors.append(f'{label}: mínimo informado exige proposta de {math.ceil(value*2)/2:g} mm em passos de 0,5 mm, acima do máximo geométrico {maximum:g} mm.')
    for name in ('fy_mpa','fu_mpa','E_mpa','G_mpa','gamma_a1'):numeric(getattr(m,name),'Material '+name,positive=True)
    if isinstance(m.fy_mpa,(int,float)) and isinstance(m.fu_mpa,(int,float)) and m.fy_mpa>m.fu_mpa:errors.append('fy não pode ultrapassar fu.')
    if s.fabrication=='welded' and s.root_radius_mm!=0:errors.append('Perfil soldado usa raio de concordância igual a zero; a altura livre é entre faces das mesas.')
    if s.fabrication not in ('rolled','welded'):errors.append('Fabricação do perfil desconhecida.')
    if s.property_basis not in ('rectangles','catalog'):errors.append('Base geométrica desconhecida.')
    if s.property_basis=='catalog':
        try:
            from .catalog import section_from_profile
            original=section_from_profile(s.catalog_id)
            if asdict(s)!=asdict(original):errors.append('Propriedades catalogadas alteradas: selecione novamente o perfil ou use seção customizável.')
        except (TypeError,ValueError,KeyError):errors.append('Perfil de catálogo não reconhecido.')
    for name in ('dynamic_psi_override','gamma_g_override','gamma_q_override'):
        if getattr(p,name) is not None:numeric(getattr(p,name),name,minimum=1.0)
    if not isinstance(p.factor_basis,str) or not p.factor_basis.strip():errors.append('Identifique a base dos fatores.')
    if p.hoist_class not in ('HC1','HC2','HC3','HC4') and not (p.hoist_class=='unselected' and p.dynamic_psi_override is not None):errors.append('Informe a classe HC para dinâmica automática ou informe Ψ diretamente.')
    if p.drive_class not in ('HD1','HD2','HD3','HD4','HD5') and not (p.drive_class=='unselected' and p.dynamic_psi_override is not None):errors.append('Informe a classe HD para dinâmica automática ou informe Ψ diretamente.')
    if p.equipment_group not in tuple('A'+str(i) for i in range(1,9)):errors.append('Grupo A inválido.')
    if p.service_class not in ('light','moderate','heavy','severe'):errors.append('Classe de serviço inválida.')
    if p.equipment_use not in ('other','steelworks'):errors.append('Uso siderúrgico ou demais usos deve ser identificado.')
    numeric(p.hoist_speed_m_s,'Velocidade nominal de elevação')
    numeric(p.creep_speed_m_s,'Velocidade lenta de elevação')
    if isinstance(p.creep_speed_m_s,(int,float)) and isinstance(p.hoist_speed_m_s,(int,float)) and p.creep_speed_m_s>p.hoist_speed_m_s:errors.append('Velocidade lenta excede velocidade nominal.')
    if p.rail.attachment!='non_composite':errors.append('A contribuição composta do trilho não está implementada.')
    errors.extend(rail_definition_errors(p.rail))
    errors.extend(lateral_restraint_errors(p))
    if p.fatigue.component_group not in ('E1','E2','E3','E4','E5','E6','E7','E8','E8_conservative','P4_cycles_conservative'):errors.append('Grupo de fadiga inválido.')
    if isinstance(p.sampling_tolerance,(int,float)) and not .00001<=p.sampling_tolerance<=.05:errors.append('Tolerância numérica deve estar entre 0,001% e 5%.')
    if len({w.offset_m for w in p.wheels})!=len(p.wheels):errors.append('Duas rodas não podem ter o mesmo deslocamento longitudinal.')
    if p.fullheight_nominal_detail is not None and not errors:
        try:
            from .autonomous_fullheight_runtime import resolved_detail
            resolved_detail(p)
        except (ValueError,TypeError,KeyError,AttributeError) as exc:errors.append('Detalhe full-height: '+str(exc))
    return list(dict.fromkeys(errors))


def physical_premises(p: AutonomousProject) -> list[str]:
    """One transparent premise list, generated from the active physical model."""
    contact={'centered_under_web':'centrado sob a alma','other_or_unknown':'outro contato ou posição desconhecida'}[p.support_contact]
    layout={'paired_full_height_uniform':'pares de altura total nos apoios e ao longo do vão',
            'paired_full_height_supports':'pares de altura total somente nos apoios',
            'none_or_unknown':'sem enrijecedores ou disposição desconhecida'}[p.stiffener_layout]
    connection={'web_and_both_flanges_welded':'soldados à alma e às duas mesas',
                'web_only_welded':'soldados somente à alma','other_or_unknown':'outra ligação ou ligação desconhecida'}[p.stiffener_connection]
    out=[
        'Viga reta prismática, um vão biapoiado, comportamento elástico e pequenos deslocamentos.',
        ('Apoios em garfo nos eixos: deslocamentos vertical/lateral e giro de torção impedidos; garfos sem restrição própria ao empenamento, que é contínuo nas projeções físicas, com pontas externas livres.' if p.beam_end_left_mm or p.beam_end_right_mm else 'Apoios de extremidade em garfo: deslocamentos vertical/lateral e giro de torção impedidos; empenamento livre.'),
        'Deslocamento axial impedido no apoio esquerdo e livre no direito.',
        'Cargas características das rodas separadas em peso do equipamento e carga içada; fatores apresentados por caso.',
        ('Peso próprio do perfil/trilho e corpos líquidos da proposta full-height incluídos. Chapas com recortes, reposição CJP e filetes usam volumes e centroides declarados, sem dupla contagem; os pares são cargas estacionárias e as juntas longitudinais têm incremento contínuo físico. Nenhuma rigidez global adicional é creditada às chapas.' if p.fullheight_nominal_detail is not None else 'Peso próprio do perfil, trilho e chapas dos pares de enrijecedores incluídos automaticamente. As chapas são cargas fixas nas posições reais, com volume retangular bruto e peso específico de 78,5 kN/m³. Peso de soldas/acessórios sem volume definido deve ser declarado na carga permanente adicional quando relevante. O peso permanente linear do perfil/trilho, inclusive adicional declarado, continua nas projeções físicas; suas forças e momentos equivalentes entram no vão.'),
        'Trilho sem contribuição para a resistência global da seção de aço.',
        ('Trem percorre somente entre os eixos dos apoios. Projeções físicas de extremidade permitem dispersão local e não recebem rodas neste modelo.'
         if p.wheel_travel_scope=='between_support_axes' else 'Rodas também percorrem as projeções físicas: requer modelo de balanços carregados, além do vão entre apoios.'),
        f'Projeções além dos eixos: esquerda {p.beam_end_left_mm:g} mm; direita {p.beam_end_right_mm:g} mm. Contato inferior: {p.support_bearing_length_mm:g} mm, {contact}.',
        f'Enrijecedores: {layout}; {connection}; duas chapas por seção, espessura {p.stiffener_thickness_mm:g} mm e largura saliente {p.stiffener_outstand_mm:g} mm quando há pares.',
        'As chapas e suas soldas são verificadas com a geometria e o detalhe fixo de projeto; atendimento, excedências e limites do modelo constam dos resultados.',
    ]
    if any((p.flange_web_weld_min_leg_mm,p.stiffener_flange_weld_min_leg_mm,p.stiffener_web_weld_min_leg_mm)):
        out.append(f'Pernas mínimas solicitadas de filete: alma–mesa contínua {p.flange_web_weld_min_leg_mm:g} mm; enrijecedor–mesa {p.stiffener_flange_weld_min_leg_mm:g} mm; enrijecedor–alma {p.stiffener_web_weld_min_leg_mm:g} mm. Zero mantém proposta automática; mínimos normativos e máximos geométricos permanecem aplicáveis. O mesmo detalhe fixo é usado em resistência e fadiga.')
    if resistance_lengths_only(p):
        out.append('Travamentos intermediários usados somente como comprimentos resistentes. Solicitações e flechas mantêm a análise bi-garfo, sem novas reações nem redistribuição. As ligações diretamente à mesa/seção são externas ao dimensionamento dos enrijecedores; coincidência de posição não cria transferência ao par.')
    if p.upper_braces_m and not resistance_lengths_only(p):
        out.append('Travamentos laterais na mesa superior nas posições informadas; reações e deslocamentos obtidos por compatibilidade lateral/torcional acoplada.')
    if p.lower_braces_m and not resistance_lengths_only(p):
        out.append('Travamentos laterais na mesa inferior nas posições informadas; reações e deslocamentos obtidos por compatibilidade lateral/torcional acoplada.')
    if p.lateral_only_braces_m and not resistance_lengths_only(p):
        level={'shear_center':'centro de cisalhamento','upper_flange':'mesa superior','lower_flange':'mesa inferior'}[p.lateral_only_brace_level]
        restraint='deslocamento lateral impedido no ponto de aplicação' if p.lateral_only_brace_model=='rigid_discrete' else (f'mola horizontal de {p.lateral_only_brace_stiffness_kn_per_mm:g} kN/mm por ponto' if p.lateral_only_brace_stiffness_kn_per_mm is not None else 'idealização/rigidez ainda não definida')
        out.append(f'Contenções horizontais adicionais no {level}: {restraint}. O giro de torção não é imposto como nulo. Seu efeito entra nos esforços, deslocamentos e reações, sem crédito favorável de redução de Lb ou aumento de Mcr. A ligação e o treliçamento externos devem realizar a contenção idealizada e transmitir a reação sem distorção da seção.')
    out.extend(equipment_basis_premises(p))
    if p.demonstration:out.insert(0,'EXEMPLO SINTÉTICO: substitua os dados pelos do equipamento ou por hipóteses de projeto explicitamente adotadas.')
    return out
