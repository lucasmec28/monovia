"""Focused rail editor; the owning input editor resets its prefix on import.

Does not edit the beam section, attachment, eccentricity or wheel guidance.
Returns a copy with resolved rail properties before any calculation signature.
"""
from copy import deepcopy

import streamlit as st

from .autonomous_rail import (
    CATALOG, MANUAL, RECTANGULAR, RAIL_SHAPES, PROPERTY_FIELDS,
    RECTANGULAR_SOURCE, catalog_rail_updates, get_rail_profile,
    list_rail_profiles, rectangular_rail_updates,
)


def render_rail_section(rail, *, key_prefix='autonomous_inputs:'):
    """Choose automatic rectangle, pinned TR catalogue, or supplied properties."""
    def key(name):
        return key_prefix + name

    def number(label, name, initial, step=1.0, help=None):
        return st.number_input(label, min_value=0.0,
            value=None if key(name) in st.session_state else float(initial),
            step=float(step), format='%.2f', key=key(name), help=help)

    p = deepcopy(rail)
    labels = {RECTANGULAR: 'Retangular · informar b e h',
              CATALOG: 'TR · catálogo verificado',
              MANUAL: 'Propriedades informadas'}
    if p.shape not in RAIL_SHAPES:
        st.error('Origem das propriedades do trilho inválida; revise o arquivo de entrada.')
        return p
    mode = st.selectbox('Tipo de trilho', RAIL_SHAPES, index=RAIL_SHAPES.index(p.shape),
                        format_func=labels.get, key=key('rail_shape'))
    previous_mode = st.session_state.get(key('rail_previous_mode'), p.shape)
    previous = st.session_state.get(key('rail_snapshot'), p)
    field_keys = dict(width_mm='rail_width', height_mm='rail_height',
                      head_width_mm='rail_head_width', inertia_cm4='rail_inertia',
                      mass_kg_per_m='rail_mass')
    if mode != previous_mode:
        for name in PROPERTY_FIELDS:
            st.session_state[key(field_keys[name])] = float(getattr(previous, name))
        st.session_state[key('rail_property_source')] = (
            getattr(previous, 'property_source', '') if previous_mode != RECTANGULAR else '')
    p.shape = mode

    if mode == CATALOG:
        profiles = list_rail_profiles()
        ids = tuple(profile.id for profile in profiles)
        initial_id = getattr(p, 'catalog_id', '')
        if p.shape == rail.shape and initial_id not in ids and key('rail_catalog') not in st.session_state:
            st.error('Trilho de catálogo não reconhecido; revise o arquivo de entrada.')
            return p
        selected = st.selectbox('Trilho TR (variante e edição)', ids,
            index=ids.index(initial_id) if initial_id in ids else 0,
            format_func=lambda value: get_rail_profile(value).label, key=key('rail_catalog'))
        for name, value in catalog_rail_updates(selected).items():
            setattr(p, name, value)
        columns = st.columns(3)
        for col, label, value in zip(columns,
                ('Largura da base b (mm)', 'Altura h (mm)', 'Largura da cabeça br (mm)'),
                (p.width_mm, p.height_mm, p.head_width_mm)):
            col.metric(label, f'{value:.2f}')
        columns = st.columns(2)
        columns[0].metric('Inércia vertical do trilho (cm⁴)', f'{p.inertia_cm4:.2f}')
        columns[1].metric('Massa do trilho (kg/m)', f'{p.mass_kg_per_m:.2f}')
        profile = get_rail_profile(selected)
        st.caption(f'Fonte: [{profile.source.split("; ")[0]}]({profile.source_url}). '
            'Confira a variante e o desenho do trilho fornecido; a seleção não comprova disponibilidade comercial atual.')
    else:
        columns = st.columns(2 if mode == RECTANGULAR else 3)
        with columns[0]:
            p.width_mm = number('Largura do trilho (mm)', 'rail_width', p.width_mm, 5,
                               help='Largura da base b; no retângulo também é a largura da cabeça br.')
        with columns[1]:
            p.height_mm = number('Altura do trilho (mm)', 'rail_height', p.height_mm, 5)
        if mode == RECTANGULAR:
            p.catalog_id = ''
            p.property_source = RECTANGULAR_SOURCE
            try:
                updates = rectangular_rail_updates(p.width_mm, p.height_mm)
            except ValueError as exc:
                st.error(str(exc))
            else:
                for name, value in updates.items():
                    setattr(p, name, value)
                columns = st.columns(2)
                columns[0].metric('Inércia vertical do trilho (cm⁴)', f'{p.inertia_cm4:.2f}')
                columns[1].metric('Massa do trilho (kg/m)', f'{p.mass_kg_per_m:.2f}')
                st.caption(f'Calculado automaticamente: I = b·h³/12; densidade = 7.850 kg/m³; '
                           f'largura da cabeça br = b = {p.head_width_mm:.2f} mm.')
        else:
            p.catalog_id = ''
            with columns[2]:
                p.head_width_mm = number('Largura da cabeça do trilho br (mm)', 'rail_head_width', p.head_width_mm)
            columns = st.columns(2)
            with columns[0]:
                p.inertia_cm4 = number('Inércia vertical do trilho (cm⁴)', 'rail_inertia', p.inertia_cm4)
            with columns[1]:
                p.mass_kg_per_m = number('Massa do trilho (kg/m)', 'rail_mass', p.mass_kg_per_m, .5)
            p.property_source = st.text_input('Fonte das propriedades do trilho',
                value=None if key('rail_property_source') in st.session_state else getattr(p, 'property_source', ''),
                key=key('rail_property_source'),
                help='Identifique fabricante, catálogo/desenho e revisão que informam I e massa. '
                     'A largura do trilho é a da base; br é a largura da cabeça.')
            if not p.property_source.strip():
                st.warning('Informe a referência usada para conferir as propriedades do trilho.')
            if p.property_source.startswith('JSON anterior'):
                st.info(p.property_source)
    st.caption('O trilho entra no peso próprio, na altura das forças e na dispersão local. '
               'Não contribui para a resistência ou a rigidez global da seção da viga.')
    st.session_state[key('rail_previous_mode')] = mode
    st.session_state[key('rail_snapshot')] = deepcopy(p)
    return p
