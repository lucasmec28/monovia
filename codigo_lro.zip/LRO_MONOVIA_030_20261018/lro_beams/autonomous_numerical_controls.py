"""Legacy-app numerical budget, separate from physical inputs and solver policy.

The native engine is unchanged: only its explicit iteration budget is selected.
Saved result records are never accepted as a calculation during project import.
"""
from __future__ import annotations

import hashlib
import json
import math

from .autonomous_result import input_signature
from .document_metadata import (project_document, unpack_project_document,
                                validate_document_metadata, word_cache_signature)

REFINEMENT_BUDGETS = (6, 7)
DEFAULT_MAX_REFINEMENTS = 7


def default_calculation_controls():
    return {'max_refinements': DEFAULT_MAX_REFINEMENTS}


def validate_calculation_controls(raw):
    if not isinstance(raw, dict) or set(raw) != {'max_refinements'}:
        raise ValueError('Controles numéricos devem conter somente max_refinements.')
    value = raw['max_refinements']
    if type(value) is not int or value not in REFINEMENT_BUDGETS:
        raise ValueError('O orçamento numérico deve ser o inteiro 6 ou 7.')
    return {'max_refinements': value}


def unpack_legacy_project_document(raw):
    """Accept old documents unchanged, or the exact legacy-app v2 envelope."""
    if isinstance(raw, dict) and ('calculation_controls' in raw or raw.get('version') == 2):
        required = {'format', 'version', 'inputs', 'calculation_controls'}
        allowed = required | {'document_metadata', 'results'}
        if set(raw) - allowed or not required <= set(raw):
            raise ValueError('Campos desconhecidos ou ausentes no envelope numérico.')
        if (raw['format'] not in ('LRO_AUTONOMOUS_PROJECT', 'LRO_AUTONOMOUS_CALCULATION')
                or type(raw['version']) is not int or raw['version'] != 2):
            raise ValueError('Formato ou versão do envelope numérico não reconhecido.')
        controls = validate_calculation_controls(raw['calculation_controls'])
        if not isinstance(raw['inputs'], dict):
            raise ValueError('O campo inputs deve conter um objeto de projeto JSON.')
        if 'results' in raw and (raw['format'] != 'LRO_AUTONOMOUS_CALCULATION'
                                 or not isinstance(raw['results'], dict)):
            raise ValueError('Resultados só são aceitos como objeto no envelope de cálculo; serão ignorados.')
        # Reuse the existing metadata/envelope validator without extending its
        # shared contract for other routes. Imported results are discarded there.
        previous = {key: value for key, value in raw.items() if key != 'calculation_controls'}
        previous['version'] = 1
        inputs, metadata = unpack_project_document(previous)
        return inputs, metadata, controls
    inputs, metadata = unpack_project_document(raw)
    return inputs, metadata, default_calculation_controls()


def legacy_project_document(project, metadata, controls):
    clean = validate_calculation_controls(controls)
    # Keep the original serializer responsible for genuine document identity.
    original = project_document(project, metadata)
    inputs = original['inputs'] if 'inputs' in original else original
    payload = {'format': 'LRO_AUTONOMOUS_PROJECT', 'version': 2,
               'inputs': inputs, 'calculation_controls': clean}
    identity = validate_document_metadata({} if metadata is None else metadata)
    if identity:
        payload['document_metadata'] = identity
    return payload


def numerical_run_identity(project, controls):
    settings = {**validate_calculation_controls(controls), 'initial_divisions': 8,
                'sampling_tolerance': project.sampling_tolerance, 'required_stable_rounds': 2}
    raw = {'input_signature': input_signature(project), **settings}
    return hashlib.sha256(json.dumps(raw, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()).hexdigest()


def calculate_with_controls(project, controls, *, progress=None, calculate=None):
    """Call the native engine, then append traceability, never a verdict."""
    controls = validate_calculation_controls(controls)
    if calculate is None:
        from .autonomous_engine import calculate_core
        calculate = calculate_core
    result = calculate(project, progress=progress, initial_divisions=8,
                       max_refinements=controls['max_refinements'])
    result.numerical_evidence['calculation_controls'] = {
        **controls, 'initial_divisions': 8,
        'sampling_tolerance': project.sampling_tolerance, 'required_stable_rounds': 2,
        'run_identity': numerical_run_identity(project, controls),
    }
    return result


def recorded_calculation_controls(result):
    """None means historical/unrecorded, not an invented default budget."""
    if 'calculation_controls' not in result.numerical_evidence:
        return None
    evidence = result.numerical_evidence['calculation_controls']
    keys = {'max_refinements', 'initial_divisions', 'sampling_tolerance',
            'required_stable_rounds', 'run_identity'}
    if not isinstance(evidence, dict) or set(evidence) != keys:
        raise ValueError('Registro dos controles numéricos inválido.')
    if (type(evidence['initial_divisions']) is not int or evidence['initial_divisions'] != 8
            or type(evidence['required_stable_rounds']) is not int or evidence['required_stable_rounds'] != 2
            or type(evidence['sampling_tolerance']) not in (int, float)
            or not math.isfinite(evidence['sampling_tolerance']) or not 0 < evidence['sampling_tolerance'] < .2
            or not isinstance(evidence['run_identity'], str) or len(evidence['run_identity']) != 64
            or any(char not in '0123456789abcdef' for char in evidence['run_identity'])):
        raise ValueError('Registro dos controles numéricos inválido.')
    return validate_calculation_controls({'max_refinements': evidence.get('max_refinements')})


def result_matches_controls(project, result, controls):
    try:
        recorded = recorded_calculation_controls(result)
    except ValueError:
        return False
    if recorded is None:
        # Historical exports remain supported, but cannot certify the budget
        # currently selected in the app without a native recalculation.
        return False
    return (recorded == validate_calculation_controls(controls)
            and result.numerical_evidence['calculation_controls']['sampling_tolerance'] == project.sampling_tolerance
            and result.numerical_evidence['calculation_controls'].get('run_identity')
            == numerical_run_identity(project, controls))


def validate_recorded_calculation_controls(project, result):
    controls = recorded_calculation_controls(result)
    if controls is not None and not result_matches_controls(project, result, controls):
        raise ValueError('O registro numérico não corresponde às entradas. Recalcule antes de exportar.')
    return controls


def numerical_word_cache_signature(result, metadata=None):
    signature = word_cache_signature(result.input_signature, metadata)
    if recorded_calculation_controls(result) is None:
        return signature
    return signature + ':' + result.numerical_evidence['calculation_controls']['run_identity']
