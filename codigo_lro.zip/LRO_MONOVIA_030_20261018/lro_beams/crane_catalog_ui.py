"""Reversible, source-linked equipment assistant for the autonomous runway app."""
from __future__ import annotations
from copy import deepcopy
from dataclasses import asdict
import json
import streamlit as st
from .crane_catalog import select_references, reference_rows, make_reference_basis, project_diff, can_propose_physical_reference, catalog_speed_dynamic, apply_catalog_speed_dynamic, correlated_vertical_comparison
from .equipment_basis import four_wheel_statics, wheel_signature, equipment_basis_summary
from .autonomous_model import validate_autonomous

_PREFIX='crane_assistant:'

def reset_catalog_inputs():
    for key in list(st.session_state):
        if isinstance(key,str) and key.startswith(_PREFIX):
            del st.session_state[key]


def _n(label,name,value=None,minimum=0.,step=.1,help=None):
    return st.number_input(label,value=value,min_value=minimum,step=step,format='%.3f',key=_PREFIX+name,help=help)



def horizontal_scenario_package(base,additional_factor,document_metadata=None):
    """Two independently importable adopted scenarios with document identity."""
    import io,zipfile
    from .crane_horizontal_reference import apply_horizontal_reference
    from .document_metadata import project_document
    package=io.BytesIO()
    with zipfile.ZipFile(package,'w',zipfile.ZIP_DEFLATED) as z:
        for scenario in ('HT-A','HT-B'):
            other,_=apply_horizontal_reference(base,scenario,dynamic_factor=additional_factor)
            z.writestr('LRO_'+scenario+'.json',json.dumps(project_document(other,document_metadata),ensure_ascii=False,indent=2))
    return package.getvalue()


def _proposal_context():
    names=('capacity','span','family','uprated','record','bridge_mass','trolley_mass','approach','wheelbase','ht','hl','pattern','status','note','hmode','hfactor','adopt_project','catalog_dynamic','adopt_upper_groups','test_regular_scope')
    return json.dumps({name:st.session_state.get(_PREFIX+name) for name in names},sort_keys=True,ensure_ascii=False,allow_nan=True)


def _queue_preview(before,after,title):
    st.session_state[_PREFIX+'proposal']={'before':before.to_json(),'after':after.to_json(),'title':title,'context':_proposal_context()}



def _proposal_view(project):
    from .autonomous_model import AutonomousProject
    proposal=st.session_state.get(_PREFIX+'proposal')
    if not proposal:
        return None
    before=AutonomousProject.from_json(proposal['before'])
    after=AutonomousProject.from_json(proposal['after'])
    try:current=project.to_json()==proposal['before'] and proposal.get('context')==_proposal_context()
    except (ValueError,TypeError):current=False
    st.markdown('**Prévia · '+proposal['title']+'**')
    for name,old,new in project_diff(before,after):
        if name=='wheels':
            st.write('Rodas: valores característicos propostos, antes de Ψ e dos fatores ELU.')
            st.dataframe([{'Roda':i+1,'Distância (m)':w.offset_m,'G (kN)':w.dead_kn,'Q (kN)':w.lifted_kn,'H transversal (kN)':w.transverse_kn,'H longitudinal (kN)':w.longitudinal_kn} for i,w in enumerate(after.wheels)],hide_index=True,width='stretch')
        elif name=='equipment_basis':
            for label,value in equipment_basis_summary(after):st.write(label+': '+value)
        elif name=='fatigue':st.write('Fadiga: '+str(old['component_group'])+' → '+str(new['component_group'])+'; demais dados de uso preservados.')
        elif name=='action_applicability':
            from .autonomous_actions import test_envelope_summary
            for label,value in test_envelope_summary(after.action_applicability):st.write(label+': '+value)
            if old['test_capacity_t']!=new['test_capacity_t']:st.write('Capacidade nominal do ensaio: '+str(old['test_capacity_t'])+' → '+str(new['test_capacity_t'])+' t métricas; não é o multiplicador de sobrecarga p.')
            st.caption('Local do ensaio, elegibilidade do equipamento, sobrecarga p, vento e caminho do batente permanecem inalterados e precisam corresponder ao projeto.')
        else:st.write(name+': '+str(old)+' → '+str(new))
    st.caption(f'Vão entre apoios da viga preservado: {before.span_m:g} m. Perfil, trilho, travamentos, enrijecedores, batente e demais entradas não listadas ficam inalterados.')
    if not current:st.warning('As entradas ou a seleção de referência mudaram depois da prévia. Gere outra proposta antes de aplicar.')
    cols=st.columns(2)
    with cols[0]:
        if st.button('Aplicar proposta ao projeto',key=_PREFIX+'apply',disabled=not current,type='primary'):
            st.session_state['auto_catalog_previous']=proposal['before']
            st.session_state.pop(_PREFIX+'proposal',None)
            return after
    with cols[1]:
        if st.button('Descartar proposta',key=_PREFIX+'discard'):
            st.session_state.pop(_PREFIX+'proposal',None)
            st.rerun()
    return None


def render_catalog_assistant(project):
    """Return a new project only on explicit Apply; preview never changes input."""
    with st.expander('Assistente da ponte apoiada · catálogo, capacidade e hipóteses',expanded=True):
        st.caption('Escolha uma referência, preencha a proposta, confira as hipóteses e aplique. Depois calcule a viga nas entradas abaixo. A seleção sozinha não muda o projeto.')
        st.caption('Use a capacidade e o vão ENTRE TRILHOS da ponte. O vão entre apoios da viga de rolamento é outro dado e não será alterado.')
        seed=project.equipment_basis
        for label,value in equipment_basis_summary(project):
            if label=='Capacidade nominal declarada no ensaio' and 'DIVERGE' in value:st.warning(value)
        cols=st.columns(2)
        with cols[0]:capacity=_n('Capacidade nominal da ponte (tf métricas)','capacity',float(seed.capacity_tf or 7.5),step=2.5)
        with cols[1]:bridge_span=_n('Vão da ponte entre trilhos (m)','span',float(seed.bridge_span_m) if seed.bridge_span_m is not None else None,step=.5)
        family=st.selectbox('Família de ponte para a referência',('all','single_girder_top_running','double_girder_top_running'),format_func=lambda v:{'all':'Comparar univiga e dupla-viga','single_girder_top_running':'Ponte univiga','double_girder_top_running':'Ponte dupla-viga'}[v],key=_PREFIX+'family')
        uprated=st.checkbox('Comparar também a capacidade de catálogo imediatamente superior',key=_PREFIX+'uprated',help='Uma ponte de 8 t não vira 7,5 t, nem 16 t vira 15 t. Maior capacidade não prova maior efeito em toda a viga.')
        try:records=select_references(capacity,bridge_span,allow_uprated=uprated)
        except ValueError as exc:
            st.info(str(exc))
            records=[]
        if family!='all':records=[r for r in records if r['family']==family]
        if records:
            ids=[r['record_id'] for r in records]
            if st.session_state.get(_PREFIX+'record') not in ids:st.session_state.pop(_PREFIX+'record',None)
            _render_correlated_comparison(project,records,capacity,bridge_span)
            labels={r['record_id']:f"{r['manufacturer']} · {r['capacity_metric_t']:g} t · {('faixa '+r['bridge_span_catalog_raw']) if r.get('bridge_span_is_row_upper_bound') else ('vão '+str(r['bridge_span_m'])+' m')} · {r['record_id']}" for r in records}
            selected=st.selectbox('Configuração de referência · registros completos, sem misturar máximos',ids,format_func=labels.get,key=_PREFIX+'record')
            st.caption('A seleção inicial é a primeira referência compatível, não um envelope conservador da família. Compare os efeitos verticais abaixo e avalie separadamente os cenários pertinentes.')
            record=next(r for r in records if r['record_id']==selected)
            if record['capacity_match'] and record['span_match']:
                st.success(('Capacidade exata e vão dentro da faixa publicada do catálogo.' if record['span_match_type']=='band' else 'Correspondência exata de capacidade e vão no catálogo.')+' Referência para hipótese de projeto, não certificado do equipamento real.')
            else:
                st.info(f"Referência de {record['capacity_metric_t']:g} t e {record['bridge_span_m']:g} m, não uma ficha para {capacity:g} tf e {bridge_span:g} m. Não há interpolação ou extrapolação automática.")
            st.dataframe(reference_rows(record),column_config={'0':'Dado','1':'Valor / definição'},hide_index=True,width='stretch')
            st.markdown(f"[Abrir catálogo do fabricante]({record['source_url']}) · página PDF {record['source_pdf_page']}")
            st.caption('Massa, carga máxima e entre-eixos pertencem ao mesmo registro. Rmín não é convertido em carga vazia. Uma configuração isolada não é chamada de conservadora para todas as verificações.')
            invalid=bool(validate_autonomous(project))
            if st.button('Preparar referência sem alterar as cargas',key=_PREFIX+'reference',disabled=invalid):
                proposed=deepcopy(project)
                proposed.equipment_basis=make_reference_basis(project,record,capacity,bridge_span)
                _queue_preview(project,proposed,'referência documental')
            _render_vertical_comparator(project,record)
            with st.expander('Ensaio · proposta separada pela velocidade de catálogo'):
                st.caption('Esta escolha não reutiliza Ψ operacional. Propõe a capacidade nominal da ponte já aplicada e, separadamente, a velocidade máxima publicada como limite para o ensaio regular; calcula uma envoltória HC1–HC4 sem confirmar classe física. Não reduz nem altera a sobrecarga p.')
                regular=st.checkbox('Adotar elevação regular na proposta de ensaio',value=False,key=_PREFIX+'test_regular_scope')
                try:
                    from .crane_catalog import apply_catalog_test_speed_envelope
                    test_project,test_dynamic=apply_catalog_test_speed_envelope(project,record,regular_lifting_adopted=regular)
                    test_error=None
                    st.write(f"Prévia da hipótese: v nominal de ensaio = {test_dynamic['nominal_speed_m_s']:.6g} m/s; Ψ de ensaio = {test_dynamic['psi']:.6g}.")
                except ValueError as exc:test_error=str(exc)
                if test_error:st.caption(test_error)
                st.caption('A proposta não escolhe local, enquadramento não seriado, carga de ensaio p, vento ou batente. Confira esses dados em Situações físicas e ensaio; valores desconhecidos continuam pendentes.')
                if st.button('Preparar hipótese de ensaio pela velocidade deste catálogo',key=_PREFIX+'test_proposal',disabled=invalid or test_error is not None):
                    _queue_preview(project,test_project,'ensaio regular · envoltória HC1–HC4 e velocidade de catálogo')
            with st.expander('Montar cargas por estática · dados físicos explícitos'):
                st.caption('Quatro rodas no total, duas por caminho. Estrutura simétrica; carro e carga na linha do gancho; divisão igual entre as duas rodas. G do carro mantém a mesma posição carregado/vazio. Não substitui o envelope operacional do fabricante.')
                if can_propose_physical_reference(record,capacity,bridge_span):
                    approach_ref=min(record['hook_approach_left_m'],record['hook_approach_right_m'])
                    vertical,evidence=four_wheel_statics(capacity_tf=capacity,bridge_span_m=bridge_span,
                        bridge_mass_kg=record['bridge_only_mass_kg'],trolley_mass_kg=record['trolley_mass_kg'],
                        hook_approach_m=approach_ref,wheelbase_m=record['wheelbase_m'],
                        transverse_kn_per_wheel=0.,longitudinal_kn_per_wheel=0.)
                    st.write(f"Modelo simétrico sugerido a partir deste registro: G = {vertical[0].dead_kn:.3f} kN e Q = {vertical[0].lifted_kn:.3f} kN por roda; entre-eixos {record['wheelbase_m']:.4f} m. Valores verticais sem fatores; H ainda não definido.")
                    st.caption('Massas separadas do catálogo; carro idealizado na linha do gancho e menor aproximação E/F para o caminho mais carregado neste modelo. A massa da faixa é adotada sem interpolação. Desbalanceamento real, passarela e centro de gravidade exigem adequação do equipamento fornecido ao modelo.')
                    if st.button('Usar os dados físicos deste registro na proposta',key=_PREFIX+'seed_reference'):
                        for name,value in {'bridge_mass':record['bridge_only_mass_kg'],'trolley_mass':record['trolley_mass_kg'],
                                           'approach':approach_ref,'wheelbase':record['wheelbase_m']}.items():
                            st.session_state[_PREFIX+name]=float(value)
                        st.session_state[_PREFIX+'note']='Hipótese de fornecimento baseada em '+record['record_id']+'. Massas separadas publicadas; repartição simétrica, carro na linha do gancho e menor aproximação E/F adotados. Vão dentro da faixa publicada; sem interpolação. Ações horizontais declaradas separadamente. O fornecedor deverá compatibilizar equipamento e ações com estas premissas.'
                cols=st.columns(2)
                with cols[0]:
                    bm=_n('Massa da estrutura da ponte, SEM carro/talha (kg)','bridge_mass',None,step=100.)
                    approach=_n('Aproximação do gancho ao trilho analisado (m)','approach',None,step=.05)
                    ht=_n('H transversal característico POR RODA (kN)','ht',None,step=.1)
                with cols[1]:
                    tm=_n('Massa do carro/talha e acessórios móveis (kg)','trolley_mass',None,step=100.)
                    wb=_n('Entre-eixos longitudinal adotado (m)','wheelbase',None,step=.1)
                    hl=_n('H longitudinal característico POR RODA (kN)','hl',None,step=.1)
                st.caption('Os campos vazios são intencionais: peso total de catálogo não é peso da estrutura sem carro, e carga de roda publicada pode incluir dinâmica. Use zero em H somente quando justificado no modelo de ações.')
                pattern=st.selectbox('Padrão de H transversal nas duas rodas',('same_sign','opposed_couple'),format_func=lambda v:'Mesmo sinal · ação transversal resultante' if v=='same_sign' else 'Sinais opostos · binário de guiamento',key=_PREFIX+'pattern')
                st.caption('O binário de guiamento e a aceleração transversal do carro são ações distintas. Um padrão isolado não cobre automaticamente o outro; avalie os cenários aplicáveis.')
                basis_status=st.selectbox('Origem dos dados físicos',('adopted_assumption','project_confirmed'),format_func=lambda v:{'adopted_assumption':'Hipótese de projeto adotada','project_confirmed':'Dados do equipamento confirmados para o projeto'}[v],key=_PREFIX+'status')
                note=st.text_input('Base das massas, geometria e ações horizontais',key=_PREFIX+'note',placeholder='Documento do fabricante ou hipótese de projeto com limites definidos')
                hmode=st.selectbox('Base das ações horizontais da proposta',('manual','HT-A','HT-B'),format_func=lambda v:{'manual':'Valores H informados acima','HT-A':'Hipótese normal HT-A · carro + guiamento (+/−)','HT-B':'Hipótese normal HT-B · carro + guiamento (−/+)'}[v],key=_PREFIX+'hmode')
                hfactor=1.
                if hmode!='manual':
                    hfactor=_n('Fator adicional adotado nas ações horizontais · 1 = sem adicional','hfactor',1.,minimum=1.,step=.1)
                    st.info('Hipótese de operação normal com ações de cálculo roda/trilho pelas expressões citadas. O fator adicional é opcional; 1 mantém essas expressões sem margem extra. O fornecedor deve verificar a compatibilidade das ações e distribuições reais com os cenários adotados.')
                    st.caption('Pi = G+Q estático por roda é a base analítica adotada aqui; não é apresentado como uma definição literal resolvida pela norma.')
                    st.caption('Fonte: NBR 8400-1:2019, 6.2.3.1.1 (p.24), 6.2.3.3/Figura 6 (p.25). Todas as rodas adotadas como motrizes/freadas; força do carro integralmente no caminho crítico e dividida igualmente. Calcule HT-A e HT-B separadamente; não há envelope automático de fadiga.')
                use_catalog_dynamic=False
                try:
                    dyn=catalog_speed_dynamic(record)
                    st.caption(f"Sugestão vertical: velocidades de catálogo {', '.join(f'{v:g}' for v in dyn['published_speed_options_m_min'])} m/min; máximo {dyn['nominal_speed_m_s']:.5f} m/s. HC4 adotada como classe superior resulta em Ψ = {dyn['psi']:.5f}. Não converte grupo da talha em A/E.")
                    use_catalog_dynamic=st.checkbox('Adotar Ψ pela velocidade deste catálogo e HC4 como hipótese',value=True,key=_PREFIX+'catalog_dynamic')
                except ValueError:st.caption('Sem velocidade utilizável neste registro; a dinâmica atual permanece. Há hipótese separada Ψ = 2,22 quando faltam dados.')
                adopt_upper_groups=st.checkbox('Adotar A8 / E8 como hipótese de grupos superiores, sem inferir o uso real',value=True,key=_PREFIX+'adopt_upper_groups',help='Maior Mx implementado e grupo superior de fadiga no domínio dos detalhes cobertos. Não infere ciclos, utilização, serviço ou classe física da talha. A dinâmica Ψ é escolhida separadamente.')
                adopt_project=st.checkbox('Adotar também as demais entradas atuais da viga como premissas de projeto',value=not project.demonstration,key=_PREFIX+'adopt_project',help='Desmarca apenas o modo de demonstração após aplicar. Não confirma dados de fabricante nem aprovação estrutural. Confira perfil, trilho, vínculos, enrijecedores, serviço e eventos aplicáveis.')
                try:
                    wheels,evidence=four_wheel_statics(capacity_tf=capacity,bridge_span_m=bridge_span,bridge_mass_kg=bm,trolley_mass_kg=tm,hook_approach_m=approach,wheelbase_m=wb,transverse_kn_per_wheel=ht if hmode=='manual' else 0.,longitudinal_kn_per_wheel=hl if hmode=='manual' else 0.,transverse_pattern=pattern if hmode=='manual' else 'same_sign')
                    model_error=None if note.strip() else 'Identifique a base das hipóteses antes de preparar as cargas.'
                    if hfactor is None:model_error='Informe o multiplicador horizontal adotado.'
                except ValueError as exc:model_error=str(exc)
                proposed=None
                if model_error is None:
                    proposed=deepcopy(project)
                    proposed.wheels=wheels
                    b=make_reference_basis(project,record,capacity,bridge_span)
                    b.status=basis_status;b.load_model='symmetric_four_wheel_bridge'
                    b.bridge_mass_kg=bm;b.trolley_mass_kg=tm;b.hook_approach_m=approach;b.wheelbase_m=wb
                    b.transverse_kn_per_wheel=ht if hmode=='manual' else 0.;b.longitudinal_kn_per_wheel=hl if hmode=='manual' else 0.;b.transverse_pattern=pattern if hmode=='manual' else 'same_sign'
                    b.assumption_note=note;b.applied_wheel_signature=wheel_signature(wheels)
                    proposed.equipment_basis=b;proposed.demonstration=not adopt_project
                    if adopt_upper_groups:
                        proposed.equipment_group='A8';proposed.fatigue.component_group='E8_conservative'
                        b.assumption_note+=' A proposta original adota A8/E8 como limites superiores no domínio implementado, sem conversão da classe da talha nem inferência de ciclos/serviço. Os grupos atuais do projeto prevalecem após eventuais edições.'
                    if use_catalog_dynamic:proposed,_=apply_catalog_speed_dynamic(proposed,record)
                    if hmode!='manual':
                        from .crane_horizontal_reference import apply_horizontal_reference
                        base=deepcopy(proposed)
                        proposed,hdata=apply_horizontal_reference(base,hmode,dynamic_factor=hfactor)
                        st.write(f"Hipótese normal: λ = {hdata['lambda_rolling']:.4f}; translação do carro = {hdata['trolley_total_transverse_kn']:.3f} kN por caminho; binário = ±{hdata['rolling_per_wheel_kn']:.3f} kN por roda; HL = {hdata['longitudinal_per_wheel_kn']:.3f} kN por roda.")
                        st.dataframe([{'Cenário':row['id'],'HT roda 1 (kN)':row['wheels'][0].transverse_kn,'HT roda 2 (kN)':row['wheels'][1].transverse_kn,'HL por roda (kN)':row['wheels'][0].longitudinal_kn} for row in hdata['scenarios']],hide_index=True,width='stretch')
                        if not invalid:
                            package=horizontal_scenario_package(base,hfactor,st.session_state.get('auto_document_metadata',{}))
                            st.download_button('Salvar os dois cenários para cálculo separado',package,'LRO_cenarios_HT_A_B.zip','application/zip',key=_PREFIX+'scenarios_save')
                if model_error:st.caption(model_error)
                if st.button('Preparar proposta de cargas por estática',key=_PREFIX+'statics',disabled=invalid or model_error is not None):
                    _queue_preview(project,proposed,'modelo estático declarado'+(' · '+hmode if hmode!='manual' else ''))
        elif bridge_span is not None and capacity is not None and capacity>0 and bridge_span>0:
            st.info('Não há registro para esta capacidade. Ative a comparação superior ou use os dados manuais. Nenhuma reação será estimada silenciosamente.')
        with st.expander('Classificações quando faltam dados · hipótese delimitada'):
            st.write('A8 usa o maior Mx da tabela implementada. E8 adota o grupo superior para os detalhes cobertos pelo motor. Ψ = 2,22 limita superiormente a fórmula normal HC1–HC4/HD1–HD5 com velocidade efetiva limitada a 1,5 m/s. Isso não classifica fisicamente a ponte nem cobre choques, queda de carga ou qualquer evento extraordinário.')
            st.caption('Serviço, ambiente, batente, velocidades e ensaio não serão inventados. O ensaio tem método e velocidade próprios; sem adoção explícita e fonte, permanece pendente. A geometria e as cargas atuais são preservadas.')
            if st.button('Preparar hipótese A8 / E8 / Ψ 2,22',key=_PREFIX+'classify',disabled=bool(validate_autonomous(project))):
                proposed=deepcopy(project)
                proposed.equipment_group='A8';proposed.fatigue.component_group='E8_conservative'
                proposed.dynamic_psi_override=2.22;proposed.hoist_class='unselected';proposed.drive_class='unselected'
                proposed.factor_basis='Hipótese adotada: envelope da fórmula dinâmica normal NBR 8400-1, Tabelas 12/13, HC1–HC4 e vh efetivo até 1,5 m/s; Ψ = 1,20 + 0,68 × 1,5 = 2,22. Não qualifica ensaio, impactos ou classificação física.'
                proposed.equipment_basis.classification_scenario='normative_upper_bounds'
                _queue_preview(project,proposed,'hipótese normativa delimitada')
        result=_proposal_view(project)
        if result is not None:return result
        previous=st.session_state.get('auto_catalog_previous')
        if previous:
            from .autonomous_model import AutonomousProject
            cols=st.columns(2)
            with cols[0]:st.download_button('Salvar projeto anterior à última aplicação',previous.encode(),'LRO_projeto_anterior_catalogo.json','application/json',key=_PREFIX+'previous_save')
            with cols[1]:
                if st.button('Restaurar projeto anterior à última aplicação',key=_PREFIX+'undo'):
                    restored=AutonomousProject.from_json(previous)
                    st.session_state.pop('auto_catalog_previous',None)
                    st.session_state.pop(_PREFIX+'proposal',None)
                    return restored
    return None


def _render_vertical_comparator(project,record):
    from .crane_vertical_reference import vertical_catalog_screen
    from .geometry import section_properties
    candidate=deepcopy(record)
    family=record.get('source_family_pmax_static_kN')
    if candidate.get('pmax_kN') is None and family is not None:
        candidate['pmax_kN']=family
    if candidate.get('pmax_kN') is None:return
    with st.expander('Comparação rápida · efeitos verticais do registro'):
        st.caption('Não altera as cargas do cálculo completo. Usa a carga TOTAL de roda e o entre-eixos correlacionado do catálogo, no vão entre apoios da viga atual. Mostra demanda, não aprovação da viga.')
        if family is not None:st.caption('Carga estática publicada para a família de capacidade/faixa; não identificada com a opção de talha selecionada.')
        key=json.dumps([candidate['record_id'],candidate['pmax_kN'],project.span_m,project.material.E_mpa,asdict(project.section)],sort_keys=True)
        if st.button('Comparar efeitos verticais deste registro',key=_PREFIX+'vertical'):
            try:
                props=section_properties(project.section)
                result=vertical_catalog_screen(candidate,support_span_m=project.span_m,E_mpa=project.material.E_mpa,Ix_mm4=props.Ix_mm4)
                st.session_state[_PREFIX+'vertical_result']=(key,result)
            except (ValueError,ArithmeticError,ZeroDivisionError) as exc:st.error('Comparação indisponível: '+str(exc))
        saved=st.session_state.get(_PREFIX+'vertical_result')
        if saved and saved[0]==key:
            r=saved[1];d=r['vertical_crane_only_demand']
            st.write(f"Reação máxima / cortante global: {d['reaction_max_kn']:.3f} kN · Momento major máximo: {d['major_moment_max_knm']:.3f} kN·m · Limite superior de flecha: {d['vertical_deflection_upper_mm']:.3f} mm.")
            st.caption(f"Somente rodas, antes de fatores adicionais. Peso próprio da viga/trilho/enrijecedores excluído. Erro numérico limitado da flecha: {d['vertical_deflection_error_bound_mm']:.4f} mm. Sem torção, fadiga, estabilidade ou resistência local.")
            if r.get('source_pending'):st.caption(r['source_pending'])
            st.download_button('Salvar comparação vertical JSON',json.dumps(r,ensure_ascii=False,indent=2).encode(),'LRO_comparacao_vertical_catalogo.json','application/json',key=_PREFIX+'vertical_save')
        elif saved:st.caption('Referência ou viga mudou. Execute novamente a comparação.')


def _render_correlated_comparison(project,records,capacity,bridge_span):
    try:rows=correlated_vertical_comparison(records,capacity,bridge_span,project.span_m)
    except ValueError:return
    if not rows:return
    with st.expander('Comparar efeitos verticais das referências compatíveis'):
        st.caption(f'Vão entre apoios da viga: {project.span_m:g} m. Modelo estático simétrico com G+Q de cada registro completo, sem Ψ, fatores ou peso da viga/trilho. Máximos escalares não concomitantes; não cobrem H, torção, estabilidade ou fadiga.')
        st.dataframe([{'Registro correlacionado':r['record_id'],'G+Q por roda (kN)':r['static_per_wheel_kn'],
            'Entre-eixos (m)':r['wheelbase_m'],'M máximo vertical (kN.m)':r['major_moment_max_knm'],
            'Reação máxima (kN)':r['reaction_max_kn']} for r in rows],hide_index=True,width='stretch')
        max_m=max(rows,key=lambda r:r['major_moment_max_knm']);max_r=max(rows,key=lambda r:r['reaction_max_kn'])
        st.write('Maior momento nesta lista: '+max_m['record_id']+'. Maior reação: '+max_r['record_id']+'.')
        st.caption('Essas escolhas são desfavoráveis somente no indicador e conjunto comparados. Menor/maior entre-eixos ou maior massa não garantem maior efeito em todas as verificações.')
        cols=st.columns(2)
        for col,key,label,row in ((cols[0],'select_max_m','Selecionar maior momento vertical da lista',max_m),
                                 (cols[1],'select_max_r','Selecionar maior reação vertical da lista',max_r)):
            with col:
                if st.button(label,key=_PREFIX+key):st.session_state[_PREFIX+'record']=row['record_id']
