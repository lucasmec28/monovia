"""Aggregate independently checked physical regions without mixing stresses.

Every station/interface must already cover its whole load family. This helper
selects the greatest utilization for each criterion only after those local
calculations. It never combines a stress from one station with another one's
capacity, never fills missing checks, and retains unresolved domains.
"""
from __future__ import annotations
from copy import deepcopy
import math


def aggregate_station_results(rows):
    """Rows have exact keys ``station_id``, ``interface_id`` and ``result``.

    Station coverage itself belongs to the physical adapter. This function
    requires a common nonempty criterion set and preserves every result as
    evidence, including any domain errors. No mere row existence proves scope.
    """
    if not isinstance(rows,(list,tuple)) or not rows:
        raise ValueError('Não há resultados físicos de estações para agregar.')
    seen=set();expected=None;normalized=[]
    for row in rows:
        if not isinstance(row,dict) or set(row)!={'station_id','interface_id','result'}:
            raise ValueError('Registro de resultado por estação inválido.')
        sid,iid=row['station_id'],row['interface_id'];r=row['result']
        if not isinstance(sid,str) or not sid.strip() or not isinstance(iid,str) or not iid.strip():
            raise ValueError('Identificação física de estação/interface ausente.')
        if (sid,iid) in seen:raise ValueError('Estação/interface duplicada.')
        seen.add((sid,iid))
        if not isinstance(r,dict) or not isinstance(r.get('checks'),list) or not r['checks']:
            raise ValueError('Estação sem comparações numéricas de fadiga.')
        ids=[]
        for c in r['checks']:
            if not isinstance(c,dict) or not isinstance(c.get('id'),str) or not c['id']:
                raise ValueError('Identificador de comparação inválido.')
            for name in ('demand','capacity','utilization'):
                v=c.get(name)
                if isinstance(v,bool) or not isinstance(v,(int,float)) or not math.isfinite(v) or v<0:
                    raise ValueError('Comparação de estação com número inválido: '+name)
            if c['capacity']<=0 or not math.isclose(c['demand']/c['capacity'],c['utilization'],rel_tol=1e-10,abs_tol=1e-12):
                raise ValueError('Utilização de estação inconsistente.')
            ids.append(c['id'])
        if len(set(ids))!=len(ids):raise ValueError('Comparação repetida na estação.')
        if expected is None:expected=tuple(ids)
        if set(ids)!=set(expected):raise ValueError('Conjunto de critérios diferente entre estações/interfaces.')
        normalized.append(row)
    governing={}
    checks=[]
    for key in expected:
        candidates=[(next(c for c in row['result']['checks'] if c['id']==key),row) for row in normalized]
        check,row=max(candidates,key=lambda pair:pair[0]['utilization'])
        copied=deepcopy(check)
        evidence=dict(station_id=row['station_id'],interface_id=row['interface_id'])
        copied['critical_location']=evidence
        checks.append(copied);governing[key]=evidence
    # The source result with the greatest criterion supplies only common
    # metadata. Its arithmetic remains explicitly separate from other stations.
    critical=max(normalized,key=lambda row:max(c['utilization'] for c in row['result']['checks']))
    out=deepcopy(critical['result']);out['checks']=checks
    out['station_results']=deepcopy(normalized)
    out['critical_location_by_check']=governing
    out.setdefault('intermediates',{})['aggregation']='Máximo de cada critério após verificar cada estação/interface; sem cruzar componentes espaciais.'
    out['intermediates']['critical_location_by_check']=governing
    out['intermediates']['representative_input_location']=dict(station_id=critical['station_id'],interface_id=critical['interface_id'])
    out['intermediates']['representative_input_only']=True
    out['intermediates']['governing_numeric_by_check']={c['id']:{key:c[key] for key in ('demand','capacity','utilization','unit') if key in c} for c in checks}
    out['domain_pending']=[f"{row['station_id']}/{row['interface_id']}: {reason}" for row in normalized for reason in row['result'].get('domain_pending',[])]
    out['errors']=[f"{row['station_id']}/{row['interface_id']}: {reason}" for row in normalized for reason in row['result'].get('errors',[])]
    out['domain_complete']=all(row['result'].get('domain_complete') is True for row in normalized) and not out['domain_pending'] and not out['errors']
    out['criterion_exceedances']=[c['id'] for c in checks if c['utilization']>1]
    out['pending']=list(out['domain_pending'])+(['Critério conservador de alguma estação/interface excedido.'] if out['criterion_exceedances'] else [])
    out['full_compliance']=False
    return out
