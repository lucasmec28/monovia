"""Bounded runway equivalent-flange method adopted under NBR 8400-2 §5.3.

EN 1993-6:2007 6.3.2.2 provides the rail-specific vertical effective height.
Jorg et al. (2024), doi:10.1002/stco.202400010, 3.4.2 provides the flange
compression/bending model with eccentric rail forces. DIN EN 1993-1-1:2025
8.3.2.4, 8.3.1.3 and Table 8.8 provide the separately adopted resistance.
Half-web is used ONLY for buckling slenderness; resistance uses the flange
alone. This is neither a native 8400 torsion equation nor a whole-beam check.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, fields
import math
from typing import Any, get_type_hints

from .stress_8400 import NU_E, _check, elastic_allowables_8400


METHOD_SOURCE = (
    'NBR 8400-2:2019, 5.3: método prático adotado; EN 1993-6:2007 '
    '6.3.2.2; Jörg et al. 2024, 3.4.2; DIN EN 1993-1-1:2025 '
    '8.3.1.3/8.3.2.4 e Tabela 8.8'
)


@dataclass
class RunwayTorsion8400Input:
    name: str = 'Rolamento: mesa equivalente, flexão horizontal e torção'
    load_case: str = 'I'
    fy_mpa: float = 0.0
    fu_mpa: float = 0.0
    E_mpa: float = 210000.0
    depth_mm: float = 0.0
    flange_width_mm: float = 0.0
    flange_thickness_mm: float = 0.0
    web_thickness_mm: float = 0.0
    span_mm: float = 0.0
    moment_major_knm: float = 0.0
    moment_minor_knm: float = 0.0
    torsion_knm: float = 0.0
    axial_force_kn: float = 0.0
    bimoment_knm2: float = 0.0
    section_symmetry: str = 'unqualified'
    action_basis: str = 'unqualified'
    material_source: str = ''
    system_source: str = ''
    rail_source: str = ''
    action_source: str = ''
    method_source: str = ''
    section_material_qualified: bool = False
    full_span_system_qualified: bool = False
    rail_load_path_qualified: bool = False
    full_span_envelopes_qualified: bool = False
    practical_method_selected: bool = False
    high_ratio_route_confirmed: bool = False


DECLARATIONS = {
    'section_material_qualified': (
        'Qualificar I/H duplamente simétrico, reto, uniforme e compacto, aço '
        'estrutural à temperatura ambiente e dimensões/propriedades reais; '
        'sem aberturas, composição do trilho ou modo distorcional relevante.'
    ),
    'full_span_system_qualified': (
        'Qualificar o vão inteiro biapoiado com ambas as extremidades tipo '
        'garfo, contenções resistentes/rígidas, empenamento livre, momentos '
        'de extremidade nulos e mesa superior comprimida pela flexão vertical; '
        'não tomar crédito de travamentos intermediários nem de continuidade.'
    ),
    'rail_load_path_qualified': (
        'Qualificar especificamente a transferência roda-trilho e a altura '
        'vertical efetiva de EN 1993-6:2007 6.3.2.2; força horizontal permanece '
        'na altura REAL do trilho e T inclui H·z e P·e. Não rebaixar cargas '
        'elevadas genéricas, suportes ou consoles para o nível da mesa.'
    ),
    'full_span_envelopes_qualified': (
        'Qualificar máximos ABSOLUTOS de Mforte, Mfraco e T interno TOTAL '
        'no vão inteiro, para o mesmo caso I/II/III e todas as posições '
        'pertinentes, fatores incluídos uma única vez. Modelo de ações '
        'compatível com os garfos/empenamento livre e sem benefício não '
        'qualificado de travamentos. Não usar T pontual aplicado nem uma '
        'única seção do Robot como envelope.'
    ),
    'practical_method_selected': (
        'Selecionar e justificar a adaptação prática 8400: meia alma apenas '
        'na esbeltez, curva d, kc=beta_c=Cmz=1, resistência elástica só da '
        'mesa, kzz=1+0,6n e margem comum alpha. Não é fórmula nativa 8400.'
    ),
}


def _finite(value: Any) -> bool:
    if type(value) not in (int, float):
        return False
    try:
        return (math.isfinite(value) and abs(value) <= 1e12
                and (value == 0 or abs(value) >= 1e-12))
    except (OverflowError, ValueError):
        return False


def _typed_errors(data: Any) -> list[str]:
    if not isinstance(data, RunwayTorsion8400Input):
        return ['Entrada deve ser RunwayTorsion8400Input.']
    errors = []
    annotations = get_type_hints(RunwayTorsion8400Input)
    for field in fields(data):
        value, expected = getattr(data, field.name), annotations[field.name]
        if expected is float and not _finite(value):
            errors.append(f'{field.name}: número finito em unidade indicada obrigatório.')
        elif expected is str and not isinstance(value, str):
            errors.append(f'{field.name}: texto obrigatório.')
        elif expected is bool and type(value) is not bool:
            errors.append(f'{field.name}: booleano verdadeiro/falso obrigatório.')
    return errors


def compression_curve_d(lambda_bar: float) -> float:
    """EC flexural-compression curve d; not the application's FLT curve."""
    if not _finite(lambda_bar) or lambda_bar < 0:
        raise ValueError('Esbeltez relativa deve ser finita e não negativa.')
    phi = 0.5 * (1.0 + 0.76 * (lambda_bar - 0.2) + lambda_bar**2)
    discriminant = phi**2 - lambda_bar**2
    if discriminant < 0 or not math.isfinite(discriminant):
        raise ValueError('Curva d fora do domínio numérico.')
    return min(1.0, 1.0 / (phi + math.sqrt(discriminant)))


def calculate_runway_torsion_8400(data: RunwayTorsion8400Input) -> dict[str, Any]:
    result = {
        'kind': 'runway_torsion_practical_8400', 'source': METHOD_SOURCE,
        'input_valid': True, 'status': 'PENDENTE', 'full_compliance': False,
        'errors': [], 'pending': [], 'checks': [], 'intermediates': {},
        'limitations': [
            'Resultado parcial: verifica a estabilidade combinada por mesa equivalente e uma envoltória de tensão longitudinal; não aprova integralmente a viga.',
            'Método prático declarado sob 8400 5.3; não é uma equação nativa 8400 nem substituição de gamma de ELU por nu_E.',
            'Domínio: vão inteiro biapoiado, I/H uniforme duplamente simétrico compacto, garfos nas extremidades, empenamento livre e N=0; sem crédito a travamentos intermediários.',
            'Meia alma contribui apenas para a esbeltez; áreas e módulos resistentes são somente da mesa. Sem reserva plástica nem rigidez composta do trilho.',
            'A altura vertical efetiva da mesa depende da regra específica roda-trilho EN 1993-6 6.3.2.2; não vale para cargas elevadas genéricas. H permanece na altura real do trilho no cálculo de T.',
            'O limite T_max·L/(2h0) decorre de equilíbrio com momentos de empenamento nulos nas duas extremidades e desprezo conservador da rigidez Saint-Venant; T_max é envelope de torque interno total.',
            'Tensão longitudinal não inclui cisalhamento, tensões locais de roda/torção, fadiga, ligação/trilho/apoios ou deformações; essas verificações continuam independentes.',
        ],
    }
    errors = _typed_errors(data)
    if errors:
        result.update(input_valid=False, status='ENTRADA INVÁLIDA', errors=errors)
        return result
    for key in ('fy_mpa', 'fu_mpa', 'E_mpa', 'depth_mm', 'flange_width_mm',
                'flange_thickness_mm', 'web_thickness_mm', 'span_mm'):
        if getattr(data, key) <= 0:
            errors.append(f'{key}: informar valor positivo.')
    if data.depth_mm <= 2 * data.flange_thickness_mm:
        errors.append('Altura deve superar duas espessuras de mesa.')
    if data.flange_width_mm <= data.web_thickness_mm:
        errors.append('Largura de mesa deve superar a espessura da alma.')
    if data.flange_thickness_mm >= data.flange_width_mm:
        errors.append('Espessura de mesa incompatível com flange de perfil I/H.')
    if data.web_thickness_mm >= data.depth_mm - 2 * data.flange_thickness_mm:
        errors.append('Espessura de alma incompatível com sua altura livre.')
    if data.fu_mpa < data.fy_mpa:
        errors.append('fu não pode ser inferior a fy.')
    if data.load_case not in NU_E:
        errors.append('Caso deve ser I, II ou III.')
    for key in ('moment_major_knm', 'moment_minor_knm', 'torsion_knm'):
        if getattr(data, key) < 0:
            errors.append(f'{key}: fornecer máximo absoluto não negativo no vão inteiro.')
    if errors:
        result.update(input_valid=False, status='ENTRADA INVÁLIDA', errors=errors)
        return result
    result['input'] = asdict(data)
    if (data.section_symmetry != 'doubly_symmetric_i' or data.axial_force_kn != 0
            or data.bimoment_knm2 != 0 or data.moment_major_knm <= 0):
        result['status'] = 'FORA DO DOMÍNIO'
        result['pending'].append('Exige I/H duplamente simétrico, N=0, sem bimomento imposto independente e flexão vertical que comprima a mesa superior. Não zerar efeitos existentes.')
        return result
    if data.action_basis != 'nbr8400_cases':
        result['pending'].append('Exige ações próprias dos casos I/II/III; esforços ELU 8800 não são convertidos.')
    for key, explanation in {
        'material_source': 'Identificar material, compacidade e geometria da seção.',
        'system_source': 'Identificar vão, modelo, condições reais e qualificação dos dois apoios.',
        'rail_source': 'Identificar o arranjo roda-trilho, regra de altura efetiva e excentricidades reais.',
        'action_source': 'Identificar modelo/barra/caso, envoltórias completas e fatores já incluídos.',
        'method_source': 'Registrar adoção e justificativa da presente adaptação prática.',
    }.items():
        if not getattr(data, key).strip():
            result['pending'].append(explanation)
    for key, explanation in DECLARATIONS.items():
        if not getattr(data, key):
            result['pending'].append(explanation)
    if data.fy_mpa / data.fu_mpa > .70 and not data.high_ratio_route_confirmed:
        result['pending'].append('Qualificar ramo 8400 5.2.1.1.2 e aço de referência 360/510 MPa.')
    try:
        allow = elastic_allowables_8400(data.fy_mpa, data.fu_mpa, data.load_case)
    except ValueError as exc:
        result['status'] = 'FORA DO DOMÍNIO'
        result['pending'].append(str(exc))
        return result
    if result['pending']:
        return result
    try:
        b, tf, tw = data.flange_width_mm, data.flange_thickness_mm, data.web_thickness_mm
        hw, h0 = data.depth_mm - 2 * tf, data.depth_mm - tf
        af, aw = b * tf, hw * tw
        i_f = tf * b**3 / 12
        a_c = af + .5 * aw
        i_c = i_f + .5 * hw * tw**3 / 12
        w_f = tf * b**2 / 6
        n_cr = math.pi**2 * data.E_mpa * i_c / data.span_mm**2
        slender = math.sqrt(a_c * data.fy_mpa / n_cr)
        chi = compression_curve_d(slender)
        alpha = min(1 / allow['nu_e'], allow['sigma_a_mpa'] / data.fy_mpa)
        n_f = data.moment_major_knm * 1e6 / h0
        m_t = data.torsion_knm * data.span_mm / (2 * h0)
        m_f = data.moment_minor_knm / 2 + m_t
        c_n = alpha * chi * data.fy_mpa * af
        c_m = alpha * data.fy_mpa * w_f / 1e6
        n, m = n_f / c_n, m_f / c_m
        kzz = 1 + .6 * n
        utilization = n + kzz * m
        sigma_long = n_f / af + m_f * 1e6 / w_f
        critical_values = (hw, h0, af, aw, i_f, a_c, i_c, w_f, n_cr, slender,
                           chi, alpha, n_f, c_n, c_m)
        if not all(math.isfinite(v) and v > 0 for v in critical_values):
            raise ValueError('Propriedade/capacidade derivada não finita ou não positiva.')
        if not all(math.isfinite(v) and v >= 0 for v in (m_t, m_f, n, m, kzz, utilization, sigma_long)):
            raise ValueError('Solicitação/interação derivada fora do domínio numérico.')
    except (OverflowError, ZeroDivisionError, ValueError) as exc:
        result.update(input_valid=False, status='ENTRADA INVÁLIDA', errors=[str(exc)])
        return result
    result['intermediates'] = {
        'hw_mm': hw, 'h0_mm': h0, 'Af_mm2': af, 'Aw_mm2': aw,
        'Ac_mm2': a_c, 'If_mm4': i_f, 'Ic_mm4': i_c, 'Wf_mm3': w_f,
        'web_fraction_slenderness': .5, 'web_fraction_resistance': 0.0,
        'effective_length_mm': data.span_mm, 'radius_c_mm': math.sqrt(i_c / a_c),
        'Ncr_kn': n_cr / 1e3, 'lambda_c': slender, 'chi_c': chi, 'omega_c': 1 / chi,
        'imperfection_alpha': .76, 'kc': 1.0, 'beta_c': 1.0, 'Cmz': 1.0,
        'alpha_common': alpha, 'nu_e': allow['nu_e'], 'sigma_a_mpa': allow['sigma_a_mpa'],
        'N_flange_kn': n_f / 1e3, 'M_torsion_flange_bound_knm': m_t,
        'M_flange_bound_knm': m_f, 'compression_capacity_kn': c_n / 1e3,
        'flange_moment_capacity_knm': c_m, 'n': n, 'm': m, 'kzz': kzz,
        'interaction': utilization, 'longitudinal_stress_envelope_mpa': sigma_long,
        'stress_reference': 'Envoltória conservadora para ambas as mesas; cisalhamento e efeitos locais separados.',
        'allowable_material_basis': allow,
    }
    stability = _check(
        'runway_flange_stability', 'Estabilidade combinada da mesa equivalente', utilization, 1.0,
        'Nf=Mforte/h0; Mf<=Mfraco/2+Tmax*L/(2h0); n=Nf/(alpha*chi*fy*Af); '
        'm=Mf/(alpha*fy*Wf); U=n+(1+0,6n)*m<=1',
        '5.3; método prático declarado: meia alma só na esbeltez, curva d e interação EC3',
    )
    stability['unit'] = 'adimensional'
    stability['source'] = METHOD_SOURCE
    stress = _check(
        'runway_flange_longitudinal_stress', 'Envoltória longitudinal conservadora das mesas',
        sigma_long, allow['sigma_a_mpa'],
        'sigma_long<=Nf/Af+Mf/Wf<=sigma_a,8400; não inclui cisalhamento/efeitos locais',
        '5.2.1.1; ações por modelo prático de mesas declarado em 5.3',
    )
    result['checks'] = [stability, stress]
    result['status'] = ('RESULTADO PARCIAL — NÃO ATENDE'
                        if any(c['status'] == 'NÃO ATENDE' for c in result['checks'])
                        else 'RESULTADO PARCIAL')
    return result
