"""Independent Robot/external-stress local route, never a top-running project.

Unknown actual project data are null, not demonstration geometry. All forces
are individual wheel actions at their declared combination stage, in kN.
"""
from dataclasses import dataclass,field,asdict,fields
import hashlib,json,math
from .document_metadata import validate_document_metadata,validate_xml_text

FORMAT='LRO_UNDERSLUNG_LOCAL'


def empty_global_points():
    return [dict(point=point,face=face,sigma_x_mpa=None,sigma_y_mpa=None,tau_mpa=None)
            for point in range(3) for face in ('bottom','top')]

@dataclass
class ExternalLocalState:
    name:str='Estado 1'
    combination_id:str=''
    action_basis:str='unselected'
    nbr_case:str='I'
    action_source:str=''
    factors_source:str=''
    factors_already_applied:bool=False
    action_case_qualified:bool=False
    section_x_m:float|None=None
    wheel_translation_m:float|None=None
    coordinate_source:str=''
    outstand_side:str='unselected'
    wheel_actions_kn:list=field(default_factory=lambda:[None])
    longitudinal_spacings_mm:list=field(default_factory=list)
    nearest_longitudinal_spacing_mm:float|None=None
    isolated_station_confirmed:bool=False
    equal_opposite_wheels_confirmed:bool=False
    distance_to_physical_end_mm:float|None=None
    global_source:str=''
    global_input_mode:str='point_states'
    global_component_bounds:dict=field(default_factory=lambda:{k:[None,None] for k in ('sigma_x_mpa','sigma_y_mpa','tau_mpa')})
    envelope_coverage_confirmed:bool=False
    envelope_load_geometry_confirmed:bool=False
    envelope_scope_source:str=''
    cluster_component_envelope_adopted:bool=False
    same_state_confirmed:bool=False
    global_effects_complete:bool=False
    global_points:list=field(default_factory=empty_global_points)
    en_gamma_mser:float|None=None
    en_gamma_source:str=''

@dataclass
class UnderslungLocalProject:
    equipment_kind:str='underslung_bridge'
    capacity_tf:float|None=None
    bottom_b_mm:float|None=None
    bottom_tf_mm:float|None=None
    web_tw_mm:float|None=None
    edge_to_contact_n_mm:float|None=None
    construction:str='unselected'
    root_radius_mm:float|None=None
    weld_throat_mm:float|None=None
    straight_parallel_i_confirmed:bool=False
    fy_mpa:float|None=None
    fu_mpa:float|None=None
    material_source:str=''
    supplemental_model_adopted:bool=False
    plane_stress_nominal_confirmed:bool=False
    base_material_points_confirmed:bool=False
    high_ratio_route_confirmed:bool=False
    equipment_source:str=''
    suspension_description:str=''
    notes:str=''
    states:list[ExternalLocalState]=field(default_factory=lambda:[ExternalLocalState()])

    def to_dict(self):return asdict(self)
    def signature(self):
        return hashlib.sha256(json.dumps(self.to_dict(),sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()


def _number(value,label,*,positive=False,nonnegative=False,nullable=True):
    if value is None and nullable:return
    if isinstance(value,bool) or not isinstance(value,(int,float)) or abs(value)>1e12 or not math.isfinite(value):raise ValueError(label+': número finito obrigatório.')
    if positive and value<=0 or nonnegative and value<0:raise ValueError(label+': valor fora do domínio.')


def validate_project(p):
    if not isinstance(p,UnderslungLocalProject):raise ValueError('Tipo de projeto local suspenso inválido.')
    if p.equipment_kind!='underslung_bridge':raise ValueError('Esta rota é exclusiva da ponte suspensa com roda na mesa inferior.')
    if p.construction not in ('unselected','rolled','welded'):raise ValueError('Fabricação inválida.')
    for name in ('capacity_tf','bottom_b_mm','bottom_tf_mm','web_tw_mm','edge_to_contact_n_mm','fy_mpa','fu_mpa'):_number(getattr(p,name),name,positive=True)
    for name in ('root_radius_mm','weld_throat_mm'):_number(getattr(p,name),name,nonnegative=True)
    for name in ('material_source','equipment_source','suspension_description','notes'):
        validate_xml_text(getattr(p,name),name)
    for name in ('straight_parallel_i_confirmed','supplemental_model_adopted','plane_stress_nominal_confirmed','base_material_points_confirmed','high_ratio_route_confirmed'):
        if type(getattr(p,name)) is not bool:raise ValueError('Confirmação inválida: '+name)
    if not isinstance(p.states,list) or not 1<=len(p.states)<=100:raise ValueError('Informe de 1 a 100 estados concomitantes.')
    names=[]
    for s in p.states:
        if not isinstance(s,ExternalLocalState):raise ValueError('Estado externo inválido.')
        for name in ('name','combination_id','action_source','global_source','en_gamma_source','factors_source','coordinate_source','envelope_scope_source'):
            validate_xml_text(getattr(s,name),name)
        if not s.name.strip() or s.name in names:raise ValueError('Nome de estado vazio ou repetido.')
        names.append(s.name)
        if s.action_basis not in ('unselected','mechanical','nbr8400','en_service'):raise ValueError('Base de ações externa inválida.')
        if s.global_input_mode not in ('point_states','section_envelope'):raise ValueError('Modo de tensões globais inválido.')
        if not isinstance(s.global_component_bounds,dict) or set(s.global_component_bounds)!={'sigma_x_mpa','sigma_y_mpa','tau_mpa'}:raise ValueError('Componentes do envelope global ausentes ou desconhecidas.')
        for component,bounds in s.global_component_bounds.items():
            if not isinstance(bounds,list) or len(bounds)!=2:raise ValueError('Intervalo global deve conter mínimo e máximo assinados.')
            for v in bounds:_number(v,component)
            if all(v is not None for v in bounds) and bounds[0]>bounds[1]:raise ValueError('Mínimo global maior que máximo.')
        if s.outstand_side not in ('unselected','left','right'):raise ValueError('Lado físico do balanço da mesa inválido.')
        if s.nbr_case not in ('I','II','III'):raise ValueError('Caso NBR 8400 inválido.')
        for name in ('isolated_station_confirmed','equal_opposite_wheels_confirmed','same_state_confirmed','global_effects_complete','factors_already_applied','action_case_qualified','envelope_coverage_confirmed','envelope_load_geometry_confirmed','cluster_component_envelope_adopted'):
            if type(getattr(s,name)) is not bool:raise ValueError(name+': confirmação booleana obrigatória.')
        if not isinstance(s.wheel_actions_kn,list) or not 1<=len(s.wheel_actions_kn)<=20:raise ValueError('Quantidade de rodas individuais inválida.')
        for v in s.wheel_actions_kn:_number(v,'Ação por roda',nonnegative=True)
        if not isinstance(s.longitudinal_spacings_mm,list) or len(s.longitudinal_spacings_mm)!=len(s.wheel_actions_kn)-1:raise ValueError('Espaçamentos devem corresponder às rodas consecutivas do mesmo lado.')
        for v in s.longitudinal_spacings_mm:_number(v,'Espaçamento longitudinal',positive=True)
        _number(s.nearest_longitudinal_spacing_mm,'Espaçamento mais próximo',positive=True)
        _number(s.distance_to_physical_end_mm,'Distância à extremidade física',nonnegative=True)
        _number(s.en_gamma_mser,'Gamma EN serviço',positive=True)
        _number(s.section_x_m,'Seção física')
        _number(s.wheel_translation_m,'Posição longitudinal do trem')
        if not isinstance(s.global_points,list) or len(s.global_points)!=6:raise ValueError('São necessários os pontos 0, 1 e 2 nas duas faces da mesa.')
        seen=set()
        for row in s.global_points:
            if not isinstance(row,dict) or set(row)!={'point','face','sigma_x_mpa','sigma_y_mpa','tau_mpa'}:raise ValueError('Registro de tensão global inválido.')
            key=(row['point'],row['face'])
            if type(row['point']) is not int or row['point'] not in (0,1,2) or row['face'] not in ('bottom','top') or key in seen:raise ValueError('Ponto/face global ausente, repetido ou inválido.')
            seen.add(key)
            for name in ('sigma_x_mpa','sigma_y_mpa','tau_mpa'):_number(row[name],name)
    return p


def project_document(project,document_metadata=None):
    validate_project(project)
    return dict(format=FORMAT,version=1,inputs=project.to_dict(),document_metadata=validate_document_metadata(document_metadata or {}))


def load_project(text):
    def unique_pairs(pairs):
        output={}
        for key,value in pairs:
            if key in output:raise ValueError('Chave JSON repetida: '+key)
            output[key]=value
        return output
    raw=json.loads(text,object_pairs_hook=unique_pairs)
    if not isinstance(raw,dict) or set(raw)!={'format','version','inputs','document_metadata'} or raw.get('format')!=FORMAT or type(raw.get('version')) is not int or raw['version']!=1:
        raise ValueError('Use um JSON da rota local de ponte suspensa; projeto de ponte apoiada não é convertido automaticamente.')
    data=raw['inputs']
    if not isinstance(data,dict) or set(data)!={f.name for f in fields(UnderslungLocalProject)}:raise ValueError('Campos do projeto local ausentes ou desconhecidos.')
    if not isinstance(data['states'],list):raise ValueError('Lista de estados externos obrigatória.')
    states=[]
    for row in data['states']:
        if not isinstance(row,dict) or set(row)!={f.name for f in fields(ExternalLocalState)}:raise ValueError('Estado externo truncado ou com campos desconhecidos.')
        states.append(ExternalLocalState(**row))
    p=UnderslungLocalProject(**{**data,'states':states})
    return validate_project(p),validate_document_metadata(raw['document_metadata'])
