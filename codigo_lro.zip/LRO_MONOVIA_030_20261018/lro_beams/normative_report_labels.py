"""Portuguese presentation maps for the separate 10084/8400 report routes.

These maps change presentation only. They never alter input keys, action bases,
calculation values, source citations or normative applicability.
"""
import re

LABELS = {
    # General report/audit schema.
    "name": "Identificação", "title": "Verificação", "kind": "Rota de cálculo",
    "id": "Identificador do cálculo", "status": "Situação", "input_valid": "Entradas válidas",
    "approval": "Aprovação integral", "full_compliance": "Conformidade integral",
    "local_effects_complete": "Parcelas locais implementadas calculadas",
    "implemented_checks_complete": "Verificações implementadas preenchidas",
    "input": "Entradas", "inputs": "Valores utilizados", "intermediates": "Valores intermediários",
    "values": "Valores calculados", "stresses": "Tensões calculadas", "checks": "Verificações",
    "audit": "Desenvolvimento do cálculo", "errors": "Erros de entrada", "pending": "Pendências",
    "limitations": "Limites de aplicação", "message": "Descrição", "detail": "Detalhamento",
    "description": "Descrição", "equation": "Expressão", "formula": "Expressão",
    "value": "Resultado", "unit": "Unidade", "units": "Unidades",
    "source": "Referência", "sources": "Referências", "standard": "Norma",
    "clause": "Item normativo", "printed_pages": "Páginas impressas", "pdf_pages": "Páginas do arquivo PDF",
    "demand": "Solicitação", "capacity": "Limite", "utilization": "Índice de utilização",
    "sign_convention": "Convenção de sinais", "method": "Método de cálculo",
    "length": "Comprimento", "force": "Força", "inertia": "Inércia", "stress": "Tensão",
    "global": "Efeitos globais", "compression": "Compressão local", "shear": "Cisalhamento local",
    "torsion": "Torção local", "combined": "Compressão local combinada", "service": "Deformações em serviço",
    # Explicit independent action bases and traceability.
    "case": "Caso de solicitação", "load_case": "Caso de solicitação",
    "load_basis": "Base da carga por roda", "action_basis": "Base das ações",
    "action_source": "Origem das ações do caso", "actions_source": "Origem das ações do caso",
    "factors_source": "Origem e tratamento dos fatores de ação",
    "actions_ready_for_case": "Cargas qualificadas para o caso informado",
    "factors_already_applied": "Fatores aplicados uma única vez",
    "action_case_qualified": "Enquadramento do caso confirmado",
    "additional_load_multiplier": "Multiplicador adicional de carga",
    "point_id": "Ponto material e eixos", "stress_source": "Origem das tensões",
    "material_source": "Fonte do material e certificado", "section_source": "Fonte da geometria da seção",
    # 8400 elastic material inputs and intermediate quantities.
    "fy_mpa": "Resistência ao escoamento fy (MPa)", "fu_mpa": "Resistência à ruptura fu (MPa)",
    "thickness_mm": "Espessura avaliada (mm)", "material_grade": "Especificação do aço",
    "sigma_x_mpa": "Tensão normal σx (MPa)", "sigma_y_mpa": "Tensão normal σy (MPa)",
    "tau_xy_mpa": "Tensão de cisalhamento τxy (MPa)",
    "same_point_concurrent": "Tensões concomitantes no mesmo ponto",
    "plane_stress_confirmed": "Estado plano de tensões confirmado",
    "base_material_confirmed": "Verificação no material base confirmada",
    "high_ratio_route_confirmed": "Ramo fy/fu > 0,70 qualificado",
    "fy_fu_ratio": "Relação fy/fu", "nu_e": "Coeficiente de segurança νE",
    "sigma_a_mpa": "Tensão normal admissível σa (MPa)", "tau_a_mpa": "Cisalhamento admissível τa (MPa)",
    "reference_sigma_a_mpa": "Tensão admissível do aço de referência (MPa)",
    "sigma_eq_mpa": "Tensão equivalente σeq (MPa)",
    "sigma_x_signed_mpa": "Tensão normal σx com sinal (MPa)",
    "sigma_y_signed_mpa": "Tensão normal σy com sinal (MPa)",
    "tau_xy_signed_mpa": "Cisalhamento τxy com sinal (MPa)",
    # 8400 fatigue history, construction and qualification.
    "group": "Grupo do componente", "group_source": "Fonte da classificação do componente",
    "detail_code": "Referência do detalhe construtivo", "detail_source": "Fonte da correspondência do detalhe",
    "load_direction": "Direção da tensão no detalhe", "direction": "Direção da tensão",
    "weld_quality": "Qualidade da solda", "stress_kind": "Componente de tensão",
    "stress_a_mpa": "Primeiro extremo do histórico (MPa)", "stress_b_mpa": "Segundo extremo do histórico (MPa)",
    "evaluation_location": "Região do material avaliada",
    "same_point_history_confirmed": "Extremos do mesmo ponto e histórico confirmados",
    "group_classification_confirmed": "Grupo por vida e espectro confirmado",
    "construction_detail_confirmed": "Geometria e direção do detalhe confirmadas",
    "fabrication_quality_confirmed": "Qualidade de fabricação e inspeção confirmada",
    "single_component_confirmed": "Uma única componente relevante confirmada",
    "case_i_no_Mx_confirmed": "Caso I sem coeficiente de majoração Mx confirmado",
    "buckling_factor_excluded": "Coeficiente de flambagem excluído do histórico",
    "local_effects_included": "Efeitos locais aplicáveis incluídos no histórico",
    "sigma_max_signed_mpa": "Extremo de maior módulo com sinal (MPa)",
    "sigma_min_signed_mpa": "Outro extremo com sinal (MPa)",
    "absolute_max_mpa": "Maior módulo da tensão (MPa)", "kappa": "Razão algébrica κ",
    "stress_range_mpa": "Variação entre extremos (MPa)", "predominance": "Sinal do extremo de maior módulo",
    "sigma_w_mpa": "Tensão de referência σw (MPa)", "category": "Categoria construtiva",
    "construction_category": "Categoria construtiva", "detail_description": "Descrição do detalhe",
    "detail_reference": "Referência normativa do detalhe",
    "fatigue_raw_capacity_mpa": "Limite de fadiga antes dos tetos (MPa)",
    "rupture_cap_normal_mpa": "Teto normal 0,75fu (MPa)",
    "elastic_case_i_sigma_a_mpa": "Tensão normal admissível do caso I (MPa)",
    "elastic_case_i_tau_a_mpa": "Cisalhamento admissível do caso I (MPa)",
    "final_capacity_mpa": "Limite governante da componente (MPa)",
    "safety_factor_already_in_table": "Coeficiente de segurança já incluído na tabela",
    # 10084 beam and rail geometry.
    "top_running": "Rolamento sobre a mesa superior", "section_kind": "Tipo de seção",
    "d_mm": "Altura total d (mm)", "bf_mm": "Largura da mesa superior bf (mm)",
    "tf_mm": "Espessura da mesa superior tf (mm)", "tw_mm": "Espessura da alma tw (mm)",
    "bottom_bf_mm": "Largura inferior informada (mm)", "bottom_tf_mm": "Espessura inferior informada (mm)",
    "beam_length_mm": "Comprimento da viga (mm)", "hw_mm": "Altura da alma hw (mm)",
    "interior_region_confirmed": "Região interna afastada dos apoios confirmada",
    "z_mm": "Profundidade na alma z (mm)", "rail_attachment": "Fixação do trilho",
    "rail_bfr_mm": "Largura do patim bfr (mm)", "rail_hr_mm": "Altura do trilho hr (mm)",
    "rail_ir_mm4": "Inércia própria do trilho Ir (mm⁴)", "rail_area_mm2": "Área do trilho (mm²)",
    "rail_centroid_from_base_mm": "Centroide do trilho desde a base (mm)",
    "rail_properties_source": "Fonte das propriedades do trilho",
    "rail_offset_from_web_mm": "Descentramento do trilho em relação à alma (mm)",
    "rigid_fixing_verified": "Fixação rígida trilho-mesa verificada",
    "rail_and_flange_same_modulus": "Mesmo módulo de elasticidade do trilho e mesa confirmado",
    "pad_thickness_mm": "Espessura da manta (mm)",
    "pad_is_resilient_elastomer": "Manta de elastômero resiliente confirmada",
    "wheel_guidance": "Guiamento da roda", "wheel_rail_clearance_fw_mm": "Folga roda-trilho fw (mm)",
    "rail_head_width_br_mm": "Largura da cabeça do trilho br (mm)",
    "eccentricity_source": "Fonte do guiamento e da excentricidade",
    "transverse_stiffeners_welded_to_web": "Enrijecedores transversais soldados à alma",
    "stiffener_spacing_a_mm": "Espaçamento de enrijecedores a (mm)",
    "top_assembly_it_mm4": "Constante torsional da parcela superior It (mm⁴)",
    "torsion_it_scope": "Parcela considerada em It", "torsion_it_source": "Fonte e método da constante It",
    "wheels": "Rodas", "x_mm": "Posição longitudinal x (mm)", "fz_kn": "Carga vertical Fz (kN)",
    # Effective strip and composite properties, including audit operands.
    "bef_mm": "Largura efetiva da mesa bef (mm)", "ifef_mm4": "Inércia da mesa efetiva If,ef (mm⁴)",
    "irf_mm4": "Inércia combinada trilho-mesa Irf (mm⁴)",
    "composite_centroid_above_flange_bottom_mm": "Centroide combinado desde a face inferior da mesa (mm)",
    "lef_mm": "Comprimento efetivo lef (mm)",
    "dispersion_length_at_z_mm": "Comprimento de dispersão em z (mm)",
    "depth_reduction": "Fator de redução em profundidade",
    "table_1_coefficient": "Coeficiente da Tabela 1", "coefficient": "Coeficiente C da Tabela 1",
    "effective_inertia_mm4": "Inércia adotada na dispersão (mm⁴)",
    "bfr_mm": "Largura do patim bfr (mm)", "hr_mm": "Altura do trilho hr (mm)",
    "ir_mm4": "Inércia própria do trilho Ir (mm⁴)", "ar_mm2": "Área do trilho Ar (mm²)",
    "af_mm2": "Área efetiva da mesa Af (mm²)",
    "yr_mm": "Centroide do trilho desde a face inferior da mesa (mm)",
    "yf_mm": "Centroide da mesa desde sua face inferior (mm)",
    "ybar_mm": "Centroide combinado desde a face inferior da mesa (mm)",
    "length_z_mm": "Comprimento de dispersão lef + 2z (mm)",
    # Local stress magnitudes and explicitly signed quantities.
    "sigma0z_top_mpa": "Compressão local σ0z no topo (MPa)",
    "sigma0z_at_z_mpa": "Compressão local σ0z em z (MPa)",
    "sigma0z_top_signed_mpa": "Tensão local σ0z no topo com sinal (MPa)",
    "sigma0z_at_z_signed_mpa": "Tensão local σ0z em z com sinal (MPa)",
    "sigma0z_top_max_mpa": "Máxima compressão local σ0z no topo (MPa)",
    "sigma0z_at_z_max_mpa": "Máxima compressão local σ0z em z (MPa)",
    "tau0xz_top_max_abs_mpa": "Máximo cisalhamento local |τ0xz| no topo (MPa)",
    "tau0xz_at_z_max_abs_mpa": "Máximo cisalhamento local |τ0xz| em z (MPa)",
    "tau0xz_at_z_candidates_mpa": "Extremos locais ±τ0xz em z (MPa)",
    "shear_spatial_basis": "Posição e sinais do cisalhamento local",
    "sigmaT_mpa": "Flexão local por torção σT (MPa)",
    "sigma_cz_isolated_mpa": "Compressão combinada σcz por roda isolada (MPa)",
    "sigma_cz_isolated_signed_mpa": "Tensão combinada σcz por roda isolada com sinal (MPa)",
    "sigma_cz_top_mpa": "Compressão combinada σcz no topo (MPa)",
    "sigma_cz_top_signed_mpa": "Tensão combinada σcz no topo com sinal (MPa)",
    "combined_scope": "Domínio da combinação local",
    "vertical_top_envelope": "Envoltória da compressão no topo",
    "vertical_at_z_envelope": "Envoltória da compressão em z",
    "maximum_mpa": "Tensão máxima (MPa)", "overlap_present": "Sobreposição de rodas presente",
    "critical_interval_x_mm": "Intervalo longitudinal crítico (mm)",
    "contributing_wheel_indices": "Índices internos das rodas participantes",
    "contributing_wheels": "Rodas participantes",
    "individual_mpa": "Parcelas de tensão por roda (MPa)", "wheel_x_mm": "Posições das rodas (mm)",
    "active_indices": "Índices internos das rodas ativas", "interval_x_mm": "Intervalo longitudinal (mm)",
    # Local torsion parameters and audit operands.
    "ey_mm": "Excentricidade de cálculo ey (mm)", "fw_mm": "Folga roda-trilho fw (mm)",
    "br_mm": "Largura da cabeça do trilho br (mm)", "a_mm": "Espaçamento de enrijecedores a (mm)",
    "it_mm4": "Constante torsional da parcela superior It (mm⁴)",
    "u_pi_hw_over_a": "Parâmetro u = πhw/a", "u": "Parâmetro u = πhw/a",
    "hyperbolic_ratio": "Razão hiperbólica da expressão de η", "eta": "Parâmetro η",
    "tanh_eta": "Tangente hiperbólica de η", "torque_nmm": "Momento torsor local T (N.mm)",
    # 10084 service geometry, reference state and limits.
    "span_mm": "Vão entre apoios L (mm)", "span_source": "Fonte do vão e dos apoios",
    "span_between_supports_confirmed": "Vão entre apoios da viga confirmado",
    "equipment_use": "Aplicação do equipamento",
    "vertical_displacement_mm": "Flecha vertical no topo do trilho (mm)",
    "horizontal_displacement_mm": "Flecha horizontal no topo do trilho (mm)",
    "impact_excluded": "Impacto excluído dos deslocamentos",
    "majoration_excluded": "Majoração excluída dos deslocamentos",
    "reference_self_weight_only": "Referência sob apenas peso próprio da estrutura-suporte",
    "measured_at_rail_top": "Medição no topo do trilho confirmada",
    "vertical_ratio": "Divisor do limite vertical L/n", "horizontal_ratio": "Divisor do limite horizontal L/n",
    "vertical_absolute_cap_mm": "Limite vertical absoluto (mm)",
    "vertical_limit_mm": "Limite vertical governante (mm)",
    "horizontal_limit_mm": "Limite horizontal governante (mm)",
    "signed_displacement_mm": "Deslocamento com sinal (mm)",
}

ENUMS = {
    "unqualified": "Não qualificado",
    "nbr8400_cases": "Casos I, II ou III da rota NBR 10084/8400",
    "nbr8400_fatigue_case_i_no_Mx": "Histórico do caso I, sem coeficiente de majoração Mx",
    "nbr10084_case_design": "Carga de projeto do caso NBR 10084, com fatores já aplicados",
    "elastic_8400": "Tensões admissíveis NBR 8400-2", "fatigue_8400": "Fadiga NBR 8400-2",
    "symmetric_i": "Seção I duplamente simétrica", "monosymmetric_i": "Seção I com mesas desiguais",
    "rigid": "Trilho com fixação rígida qualificada", "non_rigid": "Trilho sem fixação rígida",
    "resilient_pad": "Trilho sobre manta de elastômero resiliente",
    "flanged": "Roda com flange", "guide_roller_unguided_side": "Roletes-guia, lado não guiado",
    "guide_roller_guided_side": "Roletes-guia, lado guiado (não implementado)",
    "flange_only": "Somente mesa superior", "flange_plus_rigid_rail": "Mesa superior e trilho rigidamente fixado",
    "steelworks": "Equipamento siderúrgico", "other": "Demais equipamentos",
    "normal": "Tensão normal", "shear": "Cisalhamento", "compression": "Compressão", "tension": "Tração", "zero": "Nulo",
    "base_material": "Material base", "unnotched": "Material sem entalhe",
    "parallel_to_weld": "Tensão paralela à solda",
    "perpendicular_to_weld_in_web_plane": "Tensão perpendicular à solda no plano da alma",
    "not_applicable": "Não aplicável conforme justificativa", "QC": "Qualidade Q.C.",
    "W0": "W0", "K0_31": "K0,31", "K4_41": "K4,41",
    "mm2": "mm²", "mm4": "mm⁴", "mm6": "mm⁶",
    "torsion": "Torção local", "combined": "Compressão local combinada", "service": "Deformações em serviço",
    "load_basis": "Base das ações do caso", "global": "Efeitos globais",
    # Fixed audit expression descriptions; numerical terms are unchanged.
    "min(bfr + hr + tf, bf)": "min(bfr + hr + tf; bf)",
    "bef * tf^3 / 12 (rectangular effective flange, centroidal horizontal axis)": "bef · tf³ / 12; mesa efetiva retangular, eixo horizontal pelo centroide",
    "Ir + Ar*(yr-ybar)^2 + Ifef + Af*(yf-ybar)^2; ybar=sum(A*y)/sum(A)": "Ir + Ar·(yr-ȳ)² + If,ef + Af·(yf-ȳ)²; ȳ = Σ(A·y)/ΣA",
    "coefficient * (effective_inertia / tw)^(1/3)": "C · (Ief / tw)^(1/3)",
    "(1-z/hw)^2; interior region only": "(1-z/hw)²; somente região afastada dos apoios",
    "0.2*sigma0z_top if z <= 0.2*hw else 0": "0,2·σ0z,topo para z ≤ 0,2hw; zero para z > 0,2hw",
    "sum individual uniform pressures at same longitudinal interval; max over intervals": "Soma das pressões uniformes no mesmo intervalo longitudinal; máximo entre os intervalos",
    "sum individual dispersed/reduced pressures at same longitudinal interval; max over intervals": "Soma das pressões dispersas e reduzidas no mesmo intervalo; máximo entre os intervalos",
    "0.5*fw (flanged wheel)": "0,5·fw; roda com flange",
    "0.25*br (guide roller, unguided side only)": "0,25·br; rolete-guia, somente lado não guiado",
    "sigma0z_top + 0.75*sigmaT (isolated wheel)": "σ0z,topo + 0,75·σT; roda isolada",
}

CHECK_TITLES = {
    "input": "Validação das entradas", "scope": "Domínio geométrico e normativo",
    "depth": "Profundidade de avaliação na alma", "actions": "Qualificação das ações do caso",
    "dispersion_limits": "Limites da dispersão longitudinal",
    "local_vertical": "Compressão local na alma",
    "local_shear": "Cisalhamento local na alma",
    "local_web_bending_torsion": "Flexão local da alma por torção da mesa",
    "combined_local_compression": "Compressão local combinada na alma",
    "service_10084_vertical": "Flecha vertical no topo do trilho",
    "service_10084_horizontal": "Flecha horizontal no topo do trilho",
    "sigma_x": "Tensão normal x", "sigma_y": "Tensão normal y", "tau_xy": "Cisalhamento xy",
    "equivalent": "Tensão equivalente concomitante", "fatigue_component": "Fadiga da componente no ponto",
}

_AUDIT_TITLES = {
    "bef": "Largura efetiva da mesa", "ifef": "Inércia da mesa efetiva",
    "irf": "Inércia combinada do trilho e da mesa", "effective_inertia": "Inércia utilizada na dispersão",
    "lef": "Comprimento efetivo", "dispersion": "Dispersão na profundidade avaliada",
    "depth_reduction": "Redução da compressão em profundidade", "eccentricity": "Excentricidade da roda",
    "eta": "Parâmetro de torção η", "wheel_superposition_top": "Superposição de rodas no topo da alma",
    "wheel_superposition_depth": "Superposição de rodas na profundidade avaliada",
    "vertical": "Limite da flecha vertical", "horizontal": "Limite da flecha horizontal",
}
_WHEEL_STEP_TITLES = {
    "compression_top": "Compressão no topo da alma", "compression_depth": "Compressão na profundidade avaliada",
    "shear": "Cisalhamento local", "torque": "Momento torsor local", "sigmaT": "Flexão local por torção",
    "sigma_cz_isolated": "Compressão combinada isolada",
}


def audit_title(identifier: str) -> str:
    """Optional human-readable title for any wheel-indexed audit step.

    The original identifier stays in the reproducible JSON. Display numbering
    starts at 1; this helper imposes no limit on the number of wheel records.
    """
    if identifier in _AUDIT_TITLES:
        return _AUDIT_TITLES[identifier]
    match = re.fullmatch(r"wheel_(\d+)_(.+)", str(identifier))
    if match and match.group(2) in _WHEEL_STEP_TITLES:
        return f"{_WHEEL_STEP_TITLES[match.group(2)]} da roda {int(match.group(1)) + 1}"
    return CHECK_TITLES.get(identifier, LABELS.get(identifier, str(identifier).replace("_", " ")))

LABELS.update({
 'panel_length_mm':'Distância entre apoios transversais a (mm)', 'panel_height_mm':'Altura livre do painel b (mm)',
 'web_thickness_mm':'Espessura da alma t (mm)', 'poisson':'Coeficiente de Poisson',
 'sigma_bending_edge_mpa':'Tensão longitudinal extrema por flexão (MPa)', 'tau_mpa':'Cisalhamento do painel (MPa)',
 'axial_force_kn':'Força axial N (kN)', 'section_symmetry':'Simetria da seção', 'panel_source':'Fonte da geometria do painel',
 'restraint_source':'Verificação dos apoios do painel', 'method_selection_source':'Justificativa de seleção do método',
 'four_edges_supported_confirmed':'Apoio nas quatro bordas confirmado', 'support_rigidity_verified':'Rigidez e resistência dos apoios verificadas',
 'linear_antisymmetric_bending_confirmed':'Flexão linear antissimétrica confirmada', 'uniform_shear_envelope_confirmed':'Cisalhamento equivalente qualificado',
 'no_openings_or_longitudinal_stiffeners':'Sem aberturas ou enrijecedores longitudinais',
 'no_transverse_compression_confirmed':'Ausência relevante de compressão transversal confirmada',
 'same_panel_concurrent':'Tensões concomitantes no mesmo painel', 'annex_c_method_selected':'Método do Anexo C selecionado',
 'alpha':'Proporção α = a/b', 'k_sigma':'Coeficiente de flambagem normal kσ', 'k_tau':'Coeficiente de flambagem por cisalhamento kτ',
 'bending_branch':'Ramo do coeficiente de flexão', 'shear_branch':'Ramo do coeficiente de cisalhamento', 'psi':'Relação ψ entre tensões de borda',
 'plate_euler_mpa':'Tensão de Euler da chapa (MPa)', 'sigma_critical_elastic_mpa':'Tensão normal crítica elástica (MPa)',
 'tau_critical_elastic_mpa':'Cisalhamento crítico elástico (MPa)', 'sigma_edge_signed_mpa':'Tensão de borda com sinal (MPa)',
 'tau_signed_mpa':'Cisalhamento com sinal (MPa)', 'sigma_equivalent_demand_mpa':'Tensão equivalente solicitante (MPa)',
 'interaction_denominator':'Denominador da interação', 'combined_critical_elastic_mpa':'Tensão crítica combinada elástica (MPa)',
 'critical_reduced_mpa':'Tensão crítica reduzida (MPa)', 'proportional_limit_mpa':'Limite de proporcionalidade (MPa)',
 'reduction_factor':'Fator de redução', 'reduction_branch':'Ramo da redução', 'reduction_formula':'Expressão de redução',
 'nu_v':'Coeficiente de segurança νv', 'allowable_equivalent_mpa':'Tensão equivalente admissível (MPa)',
 'safety_basis':'Base do coeficiente de segurança', 'table_critical_lower_mpa':'Limite crítico inferior tabulado (MPa)',
})
ENUMS.update({'doubly_symmetric_i':'Seção I duplamente simétrica','monosymmetric_i':'Seção I monossimétrica'})
LABELS.update({
 'restraint_kind':'Tipo real de contenção', 'restrained_flange':'Mesa contida',
 'moment_min_knm':'Momento forte mínimo com sinal (kN.m)', 'moment_max_knm':'Momento forte máximo com sinal (kN.m)',
 'member_segment':'Trecho da viga', 'envelope_source':'Fonte do envelope completo',
 'continuity_geometry_source':'Evidência geométrica da continuidade', 'restraint_strength_source':'Verificação externa da resistência da contenção',
 'restraint_stiffness_source':'Verificação externa da rigidez da contenção', 'anchorage_source':'Verificação externa da ancoragem',
 'entire_segment_envelope_confirmed':'Envelope completo do trecho confirmado',
 'actual_continuous_connection_confirmed':'Ligação efetivamente contínua confirmada',
 'lateral_and_torsional_restraint_qualified':'Contenção lateral/torsional qualificada',
 'strength_stiffness_and_anchorage_verified':'Resistência, rigidez e ancoragem verificadas',
 'symmetric_i_confirmed':'Seção I duplamente simétrica confirmada', 'practical_method_selected':'Método prático selecionado',
 'free_flange_compression_moment_knm':'Momento que comprime a mesa livre (kN.m)',
})
ENUMS.update({'continuous':'Contenção realmente contínua','discrete_lacing':'Treliçamento discreto','top':'Superior','bottom':'Inferior'})

LABELS.update({'moment_minor_knm':'Momento fletor fraco concomitante (kN.m)','torsion_knm':'Torção concomitante (kN.m)','no_other_free_flange_compression_confirmed':'Ausência de outras fontes de compressão na mesa livre confirmada'})

LABELS.update({'name': 'Identificação da aba, lado e caso', 'load_case': 'Caso de solicitação', 'action_basis': 'Base do momento solicitante', 'compression_mpa': 'Magnitude de compressão longitudinal na aba (MPa)', 'poisson': 'Coeficiente de Poisson', 'segment_name': 'Trecho cadastrado nos travamentos', 'moment_major_knm': 'Momento forte com sinal do caso (kN.m)', 'moment_minor_knm': 'Momento fraco concomitante (kN.m)', 'axial_force_kn': 'Força axial concomitante (kN)', 'torsion_knm': 'Torção concomitante (kN.m)', 'action_source': 'Combinação e posição do equipamento', 'factors_source': 'Fatores já incluídos nas ações', 'action_case_qualified': 'Caso e ações qualificados', 'factors_already_applied': 'Fatores incluídos exatamente uma vez', 'load_pattern': 'Método para C1 e C2', 'load_pattern_source': 'Fonte e descrição exata do padrão de carregamento', 'load_height_mm': 'Altura assinada zg da força em relação ao centro de cisalhamento (mm)', 'load_height_source': 'Geometria, sentido da força e altura de aplicação', 'actual_load_pattern_confirmed': 'Distribuição e condições de extremidade correspondem ao método escolhido', 'single_load_height_confirmed': 'As ações transversais relevantes têm a altura única representada', 'load_height_sign_confirmed': 'Sinal e magnitude de zg conferidos', 'restraint_source': 'Desenho e verificação externa das restrições efetivas', 'compact_section_source': 'Verificação da compacidade da seção', 'method_selection_source': 'Seleção justificada do método de literatura JRC/ECCS + Anexo C.2', 'practical_method_selected': 'Método prático explicitamente selecionado pelo responsável', 'high_ratio_route_confirmed': 'Quando fy/fu > 0,70, ramo de material de referência qualificado', 'stress_source': 'Fonte da tensão e distribuição na aba', 'root_restraint_source': 'Apoio efetivo e rigidez da raiz da aba', 'actual_outstand_qualified': 'Largura de balanço vinculada à geometria real', 'flat_unperforated_outstand_confirmed': 'Aba plana sem aberturas', 'supported_root_free_edge_confirmed': 'Raiz apoiada e borda oposta livre', 'root_rigidity_verified': 'Rigidez e resistência da raiz verificadas', 'uniform_longitudinal_compression_confirmed': 'Compressão longitudinal uniforme qualificada', 'no_local_transverse_patch_confirmed': 'Não há ação transversal localizada de roda neste modelo de aba', 'no_shear_biaxial_interaction_confirmed': 'Não há interação relevante de cisalhamento ou biaxial', 'no_distortional_coupled_mode_confirmed': 'Não há modo distorcional/acoplado não representado', 'literature_method_selected': 'Método de literatura explicitamente selecionado', 'external_C1': 'Coeficiente C1 qualificado', 'external_C2': 'Coeficiente C2 qualificado', 'coefficient_source': 'Relatório/método dos coeficientes para o caso real', 'external_coefficients_qualified': 'C1/C2 qualificados para esta geometria, apoios e diagrama real', 'external_normalization_confirmed': 'Coeficientes usam a normalização da equação NCCI adotada', 'load_height_not_duplicated_confirmed': 'Altura da carga não foi incorporada duas vezes aos coeficientes e à equação', 'zero_end_moments_confirmed': 'Momentos fortes nas duas extremidades do trecho são nulos', 'straight_uniform_member_confirmed': 'Viga reta e prismática no trecho', 'fork_supports_confirmed': 'As duas extremidades impedem deslocamento lateral e giro de torção', 'free_warping_confirmed': 'Empenamento livre nas extremidades, k = kw = 1', 'restraint_strength_stiffness_verified': 'Resistência e rigidez das contenções verificadas externamente', 'section_properties_qualified': 'Iy, J, Cw, Wx e Zx vinculados à seção são aplicáveis ao modelo', 'compact_section_confirmed': 'Seção compacta no domínio da curva adotada'})
LABELS.update({
 'G_mpa':'Módulo de elasticidade transversal G (MPa)', 'E_mpa':'Módulo de elasticidade E (MPa)',
 'Z_major_mm3':'Módulo plástico forte Z (mm³)', 'W_major_mm3':'Módulo elástico forte W (mm³)',
 'I_w_mm6':'Constante de empenamento Cw (mm⁶)', 'I_weak_mm4':'Inércia no eixo fraco Iy (mm⁴)',
 'I_t_mm4':'Constante de torção J (mm⁴)', 'geometry_source':'Fonte da geometria',
 'outstand_width_mm':'Largura da aba em balanço c (mm)', 'flange_thickness_mm':'Espessura da mesa tf (mm)',
 'unrestrained_length_mm':'Comprimento destravado Lb (mm)', 'properties_source':'Fonte das propriedades da seção',
 'A_mcr_mm2':'Parâmetro geométrico A da equação Mcr (mm²)', 'B_mcr_mm':'Parâmetro de altura B = C2 zg (mm)',
 'height_arm_mm':'Termo de altura da equação Mcr (mm)', 'Mcr_nmm':'Momento crítico elástico (N.mm)',
 'Mcr_knm':'Momento crítico elástico (kN.m)', 'C1':'Coeficiente C1', 'C2':'Coeficiente C2',
 'k':'Fator de comprimento para giro lateral k', 'kw':'Fator de comprimento para empenamento kw',
 'lambda_lt':'Esbeltez adimensional λLT', 'moment_major_signed_knm':'Momento forte com sinal (kN.m)',
 'material_moment_cap_knm':'Limite de momento pelo material 8400 (kN.m)',
 'elastic_residual_bound_knm':'Limite adicional do ramo elástico (kN.m)',
 'coefficient_basis':'Origem e qualificação dos coeficientes', 'allowable_moment_knm':'Momento admissível no método (kN.m)',
 'critical_elastic_mpa':'Tensão crítica elástica da aba (MPa)', 'allowable_compression_mpa':'Compressão admissível da aba (MPa)',
})
ENUMS.update({'short_plateau':'Patamar de trecho curto qualificado','elastic_long':'Ramo elástico longo qualificado','unsupported_intermediate':'Faixa intermediária ainda não qualificada',
 'udl':'Carga uniforme isolada no vão inteiro','midspan_point':'Uma carga central isolada','external_coefficients':'Coeficientes externos qualificados para o caso real'})

LABELS.update({'resistance_route':'Rota de resistência à FLT','omega_method_source':'Justificativa da adoção do método χ/ω','omega_curve_method_qualified':'Adoção do método χ/ω qualificada','chi_flt':'Fator nominal de redução χFLT','nominal_reduced_moment_knm':'Momento nominal reduzido adotado (kN.m)','omega_flt':'Fator de flambagem ω','yield_elastic_moment_knm':'Momento elástico de escoamento fy W (kN.m)','nominal_over_nu_cap_knm':'Limite nominal dividido por νE (kN.m)','omega_stress_cap_knm':'Limite por tensão admissível com ω (kN.m)'})
ENUMS.update({'bounded_elastic':'Rota restrita ao patamar curto/ramo elástico','adopted_omega_curve':'Método prático de curva completa χ/ω'})

# Shared keys must retain meanings valid across all normative routes.
LABELS.update({'name':'Identificação do registro','action_basis':'Base normativa das ações','action_source':'Origem das ações do caso','method_selection_source':'Justificativa e fonte do método adotado','practical_method_selected':'Método prático explicitamente selecionado pelo responsável'})
LABELS.update({'Mpl_knm':'Momento plástico Mpl (kN.m)','branch':'Ramo da curva de resistência','elastic_residual_bound_applies':'Limite residual elástico aplicável','omega_method_basis':'Fundamentação do método com fator ω'})
ENUMS.update({'adopted_omega_intermediate':'Curva χ/ω adotada: faixa intermediária','adopted_omega_short_plateau':'Curva χ/ω adotada: patamar curto','adopted_omega_elastic_long':'Curva χ/ω adotada: ramo longo'})

LABELS.update({'intermediarios':'Valores intermediários','entradas':'Entradas','bottom_bf_mm':'Largura da mesa inferior (mm)','bottom_tf_mm':'Espessura da mesa inferior (mm)'})
LABELS.update({'W_minor_mm3':'Módulo elástico fraco Wy (mm³)','bimoment_knm2':'Bimomento concomitante de empenamento (kN.m²)','biaxial_method_source':'Justificativa da interação biaxial adotada','torsion_warping_source':'Evidência do caminho das forças sem torção ou empenamento','major_pattern_id':'Identificação do padrão físico para o envelope Mx','minor_pattern_id':'Identificação do padrão físico para o envelope My','critical_pattern_id':'Identificação do padrão físico usado no Mcr','biaxial_method_qualified':'Método de interação biaxial explicitamente qualificado','same_pattern_segment_envelope_confirmed':'Envelopes e Mcr pertencem ao mesmo padrão físico e trecho','no_torsion_warping_load_path_confirmed':'Caminho real das cargas qualificado sem torção e empenamento','minor_axis_compactness_confirmed':'Compacidade para a flexão fraca qualificada'})
ENUMS.update({'adopted_biaxial_omega':'Interação biaxial por método χ/ω adotado'})
LABELS.update({'limites_do_metodo':'Domínio e limites do método','alpha_common':'Fator comum de material e segurança α','allowable_major_moment_knm':'Momento admissível forte Cx (kN.m)','allowable_minor_moment_knm':'Momento admissível fraco Cy (kN.m)','moment_minor_signed_knm':'Momento fraco com sinal (kN.m)','major_utilization_term':'Parcela de utilização na flexão forte','minor_utilization_term':'Parcela de utilização na flexão fraca','biaxial_interaction':'Índice de interação biaxial','elastic_longitudinal_corner_envelope_mpa':'Envelope elástico longitudinal de canto (MPa)','pattern_id':'Identificação do padrão físico de carregamento','biaxial_method_basis':'Fundamentação da interação biaxial'})
CHECK_TITLES.update({'minor_axis_flexure':'Flexão fraca: teto elástico com margem comum','biaxial_flexure_interaction':'Interação biaxial do trecho sem força axial ou torção'})
LABELS.update({'patch_qualification':'Qualificação da rota local ELU','qualification':'Referências e condições de qualificação','case_name':'Identificação do caso vinculado','normal_elu_confirmed':'Combinação ELU normal independente confirmada','supplement_selection_source':'Critério e justificativa da rota suplementar','bearing_model':'Origem do comprimento carregado ln','bearing_at_flange_not_web_lef_confirmed':'ln qualificado na mesa sem duplicação da dispersão','nearest_end_distance_confirmed':'Distância até a extremidade física mais próxima confirmada','lateral_length_source':'Referência dos intervalos destravados de ambas as mesas','restraint_detail_source':'Referência dos vínculos e rotação da mesa','support_end_condition':'Condição dos apoios e extremidades','support_end_source':'Referência da condição de apoio ou enrijecedores','flange_web_transfer_source':'Verificação da transferência pela solda mesa–alma','opposed_pair_force_source':'Referência de cada força do par oposto','stiffener_credit':'Crédito resistente de enrijecedores','first_yield_basis':'Critério de Cr e primeiro escoamento','major_axis_first_yield_confirmed':'Primeiro escoamento por flexão forte isolada qualificado','first_yield_source':'Referência do primeiro escoamento','inputs_current_confirmed':'Referências qualificadas para as entradas atuais','qualified_input_signature':'Assinatura das entradas qualificadas','local_web_subset_verified':'Conjunto local de mecanismos da alma verificado'})
ENUMS.update({'physical_flange_contact':'Contato físico sobre a face da mesa','qualified_rail_distribution':'Distribuição trilho–mesa calculada externamente','torsion_restrained_or_web_connected':'Rotação impedida ou alma ligada a outra viga/pilar','externally_verified_full_depth_stiffeners':'Enrijecedores de altura total verificados externamente','conservative_16E':'Cr = 16E, menor dos dois ramos prescritos','qualified_major_axis':'Primeiro escoamento por flexão forte isolada qualificado','none':'Nenhum'})
LABELS.update({'component_checks_method_selected':'Método por conjunto de verificações locais selecionado','component_method_scope_source':'Justificativa do conjunto e alcance das verificações locais'})
from .runway_patch_labels import LABELS as _PATCH_LABELS, ENUMS as _PATCH_ENUMS
LABELS.update(_PATCH_LABELS)
ENUMS.update(_PATCH_ENUMS)
LABELS.update({'supplement_global_8800':'Conjunto global ELU 8800 selecionado','supplement_service_8800':'Critérios de serviço complementares selecionados','supplement_fatigue_8800':'Fadiga Anexo H 8800 selecionada'})

LABELS.update({'positive_kappa_route':'Método para κ positivo','conservative_envelope_selected':'Envelope conservador explicitamente adotado','positive_kappa_method':'Fundamentação do envelope de κ positivo'})
ENUMS.update({'conservative_zero_envelope':'Envelope conservador constante para κ positivo'})
LABELS.update({'section_symmetry':'Simetria da seção','section_material_qualified':'Seção e material no domínio calculado','full_span_system_qualified':'Sistema físico do vão inteiro qualificado','rail_load_path_qualified':'Transferência e altura das cargas do trilho qualificadas','full_span_envelopes_qualified':'Envoltórias completas do caso qualificadas','system_source':'Referência do sistema e apoios','rail_source':'Referência do arranjo roda–trilho','depth_mm':'Altura da seção (mm)','span_mm':'Vão inteiro (mm)','Af_mm2':'Área resistente de uma mesa (mm²)','Aw_mm2':'Área da alma (mm²)','Ac_mm2':'Área para esbeltez, mesa + meia alma (mm²)','If_mm4':'Inércia lateral de uma mesa (mm⁴)','Ic_mm4':'Inércia para esbeltez (mm⁴)','Wf_mm3':'Módulo elástico lateral da mesa (mm³)','web_fraction_slenderness':'Fração de alma apenas na esbeltez','web_fraction_resistance':'Fração de alma na resistência','radius_c_mm':'Raio de giração equivalente (mm)','Ncr_kn':'Força crítica elástica equivalente (kN)','lambda_c':'Esbeltez adimensional de compressão','chi_c':'Fator de redução de compressão χ','omega_c':'Fator ω de compressão','imperfection_alpha':'Parâmetro de imperfeição da curva d','N_flange_kn':'Força normal na mesa (kN)','M_torsion_flange_bound_knm':'Limite do momento de mesa devido à torção (kN.m)','M_flange_bound_knm':'Envelope do momento lateral da mesa (kN.m)','compression_capacity_kn':'Capacidade de compressão adotada (kN)','flange_moment_capacity_knm':'Capacidade elástica lateral da mesa (kN.m)','n':'Parcela de compressão n','m':'Parcela de flexão lateral m','kzz':'Fator de interação kzz','interaction':'Índice de interação','longitudinal_stress_envelope_mpa':'Envelope de tensão longitudinal das mesas (MPa)','stress_reference':'Alcance da tensão calculada','allowable_material_basis':'Limites admissíveis do material','beta_c':'Fator de comprimento βc','Cmz':'Fator de momento Cmz','kc':'Fator de momento kc'})
ENUMS.update({'doubly_symmetric_i':'Seção I/H duplamente simétrica'})

LABELS.update({'flange_width_mm':'Largura da mesa (mm)','method_source':'Referência e adoção do método prático'})

LABELS.update({'multiwheel_envelope_method':'Método para rodas múltiplas','multiwheel_model_qualified':'Modelo local de rodas múltiplas qualificado','multiwheel_model_source':'Referência do modelo local e enrijecedores','tau0xz_top_bound_mpa':'Envelope absoluto de cisalhamento local no topo (MPa)','tau0xz_at_z_bound_mpa':'Envelope absoluto de cisalhamento local na profundidade (MPa)','sigmaT_top_bound_mpa':'Envelope absoluto de flexão local por torção (MPa)','sigma_cz_top_bound_mpa':'Envelope combinado de compressão local no topo (MPa)','local_effects_bound_complete':'Envelope local do modelo qualificado'})
ENUMS.update({'absolute_sum_nbr10084':'Envelope conservador de máximos absolutos do modelo NBR10084'})

LABELS.update({'url':'Endereço da fonte','external_responsibilities':'Responsabilidades externas','supporting_source':'Fonte de fundamentação','multiwheel_bound':'Envelope de rodas múltiplas','text':'Descrição','code':'Identificador','pending_requirements':'Requisitos de cobertura','local_index':'Caso local vinculado (índice)','stress_indices':'Casos de tensões vinculados (índices)','method':'Método de cobertura','global_abs_sigma_x_mpa':'Limite global longitudinal absoluto (MPa)','global_abs_sigma_y_mpa':'Limite global transversal absoluto (MPa)','global_abs_tau_xy_mpa':'Limite global de cisalhamento absoluto (MPa)','evidence_source':'Referência da comprovação','confirmed':'Abrangência confirmada','input_signature':'Assinatura das entradas vinculadas','local_sigma_y_bound_mpa':'Parcela local normal do envelope (MPa)','local_tau_bound_mpa':'Parcela local de cisalhamento do envelope (MPa)','total_sigma_x_bound_mpa':'Limite longitudinal total (MPa)','total_sigma_y_bound_mpa':'Limite transversal total (MPa)','total_tau_bound_mpa':'Limite de cisalhamento total (MPa)','equivalent_bound_mpa':'Limite equivalente de sinais adversos (MPa)','adverse_corner_mpa':'Canto de sinais adversos (MPa)','additional_load_multiplier':'Multiplicador adicional de ações','declaracao':'Declaração de abrangência','cobertura_estabilidade':'Cobertura dos casos e trechos de estabilidade','required_pairs':'Pares caso/trecho necessários','covered_pairs':'Pares caso/trecho verificados','gaps':'Lacunas de cobertura','coverage_complete':'Cobertura concluída no domínio declarado','service_index':'Caso de serviço vinculado (índice)','responsibility':'Responsabilidade externa','outcome':'Conclusão externa'})
ENUMS.update({'concurrent_stress_rows':'Casos reais concomitantes vinculados','conservative_component_bounds':'Envelope conservador de componentes','requires_specific_assessment':'Excedência requer avaliação específica','verified':'Verificado e atendido externamente','not_satisfied':'Verificado e não atendido externamente','unverified':'Ainda não verificado externamente','global_system_service':'Serviço do sistema global','manufacturer_interface_service':'Interface do fabricante/contrato'})
