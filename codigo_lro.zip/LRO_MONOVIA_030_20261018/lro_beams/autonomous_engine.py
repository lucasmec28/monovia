"""Autonomous orchestration. Missing implementation is explicit, never green.

Primary 10084/8400 operational checks and complementary 8800 ELU checks retain
separate action families and resistance conventions throughout.
"""
from dataclasses import asdict,dataclass
import math
from .autonomous_restraint_mode import analysis_has_lateral_restraints,mode_evidence
from .autonomous_nominal_lengths import resolve_nominal_lengths
from .autonomous_fullheight_actions import enabled as fullheight_enabled
from .autonomous_model import validate_autonomous,physical_premises
from .autonomous_cases import generate_basic_cases
from .autonomous_actions import evaluate_action_applicability,HoistDynamics
from .autonomous_response import flexural_search
from .autonomous_sweep import scan_coupled_case
from .autonomous_stress import recover_section,recover_envelope,_prepare_envelope_geometry
from .autonomous_stability_en2025 import evaluate_supplemental_en2025
from .autonomous_local import calculate_autonomous_local,calculate_physical_local_8800,local_bounds_at_section
from .autonomous_local_resistance import calculate_local_8800,design_project_stiffener_welds,panel_restraint_evidence,project_vertical_transfer_bound,design_flange_web_welds,design_stiffener_weld_group,bearing_stiffener_combined_bounds,design_stiffener_station_welds
from .autonomous_panel import evaluate_panel_bound,SOURCE as PANEL_SOURCE
from .autonomous_weld_actions import stiffener_action_bounds,envelope_action_bounds
from .autonomous_stiffener_actions import stiffener_station_geometry,stiffener_station_actions,envelope_stiffener_stations,stiffener_action_translation_events
from .autonomous_retention import compact_stiffener_case
from .autonomous_lateral_restraints import SOURCE as LATERAL_RESTRAINT_SOURCE,lateral_restraint_evidence_complete
from .autonomous_coverage import coverage_requirements,required_fatigue_regions,FATIGUE_FAMILY
from .autonomous_result import AutonomousResult,Verification,input_signature,REQUIRED_MECHANISMS
from .autonomous_resistance import local_bending_resistances,axial_compression_resistance
from .autonomous_fatigue import elastic_allowables_autonomous
from .autonomous_fatigue_adapter import evaluate_fatigue_project_family
from .autonomous_fatigue_storage import PackedFatigueAnalyses
from .geometry import section_properties
from .engine import vertical_shear_resistance,horizontal_shear_resistance,ELS_PRESETS,SOURCE_ELS


def _ratio(identifier,mechanism,title,demand,capacity,unit,source,case,reason='',evidence=None,conservative=False):
    if conservative and abs(demand)>capacity:
        return Verification(identifier,mechanism,title,'calculated',source,case,abs(demand),capacity,unit,abs(demand)/capacity,'Não atende ao critério conservador adotado. Redimensionar ou empregar uma avaliação refinada; este limite não constitui prova de ruptura física. '+reason,{**(evidence or {}),'conservative_exceedance':True})
    return Verification(identifier,mechanism,title,'calculated',source,case,abs(demand),capacity,unit,abs(demand)/capacity,reason,evidence or {})


def _summary(identifier,mechanism,title,source,case,ready,reason='',evidence=None):
    return Verification(identifier,mechanism,title,'calculated' if ready is True else 'pending',source,case,
        reason=reason if ready is not True else '',evidence={**(evidence or {}),'verification_complete':ready is True})



def _stiffener_member_verifications(fixed_detail):
    """Emit pending obligations for any unqualified station, never a false ratio."""
    governing={};qualified_failures={}
    for station in fixed_detail['stations']:
        for check in station['member_bounds']['checks']:
            key=check['id'];old=governing.get(key)
            if check.get('qualified',False) and check['utilization']>1.:
                qualified_failures.setdefault(key,[]).append((station,check))
            score=(not check.get('qualified',False),check.get('utilization') or 0.)
            if old is None or score>old[0]:governing[key]=(score,station,check)
    result=[]
    for key,(_,station,check) in governing.items():
        reason='Estação '+station['station_id']+' em '+f"{station['x_m']:.3f}"+' m.'
        evidence=station['member_bounds']
        if check.get('qualified',False):
            result.append(_ratio(key,'stiffeners',check['name'],check['demand'],check['capacity'],check['unit'],check['source'],'Envelope ELU',reason=reason,evidence=evidence,conservative=True))
        else:
            result.append(Verification(key,'stiffeners',check['name'],'pending',check['source'],'Envelope ELU',
                demand=check['demand'],unit=check['unit'],reason=reason+' '+check['qualification_reason'],
                evidence={**evidence,'verification_complete':False,'diagnostic_only':True}))
            # Missing qualification elsewhere must not hide a known failure.
            for failed_station,failed in qualified_failures.get(key,[]):
                result.append(_ratio(key+'/station/'+failed_station['station_id'],'stiffeners',failed['name'],
                    failed['demand'],failed['capacity'],failed['unit'],failed['source'],'Envelope ELU',
                    reason='Falha calculada na estação '+failed_station['station_id']+'; a cobertura de outras estações permanece pendente.',
                    evidence=failed_station['member_bounds'],conservative=True))
    return result


def _equivalent_interval_bound(normal_interval,transverse_interval,shear_abs_bound):
    """Convex plane-stress quadratic reaches its rectangle maximum at a vertex."""
    if any(not math.isfinite(x) for x in (*normal_interval,*transverse_interval,shear_abs_bound)) or shear_abs_bound<0:
        raise ValueError('Intervalo de tensões inválido.')
    if normal_interval[0]>normal_interval[1] or transverse_interval[0]>transverse_interval[1]:raise ValueError('Intervalo de tensões invertido.')
    return max(math.sqrt(nx*nx+nz*nz-nx*nz+3*shear_abs_bound**2) for nx in normal_interval for nz in transverse_interval)


@dataclass
class _CombinedSectionSample:
    """Fixed-schema record; expose its ordinary dict, sharing CPython keys.

    No field, precision or sample is removed. Consumers still receive a dict.
    """
    x_m:float
    side:str
    web_sigma_abs_mpa:float
    web_shear_abs_mpa:float
    flange_sigma_abs_mpa:float
    flange_shear_abs_mpa:float
    local_compression_mpa:float
    local_shear_mpa:float
    combined_longitudinal_mpa:float
    combined_shear_mpa:float
    local_transverse_mpa:float
    local_bending_mpa:float


def _stress_observer(p,case,local_records,panel_config=None):
    cache={};cache_key_schemas={};station_index={};prepared_geometry=None
    station_geometry=stiffener_station_geometry(p)
    signature=input_signature(p)
    def local_at(r):
        a=r.translation_m
        if a not in local_records:
            if case.family in ('I','III','FAT8400'):
                local_records[a]=calculate_autonomous_local(p,case.action_factors,a,wheel_vertical_kn=case.factors.wheel_vertical_override_kn,longitudinal_sign=case.longitudinal_sign)
            elif case.family=='ULS8800':
                local_records[a]=calculate_physical_local_8800(p,case.action_factors,a,longitudinal_sign=case.longitudinal_sign)
                resistance=calculate_local_8800(p,case.action_factors,a,longitudinal_sign=case.longitudinal_sign)
                local_records[a].update(checks=resistance.get('checks',[]),component_checks_calculated=resistance.get('component_checks_calculated',False),resistance_pending=resistance.get('pending',[]))
            else:return {}
            local_records[a].update(project_signature=signature,case_id=case.id)
            if not fullheight_enabled(p):local_records[a]['stiffener_action_bounds']=stiffener_action_bounds(p,r)
            if fullheight_enabled(p):
                from .autonomous_fullheight_actions import station_actions as nominal_station_actions
                station_actions=nominal_station_actions(p,r,local_records[a])
            else:station_actions=stiffener_station_actions(p,r,local_records[a])
            local_records[a].update(stiffener_stations=station_actions['stations'],stiffener_station_complete=station_actions['complete'],stiffener_station_pending=station_actions.get('pending',[]))
            station_index[a]={row['x_m']:row for row in station_actions['stations']}
        return local_records[a]
    def extra_positions(r):
        record=local_at(r)
        return tuple({row['x_m'] for row in station_geometry}|{x/1000 for patch in record.get('compression_patches',[]) for x in (patch['left_mm'],patch['right_mm']) if 0<x<p.span_m*1000})
    def observe(r,x,side,state,level):
        nonlocal prepared_geometry
        key=(r.translation_m,x,side)
        if key in cache:
            names,values=cache[key]
            return dict(zip(names,values))
        if prepared_geometry is None:prepared_geometry=_prepare_envelope_geometry(p,r)
        field=recover_envelope(p,r,x,side,prepared_state=state,prepared_geometry=prepared_geometry)
        values={key:field[key] for key in ('sigma_abs_upper_bound_mpa','shear_magnitude_upper_bound_mpa','von_mises_upper_bound_mpa')}
        for component in ('web','flange'):
            row=field['by_component'][component]
            values[component+'_sigma_abs_upper_bound_mpa']=row['sigma_abs_upper_bound_mpa']
            values[component+'_shear_magnitude_upper_bound_mpa']=row['shear_magnitude_upper_bound_mpa']
        if case.family in ('I','III','FAT8400','ULS8800'):
            local=local_at(r)
            bounded=local_bounds_at_section(local,x)
            if bounded.get('complete'):
                sx=field['by_component']['web']['sigma_abs_upper_bound_mpa']+bounded['longitudinal_local_compression_bound_mpa']
                sz=bounded['transverse_compression_bound_mpa']+bounded['sigmaT_bound_mpa']
                tau=field['by_component']['web']['shear_magnitude_upper_bound_mpa']+bounded['local_shear_complete_bound_mpa']
                web=field['by_component']['web']
                normal_interval=(web['sigma_min_mpa']-bounded['longitudinal_local_compression_bound_mpa'],web['sigma_max_mpa'])
                transverse_interval=(-sz,bounded['sigmaT_bound_mpa'])
                equivalent=_equivalent_interval_bound(normal_interval,transverse_interval,tau)
                prescribed_compression=bounded['sigma_cz_bound_mpa']
                prescribed_equivalent=_equivalent_interval_bound(normal_interval,(-prescribed_compression,bounded['sigmaT_bound_mpa']),tau)
                values.update(local_equivalent_bound_mpa=equivalent,local_prescribed_equivalent_bound_mpa=prescribed_equivalent,local_prescribed_normal_bound_mpa=max(prescribed_compression,bounded['sigmaT_bound_mpa']),
                    local_transverse_bound_mpa=sz,local_shear_bound_mpa=bounded['local_shear_complete_bound_mpa'],
                    local_compression_bound_mpa=bounded['transverse_compression_bound_mpa'],local_bending_bound_mpa=bounded['sigmaT_bound_mpa'],
                    local_longitudinal_compression_bound_mpa=bounded['longitudinal_local_compression_bound_mpa'],
                    combined_web_longitudinal_bound_mpa=sx,combined_web_shear_bound_mpa=tau)
                local.setdefault('combined_section_samples',[]).append(vars(_CombinedSectionSample(x_m=x,side=side,web_sigma_abs_mpa=web['sigma_abs_upper_bound_mpa'],web_shear_abs_mpa=web['shear_magnitude_upper_bound_mpa'],flange_sigma_abs_mpa=field['by_component']['flange']['sigma_abs_upper_bound_mpa'],flange_shear_abs_mpa=field['by_component']['flange']['shear_magnitude_upper_bound_mpa'],local_compression_mpa=bounded['longitudinal_local_compression_bound_mpa'],local_shear_mpa=bounded['local_shear_complete_bound_mpa'],combined_longitudinal_mpa=sx,combined_shear_mpa=tau,local_transverse_mpa=sz,local_bending_mpa=bounded['sigmaT_bound_mpa'])))
                station=station_index[r.translation_m].get(x)
                if station is not None:
                    nominal=station.setdefault('nominal_bounds',{'complete':True,'x_m':x,'source':'Recuperação nominal no mesmo corte físico, ambos os lados; NBR10084 para efeitos locais.'})
                    current={'web_sigma_abs_mpa':web['sigma_abs_upper_bound_mpa'],
                        'flange_sigma_abs_mpa':field['by_component']['flange']['sigma_abs_upper_bound_mpa'],
                        'web_shear_abs_mpa':web['shear_magnitude_upper_bound_mpa'],
                        'flange_shear_abs_mpa':field['by_component']['flange']['shear_magnitude_upper_bound_mpa'],
                        'local_transverse_mpa':sz,'local_bending_mpa':bounded['sigmaT_bound_mpa'],
                        'local_shear_mpa':bounded['local_shear_complete_bound_mpa']}
                    for name,value in current.items():nominal[name]=max(nominal.get(name,0.),value)
                    # Every physical interface component has its own convergence
                    # metric; a peak at one station cannot hide another station.
                    for face in station['interfaces']:
                        for name,value in face['action_bounds'].items():
                            values['stiffener_action/'+station['station_id']+'/'+face['interface_id']+'/'+name]=value
                if panel_config and panel_config.get('qualified') and case.family in ('I','III'):
                    nu={'I':1.70,'III':1.35}[case.family]
                    crx=panel_config['crx'];crz=panel_config['crz']
                    values['panel_energy_ratio_bound']=nu*(sx/crx+sz/crz+2*tau/math.sqrt(crx*crz))
                    values['panel_elastic_ratio_bound']=nu*values['local_equivalent_bound_mpa']/panel_config['proportional']
        if case.family in ('ULS8800','FAT8400') and fullheight_enabled(p):
            for station in local_at(r)['stiffener_stations']:
                if station['vertical_bearing_kn'] is not None:
                    values['fullheight_bearing/'+station['station_id']]=abs(station['vertical_bearing_kn'])
        if case.family=='ULS8800' and fullheight_enabled(p):
            stations=[row['x_m'] for row in station_geometry]
            for i,(a,b) in enumerate(zip(stations,stations[1:])):
                if a<=x<=b:values['fullheight_panel_shear/'+str(i)]=abs(state['Vy_kn'] if isinstance(state,dict) else state.Vy_kn)
            if x==0. and side=='left' and p.beam_end_left_mm:values['fullheight_tail_shear/left']=abs(state['Vy_kn'] if isinstance(state,dict) else state.Vy_kn)
            if x==p.span_m and side=='right' and p.beam_end_right_mm:values['fullheight_tail_shear/right']=abs(state['Vy_kn'] if isinstance(state,dict) else state.Vy_kn)
        if case.family=='ULS8800':
            checks=local_at(r).get('checks',[])
            values['local_8800_ratio_bound']=max((c['utilization'] for c in checks if c.get('utilization') is not None),default=0.)
        # Share immutable key schemas instead of retaining one large dict per
        # sample. Values and every observer/local-record side effect are exact.
        names=tuple(values)
        names=cache_key_schemas.setdefault(names,names)
        cache[key]=(names,tuple(values.values()))
        return values
    observe.section_positions=extra_positions
    observe.translation_events=stiffener_action_translation_events(p)
    return observe


def _projection_service_checks(p,c,sweep,vr,hr):
    checks=[]
    def maximum(k):return abs(sweep.maxima[k].value)
    for side,length in (('left',p.beam_end_left_mm),('right',p.beam_end_right_mm)):
        if length:
            checks.append(_ratio('service8800_projection_vertical/'+side+'/'+c.id,
                'vertical_service','Flecha vertical da projeção física '+side,
                maximum('projection_'+side+'_vertical_mm'),2*length/vr,'mm',
                SOURCE_ELS+'; Tabela B.1, nota(a): L=2a para balanço',c.id,
                'Inclui rotação do eixo de apoio e curvatura por peso próprio; sem rodas fora dos apoios e sem impacto vertical.'))
            checks.append(_ratio('service8800_projection_horizontal/'+side+'/'+c.id,
                'horizontal_service','Deslocamento horizontal da projeção física '+side,
                maximum('projection_'+side+'_rail_horizontal_bound_mm'),2*length/hr,'mm',
                SOURCE_ELS+'; Tabela B.1, linhas horizontais de vigas de rolamento e nota(a): L=2a',c.id,
                'Limite triangular conservador |inclinação lateral do apoio|a+|zrail theta_ponta|, válido em toda a projeção sem forças horizontais ou torques externos.',
                conservative=True))
    return checks


def calculate_core(p,*,progress=None,initial_divisions=8,max_refinements=6):
    """Compute the independent analysis/resistance portion of the full engine.

    Six refinements are the bounded default budget, not a relaxation of the
    two-successive-pass convergence criterion. Already-converged cases stop
    early; exhausted cases remain pending. Explicit caller budgets are honored.

    Local-wheel, fatigue and combined stability adapters append their own
    evidence. This function cannot by itself return a complete design.
    """
    out=AutonomousResult(input_signature(p));out.errors=validate_autonomous(p)
    if out.errors:return out
    try:nominal_lengths=resolve_nominal_lengths(p)
    except ValueError as exc:
        out.errors.append(str(exc));return out
    out.assumptions=list(physical_premises(p))
    out.numerical_evidence['restraint_application']=mode_evidence(p)
    g=section_properties(p.section);out.properties=asdict(g)
    if not p.section.doubly_symmetric:
        out.checks.append(Verification('symmetry','global_stability','Seção para o modelo de torção','unsupported','Modelo de Vlasov bisimétrico',reason='Perfil com mesas diferentes permanece disponível para geometria; o motor acoplado atual exige seção I duplamente simétrica.'))
        return out
    if not stiffener_station_geometry(p):
        out.checks.append(Verification('stiffener_layout_domain','stiffeners','Disposição dos enrijecedores para a rota local','unsupported','NBR 10084, efeitos locais; modelo de pares de altura total',reason='A rota implementada de transferência local exige pares físicos de enrijecedores declarados. Sem pares, a alma e as ligações locais precisam de outro modelo.'))
        return out
    if (p.beam_end_left_mm or p.beam_end_right_mm) and p.rail.offset_from_web_mm!=0:
        out.checks.append(Verification('projection_torsion_domain','torsion_warping','Projeções com trilho fisicamente excêntrico','unsupported',
            'Condensação de Vlasov das projeções sem torque externo',reason='O peso de trilho fisicamente excêntrico aplica torque nas caudas; falta o vetor condensado dessa carga distribuída. A rota atual exige trilho centrado sobre a alma.'))
        return out
    if p.beam_end_left_mm or p.beam_end_right_mm:
        out.numerical_evidence['physical_end_projections']=dict(
            lengths_mm={'left':p.beam_end_left_mm,'right':p.beam_end_right_mm},
            permanent_line_load_continues=True,wheel_travel_outside_supports=False,
            root_faces_registered=True,
            stress_envelope_scope='No modelo nominal, N=My=0 na cauda; máximo de flange=|M|d/(2Ix)+|B|b*h0/(4Cw). |M|,|V|,|B|,|Ts|,|Tw| não crescem rumo à ponta. O envelope por componente na raiz cobre a cauda inteira; uma fibra assinada isolada não necessariamente.',
            vertical_kinematics='Inclui rotação real do apoio, curvatura e todos os extremos interiores.',
            horizontal_kinematics='Limite triangular de inclinação lateral e torção até a ponta.',
            service_source='NBR 8800:2024 Tabela B.1 nota(a), L=2a para cada projeção; nota(f) sem impacto vertical.')
    action_scope=evaluate_action_applicability(p.action_applicability,dynamics=HoistDynamics(p.hoist_class,p.drive_class,p.hoist_speed_m_s,p.creep_speed_m_s or None,'Classes e velocidades declaradas'),wheel_count=len(p.wheels))
    ready=action_scope['special_events_ready']
    out.checks.append(Verification('special_actions','actions','Aplicabilidade de vento, batente e ensaio','calculated' if ready is True else 'pending',action_scope['source'],reason='; '.join(action_scope['pending']) if not ready else '',evidence={'verification_complete':ready,'requirements':action_scope['requirements']}))
    cases=generate_basic_cases(p)
    out.declare_required_checks(coverage_requirements(p,cases))
    out.cases=[dict(id=c.id,family=c.family,description=c.description,loaded=c.loaded,factors=asdict(c.factors),limitations=c.limitations) for c in cases]
    # Action applicability (wind / bumpers / tests) is verified by its own adapter.
    out.checks.append(Verification('characteristic_components','actions','Separação de ações por roda','calculated','NBR 10084, 8; NBR 8800, 4.7',evidence={'verification_complete':True,'wheel_count':len(p.wheels)},reason='Permanente e sobrecarga são aplicadas antes dos coeficientes de cada família.'))
    uls_cases=[c for c in cases if c.family=='ULS8800']
    strongest=max(uls_cases,key=lambda c:project_vertical_transfer_bound(p,c.action_factors))
    if fullheight_enabled(p):
        from .autonomous_fullheight_static import prepare_fullheight_static,fullheight_panel_restraint
        fixed_detail=prepare_fullheight_static(p,max(c.action_factors.dead_support for c in uls_cases))
        restraint=fullheight_panel_restraint(p,fixed_detail)
    else:
        fixed_detail=design_project_stiffener_welds(p,strongest.action_factors)
        restraint=panel_restraint_evidence(p,fixed_detail)
    out.numerical_evidence['fixed_stiffener_weld_detail']=fixed_detail
    out.numerical_evidence['panel_restraints']=restraint
    panel_config={'qualified':False}
    if fullheight_enabled(p):
        panel_config.update(adopted=False,reason_code='supplementary_biaxial_method_not_adopted',
            prescribed_route='NBR8800 FLA/FLM, 5.4.3/5.4.3.1.3, 5.7/5.7.9; NBR10084 9.1.3; estabilidade global pelo complemento EN C.2 declarado.',
            no_four_edge_navier_claim=True,no_physical_limit_state_waived=True,
            obligation_matrix={'flange_and_web_local_bending':'local/<ULS case>',
                'regional_shear_and_prescriptive_transverse_stiffeners':'shear_vertical/<ULS case>; fullheight/panel_stockiness; fullheight/panel_inertia; fullheight/detail_specification',
                'localized_web_and_bearing':'coverage/local_8800/<ULS case>; fullheight/bearing/<station>/coverage',
                'combined_nominal_local_stress':'local_combined/<I or III case>; local_normal_prescribed/<I or III case>',
                'global_stability':'coverage/stability/<strength case>',
                'connection_and_affected_material':'fullheight/G/coverage; fullheight/concurrent/coverage; fullheight/bearing/<station>/coverage'})
    if restraint['four_edges_supported']:
        panel_trials=[evaluate_panel_bound(a_mm=a,b_mm=restraint['b_mm'],t_mm=restraint['t_mm'],E_mpa=p.material.E_mpa,fy_mpa=p.material.fy_mpa,
            sigma_longitudinal_abs_bound_mpa=0,sigma_transverse_abs_bound_mpa=0,shear_bound_mpa=0,load_case='I',
            four_edges_supported=True,restraint_evidence=restraint['restraint_evidence']) for a in restraint['panels_mm']]
        if panel_trials:
            panel_config=dict(qualified=True,crx=min(r['intermediates']['longitudinal_critical']['critical_mpa'] for r in panel_trials),
                crz=min(r['intermediates']['transverse_critical']['critical_mpa'] for r in panel_trials),proportional=panel_trials[0]['intermediates']['proportional_limit_mpa'])
    out.numerical_evidence['panel_energy_configuration']=panel_config
    local=None
    try:local=local_bending_resistances(p.section,p.material)
    except ValueError as e:out.checks.append(Verification('local_domain','local_stability','Domínio das resistências locais','unsupported','NBR 8800, Anexos D/E',reason=str(e)))
    selected=[c for c in cases if c.family in ('I','III','ULS8800','SLS10084','SLS8800','FAT8400')]
    selected.sort(key=lambda c: 0 if c.family=='ULS8800' else 1)
    sweeps={};equilibrium_max=0.
    fixed_flange_detail=None;uls_transfer_z=0.;uls_transfer_tau=0.;uls_origin_cases=[];uls_group_bounds=[];uls_station_records=[];fixed_group_ready=False;fatigue_analyses=PackedFatigueAnalyses()
    for number,c in enumerate(selected):
        if progress:progress(number,len(selected),c.description)
        if c.family!='ULS8800' and not fixed_group_ready:
            if not uls_station_records or any(not record.get('stations') for record in uls_station_records):
                out.checks.append(Verification('stiffener_actions_domain','stiffeners','Ações locais nos enrijecedores','pending','NBR 8800 e NBR 10084; corpos livres por estação',reason='Não há registros ELU das estações físicas necessários ao dimensionamento das chapas e soldas.'))
                return out
            if fullheight_enabled(p):
                from .autonomous_fullheight_static import finish_fullheight_static
                from .autonomous_fullheight_actions import envelope_station_actions
                station_envelope=envelope_station_actions(uls_station_records)
                fixed_detail,fullheight_checks=finish_fullheight_static(p,fixed_detail,station_envelope,sweeps,uls_cases)
                out.checks.extend(fullheight_checks)
                out.numerical_evidence['fixed_stiffener_weld_detail']=fixed_detail
                restraint=fullheight_panel_restraint(p,fixed_detail)
                out.numerical_evidence['panel_restraints']=restraint
                panel_config['qualified']=bool(panel_config['qualified'] and restraint['four_edges_supported'])
            else:
                station_envelope=envelope_stiffener_stations(uls_station_records)
                station_envelope['snapshot_count']=sum(row['snapshot_count'] for row in uls_station_records)
                fixed_detail=design_stiffener_station_welds(p,station_envelope)
                pairs=[row['member_bounds'] for row in fixed_detail['stations']]
                out.numerical_evidence['stiffener_pair_combined']={'station_based':True,'stations':fixed_detail['stations']}
                out.checks.extend(_stiffener_member_verifications(fixed_detail))
                pair_complete=bool(pairs) and all(row['complete'] for row in pairs) and station_envelope.get('complete',False)
                geometry_available=all(row.get('design') or row.get('limiting_design') for row in fixed_detail['connections'])
                pending=list(dict.fromkeys(station_envelope.get('pending',[])+[msg for row in pairs for msg in row.get('pending',[])]))
                out.checks.append(_summary('coverage/stiffener_detail','stiffeners','Cobertura do detalhe de enrijecedores','NBR 8800, 5.7.9 e 6.2; corpos livres por estação','Envelope ELU',pair_complete and geometry_available,'; '.join(pending) or 'Geometria ou domínio do detalhe de soldas não qualificado.',{'pair_complete':pair_complete,'fixed_weld_detail':fixed_detail}))
                fixed_detail.update(project_signature=out.input_signature,origin_case_ids=list(uls_origin_cases))
                out.numerical_evidence['fixed_stiffener_weld_detail']=fixed_detail
                restraint=panel_restraint_evidence(p,fixed_detail)
                out.numerical_evidence['panel_restraints']=restraint
                panel_config['qualified']=bool(panel_config['qualified'] and restraint['four_edges_supported'])
                for row in fixed_detail['connections']:
                    if row.get('design') or row.get('limiting_design'):
                        d=row.get('design') or row['limiting_design']
                        out.checks.append(_ratio('stiffener_weld_group/'+row['connection'],'stiffeners','Grupo tridimensional de soldas do enrijecedor — '+row['connection'],d['utilization'],1.,'adimensional','NBR 8800, 6.2; grupo elástico tridimensional','Envelope ELU',evidence=d,conservative=True))
                    else:
                        out.checks.append(Verification('stiffener_weld_group/'+row['connection'],'stiffeners','Grupo tridimensional de soldas do enrijecedor — '+row['connection'],'pending','NBR 8800, 6.2',reason='Nenhum filete admissível atende ao envelope dos seis resultantes; revisar geometria.',evidence=row))
            # The fixed detail now owns the reduced same-station envelope.
            # Original ULS bodies have no later reader; FAT traces are separate.
            uls_station_records.clear()
            fixed_group_ready=True
        is_strength=c.family in ('I','III','ULS8800','FAT8400')
        local_records={}
        sweep=scan_coupled_case(p,c,initial_divisions=initial_divisions,max_refinements=max_refinements,observer=_stress_observer(p,c,local_records,panel_config) if is_strength else None)
        sweeps[c.id]=sweep
        equilibrium_max=max(equilibrium_max,sweep.equilibrium_relative_residual)
        out.response_summary[c.id]={k:asdict(v) for k,v in sweep.maxima.items()}
        out.numerical_evidence[c.id]=dict(converged=sweep.converged,relative_change=sweep.relative_change,refinement=sweep.refinement,responses=sweep.responses,sections=sweep.evaluated_sections,cb_minimum=sweep.cb_minimum,cb_critical=sweep.cb_critical)
        out.checks.append(Verification('convergence/'+c.id,'moving_envelope','Convergência da passagem e cortes','calculated' if sweep.converged else 'pending','Malhas aninhadas com eventos de entrada/saída e travamentos',c.id,reason='' if sweep.converged else 'Refinamento insuficiente para a tolerância informada.',evidence={'verification_complete':sweep.converged,**out.numerical_evidence[c.id]}))
        if analysis_has_lateral_restraints(p):
            evidence=sweep.lateral_restraint_evidence
            ready=sweep.case_id==c.id and lateral_restraint_evidence_complete(p,sweep)
            out.numerical_evidence[c.id]['lateral_restraints']=evidence
            out.checks.append(_summary('coverage/lateral_restraints/'+c.id,'horizontal_bending',
                'Compatibilidade das contenções horizontais sem crédito FLT',LATERAL_RESTRAINT_SOURCE,c.id,ready,
                '; '.join(evidence.get('pending',[])) or 'Reações/compatibilidade não cobrem todas as posições calculadas.',evidence))
        def maximum(k):return abs(sweep.maxima[k].value)
        if c.family=='ULS8800':
            if 'local_transverse_bound_mpa' in sweep.maxima:
                uls_transfer_z=max(uls_transfer_z,maximum('local_transverse_bound_mpa'))
                uls_transfer_tau=max(uls_transfer_tau,maximum('combined_web_shear_bound_mpa'))
                uls_origin_cases.append(c.id)
                if fullheight_enabled(p):
                    from .autonomous_fullheight_actions import compact_nominal_case
                    uls_station_records.append(compact_nominal_case(local_records.values(),out.input_signature))
                else:uls_station_records.append(compact_stiffener_case(local_records.values(),out.input_signature))
            source='NBR 8800:2024 + Er1:2025, Anexo D; somente FLM/FLA, FLT avaliada separadamente'
            if local:
                out.checks.extend([
                    _ratio('major/'+c.id,'vertical_bending','Flexão vertical — seção e flambagem local',maximum('Mx_knm'),local['major_local_knm'],'kN·m',source,c.id),
                    _ratio('minor/'+c.id,'horizontal_bending','Flexão horizontal — seção e flambagem local',maximum('My_knm'),local['minor_local_knm'],'kN·m',source,c.id),
                    Verification('local/'+c.id,'local_stability','Classificação e resistência local da seção','calculated',source,c.id,evidence={'verification_complete':True,**local})])
            vy=vertical_shear_resistance(p.section,g,p.material);vx=horizontal_shear_resistance(p.section,p.material)
            out.checks.extend([
                _ratio('shear_vertical/'+c.id,'combined_yield','Cisalhamento vertical da alma',maximum('Vy_kn'),vy['Vrd_kn'],'kN','NBR 8800, 5.4.3',c.id),
                _ratio('shear_horizontal/'+c.id,'combined_yield','Cisalhamento horizontal das mesas',maximum('Vx_kn'),vx['Vrd_kn'],'kN','NBR 8800, 5.4.3',c.id),
                _ratio('normal/'+c.id,'combined_yield','Tensão normal nominal com empenamento',maximum('sigma_abs_upper_bound_mpa'),p.material.fy_mpa/p.material.gamma_a1,'MPa','NBR 8800, 5.5.2.3(a); limite elástico, estabilidade separada',c.id),
                _ratio('shear_combined/'+c.id,'torsion_warping','Cisalhamento nominal com torção',maximum('shear_magnitude_upper_bound_mpa'),.6*p.material.fy_mpa/p.material.gamma_a1,'MPa','NBR 8800, 5.5.2.3(b); modelo nominal de parede fina',c.id,conservative=True)])
            if fullheight_enabled(p):
                out.checks=[check for check in out.checks if check.id!='shear_vertical/'+c.id]
            # An independent axial component does not replace combined stability.
            axial=axial_compression_resistance(p.section,p.material,p.span_m,nominal_lengths.minor_flexural_mm/1000 if nominal_lengths is not None else p.span_m,p.span_m)
            out.checks.append(_ratio('axial_component/'+c.id,'axial_force','Componente axial — envelope conservador de compressão',maximum('N_kn'),axial['capacity_kn'],'kN',axial['source'],c.id,'Comprimento fraco nominal conforme posições; forte e torcional integrais. Interação combinada avaliada separadamente.' if nominal_lengths is not None else 'Comprimentos integrais; interação combinada avaliada separadamente.',axial,conservative=True))
        elif c.family in ('I','III'):
            cap=elastic_allowables_autonomous(p.material.fy_mpa,p.material.fu_mpa,c.family)
            local_pending=list(dict.fromkeys(text for rec in local_records.values() for text in rec.get('pending',[])))
            qualified=bool(local_records) and all(rec.get('local_effects_bound_complete',False) for rec in local_records.values())
            if qualified and 'local_equivalent_bound_mpa' in sweep.maxima:
                out.checks.append(_ratio('local_combined/'+c.id,'wheel_local_effects','Tensões globais e locais de roda/apoio combinadas',maximum('local_prescribed_equivalent_bound_mpa'),cap['sigma_a_mpa'],'MPa','NBR 10084, 9.1.3; NBR 8400-2, 5.2.1.3',c.id,'Soma conservadora dos máximos nominais no mesmo caso e posição do trem.',conservative=True))
                out.checks.append(_ratio('local_normal_prescribed/'+c.id,'wheel_local_effects','Tensão normal local prescrita de roda e apoio',maximum('local_prescribed_normal_bound_mpa'),cap['sigma_a_mpa'],'MPa','NBR 10084, 9.1.3.3–9.1.3.4; NBR 8400-2',c.id,'Compressão C+0,75T da excentricidade vertical; parcela horizontal local e tração mantidas integralmente.',conservative=True))
                out.checks.append(Verification('support_stress/'+c.id,'support_local_effects','Dispersão de tensões nos apoios','calculated','NBR 10084, 9.1.3.1, Figuras1–3',c.id,evidence={'verification_complete':True,'combined_with_global':True},reason='Pegadas completas dentro do comprimento físico; resistência do apoio e enrijecedores verificada separadamente.'))
            else:
                out.checks.append(Verification('local_domain/'+c.id,'wheel_local_effects','Domínio dos efeitos locais','pending','NBR 10084, 9.1.3',c.id,reason='; '.join(local_pending) or 'Modelo local incompleto.'))
            if panel_config['qualified'] and 'panel_energy_ratio_bound' in sweep.maxima:
                out.checks.extend([
                    _ratio('panel_energy/'+c.id,'local_stability','Flambagem biaxial do painel de alma',{'I':1.70,'III':1.35}[c.family]*(maximum('combined_web_longitudinal_bound_mpa')/panel_config['crx']+maximum('local_transverse_bound_mpa')/panel_config['crz']+2*maximum('combined_web_shear_bound_mpa')/math.sqrt(panel_config['crx']*panel_config['crz'])),1.,'adimensional',PANEL_SOURCE,c.id,'Limite energético suficiente com máximos uniformes separados dos componentes no caso; inclui dispersão local e conserva os piores comprimentos de painel.',panel_config,conservative=True),
                    _ratio('panel_elastic/'+c.id,'local_stability','Domínio proporcional do painel de alma',maximum('panel_elastic_ratio_bound'),1.,'adimensional',PANEL_SOURCE,c.id,'Sem benefício de resistência inelástica ou pós-flambagem.',conservative=True)])
            elif not fullheight_enabled(p):
                out.checks.append(Verification('panel_domain/'+c.id,'local_stability','Apoio das bordas do painel de alma','pending',PANEL_SOURCE,c.id,reason='Geometria, rigidez ou soldas dos enrijecedores não qualificam as quatro bordas do painel.'))
            out.checks.append(_ratio('equivalent_nominal/'+c.id,'combined_yield','Tensão equivalente nominal longitudinal/cisalhamento',maximum('von_mises_upper_bound_mpa'),cap['sigma_a_mpa'],'MPa','NBR 8400-2, 5.2.1; '+cap['clause'],c.id,'Limite dos componentes nominais da seção; tensões locais de roda verificadas em registro próprio.',cap,conservative=True))
        elif c.family=='SLS8800':
            vr,hr=ELS_PRESETS['runway_'+p.service_class]
            out.checks.extend([
                _ratio('service8800_vertical/'+c.id,'vertical_service','Flecha vertical complementar NBR 8800',maximum('vertical_mm'),p.span_m*1000/vr,'mm',SOURCE_ELS,c.id,'Sem amplificação vertical por impacto; classe de serviço declarada.'),
                _ratio('service8800_horizontal/'+c.id,'horizontal_service','Flecha horizontal complementar NBR 8800',maximum('rail_horizontal_mm'),p.span_m*1000/hr,'mm',SOURCE_ELS,c.id)])
            out.checks.extend(_projection_service_checks(p,c,sweep,vr,hr))
        elif c.family=='SLS10084':
            out.checks.extend([
                _ratio('service_vertical/'+c.id,'vertical_service','Deslocamento vertical operacional',maximum('vertical_mm'),min(p.span_m*1000/(1000 if p.equipment_use=='steelworks' else 600),25),'mm','NBR 10084, seção 10, Tabela 4(a)',c.id),
                _ratio('service_rail/'+c.id,'rail_service','Deslocamento horizontal no nível do trilho',maximum('rail_horizontal_mm'),p.span_m*1000/600,'mm','NBR 10084, seção 10, Tabela 4(d)',c.id),
                _ratio('service_horizontal/'+c.id,'horizontal_service','Deslocamento horizontal do centro de cisalhamento',maximum('horizontal_mm'),p.span_m*1000/600,'mm','NBR 10084, seção 10, Tabela 4(d); trilho também verificado com rotação',c.id)])
        if c.family=='ULS8800':
            governing={}
            for a,record in local_records.items():
                for check in record.get('checks',[]):
                    key=(check['name'],check['source'])
                    if check.get('utilization') is not None and (key not in governing or check['utilization']>governing[key][1]['utilization']):governing[key]=(a,check)
            for i,((title,source),(a,check)) in enumerate(governing.items()):
                mechanism='stiffeners' if 'stiffener' in check['id'] else 'wheel_local_effects' if check['id'].startswith('wheel') else 'support_local_effects'
                out.checks.append(_ratio('prescriptive_local/'+c.id+'/'+str(i),mechanism,title,check['demand_kn'],check['capacity_kn'],check.get('unit','kN'),source,c.id,'Envelope conservador de cargas agrupadas; posição do trem '+f'{a:.3f}'+' m.',{'translation_m':a,**check},conservative=True))
            pending=list(dict.fromkeys(msg for row in local_records.values() for msg in row.get('pending',[])+row.get('resistance_pending',[])))
            local_ready=not pending and bool(local_records) and all(row.get('component_checks_calculated',False) for row in local_records.values())
            out.checks.append(_summary('coverage/local_8800/'+c.id,'support_local_effects','Cobertura dos mecanismos locais NBR 8800','NBR 8800, 5.7',c.id,local_ready,'; '.join(pending) or 'Cobertura dos mecanismos locais incompleta.'))
            if not local_ready:
                out.checks.append(Verification('prescriptive_local_domain/'+c.id,'support_local_effects','Domínio dos mecanismos locais NBR 8800','pending','NBR 8800, 5.7',c.id,reason='; '.join(pending) or 'Cobertura dos mecanismos locais incompleta.'))
        if c.family=='FAT8400':
            if fixed_flange_detail is None:
                if fullheight_enabled(p):
                    from .autonomous_fullheight_longitudinal import cjp_longitudinal_transfer
                    fixed_flange_detail=cjp_longitudinal_transfer(p,transverse_normal_bound_mpa=uls_transfer_z,shear_transfer_bound_mpa=uls_transfer_tau)
                else:fixed_flange_detail=design_flange_web_welds(p,transverse_normal_bound_mpa=uls_transfer_z,shear_transfer_bound_mpa=uls_transfer_tau)
                fixed_flange_detail.update(project_signature=out.input_signature,origin_case_ids=uls_origin_cases,transverse_normal_bound_mpa=uls_transfer_z,shear_transfer_bound_mpa=uls_transfer_tau)
                fixed_detail.update(project_signature=out.input_signature,origin_case_ids=list(uls_origin_cases))
                out.numerical_evidence['fixed_flange_web_weld_detail']=fixed_flange_detail
                if fixed_flange_detail.get('applicable'):
                    design=fixed_flange_detail.get('design') or fixed_flange_detail.get('limiting_design')
                    if design:
                        out.checks.append(_ratio('flange_web_weld','stiffeners','Soldas longitudinais alma–mesas',design['traction_resultant_bound_mpa'],design['capacity_mpa'],'MPa',fixed_flange_detail['source'],'Envelope ELU',evidence=fixed_flange_detail,conservative=True))
                    else:
                        out.checks.append(Verification('flange_web_weld','stiffeners','Soldas longitudinais alma–mesas','pending',fixed_flange_detail['source'],reason='Nenhum filete admissível nas espessuras atuais atende ao envelope ELU; alterar seção ou especificar outra ligação.',evidence=fixed_flange_detail))
            fatigue_analyses.append((c,sweep,local_records))
            local_records=None  # Exact completed trace is retained losslessly above.
        if c.family in ('I','III','ULS8800'):
            stability=evaluate_supplemental_en2025(p,c,sweep)
            out.numerical_evidence[c.id]['combined_stability']=stability
            out.checks.append(_summary('coverage/stability/'+c.id,'global_stability','Cobertura da estabilidade combinada',stability.get('method_adoption_source','NBR 8800, 4.1.1/4.2.2'),c.id,stability.get('member_check_complete',False) and stability.get('adopted_route_qualified',False),'; '.join(stability.get('pending',[])+stability.get('errors',[])) or 'Domínio da estabilidade não qualificado.'))
            for check in stability.get('checks',[]):
                out.checks.append(_ratio('stability/'+c.id+'/'+check['id'],'global_stability',check['name'],check['demand'],check['capacity'],check['unit'],stability.get('method_adoption_source',check['source']),c.id,check.get('formula',''),conservative=True))
            if not stability.get('member_check_complete',False):
                out.checks.append(Verification('stability_domain/'+c.id,'global_stability','Domínio da estabilidade combinada','pending',stability.get('source','EN 1993-1-1:2025 C.2'),c.id,reason='; '.join(stability.get('pending',[])+stability.get('errors',[])) or 'Modelo complementar não qualificado.'))
            if c.family=='ULS8800' and not stability.get('adopted_route_qualified',False):
                out.checks.append(Verification('stability_8800_adoption/'+c.id,'global_stability','Qualificação da rota complementar de estabilidade','pending','NBR 8800, 4.1.1 e 5.5.2.3',c.id,reason='; '.join(stability.get('pending',[])+stability.get('errors',[])) or 'As entradas atuais não satisfazem o domínio e as condições de segurança da rota racional complementar adotada.'))
        # Only FAT needs the complete cut registry after this case is audited.
        # Preserve every ULS maximum for the final common-detail panel checks.
        if c.family!='FAT8400':sweep.observer_sample_keys=()
        else:
            sweeps.pop(c.id)
            sweep=None
    for c in uls_cases:
        sweep=sweeps[c.id]
        if fullheight_enabled(p):
            from .autonomous_fullheight_static import fullheight_shear_verifications
            out.checks.extend(fullheight_shear_verifications(p,c,sweep,fixed_detail))
        if panel_config['qualified'] and 'combined_web_longitudinal_bound_mpa' in sweep.maxima:
            mx=lambda key:abs(sweep.maxima[key].value)
            gamma=p.material.gamma_a1
            energy=gamma*(mx('combined_web_longitudinal_bound_mpa')/panel_config['crx']+mx('local_transverse_bound_mpa')/panel_config['crz']+2*mx('combined_web_shear_bound_mpa')/math.sqrt(panel_config['crx']*panel_config['crz']))
            source='NBR 8800, 4.1.1/4.2.2; modelo racional de energia de placa elástica, margem gamma_a1.'
            out.checks.extend([
                _ratio('panel_energy/'+c.id,'local_stability','Flambagem biaxial do painel de alma — ELU',energy,1.,'adimensional',source,c.id,'Máximos uniformes separados dos componentes; sem crédito plástico.',panel_config,conservative=True),
                _ratio('panel_elastic/'+c.id,'local_stability','Domínio proporcional do painel de alma — ELU',gamma*mx('local_equivalent_bound_mpa')/panel_config['proportional'],1.,'adimensional',source,c.id,'Restrição conservadora ao regime proporcional do modelo de placa.',conservative=True)])
        elif not fullheight_enabled(p):
            out.checks.append(Verification('panel_domain/'+c.id,'local_stability','Apoio das bordas do painel de alma — ELU','pending','NBR 8800, 4.1.1/4.2.2',c.id,reason='Não foi qualificado o apoio das quatro bordas para o modelo de placa.'))
    if progress:progress(len(selected)-1,len(selected),'Consolidando a família de fadiga e auditando todos os casos…')
    fatigue=evaluate_fatigue_project_family(p,fatigue_analyses,fixed_flange_web_detail=fixed_flange_detail,fixed_stiffener_detail=fixed_detail)
    out.checks.extend(fatigue['verifications'])
    out.numerical_evidence['fatigue_family']={k:v for k,v in fatigue.items() if k!='verifications'}
    out.checks.append(_summary('coverage/fatigue_family','fatigue','Cobertura da vida inteira de fadiga','NBR 8400-2, Anexo D',FATIGUE_FAMILY,fatigue.get('complete',False),'; '.join(fatigue.get('pending',[])+fatigue.get('errors',[])) or 'Família de fadiga incompleta.'))
    for region in required_fatigue_regions(p):
        record=fatigue.get('regions',{}).get(region,{})
        ready=record.get('domain_complete') is True and (bool(record.get('checks')) or fullheight_enabled(p) and region=='fullheight_web_straight' and record.get('status')=='NOT_APPLICABLE_NO_STRAIGHT_INTERIOR') and not record.get('errors') and not record.get('domain_pending',record.get('pending',[]))
        out.checks.append(_summary('coverage/fatigue_region/'+region,'fatigue','Cobertura de fadiga: '+{'web_homogeneous':'alma','flange_nominal_homogeneous':'mesas','web_adjacent_fillet':'alma junto ao filete','flange_web_weld_throat':'garganta alma–mesa','stiffener_adjacent_base':'base junto ao enrijecedor','stiffener_plate_base':'chapas do enrijecedor','stiffener_weld_mesa':'solda enrijecedor–mesa','stiffener_weld_alma':'solda enrijecedor–alma'}.get(region,region),'NBR 8400-2, Anexo D',FATIGUE_FAMILY,ready,'; '.join(record.get('domain_pending',record.get('pending',[]))+record.get('errors',[])) or 'Região de fadiga sem avaliação completa.'))
    out.checks.append(_ratio('equilibrium','equilibrium','Equilíbrio global das respostas',equilibrium_max,1e-8,'relativo','Equilíbrio de forças e momentos, incluindo reações de travamentos','Todos os casos analisados'))
    out.numerical_evidence['scope']='Convergência numérica não equivale à qualificação normativa ou à verificação dos mecanismos faltantes.'
    return out
