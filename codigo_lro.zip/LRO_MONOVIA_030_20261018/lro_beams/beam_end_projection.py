"""Exact linear Vlasov condensation of unforced physical end projections.

Each projection is the SAME prismatic section, free at its physical outer end.
Its root is a fork (theta=0), with continuous warping rotation theta'. There
are no wheels, horizontal loads or externally applied torques on these tails.
Vertical self-weight bending is supplied separately by exact statics.

No user spring is introduced: Komega=ECw*k*tanh(k*a) follows by eliminating
ECw theta''''-GJ theta''=0 with B=T=0 at the physical free end. The existing
lateral/torque Green solver supplies the exact constrained 2x2 flexibility.
"""
from dataclasses import replace
from functools import lru_cache
import math
import sys
from .beam_torsion import (LateralTorqueLoad,solve_lateral_torsion,_number,
    _cholesky_solve,_log_cosh,_log_sinhc,_point_kernel,_bimoment_kernel,
    _uniform_kernel,_compatibility_roundoff_row,_brace_compatibility_roundoff_row)


def projection_warping_stiffness(beam,length_mm):
    _number(length_mm,'projection length')
    if length_mm<0:raise ValueError('Projection length must be nonnegative')
    value=beam.ECw*beam.k*math.tanh(beam.k*length_mm)
    if not math.isfinite(value):raise ValueError('Nonfinite projection warping stiffness')
    return value


@lru_cache(maxsize=128)
def _end_flexibility(beam,Iy,braces):
    ends=(0.,beam.span_mm);columns=[]
    for x in ends:
        unit=(LateralTorqueLoad(x,0.,0.,'Unit end warping couple',sectorial_couple_nmm2=1.),)
        solution=solve_lateral_torsion(beam,Iy,unit,braces)
        columns.append(tuple(solution.torsion.at(at).theta_prime_per_mm for at in ends))
    matrix=tuple(tuple(columns[j][i] for j in range(2)) for i in range(2))
    scale=max(abs(v) for row in matrix for v in row)
    if abs(matrix[0][1]-matrix[1][0])>1e-10*scale:
        raise ValueError('End warping flexibility lost reciprocity')
    cross=(matrix[0][1]+matrix[1][0])/2
    return ((matrix[0][0],cross),(cross,matrix[1][1]))


def _full_compatibility_roundoff_audit(beam,Iy,solution,braces,stiffness,couples):
    """Backward residuals of the ORIGINAL brace/end equations, before cancellation.

    A load at two rigid brace levels can be reacted completely at that station.
    Its end slope is then zero, although individual Green-response terms are
    not. Relative error divided by that cancelled response is not meaningful.
    Re-solving the braces after condensation also rounds the reactions anew.

    This audit does not change the solution or use a displacement/unit floor.
    Each equation is scaled by its own sum of absolute, uncombined terms. The
    gamma_n allowance is a conservative floating-point operation budget (32
    operations per term/brace, covering kernel evaluation and assembly), not
    a certified libm error bound. The existing response-relative test remains
    the primary test; this much smaller machine-precision allowance is used
    only when that test encounters cancellation. Every brace row must pass,
    so a small end residual alone cannot conceal a wrong restraint solution.
    """
    rows=[];torsion=solution.torsion
    for i,x in enumerate((0.,beam.span_mm)):
        if not stiffness[i]:continue
        terms=[p.torque_nmm*_point_kernel(beam,x,p.x_mm)[1] for p in torsion.point_torques]
        terms.extend(p.sectorial_couple_nmm2*_bimoment_kernel(beam,x,p.x_mm)[1]
                     for p in torsion.point_bimoments)
        if torsion.uniform_torque_nmm_per_mm:
            terms.append(torsion.uniform_torque_nmm_per_mm*_uniform_kernel(beam,x)[1])
        terms.append(couples[i]/stiffness[i])
        field_residual=math.fsum((torsion.at(x).theta_prime_per_mm,terms[-1]))
        rows.append(dict(kind='end_warping',index=i,x_mm=x,equation_units='1/mm',
            **_compatibility_roundoff_row(terms,field_residual,len(braces))))
    rows.extend(_brace_compatibility_roundoff_row(solution,b,i,len(braces)) for i,b in enumerate(braces))
    return rows


def solve_lateral_torsion_with_projections(beam,Iy_mm4,loads=(),braces=(),
        uniform_horizontal_n_per_mm=0.,uniform_torque_nmm_per_mm=0.,*,
        left_projection_mm=0.,right_projection_mm=0.):
    """Return (ordinary span solution, derived physical-projection evidence).

    All existing lateral braces remain active in the end-warping flexibility.
    Pure auxiliary end-sectorial loads are retained in torsion.point_bimoments
    but removed from .loads, which keeps the existing physical load-list API.
    Only the centered/no-torque tail domain is represented; a nonzero external
    distributed torque requires a tail load vector in addition to stiffness.
    """
    lengths=(left_projection_mm,right_projection_mm)
    stiffness=tuple(projection_warping_stiffness(beam,a) for a in lengths)
    loads,braces=tuple(loads),tuple(braces)
    if any(lengths) and (uniform_torque_nmm_per_mm!=0 or uniform_horizontal_n_per_mm!=0):
        raise ValueError('Horizontally/torsionally loaded projections require their own condensed load vector')
    basic=solve_lateral_torsion(beam,Iy_mm4,loads,braces,
        uniform_horizontal_n_per_mm,uniform_torque_nmm_per_mm)
    ends=(0.,beam.span_mm)
    initial=tuple(basic.torsion.at(x).theta_prime_per_mm for x in ends)
    active=[i for i,k in enumerate(stiffness) if k>0]
    couples=[0.,0.];flexibility=((0.,0.),(0.,0.));solution=basic
    if active:
        flexibility=_end_flexibility(beam,Iy_mm4,braces)
        matrix=[[flexibility[i][j]+(1/stiffness[i] if i==j else 0.) for j in active] for i in active]
        solved=_cholesky_solve(matrix,[-initial[i] for i in active])
        for i,value in zip(active,solved):couples[i]=value
        auxiliary=tuple(LateralTorqueLoad(ends[i],0.,0.,'Physical projection warping',sectorial_couple_nmm2=couples[i]) for i in active)
        solved_span=solve_lateral_torsion(beam,Iy_mm4,loads+auxiliary,braces,
            uniform_horizontal_n_per_mm,uniform_torque_nmm_per_mm)
        # Original loads precede the auxiliaries; brace loads are last.
        solution=replace(solved_span,loads=solved_span.loads[:len(loads)]+solved_span.loads[len(loads)+len(auxiliary):])
    slopes=tuple(solution.torsion.at(x).theta_prime_per_mm for x in ends)
    residuals=tuple(slopes[i]+couples[i]/stiffness[i] if stiffness[i] else 0. for i in range(2))
    roundoff_audit=None;roundoff_limited_ends=[]
    for i in active:
        scale=max(abs(initial[i]),abs(slopes[i]),abs(couples[i]/stiffness[i]),1e-30)
        if abs(residuals[i])>1e-9*scale:
            if roundoff_audit is None:
                roundoff_audit=_full_compatibility_roundoff_audit(beam,Iy_mm4,solution,braces,stiffness,couples)
            end_row=next(row for row in roundoff_audit if row['kind']=='end_warping' and row['index']==i)
            if abs(residuals[i])>end_row['roundoff_limit'] or not all(row['passed'] for row in roundoff_audit):
                raise ValueError('Physical projection warping compatibility did not close')
            roundoff_limited_ends.append(i)
    evidence=dict(complete=True,method='exact_unloaded_Vlasov_end_projection_condensation',
        lengths_mm=list(lengths),warping_stiffness_nmm3=list(stiffness),
        added_end_sectorial_couples_nmm2=couples,initial_end_slopes_per_mm=list(initial),
        end_slopes_per_mm=list(slopes),compatibility_residuals_per_mm=list(residuals),
        compatibility_audit=dict(response_relative_tolerance=1e-9,machine_epsilon=sys.float_info.epsilon,
            roundoff_limited_ends=roundoff_limited_ends,full_system_rows=roundoff_audit),
        constrained_end_flexibility_per_nmm3=[list(row) for row in flexibility],
        left=projection_torsion_at(beam,lengths[0],slopes[0],'left',0.) if lengths[0] else None,
        right=projection_torsion_at(beam,lengths[1],slopes[1],'right',0.) if lengths[1] else None,
        assumptions=['Mesma seção prismática; pontas físicas livres, B=T=0.',
                     'Sem rodas, forças horizontais ou torques externos nas projeções.',
                     'Flexão vertical e peso distribuído das projeções resolvidos separadamente.'])
    evidence['root_torsion_states']={name:dict(x_mm=ends[i],side=name,
        **{key:values[key] for key in ('theta_rad','theta_prime_per_mm','bimoment_nmm2',
            'saint_venant_torque_nmm','warping_torque_nmm','total_torque_nmm')})
        for i,name in enumerate(('left','right')) if (values:=evidence[name]) is not None}
    return solution,evidence


def projection_torsion_at(beam,length_mm,root_slope_per_mm,side,distance_from_fork_mm):
    """Physical tail field, global x signs, from its computed root slope."""
    projection_warping_stiffness(beam,length_mm)
    _number(root_slope_per_mm,'root warping slope');_number(distance_from_fork_mm,'distance from fork')
    if side not in ('left','right') or not 0<=distance_from_fork_mm<=length_mm:
        raise ValueError('Invalid physical projection station')
    a,u,k=length_mm,distance_from_fork_mm,beam.k;s=root_slope_per_mm
    direction=-1. if side=='left' else 1.
    c=math.exp(_log_cosh(k*(a-u))-_log_cosh(k*a))
    sinh_ratio=k*(a-u)*math.exp(_log_sinhc(k*(a-u))-_log_cosh(k*a))
    theta=direction*s*u*math.exp(_log_cosh(k*(a-u/2))+_log_sinhc(k*u/2)-_log_cosh(k*a))
    B=direction*beam.ECw*k*s*sinh_ratio
    Ts=beam.GJ*s*c
    return dict(side=side,distance_from_fork_mm=u,theta_rad=theta,theta_prime_per_mm=s*c,
        bimoment_nmm2=B,saint_venant_torque_nmm=Ts,warping_torque_nmm=-Ts,total_torque_nmm=0.)


def projection_flexure_reference_bound(beam,Iy_mm4,length_mm,vertical_down_n_per_mm,load_height_mm):
    """Sufficient elastic coefficient for a wheel-free self-weight projection.

    Root theta=0; its lateral flexural slope is deliberately unrestrained.
    Poincare with ONE zero gives ||theta|| <= 2a/pi ||theta'||. Cauchy bounds
    2 int M v'' theta by 2a Mmax/(pi sqrt(EIy GJ)) times elastic energy.
    The positive load-height term is bounded by qz(2a/pi)^2/GJ times energy.
    Main-span and tail energies add; use the MAX of their geometric/elastic
    coefficients, equivalently the MIN of their critical-factor lower bounds.
    This is a reference-mode bound, not an independent section resistance.
    """
    _number(Iy_mm4,'Iy',True);projection_warping_stiffness(beam,length_mm)
    _number(vertical_down_n_per_mm,'projection vertical load');_number(load_height_mm,'load height')
    if vertical_down_n_per_mm<0:raise ValueError('Projection load must be nonnegative')
    a=length_mm;q=vertical_down_n_per_mm;M=q*a*a/2
    moment=2*a*M/(math.pi*math.sqrt(beam.E_mpa*Iy_mm4*beam.GJ))
    height=max(0.,q*load_height_mm)*(2*a/math.pi)**2/beam.GJ
    mu=(moment+height)*(1+1e-10)
    if not math.isfinite(mu):raise ValueError('Nonfinite projection stability bound')
    return dict(length_mm=a,major_moment_bound_nmm=M,moment_energy_coefficient=moment,
        height_energy_coefficient=height,inverse_factor_upper_bound=mu,
        load_factor_lower_bound=1/mu if mu else None,
        combination='lambda_combined_lower=min(lambda_span_lower,lambda_left_lower,lambda_right_lower)',
        scope='pure-flexure reference; root fork; free physical tip; no wheel or axial/torsional tail loading')
