"""Selected practical FLT method under NBR 8400-2:2019 §5.3.

Elastic critical moment: JRC/CTICM/SCI NCCI SN003a-EN-EU Eq. (1)/(2), k=kw=1.
Branch-domain qualification: NBR 8800:2024 D.2.1 alternative lambda_LT curve.
Explicit routes cover bounded short/elastic branches, an adopted full-curve
omega method, and its qualified N=0 torque-free biaxial interaction. No gamma_a1
substitution is made. Result is partial.
"""
from __future__ import annotations
from dataclasses import asdict, dataclass, fields
import math
from typing import Any, get_type_hints
from .stress_8400 import NU_E, elastic_allowables_8400, _check

NUMERIC_LIMITS = {'I_w_mm6':1e30,'I_weak_mm4':1e20,'I_t_mm4':1e20,'W_major_mm3':1e15,'W_minor_mm3':1e15,'Z_major_mm3':1e15}

NCCI_SOURCE = 'CTICM/SCI NCCI SN003a-EN-EU, Eq. (1)/(2), Tabela 3.2 (cópia oficial JRC)'
PATTERNS = {
    'udl': {'C1':1.127,'C2':.454,'description':'Carga uniforme ao longo de todo o vão, momentos de extremidade nulos.'},
    'midspan_point': {'C1':1.348,'C2':.630,'description':'Uma única carga concentrada no meio do vão, momentos de extremidade nulos.'},
    'external_coefficients': {'description':'C1/C2 fornecidos externamente; aplicabilidade ao caso real atestada por relatório.'},
}

@dataclass
class FLT8400Input:
    name: str = 'FLT por método prático qualificado'
    segment_name: str = ''
    load_case: str = 'I'
    fy_mpa: float = 0.0
    fu_mpa: float = 0.0
    E_mpa: float = 210000.0
    G_mpa: float = 80770.0
    I_weak_mm4: float = 0.0
    I_t_mm4: float = 0.0
    I_w_mm6: float = 0.0
    W_major_mm3: float = 0.0
    W_minor_mm3: float = 0.0
    Z_major_mm3: float = 0.0
    unrestrained_length_mm: float = 0.0
    load_height_mm: float = 0.0
    moment_major_knm: float = 0.0
    moment_minor_knm: float = 0.0
    axial_force_kn: float = 0.0
    torsion_knm: float = 0.0
    bimoment_knm2: float = 0.0
    load_pattern: str = 'unqualified'
    resistance_route: str = 'bounded_elastic'
    external_C1: float = 0.0
    external_C2: float = 0.0
    section_symmetry: str = 'unqualified'
    action_basis: str = 'unqualified'
    material_source: str = ''
    properties_source: str = ''
    action_source: str = ''
    factors_source: str = ''
    restraint_source: str = ''
    load_pattern_source: str = ''
    load_height_source: str = ''
    compact_section_source: str = ''
    method_selection_source: str = ''
    coefficient_source: str = ''
    omega_method_source: str = ''
    biaxial_method_source: str = ''
    torsion_warping_source: str = ''
    major_pattern_id: str = ''
    minor_pattern_id: str = ''
    critical_pattern_id: str = ''
    action_case_qualified: bool = False
    factors_already_applied: bool = False
    straight_uniform_member_confirmed: bool = False
    fork_supports_confirmed: bool = False
    free_warping_confirmed: bool = False
    restraint_strength_stiffness_verified: bool = False
    section_properties_qualified: bool = False
    compact_section_confirmed: bool = False
    actual_load_pattern_confirmed: bool = False
    single_load_height_confirmed: bool = False
    load_height_sign_confirmed: bool = False
    zero_end_moments_confirmed: bool = False
    practical_method_selected: bool = False
    omega_curve_method_qualified: bool = False
    biaxial_method_qualified: bool = False
    same_pattern_segment_envelope_confirmed: bool = False
    no_torsion_warping_load_path_confirmed: bool = False
    minor_axis_compactness_confirmed: bool = False
    high_ratio_route_confirmed: bool = False
    external_coefficients_qualified: bool = False
    external_normalization_confirmed: bool = False
    load_height_not_duplicated_confirmed: bool = False


def _finite(value: Any, *, positive: bool=False) -> bool:
    # Iw naturally exceeds 1e12 mm6 for ordinary runway sections.
    if type(value) not in (int,float): return False
    try:
        return math.isfinite(value) and abs(value)<=1e30 and (value==0 or abs(value)>=1e-12) and (not positive or value>0)
    except (ValueError,OverflowError): return False


def _typed_errors(data: Any) -> list[str]:
    if not isinstance(data,FLT8400Input):return ['Entrada deve ser FLT8400Input.']
    errors=[]
    annotations=get_type_hints(FLT8400Input)
    for field in fields(FLT8400Input):
        value=getattr(data,field.name); expected=annotations[field.name]
        if expected is str and not isinstance(value,str):errors.append(f'{field.name}: texto obrigatório.')
        if expected is bool and type(value) is not bool:errors.append(f'{field.name}: booleano obrigatório.')
        if expected is float and (not _finite(value) or abs(value)>NUMERIC_LIMITS.get(field.name,1e12)):
            errors.append(f'{field.name}: magnitude numérica inválida; conferir unidade.')
    return errors


def elastic_mcr_ncci(*, E_mpa: float, G_mpa: float, I_weak_mm4: float,
                     I_t_mm4: float, I_w_mm6: float, length_mm: float,
                     load_height_mm: float, C1: float, C2: float) -> dict[str,float]:
    """Numerical Eq. (1), k=kw=1; no applicability assertion. Mcr in Nmm.

    zg is positive when the force points from its application point toward the
    shear centre (gravity above centre), negative on the opposite side.
    C1/C2 must refer to this equation, without already including height effects.
    """
    for value in (E_mpa,G_mpa,I_weak_mm4,I_t_mm4,I_w_mm6,length_mm,C1):
        if not _finite(value,positive=True):raise ValueError('Propriedades, L e C1 devem ser finitos positivos nas unidades indicadas.')
    if not _finite(load_height_mm) or not _finite(C2):raise ValueError('zg e C2 devem ser finitos.')
    try:
        prefactor=C1*math.pi**2*E_mpa*I_weak_mm4/length_mm**2
        a=I_w_mm6/I_weak_mm4+length_mm**2*G_mpa*I_t_mm4/(math.pi**2*E_mpa*I_weak_mm4)
        b=C2*load_height_mm
        root=math.hypot(math.sqrt(a),b)
        arm=a/(root+b) if b>=0 else root-b
        critical=prefactor*arm
    except (OverflowError,ZeroDivisionError,ValueError) as exc:
        raise ValueError('Grandezas derivadas fora do domínio computacional de Mcr.') from exc
    if not all(math.isfinite(v) and v>0 for v in (a,arm,critical)):
        raise ValueError('Mcr ou grandezas derivadas não finitas/positivas.')
    return {'A_mcr_mm2':a,'B_mcr_mm':b,'height_arm_mm':arm,'Mcr_nmm':critical,'Mcr_knm':critical/1e6,'C1':C1,'C2':C2,'k':1.0,'kw':1.0}


def flt_branch_8400(lambda_lt: float) -> str:
    """Exact D.2.1 intervals: 0.4 in plateau; 1.4 in unsupported middle."""
    if not _finite(lambda_lt,positive=True):raise ValueError('lambda_LT deve ser finito positivo.')
    if lambda_lt<=.4:return 'short_plateau'
    if lambda_lt>1.4:return 'elastic_long'
    return 'unsupported_intermediate'


def chi_flt_8800(lambda_lt: float) -> float:
    """Exact 8800 D.2.1 alternative nominal curve, not an 8400 formula.

    Preserve its small discontinuity just above 1.4; do not repair coefficients.
    Applicability and adoption as omega must be qualified separately.
    """
    if not _finite(lambda_lt,positive=True):raise ValueError('lambda_LT deve ser finito positivo.')
    if lambda_lt<=.4:return 1.0
    if lambda_lt<=1.4:return 1-.49*(lambda_lt-.4)
    return 1/lambda_lt**2


def calculate_flt_8400(data: FLT8400Input) -> dict[str,Any]:
    result={'kind':'flt_practical_8400','source':'NBR 8400-2:2019, 5.3; método prático declarado NCCI SN003a + NBR 8800:2024 D.2.1',
        'input_valid':True,'status':'PENDENTE','full_compliance':False,'errors':[],'pending':[],'checks':[],'intermediates':{},
        'limitations':[
            'Resultado parcial da FLT do trecho/caso; não aprova integralmente a viga.',
            'Método prático de origem declarada: não é equação nativa de FLT da NBR 8400 nem conversão de esforços ELU.',
            'bounded_elastic exclui 0,4 < lambda_LT <= 1,4; adopted_omega_curve exige adoção adicional explícita da curva nominal como método omega, não uma curva nativa 8400.',
            'Requer I duplamente simétrico compacto, reto/prismático, N=T=bimomento=0; My somente na opção biaxial adotada; apoios tipo garfo com empenamento livre.',
            'C1/C2 tabelados valem apenas para todo o vão com carga uniforme ou uma única carga central; não valem automaticamente para rodas móveis ou mistura de cargas.',
            'Coeficientes externos exigem relatório do caso real, normalização e altura única; não constituem um preset de trem de rodas.',
            'Estabilidade local, ação de roda/patch, fadiga, resistência das contenções e demais casos permanecem verificações separadas.',
        ]}
    errors=_typed_errors(data)
    if errors:
        result.update(input_valid=False,status='ENTRADA INVÁLIDA',errors=errors);return result
    for field in ('fy_mpa','fu_mpa','E_mpa','G_mpa','I_weak_mm4','I_t_mm4','I_w_mm6','W_major_mm3','Z_major_mm3','unrestrained_length_mm'):
        if getattr(data,field)<=0:errors.append(f'{field}: informar valor positivo.')
    if data.resistance_route=='adopted_biaxial_omega' and data.W_minor_mm3<=0:errors.append('W_minor_mm3: módulo elástico minoritário positivo obrigatório na rota biaxial.')
    if data.fu_mpa<data.fy_mpa:errors.append('fu não pode ser inferior a fy.')
    if data.Z_major_mm3<data.W_major_mm3:errors.append('Módulo plástico Z deve ser >= módulo elástico W.')
    if data.load_case not in NU_E:errors.append('Caso deve ser I, II ou III.')
    if data.load_pattern=='external_coefficients' and data.external_C1<=0:errors.append('C1 externo deve ser positivo.')
    if errors:
        result.update(input_valid=False,status='ENTRADA INVÁLIDA',errors=errors);return result
    result['input']=asdict(data)
    biaxial=data.resistance_route=='adopted_biaxial_omega'
    if data.section_symmetry!='doubly_symmetric_i' or any(v!=0 for v in (data.axial_force_kn,data.torsion_knm,data.bimoment_knm2)) or (data.moment_minor_knm!=0 and not biaxial):
        result['status']='FORA DO DOMÍNIO';result['pending'].append('Exige I duplamente simétrico com N=T=bimomento=0; My exige a opção biaxial adotada. Não omitir efeitos existentes.');return result
    if data.load_pattern not in PATTERNS:
        result['status']='FORA DO DOMÍNIO';result['pending'].append('Padrão não qualificado: selecionar um dos dois padrões exatos ou coeficientes externos rastreáveis.');return result
    if data.resistance_route not in ('bounded_elastic','adopted_omega_curve','adopted_biaxial_omega'):
        result['status']='FORA DO DOMÍNIO';result['pending'].append('Selecionar bounded_elastic, adopted_omega_curve ou adopted_biaxial_omega.');return result
    if data.action_basis!='nbr8400_cases':result['pending'].append('Exige ações próprias dos casos I/II/III, sem conversão ELU 8800.')
    sources={
        'material_source':'Material, fy, fu, E e G aplicáveis.',
        'properties_source':'Propriedades reais I fraco, It, Iw, W e Z; sem composição assimétrica do trilho não qualificada.',
        'action_source':'Caso/combinação, posição do equipamento e diagrama de momentos assinado.',
        'factors_source':'Fatores de ação/dinâmica já incluídos exatamente uma vez.',
        'restraint_source':'Geometria, rigidez, resistência e ancoragem dos apoios do trecho.',
        'load_pattern_source':'Padrão completo real de cargas e momentos de extremidade.',
        'load_height_source':'Plano, altura e sentido reais da carga em relação ao centro de cisalhamento.',
        'compact_section_source':'Critério/fonte e verificação da compacidade das mesas e alma.',
        'method_selection_source':'Seleção justificada do método prático pelo responsável, incluindo domínio de esbeltez.',
    }
    for field,message in sources.items():
        if not getattr(data,field).strip():result['pending'].append(message)
    flags={
        'action_case_qualified':'Qualificar caso I/II/III.',
        'factors_already_applied':'Confirmar fatores aplicados uma única vez.',
        'straight_uniform_member_confirmed':'Confirmar barra reta e seção constante.',
        'fork_supports_confirmed':'Confirmar contenção lateral e à rotação de torção nas duas extremidades, k=1.',
        'free_warping_confirmed':'Confirmar empenamento livre nas extremidades, kw=1.',
        'restraint_strength_stiffness_verified':'Qualificar rigidez, resistência e ancoragem das contenções.',
        'section_properties_qualified':'Qualificar propriedades efetivas da seção para o método.',
        'compact_section_confirmed':'Qualificar seção compacta para o uso da curva alternativa de referência.',
        'actual_load_pattern_confirmed':'Qualificar padrão real de cargas e momentos com os coeficientes adotados.',
        'single_load_height_confirmed':'Confirmar altura única compatível com as cargas transversais do padrão.',
        'load_height_sign_confirmed':'Qualificar zg positivo para carga dirigida ao centro de cisalhamento (gravidade acima), negativo no sentido oposto.',
        'practical_method_selected':'Confirmar seleção justificada desta rota prática; não é aceite automático pelo aplicativo.',
    }
    if data.load_pattern!='external_coefficients':flags['zero_end_moments_confirmed']='Os presets exigem momentos de extremidade nulos no vão inteiro.'
    else:
        if not data.coefficient_source.strip():result['pending'].append('Identificar relatório/fonte de C1/C2, padrão, momentos de extremidade, geometria, apoios e convenções da Eq. (1).')
        flags.update(external_coefficients_qualified='Qualificar externamente C1/C2 para o padrão/trecho real; não copiar coeficientes de uma roda central para várias rodas.',
            external_normalization_confirmed='Confirmar sinais e normalização de C1/C2 segundo SN003a Eq. (1).',
            load_height_not_duplicated_confirmed='Confirmar que o efeito da altura não já está incluído em C1/C2 e não será duplicado.')
    if data.resistance_route in ('adopted_omega_curve','adopted_biaxial_omega'):
        if not data.omega_method_source.strip():result['pending'].append('Registrar adoção justificada de chi D.2.1 como método omega de 8400 §5.3; Mcr elástico permitido por 8800 D.2.8 k).')
        flags['omega_curve_method_qualified']='Qualificar explicitamente a curva nominal adotada, omega>=1 e remoção do crédito de plastificação por fyW.'
    if biaxial:
        if not data.segment_name.strip():result['pending'].append('Identificar o mesmo trecho destravado para a interação biaxial.')
        pattern_ids=(data.major_pattern_id.strip(),data.minor_pattern_id.strip(),data.critical_pattern_id.strip())
        if not all(pattern_ids) or len(set(pattern_ids))!=1:result['pending'].append('Mx, My e Mcr devem identificar o mesmo padrão físico de carregamento; IDs não vazios e iguais são obrigatórios.')
        if not data.biaxial_method_source.strip():result['pending'].append('Registrar adoção de 8800 5.5.1.2(b), N=0, com capacidades elásticas/omega e margem comum 8400.')
        if not data.torsion_warping_source.strip():result['pending'].append('Demonstrar caminho real das ações sem torção/empenamento; força horizontal elevada no trilho normalmente introduz torque.')
        flags.update(biaxial_method_qualified='Qualificar explicitamente o método prático de interação biaxial adotado.',
            same_pattern_segment_envelope_confirmed='Confirmar máximos de |Mx| e |My| em todo o mesmo trecho e padrão físico, com Mcr aplicável a esse padrão.',
            no_torsion_warping_load_path_confirmed='Demonstrar ausência real de torção, bimomento, giro imposto e ações de empenamento; campos zero não bastam.',
            minor_axis_compactness_confirmed='Qualificar compacidade da mesa também para flexão minoritária; bf/(2tf)<=0,38sqrt(E/fy), conforme critério de origem.')
    for field,message in flags.items():
        if not getattr(data,field):result['pending'].append(message)
    if data.fy_mpa/data.fu_mpa>.7 and not data.high_ratio_route_confirmed:
        result['pending'].append('Qualificar rota 5.2.1.1.2 de material com fy/fu>0,70.')
    if result['pending']:return result
    try: allow=elastic_allowables_8400(data.fy_mpa,data.fu_mpa,data.load_case)
    except ValueError as exc:
        result['status']='FORA DO DOMÍNIO';result['pending'].append(str(exc));return result
    if data.moment_major_knm==0 and (not biaxial or data.moment_minor_knm==0):
        result['pending'].append('Momento nulo nesta linha: não há verificação de FLT com solicitação; conferir os demais casos.');return result
    coefficients=PATTERNS[data.load_pattern]
    c1=data.external_C1 if data.load_pattern=='external_coefficients' else coefficients['C1']
    c2=data.external_C2 if data.load_pattern=='external_coefficients' else coefficients['C2']
    try:
        core=elastic_mcr_ncci(E_mpa=data.E_mpa,G_mpa=data.G_mpa,I_weak_mm4=data.I_weak_mm4,I_t_mm4=data.I_t_mm4,I_w_mm6=data.I_w_mm6,
            length_mm=data.unrestrained_length_mm,load_height_mm=data.load_height_mm,C1=c1,C2=c2)
        mpl=data.fy_mpa*data.Z_major_mm3/1e6
        slender=math.sqrt(mpl/core['Mcr_knm'])
        branch=flt_branch_8400(slender)
    except (ValueError,OverflowError,ZeroDivisionError) as exc:
        result.update(input_valid=False,status='ENTRADA INVÁLIDA',errors=[str(exc)]);return result
    material_cap=allow['sigma_a_mpa']*data.W_major_mm3/1e6
    residual_bound=.7*data.fy_mpa*data.W_major_mm3/1e6
    result['intermediates']={**core,**allow,'Mpl_knm':mpl,'lambda_lt':slender,'branch':branch,
        'moment_major_signed_knm':data.moment_major_knm,'material_moment_cap_knm':material_cap,'resistance_route':data.resistance_route,
        'elastic_residual_bound_knm':residual_bound,'elastic_residual_bound_applies':data.resistance_route=='bounded_elastic',
        'coefficient_basis': 'Coeficientes fornecidos externamente; aplicabilidade atestada.' if data.load_pattern=='external_coefficients' else NCCI_SOURCE}
    if data.resistance_route=='bounded_elastic' and branch=='unsupported_intermediate':
        result['status']='FORA DO DOMÍNIO';result['pending'].append('0,4 < lambda_LT <= 1,4: ramo intermediário/inelástico não qualificado; não interpolar nem substituir gamma_a1 por nu_E.');return result
    if data.resistance_route=='bounded_elastic' and branch=='elastic_long' and core['Mcr_knm']>residual_bound:
        result['status']='FORA DO DOMÍNIO';result['pending'].append('Limite adicional conservador Mcr <= 0,7 fy W não satisfeito; rota elástica restrita.');return result
    if data.resistance_route in ('adopted_omega_curve','adopted_biaxial_omega'):
        chi=chi_flt_8800(slender)
        yield_moment=data.fy_mpa*data.W_major_mm3/1e6
        nominal=min(chi*mpl,yield_moment)
        omega=yield_moment/nominal
        nominal_cap=nominal/allow['nu_e']
        omega_cap=material_cap/omega
        capacity=min(nominal_cap,omega_cap)
        formula='Rnom=min(chi(lambda_LT)*Mpl,fy*W); omega=fy*W/Rnom>=1; M_adm=min(Rnom/nu_E,sigma_a,8400*W/omega)'
        result['intermediates'].update(chi_flt=chi,yield_elastic_moment_knm=yield_moment,
            nominal_reduced_moment_knm=nominal,omega_flt=omega,nominal_over_nu_cap_knm=nominal_cap,omega_stress_cap_knm=omega_cap,
            branch='adopted_omega_'+('intermediate' if branch=='unsupported_intermediate' else branch),
            omega_method_basis='Inferência de engenharia explicitamente adotada: 8400 §5.3; 8800 D.2.1/D.2.8 k); sem crédito plástico e sem gamma_a1.')
    elif branch=='short_plateau':
        capacity=material_cap
        formula='lambda_LT=sqrt(Mpl/Mcr)<=0,4; condição suficiente adotada: M_adm=sigma_a,8400*W'
    else:
        capacity=min(core['Mcr_knm']/allow['nu_e'],material_cap)
        formula='lambda_LT>1,4 e Mcr<=0,7fyW; M_adm=min(Mcr/nu_E, sigma_a,8400*W)'
    result['intermediates']['allowable_moment_knm']=capacity
    clause=('5.3 (omega); método NCCI SN003a Eq. (1)/(2) + NBR 8800:2024 D.2.1/D.2.8 k) (curva nominal adotada)'
            if data.resistance_route in ('adopted_omega_curve','adopted_biaxial_omega') else
            '5.3; método NCCI SN003a Eq. (1)/(2) + NBR 8800:2024 D.2.1 (domínio)')
    check=_check('flt_practical','FLT do trecho: método prático delimitado',abs(data.moment_major_knm),capacity,formula,clause)
    check['unit']='kN.m'
    result['checks']=[check]
    if biaxial:
        alpha=min(1/allow['nu_e'],allow['sigma_a_mpa']/data.fy_mpa)
        minor_capacity=alpha*data.fy_mpa*data.W_minor_mm3/1e6
        major_term=abs(data.moment_major_knm)/capacity
        minor_term=abs(data.moment_minor_knm)/minor_capacity
        interaction=major_term+minor_term
        minor_check=_check('minor_axis_flexure','Flexão minoritária: teto elástico com margem comum',abs(data.moment_minor_knm),minor_capacity,
            'alpha=min(1/nu_E,sigma_a,8400/fy); Cy=alpha*fy*Wy','5.2.1.1/5.3; método prático NBR 8800:2024 5.5.1.2(b), N=0')
        minor_check['unit']='kN.m'
        check=_check('biaxial_flexure_interaction','Interação de flexão biaxial do trecho, sem N/torção',interaction,1.,
            'U=|Mx|/Cx+|My|/Cy<=1; Cx=alpha*min(chi*Mplx,fy*Wx); Cy=alpha*fy*Wy',
            '5.3; método prático declarado NBR 8800:2024 5.5.1.1/5.5.1.2(b), N=0, e D.2.1/D.2.8 k)')
        check['unit']='adimensional'
        result['checks'].extend([minor_check,check])
        result['intermediates'].update(alpha_common=alpha,allowable_major_moment_knm=capacity,allowable_minor_moment_knm=minor_capacity,
            moment_minor_signed_knm=data.moment_minor_knm,major_utilization_term=major_term,minor_utilization_term=minor_term,
            biaxial_interaction=interaction,elastic_longitudinal_corner_envelope_mpa=(abs(data.moment_major_knm)/data.W_major_mm3+abs(data.moment_minor_knm)/data.W_minor_mm3)*1e6,
            pattern_id=data.major_pattern_id.strip(),
            biaxial_method_basis='Adaptação explícita do caso N=0 de 8800 5.5.1.2(b); capacidades com mesmo alpha; Mcr é uniaxial majoritário, não autovalor biaxial simultâneo.')
        result['limitations'].append('Mx/Wx e My/Wy contribuem para a MESMA tensão longitudinal; não são duas tensões normais ortogonais. Combinar sinais e efeitos locais no ponto físico separadamente.')
    result['status']='RESULTADO PARCIAL — NÃO ATENDE' if check['status']=='NÃO ATENDE' else 'RESULTADO PARCIAL'
    return result
