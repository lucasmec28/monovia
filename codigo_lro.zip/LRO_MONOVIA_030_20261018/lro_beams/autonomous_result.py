"""Fail-closed outcome contract for the autonomous calculation.

A calculated scalar demand is not complete member verification. Every required
mechanism has a positive computation record or a physical non-applicability
reason; a missing record never acquires an implicit success status.
"""
from dataclasses import dataclass,field,asdict
import hashlib,json,math

REQUIRED_MECHANISMS=(
    'actions','equilibrium','moving_envelope','vertical_bending','horizontal_bending',
    'axial_force','torsion_warping','combined_yield','global_stability','local_stability',
    'wheel_local_effects','support_local_effects','stiffeners','fatigue',
    'vertical_service','horizontal_service','rail_service',
)

@dataclass(frozen=True)
class Verification:
    id:str
    mechanism:str
    title:str
    state:str # calculated / not_applicable / pending / unsupported
    source:str
    case:str=''
    demand:float|None=None
    capacity:float|None=None
    unit:str=''
    utilization:float|None=None
    reason:str=''
    evidence:dict=field(default_factory=dict)
    def __post_init__(self):
        if self.mechanism not in REQUIRED_MECHANISMS:raise ValueError('Mecanismo de verificação desconhecido.')
        if self.state not in ('calculated','not_applicable','pending','unsupported'):raise ValueError('Estado inválido.')
        if not self.id or not self.title:raise ValueError('Identificação da verificação ausente.')
        if self.state in ('calculated','not_applicable') and not self.source:raise ValueError('Fonte ausente.')
        if self.state!='calculated' and not self.reason:raise ValueError('Justificativa ausente.')
        for name in ('demand','capacity','utilization'):
            value=getattr(self,name)
            if value is not None and (isinstance(value,bool) or not isinstance(value,(int,float)) or not math.isfinite(value)):
                raise ValueError('Resultado numérico inválido.')
        if not isinstance(self.evidence,dict):raise ValueError('Evidência de verificação inválida.')
        if self.state=='calculated' and self.utilization is None and self.evidence.get('verification_complete') is not True:
            raise ValueError('Verificação calculada sem comparação nem conclusão técnica.')
        if self.utilization is not None and self.utilization<0:raise ValueError('Utilização negativa.')
        if self.capacity is not None and self.capacity<=0:raise ValueError('Resistência não positiva.')
    @property
    def verdict(self):
        if self.state=='calculated':return 'ATENDE' if self.utilization is None or self.utilization<=1+1e-10 else 'NÃO ATENDE'
        return {'pending':'PENDENTE','unsupported':'FORA DO DOMÍNIO','not_applicable':'NÃO SE APLICA'}[self.state]


def input_signature(project):
    return hashlib.sha256(json.dumps(project.to_dict(),sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()

@dataclass
class AutonomousResult:
    input_signature:str
    checks:list[Verification]=field(default_factory=list)
    errors:list[str]=field(default_factory=list)
    assumptions:list[str]=field(default_factory=list)
    cases:list[dict]=field(default_factory=list)
    properties:dict=field(default_factory=dict)
    response_summary:dict=field(default_factory=dict)
    numerical_evidence:dict=field(default_factory=dict)
    # Declared independently from computed rows. An empty/default declaration
    # never establishes complete coverage, even if every broad mechanism occurs.
    required_check_ids:list[str]=field(default_factory=list)
    required_check_scopes:dict=field(default_factory=dict)
    def declare_required_checks(self,requirements):
        rows=list(requirements);scopes={}
        if not rows:raise ValueError('Matriz de obrigações vazia.')
        for row in rows:
            if not isinstance(row,dict) or not isinstance(row.get('id'),str) or not row['id']:
                raise ValueError('Identificação da obrigação ausente.')
            if row['id'] in scopes:raise ValueError('Obrigações duplicadas.')
            if row.get('mechanism') not in REQUIRED_MECHANISMS or not isinstance(row.get('case',''),str):
                raise ValueError('Escopo de obrigação inválido.')
            if type(row.get('summary',False)) is not bool or type(row.get('allow_not_applicable',False)) is not bool:
                raise ValueError('Declaração de obrigação inválida.')
            scopes[row['id']]={'mechanism':row['mechanism'],'case':row.get('case',''),
                'summary':row.get('summary',False),'allow_not_applicable':row.get('allow_not_applicable',False)}
        self.required_check_ids=[row['id'] for row in rows]
        self.required_check_scopes=scopes
        return self
    @property
    def coverage_declared(self):
        return bool(self.required_check_ids) and len(set(self.required_check_ids))==len(self.required_check_ids) and set(self.required_check_ids)==set(self.required_check_scopes)
    @property
    def missing_required_checks(self):
        present={c.id for c in self.checks}
        return [id_ for id_ in self.required_check_ids if id_ not in present]
    @property
    def coverage_issues(self):
        if not self.coverage_declared:return [{'id':'coverage_declaration','reason':'Matriz independente de obrigações não declarada.'}]
        rows={};issues=[]
        for c in self.checks:
            if c.id in rows:issues.append({'id':c.id,'reason':'Identificação de verificação duplicada.'})
            rows[c.id]=c
        for id_ in self.required_check_ids:
            expected=self.required_check_scopes[id_];c=rows.get(id_)
            if c is None:issues.append({'id':id_,'reason':'Verificação obrigatória ausente.'});continue
            if c.mechanism!=expected.get('mechanism') or c.case!=expected.get('case'):
                issues.append({'id':id_,'reason':'Registro pertence a outro mecanismo ou caso.'});continue
            if c.state=='not_applicable':
                if not expected.get('allow_not_applicable',False):issues.append({'id':id_,'reason':'Obrigação física não admite dispensa por outro registro.'})
            elif c.state!='calculated':issues.append({'id':id_,'reason':'Obrigação ainda pendente ou fora do domínio.'})
            elif expected.get('summary') and c.evidence.get('verification_complete') is not True:
                issues.append({'id':id_,'reason':'Sumário não demonstra cobertura integral do seu escopo.'})
        return issues
    @property
    def missing_mechanisms(self):
        return [m for m in REQUIRED_MECHANISMS if not any(c.mechanism==m for c in self.checks)]
    @property
    def complete(self):
        return not self.errors and not self.missing_mechanisms and not self.coverage_issues and all(c.state in ('calculated','not_applicable') for c in self.checks)
    @property
    def status(self):
        if self.errors:return 'ENTRADAS INVÁLIDAS'
        if any(c.verdict=='NÃO ATENDE' for c in self.checks):return 'NÃO ATENDE AO MODELO ADOTADO'+(' · VERIFICAÇÃO INCOMPLETA' if not self.complete else '')
        if not self.complete:return 'VERIFICAÇÃO INCOMPLETA'
        return 'ATENDE AO MODELO DECLARADO'
    def validate_current(self,project):
        if self.input_signature!=input_signature(project):raise ValueError('As entradas mudaram. Recalcule antes de exportar os resultados.')
        if len({c.id for c in self.checks})!=len(self.checks):raise ValueError('Identificações de verificações duplicadas.')
        return self
    def to_dict(self):
        return {**asdict(self),'status':self.status,'complete':self.complete,'missing_mechanisms':self.missing_mechanisms,'coverage_declared':self.coverage_declared,
                'missing_required_checks':self.missing_required_checks,'coverage_issues':self.coverage_issues}
