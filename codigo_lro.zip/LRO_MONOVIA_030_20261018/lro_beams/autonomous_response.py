"""Concurrent first-order beam response for the autonomous runway model.

This layer solves mechanics only. Case coefficients must be supplied by the
source-backed action module; it never supplies default safety factors. It does
not turn a mechanical solution into a normative approval.
"""
from __future__ import annotations
from dataclasses import dataclass,asdict,field
import math
from .autonomous_model import AutonomousProject,validate_autonomous
from .geometry import section_properties
from .autonomous_lateral_restraints import physical_lateral_braces
from .autonomous_restraint_mode import analysis_brace_positions
from .moving_beam import BeamModel,PointLoad,MovingWheel,UniformLoad,translate_train,solve_position,scan_moving_train,SearchTolerance
from .beam_torsion import VlasovBeam,LateralTorqueLoad,LateralBrace,solve_lateral_torsion,wheel_torque_nmm,thin_wall_i_torsion_properties

from .beam_end_projection import solve_lateral_torsion_with_projections,projection_torsion_at
from .autonomous_projection import vertical_projection_extrema

LONGITUDINAL_TRANSFER_PREMISE = ('Força longitudinal do trilho transferida por tração axial na mesa superior; '
    'casal setorial Ctheta=-Fx*e*h0/2, sem prolongar a coordenada setorial até o topo do trilho. '
    'A altura real do trilho permanece no casal de flexão major Fx*zrail.')

@dataclass(frozen=True)
class CaseFactors:
    name:str
    dead_support:float
    dead_equipment:float
    lifted:float
    transverse:float
    longitudinal:float
    source:str
    extra_dead:float|None=None
    wheel_vertical_override_kn:tuple[float,...]|None=None
    def __post_init__(self):
        if self.wheel_vertical_override_kn is not None:
            if not self.wheel_vertical_override_kn or any(isinstance(v,bool) or not isinstance(v,(int,float)) or not math.isfinite(v) or v<0 for v in self.wheel_vertical_override_kn):raise ValueError('Cargas totais de ensaio por roda inválidas.')
        if not self.name.strip() or not self.source.strip():raise ValueError('Identifique o caso e a origem de seus fatores.')
        if self.extra_dead is not None and (isinstance(self.extra_dead,bool) or not isinstance(self.extra_dead,(int,float)) or not math.isfinite(self.extra_dead) or self.extra_dead<0):raise ValueError('Coeficiente de ação inválido: extra_dead')
        for key in ('dead_support','dead_equipment','lifted','transverse','longitudinal'):
            v=getattr(self,key)
            if isinstance(v,bool) or not isinstance(v,(int,float)) or not math.isfinite(v) or v<0:raise ValueError('Coeficiente de ação inválido: '+key)

@dataclass(frozen=True)
class ConcurrentResponse:
    case_name:str
    translation_m:float
    transverse_sign:int
    longitudinal_sign:int
    vertical:object
    lateral_torsion:object
    properties:object
    factors:CaseFactors
    rail_level_mm:float
    longitudinal_transfer_basis:str=LONGITUDINAL_TRANSFER_PREMISE
    projection_lengths_m:tuple[float,float]=(0.,0.)
    projection_evidence:dict=field(default_factory=dict)

    def projection_vertical_extrema(self,side):
        if side not in ('left','right'):raise ValueError('Projection side must be left/right')
        index=0 if side=='left' else 1;x=0. if index==0 else self.vertical.beam.span_m
        return vertical_projection_extrema(self.projection_lengths_m[index],
            self.vertical.udl.vertical_kn_per_m,self.vertical.vertical.EI_knm2,
            self.vertical.vertical.slope_rad(x),-1 if index==0 else 1)

    def at(self,x_m,side='right'):
        # The unbraced horizontal plane is overwritten by the coupled model.
        # Evaluate only retained vertical/axial fields, with the original
        # moment/shear coordinate and side validation still active.
        vertical=self.vertical
        major=vertical.vertical.moment_knm(x_m,side)
        shear=vertical.vertical.shear_kn(x_m,side)
        displacement=vertical.vertical.deflection_mm(x_m)
        axial=vertical.axial_force_kn(x_m,side)
        lateral=self.lateral_torsion.at(x_m*1000,side)
        s=dict(position_m=x_m,side=side,Mx_knm=major,
               My_knm=lateral['minor_moment_nmm']/1e6,Vy_kn=shear,
               Vx_kn=lateral['horizontal_shear_n']/1000,vertical_mm=displacement,
               horizontal_mm=lateral['horizontal_mm'],N_kn=axial)
        s['rail_horizontal_mm']=s['horizontal_mm']+self.rail_level_mm*lateral['torsion']['theta_rad']
        s['torsion']=lateral['torsion']
        # These are REAL exterior root sections of continuous projections.
        # They differ from the fictitious outer side of an equivalent end load.
        projection=('left' if x_m==0 and side=='left' and self.projection_lengths_m[0]>0
                    else 'right' if x_m==self.vertical.beam.span_m and side=='right' and self.projection_lengths_m[1]>0 else None)
        if projection is not None:
            vertical_tail=self.projection_vertical_extrema(projection)
            torsion_tail=self.projection_evidence['root_torsion_states'][projection]
            s.update(Mx_knm=vertical_tail['root']['Mx_knm'],Vy_kn=vertical_tail['root']['Vy_kn'],
                     My_knm=0.,Vx_kn=0.,N_kn=0.,vertical_mm=0.,horizontal_mm=0.,rail_horizontal_mm=0.,
                     torsion=dict(torsion_tail),projection_side=projection,
                     projection_vertical_mm=vertical_tail['vertical_critical']['vertical_mm'],
                     projection_vertical_critical_position_m=x_m+(-1 if projection=='left' else 1)*vertical_tail['vertical_critical']['distance_from_support_m'])
        if projection is not None:
            s['projection_'+projection+'_vertical_mm']=s['projection_vertical_mm']
            s['projection_'+projection+'_rail_horizontal_bound_mm']=self.projection_evidence['service'][projection]['rail_horizontal_bound_mm']
        return s


def _validated(p):
    errors=validate_autonomous(p)
    if errors:raise ValueError('; '.join(errors))
    if not p.section.doubly_symmetric:raise ValueError('A recuperação acoplada de torção requer I duplamente simétrico nesta versão do motor.')
    return section_properties(p.section)


def case_loads(p:AutonomousProject,factors:CaseFactors,transverse_sign=1,longitudinal_sign=1):
    g=_validated(p)
    if transverse_sign not in (-1,1) or longitudinal_sign not in (-1,1):raise ValueError('Sentido horizontal deve ser +1 ou -1.')
    # A in mm², steel unit weight 78.5 kN/m³; rail is kg/m -> kN/m.
    permanent=g.A_mm2*1e-6*STEEL_UNIT_WEIGHT_KN_PER_M3+p.rail.mass_kg_per_m*9.80665/1000
    if getattr(p,'fullheight_nominal_detail',None) is not None:
        from .autonomous_fullheight_runtime import longitudinal_extra_udl_kn_m
        permanent+=longitudinal_extra_udl_kn_m(p)
    extra_factor=factors.dead_support if factors.extra_dead is None else factors.extra_dead
    udl=UniformLoad(permanent*factors.dead_support+p.extra_dead_kn_per_m*extra_factor)
    if factors.wheel_vertical_override_kn is not None and len(factors.wheel_vertical_override_kn)!=len(p.wheels):raise ValueError('Número de cargas totais de ensaio diferente do número de rodas.')
    wheels=tuple(MovingWheel(w.offset_m,(factors.wheel_vertical_override_kn[i] if factors.wheel_vertical_override_kn is not None else w.dead_kn*factors.dead_equipment+w.lifted_kn*factors.lifted),
        w.transverse_kn*factors.transverse*transverse_sign,f'Roda {i+1}',
        w.longitudinal_kn*factors.longitudinal*longitudinal_sign,
        major_moment_knm=w.longitudinal_kn*factors.longitudinal*longitudinal_sign*(p.section.d_mm/2+p.rail.height_mm)/1000,
        minor_moment_knm=-w.longitudinal_kn*factors.longitudinal*longitudinal_sign*(p.rail.offset_from_web_mm+p.rail.lateral_eccentricity_mm)/1000) for i,w in enumerate(p.wheels))
    return g,udl,wheels



def projection_equivalent_loads(p, udl):
    """Exact static main-span replacement of unloaded physical end projections.

    The same factored permanent UDL (steel, rail and declared extra dead load)
    continues on both projections. Wheels remain restricted to 0 <= x <= L.
    +Mx jumps follow the solver convention: left C=-q*a²/2, right C=+q*b²/2.
    These are global equivalent actions, NEVER additional wheels or concentrated
    weld/stiffener introductions. Tail stability/service require separate scope.
    """
    q=udl.vertical_kn_per_m;result=[]
    for length,x,sign,label in ((p.beam_end_left_mm/1000,0.,-1.,'A'),
                                (p.beam_end_right_mm/1000,p.span_m,1.,'B')):
        if length and q:
            result.append(PointLoad(x,q*length,name='Peso permanente da projeção '+label,
                                    major_moment_knm=sign*q*length*length/2))
    return tuple(result)



STEEL_UNIT_WEIGHT_KN_PER_M3 = 78.5


def stiffener_self_weight_metadata(p):
    """Unfactored plate-only quantity; no weld volume or uniform smearing."""
    from .autonomous_local import stiffener_positions_mm
    positions=stiffener_positions_mm(p)
    if getattr(p,'fullheight_nominal_detail',None) is not None:
        from .autonomous_fullheight_runtime import pair_mass
        ledger=pair_mass(p)
        weight=-ledger['Fz_N']/1000
        return dict(pair_count=len(positions),positions_m=[x/1000 for x in positions],
            weight_each_pair_kn=weight,weight_total_kn=weight*len(positions),
            mass_each_pair_kg=ledger['total_mass_kg'],mass_total_kg=ledger['total_mass_kg']*len(positions),
            physical_mass_ledger=ledger,formula='Corpos físicos líquidos da proposta full-height; chapas e metal depositado, sem dupla contagem de preparo/reposição.',
            scope='Pesos estacionários nas posições reais dos pares; juntas longitudinais contadas uma única vez como incremento distribuído físico.')
    if not positions:
        return dict(pair_count=0,positions_m=[],volume_each_pair_m3=0.,volume_total_m3=0.,
            weight_each_pair_kn=0.,weight_total_kn=0.,steel_unit_weight_kn_per_m3=STEEL_UNIT_WEIGHT_KN_PER_M3,
            formula='Sem estações físicas: volume e peso das chapas iguais a zero.',
            scope='Somente chapas físicas declaradas; nenhuma solda ou acessório inferido.')
    h=p.section.d_mm-p.section.tf_mm-p.section.bottom_thickness
    dimensions=(p.stiffener_outstand_mm,p.stiffener_thickness_mm,h)
    if any(isinstance(v,bool) or not isinstance(v,(int,float)) or not math.isfinite(v) or v<=0 for v in dimensions):
        raise ValueError('Dimensões físicas inválidas para peso próprio dos pares de enrijecedores.')
    volume=2*p.stiffener_outstand_mm*p.stiffener_thickness_mm*h*1e-9
    weight=volume*STEEL_UNIT_WEIGHT_KN_PER_M3
    if not math.isfinite(weight):raise ValueError('Peso próprio dos enrijecedores não finito.')
    return dict(pair_count=len(positions),positions_m=[0. if x==0 else p.span_m if x==p.span_m*1000 else x/1000 for x in positions],
        volume_each_pair_m3=volume,volume_total_m3=len(positions)*volume,
        weight_each_pair_kn=weight,weight_total_kn=len(positions)*weight,
        steel_unit_weight_kn_per_m3=STEEL_UNIT_WEIGHT_KN_PER_M3,
        formula='Vpar=2*c*t*(d-tf_top-tf_bottom); Gpar=Vpar*78.5 kN/m³',
        scope='Somente duas chapas retangulares de cada par, altura livre total. Soldas e acessórios sem volume definido não incluídos. Cargas fixas centradas na seção; não são rodas nem carga distribuída adicional.')


def stiffener_self_weight_loads(p,factors):
    """Physical fixed pair weights, scaled once by support permanent factor."""
    factor=factors.dead_support
    if isinstance(factor,bool) or not isinstance(factor,(int,float)) or not math.isfinite(factor) or factor<0:
        raise ValueError('Fator de peso próprio dos enrijecedores inválido.')
    data=stiffener_self_weight_metadata(p)
    weight=data['weight_each_pair_kn']*factor
    if not math.isfinite(weight):raise ValueError('Peso próprio fatorado dos enrijecedores não finito.')
    return tuple(PointLoad(x,weight,name='Peso próprio do par de enrijecedores '+str(i))
                 for i,x in enumerate(data['positions_m'])) if weight else ()


def fixed_permanent_loads(p,factors,udl):
    """All fixed permanent loads: projection equivalents plus real plate pairs."""
    return projection_equivalent_loads(p,udl)+stiffener_self_weight_loads(p,factors)


def solve_concurrent_position(p:AutonomousProject,factors:CaseFactors,translation_m:float,transverse_sign=1,longitudinal_sign=1):
    g,udl,wheels=case_loads(p,factors,transverse_sign,longitudinal_sign)
    s=p.section;m=p.material
    beam=BeamModel(p.span_m,m.E_mpa,g.Ix_mm4,g.Iy_mm4,analysis_brace_positions(p,'upper_braces_m'))
    loads=translate_train(beam,wheels,translation_m)
    vertical=solve_position(beam,loads,udl,fixed_loads=fixed_permanent_loads(p,factors,udl))
    t=thin_wall_i_torsion_properties(s.d_mm,s.bf_mm,s.tf_mm,s.tw_mm)
    torsion_beam=VlasovBeam(p.span_m*1000,m.E_mpa,m.G_mpa,t['J_mm4'],t['Cw_mm6'])
    rail_level=s.d_mm/2+p.rail.height_mm
    coupled=tuple(LateralTorqueLoad(w.position_m*1000,w.horizontal_kn*1000,
        wheel_torque_nmm(w.vertical_kn*1000,w.horizontal_kn*1000,rail_level,p.rail.offset_from_web_mm+p.rail.lateral_eccentricity_mm),w.name,minor_couple_nmm=w.minor_moment_knm*1e6,
        sectorial_couple_nmm2=w.minor_moment_knm*1e6*(s.d_mm-s.tf_mm)/2) for w in loads)
    braces=physical_lateral_braces(p)
    # Rail dead load is eccentric too. Beam dead load is at the shear centre.
    rail_q=p.rail.mass_kg_per_m*9.80665/1000*factors.dead_support # kN/m == N/mm
    distributed_torque=rail_q*p.rail.offset_from_web_mm
    lateral,projection_evidence=solve_lateral_torsion_with_projections(torsion_beam,g.Iy_mm4,coupled,braces,
        uniform_torque_nmm_per_mm=distributed_torque,left_projection_mm=p.beam_end_left_mm,right_projection_mm=p.beam_end_right_mm)
    response=ConcurrentResponse(factors.name,translation_m,transverse_sign,longitudinal_sign,vertical,lateral,g,factors,rail_level,
        projection_lengths_m=(p.beam_end_left_mm/1000,p.beam_end_right_mm/1000),projection_evidence=projection_evidence)
    # An unloaded extension has zero lateral curvature, so v=phi_support*u.
    # The Vlasov tip twist is the largest absolute tail twist. Their triangle
    # inequality bounds the rail displacement everywhere, even if signs cancel.
    if p.beam_end_left_mm or p.beam_end_right_mm:
        from .autonomous_critical import lateral_polynomial_solution
        plane=lateral_polynomial_solution(response)
        projection_evidence['service']={}
        for i,(side,length,x) in enumerate((('left',p.beam_end_left_mm,0.),('right',p.beam_end_right_mm,p.span_m))):
            if not length:continue
            slope=plane.slope_rad(x)
            tip=projection_torsion_at(torsion_beam,length,projection_evidence['end_slopes_per_mm'][i],side,length)
            bound=abs(slope)*length+abs(rail_level*tip['theta_rad'])
            projection_evidence['service'][side]=dict(lateral_root_slope_rad=slope,
                tip_theta_rad=tip['theta_rad'],rail_horizontal_bound_mm=bound,
                method='triangle_bound_of_linear_lateral_displacement_and_monotone_tail_twist')
    return response


def flexural_search(p:AutonomousProject,factors:CaseFactors,transverse_sign=1,longitudinal_sign=1,**search_options):
    """Vertical/axial exact-space bounded-translation search.

    Its horizontal values are unbraced baseline only; the coupled solution must
    be used for lateral response, warping, brace reactions and interactions.
    """
    g,udl,wheels=case_loads(p,factors,transverse_sign,longitudinal_sign)
    beam=BeamModel(p.span_m,p.material.E_mpa,g.Ix_mm4,g.Iy_mm4,analysis_brace_positions(p,'upper_braces_m'))
    return scan_moving_train(beam,wheels,udl,fixed_loads=fixed_permanent_loads(p,factors,udl),tolerance=SearchTolerance(relative=p.sampling_tolerance),**search_options)
