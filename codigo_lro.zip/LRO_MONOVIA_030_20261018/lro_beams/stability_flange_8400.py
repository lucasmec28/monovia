"""Literature-backed flange-outstand plate method under NBR 8400 C.2.

JRC/ECCS EUR22898EN Eq4.9 / Table4.2: supported root, free edge, uniform
longitudinal compression, k_sigma=.43. General C.2 reduction and Table13
psi=1 safety factors. Not a native four-supported-edge TableC5 calculation.
"""
from __future__ import annotations
from dataclasses import asdict, dataclass
import math
from typing import Any
from .stress_8400 import _type_errors, _check
from .stability_8400 import reduce_plate_critical_8400, CASE_FACTORS_UNIFORM

@dataclass
class FlangeOutstand8400Input:
    name: str = 'Aba em balanço: estabilidade local'
    load_case: str = 'I'
    fy_mpa: float = 0.0
    E_mpa: float = 210000.0
    poisson: float = .3
    outstand_width_mm: float = 0.0
    flange_thickness_mm: float = 0.0
    compression_mpa: float = 0.0
    action_basis: str = 'unqualified'
    material_source: str = ''
    geometry_source: str = ''
    stress_source: str = ''
    action_source: str = ''
    factors_source: str = ''
    root_restraint_source: str = ''
    method_selection_source: str = ''
    action_case_qualified: bool = False
    factors_already_applied: bool = False
    actual_outstand_qualified: bool = False
    flat_unperforated_outstand_confirmed: bool = False
    supported_root_free_edge_confirmed: bool = False
    root_rigidity_verified: bool = False
    uniform_longitudinal_compression_confirmed: bool = False
    no_local_transverse_patch_confirmed: bool = False
    no_shear_biaxial_interaction_confirmed: bool = False
    no_distortional_coupled_mode_confirmed: bool = False
    literature_method_selected: bool = False


def calculate_flange_outstand_8400(data: FlangeOutstand8400Input) -> dict[str,Any]:
    result={'kind':'flange_outstand_buckling_8400','source':'NBR 8400-2:2019, 5.4/C.2; coeficiente de literatura JRC/ECCS EUR22898EN, Eq.4.9/Tabela4.2',
        'input_valid':True,'status':'PENDENTE','full_compliance':False,'errors':[],'pending':[],'checks':[],'intermediates':{},
        'limitations':[
            'Resultado parcial de uma aba em balanço sob compressão longitudinal uniforme, psi=1.',
            'k_sigma=0,43 é coeficiente de literatura adotado e justificado; não é a Tabela C.5 de quatro bordas apoiadas.',
            'Não cobre tensões locais de roda/patch, torção, interação de cisalhamento/biaxial ou modos distorcionais/acoplados.',
            'Exige raiz efetivamente apoiada, borda oposta livre, chapa plana sem aberturas e largura real do balanço.',
            'Escoamento, fadiga, FLT, alma, ligações e demais trechos/casos continuam verificações separadas.',
        ]}
    errors=_type_errors(data,FlangeOutstand8400Input)
    if errors:
        result.update(input_valid=False,status='ENTRADA INVÁLIDA',errors=errors);return result
    for field in ('fy_mpa','E_mpa','outstand_width_mm','flange_thickness_mm'):
        if getattr(data,field)<=0:errors.append(f'{field}: informar valor positivo.')
    if not 0<data.poisson<.5:errors.append('Poisson deve estar entre 0 e 0,5.')
    if data.flange_thickness_mm>=data.outstand_width_mm:errors.append('Espessura incompatível com chapa em balanço.')
    if data.compression_mpa<0:errors.append('compression_mpa é magnitude de compressão positiva, não tensão assinada de tração.')
    if data.load_case not in CASE_FACTORS_UNIFORM:errors.append('Caso deve ser I, II ou III.')
    if errors:
        result.update(input_valid=False,status='ENTRADA INVÁLIDA',errors=errors);return result
    result['input']=asdict(data)
    if data.action_basis!='nbr8400_cases':result['pending'].append('Exige ações próprias dos casos I/II/III, sem conversão ELU 8800.')
    for field,message in {
        'material_source':'Identificar material, fy, E, Poisson e espessura.',
        'geometry_source':'Identificar a aba e largura efetivamente sem apoio; projeção geométrica integral conservadora requer registro.',
        'stress_source':'Identificar compressão longitudinal uniforme concomitante na aba.',
        'action_source':'Identificar caso/combinação e posição do equipamento.',
        'factors_source':'Registrar fatores de ação/dinâmica já incluídos uma única vez.',
        'root_restraint_source':'Registrar cálculo/detalhe da rigidez e resistência do apoio longitudinal da raiz.',
        'method_selection_source':'Registrar seleção justificada da literatura JRC/ECCS k=0,43 em conjunto com C.2/8400.',
    }.items():
        if not getattr(data,field).strip():result['pending'].append(message)
    for field,message in {
        'action_case_qualified':'Qualificar o caso I/II/III.',
        'factors_already_applied':'Confirmar fatores incluídos uma única vez.',
        'actual_outstand_qualified':'Qualificar a largura real em balanço, sem subtrair apoio não comprovado.',
        'flat_unperforated_outstand_confirmed':'Confirmar chapa plana sem aberturas/descontinuidades.',
        'supported_root_free_edge_confirmed':'Confirmar uma borda longitudinal apoiada e a outra livre.',
        'root_rigidity_verified':'Qualificar rigidez e resistência do apoio da raiz.',
        'uniform_longitudinal_compression_confirmed':'Confirmar compressão longitudinal uniforme psi=1.',
        'no_local_transverse_patch_confirmed':'Confirmar ausência relevante de tensão transversal/local/patch neste painel e caso.',
        'no_shear_biaxial_interaction_confirmed':'Confirmar ausência de interação relevante com cisalhamento ou tensão biaxial.',
        'no_distortional_coupled_mode_confirmed':'Confirmar que modos distorcionais/acoplados não invalidam o modelo de chapa.',
        'literature_method_selected':'Confirmar seleção justificada do coeficiente de literatura e redução C.2.',
    }.items():
        if not getattr(data,field):result['pending'].append(message)
    if result['pending']:return result
    if data.compression_mpa==0:
        result['pending'].append('Compressão nula nesta linha; demais abas/casos precisam ser avaliados.');return result
    euler=math.pi**2*data.E_mpa/(12*(1-data.poisson**2))*(data.flange_thickness_mm/data.outstand_width_mm)**2
    critical=.43*euler
    result['intermediates']={'k_sigma':.43,'psi':1.0,'plate_euler_mpa':euler,'critical_elastic_mpa':critical}
    try:reduced=reduce_plate_critical_8400(critical,data.fy_mpa)
    except ValueError as exc:
        result['status']='FORA DO DOMÍNIO';result['pending'].append(str(exc));return result
    nu=CASE_FACTORS_UNIFORM[data.load_case]
    allowable=reduced['critical_reduced_mpa']/nu
    result['intermediates'].update(reduced,nu_v=nu,allowable_compression_mpa=allowable)
    check=_check('flange_outstand_buckling','Flambagem local da aba em balanço',data.compression_mpa,allowable,
        'sigma_cr=0,43*pi²*E/[12*(1-nu²)]*(tf/c)²; sigma_comp <= sigma_cr,R/nu_v',
        '5.4, Tabela 13, C.2.1/C.2.2; coeficiente prático JRC/ECCS EUR22898EN Eq.4.9/Tabela4.2')
    result['checks']=[check]
    result['status']='RESULTADO PARCIAL — NÃO ATENDE' if check['status']=='NÃO ATENDE' else 'RESULTADO PARCIAL'
    return result
