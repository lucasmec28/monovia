"""Educational, single-choice fatigue inputs for the legacy autonomous editor.

Only identifiers already consumed by the model are returned. No classification,
cycle count, provenance, project mutation or calculation is performed here.
The existing reviewed CMAA gallery remains consultation-only, not an option set.
"""
from __future__ import annotations

from .autonomous_fatigue import FATIGUE_DETAIL_OPTIONS


GROUP_OPTIONS = ("E8_conservative", "P4_cycles_conservative", *(f"E{i}" for i in range(1, 9)))
DETAIL_OPTIONS = ("automatic_section_preset", "unselected", *FATIGUE_DETAIL_OPTIONS)
_GROUP_LABELS = {
    "E8_conservative": "E8 · hipótese conservadora",
    "P4_cycles_conservative": "Grupo por ciclos informados · espectro P4 conservador",
}
_COMPONENT_LABELS = {
    "normal_longitudinal": "normal longitudinal",
    "normal_transverse": "normal transversal",
    "shear": "cisalhamento",
}


def component_group_rows():
    """Explain application modes, without inventing cycle bands for E1–E8."""
    return [
        {"Opção": _GROUP_LABELS["E8_conservative"],
         "Como é utilizada": "Adota E8 como envelope conservador, sem classificar o uso real.",
         "Ciclos de tensão por utilização": "Opcionais para este grupo; a análise de vida permanece separada."},
        {"Opção": _GROUP_LABELS["P4_cycles_conservative"],
         "Como é utilizada": "Obtém o grupo pela vida, utilizações/ano e ciclos no ponto; adota espectro P4.",
         "Ciclos de tensão por utilização": "Obrigatórios e maiores que zero; não são inferidos das rodas."},
        *({"Opção": group,
           "Como é utilizada": f"Aplica {group} ao componente, como seleção explícita no cálculo.",
           "Ciclos de tensão por utilização": "Opcionais para selecionar o grupo; a seleção não comprova vida finita."}
          for group in GROUP_OPTIONS[2:]),
    ]


def _detail_label(identifier):
    if identifier == "automatic_section_preset":
        return "Automático: detalhe de fabricação proposto"
    if identifier == "unselected":
        return "Selecione o detalhe físico"
    return FATIGUE_DETAIL_OPTIONS[identifier]["label"]


def fatigue_detail_rows():
    """Use the model's existing detail catalog, not CMAA letters as identifiers."""
    rows = [
        {"Detalhe físico": _detail_label("automatic_section_preset"),
         "Condições e região avaliada": "Preserva a proposta de fabricação do perfil; não classifica todos os detalhes da viga.",
         "NBR 8800": "Conforme detalhe proposto", "NBR 8400": "Conforme detalhe proposto"},
        {"Detalhe físico": _detail_label("unselected"),
         "Condições e região avaliada": "Mantém a escolha pendente, sem atribuir categoria.",
         "NBR 8800": "Pendente", "NBR 8400": "Pendente"},
    ]
    for detail in FATIGUE_DETAIL_OPTIONS.values():
        rows.append({
            "Detalhe físico": detail["label"],
            "Condições e região avaliada": detail["criteria"],
            "NBR 8800": detail["category_8800"] or "Sem categoria automática implementada",
            "NBR 8400": detail["detail_8400"] or "Sem equivalência automática",
        })
    return rows


def _single_choice(st, label, options, current, *, key, format_func, help):
    # Unknown imported identifiers must survive a read/rerun, but must not become
    # newly selectable calculation capabilities or be replaced by the first row.
    known = current in options
    if not known:
        st.warning(
            f"Valor importado não implementado neste seletor: {current}. "
            "Preservado sem atribuir categoria. Escolha uma opção disponível "
            "somente se ela representar o detalhe ou grupo do projeto."
        )
    if key in st.session_state and st.session_state[key] not in (*options, None):
        del st.session_state[key]
    selected = st.radio(label, options, index=options.index(current) if known else None,
                        format_func=format_func, key=key, help=help)
    return current if selected is None else selected


def render_component_group_choice(st, current, *, key):
    st.markdown("**Guia de seleção · grupo de fadiga do componente**")
    st.caption(
        "O grupo E1–E8 considera ciclos e espectro de tensões do componente "
        "(NBR 8400-1, 6.1.4.2–6.1.4.4, Tabelas 9–11). Não é a classe "
        "de serviço da ponte nem uma categoria de detalhe A–F. Não há uma "
        "faixa única de ciclos para cada E sem definir o espectro."
    )
    st.table(component_group_rows())
    return _single_choice(
        st, "Grupo de fadiga do componente E", GROUP_OPTIONS, current, key=key,
        format_func=lambda value: _GROUP_LABELS.get(value, value),
        help="Escolha uma única opção. E1–E8 são escolhas explícitas, não uma classificação operacional verificada. "
             "Apenas o método por ciclos exige ciclos de tensão por utilização."
    )


def render_fatigue_detail_choice(st, current, *, key):
    st.markdown("**Guia de seleção · detalhe físico de fadiga**")
    st.caption(
        "Escolha pelo ponto, ligação e direção da tensão, não somente pela letra. "
        "A tabela lista os detalhes já disponíveis nesta rota; uma categoria "
        "de uma norma não é convertida automaticamente para outra."
    )
    st.table(fatigue_detail_rows())
    selected = _single_choice(
        st, "Detalhe físico de fadiga", DETAIL_OPTIONS, current, key=key,
        format_func=_detail_label,
        help="Uma escolha por vez. As condições da linha devem corresponder ao ponto físico avaliado; "
             "selecionar um detalhe não habilita verificações fora de seu escopo."
    )
    if selected in FATIGUE_DETAIL_OPTIONS:
        detail = FATIGUE_DETAIL_OPTIONS[selected]
        st.caption("Condição do detalhe selecionado: " + detail["criteria"])
        st.caption("Componentes previstos no catálogo: " + ", ".join(
            _COMPONENT_LABELS[value] for value in detail["components"]) +
            ". A disponibilidade de cada verificação continua sujeita à rota de cálculo.")
        if detail["category_8800"] is None:
            st.info("Este detalhe não possui categoria automática NBR 8800 implementada; "
                    "sua seleção não cria essa verificação.")
        if detail["detail_8400"] is None:
            st.info("Este detalhe não possui equivalência automática NBR 8400; "
                    "sua seleção não cria essa equivalência.")
    st.caption(
        "Desenhos de consulta abaixo: CMAA 74:2020, categorias A–F. "
        "Não são opções adicionais do seletor NBR. Em particular, F trata de "
        "cisalhamento na garganta de solda, não de tensão normal no metal-base."
    )
    # Reuse the audited catalog and image-integrity handling without modifying
    # assets, assigning CMAA letters, or adding any new calculation permission.
    from top_unstiffened_candidate.detail_gallery import render_detail_gallery
    render_detail_gallery(st)
    return selected
