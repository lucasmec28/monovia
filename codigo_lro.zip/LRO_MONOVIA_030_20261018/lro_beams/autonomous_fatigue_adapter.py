"""Bind project life, physical regions and audited sweeps to fatigue envelopes.

This adapter does not turn mere row existence into coverage. Results stay tied
to the current full project signature, generated fatigue case and every swept
translation. Homogeneous base, base near weld and flange nominal fields are
separate regions. Local effects on a web never qualify a flange or weld throat.
"""
from __future__ import annotations
from .autonomous_restraint_mode import analysis_brace_positions
from dataclasses import asdict
from copy import deepcopy
import math
from .autonomous_result import Verification,input_signature
from .autonomous_fatigue_storage import PackedFatigueAnalyses
from .autonomous_model import validate_autonomous
from .autonomous_cases import generate_basic_cases
from .autonomous_response import stiffener_self_weight_loads
from .autonomous_fatigue import (FatigueAbsoluteBounds,evaluate_8400_absolute_envelope,
    component_group_from_explicit_use,explicit_component_group_selection)

SOURCE='ABNT NBR 10084:2020, 9.1.1–9.1.3; ABNT NBR 8400-2:2019, D.2.1–D.2.3; Eq. D.5, pp.62–63'
METRICS=('web_sigma_abs_upper_bound_mpa','flange_sigma_abs_upper_bound_mpa',
         'web_shear_magnitude_upper_bound_mpa','flange_shear_magnitude_upper_bound_mpa',
         'local_transverse_bound_mpa','local_shear_bound_mpa',
         'local_longitudinal_compression_bound_mpa','combined_web_longitudinal_bound_mpa','combined_web_shear_bound_mpa')


def _value(value,label):
    if isinstance(value,bool) or not isinstance(value,(int,float)) or not math.isfinite(value) or value<0:
        raise ValueError(label+': limite não negativo e finito obrigatório.')
    return float(value)


def evaluate_absolute_fatigue_project(project,case,sweep,local_records, *,fixed_flange_web_detail=None,fixed_stiffener_detail=None,_family_bounds=None) -> dict:
    """Return Verification records, per-region arithmetic, and remaining scope.

    The usual welded-I preset prescribes Q.C. execution; it does not certify an
    existing weld or inspection. E8 is a conservative group envelope. Finite life
    requires explicit cycles of stress per use and adopts the worst printed P4
    spectrum via NBR8400-1 Tables9–11, or a separately declared E group.
    Additional same-point nominal histories/8800 detail and actual weld-throat
    methods can close the identified region obligations, but their mere presence
    cannot erase them. Parent owns their scope reconciliation.
    """
    output=dict(case_id=getattr(case,'id',''),verifications=[],regions={},pending=[],errors=[],
        group_selection={},design_requirements=[],complete=False,full_compliance=False)
    def pending(identifier,title,reason,state='pending',evidence=None):
        output['pending'].append(reason)
        output['verifications'].append(Verification('fatigue/'+identifier+'/'+output['case_id'],'fatigue',title,state,SOURCE,
            output['case_id'],reason=reason,evidence=evidence or {}))
    try:
        errors=validate_autonomous(project)
        if errors:raise ValueError('; '.join(errors))
        rail=project.rail
        if abs(rail.offset_from_web_mm)>1e-9 or rail.local_attachment!='non_rigid' or rail.continuity!='continuous_no_joint' or project.support_contact!='centered_under_web':
            raise ValueError('Modelo simplificado superior NBR10084 exige trilho centrado, fixação não rígida, continuidade e apoio compressivo centrado; outra configuração exige avaliação específica.')
        if case.family!='FAT8400' or getattr(case.action_factors,'basis','')!='nbr8400_fatigue_case_i_without_mx':
            raise ValueError('Adaptador exige caso FAT8400, caso I operacional sem Mx.')
        if sweep.case_id!=case.id:raise ValueError('Varredura pertence a outro caso.')
        if getattr(sweep,'project_signature',None)!=input_signature(project):
            raise ValueError('Varredura não vinculada às entradas atuais; recalcular após qualquer alteração.')
        expected=next((c for c in generate_basic_cases(project) if c.id==case.id),None)
        if expected is None or asdict(expected)!=asdict(case):
            raise ValueError('Caso de ações não corresponde às entradas atuais do projeto.')
        if type(sweep.converged) is not bool or not sweep.converged:
            raise ValueError('Varredura de fadiga ainda não convergiu na tolerância informada.')
        if not isinstance(local_records,dict) or not local_records:
            raise ValueError('Registros locais de fadiga ausentes.')
        positions=tuple(sweep.translation_positions)
        if not positions or len(positions)>200000:raise ValueError('Posições da varredura ausentes ou fora do domínio.')
        if any(b<=a for a,b in zip(positions,positions[1:])):raise ValueError('Posições devem estar em ordem estritamente crescente.')
        lo=-max(w.offset_m for w in project.wheels);hi=project.span_m-min(w.offset_m for w in project.wheels)
        if not (positions[0]<lo and positions[-1]>hi):raise ValueError('Varredura não cobre entrada/saída completas e linhas de base sem rodas.')
        for a in positions:
            if isinstance(a,bool) or not isinstance(a,(int,float)) or not math.isfinite(a):raise ValueError('Posição da varredura inválida.')
            if a not in local_records:raise ValueError('Falta efeito local em uma posição da varredura.')
            row=local_records[a]
            if not isinstance(row,dict) or row.get('translation_m')!=a or row.get('basis')!='nbr8400_fatigue_case_i_without_mx':
                raise ValueError('Registro local pertence a outra posição/base de ações.')
            if row.get('project_signature')!=sweep.project_signature or row.get('case_id')!=case.id:
                raise ValueError('Registro local não vinculado ao projeto e caso atuais; não trocar passagem carregada/vazia.')
            reactions=row.get('reactions_kn',{})
            if not isinstance(reactions,dict) or any(k not in reactions for k in ('A','B')):
                raise ValueError('Registro local sem reações para qualificar o caminho compressivo.')
            for key in ('A','B'):_value(reactions[key],'Reação compressiva '+key)
            if row.get('prescribed_scope_complete') is not True:
                raise ValueError('Cobertura do modelo nominal prescrito NBR10084 não demonstrada.')
            if row.get('input_valid') is not True or row.get('local_effects_bound_complete') is not True or row.get('pending'):
                raise ValueError('Modelo local de fadiga incompleto: '+'; '.join(row.get('pending',[]) or ['limites locais não demonstrados']))
        metrics={k:_value(sweep.maxima[k].value,k) for k in METRICS}
        # Check that the observer did not omit a local maximum. Summing maxima
        # of components is conservative; selecting less than a recorded one is not.
        local_values=[]
        for a in positions:
            record=local_records[a];stresses=record['stresses']
            bending=_value(stresses['sigmaT_bound_mpa'],'σflexão local')
            patches=record.get('compression_patches')
            if isinstance(patches,list):
                if len(patches)>10000:raise ValueError('Excesso de faixas locais de compressão.')
                critical={0.,project.span_m*1000}
                for patch in patches:
                    left=patch['left_mm'];right=patch['right_mm']
                    if any(isinstance(v,bool) or not isinstance(v,(int,float)) or not math.isfinite(v) for v in (left,right)) or left>right:raise ValueError('Faixa de compressão inválida.')
                    _value(patch['pressure_mpa'],'Pressão da faixa')
                    if patch.get('kind') not in ('wheel','support'):raise ValueError('Origem da faixa de compressão inválida.')
                    critical.update(x for x in (left,right) if 0<=x<=project.span_m*1000)
                compression=max(math.fsum(patch['pressure_mpa'] for patch in patches if patch['left_mm']<=x<=patch['right_mm']) for x in critical)
                wheel_compression=max(math.fsum(patch['pressure_mpa'] for patch in patches if patch['kind']=='wheel' and patch['left_mm']<=x<=patch['right_mm']) for x in critical)
                fan_applied=isinstance(record.get('fan_model'),dict) and record['fan_model'].get('applied') is True
                local_values.append((compression+bending,bending,compression if fan_applied else 0.,max(compression,.2*wheel_compression) if fan_applied else .2*wheel_compression))
            else:
                local_values.append((_value(stresses['transverse_compression_bound_mpa'],'σcompressão')+bending,bending,
                    _value(stresses['longitudinal_local_compression_bound_mpa'],'σlong local'),
                    _value(stresses['local_shear_complete_bound_mpa'],'τlocal completo')))
        local_transverse,local_bending,local_longitudinal,local_shear=(max(row[i] for row in local_values) for i in range(4))
        for metric,value in (('local_transverse_bound_mpa',local_transverse),('local_shear_bound_mpa',local_shear),('local_longitudinal_compression_bound_mpa',local_longitudinal)):
            if metrics[metric]+1e-10*max(1.,value)<value:raise ValueError('Métrica '+metric+' não cobre o máximo local registrado.')
        for combined,parts in (('combined_web_longitudinal_bound_mpa',('web_sigma_abs_upper_bound_mpa','local_longitudinal_compression_bound_mpa')),
                               ('combined_web_shear_bound_mpa',('web_shear_magnitude_upper_bound_mpa','local_shear_bound_mpa'))):
            if any(metrics[combined]+1e-10*max(1.,metrics[k])<metrics[k] for k in parts):
                raise ValueError('Envelope combinado menor que uma parcela não negativa: '+combined)
        # Prefer auditable sums at the same position/cut. Imported or synthetic
        # sweeps without this chain use the conservative sum of maxima instead.
        registry=getattr(sweep,'observer_sample_keys',None)
        samples_available=isinstance(registry,(list,tuple)) and bool(registry) and all(isinstance(local_records[a].get('combined_section_samples'),list) and local_records[a]['combined_section_samples'] for a in positions)
        lateral_jump_faces={(x,side) for x in analysis_brace_positions(project,'lateral_only_braces_m') for side in ('left','right') if 0<x<project.span_m}
        fixed_jump_faces={(load.position_m,side) for load in stiffener_self_weight_loads(project,case.factors)
                          for side in ('left','right') if 0<load.position_m<project.span_m}
        exterior_root_faces=set()
        if project.beam_end_left_mm>0:exterior_root_faces.update(((0.,'left'),(0.,'right')))
        if project.beam_end_right_mm>0:exterior_root_faces.update(((project.span_m,'left'),(project.span_m,'right')))
        if exterior_root_faces and not samples_available:
            raise ValueError('Projeções físicas exigem trilha das duas faces da raiz; fallback global não comprova os extremos exteriores de empenamento.')
        if lateral_jump_faces and not samples_available:
            raise ValueError('Contenções horizontais adicionais exigem trilha das duas faces de cada salto lateral; fallback global não comprova os cortes.')
        if fixed_jump_faces and not samples_available:
            raise ValueError('Pesos fixos dos enrijecedores exigem trilha das duas faces dos saltos de cortante.')
        if samples_available:
            expected_keys=set()
            if len(registry)>2000000:raise ValueError('Excesso de cortes no registro da varredura.')
            for key in registry:
                if not isinstance(key,(list,tuple)) or len(key)!=3 or key[2] not in ('left','right') or key[0] not in positions:raise ValueError('Registro de cortes da varredura inválido.')
                if isinstance(key[0],bool) or not isinstance(key[0],(int,float)) or not math.isfinite(key[0]):raise ValueError('Translação inválida no registro de cortes.')
                _value(key[1],'Coordenada registrada do corte')
                expected_keys.add(tuple(key))
            actual_keys=set()
            sample_maxima={}
            for a in positions:
                rows=local_records[a]['combined_section_samples']
                if len(rows)>100000:raise ValueError('Excesso de amostras de combinação por posição.')
                for row in rows:
                    if not isinstance(row,dict) or row.get('side') not in ('left','right'):raise ValueError('Amostra concomitante inválida.')
                    x=_value(row.get('x_m'),'Coordenada de combinação')
                    if x>project.span_m:raise ValueError('Amostra concomitante fora da viga.')
                    values={k:_value(row.get(k),k) for k in ('web_sigma_abs_mpa','web_shear_abs_mpa','local_compression_mpa','local_shear_mpa','combined_longitudinal_mpa','combined_shear_mpa')}
                    for combined,first,second in (('combined_longitudinal_mpa','web_sigma_abs_mpa','local_compression_mpa'),('combined_shear_mpa','web_shear_abs_mpa','local_shear_mpa')):
                        expected_sum=values[first]+values[second]
                        if not math.isclose(values[combined],expected_sum,rel_tol=1e-10,abs_tol=1e-10):raise ValueError('Registro concomitante não reproduz a soma global/local: '+combined)
                    if isinstance(local_records[a].get('compression_patches'),list):
                        from .autonomous_local import local_bounds_at_section
                        local=local_bounds_at_section(local_records[a],x)
                        for key,expected_value in (('local_compression_mpa',local['longitudinal_local_compression_bound_mpa']),('local_shear_mpa',local['local_shear_complete_bound_mpa'])):
                            if not math.isclose(values[key],expected_value,rel_tol=1e-10,abs_tol=1e-10):raise ValueError('Amostra local não corresponde às faixas do corte: '+key)
                        for key,expected_value in (('local_transverse_mpa',local['transverse_compression_bound_mpa']+local['sigmaT_bound_mpa']),('local_bending_mpa',local['sigmaT_bound_mpa'])):
                            if not math.isclose(_value(row.get(key),key),expected_value,rel_tol=1e-10,abs_tol=1e-10):raise ValueError('Amostra transversal não corresponde ao corte: '+key)
                    actual_keys.add((a,x,row['side']))
                    # Audit every row, retaining only the exact running maxima
                    # needed below instead of a second per-sample dict copy.
                    for name,value in values.items():
                        if name not in sample_maxima or value>sample_maxima[name]:sample_maxima[name]=value
                local_reference=local_values[positions.index(a)]
                for key,target in (('local_compression_mpa',local_reference[2]),('local_shear_mpa',local_reference[3])):
                    if max(row[key] for row in rows)+1e-10*max(1.,target)<target:raise ValueError('Trilha de cortes omite máximo local na translação: '+key)
                if not any(row['x_m']==0 for row in rows) or not any(row['x_m']==project.span_m for row in rows):
                    raise ValueError('Registros concomitantes não incluem ambos os apoios.')
                if not lateral_jump_faces.issubset({(row['x_m'],row['side']) for row in rows}):
                    raise ValueError('Trilha de fadiga omite uma face do salto de contenção horizontal nesta translação.')
                if not fixed_jump_faces.issubset({(row['x_m'],row['side']) for row in rows}):
                    raise ValueError('Trilha de fadiga omite uma face do peso fixo de enrijecedor nesta translação.')
                if not exterior_root_faces.issubset({(row['x_m'],row['side']) for row in rows}):
                    raise ValueError('Trilha de fadiga omite uma face física da raiz da projeção nesta translação.')
            if actual_keys!=expected_keys:raise ValueError('Trilha concomitante não corresponde a todos os cortes da varredura.')
            for metric,key in (('combined_web_longitudinal_bound_mpa','combined_longitudinal_mpa'),('combined_web_shear_bound_mpa','combined_shear_mpa')):
                maximum=sample_maxima[key]
                if metrics[metric]+1e-10*max(1.,maximum)<maximum:raise ValueError('Métrica combinada subestima as somas registradas: '+metric)
            for metric,key in (('web_sigma_abs_upper_bound_mpa','web_sigma_abs_mpa'),('web_shear_magnitude_upper_bound_mpa','web_shear_abs_mpa')):
                if not math.isclose(metrics[metric],sample_maxima[key],rel_tol=1e-8,abs_tol=1e-8):raise ValueError('Trilha de amostras não reproduz o máximo global: '+metric)
            output['combination_evidence']='Somas global/local auditadas na mesma posição/corte, cobrindo os extremos globais e os apoios.'
        else:
            metrics['combined_web_longitudinal_bound_mpa']=metrics['web_sigma_abs_upper_bound_mpa']+metrics['local_longitudinal_compression_bound_mpa']
            metrics['combined_web_shear_bound_mpa']=metrics['web_shear_magnitude_upper_bound_mpa']+metrics['local_shear_bound_mpa']
            output['combination_evidence']='Fallback conservador: soma dos máximos globais e locais separados; trilha concomitante indisponível.'
        use=project.fatigue
        group=use.component_group
        if group=='P4_cycles_conservative':
            explicit=getattr(use,'stress_cycles_per_use',None)
            if explicit is None:raise ValueError('Vida finita exige ciclos de tensão por uso explicitamente definidos para a região.')
            selection=component_group_from_explicit_use(life_years=use.life_years,uses_per_year=use.uses_per_year,
                stress_cycles_per_use=explicit,source='Ciclos de tensão por uso explicitamente informados no projeto; não derivados silenciosamente de rodas/passagens.')
            chosen=selection['component_group'];group_source=selection['source']+'; '+selection['formula']+f" = {selection['cycles_upper_bound']:g}; envelope P4."
        elif group=='E8_conservative':
            selection=dict(component_group='E8',is_actual_classification=False,
                life_years=use.life_years,uses_per_year=use.uses_per_year,
                method='Envelope E8 de todos os grupos; vida informada preservada, sem cálculo fictício de N.')
            chosen=group;group_source=''
        elif group in tuple(f'E{i}' for i in range(1,9)):
            group_source=getattr(use,'group_source','')
            selection=explicit_component_group_selection(group,group_source)
            chosen=group
        else:raise ValueError('Grupo/método de fadiga inválido.')
    except (ValueError,KeyError,TypeError,AttributeError) as exc:
        output['errors'].append(str(exc))
        pending('input_domain','Domínio e rastreabilidade da fadiga',str(exc))
        return output
    output['input_audit_complete']=True
    output['audited_metrics']=dict(metrics)
    output['audited_local_bending_bound_mpa']=local_bending
    lifetime_intervals=False
    if _family_bounds is not None:
        expected_fatigue={c.id for c in generate_basic_cases(project) if c.family=='FAT8400'}
        if not isinstance(_family_bounds,dict) or _family_bounds.get('project_signature')!=input_signature(project) or set(_family_bounds.get('case_ids',[]))!=expected_fatigue:
            pending('family_domain','Cobertura da família de fadiga','Família não vinculada ao projeto/casos completos.');return output
        metrics={k:_value(_family_bounds['metrics'][k],k) for k in METRICS}
        local_bending=_value(_family_bounds['local_bending_bound_mpa'],'Flexão transversal da família')
        output['case_id']='FAT8400_LIFETIME'
        output['audited_metrics']=dict(metrics)
        output['audited_local_bending_bound_mpa']=local_bending
        output['family_evidence']={k:v for k,v in _family_bounds.items() if k!='metrics'}
        lifetime_intervals=True
    output['lifetime_intervals_qualified']=lifetime_intervals
    output['group_selection']=selection
    output['design_requirements']=[
        'Propriedades fy/fu e grau '+project.material_grade+' devem corresponder ao aço/espessura previstos e ao certificado de fornecimento.',
        'Execução, inspeção e proteção compatíveis com as normas; Q.C. para os filetes, com penetração, transições e términos sem crateras/mordeduras conforme AnexoB. Trata-se de exigência de projeto, não atestado de fabricação já executada.',
        'Modelo nominal simplificado de viga de rolamento superior NBR10084 §9.1.3: trilho centrado/contínuo, fixação não rígida e cargas/reação compressivas. Tensões globais das mesas, flexão transversal da alma e transferência das soldas permanecem verificadas. Não se afirma tensão local 3D nula; contato roda–trilho pertence ao componente trilho/equipamento.']
    fabrication='specified_h6_qc' if project.section.fabrication=='welded' else 'specified_h6'
    design=dict(fy_mpa=project.material.fy_mpa,fu_mpa=project.material.fu_mpa,
        material_grade=project.material_grade,fabrication=fabrication,
        component_group=chosen,group_source=group_source)
    def append_region_result(identifier,label,result):
        result.setdefault('intermediates',{})['is_actual_classification']=selection.get('is_actual_classification',False)
        result['intermediates']['group_adoption']=selection
        result['group_selection']=selection
        for check in result['checks']:
            criterion_exceeded=(result.get('domain_complete') is True and check['id'] in result.get('criterion_exceedances',[]) and check.get('exceedance_policy')=='requires_specific_assessment' and check['utilization']>1)
            state='calculated' if result.get('domain_complete') is True and (check['status']=='ATENDE NO DOMÍNIO' or criterion_exceeded) else 'pending'
            reason='Não atende ao critério conservador adotado; não constitui prova de ruptura física; redimensionar ou adotar método refinado.' if criterion_exceeded else check['detail']
            output['verifications'].append(Verification('fatigue/'+identifier+'/'+check['id']+'/'+output['case_id'],'fatigue',label+' · '+check['name'],
                state,check['source'],output['case_id'],check['demand'],check['capacity'],check['unit'],check['utilization'],reason,
                dict(region=identifier,conservative_envelope=True,formula=check['formula'],
                     conservative_exceedance=criterion_exceeded,group_selection=selection,
                     critical_location=check.get('critical_location'),
                     scope='enrijecedor_modelo_nominal_grupo_3d_e_par_de_chapas' if identifier.startswith('stiffener') else 'garganta_fixa_filetes_alma_mesa_d3_1' if identifier=='flange_web_weld_throat' else 'mesa_no_modelo_nominal_simplificado_nbr10084_9_1_3_trilho_centrado_compressivo' if identifier.startswith('flange') else 'alma_no_modelo_nominal_prescrito_nbr10084_longe_de_acessorios_e_terminos')))
        for reason in result.get('domain_pending',result.get('pending',[])):pending(identifier+'_domain',label+' · domínio',reason)
        for reason in result.get('errors',[]):pending(identifier+'_invalid',label+' · entrada',reason)
    # The entire-web stress bounds may be reused on SUBREGIONS. Both W0 and
    # K0/K4 are checked because K0 is not uniformly weaker than W0 at low E.
    regions=[('web_homogeneous','Material-base homogêneo da alma no modelo nominal NBR10084','unnotched_base',project.section.tw_mm,
        metrics['combined_web_longitudinal_bound_mpa'],metrics['local_transverse_bound_mpa'],
        metrics['combined_web_shear_bound_mpa'])]
    detail=project.fatigue.detail
    if detail=='automatic_section_preset':
        detail='continuous_longitudinal_fillet' if project.section.fabrication=='welded' else 'plain_base_no_notch'
        output['design_requirements'].append('Preset de fabricação proposto pelo aplicativo: '+('filetes contínuos Q.C. na ligação alma–mesa; executar geometria de cordões definida pelo cálculo.' if project.section.fabrication=='welded' else 'perfil laminado, material-base homogêneo afastado de descontinuidades; acessórios são verificados separadamente.'))
    output['adopted_detail']=detail
    if project.section.fabrication=='welded':
        if detail in ('continuous_longitudinal_fillet','web_flange_fillet_local_patch'):
            regions.append(('web_adjacent_fillet','Faixas da alma adjacentes aos filetes contínuos das mesas superior/inferior',
                'web_flange_fillet_adjacent_base',project.section.tw_mm,
                metrics['combined_web_longitudinal_bound_mpa'],metrics['local_transverse_bound_mpa'],
                metrics['combined_web_shear_bound_mpa']))
        else:
            pending('web_weld_detail','Detalhe de fadiga da alma junto à mesa',
                'Selecionar o detalhe físico do filete contínuo alma–mesa ou fornecer a verificação do tipo de junta realmente especificado. A fabricação soldada isoladamente não define a categoria.')
    regions.append(('flange_nominal_homogeneous','Material-base homogêneo das mesas: campo nominal',
        'unnotched_base',max(project.section.tf_mm,project.section.bottom_thickness),
        metrics['flange_sigma_abs_upper_bound_mpa'],0.,metrics['flange_shear_magnitude_upper_bound_mpa']))
    for identifier,label,profile,thickness,sx,sy,tau in regions:
        bound=FatigueAbsoluteBounds(identifier,sx,sy,tau,'nbr8400_fatigue_case_i_without_mx',True,
            'Máximos por componente de '+output['case_id']+'; limites locais do modelo nominal NBR10084, separados dos ELU8800.',
            transverse_interval_mpa=(-sy,local_bending) if identifier.startswith('web') and lifetime_intervals else None,
            interval_source='No modelo local, compressão por rodas/reação é não positiva: sigma_x local em [−C,0]; flexão transversal pode ter ambos os sinais: sigma_z em [−(C+T),+T]. Máximos cobrem todas as translações.' if identifier.startswith('web') else '',
            longitudinal_interval_mpa=(-sx,metrics['web_sigma_abs_upper_bound_mpa']) if identifier.startswith('web') and lifetime_intervals else None)
        result=evaluate_8400_absolute_envelope(bound,profile=profile,thickness_mm=thickness,**design)
        output['regions'][identifier]=result
        append_region_result(identifier,label,result)
    def geometry_for_fatigue(original,kind):
        if not isinstance(original,dict) or original.get('detail_feasible') is True:return original
        normalized=deepcopy(original);ratios=[]
        rows=normalized.get('connections',[]) if kind=='stiffener' else [normalized]
        if not rows:return original
        for row in rows:
            if row.get('design') is not None:continue
            limiting=row.get('limiting_design')
            if not isinstance(limiting,dict):return original
            ratio=_value(limiting.get('utilization'),'Utilização ELU da geometria limite')
            if ratio<=1:raise ValueError('Geometria limite sem reprodução da excedência ELU.')
            row['design']=limiting;row['criterion_satisfied']=False;ratios.append(ratio)
        if not ratios:return original
        normalized.update(detail_feasible=True,original_detail_feasible=False,
            geometry_available_for_fatigue=True,uls_criterion_satisfied=False,
            usage='Somente geometria fixa para calcular fadiga; não aprova ELU nem qualifica borda de painel.')
        ratio=max(ratios)
        output['verifications'].append(Verification('fatigue/fixed_geometry_uls/'+kind,'stiffeners',
            'Critério ELU da geometria limite usada no diagnóstico de fadiga','calculated',original.get('source',SOURCE),
            'Envelope ELU',ratio,1.,'—',ratio,
            'Não atende ao critério ELU da geometria limite. Fadiga usa essa garganta fixa para diagnóstico, sem aprovação do detalhe ou do apoio de painel.',
            {'conservative_exceedance':True,'original_detail_feasible':False,'criterion_satisfied':False}))
        return normalized
    throat_complete=False
    if project.section.fabrication=='welded' and fixed_flange_web_detail is not None:
        from .autonomous_local_resistance import flange_web_weld_stress_bounds
        from .autonomous_fatigue_welds import evaluate_flange_web_weld_fatigue
        try:
            d=geometry_for_fatigue(fixed_flange_web_detail,'flange_web')
            if not isinstance(d,dict) or d.get('project_signature')!=input_signature(project) or d.get('fixed_project_detail') is not True:
                raise ValueError('Detalhe fixo de solda não vinculado ao projeto atual.')
            expected_uls={c.id for c in generate_basic_cases(project) if c.family=='ULS8800'}
            origins=d.get('origin_case_ids')
            if not isinstance(origins,(list,tuple)) or set(origins)!=expected_uls:raise ValueError('Detalhe da garganta não cobre todos os casos ELU gerados.')
            from .autonomous_fatigue_geometry import audit_fixed_weld_geometry
            audit_fixed_weld_geometry(project,d,'flange_web')
            if d.get('detail_feasible') is not True or not isinstance(d.get('design'),dict):raise ValueError('Geometria da garganta alma–mesa inviável ou ausente.')
            if _value(d.get('specified_minimum_fyw_mpa'),'fyw')<project.material.fy_mpa or _value(d.get('specified_minimum_fuw_mpa'),'fuw')<project.material.fu_mpa:
                raise ValueError('Metal de solda deve ter fyw≥fy e fuw≥fu.')
            a=_value(d['design'].get('throat_mm'),'Garganta')
            if a<=0:raise ValueError('Garganta deve ser positiva.')
            if d['design'].get('number_of_lines_per_interface')!=2 or d.get('number_of_lines')!=4:raise ValueError('Modelo exige dois filetes iguais em cada interface.')
            stresses=flange_web_weld_stress_bounds(project,throat_mm=a,
                transverse_normal_bound_mpa=metrics['local_transverse_bound_mpa'],shear_transfer_bound_mpa=metrics['combined_web_shear_bound_mpa'])
            sx=max(metrics['combined_web_longitudinal_bound_mpa'],metrics['flange_sigma_abs_upper_bound_mpa'])
            positive_sx=max(metrics['web_sigma_abs_upper_bound_mpa'],metrics['flange_sigma_abs_upper_bound_mpa'])
            sy=stresses['normal_perpendicular_bound_mpa'];scale=project.section.tw_mm/(2*a*math.sqrt(2))
            bound=FatigueAbsoluteBounds('flange_web_weld_throat',sx,sy,stresses['shear_resultant_bound_mpa'],
                'nbr8400_fatigue_case_i_without_mx',True,'Equilíbrio local e transformação da garganta a45°; detalhe fixo dimensionado com todos os ELU.',
                transverse_interval_mpa=(-sy,local_bending*scale) if lifetime_intervals else None,longitudinal_interval_mpa=(-sx,positive_sx) if lifetime_intervals else None,
                interval_source='Transferência vertical compressiva e flexão local de ambos os sinais; normal longitudinal inclui os termos do modelo nominal adotado.')
            result=evaluate_flange_web_weld_fatigue(bound,thickness_mm=max(project.section.tw_mm,project.section.tf_mm,project.section.bottom_thickness),**design)
            result['fixed_detail']=d;result['transfer_stresses']=stresses
            output['regions']['flange_web_weld_throat']=result
            append_region_result('flange_web_weld_throat','Garganta dos filetes contínuos alma–mesa',result)
            throat_complete=result.get('domain_complete') is True and not result.get('domain_pending') and not result.get('errors')
        except (ValueError,KeyError,TypeError,AttributeError) as exc:
            pending('web_flange_weld_detail','Geometria e domínio da garganta alma–mesa',str(exc))
    stiffener_complete=False
    if project.stiffener_layout!='none_or_unknown' and fixed_stiffener_detail is not None:
        from .autonomous_local_resistance import stiffener_weld_group_stress_bounds,bearing_stiffener_combined_bounds
        from .autonomous_weld_actions import envelope_action_bounds
        from .autonomous_fatigue_welds import evaluate_flange_web_weld_fatigue
        try:
            d=geometry_for_fatigue(fixed_stiffener_detail,'stiffener')
            expected_uls={c.id for c in generate_basic_cases(project) if c.family=='ULS8800'}
            if not isinstance(d,dict) or d.get('project_signature')!=input_signature(project) or d.get('fixed_project_detail') is not True:
                raise ValueError('Detalhe fixo do enrijecedor não vinculado ao projeto atual.')
            if set(d.get('origin_case_ids',[]))!=expected_uls:raise ValueError('Grupo fixo do enrijecedor não cobre todos os casos ELU.')
            from .autonomous_fatigue_geometry import audit_fixed_weld_geometry
            audit_fixed_weld_geometry(project,d,'stiffener')
            if project.stiffener_connection!='web_and_both_flanges_welded':raise ValueError('Detalhe K4 adotado exige par de chapas ligado à alma e às duas mesas.')
            if d.get('detail_feasible') is not True or {r.get('connection') for r in d.get('connections',[])}!={'alma','mesa'}:raise ValueError('Geometria das duas interfaces do enrijecedor ausente ou inviável.')
            if _value(d.get('specified_minimum_fyw_mpa'),'fyw')<project.material.fy_mpa or _value(d.get('specified_minimum_fuw_mpa'),'fuw')<project.material.fu_mpa:raise ValueError('Metal de solda do enrijecedor deve ter fyw≥fy e fuw≥fu.')
            for row in d['connections']:
                geometry=row.get('design')
                if not isinstance(geometry,dict) or geometry.get('number_of_lines')!=4:raise ValueError('Cada interface requer quatro cordões com geometria fixa.')
                for key in ('throat_mm','length_each_mm','effective_length_each_mm'):
                    if _value(geometry.get(key),key)<=0:raise ValueError('Dimensão efetiva de solda não positiva.')
            if fixed_stiffener_detail.get('station_based') is True:
                from .autonomous_fatigue_stations import collect_station_family,evaluate_station_fatigue
                station_family=_family_bounds.get('stiffener_station_family') if lifetime_intervals else collect_station_family(project,[(case,sweep,local_records)])
                if not station_family:raise ValueError('Falta cobertura de estações em todos os casos da vida inteira.')
                station_result=evaluate_station_fatigue(project,fixed_stiffener_detail,station_family,design,lifetime_intervals=lifetime_intervals)
                output['stiffener_transfer']=station_result['transfer']
                output['stiffener_station_family']=station_family
                output['stiffener_method']=station_result['method']
                labels={'stiffener_adjacent_base':'Metal-base no pé dos enrijecedores, por corpo e estação',
                    'stiffener_plate_base':'Material-base dos pares de chapas, por estação',
                    'stiffener_weld_mesa':'Gargantas dos enrijecedores nas mesas, por estação/interface',
                    'stiffener_weld_alma':'Gargantas dos enrijecedores na alma, por estação'}
                for identifier,result in station_result['regions'].items():
                    output['regions'][identifier]=result
                    append_region_result(identifier,labels[identifier],result)
                stiffener_complete=station_result['complete']
                output['design_requirements'].append('Enrijecedores por estação com filetes Q.C.; campos da viga, chapas e gargantas separados; orientação transversal nas mesas e vertical na alma.')
            else:
                if lifetime_intervals:
                    actions=_family_bounds.get('stiffener_action_bounds')
                    if actions is None:raise ValueError('Faltam seis resultantes do enrijecedor em algum caso da vida inteira.')
                else:
                    actions=envelope_action_bounds([local_records[a].get('stiffener_action_bounds') for a in positions])
                transfer=stiffener_weld_group_stress_bounds(project,d,actions)
                plate=bearing_stiffener_combined_bounds(project,actions)
                if transfer.get('complete') is not True:raise ValueError('Transferência tridimensional do grupo de soldas incompleta.')
                if plate.get('complete') is not True:raise ValueError('Domínio das chapas do enrijecedor: '+'; '.join(plate.get('pending',[])))
                output['stiffener_transfer']=transfer;output['stiffener_plate']=plate
                stiff_design={**design,'fabrication':'specified_h6_qc'}
                output['design_requirements'].append('Enrijecedores propostos com filetes contínuos Q.C. em ambas as faces de cada chapa e interfaces alma/mesas, inclusive quando o perfil-base é laminado.')
                base_traction=max(_value(row['base_metal_traction_bound_mpa'],'Tração transferida no metal-base') for row in transfer['connections'])
                global_normal=max(metrics['combined_web_longitudinal_bound_mpa'],metrics['flange_sigma_abs_upper_bound_mpa'])
                global_shear=max(metrics['combined_web_shear_bound_mpa'],metrics['flange_shear_magnitude_upper_bound_mpa'])
                adjacent_sx=global_normal+base_traction
                adjacent_sy=metrics['local_transverse_bound_mpa']+plate['normal_bound_mpa']+base_traction
                adjacent_tau=global_shear+plate['shear_bound_mpa']+base_traction
                source='Grupo tridimensional de quatro cordões com seis resultantes físicos e par de chapas; máximos de toda a vida.'
                adjacent=FatigueAbsoluteBounds('stiffener_adjacent_base',adjacent_sx,adjacent_sy,adjacent_tau,
                    'nbr8400_fatigue_case_i_without_mx',True,source,
                    transverse_interval_mpa=(-adjacent_sy,local_bending+plate['normal_bending_bound_mpa']+base_traction) if lifetime_intervals else None,
                    interval_source='Compressão vertical não positiva; flexão e tração transferida limitadas em módulo.')
                plate_bound=FatigueAbsoluteBounds('stiffener_plate_base',plate['normal_bound_mpa'],0.,plate['shear_bound_mpa'],
                    'nbr8400_fatigue_case_i_without_mx',True,source,
                    longitudinal_interval_mpa=tuple(plate['normal_interval_mpa']) if lifetime_intervals else None,
                    interval_source='Par submetido a compressão vertical e flexão de ambos os sinais, no domínio elástico do modelo.')
                details=[('stiffener_adjacent_base','Metal-base no encontro e transferência dos enrijecedores',adjacent,'stiffener_load_transfer_fillet_base',max(project.section.tw_mm,project.section.tf_mm,project.section.bottom_thickness,project.stiffener_thickness_mm)),
                         ('stiffener_plate_base','Material-base do par de chapas de enrijecedor',plate_bound,'unnotched_base',project.stiffener_thickness_mm)]
                completed=[]
                for identifier,label,bound,profile,thickness in details:
                    result=evaluate_8400_absolute_envelope(bound,profile=profile,thickness_mm=thickness,**stiff_design)
                    if identifier=='stiffener_adjacent_base':
                        from .autonomous_fatigue_scope import mark_unqualified_nominal_field
                        mark_unqualified_nominal_field(result)
                    output['regions'][identifier]=result;append_region_result(identifier,label,result)
                    completed.append(result.get('domain_complete') is True and not result.get('domain_pending') and not result.get('errors'))
                parallel=max(global_normal,metrics['local_transverse_bound_mpa'],plate['normal_bound_mpa'])+base_traction
                for row in transfer['connections']:
                    identifier='stiffener_weld_'+row['connection']
                    bound=FatigueAbsoluteBounds(identifier,parallel,row['normal_perpendicular_bound_mpa'],row['shear_resultant_bound_mpa'],
                        'nbr8400_fatigue_case_i_without_mx',True,source)
                    result=evaluate_flange_web_weld_fatigue(bound,thickness_mm=max(project.section.tw_mm,project.section.tf_mm,project.section.bottom_thickness,project.stiffener_thickness_mm),joint_profile='stiffener_load_transfer',**stiff_design)
                    result['fixed_detail']=d;result['transfer_stresses']=row
                    if row['connection']=='mesa':
                        from .autonomous_fatigue_scope import mark_unqualified_nominal_field
                        mark_unqualified_nominal_field(result)
                    output['regions'][identifier]=result;append_region_result(identifier,'Garganta do enrijecedor · '+row['connection'],result)
                    completed.append(result.get('domain_complete') is True and not result.get('domain_pending') and not result.get('errors'))
                stiffener_complete=all(completed) and len(completed)==4
        except (ValueError,KeyError,TypeError,AttributeError) as exc:
            pending('stiffener_detail','Geometria, esforços e domínio do enrijecedor',str(exc))
    # Typed remaining regions: a later qualified physical adapter can resolve
    # exactly these obligations, not suppress arbitrary text or all fatigue.
    obligations=[]
    output['resolved_region_checks']=[dict(code='flange_local_fatigue',
        method='Modelo nominal simplificado de viga superior NBR10084, trilho centrado, fixação não rígida, rodas e reações compressivas; não é dispensa de tensões físicas locais nem alegação de campo 3D nulo.',
        source='NBR10084 §9.1.3; NBR8800 §5.7.2.1 restringe seu mecanismo ELU de flexão local à tração na alma, sem dispensa geral de fadiga.'),
        dict(code='support_lower_shear_fatigue',
        method='Modelo nominal prescrito NBR10084: compressão de roda/reação, flexão transversal e cisalhamento local de roda; combinados aos campos globais. Não afirma ausência de tensões tridimensionais adicionais.',
        source='NBR10084 §9.1.3; prescribed_scope_complete em todas as posições.')]

    if throat_complete:output['resolved_region_checks'].append(dict(code='web_flange_weld_throat_fatigue',method='Garganta fixa ELU; transferência local e interação D.3.1/D.5 calculadas, incluindo limite estático AnexoB.',source=SOURCE))
    if project.section.fabrication=='welded' and not throat_complete:obligations.append(('web_flange_weld_throat_fatigue','Fadiga da garganta do filete alma–mesa',
        'Calcular fluxo transferido e tensão na garganta efetiva dos cordões; aplicar NBR8400-2 D.3.1/Anexo B, não W0 do material-base.'))
    if stiffener_complete:output['resolved_region_checks'].append(dict(code='stiffener_connection_fatigue',method='Quatro regiões calculadas: base adjacente K4,4/K4,5, chapas homogêneas e gargantas de ambas as interfaces sob seis resultantes; detalhes fixos ELU.',source=SOURCE+'; TabelaD.5 p.77; D.3.1'))
    if project.stiffener_layout!='none_or_unknown' and not stiffener_complete:obligations.append(('stiffener_connection_fatigue','Fadiga dos enrijecedores e suas soldas',
        'Faltam detalhe fixo ELU, seis resultantes físicos ou domínio completo do par: calcular base adjacente K4,4/K4,5, chapas homogêneas e gargantas das duas interfaces conforme D.3.1. O filete longitudinal K0,31 isolado não cobre esse encontro.'))
    output['required_region_checks']=[]
    for code,title,reason in obligations:
        output['required_region_checks'].append(dict(code=code,title=title,reason=reason))
        pending(code,title,reason,evidence={'requirement_code':code})
    output['complete']=not output['pending'] and not output['errors'] and bool(output['regions'])
    return output



def evaluate_fatigue_project_family(project, analyses, *,fixed_flange_web_detail=None,fixed_stiffener_detail=None):
    """One whole-life envelope across every generated loaded/empty/H-sign case.

    A per-case compressive interval cannot establish kappa over the entire life.
    Every bundle is audited first, then maxima and admissible-value intervals
    cover all passages together. Component maxima need not be concurrent.
    """
    failure=dict(case_id='FAT8400_LIFETIME',verifications=[],regions={},pending=[],errors=[],
        group_selection={},design_requirements=[],complete=False,full_compliance=False)
    def fail(reason):
        failure['errors'].append(reason);failure['pending'].append(reason)
        failure['verifications'].append(Verification('fatigue/family_coverage','fatigue','Cobertura de todos os casos de fadiga',
            'pending',SOURCE,'FAT8400_LIFETIME',reason=reason))
        return failure
    try:
        if not isinstance(analyses,(list,tuple,PackedFatigueAnalyses)) or not analyses:raise ValueError('Família de fadiga vazia.')
        expected={c.id for c in generate_basic_cases(project) if c.family=='FAT8400'}
        for row in analyses:
            if not isinstance(row,(list,tuple)) or len(row)!=3:raise ValueError('Cada análise exige caso, varredura e registros locais.')
            del row
        ids=[]
        for row in analyses:
            ids.append(row[0].id)
            del row
        if len(ids)!=len(set(ids)) or set(ids)!=expected:raise ValueError('Família deve cobrir exatamente todos os casos FAT8400 gerados, sem duplicações.')
        audited=[]
        for case,sweep,records in analyses:
            audit=evaluate_absolute_fatigue_project(project,case,sweep,records)
            if audit.get('input_audit_complete') is not True:raise ValueError(case.id+': '+'; '.join(audit['errors'] or audit['pending']))
            audited.append(audit)
            del case,sweep,records
        metrics={k:max(r['audited_metrics'][k] for r in audited) for k in METRICS}
        family=dict(project_signature=input_signature(project),case_ids=ids,metrics=metrics,
            local_bending_bound_mpa=max(r['audited_local_bending_bound_mpa'] for r in audited),
            critical_case_by_metric={k:max(audited,key=lambda r:r['audited_metrics'][k])['case_id'] for k in METRICS},
            method='Envoltória da vida inteira: todas as passagens carregadas/vazias e sinais de ações gerados; intervalos são conjuntos de valores, não séries artificiais.')
        from .autonomous_fullheight_actions import enabled as fullheight_enabled
        if fullheight_enabled(project):
            from .autonomous_fullheight_actions import compact_nominal_case,envelope_station_actions
            from .autonomous_fullheight_runtime import resolved_detail
            from .autonomous_fullheight_fatigue import evaluate_fullheight_family_bounds
            family['fullheight_station_family']=envelope_station_actions(
                compact_nominal_case((records[a] for a in sweep.translation_positions),input_signature(project))
                for case,sweep,records in analyses)
            selection=explicit_component_group_selection(project.fatigue.component_group,getattr(project.fatigue,'group_source',''))
            result=evaluate_fullheight_family_bounds(project,metrics,group_selection=selection,
                family_evidence=family,physical_detail=resolved_detail(project),
                fixed_flange_detail=fixed_flange_web_detail,fixed_station_detail=fixed_stiffener_detail)
            result['analysed_case_ids']=ids
            result['audited_case_metrics']={r['case_id']:r['audited_metrics'] for r in audited}
            return result
        from .autonomous_weld_actions import envelope_action_bounds
        station_based=isinstance(fixed_stiffener_detail,dict) and fixed_stiffener_detail.get('station_based') is True
        if station_based:
            from .autonomous_fatigue_stations import collect_station_family
            family['stiffener_station_family']=collect_station_family(project,analyses)
        else:
            action_rows=[]
            for case,sweep,records in analyses:
                action_rows.extend(records[a].get('stiffener_action_bounds') for a in sweep.translation_positions)
                del case,sweep,records
            if action_rows and all(isinstance(row,dict) for row in action_rows):
                family['stiffener_action_bounds']=envelope_action_bounds(action_rows)
        case,sweep,records=analyses[0]
        result=evaluate_absolute_fatigue_project(project,case,sweep,records,
            fixed_flange_web_detail=fixed_flange_web_detail,fixed_stiffener_detail=fixed_stiffener_detail,_family_bounds=family)
        result['analysed_case_ids']=ids
        result['audited_case_metrics']={r['case_id']:r['audited_metrics'] for r in audited}
        return result
    except (ValueError,KeyError,TypeError,AttributeError) as exc:return fail(str(exc))


def evaluate_fatigue_family_project(project,case_records,*,fixed_flange_web_detail=None,fixed_stiffener_detail=None):
    """Compatibility entry point accepting named case/sweep/local-record bundles."""
    if isinstance(case_records,(list,tuple)) and all(isinstance(row,dict) and set(row)=={'case','sweep','local_records'} for row in case_records):
        analyses=[(r['case'],r['sweep'],r['local_records']) for r in case_records]
    else:analyses=case_records
    return evaluate_fatigue_project_family(project,analyses,fixed_flange_web_detail=fixed_flange_web_detail,fixed_stiffener_detail=fixed_stiffener_detail)
