"""Lossless, process-local storage for completed fatigue cases.

Only tuples produced inside this process are packed. Never load untrusted pickle
content. Consumers receive ordinary original tuples/dicts, not lazy mappings.
"""
import gzip
import io
import pickle

_SAMPLE_KEYS=('x_m','side','web_sigma_abs_mpa','web_shear_abs_mpa',
    'flange_sigma_abs_mpa','flange_shear_abs_mpa','local_compression_mpa',
    'local_shear_mpa','combined_longitudinal_mpa','combined_shear_mpa',
    'local_transverse_mpa','local_bending_mpa')


class _SampleValues:
    __slots__=('values',)
    def __init__(self,values):self.values=values


def _encode_record(record):
    # Only the exact known ordinary-dict schema is encoded. Malformed or
    # alternative records remain unchanged for the existing validators.
    if type(record) is dict and type(record.get('combined_section_samples')) is list:
        record=dict(record)
        record['combined_section_samples']=[
            _SampleValues(tuple(sample.values()))
            if type(sample) is dict and tuple(sample)==_SAMPLE_KEYS else sample
            for sample in record['combined_section_samples']]
    return record


def _decode_record(record):
    if type(record) is not dict or type(record.get('combined_section_samples')) is not list:return record
    from .autonomous_engine import _CombinedSectionSample
    samples=record['combined_section_samples']
    for index,sample in enumerate(samples):
        if type(sample) is _SampleValues:
            samples[index]=vars(_CombinedSectionSample(*sample.values))
    return record


class PackedFatigueAnalyses:
    """Re-iterable completed-case storage with ordinary materialized records.

    Pack one translation at a time, avoiding a second complete case or a full
    uncompressed pickle buffer. All original validation runs after restoration;
    no audit result is cached. Compression is internal, never an import format.
    """
    def __init__(self):self._cases=[]

    def append(self,row):
        stream=io.BytesIO()
        with gzip.GzipFile(fileobj=stream,mode='wb',compresslevel=1,mtime=0) as output:
            def write(value):pickle.dump(value,output,protocol=pickle.HIGHEST_PROTOCOL)
            structured=type(row) in (list,tuple) and len(row)==3 and type(row[2]) is dict
            write(structured)
            if not structured:write(row)
            else:
                write((type(row),row[0],row[1],len(row[2])))
                for key,record in row[2].items():write((key,_encode_record(record)))
        self._cases.append(stream.getvalue())

    def __len__(self):return len(self._cases)

    def __getitem__(self,index):
        with gzip.GzipFile(fileobj=io.BytesIO(self._cases[index]),mode='rb') as source:
            if not pickle.load(source):return pickle.load(source)
            row_type,case,sweep,count=pickle.load(source)
            records={}
            for _ in range(count):
                key,record=pickle.load(source)
                records[key]=_decode_record(record)
            return row_type((case,sweep,records))

    def __iter__(self):
        for index in range(len(self)):yield self[index]
