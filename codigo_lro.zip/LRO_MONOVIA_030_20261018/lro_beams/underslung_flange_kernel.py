"""Isolated EN 1993-6:2007 local bottom-flange candidate. N, mm, MPa.
NOT a whole-member, connection, NBR compliance, or fatigue acceptance check.
"""
from dataclasses import dataclass
from math import exp, sqrt, isfinite

SOURCE = 'EN 1993-6:2007 incorporating AC:2009'
class DomainError(ValueError): pass

def number(v, name, positive=False, nonnegative=False):
    if isinstance(v, bool) or not isinstance(v, (int, float)) or not isfinite(v):
        raise DomainError(f'{name} must be finite numeric')
    if positive and v <= 0 or nonnegative and v < 0:
        raise DomainError(f'{name} outside positive/nonnegative domain')
    return v

@dataclass(frozen=True)
class Geometry:
    bottom_b_mm: float
    web_tw_mm: float
    bottom_tf_mm: float
    edge_to_contact_n_mm: float
    construction: str
    root_radius_mm: float = 0
    weld_throat_mm: float = 0
    straight_parallel_i: bool = True
    def __post_init__(self):
        for k in ('bottom_b_mm','web_tw_mm','bottom_tf_mm','edge_to_contact_n_mm'):
            number(getattr(self,k),k,positive=True)
        for k in ('root_radius_mm','weld_throat_mm'): number(getattr(self,k),k,nonnegative=True)
        if self.straight_parallel_i is not True: raise DomainError('Only straight parallel-flange I sections implemented')
        if self.construction not in ('rolled','welded'): raise DomainError('Specify rolled or welded')
        if self.construction == 'rolled' and (self.root_radius_mm <= 0 or self.weld_throat_mm != 0):
            raise DomainError('Rolled requires root radius and no weld throat')
        if self.construction == 'welded' and (self.weld_throat_mm <= 0 or self.root_radius_mm != 0):
            raise DomainError('Welded requires fillet weld throat and no root radius; other joints pending')
        physical_root = self.root_radius_mm if self.construction == 'rolled' else sqrt(2)*self.weld_throat_mm
        physical_clearance = .5*(self.bottom_b_mm-self.web_tw_mm)-self.edge_to_contact_n_mm-physical_root
        if self.bottom_b_mm <= self.web_tw_mm or self.m_mm <= 0 or physical_clearance <= 0:
            raise DomainError('Wheel contact must be on clear bottom-flange outstand outside root zone')
    @property
    def mu(self): return 2*self.edge_to_contact_n_mm/(self.bottom_b_mm-self.web_tw_mm)
    @property
    def m_mm(self):
        root = self.root_radius_mm if self.construction=='rolled' else sqrt(2)*self.weld_throat_mm
        return .5*(self.bottom_b_mm-self.web_tw_mm)-.8*root-self.edge_to_contact_n_mm

@dataclass(frozen=True)
class Action:
    individual_wheel_N: float
    stage: str # mechanical, service, ultimate, fatigue
    basis: str # mechanical or EN 1993-6:2007; NOT NBR
    provenance: str # caller's combination/dynamic-factor ledger
    def __post_init__(self):
        number(self.individual_wheel_N,'individual_wheel_N',nonnegative=True)
        if self.stage not in ('mechanical','service','ultimate','fatigue'): raise DomainError('Unknown action stage')
        if self.basis not in ('mechanical',SOURCE): raise DomainError('EN checks cannot silently adopt NBR factors')
        if self.stage!='mechanical' and self.basis!=SOURCE: raise DomainError('Verification actions require EN basis')
        if not isinstance(self.provenance,str) or not self.provenance.strip(): raise DomainError('Combination/factor provenance required')

def symmetric_pair_from_total(total_N, *, stage, basis, provenance, equal_split_confirmed):
    """Only explicit equal split. Individual API never auto-divides by two."""
    number(total_N,'pair total',nonnegative=True)
    if equal_split_confirmed is not True: raise DomainError('Obtain actual individual wheel reactions')
    return Action(total_N/2,stage,basis,provenance+'; explicitly equal opposite-wheel pair /2')

def coefficients(mu):
    number(mu,'mu',positive=True)
    if mu >= 1: raise DomainError('Contact must lie on flange outstand')
    return ((.050-.580*mu+.148*exp(3.015*mu), -2.110+1.977*mu+.0076*exp(6.530*mu)),
            (2.230-1.490*mu+1.390*exp(-18.33*mu),10.108-7.408*mu-10.108*exp(-1.364*mu)),
            (.730-1.580*mu+2.910*exp(-6.000*mu),0.0))

def _interior_stresses(g, action, *, distance_to_nearest_end_mm, symmetric_opposite_wheels_confirmed):
    """§5.8(3), table 5.2, bottom face tensile positive; top face signs reverse.
    Opposite wheels pictured in Fig 5.6 are NOT summed as adjacent axial wheels.
    Assumes symmetric equal opposite contacts; arbitrary asymmetric arrangement pending.
    """
    number(distance_to_nearest_end_mm,'end distance',nonnegative=True)
    if distance_to_nearest_end_mm <= g.bottom_b_mm: raise DomainError('§5.8 interior requires end distance > b; transition pending')
    if symmetric_opposite_wheels_confirmed is not True: raise DomainError('Asymmetric/unilateral wheel analysis pending')
    return tuple((cx*action.individual_wheel_N/g.bottom_tf_mm**2,cy*action.individual_wheel_N/g.bottom_tf_mm**2) for cx,cy in coefficients(g.mu))

def local_stresses(g, action, *, distance_to_nearest_end_mm, symmetric_opposite_wheels_confirmed,
                   nearest_longitudinal_spacing_mm=None, isolated_longitudinal_station_confirmed=False):
    """Single-wheel §5.8(3) requires spacing >=1.5b or explicit isolated station."""
    if nearest_longitudinal_spacing_mm is None:
        if isolated_longitudinal_station_confirmed is not True:
            raise DomainError('Provide actual nearest longitudinal spacing or confirm isolated station')
    else:
        number(nearest_longitudinal_spacing_mm,'nearest longitudinal spacing',positive=True)
        if nearest_longitudinal_spacing_mm < 1.5*g.bottom_b_mm:
            raise DomainError('Close wheels require §5.8(8) superposition')
    return _interior_stresses(g,action,distance_to_nearest_end_mm=distance_to_nearest_end_mm,
                             symmetric_opposite_wheels_confirmed=symmetric_opposite_wheels_confirmed)

def close_wheel_stresses(g, actions, spacings_mm, *, distance_to_nearest_end_mm, symmetric_opposite_wheels_confirmed):
    """§5.8(8): same-side longitudinal cluster, identical contact geometry.
    Every consecutive spacing must be <1.5b; conservatively superpose full local
    stresses of ALL cluster wheels. Other independent clusters evaluated separately.
    """
    if not actions or len(spacings_mm)!=len(actions)-1: raise DomainError('Invalid cluster')
    for d in spacings_mm:
        number(d,'wheel spacing',positive=True)
        if d>=1.5*g.bottom_b_mm: raise DomainError('Split cluster at spacing >=1.5b')
    if len({(a.stage,a.basis,a.provenance) for a in actions})!=1: raise DomainError('Cluster requires same simultaneous combination and factor ledger')
    total=Action(sum(a.individual_wheel_N for a in actions),actions[0].stage,actions[0].basis,actions[0].provenance)
    return _interior_stresses(g,total,distance_to_nearest_end_mm=distance_to_nearest_end_mm,symmetric_opposite_wheels_confirmed=symmetric_opposite_wheels_confirmed)

def perpendicular_unstiffened_end_transverse(g, action):
    """§5.8(6), eq 5.8 only. At perpendicular physical end. NOT full stress state.
    Parallel flange tf equals mean tf. No interpolation over 0 < xe <= b.
    """
    u=g.mu
    return (5.6-3.225*u-2.8*u**3)*action.individual_wheel_N/g.bottom_tf_mm**2

@dataclass(frozen=True)
class ENResistance:
    fy_MPa: float
    gamma: float
    national_annex_reference: str
    def __post_init__(self):
        number(self.fy_MPa,'fy',positive=True); number(self.gamma,'gamma',positive=True)
        if not isinstance(self.national_annex_reference,str) or not self.national_annex_reference.strip():
            raise DomainError('Explicit gamma source/National Annex selection required')

def bottom_flange_resistance(g, action, resistance, *, global_midflange_sigma_MPa,
                             end_case, wheel_spacing_mm=None, remote_from_end_confirmed=False):
    """§6.7 eq 6.2-6.4, table 6.2(a,b). gamma is gamma_M0.
    Other end support/stop cases explicitly pending; no partial stiffener credit.
    """
    if action.stage!='ultimate' or action.basis!=SOURCE: raise DomainError('Already-combined EN ultimate individual wheel required')
    number(global_midflange_sigma_MPa,'global midflange sigma')
    q=g.m_mm+g.edge_to_contact_n_mm
    if end_case=='nonreinforced_simple_joint': leff=2*q
    elif end_case=='remote':
        if remote_from_end_confirmed is not True: raise DomainError('Engineer must confirm remote end domain of table 6.2(b)')
        if wheel_spacing_mm is None: raise DomainError('Finite actual wheel spacing required')
        number(wheel_spacing_mm,'wheel spacing',positive=True)
        leff=min(4*sqrt(2)*q,2*sqrt(2)*q+.5*wheel_spacing_mm)
    else: raise DomainError('End-stop/fully-supported/stiffened end resistance pending; no guessed restraint credit')
    fd=resistance.fy_MPa/resistance.gamma
    reduction=max(0.0,1-(global_midflange_sigma_MPa/fd)**2)
    capacity=leff*g.bottom_tf_mm**2*fd/(4*g.m_mm)*reduction
    return dict(effective_length_mm=leff,lever_arm_mm=g.m_mm,capacity_N=capacity,
                utilization=(action.individual_wheel_N/capacity if capacity>0 else float('inf')),
                local_only=True,source='EN 1993-6:2007 §6.7 / table 6.2(a,b)')

def service_point_check(local_xy, *, action, global_faces, resistance, same_state_confirmed):
    """§7.5(3), (7.2a,b,d). global_faces = [(sx,sy,txy) bottom, top].
    Caller supplies coexistent global stresses at THIS point, section and wheel
    position, for both surfaces. No independent maxima or absolute-value mixing.
    gamma is gamma_M,ser. Does not evaluate other points or member deflections.
    """
    if action.stage!='service' or action.basis!=SOURCE: raise DomainError('EN characteristic/test combination required')
    if same_state_confirmed is not True: raise DomainError('Coexistent local/global state required')
    if len(local_xy)!=2 or len(global_faces)!=2: raise DomainError('Two local components and two face states required')
    for v in local_xy: number(v,'local stress')
    results=[]; fd=resistance.fy_MPa/resistance.gamma
    for sign,glob in zip((1,-1),global_faces):
        if len(glob)!=3: raise DomainError('Each face needs sx,sy,tau')
        for v in glob: number(v,'global stress')
        sx=glob[0]+sign*local_xy[0]; sy=glob[1]+sign*local_xy[1]; tau=glob[2]
        vm=sqrt(sx*sx+sy*sy-sx*sy+3*tau*tau)
        ratio=max(abs(sx)/fd,abs(sy)/fd,sqrt(3)*abs(tau)/fd,vm/fd)
        results.append(dict(sigma_x_MPa=sx,sigma_y_MPa=sy,tau_MPa=tau,von_mises_MPa=vm,utilization=ratio))
    return dict(faces=results,utilization=max(r['utilization'] for r in results),local_only=True)

FATIGUE_STATUS = ('PENDING: §9.3.4 requires local bottom-flange stress histories in fatigue; '
                  'no fatigue PASS from this kernel. Detail category, cycles, coexistent signed '
                  'global/local histories and EN 1993-1-9 verification required.')
