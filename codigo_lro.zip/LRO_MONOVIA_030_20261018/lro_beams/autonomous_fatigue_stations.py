"""Whole-life fatigue of physical stiffener stations and oriented interfaces.

Actions and nominal fields are enveloped only at the same station. Member,
beam-foot and throat stresses remain distinct. Final criteria may be enveloped
between stations; their stress components are never crossed spatially.
"""
from __future__ import annotations
import math,hashlib,json
from .autonomous_fatigue import FatigueAbsoluteBounds,evaluate_8400_absolute_envelope
from .autonomous_fatigue_welds import evaluate_flange_web_weld_fatigue
from .autonomous_fatigue_regions import aggregate_station_results
from .autonomous_fatigue_scope import mark_unqualified_nominal_field
from .autonomous_lateral_restraints import all_lateral_positions
from .autonomous_response import stiffener_self_weight_loads

NOMINAL_KEYS=('web_sigma_abs_mpa','flange_sigma_abs_mpa','web_shear_abs_mpa',
    'flange_shear_abs_mpa','local_transverse_mpa','local_bending_mpa','local_shear_mpa')
SOURCE='NBR8400-2, Anexo B p.45, 5.6.2, D.1/D.2, D.3.1 e D.5; tensões nominais por corpo/estação e orientação física y/y/z, sem repetir a tração da garganta no metal-base.'
FOOT_BASIS=('NBR8400-2 corrigida, Anexo B p.45: extremos nominais no metal-base por resistência dos materiais; '
    '5.6.2 e D.1/D.2: efeito de entalhe nas categorias. O pé usa o campo nominal do próprio corpo, '
    'incluindo flexões secundárias já calculadas; a tração da garganta e a resistência da faixa de transferência '
    'têm verificações próprias e não são somadas novamente às componentes. K4/K4 é envelope conservador '
    'de categorias do encontro qualificado, não enquadramento literal de qualquer direção. Não é recuperação local 3D.')


def _number(v,label):
    if isinstance(v,bool) or not isinstance(v,(int,float)) or not math.isfinite(v) or v<0:
        raise ValueError(label+': limite não negativo e finito obrigatório.')
    return float(v)


def collect_station_family(project,analyses):
    """Audit all sampled stations before taking same-station life maxima."""
    from .autonomous_stiffener_actions import stiffener_station_geometry,envelope_stiffener_stations
    from .autonomous_local import local_bounds_at_section
    geometry=stiffener_station_geometry(project)
    expected={row['station_id']:row['x_m'] for row in geometry}
    if not expected:raise ValueError('Geometria física dos enrijecedores ausente.')
    nominal={sid:{key:0. for key in NOMINAL_KEYS} for sid in expected}
    critical={sid:{} for sid in expected};action_records=[];count=0
    for case,sweep,records in analyses:
        fixed_jumps={load.position_m for load in stiffener_self_weight_loads(project,case.factors)}
        if not isinstance(getattr(sweep,'observer_sample_keys',None),(list,tuple)) or not sweep.observer_sample_keys:
            raise ValueError('Rota por estação exige registro completo dos cortes da varredura; fallback global não qualifica campos locais menores.')
        for a in sweep.translation_positions:
            record=records[a];rows=record.get('stiffener_stations')
            if record.get('stiffener_station_complete') is not True or record.get('stiffener_station_pending'):
                raise ValueError('Corpo livre por estação incompleto em '+case.id+'.')
            if not isinstance(rows,list) or len(rows)!=len(expected):raise ValueError('Quantidade de estações físicas incompleta.')
            ids=[r.get('station_id') for r in rows if isinstance(r,dict)]
            if len(ids)!=len(rows) or len(set(ids))!=len(ids) or set(ids)!=set(expected):
                raise ValueError('Estações não correspondem à geometria independente do projeto.')
            samples_record=record.get('combined_section_samples')
            if not isinstance(samples_record,list) or not samples_record:raise ValueError('Trilha de cortes ausente na posição da estação.')
            sample_index={}
            for sample in samples_record:
                sample_index.setdefault(sample.get('x_m'),[]).append(sample)
            for row in rows:
                sid=row['station_id'];x=_number(row.get('x_m'),'Posição da estação')
                if not math.isclose(x,expected[sid],rel_tol=0,abs_tol=1e-10):raise ValueError('Estação deslocada em relação ao projeto.')
                values=row.get('nominal_bounds')
                if not isinstance(values,dict) or any(key not in values for key in NOMINAL_KEYS):raise ValueError('Campos nominais ausentes no corte da estação '+sid+'.')
                if values.get('complete') is not True or values.get('x_m')!=x or not isinstance(values.get('source'),str) or not values['source'].strip():
                    raise ValueError('Campos nominais não vinculados ao corte completo da estação.')
                values={key:_number(values[key],key) for key in NOMINAL_KEYS}
                if record.get('combined_section_samples'):
                    samples=sample_index.get(x,[])
                    if not samples:raise ValueError('A trilha da varredura não contém o corte da estação.')
                    jumps=set(all_lateral_positions(project))|{a+w.offset_m for w in project.wheels}|fixed_jumps
                    sides=({'left','right'} if (x==0 and project.beam_end_left_mm>0) or (x==project.span_m and project.beam_end_right_mm>0)
                           else {'right'} if x==0 else {'left'} if x==project.span_m else {'left','right'} if x in jumps else {'right'})
                    if not sides.issubset({sample.get('side') for sample in samples}):raise ValueError('Trilha da estação omite um lado físico do corte/salto.')
                    for key in NOMINAL_KEYS[:4]:
                        maximum=max(_number(sample.get(key),'Amostra da estação '+key) for sample in samples)
                        if not math.isclose(values[key],maximum,rel_tol=1e-9,abs_tol=1e-9):
                            raise ValueError('Campo nominal da estação não reproduz os cortes registrados: '+key)

                if values['local_bending_mpa']>values['local_transverse_mpa']+1e-10:raise ValueError('Flexão local maior que o limite transversal total.')
                if isinstance(record.get('compression_patches'),list):
                    local=local_bounds_at_section(record,x)
                    for key,target in [('local_transverse_mpa',local['transverse_compression_bound_mpa']+local['sigmaT_bound_mpa']),
                                       ('local_bending_mpa',local['sigmaT_bound_mpa']),('local_shear_mpa',local['local_shear_complete_bound_mpa'])]:
                        if not math.isclose(values[key],target,rel_tol=1e-9,abs_tol=1e-9):raise ValueError('Campo local da estação difere do corte físico: '+key)
                for key,value in values.items():
                    if value>=nominal[sid][key]:
                        nominal[sid][key]=value;critical[sid][key]=dict(case_id=case.id,translation_m=a,x_m=x)
            action_records.append(rows);count+=1
        del case,sweep,records
    if not action_records:raise ValueError('Vida inteira sem registros de estações.')
    actions=envelope_stiffener_stations(action_records)
    if isinstance(actions,dict) and (actions.get('complete') is False or actions.get('pending')):
        raise ValueError('Envelope de ações por estação incompleto.')
    for row in actions['stations']:row['nominal_bounds']=dict(nominal[row['station_id']],complete=True,x_m=row['x_m'],source=SOURCE)
    return dict(actions=actions,nominal_bounds=nominal,critical_case_by_nominal=critical,
        audited_position_count=count,station_ids=list(expected),source=SOURCE)


def _nominal_foot_demands(nominal,member,interface_id):
    """Nominal fields of two distinct bodies, with their physical directions.

    The member normal is axial z of the stiffener pair; beam normals remain
    longitudinal x and local transverse z (web) or y (flange). A resultant
    weld-traction norm is neither another load nor a stress concentration
    factor. Its separate interface checks are retained by the caller.
    """
    if interface_id not in ('top','bottom','web'):
        raise ValueError('Interface física desconhecida para tensão nominal do pé.')
    if member.get('complete') is not True:
        raise ValueError('Campo nominal do par incompleto; não qualifica o pé do filete.')
    normal=_number(member.get('normal_bound_mpa'),'Normal nominal do par')
    shear=_number(member.get('shear_bound_mpa'),'Cisalhamento nominal do par')
    interval=member.get('normal_interval_mpa')
    if (not isinstance(interval,(list,tuple)) or len(interval)!=2 or
        any(isinstance(v,bool) or not isinstance(v,(int,float)) or not math.isfinite(v) for v in interval) or
        interval[0]>interval[1] or max(map(abs,interval))>normal+1e-10*max(1.,normal)):
        raise ValueError('Intervalo nominal do par não corresponde ao limite de tensão.')
    if interface_id=='web':
        sx=_number(nominal['web_sigma_abs_mpa'],'Normal longitudinal da alma')
        sy=_number(nominal['local_transverse_mpa'],'Normal transversal da alma')
        tau=_number(nominal['web_shear_abs_mpa'],'Cisalhamento global da alma')+_number(nominal['local_shear_mpa'],'Cisalhamento local da alma')
        bend=_number(nominal['local_bending_mpa'],'Flexão transversal da alma')
        if bend>sy+1e-10*max(1.,sy):raise ValueError('Flexão local excede limite transversal nominal.')
        iy=(-sy,bend)
    else:
        sx=_number(nominal['flange_sigma_abs_mpa'],'Normal longitudinal da mesa')
        sy=0.;tau=_number(nominal['flange_shear_abs_mpa'],'Cisalhamento nominal da mesa');iy=(0.,0.)
    return dict(beam=dict(sx=sx,sy=sy,tau=tau,ix=None,iy=iy),
                member=dict(sx=normal,sy=0.,tau=shear,ix=tuple(interval),iy=(0.,0.)))


def evaluate_station_fatigue(project,fixed_detail,family,design,*,lifetime_intervals):
    from .autonomous_local_resistance import stiffener_station_weld_stress_bounds
    detail_hash=hashlib.sha256(json.dumps(fixed_detail,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()).hexdigest()
    transfer=stiffener_station_weld_stress_bounds(project,fixed_detail,family['actions'])
    if transfer.get('complete') is not True or transfer.get('pending'):
        raise ValueError('Transferência física por estação incompleta: '+'; '.join(transfer.get('pending',[])))
    expected=set(family['station_ids']);stations=transfer.get('stations',[])
    if len(stations)!=len(expected) or {r['station_id'] for r in stations}!=expected:
        raise ValueError('Transferência omite estação da vida inteira.')
    fixed_stations=fixed_detail.get('stations',[])
    if len(fixed_stations)!=len(expected) or {r['station_id'] for r in fixed_stations}!=expected:
        raise ValueError('Detalhe fixo ELU não corresponde às mesmas estações físicas.')
    bins={key:[] for key in ('stiffener_adjacent_base','stiffener_plate_base','stiffener_weld_mesa','stiffener_weld_alma')}
    thickness=max(project.section.tw_mm,project.section.tf_mm,project.section.bottom_thickness,project.stiffener_thickness_mm)
    stiff_design={**design,'fabrication':'specified_h6_qc'}
    def bounds(identifier,sx,sy,tau,*,ix=None,iy=None):
        return FatigueAbsoluteBounds(identifier,sx,sy,tau,'nbr8400_fatigue_case_i_without_mx',True,SOURCE,
            longitudinal_interval_mpa=ix if lifetime_intervals else None,
            transverse_interval_mpa=iy if lifetime_intervals else None,
            interval_source='Intervalos da vida inteira na mesma estação e orientação material; sem séries artificiais ou soma de componentes de outros corpos.')
    def add(region,sid,interface,result):
        result['station_id']=sid;result['interface_id']=interface
        result['station_nominal_evidence']=family['critical_case_by_nominal'][sid]
        bins[region].append(dict(station_id=sid,interface_id=interface,result=result))
    for station in stations:
        sid=station['station_id'];nominal=family['nominal_bounds'][sid];member=station['member_bounds']
        if member.get('complete') is not True:raise ValueError(sid+': domínio do par de chapas incompleto: '+'; '.join(member.get('pending',[])))
        normal=_number(member.get('normal_bound_mpa'),'Normal do par');shear=_number(member.get('shear_bound_mpa'),'Cisalhamento do par')
        plate_bound=bounds('stiffener_plate_base',normal,0.,shear,ix=tuple(member['normal_interval_mpa']))
        add('stiffener_plate_base',sid,'member',evaluate_8400_absolute_envelope(plate_bound,profile='unnotched_base',thickness_mm=project.stiffener_thickness_mm,**stiff_design))
        faces=station.get('connections',[])
        if len(faces)!=3 or {r['interface_id'] for r in faces}!={'top','bottom','web'}:raise ValueError('Faltam interfaces físicas top/bottom/web.')
        for face in faces:
            iid=face['interface_id'];web=iid=='web';expected_direction=[0,0,1] if web else [0,1,0]
            if face.get('seam_direction_xyz')!=expected_direction or (web and face.get('normal_parallel_member_complete') is not True):
                raise ValueError('Orientação/campo paralelo do cordão incompleto.')
            interval=face.get('normal_parallel_member_interval_mpa')
            if not isinstance(interval,(list,tuple)) or len(interval)!=2 or any(isinstance(v,bool) or not isinstance(v,(int,float)) or not math.isfinite(v) for v in interval) or interval[0]>interval[1]:
                raise ValueError('Intervalo paralelo do cordão inválido.')
            if web:
                if face.get('requires_web_transverse_interval') is not True:raise ValueError('Interface web não inclui campo transversal da alma.')
                parallel_interval=(min(interval[0],-nominal['local_transverse_mpa']),max(interval[1],nominal['local_bending_mpa']))
            else:
                if tuple(interval)!=(0.,0.):raise ValueError('Modelo nominal transversal da mesa recebeu normal paralela indevida.')
                parallel_interval=(0.,0.)
            parallel=max(abs(v) for v in parallel_interval)
            region='stiffener_weld_alma' if web else 'stiffener_weld_mesa'
            weld=bounds(region,parallel,_number(face['normal_perpendicular_bound_mpa'],'Normal perpendicular'),
                _number(face['shear_resultant_bound_mpa'],'Cisalhamento de garganta'),ix=parallel_interval)
            result=evaluate_flange_web_weld_fatigue(weld,thickness_mm=thickness,joint_profile='stiffener_load_transfer',**stiff_design)
            result['fixed_detail_reference']=dict(evidence_key='fixed_stiffener_weld_detail',
                project_signature=fixed_detail.get('project_signature'),detail_sha256=detail_hash,
                station_id=sid,interface_id=iid,throat_mm=face['throat_mm'],leg_mm=face['leg_mm'],
                length_each_mm=face['length_each_mm'],effective_length_each_mm=face['effective_length_each_mm'],
                static_design_satisfied=face['static_design_satisfied'],limiting_geometry_used=face['limiting_geometry_used'])
            result['transfer_stresses']=face
            add(region,sid,iid,result)
            # Anexo B p.45 uses nominal material stresses. The scalar 2a/t
            # times weld traction is a separate transfer check, not an extra
            # stress in every tensor component. In pure N it would repeat N/A
            # and manufacture a second normal and shear. Retain the real beam
            # fields and the member's N/A + M/W, including its secondary effects.
            demands=_nominal_foot_demands(nominal,member,iid)
            for body in ('beam','member'):
                demand=demands[body]
                foot=bounds('stiffener_adjacent_base',demand['sx'],demand['sy'],demand['tau'],
                    ix=demand['ix'],iy=demand['iy'])
                result=evaluate_8400_absolute_envelope(foot,profile='stiffener_load_transfer_fillet_base',thickness_mm=thickness,**stiff_design)
                result['nominal_stress_basis']=FOOT_BASIS
                add('stiffener_adjacent_base',sid,iid+':'+body,result)
    regions={key:aggregate_station_results(rows) for key,rows in bins.items()}
    # Preserve arithmetic and fixed-detail identity without qualifying an
    # unresolved receiving-flange / seam-parallel nominal field.
    for key in ('stiffener_adjacent_base','stiffener_weld_mesa'):
        mark_unqualified_nominal_field(regions[key])
    return dict(regions=regions,transfer=transfer,station_family=family,fixed_detail_sha256=detail_hash,
        complete=all(r['domain_complete'] and not r.get('errors') and not r.get('domain_pending') for r in regions.values()),
        nominal_foot_basis=FOOT_BASIS,
        method='Verificação por estação/interface, seguida do maior critério. Forças de um garfo não são concentradas em um grupo estreito; σ paralela acompanha a orientação real do cordão.')
