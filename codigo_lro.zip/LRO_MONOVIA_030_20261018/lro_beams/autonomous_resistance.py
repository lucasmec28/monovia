"""Source-backed NBR8800 section resistance components, not global approval.

Non-slender web symmetric I sections, rectangular or verified catalogue
properties. The torsion/combined stability route is evaluated separately;
these isolated resistances cannot be used to bypass §5.5.2.3.
"""
from __future__ import annotations
import math
from .model import Section,Material
from .geometry import section_properties
from .beam_torsion import thin_wall_i_torsion_properties
SOURCE_LOCAL='ABNT NBR 8800:2024 + Er1:2025, D.2.2, Tabela D.1, D.2.8(c,e,f,h), Tabela 4 nota a'
SOURCE_AXIAL='ABNT NBR 8800:2024 + Er1:2025, 5.3.2–5.3.5.1, Tabelas 4 e 5'


def _valid(s,m):
    if s.fabrication=='welded' and s.root_radius_mm!=0:raise ValueError('Perfil soldado não possui raio de concordância laminado.')
    if not s.doubly_symmetric:raise ValueError('Componente limitado a seção I duplamente simétrica.')
    vals=(s.d_mm,s.bf_mm,s.tw_mm,s.tf_mm,m.E_mpa,m.G_mpa,m.fy_mpa,m.gamma_a1)
    if any(isinstance(x,bool) or not isinstance(x,(int,float)) or not math.isfinite(x) or x<=0 for x in vals):raise ValueError('Geometria/material inválido.')
    if s.d_mm<=2*s.tf_mm+2*s.root_radius_mm or s.bf_mm<=s.tw_mm:raise ValueError('Geometria inválida.')
    if s.fabrication not in ('rolled','welded'):raise ValueError('Fabricação inválida.')
    return section_properties(s)


def _branch(lam,lp,lr,mp,mr,mcr):
    if lam<=lp:return mp,'compacto'
    if lam<=lr:return mp-(mp-mr)*(lam-lp)/(lr-lp),'semicompacto'
    return mcr,'esbelto'


def local_bending_resistances(s:Section,m:Material):
    g=_valid(s,m)
    if g.Ix_mm4<g.Iy_mm4:raise ValueError('Eixo vertical não é o de maior inércia; esta rota da Tabela D.1 não se aplica.')
    root=math.sqrt(m.E_mpa/m.fy_mpa)
    kc=max(.35,min(.76,4/math.sqrt(g.h_mm/s.tw_mm)))
    lf=s.bf_mm/(2*s.tf_mm);lp=.38*root
    if s.fabrication=='rolled':
        lr=.83*math.sqrt(m.E_mpa/(.7*m.fy_mpa));coef=.69
    else:
        lr=.95*math.sqrt(m.E_mpa*kc/(.7*m.fy_mpa));coef=.90*kc
    flanges={}
    for axis,W,Z in [('major',g.Wx_mm3,g.Zx_mm3),('minor',g.Wy_mm3,g.Zy_mm3)]:
        nominal,branch=_branch(lf,lp,lr,m.fy_mpa*Z,.7*m.fy_mpa*W,coef*m.E_mpa*W/lf**2)
        flanges[axis]=dict(capacity_knm=min(nominal,1.5*m.fy_mpa*W)/m.gamma_a1/1e6,branch=branch,
            lambda_=lf,lambda_p=lp,lambda_r=lr,kc=kc,source=SOURCE_LOCAL)
    lw=g.h_mm/s.tw_mm;lwp=3.76*root;lwr=5.70*root
    if lw>lwr:raise ValueError('Alma esbelta exige Anexo E; não usar a resistência do Anexo D.')
    web,branch=_branch(lw,lwp,lwr,m.fy_mpa*g.Zx_mm3,m.fy_mpa*g.Wx_mm3,0)
    web=min(web,1.5*m.fy_mpa*g.Wx_mm3)/m.gamma_a1/1e6
    return dict(major_flange=flanges['major'],minor_flange=flanges['minor'],
        major_web=dict(capacity_knm=web,branch=branch,lambda_=lw,lambda_p=lwp,lambda_r=lwr,source=SOURCE_LOCAL),
        major_local_knm=min(web,flanges['major']['capacity_knm']),minor_local_knm=flanges['minor']['capacity_knm'])


def reduction_chi(lambda_zero):
    if not isinstance(lambda_zero,(int,float)) or isinstance(lambda_zero,bool) or not math.isfinite(lambda_zero) or lambda_zero<0:raise ValueError('Esbeltez reduzida inválida.')
    return .658**(lambda_zero**2) if lambda_zero<=1.5 else .877/lambda_zero**2


def _effective_width(width,thickness,limit,chi,fy,c1,c2):
    slender=width/thickness
    if slender<=limit/math.sqrt(chi):return width
    elastic=(c2*limit/slender)**2*fy
    r=math.sqrt(elastic/(chi*fy))
    return max(0,min(width,width*(1-c1*r)*r))


def axial_compression_resistance(s:Section,m:Material,Lx_m:float,Ly_m:float,Lz_m:float):
    """Uniform axial compression, forks/free warping; lengths explicitly supplied.

    Intermediate one-flange braces do not automatically shorten Ly or Lz.
    This scalar capacity does not assess combined bending/torsion stability.
    """
    g=_valid(s,m)
    if any(isinstance(x,bool) or not isinstance(x,(int,float)) or not math.isfinite(x) or x<=0 for x in (Lx_m,Ly_m,Lz_m)):raise ValueError('Comprimentos de flambagem inválidos.')
    torsion=thin_wall_i_torsion_properties(s.d_mm,s.bf_mm,s.tf_mm,s.tw_mm)
    r0sq=(g.Ix_mm4+g.Iy_mm4)/g.A_mm2
    nex=math.pi**2*m.E_mpa*g.Ix_mm4/(Lx_m*1000)**2
    ney=math.pi**2*m.E_mpa*g.Iy_mm4/(Ly_m*1000)**2
    nez=(math.pi**2*m.E_mpa*torsion['Cw_mm6']/(Lz_m*1000)**2+m.G_mpa*torsion['J_mm4'])/r0sq
    ne=min(nex,ney,nez);lam=math.sqrt(g.A_mm2*m.fy_mpa/ne);chi=reduction_chi(lam)
    root=math.sqrt(m.E_mpa/m.fy_mpa);kc=max(.35,min(.76,4/math.sqrt(g.h_mm/s.tw_mm)))
    flange_limit=.56*root if s.fabrication=='rolled' else .64*math.sqrt(m.E_mpa*kc/m.fy_mpa)
    half=s.bf_mm/2;effective_half=_effective_width(half,s.tf_mm,flange_limit,chi,m.fy_mpa,.22,1.49)
    effective_web=_effective_width(g.h_mm,s.tw_mm,1.49*root,chi,m.fy_mpa,.18,1.31)
    area=g.A_mm2-4*(half-effective_half)*s.tf_mm-(g.h_mm-effective_web)*s.tw_mm
    if area<=0:raise ValueError('Área efetiva não positiva.')
    return dict(capacity_kn=chi*area*m.fy_mpa/m.gamma_a1/1000,lambda_zero=lam,chi=chi,
        Ag_mm2=g.A_mm2,Aef_mm2=area,Nex_kn=nex/1000,Ney_kn=ney/1000,Nez_kn=nez/1000,
        effective_half_flange_mm=effective_half,effective_web_mm=effective_web,source=SOURCE_AXIAL,
        torsion_Cw_mm6=torsion['Cw_mm6'],torsion_J_mm4=torsion['J_mm4'],
        torsion_property_basis='Retângulos de parede fina; Cw setorial das mesas, coerente com resposta autônoma; sem crédito do trilho/raios.')
