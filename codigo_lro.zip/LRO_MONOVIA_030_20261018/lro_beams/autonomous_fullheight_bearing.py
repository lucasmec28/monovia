"""Actual centred vertical-bearing branch of the nominal full-height detail.

This consumes a bound of the ORIGINAL support Rz, not a wheel reaction, a
brace wrench or P/2. NBR 8800 5.7.9 serial weld requirements, the physical
minimum column and local classical-group equilibrium are separate ledgers.
The symmetric split Rz/2 follows the explicit two-identical-plate idealization
of BEARING_FATIGUE_DETAIL_ADDENDUM, not a new global force distribution.

Rz already includes stationary G. At each plate, bottom introduction is Rz/2,
own weight is -G at its real centroid, and the top/web receiving group balances
both. G is not added again to lower introduction or global loads. No contact,
fitted bearing, extra restraint or complete-station approval is inferred.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, replace
from hashlib import sha256
import json
from math import fsum, isfinite, pi, sqrt

from .autonomous_fullheight_detail import (
    FullHeightNominalDetail, fullheight_geometry, fullheight_detail_assessment,
    fullheight_mass_ledger, fullheight_mixed_group, _group_component_checks,
)
from .autonomous_resistance import reduction_chi, _effective_width
from top_unstiffened_candidate.stiffeners.selfweight_transfer import (
    mixed_group, solve_mixed_group, MINIMUM_CONNECTION_FORCE_N, GROUP_ASSUMPTION,
    _rectangular_core_stability,
)

SCHEMA = "TOP_FULLHEIGHT_REAL_VERTICAL_BEARING_V1"
SOURCE = "NBR 8800:2024+Er1:2025 5.7.9.2-.6, 5.3, 6.1.5.2, 6.2/6.5; BEARING_FATIGUE_DETAIL_ADDENDUM 2026-10-17"


def _number(value, name, *, positive=False):
    if type(value) not in (int, float) or not isfinite(value) or abs(value) > 1e50 or value < 0 or (positive and value == 0):
        raise ValueError(name+" must be a finite real nonnegative value, never bool")
    return float(value)


def _check(name, demand, capacity, units, *, bound=False, geometry=False, scope=""):
    demand, capacity = _number(demand, name), _number(capacity, name+" capacity", positive=True)
    ratio = demand/capacity
    status = "SUFFICIENT" if ratio <= 1 else ("GEOMETRY_NOT_MET" if geometry else "NOT_SUFFICIENT" if bound else "COMPONENT_EXCEEDED")
    return {"check_id": name, "demand": demand, "capacity": capacity, "units": units,
        "utilization": ratio, "status": status, "sufficient_bound": bound,
        "physical_failure_proven": False, "source": SOURCE, "scope": scope}


def bearing_minimum_column(detail, *, at_end=True, gamma_a1=1.1):
    """Published .75h column using only the minimum real post-cope section.

    Local plate stockiness still uses c, never c-R. Effective-width reduction
    is reused from the existing NBR bearing-column kernel, then the complete
    removed inner width is subtracted conservatively. No web-strip material
    beyond the real end projection is borrowed. This function supplies a
    capacity, not a station or support-role classifier.
    """
    if type(detail) is not FullHeightNominalDetail or type(at_end) is not bool:
        raise TypeError("Typed full-height detail and explicit boolean at_end required")
    gamma = _number(gamma_a1, "gamma_a1", positive=True)
    g, s = fullheight_geometry(detail), detail.section
    c, ts, tw = detail.outstand_mm, detail.plate_thickness_mm, s.web_thickness_mm
    removed = max(detail.upper_cope.radius_mm, detail.lower_cope.radius_mm)
    b = c-removed
    prescribed_strip = (12. if at_end else 25.)*tw
    # At either support, the lesser supplied physical end projection proves a
    # symmetric strip of this width is present. Less material gives a smaller
    # conservative strip, not a fictitious extension beyond the actual beam.
    available_strip = 2*min(detail.beam_end_left_mm, detail.beam_end_right_mm) if at_end else prescribed_strip
    strip = min(prescribed_strip, available_strip)
    A = 2*ts*b+strip*tw
    outer, inner = tw/2+c, tw/2+removed
    I = 2*ts*(outer-inner)*(outer*outer+outer*inner+inner*inner)/3+strip*tw**3/12
    E = min(s.material.E_mpa, detail.plate_material.E_mpa)
    fy = min(s.material.fy_mpa, detail.plate_material.fy_mpa)
    Le = .75*g["h_mm"]
    Ne = pi*pi*E*I/Le**2
    lam = sqrt(A*fy/Ne)
    chi = reduction_chi(lam)
    limit = .56*sqrt(E/fy)
    ce_full = _effective_width(c, ts, limit, chi, fy, .22, 1.49)
    ce_core = max(0., min(b, ce_full-removed))
    we = 0. if strip == 0 else _effective_width(strip/2, tw, limit, chi, fy, .22, 1.49)
    Ae = 2*ce_core*ts+2*we*tw
    if Ae <= 0:
        raise ValueError("The conservative real bearing-column effective area is not positive")
    return {"Amin_mm2": A, "Imin_mm4": I, "Aef_mm2": Ae, "capacity_N": chi*Ae*fy/gamma,
        "minimum_plate_core_width_mm": b, "removed_inner_width_mm": removed,
        "physical_c_over_t": c/ts, "local_limit": limit, "stockiness_pass": c/ts <= limit,
        "prescribed_web_strip_mm": prescribed_strip, "credited_web_strip_mm": strip,
        "symmetric_available_end_strip_mm": available_strip if at_end else None,
        "effective_outer_plate_width_mm": ce_core, "effective_web_half_width_mm": we,
        "h_mm": g["h_mm"], "effective_length_mm": Le, "effective_length_factor": .75,
        "elastic_critical_force_N": Ne, "lambda_zero": lam, "chi": chi,
        "fy_lower_mpa": fy, "E_lower_mpa": E, "gamma_a1": gamma,
        "axis": "longitudinal axis in the web midplane; prescribed flexural mode",
        "basis": "least physically continuous outer plate strips plus available prescribed web strip; no full-rectangle plate credit after circular copes",
        "at_end": at_end, "source": SOURCE, "complete_bearing_eligible": False}


@dataclass(frozen=True)
class BearingPlateInterfaceField:
    """Two serial nominal groups, not one fictitious five-line stiffness group."""
    required_Fz_N: float
    lines: tuple


def _absolute_line_force(q0, q1, length):
    """Exact integral of the absolute value of a linear line traction."""
    if q0*q1 >= 0:
        return length*(abs(q0)+abs(q1))/2
    return length*(q0*q0+q1*q1)/(2*(abs(q0)+abs(q1)))


def _all_core_cuts_bound(detail, rows, own_G):
    """Triangle-inequality bound, not an invented interior stress tensor.

    Every y cut of the physical continuous core is within c of every vertical
    load and h/2 from every horizontal load in z. Absolute integrals bound any
    subset of the actual external loads. Putting all these resultants on the
    smaller real core is the existing nominal rectangular-section reserve.
    Unlike a root-only envelope, this does not assume the interior moment is
    monotone when top and bottom bearing forces have opposite signs.
    """
    g = fullheight_geometry(detail)
    H = fsum(_absolute_line_force(v.qy0_N_per_mm, v.qy1_N_per_mm, v.interface.length_mm) for v in rows)
    V = fsum(_absolute_line_force(v.qz0_N_per_mm, v.qz1_N_per_mm, v.interface.length_mm) for v in rows)+own_G
    M = detail.outstand_mm*V+g["h_mm"]/2*H
    h, t = g["web_length_mm"], detail.plate_thickness_mm
    A, W = t*h, t*h*h/6
    compression, shear = H/A+M/W, 1.5*V/A
    record = {"normal_force_abs_bound_N": H, "shear_force_abs_bound_N": V,
        "moment_abs_bound_Nmm": M, "area_mm2": A, "elastic_modulus_mm3": W,
        "sigma_yy_abs_bound_mpa": compression, "tau_yz_abs_bound_mpa": shear,
        "y_domain_absolute_u_mm": (0., detail.outstand_mm),
        "z_core_interval_mm": (g["web_low_z_mm"], g["web_high_z_mm"]),
        "all_nominal_core_cuts_covered": True, "new_interior_stress_field_created": False,
        "physical_failure_from_exceeded_bound": False,
        "basis": "Exact absolute linear-traction integrals plus triangle inequality over actual loads; existing nominal rectangular-core reserve, no assumed root maximum"}
    stability, check = _rectangular_core_stability(outstand_mm=detail.outstand_mm,
        thickness_mm=t, active_height_mm=h, E_mpa=detail.plate_material.E_mpa,
        G_mpa=detail.plate_material.G_mpa, fy_mpa=detail.plate_material.fy_mpa,
        compression_mpa=compression)
    stability["compression_envelope_source"] = record["basis"]
    return record, stability, asdict(check)


def _plate_case(detail, side, plate_bodies, lower_force, own_G, case_id, *, station_id, floor_case):
    """Recover an equilibrated plate from its actual lower introduction and G."""
    full = fullheight_mixed_group(detail, side, station_id=station_id)
    lower_lines = tuple(v for v in full.interfaces if ":bottom:" in v.interface_id)
    receiver_lines = tuple(v for v in full.interfaces if ":bottom:" not in v.interface_id)
    lower, receiver = mixed_group(lower_lines), mixed_group(receiver_lines)
    mass = fsum(v["mass_kg"] for v in plate_bodies)
    yg = fsum(v["mass_kg"]*v["y_mm"] for v in plate_bodies)/mass
    zg = fsum(v["mass_kg"]*v["z_from_bottom_mm"] for v in plate_bodies)/mass
    lower_solution = solve_mixed_group(lower, Fy_N=0., Fz_N=lower_force, Mx_about_group_Nmm=0.)
    receiver_solution = solve_mixed_group(receiver, Fy_N=0., Fz_N=own_G-lower_force,
        Mx_about_group_Nmm=own_G*(yg-receiver.centroid_y_mm)-lower_force*(lower.centroid_y_mm-receiver.centroid_y_mm))
    rows = tuple(receiver_solution.lines)+tuple(lower_solution.lines)
    field = BearingPlateInterfaceField(own_G, rows)
    # This consumer contains only algebra on supplied physical tractions and
    # cuts. Its five-line *single-group* authentication wrapper is deliberately
    # not used: the two groups here have different, explicit load-path roles.
    checks, sections = _group_component_checks(detail, field, side)
    # The old G-only downward root/top detachment subset is not re-labelled as
    # a proof of the reversed bearing transfer. Compression column, each real
    # net ligament and actual root components are evaluated independently.
    checks = [v for v in checks if v["check_id"] not in (
        "plate_root_top_block_bottom_resistance_omitted", "plate_core_transverse_compression_stability")]
    sections.pop("plate_root_top_block_bottom_resistance_omitted", None)
    core_bound, core_stability, core_check = _all_core_cuts_bound(detail, rows, own_G)
    checks.append(core_check)
    sections["core_stability"] = core_stability
    sections["nominal_core_all_cuts_bounds"] = core_bound
    force_y = fsum(v.Fy_N for v in rows)
    force_z = fsum(v.Fz_N for v in rows)-own_G
    moment = fsum(v.moment_about(0., 0.) for v in rows)-own_G*yg
    scale = max(1., own_G, lower_force)
    equilibrium = abs(force_y) <= scale*1e-11 and abs(force_z) <= scale*1e-11 and abs(moment) <= scale*detail.section.depth_mm*1e-11
    if not equilibrium:
        raise ValueError("Actual lower introduction + local G + top/web receiver equilibrium did not close")
    return {"case_id": case_id, "side": side, "lower_introduction_N": lower_force,
        "own_downward_G_N": own_G, "receiver_group_Fz_on_plate_N": own_G-lower_force,
        "lower_group": asdict(lower_solution), "top_web_receiver_group": asdict(receiver_solution),
        "G_centroid_y_mm": yg, "G_centroid_z_mm": zg,
        "checks": checks, "section_results": sections,
        "equilibrium": {"force_y_residual_N": force_y, "force_z_residual_N": force_z,
            "moment_x_residual_Nmm": moment, "satisfied": equilibrium,
            "identity": "Rz/2 at lower connection - G at body centroid + top/web reactions = 0"},
        "executed_checks_sufficient": all(v["utilization"] <= 1 for v in checks),
        "minimum_connection_force_case": floor_case,
        "global_force_increment_N": 0., "fatigue_range_increment_N": 0.,
        "nominal_stiffness_idealization": GROUP_ASSUMPTION,
        "top_CJP_given_full_Rz_automatically": False,
        "transverse_or_fork_torque_inferred": False}


def evaluate_fullheight_bearing(detail, reaction_bound_N, structural_G_factor=1., station_id="bearing", *,
        station_x_mm=0., at_end=True, gamma_a1=1.1,
        reaction_source="caller-supplied bound of the original support vertical design reaction",
        reaction_includes_stationary_G=True):
    """Evaluate this *explicitly identified* real bottom-bearing station.

    reaction_bound_N is the nonnegative ULS bound of the original centred Rz.
    This function neither obtains nor authenticates that source by coincidence
    of coordinates. The caller owns the response/action-basis receipt. Rz
    already includes stationary weights; no selfweight/global load is added.
    """
    if type(detail) is not FullHeightNominalDetail:
        raise TypeError("Resolved FullHeightNominalDetail required")
    R = _number(reaction_bound_N, "original vertical reaction bound")
    factor = _number(structural_G_factor, "structural_G_factor", positive=True)
    gamma = _number(gamma_a1, "gamma_a1", positive=True)
    if gamma != 1.1:
        raise ValueError("The adopted local-component kernel fixes gamma_a1=1.1; another resistance basis requires a separate authenticated adapter")
    if type(at_end) is not bool or type(reaction_includes_stationary_G) is not bool:
        raise TypeError("Bearing role and G-basis flags must be actual booleans")
    if not reaction_includes_stationary_G:
        raise ValueError("Supply original Rz recomputed with stationary G; this local module cannot invent the missing global reaction increment")
    if not isinstance(station_id, str) or not station_id.strip() or not isinstance(reaction_source, str) or not reaction_source.strip():
        raise ValueError("Station identity and original-reaction source required")
    g, s = fullheight_geometry(detail), detail.section
    assessment = fullheight_detail_assessment(detail)
    ledger = fullheight_mass_ledger(detail, station_x_mm, station_id=station_id)
    Gpair = -ledger["Fz_N"]*factor
    column = bearing_minimum_column(detail, at_end=at_end, gamma_a1=gamma)
    minimum_c = s.bottom_flange_width_mm/3-s.web_thickness_mm/2
    minimum_t = max(s.bottom_flange_thickness_mm/2, detail.outstand_mm/16)
    checks = [
        _check("bearing_minimum_outstand", minimum_c, detail.outstand_mm, "mm", geometry=True,
            scope="NBR 8800 5.7.9.5(a), only actual loaded bottom flange; does not gate shear-only intermediates"),
        _check("bearing_minimum_thickness", minimum_t, detail.plate_thickness_mm, "mm", geometry=True,
            scope="NBR 8800 5.7.9.5(b), only actual loaded bottom flange"),
        _check("bearing_plate_stockiness", column["physical_c_over_t"], column["local_limit"], "ratio", geometry=True,
            scope="Physical outstand c used; Rc never reduces the stockiness dimension"),
        _check("bearing_minimum_column", R+Gpair, column["capacity_N"], "N", bound=True,
            scope="Sufficient absolute bound |Rz|+G on local column demand; not physical lower introduction and not an added global force"),
    ]
    pending = list(assessment["pending"])
    for name, weld in (("web", detail.web_fillets), ("bottom", detail.bottom_attachment)):
        if weld.endpoint_tolerance_mm:
            pending.append(name+"_effective_line_geometry: the nominal group uses the full-size physical run; a nonzero endpoint tolerance requires regenerated effective lines before transfer credit")
    if not at_end:
        pending.append("interior_web_strip_extent: caller must verify that the actual interior member contains the complete 25tw longitudinal strip")
    invalid_detail_checks = [v["check_id"] for v in assessment["checks"] if not v["passed"]]
    pending += ["physical_detail_requirement: "+v for v in invalid_detail_checks]
    if any("no_long_joint_reduction" in name for name in invalid_detail_checks):
        raise ValueError("Long-joint effective-length reduction is outside this nominal bearing group")
    cases, serial = [], []
    for side in (-1, 1):
        bodies = [v for v in ledger["points"] if v["side"] == side]
        own_G = -fsum(v["Fz_N"] for v in bodies)*factor
        # Only the symmetrical pair divides the original REACTION. No wheel
        # P/2 is mapped to an arbitrary station or to the top CJP.
        lower = R/2
        actual = _plate_case(detail, side, bodies, lower, own_G, "actual_Rz_and_G", station_id=station_id, floor_case=False)
        if R:
            local_floor = max(lower, MINIMUM_CONNECTION_FORCE_N)
            floor = _plate_case(detail, side, bodies, local_floor, own_G, "local_connection_minimum_once", station_id=station_id, floor_case=True)
        else:
            # No upward introduction exists: the only existing direction is
            # own gravity. Do not invent an upward 45 kN bearing action.
            local_floor = 0.
            floor = _plate_case(detail, side, bodies, 0., max(own_G, MINIMUM_CONNECTION_FORCE_N),
                "local_connection_minimum_once", station_id=station_id, floor_case=True)
            floor['minimum_force_direction']='gravity_only_no_upward_introduction'
        cases.append(actual)
        zero = _plate_case(detail, side, bodies, 0., own_G, "zero_reaction_bound_vertex_with_G",
            station_id=station_id, floor_case=False)
        zero["represents_physical_time_history_state"] = False
        zero["scope"] = "Lower vertex of the conservative 0<=Rz<=bound interval; not an asserted real support state"
        cases.append(zero)
        cases.append(floor)
        # NBR .2/.3 requires lower attachment and web attachment in SERIES.
        # Full Rz/2 rather than an unprovided residual is the declared design
        # bound for each plate. Its web scalar demand conservatively includes
        # own G by |Rz/2|+G; this is not substituted for equilibrated fields.
        for name, weld, length, demand, receiver in (
                ("lower", detail.bottom_attachment, g["bottom_length_mm"], max(lower, local_floor), s.material),
                ("web", detail.web_fillets, g["web_length_mm"], max(lower+own_G, MINIMUM_CONNECTION_FORCE_N), s.material)):
            area = 2*weld.leg_mm/sqrt(2)*length
            footprint = 2*weld.leg_mm*length
            prefix = f"{station_id}:plate:{side:+d}:serial_{name}"
            row = {"interface": name, "side": side, "demand_N": demand, "effective_area_mm2": area,
                "physical_length_per_line_mm": length, "line_count": 2,
                "force_per_line_N_per_mm": demand/(2*length),
                "source": "NBR 8800 5.7.9.2/.3 full-reaction design option instead of residual; serial capacity requirement, not a separate external load",
                "global_load_increment_N": 0.}
            local = [
                _check(prefix+"/fillet_resultant", demand, .60*weld.material.fu_mpa/1.35*area, "N",
                    bound=True, scope="NBR 8800 Table 9 resultant capacity with the same physical fixed fillet"),
                _check(prefix+"/plate_footprint_shear", demand,
                    min(.60*detail.plate_material.fy_mpa/gamma, .60*detail.plate_material.fu_mpa/1.35)*footprint,
                    "N", bound=True, scope="Actual directly fused plate footprint, no throat/base-area interchange"),
            ]
            if name == "web":
                local.append(_check(prefix+"/web_footprint_shear", demand,
                    min(.60*receiver.fy_mpa/gamma, .60*receiver.fu_mpa/1.35)*footprint,
                    "N", bound=True, scope="Actual fused web footprint, full serial transfer requirement"))
            row["checks"] = local; checks.extend(local); serial.append(row)
    lower_net_area = 2*detail.plate_thickness_mm*g["bottom_length_mm"]
    checks += [
        _check("bearing_loaded_plate_net_ligament_compression", R, detail.plate_material.fy_mpa/gamma*lower_net_area,
            "N", bound=True, scope="Actual two post-cope lower ligaments; not the larger pair-column area"),
        _check("bearing_web_two_real_vertical_cuts_shear", R+Gpair,
            min(.60*s.material.fy_mpa/gamma, .60*s.material.fu_mpa/1.35)*(2*s.web_thickness_mm*g["web_length_mm"]),
            "N", bound=True, scope="Two physical web cuts; conservative serial transfer plus own G bound, not an interior elastic-peak proof"),
    ]
    for case in cases:
        checks.extend(dict(v,
            check_id=f"{station_id}:{case['side']:+d}:{case['case_id']}/"+v["check_id"],
            physical_component_check_id=v["check_id"], case_id=case["case_id"], side=case["side"])
            for v in case["checks"])
    pending += [
        "receiver_member_interaction: combine supplied actual receiver footprints/strip functions with the member stresses in the same action basis",
        "plate_normal_shear_interaction: combine supplied nominal root/ligament functions in the actual yz plane; the plate does not receive member sigma_x",
        "reaction_receipt: caller must bind this scalar to the original centred vertical support-reaction envelope and its ULS factors",
    ]
    signature = sha256(json.dumps({"detail": detail.to_dict(), "Rz": R, "Gfactor": factor,
        "station_id": station_id, "station_x_mm": station_x_mm, "at_end": at_end,
        "gamma_a1": gamma, "reaction_source": reaction_source}, sort_keys=True, allow_nan=False).encode()).hexdigest()
    return {"schema": SCHEMA, "status": "REAL_BEARING_NOMINAL_CHECKS_CALCULATED",
        "station_id": station_id, "reaction_bound_N": R, "reaction_source": reaction_source,
        "reaction_action_basis": "original support vertical ULS reaction already including stationary G",
        "reaction_direction": "centred_upward_compressive_support_reaction",
        "uplift_or_asymmetric_bearing_covered": False,
        "reaction_interval_N": (0., R), "reaction_interval_vertices_evaluated": True,
        "physical_time_history_created": False,
        "structural_G_factor": factor, "own_pair_G_N": Gpair,
        "lower_introduction_total_N": R, "column_absolute_demand_bound_N": R+Gpair,
        "column": column, "loaded_plate_net_area_mm2": lower_net_area,
        "serial_weld_requirements": serial, "plate_cases": cases, "checks": checks,
        "pending": list(dict.fromkeys(pending)), "geometry_inputs_hash": detail.input_signature,
        "input_signature": signature, "mass_ledger": ledger,
        "maximum_utilization": max(v["utilization"] for v in checks),
        "exceeded_check_ids": [v["check_id"] for v in checks if v["utilization"] > 1],
        "any_sufficient_bound_exceeded": any(v.get("sufficient_bound", False) and v["utilization"] > 1 for v in checks),
        "bearing_geometry_satisfied": detail.outstand_mm >= minimum_c and detail.plate_thickness_mm >= minimum_t,
        "computed_checks_sufficient": all(v["utilization"] <= 1 for v in checks),
        "complete_bearing_eligible": False, "station_qualified": False, "member_qualified": False,
        "as_built_verified": False, "fitted_contact_credited": False,
        "global_force_increment_N": 0., "global_mass_increment_kg": 0., "fatigue_range_increment_N": 0.,
        "wheel_P_over_2_used": False, "horizontal_fork_or_brace_actions_inferred": False,
        "new_restraint_requested": False, "source": SOURCE}


def bearing_reaction_unit_field(detail, side, *, station_id="bearing"):
    """Signed linear field for ONE NEWTON of pair Rz, G/floor excluded.

    This is an influence coefficient for the same explicit nominal serial
    group idealization. It does not supply a fatigue class or create a history.
    A caller may scale it only by the matching original centred reaction.
    """
    if type(detail) is not FullHeightNominalDetail or type(side) is not int or side not in (-1, 1):
        raise TypeError("Typed full-height detail and physical side -1/+1 required")
    ledger = fullheight_mass_ledger(detail, 0., station_id=station_id)
    bodies = [v for v in ledger["points"] if v["side"] == side]
    result = _plate_case(detail, side, bodies, .5, 0., "unit_original_pair_reaction", station_id=station_id, floor_case=False)
    domain_pending = [name+"_effective_line_geometry: nonzero endpoint tolerance requires regenerated effective interface lines"
        for name, weld in (("web", detail.web_fillets), ("bottom", detail.bottom_attachment)) if weld.endpoint_tolerance_mm]
    result.update(pair_reaction_N=1., field_units="MPa_per_N_of_original_pair_Rz",
        G_included=False, connection_floor_included=False, fatigue_history_created=False,
        fatigue_classification_performed=False, geometry_inputs_hash=detail.input_signature,
        domain_pending=domain_pending, nominal_effective_line_domain_complete=not domain_pending,
        effective_line_basis="Nominal square-ended full-size physical runs; endpoint tolerance zero required for transfer credit without regenerated effective geometry",
        input_signature=sha256(json.dumps({"geometry": detail.input_signature, "side": side,
            "station_id": station_id, "source": SOURCE, "unit_pair_Rz_N": 1.}, sort_keys=True).encode()).hexdigest(),
        scope="Influence coefficients of the declared centred serial-group model only; no arbitrary support/brace action, no extra global load")
    return result


__all__ = ["bearing_minimum_column", "evaluate_fullheight_bearing", "bearing_reaction_unit_field"]
