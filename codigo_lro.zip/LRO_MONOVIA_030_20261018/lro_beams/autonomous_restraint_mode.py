"""Separate resistance-length declarations from analysis boundary conditions.

The nominal mode is not an elastic redistribution model.  Intermediate
positions remain explicit input for resistance consumers, while the load and
response model retains only its original end forks.  Old projects migrate to
physical_response; selecting this mode is never an implicit JSON migration.
"""
from __future__ import annotations

PHYSICAL_RESPONSE = 'physical_response'
RESISTANCE_LENGTHS_ONLY = 'resistance_lengths_only'
MODES = (PHYSICAL_RESPONSE, RESISTANCE_LENGTHS_ONLY)


def resistance_lengths_only(project):
    mode = getattr(project, 'restraint_application', PHYSICAL_RESPONSE)
    if mode not in MODES:
        raise ValueError('Modo de aplicação dos travamentos desconhecido.')
    return mode == RESISTANCE_LENGTHS_ONLY


def analysis_brace_positions(project, field):
    if field not in ('upper_braces_m', 'lower_braces_m', 'lateral_only_braces_m'):
        raise ValueError('Família de travamento desconhecida.')
    return () if resistance_lengths_only(project) else tuple(getattr(project, field))


def analysis_has_lateral_restraints(project):
    return bool(analysis_brace_positions(project, 'lateral_only_braces_m'))


def mode_evidence(project):
    nominal = resistance_lengths_only(project)
    return {
        'mode': project.restraint_application,
        'analysis_end_supports': project.support_model,
        'intermediate_analysis_restraints': not nominal,
        'intermediate_restraint_reactions_generated': not nominal,
        'resistance_positions_m': {
            name: list(getattr(project, name))
            for name in ('upper_braces_m', 'lower_braces_m', 'lateral_only_braces_m')
        },
        'analysis_positions_m': {
            name: list(analysis_brace_positions(project, name))
            for name in ('upper_braces_m', 'lower_braces_m', 'lateral_only_braces_m')
        },
        'scope': (
            'Posições delimitam apenas comprimentos resistentes. A análise permanece '
            'bi-garfo, sem apoios intermediários, novas reações ou redistribuição de '
            'esforços e flechas. Não é uma simulação física das contenções.'
            if nominal else
            'As contenções intermediárias fazem parte da análise física acoplada.'
        ),
    }
