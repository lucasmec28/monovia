"""Small physical-applicability editor; no approval checkbox or implicit waiver."""
from __future__ import annotations
from dataclasses import asdict, replace
from copy import deepcopy
import hashlib,json,math,re
import streamlit as st
from .autonomous_actions import ActionApplicability, APPLICABILITY_OPTIONS, action_applicability_errors

_PREFIX='autonomous_inputs:actions:'
def _key(name):return _PREFIX+name

def _signature(value):
    return hashlib.sha256(json.dumps(asdict(value),sort_keys=True,allow_nan=True).encode()).hexdigest()

def _prepare(initial):
    signature=_signature(initial)
    known={st.session_state.get(_key('source_signature')),st.session_state.get(_key('output_signature'))}
    if signature not in known:
        for key in list(st.session_state):
            if isinstance(key,str) and key.startswith(_PREFIX):del st.session_state[key]
        st.session_state[_key('source_signature')]=signature
        st.session_state[_key('record')]=deepcopy(initial)
    return deepcopy(st.session_state[_key('record')])

def _select(label,name,value,*,help=None):
    labels=dict(APPLICABILITY_OPTIONS[name]);options=list(labels)
    if value not in options:
        options.append(value);labels[value]='Seleção importada não reconhecida: '+str(value)
    return st.selectbox(label,options,index=None if _key(name) in st.session_state else options.index(value),
                        format_func=lambda x:labels[x],key=_key(name),help=help)

def _number(label,name,value):
    return st.number_input(label,min_value=0.,value=None if _key(name) in st.session_state or value is None else float(value),
                           step=.01,format='%.3f',key=_key(name))

def parse_test_wheels(text):
    if not isinstance(text,str):raise ValueError('Informe valores separados por ponto e vírgula.')
    if not text.strip():return ()
    try:values=tuple(float(x.replace(',','.')) for x in re.split(r'[;\s]+',text.strip()) if x)
    except ValueError as exc:raise ValueError('Use reações em kN separadas por ponto e vírgula.') from exc
    if len(values)>20 or any(not math.isfinite(x) or x<0 for x in values):raise ValueError('Reações devem ser finitas, não negativas, até vinte rodas.')
    return values

def render_action_applicability(initial: ActionApplicability) -> ActionApplicability:
    if not isinstance(initial,ActionApplicability):raise TypeError('initial deve ser ActionApplicability.')
    value=_prepare(initial)
    st.markdown('**Situações físicas e ensaio de carga**')
    cols=st.columns(3)
    for col,name,label in zip(cols,('environment','bumper_load_path','test_location'),('Exposição do caminho','Reação do batente','O ensaio de carga solicita este trecho?')):
        help_text=('Não é endereço ou cidade. Indique se as rodas transmitem a carga de ensaio a esta viga. '
                   'NBR 10084:2020, 8.3(c): caso especial de ensaio dinâmico; NBR 8400-5:2019, 4.1 e Tabela 1: cargas de ensaio.'
                   if name=='test_location' else None)
        with col:value=replace(value,**{name:_select(label,name,getattr(value,name),help=help_text)})
    st.caption('Se a ponte for ensaiada montada sobre esta viga, inclua o ensaio neste trecho. Se o ensaio ocorrer em estrutura independente ou não carregar este trecho, selecione a exclusão correspondente; as cargas de operação continuam no cálculo.')
    if value.test_location=='on_this_runway':
        value=replace(value,test_method=_select('Como informar o ensaio','test_method',value.test_method))
        if value.test_method=='wheel_vertical':
            st.caption('Informe a reação vertical TOTAL de cada roda no ensaio, já com o peso da ponte e a dinâmica/sobrecarga de ensaio. Esses valores substituem G + ΨpQ das rodas operacionais.')
            # This editable string is parsed back into input data. Use roundtrip
            # precision, not display-only :g (which silently shortened imports).
            raw=st.text_input('Reações totais dinâmicas de ensaio por roda (kN)',value='; '.join(repr(float(v)) for v in value.test_wheel_vertical_kn),key=_key('test_wheels_text'))
            try:value=replace(value,test_wheel_vertical_kn=parse_test_wheels(raw))
            except ValueError as exc:
                st.error(str(exc));value=replace(value,test_wheel_vertical_kn=(math.nan,))
        elif value.test_method!='unknown':
            value=replace(value,test_equipment=_select('Enquadramento do equipamento para ensaio','test_equipment',value.test_equipment))
            cols=st.columns(2)
            if value.test_method in ('factor_table','factor_explicit'):
                with cols[0]:value=replace(value,test_capacity_t=_number('Capacidade nominal para Tabela 1 (t)','test_capacity_t',value.test_capacity_t))
            if value.test_method=='factor_explicit':
                with cols[1]:value=replace(value,test_multiplier=_number('Multiplicador p do ensaio','test_multiplier',value.test_multiplier))
            elif value.test_method=='factor_1_30_envelope':
                st.caption('p = 1,30 limita os multiplicadores mínimos da Tabela 1 no escopo não seriado. Não cobre uma sobrecarga real maior: informe o p efetivamente adotado para o ensaio.')
            value=replace(value,test_dynamic_method=_select('Dinâmica específica do ensaio','test_dynamic_method',value.test_dynamic_method))
            if value.test_dynamic_method=='class_nominal_speed_envelope':
                value=replace(value,test_nominal_speed_m_s=_number('Velocidade nominal máxima adotada PARA O ENSAIO (m/s)','test_nominal_speed_m_s',value.test_nominal_speed_m_s))
                value=replace(value,test_speed_source=st.text_input('Fonte e limite adotado da velocidade de ensaio',value=value.test_speed_source,key=_key('test_speed_source')))
                value=replace(value,test_regular_lifting_adopted=st.checkbox('Adotar elevação regular para este cenário de ensaio',value=value.test_regular_lifting_adopted,key=_key('test_regular_lifting_adopted')))
                st.caption('Envoltória de engenharia HC1–HC4: Ψ = 1,20 + 0,68 × min(v nominal do ensaio, 1,5 m/s). Não confirma HC4 físico e não preenche traços da Tabela 13. A velocidade e o fator operacionais não são copiados. Não cobre carga presa, queda, juntas defeituosas ou outros eventos especiais.')
            elif value.test_dynamic_method=='explicit_psi':
                value=replace(value,test_dynamic_psi=_number('Ψ específico do ensaio','test_dynamic_psi',value.test_dynamic_psi))
            else:
                st.caption('O ensaio usa os dados HC e de velocidade da ponte. O envelope nominal considera a velocidade máxima do ensaio; não copia silenciosamente Ψ da operação normal.')
    st.caption('NBR 10084, 8.3(a–c). Seleções descrevem a configuração física; desconhecido permanece pendente. Batente independente exige que sua reação não retorne a esta viga pelas fixações. Interior protegido não dispensa ensaio.')
    errors=action_applicability_errors(value)
    if errors:st.error('Confira as situações físicas: '+' · '.join(errors))
    st.session_state[_key('record')]=deepcopy(value)
    st.session_state[_key('output_signature')]=_signature(value)
    return value
