"""Localized, equilibrium-traceable actions on physical stiffener pairs.

Physical axes are x along the runway, y transverse, z upwards. Applied wheel
vertical loads are negative Fz; Vlasov's positive torque is minus physical Mx.
Top/bottom resultants are transported WITH SIGNS to inner flange faces before
component envelopes are formed. No global span bending moment is applied to a
transverse pair. A brace without a coincident pair remains a flange attachment.

The vertical wheel transfer is a sufficient bound of the adopted NBR10084
nominal 45-degree pressure model: only an intersecting footprint can contribute,
and its ENTIRE wheel force is retained, without favorable sharing. The local
flange-torsion couple can react only at the two boundaries of its panel in the
adopted restrained-flange model; each boundary retains the full couple bound.
These are localized model bounds, not inferred exact weld forces or a 3-D field.
"""
from __future__ import annotations
import math
from copy import deepcopy
from .autonomous_local import stiffener_positions_mm
from .autonomous_result import input_signature
from .autonomous_response import stiffener_self_weight_loads
from .autonomous_weld_actions import KEYS

SOURCE='NBR10084 9.1.3: domínio nominal de dispersão45° e torção local da mesa; equilíbrio assinado dos garfos/travas do modelo autônomo.'
INTERFACES=('top','bottom','web')


def stiffener_station_geometry(p):
    L=p.span_m
    return tuple(dict(station_id='stiffener/'+str(i),x_m=0. if x==0 else L if x==L*1000 else x/1000,
                      kind='support_left' if x==0 else 'support_right' if x==L*1000 else 'intermediate')
                 for i,x in enumerate(stiffener_positions_mm(p)))


def _position_tolerance(p):
    # Smaller than the sweep's 64-ulp event neighbours, while retaining the
    # rounding error of translating an offset wheel onto a physical station.
    return 4*math.ulp(max(1.,p.span_m,*(abs(w.offset_m) for w in p.wheels)))


def stiffener_action_translation_events(p):
    """Exact nominal station/pressure-footprint events for the moving sweep.

    The sweep must also sample one-sided neighbours beyond the 4-ulp comparison
    tolerance. Its existing 64-ulp neighbours satisfy this requirement. The
    same Table-1 pressure length as ``autonomous_local`` is used here; this
    function only locates events and does not qualify the local force model.
    """
    stations=stiffener_station_geometry(p)
    if not stations or not p.wheels:return ()
    s=p.section;r=p.rail
    dimensions=(s.tw_mm,s.tf_mm,s.bf_mm,s.d_mm,s.bottom_thickness,
                r.width_mm,r.height_mm,r.inertia_cm4)
    if any(isinstance(v,bool) or not isinstance(v,(int,float)) or not math.isfinite(v) or v<=0 for v in dimensions):
        raise ValueError('Geometria inválida para os eventos locais de enrijecedores.')
    bef=min(r.width_mm+r.height_mm+s.tf_mm,s.bf_mm)
    lef=3.25*((r.inertia_cm4*10000+bef*s.tf_mm**3/12)/s.tw_mm)**(1/3)
    radius=(lef/2+s.d_mm-s.tf_mm-s.bottom_thickness)/1000
    offsets=[w.offset_m for w in p.wheels]
    lo=-max(offsets);hi=p.span_m-min(offsets)
    events={g['x_m']+delta-offset for g in stations for offset in offsets for delta in (-radius,0.,radius)}
    return tuple(sorted(x for x in events if lo<=x<=hi))


def _intervals():return {k:[0.,0.] for k in KEYS}

def _add(target,key,lo,hi=None):
    hi=lo if hi is None else hi
    if not all(math.isfinite(v) for v in (lo,hi)) or lo>hi:raise ValueError('Intervalo de ação local inválido.')
    target[key][0]+=lo;target[key][1]+=hi

def _linear(interval,scale):return [min(scale*interval[0],scale*interval[1]),max(scale*interval[0],scale*interval[1])]

def _bound(intervals):return {k:max(abs(v) for v in intervals[k]) for k in KEYS}

def _add_force(face,F,M,z_application,z_face):
    dz=(z_application-z_face)/1000
    moment=(M[0]-dz*F[1],M[1]+dz*F[0],M[2])
    for key,value in zip(KEYS,(*F,*moment)):_add(face,key,value)


def stiffener_station_actions(p,response,local_record):
    """Return every physical pair, localized top/bottom/web action intervals.

    ``local_record`` must be the already-computed nominal local record for this
    SAME translation. The caller binds its generated case/project signature.
    The helper audits position and pressure geometry and never fills missing
    nominal geometry with an unrelated global force envelope.
    """
    geometry=stiffener_station_geometry(p);pending=[];s=p.section
    if not geometry:pending.append('A rota local de distorção e transferência exige pares de enrijecedores de geometria declarada; não há estações físicas.')
    if not s.doubly_symmetric:raise ValueError('Corpo livre local exige seção bisimétrica.')
    if not isinstance(local_record,dict):raise ValueError('Registro local obrigatório.')
    if 'translation_m' in local_record and not math.isclose(local_record['translation_m'],response.translation_m,rel_tol=0,abs_tol=1e-9):
        raise ValueError('Registro local pertence a outra posição do trem.')
    if local_record.get('project_signature') not in (None,input_signature(p)):
        raise ValueError('Registro local pertence a outro projeto.')
    hw=s.d_mm-s.tf_mm-s.bottom_thickness;h0=s.d_mm-s.tf_mm
    zface={'top':hw/2,'bottom':-hw/2,'web':0.}
    intervals={g['station_id']:{i:_intervals() for i in INTERFACES} for g in geometry}
    audits={g['station_id']:[] for g in geometry};external=[]
    tolerance=_position_tolerance(p)
    def coincident(x):return next((g for g in geometry if abs(g['x_m']-x)<=tolerance),None)
    v=response.vertical;lat=response.lateral_torsion
    weights={load.position_m:load.vertical_kn for load in stiffener_self_weight_loads(p,response.factors)}
    if len(lat.loads)!=len(v.loads)+len(lat.brace_reactions):raise ValueError('Cargas e reações acopladas inconsistentes.')
    # A fork has exactly two independent lateral reactions at flange centroids.
    for j,g in enumerate((coincident(0.),coincident(p.span_m))):
        if g is None:continue
        rows=intervals[g['station_id']]
        H=lat.horizontal_support_reactions_n[j]/1000;T=lat.torsion.support_torques_nmm[j]/1e6
        top=H/2+T/(h0/1000);bottom=H/2-T/(h0/1000)
        R=(v.reactions.vertical_left_kn,v.reactions.vertical_right_kn)[j]
        _add_force(rows['top'],(0.,top,0.),(0.,0.,0.),h0/2,zface['top'])
        _add_force(rows['bottom'],(0.,bottom,R),(0.,0.,0.),-h0/2,zface['bottom'])
        audits[g['station_id']].append(dict(kind='fork',lateral_reaction_kn=H,vl_torque_knm=T,
            top_lateral_kn=top,bottom_lateral_kn=bottom,vertical_reaction_kn=R,
            equilibrium_lateral_residual_kn=top+bottom-H,
            equilibrium_torque_residual_knm=(top-bottom)*h0/2000-T))
        if R<0:pending.append(g['station_id']+': reação de arrancamento fora do caminho compressivo.')
    for brace in lat.brace_reactions:
        x=brace['x_mm']/1000 if 'x_mm' in brace else brace['position_mm']/1000
        height=brace['height_from_cs_mm'];F=brace['horizontal_reaction_n']/1000;g=coincident(x)
        if height==0:
            external.append(dict(kind='brace_axis_attachment',x_m=x,height_mm=height,lateral_reaction_kn=F,
                scope='Interface externa no eixo da seção, com transmissão sem distorção local pela ligação fornecida. Não é carga pontual na alma automaticamente verificada nem ligação de mesa/enrijecedor inventada.'))
            continue
        if g is None:
            external.append(dict(kind='brace_flange_attachment',x_m=x,height_mm=height,lateral_reaction_kn=F,
                scope='Reação aplicada diretamente à mesa; não cria par nem carga concentrada em par vizinho.'))
            continue
        face='top' if height>=0 else 'bottom'
        _add_force(intervals[g['station_id']][face],(0.,F,0.),(0.,0.,0.),height,zface[face])
        audits[g['station_id']].append(dict(kind='brace',interface_id=face,lateral_reaction_kn=F,height_mm=height))
    values=local_record.get('values',{});lef=values.get('lef_mm');ey=values.get('ey_envelope_mm')
    local_ready=local_record.get('local_effects_bound_complete') is True
    lef_valid=not isinstance(lef,bool) and isinstance(lef,(int,float)) and math.isfinite(lef) and lef>0
    if not local_ready or not lef_valid:
        pending.append('Geometria/domínio local10084 incompleto para localizar a transferência das rodas.')
    if isinstance(ey,bool) or not isinstance(ey,(int,float)) or not math.isfinite(ey) or ey<0:
        pending.append('Excentricidade normativa local não qualificada.');ey=None
    positions=[g['x_m'] for g in geometry]
    for wheel in v.loads:
        x=wheel.position_m;P=wheel.vertical_kn;H=wheel.horizontal_kn;Fx=wheel.longitudinal_kn
        if P<0:pending.append('Roda com tração fora do caminho compressivo.');continue
        if local_ready and lef_valid:
            radius=(lef/2+hw)/1000
            for g in geometry:
                if abs(g['x_m']-x)<=radius+tolerance:
                    # Unknown nonnegative share: retain [0,P], not an exact P.
                    _add(intervals[g['station_id']]['top'],KEYS[2],-P,0.)
                    audits[g['station_id']].append(dict(kind='local_vertical_footprint_bound',wheel=wheel.name,
                        wheel_x_m=x,whole_force_bound_kn=P,influence_radius_m=radius))
        if ey is not None and geometry:
            at=coincident(x)
            if at is not None:targets=[at]
            else:targets=[g for a,b in zip(geometry,geometry[1:]) if a['x_m']<x<b['x_m'] for g in (a,b)]
            # Equation of flange torsion with nonnegative web elastic restraint
            # has nonnegative end-torque influence <=1. Retain 1 at each end.
            local_couple=(P*ey+abs(H)*(p.rail.height_mm+s.tf_mm/2))/1000
            for g in targets:
                _add(intervals[g['station_id']]['top'],KEYS[3],-local_couple,local_couple)
                audits[g['station_id']].append(dict(kind='adjacent_panel_distortion_bound',wheel=wheel.name,
                    wheel_x_m=x,couple_bound_knm=local_couple,reaction_factor_bound=1.,
                    basis='Somente limites do painel local; reação não negativa limitada pelo binário no operador de torção com fundação.'))
            if at is not None:
                # Direct in-plane force at this section: local rail-height
                # couple above already ends at the flange midline.
                _add_force(intervals[at['station_id']]['top'],(Fx,H,0.),
                    (0.,Fx*(p.rail.height_mm+s.tf_mm/2)/1000,wheel.minor_moment_knm),
                    h0/2,zface['top'])
    stations=[]
    for g in geometry:
        rows=intervals[g['station_id']];web=rows['web']
        own_weight=weights.get(g['x_m'],0.)
        # Gravity is a separate centered body force. Its positive shares among
        # passive axial attachments sum to W, but are NOT known individually.
        # Keep [0,W] per interface; do not put W at the rail/top or add 3W to N.
        base_axial=max(_bound(rows['top'])[KEYS[2]],_bound(rows['bottom'])[KEYS[2]])
        audits[g['station_id']].append(dict(kind='stiffener_body_weight',body_force_vertical_kn=-own_weight,
            centroid_moment_knm=0.,weight_factor=response.factors.dead_support))
        # The web-interface wrench balances the two flange interfaces. Interval
        # arithmetic retains uncertain wheel shares: R cannot cancel a P bound.
        for face in ('top','bottom'):
            for k in KEYS:
                lo,hi=rows[face][k];_add(web,k,-hi,-lo)
            for key,force,scale in ((KEYS[3],KEYS[1],-zface[face]/1000),(KEYS[4],KEYS[0],zface[face]/1000)):
                lo,hi=_linear(rows[face][force],scale);_add(web,key,-hi,-lo)
        for face in INTERFACES:_add(rows[face],KEYS[2],0.,own_weight)
        interfaces=[]
        for face in INTERFACES:
            intervals_face=rows[face];bounds=_bound(intervals_face)
            interfaces.append(dict(interface_id=face,reference='web_midheight' if face=='web' else 'inner_flange_face',
                direction='z' if face=='web' else 'y',z_reference_mm=zface[face],
                action_bounds=bounds,signed_action_intervals=deepcopy(intervals_face),**bounds,source=SOURCE))
        # Monotone compression of a short pair is bounded by either end's entire
        # compressive introduction, not their sum when they oppose one another.
        member={k:max(row['action_bounds'][k] for row in interfaces) for k in KEYS}
        member[KEYS[2]]=base_axial+own_weight
        stations.append(dict(**g,member_action_bounds=member,body_weight_kn=own_weight,interfaces=interfaces,
            body_weight_transfer={'force_vertical_kn':-own_weight,'centroid_moment_knm':0.,
                'interface_share_bounds_kn':[0.,own_weight],'sum_interface_shares_kn':own_weight,
                'basis':'Subproblema axial simétrico de gravidade com ligações passivas: frações não negativas somam1. Envelope por interface, não três cargas concomitantes nem tração escalar acrescentada ao tensor.'},
            complete=not pending,source=SOURCE,load_sources=audits[g['station_id']],
            force_path='Par e soldas: corpo livre local. Rodas são intervalos de transferência no modelo nominal; web equilibra as mesas.',
            compression_path='Introduções verticais opostas mais carga de corpo: |N| limitado por max(|Fz_top|,|Fz_bottom|)+Wpar. Peso próprio também admite tração nominal até Wpar/Aef; sem crédito de contato ajustado.'))
    return dict(stations=stations,complete=not pending,pending=list(dict.fromkeys(pending)),
        project_signature=input_signature(p),translation_m=response.translation_m,source=SOURCE,
        external_brace_reactions=external,external_axial_reactions_kn=(v.reactions.longitudinal_left_kn,v.reactions.longitudinal_right_kn),
        limitations=['Não atribui toda a carga do trem a todos os pares.',
            'Rodas remotas à pegada nominal não são introduções verticais locais; esforços globais permanecem na recuperação nominal da viga.',
            'Binários locais são limites do modelo de torção da aba, distintos da torção global de Vlasov.',
            'Ligações externas das travas/garfos e apoio axial não são transformadas em novas chapas de enrijecedor.'])


def envelope_stiffener_stations(records):
    """Envelope SAME geometry by station/interface, after signed transport.

    Accept helper result dictionaries or lists of station rows. Never aggregate
    different stations before deriving their local interface wrenches.
    """
    snapshots=list(records)
    if not snapshots:raise ValueError('Envoltória de estações vazia.')
    normalized=[];pending=[];signatures=set();snapshot_count=0
    for item in snapshots:
        if isinstance(item,dict):
            pending.extend(item.get('pending',[]) or [])
            pending.extend(item.get('errors',[]) or [])
            if item.get('complete') is not True:pending.append('Ações por estação incompletas.')
            if item.get('project_signature'):signatures.add(item['project_signature'])
            rows=item.get('stations')
            count=item.get('snapshot_count',1)
            if isinstance(count,bool) or not isinstance(count,int) or count<1:raise ValueError('Contagem de posições da envoltória inválida.')
            snapshot_count+=count
        else:rows=item;snapshot_count+=1
        if not isinstance(rows,(list,tuple)) or not rows:raise ValueError('Estações físicas ausentes.')
        ids=[r.get('station_id') for r in rows]
        if len(set(ids))!=len(ids):raise ValueError('Estações duplicadas.')
        if any(r.get('complete') is not True for r in rows):pending.append('Uma estação contém domínio incompleto.')
        for row in rows:
            pending.extend(row.get('pending',[]) or [])
            pending.extend(row.get('errors',[]) or [])
        normalized.append(rows)
    if len(signatures)>1:raise ValueError('Envoltória mistura projetos distintos.')
    def geometry(rows):return tuple((r['station_id'],r['x_m'],r['kind']) for r in rows)
    expected=geometry(normalized[0])
    if any(geometry(rows)!=expected for rows in normalized[1:]):raise ValueError('Geometria/ordem das estações mudou entre posições.')
    output=deepcopy(normalized[0])
    for index,out in enumerate(output):
        all_rows=[rows[index] for rows in normalized]
        out['member_action_bounds']={k:max(r['member_action_bounds'][k] for r in all_rows) for k in KEYS}
        out['body_weight_kn']=max(r.get('body_weight_kn',0.) for r in all_rows)
        if out.get('body_weight_transfer') is not None:
            W=out['body_weight_kn'];out['body_weight_transfer'].update(force_vertical_kn=-W,interface_share_bounds_kn=[0.,W],sum_interface_shares_kn=W)
        for j,face in enumerate(INTERFACES):
            interfaces=[r['interfaces'][j] for r in all_rows]
            if any(r['interface_id']!=face or r['reference']!=interfaces[0]['reference'] or r['direction']!=interfaces[0]['direction'] for r in interfaces):
                raise ValueError('Interface física mudou entre posições.')
            row=out['interfaces'][j]
            row['action_bounds']={k:max(r['action_bounds'][k] for r in interfaces) for k in KEYS}
            row.update(row['action_bounds'])
            row['signed_action_intervals']={k:[min(r['signed_action_intervals'][k][0] for r in interfaces),max(r['signed_action_intervals'][k][1] for r in interfaces)] for k in KEYS}
        out['complete']=not pending
        out['load_sources']=[]
        out['envelope_note']='Envoltória separada desta estação/interface; não concomitante entre componentes.'
    return dict(stations=output,complete=not pending,pending=list(dict.fromkeys(pending)),
                project_signature=next(iter(signatures),'') ,source=SOURCE,snapshot_count=snapshot_count)
