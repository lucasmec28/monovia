"""Nominal longitudinal CJP transfer, distinct from a pair of fillet throats.

The effective CJP thickness is the smaller connected part. The component
traction bound is an algebraic sufficient test of the separate base-metal
normal and shear resistances, NOT a new equivalent-stress failure criterion.
"""
from math import isfinite

SOURCE='EN 1993-1-8:2005 4.7.1 (CJP real, consumível compatível); NBR 8800:2024 6.2/Tabela9 e 6.5 (metal-base).'

def _number(v,name,positive=False):
    if type(v) not in (int,float) or not isfinite(v) or (v<=0 if positive else v<0):
        raise ValueError(name+': número finito no domínio obrigatório.')
    return float(v)


def cjp_longitudinal_transfer(project,*,transverse_normal_bound_mpa,shear_transfer_bound_mpa):
    if project.section.fabrication!='welded' or project.fatigue.detail!='continuous_longitudinal_cjp_backgouged':
        raise ValueError('Este ramo exige I soldado e CJP longitudinal efetivamente selecionada.')
    z=_number(transverse_normal_bound_mpa,'Normal transversal')
    tau=_number(shear_transfer_bound_mpa,'Cisalhamento longitudinal')
    s=project.section;m=project.material
    tw=_number(s.tw_mm,'Espessura da alma',True)
    a=min(tw,_number(s.tf_mm,'Mesa superior',True),_number(s.bottom_thickness,'Mesa inferior',True))
    fy=_number(m.fy_mpa,'fy',True);fu=_number(m.fu_mpa,'fu',True)
    gamma1=_number(m.gamma_a1,'gamma_a1',True)
    gamma2=1.35 # NBR8800 normal ULS rupture margin; not a weld-quality factor.
    if gamma1<1 or gamma2<1 or fu<fy:raise ValueError('Material ou margens resistentes inválidos.')
    # q/t_eff, one fully fused section per junction. No sqrt(2), duplicated
    # fillet, added reinforcement area, or fictitious larger effective throat.
    normal=z*tw/a;shear=tau*tw/a
    normal_capacity=min(fy/gamma1,fu/gamma2)
    shear_capacity=min(.6*fy/gamma1,.6*fu/gamma2)
    sufficient_normal_equivalent=max(normal,shear*normal_capacity/shear_capacity)
    u=max(normal/normal_capacity,shear/shear_capacity)
    d=dict(normal_perpendicular_bound_mpa=normal,shear_parallel_bound_mpa=shear,
        shear_perpendicular_bound_mpa=0.,shear_resultant_bound_mpa=shear,
        traction_resultant_bound_mpa=sufficient_normal_equivalent,
        capacity_mpa=normal_capacity,normal_capacity_mpa=normal_capacity,
        shear_capacity_mpa=shear_capacity,utilization=u,
        effective_thickness_mm=a,number_of_fused_sections_per_interface=1,
        line_vertical_n_per_mm=tw*z,line_longitudinal_n_per_mm=tw*tau,
        physical_joint='continuous_longitudinal_cjp_backgouged',complete=True,
        algebraic_bound='max(sigma_perp / Rnormal, tau_parallel / Rshear); componentes verificadas separadamente',
        fillet_45_degree_transform_used=False,reinforcement_strength_credit=False,
        source=SOURCE)
    return dict(applicable=True,fixed_project_detail=True,detail_feasible=u<=1,
        proposed_detail=False,approval=False,design=d,limiting_design=None,
        physical_joint=d['physical_joint'],source=SOURCE,
        length_each_mm=project.span_m*1000+project.beam_end_left_mm+project.beam_end_right_mm,
        requirements=['Fusão total com extração de raiz/contrassolda; consumível com fy/fu não inferiores à parte conectada mais fraca.',
            'Preparo, geometria e qualidade explicitados no detalhe físico; seleção não é certificado de execução.',
            'Fadiga e tensões nominais nas partes conectadas verificadas separadamente, sem transformar CJP em filete.'])
