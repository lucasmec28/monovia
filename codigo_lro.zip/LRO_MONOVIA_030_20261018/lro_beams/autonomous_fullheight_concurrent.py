"""Nominal same-material component boxes, not a new local field solver.

Only already recovered group tractions/rectangular-section functions and the
complete member ULS envelopes are composed. The algebraic principal bounds
are compared with the separate NBR normal/shear limits. No Tresca, VM3D,
new fatigue criterion, effective-width spread or stiffness credit is claimed.
"""
from math import isfinite
from .autonomous_result import input_signature
from top_unstiffened_candidate.stiffeners.concurrent_static import gershgorin_normal_shear_bounds

KEYS={'sigma_xx':'sx','sigma_yy':'sy','sigma_zz':'sz','tau_xy':'txy','tau_xz':'txz','tau_yz':'tyz'}
SOURCE='NBR8800 6.5/5.5.2.3(a,b), limites normal/cisalhamento nas partes locais e faixas prismáticas; caixa algébrica conservadora, sem novo critério 3D.'
RESOLVED=('concurrent_member_receiver_interaction','concurrent_plate_normal_shear_interaction')

def _value(x):
    if type(x) not in (int,float) or not isfinite(x) or x<0:raise ValueError('Limite ULS finito não negativo obrigatório.')
    return float(x)

def _zero():return {key:(0.,0.) for key in KEYS.values()}

def _local(row,functions=False):
    result=_zero()
    if functions:
        found=False
        for long,key in KEYS.items():
            if long+'_interval_mpa' in row:
                values=row[long+'_interval_mpa']
                if not isinstance(values,(tuple,list)) or len(values)!=2 or any(type(x) not in (int,float) or not isfinite(x) for x in values) or values[0]>values[1]:raise ValueError('Intervalo local inválido.')
                result[key]=tuple(values);found=True
        if not found:raise ValueError('Função nominal sem intervalos de componentes.')
    else:
        values=row['tensor_components_mpa']
        if not values or not set(values)<=set(KEYS):raise ValueError('Componentes locais desconhecidas/ausentes.')
        for long,value in values.items():
            if type(value) not in (int,float) or not isfinite(value):raise ValueError('Componente local inválida.')
            result[KEYS[long]]=(value,value)
    return result

def _member(metrics,role):
    t=_zero()
    if role=='plate':return t
    if role=='beam_web':
        sx=_value(metrics['combined_web_longitudinal_bound_mpa'])
        sz=_value(metrics['local_transverse_bound_mpa']);tau=_value(metrics['combined_web_shear_bound_mpa'])
        t.update(sx=(-sx,sx),sz=(-sz,sz),txz=(-tau,tau))
    elif role in ('beam_top_flange','beam_bottom_flange'):
        sx=_value(metrics['flange_sigma_abs_upper_bound_mpa']);tau=_value(metrics['flange_shear_magnitude_upper_bound_mpa'])
        t.update(sx=(-sx,sx),txy=(-tau,tau))
    else:raise ValueError('Papel material local desconhecido.')
    return t

def evaluate_concurrent_fullheight(project,fixed,sweeps,uls_cases):
    expected={c.id for c in uls_cases}
    if not expected or not expected<=set(sweeps) or fixed.get('project_signature')!=input_signature(project):raise ValueError('Identidade/ULS completo obrigatório.')
    metric_names=('combined_web_longitudinal_bound_mpa','local_transverse_bound_mpa','combined_web_shear_bound_mpa','flange_sigma_abs_upper_bound_mpa','flange_shear_magnitude_upper_bound_mpa')
    metrics={}
    for name in metric_names:
        if any(name not in sweeps[c].maxima for c in expected):raise ValueError('Métrica ULS de interação ausente: '+name)
        metrics[name]=max(_value(sweeps[c].maxima[name].value) for c in expected)
    from .autonomous_fullheight_runtime import resolved_detail
    detail=resolved_detail(project);rows=[];checks=[]
    for connection in fixed['selfweight_reference']['connections']:
        for case in connection['cases']:
            sections=case['section_results']
            for kind,items in (('footprint',sections['signed_interface_points']),('section',sections['nominal_section_stress_functions'])):
                if not items:raise ValueError('Cobertura física de receptores/cortes vazia.')
                for row in items:
                    local=_local(row,kind=='section');member=_member(metrics,row['material_role'])
                    box={k:(local[k][0]+member[k][0],local[k][1]+member[k][1]) for k in local}
                    demand=gershgorin_normal_shear_bounds(box)
                    material=detail.plate_material if row['material_role']=='plate' else detail.section.material
                    capacities={'normal':min(material.fy_mpa/project.material.gamma_a1,material.fu_mpa/1.35),
                        'shear':min(.6*material.fy_mpa/project.material.gamma_a1,.6*material.fu_mpa/1.35)}
                    identity=str(connection['side'])+'/'+case['case_id']+'/'+kind+'/'+row.get('point_id',row.get('field_id'))
                    item=dict(identity=identity,local_geometry=row,tensor_box_mpa=box,demands=demand,member_metrics=metrics,capacities=capacities)
                    rows.append(item)
                    for component,key in (('normal','normal_abs_bound_mpa'),('shear','shear_abs_bound_mpa')):
                        checks.append(dict(check_id=identity+'/'+component,demand=demand[key],capacity=capacities[component],units='MPa',
                            utilization=demand[key]/capacities[component],sufficient_bound=True,source=SOURCE,material_role=row['material_role'],
                            actual_failure_proven=False,full_member_box_added_only_to_receiver=row['material_role']!='plate'))
    return dict(complete=True,pending=[],checks=checks,regions=rows,project_signature=input_signature(project),case_ids=sorted(expected),
        resolved_obligation_ids=list(RESOLVED),new_stress_field_created=False,new_normative_3d_criterion=False,
        all_continuous_section_functions_enclosed=True,not_only_sampled_section_points=True,source=SOURCE)
