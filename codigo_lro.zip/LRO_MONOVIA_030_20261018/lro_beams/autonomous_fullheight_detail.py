"""Explicit proposed welded-I TOP full-height detail, not an as-built certificate.

N, mm, MPa, kg. x is longitudinal, y transverse and z is upward from the
external bottom flange. This new physical family never calls the rolled/gap
wrapper. Only the audited scalar panel kernel and classical planar mixed-group
algebra are reused. No wheel force, support/brace reaction or stiffness credit
is manufactured here. A proposal must be explicitly selected and persisted.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, fields
from hashlib import sha256
import json
from math import asin, ceil, fsum, hypot, isclose, isfinite, pi, radians, sqrt, tan
from numbers import Real

from top_unstiffened_candidate.stiffeners.shear import paired_stiffener_prescriptive
from top_unstiffened_candidate.stiffeners.selfweight_transfer import (
    InterfaceLine, mixed_group, solve_mixed_group, GROUP_ASSUMPTION,
    MINIMUM_CONNECTION_FORCE_N, _rectangular_core_stability, _normal_checks, _shear_checks,
)

SCHEMA = "TOP_WELDED_I_FULLHEIGHT_NOMINAL_V1"
SOURCE = "FULLHEIGHT_DETAIL_CONTRACT 2026-10-17; NBR 8800:2024+Er1:2025 5.4.3.1.3, 6.1/6.2, H; NBR 8400-2 D.3/D.5; EN 1993-1-8:2005 4.7.1"
GRAVITY = 9.80665
QE_REQUIREMENTS = (
    "edges_undercut_free", "tension_region_lamination_free",
    "ends_ground_notch_free_preserve_throat", "inspection_fatigue_acceptance",
)
QC_REQUIREMENTS = (
    "QC_acceptance_NBR8400_D3", "continuous_visual_inspection",
    "no_cracks", "defect_limits_NBR8400_D3_QC", "inspection_access_provided",
)
CJP_REQUIREMENTS = (
    "full_root_fusion", "complete_declared_groove_refill",
    "root_removed_before_second_face", "no_permanent_backing",
    "run_on_off_tabs_removed", "ends_ground_flush", "no_end_dams",
    "qualified_or_prequalified_WPS_required_before_execution",
)


def _number(value, name, *, positive=False, nonnegative=False):
    if isinstance(value, bool) or not isinstance(value, Real):
        raise TypeError(name + " must be a real number, never bool")
    value = float(value)
    if not isfinite(value) or abs(value) > 1e50:
        raise ValueError(name + " must be finite within the supported range")
    if positive and value <= 0 or nonnegative and value < 0:
        raise ValueError(name + " has an invalid sign")
    return value


def _numbers(obj, positive=(), nonnegative=()):
    for key in positive + nonnegative:
        object.__setattr__(obj, key, _number(getattr(obj, key), key,
            positive=key in positive, nonnegative=key in nonnegative))


def _text(value, name):
    if not isinstance(value, str) or not value.strip():
        raise ValueError(name + " requires an explicit nonempty description")


def _tuple_strings(value, name):
    if type(value) is not tuple or any(not isinstance(v, str) or not v.strip() for v in value):
        raise TypeError(name + " must be an immutable tuple of descriptions")
    if len(set(value)) != len(value):
        raise ValueError(name + " contains duplicate requirements")


def _signature(value):
    return sha256(json.dumps(value, sort_keys=True, separators=(",", ":"),
                             ensure_ascii=False, allow_nan=False).encode()).hexdigest()


@dataclass(frozen=True)
class FullHeightMaterial:
    material_id: str
    fy_mpa: float
    fu_mpa: float
    E_mpa: float
    G_mpa: float
    density_kg_m3: float
    source: str

    def __post_init__(self):
        _text(self.material_id, "material_id"); _text(self.source, "material source")
        _numbers(self, positive=("fy_mpa", "fu_mpa", "E_mpa", "G_mpa", "density_kg_m3"))
        if self.fu_mpa < self.fy_mpa:
            raise ValueError("fu must not be below fy")


@dataclass(frozen=True)
class FabricationQuality:
    grade: str
    requirements: tuple[str, ...]
    procedure_id: str
    inspection_method: str
    inspection_acceptance: str
    status: str = "proposed_design_requirements_not_as_built"

    def __post_init__(self):
        if self.grade not in ("QC", "QE"):
            raise ValueError("Explicit QC or QE required; no automatic quality upgrade")
        _tuple_strings(self.requirements, "quality requirements")
        for name in ("procedure_id", "inspection_acceptance"):
            _text(getattr(self, name), name)
        if self.inspection_method not in ("VT_MT", "UT_VT_MT", "RT_VT_MT"):
            raise ValueError("Explicit inspection method required")
        if self.status != "proposed_design_requirements_not_as_built":
            raise ValueError("This API defines proposed fabrication, never verified execution")


@dataclass(frozen=True)
class CJPJointSpec:
    material: FullHeightMaterial
    quality: FabricationQuality
    bevel_angle_deg: float
    root_face_mm: float
    root_gap_mm: float
    root_gap_tolerance_mm: float
    reinforcement_leg_mm: float
    reinforcement_tolerance_mm: float
    root_envelope_tolerance_mm: float
    access_allowance_mm: float
    required_operations: tuple[str, ...]
    source: str
    joint_type: str = "double_bevel_T_CJP"
    preparation: str = "K"
    root_method: str = "backgouged_and_welded"
    reinforcement_shape: str = "two_equal_leg_triangular_prisms"

    def __post_init__(self):
        if type(self.material) is not FullHeightMaterial or type(self.quality) is not FabricationQuality:
            raise TypeError("Typed material and quality are required")
        _numbers(self, positive=("bevel_angle_deg",), nonnegative=("root_face_mm", "root_gap_mm",
            "root_gap_tolerance_mm", "reinforcement_leg_mm", "reinforcement_tolerance_mm",
            "root_envelope_tolerance_mm", "access_allowance_mm"))
        if not 0 < self.bevel_angle_deg < 90 or self.root_gap_tolerance_mm > self.root_gap_mm:
            raise ValueError("Invalid bevel angle or root-opening tolerance")
        if self.reinforcement_tolerance_mm > self.reinforcement_leg_mm:
            raise ValueError("Reinforcement tolerance removes its physical dimension")
        if (self.joint_type, self.preparation, self.root_method, self.reinforcement_shape) != (
                "double_bevel_T_CJP", "K", "backgouged_and_welded", "two_equal_leg_triangular_prisms"):
            raise ValueError("Only explicit real K CJP/backgouging is supported, not a fillet substitute")
        _tuple_strings(self.required_operations, "CJP operations"); _text(self.source, "CJP source")


@dataclass(frozen=True)
class FilletAttachmentSpec:
    leg_mm: float
    material: FullHeightMaterial
    interior_quality: FabricationQuality
    end_quality: FabricationQuality
    qe_end_zone_length_mm: float
    endpoint_tolerance_mm: float
    source: str
    continuity: str = "continuous"
    termination_shape: str = "square_ended_no_returns"

    def __post_init__(self):
        _numbers(self, positive=("leg_mm",), nonnegative=("qe_end_zone_length_mm", "endpoint_tolerance_mm"))
        if type(self.material) is not FullHeightMaterial or any(type(v) is not FabricationQuality
                for v in (self.interior_quality, self.end_quality)):
            raise TypeError("Typed fillet material and qualities required")
        if (self.continuity, self.termination_shape) != ("continuous", "square_ended_no_returns"):
            raise ValueError("Physical continuous straight fillets without unmodelled returns required")
        _text(self.source, "fillet source")


@dataclass(frozen=True)
class CopeSpec:
    radius_mm: float
    radius_tolerance_mm: float
    clearance_mm: float
    finish: str
    thermal_cut_roughness_um: float
    source: str

    def __post_init__(self):
        _numbers(self, positive=("radius_mm",), nonnegative=("radius_tolerance_mm", "clearance_mm",
                                                            "thermal_cut_roughness_um"))
        if self.radius_mm - self.radius_tolerance_mm < 25:
            raise ValueError("Actual concave cope radius must remain at least 25 mm")
        if self.finish not in ("ground_notch_free", "machined_notch_free"):
            raise ValueError("Explicit notch-free finish required; radius alone gives no FAT class")
        _text(self.source, "cope source")


@dataclass(frozen=True)
class WeldedISectionDetail:
    depth_mm: float
    top_flange_width_mm: float
    bottom_flange_width_mm: float
    top_flange_thickness_mm: float
    bottom_flange_thickness_mm: float
    web_thickness_mm: float
    dimension_tolerance_mm: float
    material: FullHeightMaterial
    longitudinal_top: CJPJointSpec
    longitudinal_bottom: CJPJointSpec
    source: str
    fabrication: str = "welded"
    root_radius_mm: float = 0.0

    def __post_init__(self):
        _numbers(self, positive=("depth_mm", "top_flange_width_mm", "bottom_flange_width_mm",
            "top_flange_thickness_mm", "bottom_flange_thickness_mm", "web_thickness_mm"),
            nonnegative=("dimension_tolerance_mm", "root_radius_mm"))
        if self.fabrication != "welded" or self.root_radius_mm != 0:
            raise ValueError("Welded rectangle section only; weld envelopes are not equivalent root radii")
        if type(self.material) is not FullHeightMaterial or any(type(v) is not CJPJointSpec
                for v in (self.longitudinal_top, self.longitudinal_bottom)):
            raise TypeError("Physical welded section requires both longitudinal CJP specifications")
        if self.clear_web_depth_mm <= 0 or self.web_thickness_mm >= min(self.top_flange_width_mm,
                                                                         self.bottom_flange_width_mm):
            raise ValueError("Invalid welded-I dimensions")
        if self.dimension_tolerance_mm >= min(self.web_thickness_mm, self.top_flange_thickness_mm,
                                               self.bottom_flange_thickness_mm):
            raise ValueError("Section tolerance removes a dimension")
        _text(self.source, "section source")

    @property
    def clear_web_depth_mm(self):
        return self.depth_mm-self.top_flange_thickness_mm-self.bottom_flange_thickness_mm

    @property
    def top_inner_z_mm(self):
        return self.depth_mm-self.top_flange_thickness_mm


@dataclass(frozen=True)
class FullHeightNominalDetail:
    section: WeldedISectionDetail
    plate_material: FullHeightMaterial
    plate_thickness_mm: float
    outstand_mm: float
    upper_cope: CopeSpec
    lower_cope: CopeSpec
    top_cjp: CJPJointSpec
    web_fillets: FilletAttachmentSpec
    bottom_attachment: FilletAttachmentSpec
    beam_end_left_mm: float
    beam_end_right_mm: float
    longitudinal_selection: str
    proposal_note: str
    schema: str = SCHEMA

    def __post_init__(self):
        _numbers(self, positive=("plate_thickness_mm", "outstand_mm"),
                 nonnegative=("beam_end_left_mm", "beam_end_right_mm"))
        required = ((self.section, WeldedISectionDetail), (self.plate_material, FullHeightMaterial),
            (self.upper_cope, CopeSpec), (self.lower_cope, CopeSpec), (self.top_cjp, CJPJointSpec),
            (self.web_fillets, FilletAttachmentSpec), (self.bottom_attachment, FilletAttachmentSpec))
        if any(type(value) is not cls for value, cls in required):
            raise TypeError("Every full-height physical interface and material must be explicit and typed")
        if self.schema != SCHEMA or self.longitudinal_selection != "continuous_longitudinal_cjp_backgouged":
            raise ValueError("This version requires the selected continuous longitudinal CJP/backgouging")
        _text(self.proposal_note, "proposal_note")
        fullheight_geometry(self)

    def to_dict(self):
        return asdict(self)

    def to_json(self):
        return json.dumps(self.to_dict(), ensure_ascii=False, sort_keys=True, allow_nan=False)

    @classmethod
    def from_mapping(cls, value):
        return fullheight_detail_from_mapping(value)

    @property
    def input_signature(self):
        return _signature(self.to_dict())


def _strict_mapping(cls, value, nested=None, tuples=()):
    if not isinstance(value, dict) or set(value) != {f.name for f in fields(cls)}:
        raise ValueError("Unknown or missing fields in " + cls.__name__)
    data = dict(value)
    for key, constructor in (nested or {}).items():
        data[key] = constructor(data[key])
    for key in tuples:
        if type(data[key]) not in (list, tuple):
            raise TypeError(key + " must be an array")
        data[key] = tuple(data[key])
    return cls(**data)


def fullheight_detail_from_mapping(value):
    material = lambda v: _strict_mapping(FullHeightMaterial, v)
    quality = lambda v: _strict_mapping(FabricationQuality, v, tuples=("requirements",))
    cjp = lambda v: _strict_mapping(CJPJointSpec, v, {"material": material, "quality": quality},
                                    ("required_operations",))
    fillet = lambda v: _strict_mapping(FilletAttachmentSpec, v,
        {"material": material, "interior_quality": quality, "end_quality": quality})
    section = lambda v: _strict_mapping(WeldedISectionDetail, v,
        {"material": material, "longitudinal_top": cjp, "longitudinal_bottom": cjp})
    cope = lambda v: _strict_mapping(CopeSpec, v)
    return _strict_mapping(FullHeightNominalDetail, value, {"section": section, "plate_material": material,
        "upper_cope": cope, "lower_cope": cope, "top_cjp": cjp, "web_fillets": fillet,
        "bottom_attachment": fillet})


def _groove(joint, thickness):
    if joint.root_face_mm >= thickness:
        raise ValueError("CJP root land removes the full bevel width")
    width = (thickness-joint.root_face_mm)/2
    return width, width/tan(radians(joint.bevel_angle_deg))


def fullheight_geometry(detail):
    """Exact nominal shape plus conservative clearance of real deposited bodies.

    A circular cut removes material inside each corner disk. A conservative
    rectangle encloses each actual triangular longitudinal reinforcement. Its
    farthest corner plus access, clearance and tolerances must fit the disk.
    Neither a zero section root radius nor nominal weld throat hides a body.
    """
    if type(detail) is not FullHeightNominalDetail:
        raise TypeError("FullHeightNominalDetail required")
    d, s = detail, detail.section
    c, t, g = d.outstand_mm, d.plate_thickness_mm, d.top_cjp.root_gap_mm
    rt, rb = d.upper_cope.radius_mm, d.lower_cope.radius_mm
    if c+s.web_thickness_mm/2+s.dimension_tolerance_mm > min(s.top_flange_width_mm,
                                                                            s.bottom_flange_width_mm)/2:
        raise ValueError("Actual plate extends past a physical flange")
    if g+d.top_cjp.root_gap_tolerance_mm >= rt-d.upper_cope.radius_tolerance_mm:
        raise ValueError("Top CJP opening removes the circular-cope joint")
    if c <= max(rt+d.upper_cope.radius_tolerance_mm, rb+d.lower_cope.radius_tolerance_mm):
        raise ValueError("Both copes must leave a real horizontal attachment")
    if rt+rb+d.upper_cope.radius_tolerance_mm+d.lower_cope.radius_tolerance_mm >= s.clear_web_depth_mm-2*s.dimension_tolerance_mm:
        raise ValueError("Copes remove the full web interface")
    longitudinal_depths = []
    for location, joint, cope in (("upper", s.longitudinal_top, d.upper_cope),
                                  ("lower", s.longitudinal_bottom, d.lower_cope)):
        longitudinal_depths.append(_groove(joint, s.web_thickness_mm)[1])
        # Exact mass below supports zero longitudinal openings; a nonzero
        # opening changes the input section's physical web rectangle.
        if joint.root_gap_mm != 0 or joint.root_gap_tolerance_mm != 0:
            raise ValueError("Nonzero longitudinal root opening needs an explicitly shortened web section; not supported by this rectangle adapter")
        extent = joint.reinforcement_leg_mm+joint.reinforcement_tolerance_mm+joint.root_envelope_tolerance_mm
        required = hypot(extent, extent)+joint.access_allowance_mm+cope.clearance_mm+s.dimension_tolerance_mm
        if cope.radius_mm-cope.radius_tolerance_mm < required:
            raise ValueError(location+" cope intersects the declared longitudinal weld/access envelope")
    if fsum(longitudinal_depths) >= s.clear_web_depth_mm-2*s.dimension_tolerance_mm:
        raise ValueError("Longitudinal K preparations overlap within the physical web")
    q = sqrt(rt*rt-g*g)
    q_min = sqrt((rt-d.upper_cope.radius_tolerance_mm)**2-
                 (g+d.top_cjp.root_gap_tolerance_mm)**2)
    if min(q_min, rb-d.lower_cope.radius_tolerance_mm) <= d.web_fillets.leg_mm:
        raise ValueError("Transverse weld bodies cross within a circular cope")
    # No overlap of top reinforcement and vertical fillet projections. With
    # q>=web leg, and vertical run ending below the disk, the bodies are disjoint.
    if d.top_cjp.reinforcement_leg_mm <= g or d.top_cjp.reinforcement_leg_mm >= s.clear_web_depth_mm-rb:
        raise ValueError("Top reinforcement fails to reach the plate or leaves its physical envelope")
    bw, bd = _groove(d.top_cjp, t)
    if bd >= s.clear_web_depth_mm-g-rb:
        raise ValueError("Top bevel preparation removes the full plate depth")
    zt, zb = s.top_inner_z_mm, s.bottom_flange_thickness_mm
    ar = pi*rt*rt/4-(g*q+rt*rt*asin(g/rt))/2
    um = rt**3/3-rt*rt*g/2+g**3/6
    vm = q**3/3
    bottom_area = pi*rb*rb/4
    rect_area = c*(zt-g-zb)
    area = rect_area-ar-bottom_area
    u = (rect_area*c/2-um-rb**3/3)/area
    z = (rect_area*(zt-g+zb)/2-(zt*ar-vm)-(zb*bottom_area+rb**3/3))/area
    minimum_cut = max(q, rb)
    outer, inner = s.web_thickness_mm/2+c, s.web_thickness_mm/2+minimum_cut
    imin = 2*t*(outer-inner)*(outer*outer+outer*inner+inner*inner)/3
    return {"h_mm": s.clear_web_depth_mm, "Aw_mm2": s.depth_mm*s.web_thickness_mm,
        "top_z_mm": zt, "bottom_z_mm": zb, "plate_top_z_mm": zt-g,
        "top_start_u_mm": q, "bottom_start_u_mm": rb,
        "top_length_mm": c-q, "bottom_length_mm": c-rb,
        "web_low_z_mm": zb+rb, "web_high_z_mm": zt-rt,
        "web_length_mm": zt-rt-zb-rb, "plate_area_mm2": area,
        "plate_centroid_u_mm": u, "plate_centroid_y_mm": s.web_thickness_mm/2+u,
        "plate_centroid_z_mm": z, "upper_removed_area_mm2": ar,
        "lower_removed_area_mm2": bottom_area, "bevel_width_mm": bw, "bevel_depth_mm": bd,
        "minimum_plate_Is_mm4": imin, "minimum_Is_basis": "least remaining horizontal slice; plates only, full compatible groove refill required; no web bearing strip or reinforcement",
        "CJP_effective_throat_mm": min(t, s.top_flange_thickness_mm),
        "cope_collision_basis": "conservative physical longitudinal-deposit rectangle plus explicit access/clearance/tolerances",
        "arc_weld_length_mm": 0.0, "as_built_verified": False, "bottom_gap_rule_applied": False}


def _quality_pending(quality, prefix, qe=False):
    pending = []
    if qe and quality.grade != "QE":
        pending.append(prefix+": QE is required by the adopted detail")
    if quality.grade == "QE":
        pending += [prefix+": missing "+v for v in QE_REQUIREMENTS if v not in quality.requirements]
    else:
        pending += [prefix+": missing "+v for v in QC_REQUIREMENTS if v not in quality.requirements]
    return pending


def fullheight_detail_assessment(detail):
    d, s, geo = detail, detail.section, fullheight_geometry(detail)
    pending, checks = [], []
    for name, joint, connected in (("top_cjp", d.top_cjp, (d.plate_material, s.material)),
            ("longitudinal_top", s.longitudinal_top, (s.material,)),
            ("longitudinal_bottom", s.longitudinal_bottom, (s.material,))):
        pending += [name+": missing "+v for v in CJP_REQUIREMENTS if v not in joint.required_operations]
        pending += _quality_pending(joint.quality, name, qe=name == "top_cjp")
        if joint.quality.inspection_method not in ("UT_VT_MT", "RT_VT_MT"):
            pending.append(name+": CJP UT or RT with fatigue acceptance required")
        if joint.material.fy_mpa < max(m.fy_mpa for m in connected) or joint.material.fu_mpa < max(m.fu_mpa for m in connected):
            pending.append(name+": consumable fy/fu does not match both connected base metals")
        if any(joint.material.E_mpa != m.E_mpa for m in connected):
            pending.append(name+": common E for reconstructed section not specified")
    if d.top_cjp.reinforcement_leg_mm-d.top_cjp.reinforcement_tolerance_mm < 6:
        pending.append("top_cjp: transverse T/CJP reinforcement must be at least 6 mm, not extra throat")
    if s.longitudinal_top.reinforcement_leg_mm-s.longitudinal_top.reinforcement_tolerance_mm <= 0:
        pending.append("longitudinal_top_published_local_mode_coverage: the adopted Fisher/Van de Pas CJP-plus-reinforcement recommendation requires an explicit positive physical reinforcement; other computable CJP checks remain available")
    for name, w, length, thin in (("web", d.web_fillets, geo["web_length_mm"], min(d.plate_thickness_mm, s.web_thickness_mm)),
            ("bottom", d.bottom_attachment, geo["bottom_length_mm"], min(d.plate_thickness_mm, s.bottom_flange_thickness_mm))):
        minimum = 3 if thin <= 6.3 else 5 if thin <= 12.5 else 6 if thin <= 19 else 8
        maximum = thin if thin < 6.3 else thin-1.5
        effective_length = length-2*w.endpoint_tolerance_mm
        checks.extend((dict(check_id=name+"_fillet_leg", passed=minimum <= w.leg_mm <= maximum,
            minimum_mm=minimum, actual_mm=w.leg_mm, maximum_mm=maximum),
            dict(check_id=name+"_fillet_length", passed=effective_length >= max(40., 4*w.leg_mm, 6*w.leg_mm/sqrt(2)),
                effective_length_mm=effective_length, minimum_mm=max(40., 4*w.leg_mm, 6*w.leg_mm/sqrt(2))),
            dict(check_id=name+"_fillet_EN_throat", passed=w.leg_mm/sqrt(2) >= 3., throat_mm=w.leg_mm/sqrt(2)),
            dict(check_id=name+"_fillet_no_long_joint_reduction", passed=length <= 100*w.leg_mm)))
        pending += _quality_pending(w.end_quality, name+"_ends", qe=True)
        pending += _quality_pending(w.interior_quality, name+"_interior", qe=name == "bottom")
        if name == "web" and w.qe_end_zone_length_mm < 10*d.plate_thickness_mm:
            pending.append("web: QE zones must extend at least 10ts from both terminations; overlap allowed")
        if name == "bottom" and w.qe_end_zone_length_mm < length:
            pending.append("bottom: QE required over its entire physical length")
    for name, cope in (("upper", d.upper_cope), ("lower", d.lower_cope)):
        if cope.thermal_cut_roughness_um > 25:
            pending.append(name+": adopted thermal-cut finish requires roughness <=25 micrometres")
    if any((s.dimension_tolerance_mm, d.upper_cope.radius_tolerance_mm,
            d.lower_cope.radius_tolerance_mm, d.top_cjp.root_gap_tolerance_mm,
            d.web_fillets.endpoint_tolerance_mm, d.bottom_attachment.endpoint_tolerance_mm,
            d.top_cjp.reinforcement_tolerance_mm)):
        pending.append("asymmetric_tolerance_realizations: physical clearance is checked conservatively, but G/group and mass receipts describe the symmetric nominal dimensions only")
    return {"status": "DESIGN_REQUIREMENTS_SPECIFIED" if not pending and all(c["passed"] for c in checks) else "DETAIL_REQUIREMENTS_NOT_CLOSED",
        "checks": checks, "pending": pending, "geometry": geo, "as_built_verified": False,
        "longitudinal_top_vertical_detail": "K2,41" if s.longitudinal_top.quality.grade == "QE" else "K3,41",
        "longitudinal_bottom_vertical_detail": "K2,41" if s.longitudinal_bottom.quality.grade == "QE" else "K3,41",
        "longitudinal_direction_detail": "K0,33", "complete_station_eligible": False}


def fullheight_prescriptive(detail, panel_lengths_mm):
    """Scalar stabilization only. Bearing minima are deliberately absent."""
    d, s, geo = detail, detail.section, fullheight_geometry(detail)
    result = paired_stiffener_prescriptive(outstand_mm=d.outstand_mm, plate_thickness_mm=d.plate_thickness_mm,
        web_thickness_mm=s.web_thickness_mm, clear_web_depth_mm=s.clear_web_depth_mm,
        E_MPa=d.plate_material.E_mpa, fy_MPa=d.plate_material.fy_mpa, panel_lengths_mm=panel_lengths_mm)
    record = asdict(result)
    record["rectangular_plate_Is_mm4"] = record["Is_mm4"]
    record["Is_mm4"] = geo["minimum_plate_Is_mm4"]
    record["inertia_pass"] = record["Is_mm4"] >= record["Irequired_mm4"]
    record["section_rules_pass"] = record["stockiness_pass"] and record["inertia_pass"]
    record["minimum_Is_basis"] = geo["minimum_Is_basis"]
    record["h_mm"] = s.clear_web_depth_mm
    record["Aw_mm2"] = geo["Aw_mm2"]
    record["bearing_minima_applied"] = False
    record["attachment_assessment"] = fullheight_detail_assessment(d)
    reconstruction = (all(v in d.top_cjp.required_operations for v in CJP_REQUIREMENTS)
        and d.top_cjp.material.fy_mpa >= d.plate_material.fy_mpa
        and d.top_cjp.material.fu_mpa >= d.plate_material.fu_mpa
        and d.top_cjp.material.E_mpa == d.plate_material.E_mpa)
    record["reconstructed_section_requirements_specified"] = reconstruction
    record["Is_requires_compatible_complete_groove_refill"] = True
    record["prepared_root_land_Is_mm4"] = geo["minimum_plate_Is_mm4"]*d.top_cjp.root_face_mm/d.plate_thickness_mm
    record["section_rules_are_conditional_on_reconstruction"] = not reconstruction
    record["nominal_material_numeric_domain_pass"] = (result.source_numeric_limits_pass and
        s.material.E_mpa == d.plate_material.E_mpa and d.plate_material.fu_mpa/d.plate_material.fy_mpa >= 1.15)
    record["source"] = SOURCE
    return record


def fullheight_bearing_geometry(detail):
    """Call ONLY for an independently identified bearing function; no Rz inferred."""
    s = detail.section
    minimum_c = max(s.top_flange_width_mm, s.bottom_flange_width_mm)/3-s.web_thickness_mm/2
    minimum_t = max(max(s.top_flange_thickness_mm, s.bottom_flange_thickness_mm)/2, detail.outstand_mm/16)
    return {"minimum_outstand_mm": minimum_c, "actual_outstand_mm": detail.outstand_mm,
        "minimum_thickness_mm": minimum_t, "actual_thickness_mm": detail.plate_thickness_mm,
        "geometry_pass": detail.outstand_mm >= minimum_c and detail.plate_thickness_mm >= minimum_t,
        "source": "NBR 8800:2024 5.7.9.5, only actual vertical-bearing stations",
        "complete_bearing_eligible": False, "reaction_inferred": False}


def propose_fullheight_detail(project):
    """Return an explicit editable proposal; NEVER called implicitly on import.

    Rc25, 45-degree K, 2 mm land, zero opening, 6 mm reinforcements and
    QC longitudinal/QE top-and-bottom are proposed design choices, not facts
    established by the source JSON and not an assertion of executed welding.
    """
    p, s, m = project, project.section, project.material
    if s.fabrication != "welded" or p.fatigue.detail != "continuous_longitudinal_cjp_backgouged":
        raise ValueError("Select the welded-I / continuous-longitudinal-CJP branch explicitly first")
    if p.stiffener_connection != "web_and_both_flanges_welded":
        raise ValueError("Full-height credit requires all three physical interfaces")
    material = FullHeightMaterial(p.material_grade, m.fy_mpa, m.fu_mpa, m.E_mpa, m.G_mpa, 7850., m.specification)
    weld = FullHeightMaterial("proposed_matching_CJP_fillet_consumable", max(400., m.fy_mpa),
        max(485., m.fu_mpa), m.E_mpa, m.G_mpa, 7850., "Proposed procurement requirement; compatible fy/fu, certificate and WPS required before execution")
    def quality(grade, name, cjp=False):
        return FabricationQuality(grade, QE_REQUIREMENTS if grade == "QE" else QC_REQUIREMENTS,
            "PROPOSED-WPS-"+name, "UT_VT_MT" if cjp else "VT_MT",
            "NBR 8400-2 Table D.3 "+grade+"; applicable NBR 8800 H fatigue execution acceptance; design requirement")
    def cjp(grade, name):
        return CJPJointSpec(weld, quality(grade, name, True), 45., min(2., p.stiffener_thickness_mm/2, s.tw_mm/2),
            0., 0., 6., 0., 0., 4., CJP_REQUIREMENTS,
            "Explicit proposed K preparation/backgouging and 6 mm triangular reinforcement; longitudinal reinforcement is a design choice, not the transverse H.6.2 minimum")
    section = WeldedISectionDetail(s.d_mm, s.bf_mm, s.bottom_width, s.tf_mm, s.bottom_thickness,
        s.tw_mm, 0., material, cjp("QC", "LONG-TOP"), cjp("QC", "LONG-BOTTOM"),
        "Original project dimensions preserved; physical K/QC longitudinal welds are this proposed specification")
    cope = CopeSpec(25., 0., 2., "ground_notch_free", 25., "Proposed Rc25 minimum, no undersize tolerance; NBR 8800 H.6.3/.4")
    web_leg = ceil(max(6., p.stiffener_web_weld_min_leg_mm)*2)/2
    bottom_leg = ceil(max(6., p.stiffener_flange_weld_min_leg_mm)*2)/2
    web = FilletAttachmentSpec(web_leg, weld, quality("QC", "WEB"), quality("QE", "WEB-ENDS"),
        10*p.stiffener_thickness_mm, 0., "Proposed continuous two-sided web fillets with QE at both ends")
    bottom = FilletAttachmentSpec(bottom_leg, weld, quality("QE", "BOTTOM"), quality("QE", "BOTTOM"),
        p.stiffener_outstand_mm, 0., "Proposed continuous two-sided bottom fillets, QE over all length, no fitted bearing assumed")
    return FullHeightNominalDetail(section, material, p.stiffener_thickness_mm, p.stiffener_outstand_mm,
        cope, cope, cjp("QE", "TRANSVERSE-TOP"), web, bottom, p.beam_end_left_mm, p.beam_end_right_mm,
        p.fatigue.detail, "PROPOSED DESIGN ONLY: newly specified Rc25/K preparation, root/clearance, QC longitudinal, QE transverse top and bottom, weld bodies and WPS requirements. Original dimensions/projections unchanged; execution and inspection not verified.")


def resolve_fullheight_detail(project, physical_specs=None):
    if physical_specs is None:
        raise ValueError("Explicit persisted physical_specs required; proposing a new detail is a separate user-selected action")
    detail = physical_specs if type(physical_specs) is FullHeightNominalDetail else fullheight_detail_from_mapping(physical_specs)
    p, s, d = project, project.section, detail
    pairs = ((s.d_mm, d.section.depth_mm), (s.bf_mm, d.section.top_flange_width_mm),
        (s.bottom_width, d.section.bottom_flange_width_mm), (s.tf_mm, d.section.top_flange_thickness_mm),
        (s.bottom_thickness, d.section.bottom_flange_thickness_mm), (s.tw_mm, d.section.web_thickness_mm),
        (p.stiffener_thickness_mm, d.plate_thickness_mm), (p.stiffener_outstand_mm, d.outstand_mm),
        (p.beam_end_left_mm, d.beam_end_left_mm), (p.beam_end_right_mm, d.beam_end_right_mm))
    for a, b in pairs:
        if _number(a, "project dimension", nonnegative=True) != b:
            raise ValueError("Persisted full-height detail differs from original physical project dimensions/projections")
    if s.fabrication != "welded" or p.fatigue.detail != d.longitudinal_selection:
        raise ValueError("Static and fatigue longitudinal joint types disagree")
    if p.stiffener_connection != "web_and_both_flanges_welded":
        raise ValueError("Original project does not specify the required bottom and top attachments")
    for key in ("fy_mpa", "fu_mpa", "E_mpa", "G_mpa"):
        if _number(getattr(p.material, key), key, positive=True) != getattr(d.section.material, key):
            raise ValueError("Persisted beam material differs from project material")
    return detail


def _body(part_id, kind, volume, material, x, y, z, xextent, section_centroid_z, gravity):
    volume = _number(volume, "physical volume", positive=True)
    mass = volume*material.density_kg_m3/1e9
    return {"part_id": part_id, "part_kind": kind, "volume_mm3": volume, "material_id": material.material_id,
        "density_kg_m3": material.density_kg_m3, "mass_kg": mass, "x_mm": x, "y_mm": y,
        "z_from_bottom_mm": z, "z_mm": z-section_centroid_z, "z_centroid_mm": z-section_centroid_z,
        "x_extent_mm": list(xextent), "Fz_N": -mass*gravity,
        "Mx_origin_Nmm": -y*mass*gravity, "My_origin_Nmm": x*mass*gravity,
        "volume_basis": "exact_declared_nominal_prism_not_effective_throat", "as_built_verified": False}


def _section_centroid(s):
    a = (s.top_flange_width_mm*s.top_flange_thickness_mm,
         s.bottom_flange_width_mm*s.bottom_flange_thickness_mm, s.web_thickness_mm*s.clear_web_depth_mm)
    z = (s.depth_mm-s.top_flange_thickness_mm/2, s.bottom_flange_thickness_mm/2,
         s.bottom_flange_thickness_mm+s.clear_web_depth_mm/2)
    return fsum(v*w for v, w in zip(a, z))/fsum(a)


def fullheight_mass_ledger(detail, station_x_mm=0., *, station_id="station", gravity_m_s2=GRAVITY):
    """Station bodies only, each with its own physical centroid and Gk.

    Longitudinal deposits are not repeated at stations. The separate function
    longitudinal_mass_ledger reports the continuous-beam increment once.
    """
    d, s, g = detail, detail.section, fullheight_geometry(detail)
    x = _number(station_x_mm, "station_x_mm"); _text(station_id, "station_id")
    gravity = _number(gravity_m_s2, "gravity", positive=True)
    t, length = d.plate_thickness_mm, g["top_length_mm"]
    gross = g["plate_area_mm2"]*t
    removed = g["bevel_width_mm"]*g["bevel_depth_mm"]*length
    gu, gz = (g["top_start_u_mm"]+d.outstand_mm)/2, g["plate_top_z_mm"]-g["bevel_depth_mm"]/3
    remain = _number(gross-removed, "prepared plate volume", positive=True)
    points, replacements = [], []
    zcg = _section_centroid(s)
    for side, label in ((-1, "left"), (1, "right")):
        prefix = station_id+":plate:"+label
        gy = side*(s.web_thickness_mm/2+gu)
        y = (gross*side*g["plate_centroid_y_mm"]-removed*gy)/remain
        z = (gross*g["plate_centroid_z_mm"]-removed*gz)/remain
        def add(name, kind, v, material, xx, yy, zz, extent):
            row = _body(prefix+name, kind, v, material, xx, yy, zz, extent, zcg, gravity)
            row.update(station_id=station_id, connection_id=prefix, side=side)
            points.append(row)
        add("", "prepared_plate", remain, d.plate_material, x, y, z, (x-t/2, x+t/2))
        add(":cjp_groove", "cjp_groove_replacement", removed, d.top_cjp.material, x, gy, gz, (x-t/2, x+t/2))
        replacements.append({"connection_id": prefix, "removed_volume_mm3": removed,
            "replacement_volume_mm3": removed, "removed_density_kg_m3": d.plate_material.density_kg_m3,
            "replacement_density_kg_m3": d.top_cjp.material.density_kg_m3,
            "removed_centroid_y_mm": gy, "removed_centroid_z_mm": gz,
            "basis": "only declared double-bevel wedges, full refill; no extra backgouging volume invented"})
        if d.top_cjp.root_gap_mm:
            add(":cjp_opening", "cjp_root_opening_deposit", t*d.top_cjp.root_gap_mm*length,
                d.top_cjp.material, x, gy, g["top_z_mm"]-d.top_cjp.root_gap_mm/2, (x-t/2, x+t/2))
        for face in (-1, 1):
            for name, weld, L, yy, zz in (
                ("web", d.web_fillets, g["web_length_mm"], side*(s.web_thickness_mm/2+d.web_fillets.leg_mm/3),
                    (g["web_low_z_mm"]+g["web_high_z_mm"])/2),
                ("bottom", d.bottom_attachment, g["bottom_length_mm"], side*(s.web_thickness_mm/2+(d.lower_cope.radius_mm+d.outstand_mm)/2),
                    g["bottom_z_mm"]+d.bottom_attachment.leg_mm/3)):
                leg = weld.leg_mm
                add(f":{name}:{face:+d}", name+"_fillet", leg*leg*L/2, weld.material,
                    x+face*(t/2+leg/3), yy, zz, sorted((x+face*t/2, x+face*(t/2+leg))))
            leg = d.top_cjp.reinforcement_leg_mm
            add(f":cjp_reinforcement:{face:+d}", "cjp_transverse_reinforcement", leg*leg*length/2,
                d.top_cjp.material, x+face*(t/2+leg/3), gy, g["top_z_mm"]-leg/3,
                sorted((x+face*t/2, x+face*(t/2+leg))))
    return {"status": "NOMINAL_PHYSICAL_MASS_CALCULATED", "points": points,
        "total_mass_kg": fsum(v["mass_kg"] for v in points), "Fz_N": fsum(v["Fz_N"] for v in points),
        "preparation_replacement": replacements, "gravity_m_s2": gravity,
        "input_signature": _signature({"detail": d.to_dict(), "station_x_mm": x, "station_id": station_id, "gravity": gravity}),
        "geometry_inputs_hash": d.input_signature, "as_built_verified": False,
        "global_stiffness_credit": False, "includes_longitudinal_deposits": False,
        "section_centroid_from_bottom_mm": zcg, "mass_factor_applied": 1.,
        "fatigue_range_increment_N": 0., "source": SOURCE}


def longitudinal_mass_ledger(detail, beam_start_mm, beam_end_mm, *, gravity_m_s2=GRAVITY):
    """Continuous CJP additions relative to the already counted rectangle beam.

    Removal/refill pairs remain explicit and colocated. Only their exactly
    demonstrable density difference is a net correction. Reinforcement bodies
    above/below the shear centre stay separate for adverse-only D consumers.
    Nonzero longitudinal openings are rejected by the section adapter.
    """
    fullheight_geometry(detail)
    start, end = _number(beam_start_mm, "beam start"), _number(beam_end_mm, "beam end")
    L = _number(end-start, "physical beam length", positive=True)
    gravity = _number(gravity_m_s2, "gravity", positive=True)
    s, points, replacement, positive_deposits = detail.section, [], [], []
    zcg, x = _section_centroid(s), (start+end)/2
    for name, joint, surface, toward in (("top", s.longitudinal_top, s.top_inner_z_mm, -1),
            ("bottom", s.longitudinal_bottom, s.bottom_flange_thickness_mm, 1)):
        width, depth = _groove(joint, s.web_thickness_mm)
        volume, z = width*depth*L, surface+toward*depth/3
        replacement.append({"joint": name, "removed_volume_mm3": volume, "replacement_volume_mm3": volume,
            "removed_mass_kg": volume*s.material.density_kg_m3/1e9,
            "replacement_mass_kg": volume*joint.material.density_kg_m3/1e9,
            "centroid_z_from_bottom_mm": z, "centroid_x_mm": x,
            "basis": "two declared triangular groove wedges within original web rectangle; exactly colocated refill"})
        positive_deposits.append(_body("longitudinal_"+name+":groove_replacement", "longitudinal_CJP_groove_replacement",
            volume, joint.material, x, 0., z, (start, end), zcg, gravity))
        delta = volume*(joint.material.density_kg_m3-s.material.density_kg_m3)/1e9
        if delta:
            # Negative corrections are explicit, never hidden or treated as
            # new positive deposited bodies by adverse-only consumers.
            points.append({"part_id": "longitudinal_"+name+":refill_density_correction",
                "part_kind": "signed_colocated_density_correction", "mass_kg": delta,
                "x_mm": x, "y_mm": 0., "z_from_bottom_mm": z, "z_mm": z-zcg,
                "Fz_N": -delta*gravity, "x_extent_mm": [start, end], "signed_correction": True})
        leg = joint.reinforcement_leg_mm
        if leg:
            for side in (-1, 1):
                body = _body(f"longitudinal_{name}:reinforcement:{side:+d}", "longitudinal_CJP_reinforcement",
                    leg*leg*L/2, joint.material, x, side*(s.web_thickness_mm/2+leg/3), surface+toward*leg/3,
                    (start, end), zcg, gravity)
                points.append(body)
                positive_deposits.append(body)
    # A continuous longitudinal body is not a point load at its centroid.
    # The centroid records are for exact totals/moments and adverse D; load
    # producers must consume the uniform intensity over the physical extent.
    for body in points+positive_deposits:
        body.update(distribution="uniform_along_physical_x_extent", physical_length_mm=L,
            mass_kg_per_m=body["mass_kg"]*1000/L, Fz_N_per_mm=body["Fz_N"]/L)
    return {"points": points, "preparation_replacement": replacement,
        "physical_positive_deposit_points": positive_deposits,
        "D_adverse_only_points": positive_deposits,
        "D_adverse_only_basis": "Conservative added positive-deposit envelope relative to original rectangle beam; no removal credit, no cancellation of distinct top/bottom bodies. Do not use these additional bounds as global G mass.",
        "total_mass_kg": fsum(v["mass_kg"] for v in points), "mass_factor_applied": 1.,
        "Fz_N": fsum(v["Fz_N"] for v in points), "relative_to_existing_rectangle_beam": True,
        "input_signature": _signature({"detail": detail.to_dict(), "start": start, "end": end, "gravity": gravity}),
        "as_built_verified": False, "global_stiffness_credit": False,
        "load_model": "uniform_distributed_increment_over_actual_beam_extent_not_midpoint_point_load",
        "cannot_cancel_distinct_top_bottom_reinforcement_bodies": True}


def fullheight_mixed_group(detail, side, *, station_id="station"):
    """One CJP, two web fillets AND two bottom fillets per physical plate."""
    if type(side) is not int or side not in (-1, 1):
        raise ValueError("side must be integer -1 or +1")
    _text(station_id, "station_id")
    d, s, g = detail, detail.section, fullheight_geometry(detail)
    yw, root = side*s.web_thickness_mm/2, station_id+":plate:"+("left" if side < 0 else "right")
    lines = []
    for face in (-1, 1):
        lines.append(InterfaceLine(root+f":web:{face:+d}", "fillet", yw, g["web_low_z_mm"],
            yw, g["web_high_z_mm"], d.web_fillets.leg_mm/sqrt(2), face*d.plate_thickness_mm/2))
    lines.append(InterfaceLine(root+":top_cjp", "CJP", yw+side*g["top_start_u_mm"], g["top_z_mm"],
        yw+side*d.outstand_mm, g["top_z_mm"], g["CJP_effective_throat_mm"]))
    for face in (-1, 1):
        lines.append(InterfaceLine(root+f":bottom:{face:+d}", "fillet", yw+side*g["bottom_start_u_mm"],
            g["bottom_z_mm"], yw+side*d.outstand_mm, g["bottom_z_mm"],
            d.bottom_attachment.leg_mm/sqrt(2), face*d.plate_thickness_mm/2))
    return mixed_group(tuple(lines))


def _component_check(name, demand, capacity, scope, bound=False):
    demand = _number(demand, "demand", nonnegative=True)
    capacity = _number(capacity, "capacity", positive=True)
    ratio = demand/capacity
    return {"check_id": name, "demand_mpa": demand, "capacity_mpa": capacity,
        "demand": demand, "capacity": capacity, "units": "MPa", "basis": SOURCE,
        "utilization": ratio, "status": "SUFFICIENT" if ratio <= 1 else "NOT_SUFFICIENT" if bound else "COMPONENT_EXCEEDED",
        "scope": scope, "sufficient_bound": bound}


def _group_component_checks(d, solution, side):
    """Existing interface/rectangular-core mechanisms only, not 3-D approval."""
    g, s, checks = fullheight_geometry(d), d.section, []
    sections, interface_points, section_points, functions = {}, [], [], []
    def strengths(prefix, normal, shear, material, scope, *, bound=False):
        checks.extend(asdict(v) for v in _normal_checks(prefix, max(0., *normal),
            max(0., *(-v for v in normal)), material, scope, bound=bound, net_tension=True))
        checks.extend(asdict(v) for v in _shear_checks(prefix, shear, material, scope, bound=bound))
    for row in solution.lines:
        interface = row.interface
        qy, qz = max(abs(row.qy0_N_per_mm), abs(row.qy1_N_per_mm)), max(abs(row.qz0_N_per_mm), abs(row.qz1_N_per_mm))
        if interface.weld_type == "CJP":
            fy = min(d.plate_material.fy_mpa, s.material.fy_mpa)
            checks += [_component_check(interface.interface_id+"/CJP_normal", max(abs(row.tz0_mpa), abs(row.tz1_mpa)),
                fy/1.1, "EN 1993-1-8 4.7.1 and NBR 8800 Table 9; compatible real CJP, lesser base metal; no 45-degree transform"),
                _component_check(interface.interface_id+"/CJP_shear", max(abs(row.ty0_mpa), abs(row.ty1_mpa)),
                .6*fy/1.1, "Real CJP shear; normal/shear interaction with member remains separate")]
            for key, value, capacity in (("normal", qz/d.plate_thickness_mm, d.plate_material.fy_mpa/1.1),
                    ("shear", qy/d.plate_thickness_mm, .6*d.plate_material.fy_mpa/1.1)):
                checks.append(_component_check("top_net_ligament/"+key, value, capacity,
                    "Actual ts by post-cope CJP length, complete compatible refill; no reinforcement credited"))
            strengths("top_net_ligament", (row.qz0_N_per_mm/d.plate_thickness_mm,
                row.qz1_N_per_mm/d.plate_thickness_mm), qy/d.plate_thickness_mm, d.plate_material,
                "Actual final ts by post-cope CJP length; directly connected no-hole net section, compatible full groove refill")
        else:
            w = d.web_fillets if ":web:" in interface.interface_id else d.bottom_attachment
            checks.append(_component_check(interface.interface_id+"/fillet_resultant",
                row.peak_resultant_N_per_mm/interface.effective_throat_mm, .60*w.material.fu_mpa/1.35,
                "Audited NBR 8800 Table 9 resultant method, actual effective throat, no directional enhancement"))
            normal, shear = (qy, qz) if ":web:" in interface.interface_id else (qz, qy)
            checks += [_component_check(interface.interface_id+"/receiver_normal", normal/w.leg_mm,
                s.material.fy_mpa/1.1, "Actual fused receiver footprint, width=leg; member interaction not included"),
                _component_check(interface.interface_id+"/receiver_shear", shear/w.leg_mm,
                min(.6*s.material.fy_mpa/1.1, .6*s.material.fu_mpa/1.35), "Actual unperforated receiver footprint"),
                _component_check(interface.interface_id+"/plate_footprint_shear", row.peak_resultant_N_per_mm/w.leg_mm,
                min(.6*d.plate_material.fy_mpa/1.1, .6*d.plate_material.fu_mpa/1.35), "Both tractions are shear on the plate x-face")]
        # Signed nominal interface tensors, kept on the actual receiving face.
        # The group solution is the balancing reaction ON THE PLATE. The
        # opposite acts on the receiver. n_z=-1 at top and +1 at bottom.
        is_web = ":web:" in interface.interface_id
        is_top = interface.weld_type == "CJP"
        width = d.plate_thickness_mm if is_top else (d.web_fillets if is_web else d.bottom_attachment).leg_mm
        n = side if is_web else (-1 if is_top else 1)
        for endpoint, yy, zz, qy_e, qz_e in (("start", interface.y0_mm, interface.z0_mm, row.qy0_N_per_mm, row.qz0_N_per_mm),
                ("end", interface.y1_mm, interface.z1_mm, row.qy1_N_per_mm, row.qz1_N_per_mm)):
            if is_top:
                xface, interval = 0., (-d.plate_thickness_mm/2, d.plate_thickness_mm/2)
            else:
                face = 1 if interface.x_from_station_mm > 0 else -1
                xface = face*(d.plate_thickness_mm/2+width/2)
                interval = tuple(sorted((face*d.plate_thickness_mm/2, face*(d.plate_thickness_mm/2+width))))
            tensor = {"sigma_yy": -n*qy_e/width, "tau_yz": -n*qz_e/width} if is_web else {
                "sigma_zz": -n*qz_e/width, "tau_yz": -n*qy_e/width}
            interface_points.append({"point_id": interface.interface_id+"/receiver/"+endpoint,
                "material_role": "beam_web" if is_web else "beam_top_flange" if is_top else "beam_bottom_flange",
                "x_from_station_mm": xface, "x_footprint_interval_from_station_mm": interval,
                "y_mm": yy, "z_mm": zz, "tensor_components_mpa": tensor,
                "surface_normal": (0, n, 0) if is_web else (0, 0, n),
                "basis": "Signed nominal traction on actual receiver footprint, not a reconstructed interior field"})
    web = [v for v in solution.lines if ":web:" in v.interface.interface_id]
    yw, zmid, h = side*s.web_thickness_mm/2, (g["web_low_z_mm"]+g["web_high_z_mm"])/2, g["web_length_mm"]
    H, V = fsum(v.Fy_N for v in web), fsum(v.Fz_N for v in web)
    M = fsum(v.moment_about(yw, zmid) for v in web)
    A, W = d.plate_thickness_mm*h, d.plate_thickness_mm*h*h/6
    sigma = (-side*H/A-side*M/W, -side*H/A+side*M/W)
    tau = 1.5*abs(V)/A
    checks += [_component_check("plate_connected_root/normal", max(map(abs, sigma)), d.plate_material.fy_mpa/1.1,
        "Audited nominal rectangular connected root ts by vertical length, not full uncut plate", True),
        _component_check("plate_connected_root/shear", tau, min(.6*d.plate_material.fy_mpa/1.1,
            .6*d.plate_material.fu_mpa/1.35), "Audited parabolic rectangular-root shear", True)]
    strengths("plate_connected_root", sigma, tau, d.plate_material,
        "Actual connected rectangular root; ts by Lweb, no fictitious uncut root", bound=True)
    core, core_check = _rectangular_core_stability(outstand_mm=d.outstand_mm, thickness_mm=d.plate_thickness_mm,
        active_height_mm=h, E_mpa=d.plate_material.E_mpa, G_mpa=d.plate_material.G_mpa,
        fy_mpa=d.plate_material.fy_mpa, compression_mpa=max(0., *(-v for v in sigma)))
    checks.append(asdict(core_check))
    sections.update({"plate_connected_root": {"area_mm2": A, "net_area_mm2": A, "effective_area_mm2": A,
        "Ct": 1., "height_mm": h, "elastic_modulus_mm3": W, "normal_endpoints_mpa": sigma,
        "shear_peak_mpa": tau, "actual_web_Fy_N": H, "actual_web_Fz_N": V, "actual_web_Mx_Nmm": M},
        "core_stability": core})
    functions.append({"field_id": "plate_connected_root", "material_role": "plate", "plane": "yz",
        "x_from_station_mm": 0., "y_mm": yw, "z_interval_mm": (zmid-h/2, zmid+h/2),
        "parameter": "xi=2*(z-z_centroid)/height", "parameter_interval": (-1., 1.),
        "sigma_yy_polynomial_ascending_mpa": (-side*H/A, side*M/W),
        "tau_yz_polynomial_ascending_mpa": (-side*1.5*V/A, 0., side*1.5*V/A),
        "sigma_yy_interval_mpa": tuple(sorted(sigma)),
        "tau_yz_interval_mpa": tuple(sorted((0., -side*1.5*V/A))),
        "basis": "Exact linear-normal/parabolic-shear nominal rectangular-section functions across the entire actual connected root; no new field method"})
    for position, zz, sn, st in (("bottom", zmid-h/2, sigma[0], 0.),
            ("middle", zmid, -side*H/A, -side*1.5*V/A), ("top", zmid+h/2, sigma[1], 0.)):
        section_points.append({"point_id": "plate_root/"+position, "x_from_station_mm": 0.,
            "y_mm": yw, "z_mm": zz, "material_role": "plate",
            "tensor_components_mpa": {"sigma_yy": sn, "tau_yz": st},
            "basis": "Same-point linear normal and parabolic shear in actual connected rectangular root"})
    # Horizontal plate ligaments: the top has one true CJP line; the bottom
    # has two physical fillets. Symmetric faces cancel the out-of-plane couple.
    for location, rows, length, zz, normal_sign in (
            ("top", [v for v in solution.lines if v.interface.weld_type == "CJP"], g["top_length_mm"], g["top_z_mm"], 1),
            ("bottom", [v for v in solution.lines if ":bottom:" in v.interface.interface_id], g["bottom_length_mm"], g["bottom_z_mm"], -1)):
        normals = tuple(normal_sign*fsum(getattr(v, key) for v in rows)/d.plate_thickness_mm
                        for key in ("qz0_N_per_mm", "qz1_N_per_mm"))
        shears = tuple(normal_sign*fsum(getattr(v, key) for v in rows)/d.plate_thickness_mm
                        for key in ("qy0_N_per_mm", "qy1_N_per_mm"))
        strengths(location+"_horizontal_plate_ligament", normals, max(map(abs, shears)), d.plate_material,
            "Physical post-cope horizontal net ligament ts*L; sum of its own real interface lines, no transfer from another interface")
        sections[location+"_horizontal_plate_ligament"] = {"area_mm2": d.plate_thickness_mm*length,
            "net_area_mm2": d.plate_thickness_mm*length, "length_mm": length, "Ct": 1.,
            "normal_endpoints_mpa": normals, "shear_endpoints_mpa": shears,
            "Fy_N": fsum(v.Fy_N for v in rows), "Fz_N": fsum(v.Fz_N for v in rows)}
        functions.append({"field_id": location+"_horizontal_plate_ligament", "material_role": "plate",
            "plane": "yz", "x_from_station_mm": 0., "z_mm": zz,
            "y_interval_mm": (rows[0].interface.y0_mm, rows[0].interface.y1_mm),
            "parameter": "eta=(y-y0)/(y1-y0)", "parameter_interval": (0., 1.),
            "sigma_zz_polynomial_ascending_mpa": (normals[0], normals[1]-normals[0]),
            "tau_yz_polynomial_ascending_mpa": (shears[0], shears[1]-shears[0]),
            "sigma_zz_interval_mpa": tuple(sorted(normals)), "tau_yz_interval_mpa": tuple(sorted(shears)),
            "basis": "Exact nominal linear traction from all own physical group lines, divided by actual plate thickness"})
        for row in rows:
            # The bottom fillets occupy two separate real x strips outside
            # the plate thickness. Never spread them over a fictitious width.
            width = d.plate_thickness_mm if location == "top" else d.bottom_attachment.leg_mm
            tf = s.top_flange_thickness_mm if location == "top" else s.bottom_flange_thickness_mm
            zroot = zz+(tf/2 if location == "top" else -tf/2)
            area, modulus = width*tf, width*tf*tf/6
            moment = row.moment_about(yw, zroot)
            ns = (-side*row.Fy_N/area-side*moment/modulus, -side*row.Fy_N/area+side*moment/modulus)
            tshear = 1.5*abs(row.Fz_N)/area
            prefix = row.interface.interface_id+"/flange_strip"
            strengths(prefix, ns, tshear, s.material,
                "Actual physical receiver cantilever strip rooted at web face; group force and moment integrated about flange midplane, no spread", bound=True)
            sections[prefix] = {"width_x_mm": width, "thickness_mm": tf, "area_mm2": area,
                "elastic_modulus_mm3": modulus, "root_y_mm": yw, "root_z_mm": zroot,
                "load_y_interval_mm": sorted((row.interface.y0_mm, row.interface.y1_mm)),
                "reaction_Fy_N": row.Fy_N, "reaction_Fz_N": row.Fz_N, "reaction_Mx_Nmm": moment,
                "normal_endpoints_mpa": ns, "rectangular_peak_shear_mpa": tshear,
                "surface_shear_eccentricity_included": True, "sufficient_bound": True}
            xstrip = 0. if location == "top" else (1 if row.interface.x_from_station_mm > 0 else -1)*(d.plate_thickness_mm/2+width/2)
            functions.append({"field_id": prefix, "material_role": "beam_"+location+"_flange", "plane": "yz",
                "x_from_station_mm": xstrip, "x_interval_from_station_mm": (xstrip-width/2, xstrip+width/2),
                "y_mm": yw, "z_interval_mm": (zroot-tf/2, zroot+tf/2),
                "parameter": "xi=2*(z-z_centroid)/thickness", "parameter_interval": (-1., 1.),
                "sigma_yy_polynomial_ascending_mpa": (-side*row.Fy_N/area, side*moment/modulus),
                "tau_yz_polynomial_ascending_mpa": (-side*1.5*row.Fz_N/area, 0., side*1.5*row.Fz_N/area),
                "sigma_yy_interval_mpa": tuple(sorted(ns)),
                "tau_yz_interval_mpa": tuple(sorted((0., -side*1.5*row.Fz_N/area))),
                "basis": "Exact nominal linear-normal/parabolic-shear functions across entire physical receiver-strip root; no effective-width spread"})
            for position, zpoint, sn, st in (("lower", zroot-tf/2, ns[0], 0.),
                    ("middle", zroot, -side*row.Fy_N/area, -side*1.5*row.Fz_N/area),
                    ("upper", zroot+tf/2, ns[1], 0.)):
                section_points.append({"point_id": prefix+"/"+position, "x_from_station_mm": xstrip,
                    "y_mm": yw, "z_mm": zpoint, "material_role": "beam_"+location+"_flange",
                    "tensor_components_mpa": {"sigma_yy": sn, "tau_yz": st},
                    "basis": "Same-point nominal physical strip root, no effective-width increase"})
    # Sufficient downward-G path: root shear plus actual top net ligament,
    # separated by the upper free cope. Entire |G| is imposed on this subset;
    # the new bottom attachment contributes no favorable resistance. Its own
    # local demand is checked independently above. This is a reserve bound,
    # not an assertion that physical G follows only the old subset of lines.
    av, at = d.plate_thickness_mm*h, d.plate_thickness_mm*g["top_length_mm"]
    capacity = (min(.6*d.plate_material.fu_mpa*av, .6*d.plate_material.fy_mpa*av)
        +.5*d.plate_material.fu_mpa*at)/1.35
    force = abs(solution.required_Fz_N)
    checks.append({"check_id": "plate_root_top_block_bottom_resistance_omitted", "demand": force,
        "capacity": capacity, "units": "N", "utilization": force/capacity,
        "status": "SUFFICIENT" if force <= capacity else "NOT_SUFFICIENT", "sufficient_bound": True,
        "basis": "NBR 8800 6.5.6; actual root/top path, Cts=0.5, lower attachment favorable strength omitted",
        "scope": "Entire downward G imposed once on physical root+top subset; not the physical interface-force history"})
    sections["plate_root_top_block_bottom_resistance_omitted"] = {"Agv_mm2": av, "Anv_mm2": av,
        "Ant_mm2": at, "Cts": .5, "force_N": force, "capacity_N": capacity,
        "bottom_resistance_credited": False, "actual_lower_interface_checks_retained": True,
        "upper_free_cope_separates_actual_root_and_top_cuts": True}
    sections["signed_interface_points"] = interface_points
    sections["signed_section_points"] = section_points
    sections["nominal_section_stress_functions"] = functions
    return checks, sections


def fullheight_group_component_checks(detail, group_demand, side):
    """Independent component consumer of an authenticated five-line solution."""
    if type(side) is not int or side not in (-1, 1):
        raise ValueError("Physical side -1/+1 required")
    # solve_mixed_group revalidates geometry and equilibrium before use.
    checked = solve_mixed_group(group_demand.group, Fy_N=group_demand.required_Fy_N,
        Fz_N=group_demand.required_Fz_N, Mx_about_group_Nmm=group_demand.required_Mx_about_group_Nmm)
    if checked != group_demand:
        raise ValueError("Untampered mixed-group demand required")
    ids = [v.interface_id for v in checked.group.interfaces]
    if len(ids) != 5 or len([v for v in ids if ":bottom:" in v]) != 2:
        raise ValueError("This consumer requires all five full-height plate interfaces")
    station_id = ids[0].split(":plate:")[0]
    if checked.group != fullheight_mixed_group(detail, side, station_id=station_id):
        raise ValueError("Group does not belong to this physical full-height detail")
    return _group_component_checks(detail, checked, side)


def fullheight_selfweight_transfer(detail, structural_G_factor=1., *, station_x_mm=0., station_id="station"):
    """Gravity and 45 kN ONCE per plate connection, all five interfaces together.

    The floor replaces G locally on the real G force line. It never adds mass,
    global force or a fatigue cycle. Longitudinal member deposits do not flow
    through every transverse plate. Full receiver/member interactions and a
    new all-interface detachment proof are explicitly not claimed here.
    """
    factor = _number(structural_G_factor, "structural_G_factor", positive=True)
    ledger = fullheight_mass_ledger(detail, station_x_mm, station_id=station_id)
    assessment = fullheight_detail_assessment(detail)
    if any(not c["passed"] for c in assessment["checks"] if "no_long_joint_reduction" in c["check_id"]):
        raise ValueError("Mixed group requires unreduced effective physical lengths; long-joint reduction outside this API")
    connections = []
    for side in (-1, 1):
        bodies = [v for v in ledger["points"] if v["side"] == side]
        mass = fsum(v["mass_kg"] for v in bodies)
        y = fsum(v["mass_kg"]*v["y_mm"] for v in bodies)/mass
        z = fsum(v["mass_kg"]*v["z_from_bottom_mm"] for v in bodies)/mass
        moment_y = fsum((v["x_mm"]-station_x_mm)*(-v["Fz_N"])*factor for v in bodies)
        if not isclose(moment_y, 0., abs_tol=1e-8):
            raise ValueError("Nonplanar G moment falls outside the audited symmetric planar group")
        Gk, group = mass*GRAVITY, fullheight_mixed_group(detail, side, station_id=station_id)
        cases = []
        for name, force, replaces in (("real_factored_G", factor*Gk, False),
                ("connection_minimum_same_force_line", max(factor*Gk, MINIMUM_CONNECTION_FORCE_N), True)):
            solution = solve_mixed_group(group, Fy_N=0., Fz_N=force,
                Mx_about_group_Nmm=force*(y-group.centroid_y_mm))
            checks, sections = fullheight_group_component_checks(detail, solution, side)
            cases.append({"case_id": name, "required_Fz_N": force, "applied_gravity_Fz_N": -force,
                "group_force_convention": "balancing reactions on plate; equal opposite loads act on beam receivers",
                "force_line_y_mm": y,
                "replaces_real_G_locally": replaces, "group_demand": asdict(solution), "checks": checks,
                "section_results": sections, "executed_checks_sufficient": all(v["utilization"] <= 1 for v in checks),
                "global_load_increment_N": 0., "fatigue_stress_range_increment_mpa": 0.})
        connections.append({"side": side, "connection_id": bodies[0]["connection_id"],
            "body_ids": [v["part_id"] for v in bodies], "mass_kg": mass, "G_characteristic_N": Gk,
            "G_design_N": factor*Gk, "centroid_y_mm": y, "centroid_z_mm": z,
            "group": asdict(group), "cases": cases})
    pending = list(assessment["pending"])+[
        "concurrent_member_receiver_interaction: compose supplied signed footprint/physical-strip stresses with the member stresses at their actual points or declared spatial bounds",
        "concurrent_plate_normal_shear_interaction: compose supplied signed root and horizontal-ligament components in their yz plane; individual checks alone do not assert interaction",
    ]
    return {"status": "NOMINAL_G_GROUP_AND_COMPONENTS_CALCULATED", "connections": connections,
        "total_mass_kg": ledger["total_mass_kg"], "mass_ledger": ledger, "structural_G_factor": factor,
        "geometry_inputs_hash": detail.input_signature,
        "input_signature": _signature({"ledger": ledger["input_signature"], "G_factor": factor}),
        "nominal_stiffness_idealization": GROUP_ASSUMPTION, "pending": pending,
        "force_floor_policy": "max(factored actual G,45000 N) once per physical plate connection, same downward line; no force/mass/FAT addition",
        "station_qualified": False, "member_qualified": False, "global_stiffness_credit": False,
        "bearing_or_brace_actions_inferred": False, "as_built_verified": False}


__all__ = ["FullHeightMaterial", "FabricationQuality", "CJPJointSpec", "FilletAttachmentSpec", "CopeSpec",
    "WeldedISectionDetail", "FullHeightNominalDetail", "propose_fullheight_detail", "resolve_fullheight_detail",
    "fullheight_detail_from_mapping", "fullheight_geometry", "fullheight_detail_assessment", "fullheight_prescriptive",
    "fullheight_bearing_geometry", "fullheight_mass_ledger", "longitudinal_mass_ledger", "fullheight_mixed_group",
    "fullheight_selfweight_transfer", "fullheight_group_component_checks"]
