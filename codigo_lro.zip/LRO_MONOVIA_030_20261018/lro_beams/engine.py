"""Verificações delimitadas da viga suporte segundo fontes auditadas.

Convenção: N positivo tração; Mx positivo comprime mesa superior; x horizontal
na seção; y vertical na seção. Esses eixos NÃO são os eixos locais padrão Robot.
Unidades internas: N, mm, MPa. Entrada: kN/kN.m/m; sem remajoração de esforços.
"""
from __future__ import annotations
from dataclasses import dataclass, field, asdict
import math
from .model import Project, Material, Section, validate
from .geometry import Properties, section_properties, elastic_extreme_stresses

SOURCE_BENDING = "ABNT NBR 8800:2024 + Er1:2025, 5.4.2 e Anexo D, D.2.1/D.2.2, Tabela D.1, D.2.8(a,c,e,h); pp. 54–56, 137–138, 144–147"
SOURCE_SHEAR = "ABNT NBR 8800:2024 + Er1:2025, 5.4.3.1.1–5.4.3.1.2; pp. 57–58"
SOURCE_FATIGUE = "ABNT NBR 8800:2024 + Er1:2025, Anexo H, H.1–H.4(a), H.6 e Tabelas H.1/H.2; pp. 153–160 (numeração corrigida na errata p. 4)"
FATIGUE_CATEGORIES = {"A": (250e8,165.), "B": (120e8,110.), "B'": (61e8,83.), "C": (44e8,69.), "D": (22e8,48.), "E": (11e8,31.), "E'": (3.9e8,18.)}
ELS_PRESETS = {"runway_light": (750.,500.), "runway_moderate": (750.,500.), "runway_heavy": (1000.,500.), "runway_severe": (1250.,750.)}
SOURCE_ELS = "ABNT NBR 8800:2024 + Er1:2025, Anexo B, Tabela B.1 e notas a/f; p. 133"
SOURCE_LTB_LOAD = "ABNT NBR 8800:2024 + Er1:2025, 5.4.2.3–5.4.2.5; pp. 54–56"

@dataclass
class Check:
    id: str
    title: str
    status: str
    case: str = ""
    demand: float | None = None
    capacity: float | None = None
    unit: str = ""
    utilization: float | None = None
    source: str = ""
    equation: str = ""
    detail: str = ""
    values: dict = field(default_factory=dict)
    exceedance_policy: str = ""

@dataclass
class Result:
    input_valid: bool
    errors: list[str]
    properties: dict
    checks: list[Check]
    warnings: list[str]
    summary: str
    status: str
    coverage: dict = field(default_factory=dict)
    def to_dict(self):
        return asdict(self)


def ratio_check(id,title,case,demand,capacity,unit,source,equation,detail="",values=None):
    ratio=abs(demand)/capacity
    return Check(id,title,"ATENDE" if ratio <= 1.0+1e-10 else "NÃO ATENDE",case,
                 abs(demand),capacity,unit,ratio,source,equation,detail,values or {})


def ltb_resistance(g:Properties,m:Material,Lb_m:float,Cb:float) -> dict:
    """NBR8800 D.2.1 and D.2.8a. No extra Cb on inelastic branch (2024).

    Caller owns qualifying restraints/load application. Section must be compact I
    and doubly symmetric. Returns nominal/design capacities in kN.m.
    """
    Lb=Lb_m*1000
    lam=Lb/g.ry_mm
    lp=1.76*math.sqrt(m.E_mpa/m.fy_mpa)
    beta=.7*m.fy_mpa*g.Wx_mm3/(m.E_mpa*g.J_mm4)
    lr=1.38*Cb*math.sqrt(g.Iy_mm4*g.J_mm4)/(g.ry_mm*g.J_mm4*beta)*math.sqrt(1+math.sqrt(1+27*g.Cw_mm6*beta**2/(Cb**2*g.Iy_mm4)))
    mp=m.fy_mpa*g.Zx_mm3
    mr=.7*m.fy_mpa*g.Wx_mm3
    mcr=Cb*math.pi**2*m.E_mpa*g.Iy_mm4/Lb**2*math.sqrt(g.Cw_mm6/g.Iy_mm4*(1+.039*g.J_mm4*Lb**2/g.Cw_mm6))
    if lam<=lp:
        mn=mp; branch="plastificação (λ ≤ λp)"
    elif lam<=lr:
        mn=mp-(mp-mr)*(lam-lp)/(lr-lp); branch="FLT inelástica (λp < λ ≤ λr)"
    else:
        mn=mcr; branch="FLT elástica (λ > λr)"
    cap=1.5*g.Wx_mm3*m.fy_mpa
    return dict(lambda_=lam,lambda_p=lp,lambda_r=lr,beta1_per_mm=beta,Cb=Cb,Lb_m=Lb_m,
                Mpl_knm=mp/1e6,Mr_knm=mr/1e6,Mcr_knm=mcr/1e6,
                elastic_analysis_cap_knm=cap/m.gamma_a1/1e6,
                Mrd_knm=min(mn,mp,cap)/m.gamma_a1/1e6,branch=branch)


def vertical_shear_resistance(s:Section,g:Properties,m:Material) -> dict:
    """Unstiffened web, kv=5.34; area d*tw distinct from h/tw slenderness."""
    kv=5.34
    lam=g.h_mm/s.tw_mm
    lp=1.10*math.sqrt(kv*m.E_mpa/m.fy_mpa)
    lr=1.37*math.sqrt(kv*m.E_mpa/m.fy_mpa)
    vpl=.6*s.d_mm*s.tw_mm*m.fy_mpa
    factor=1 if lam<=lp else lp/lam if lam<=lr else 1.24*(lp/lam)**2
    return dict(kv=kv,lambda_=lam,lambda_p=lp,lambda_r=lr,Aw_mm2=s.d_mm*s.tw_mm,
                Vpl_kn=vpl/1000,Vrd_kn=factor*vpl/m.gamma_a1/1000,factor=factor)



def horizontal_shear_resistance(s:Section,m:Material) -> dict:
    kv=1.2; lam=s.bf_mm/(2*s.tf_mm)
    lp=1.10*math.sqrt(kv*m.E_mpa/m.fy_mpa)
    lr=1.37*math.sqrt(kv*m.E_mpa/m.fy_mpa)
    Aw=2*s.bf_mm*s.tf_mm
    vpl=.6*Aw*m.fy_mpa
    factor=1 if lam<=lp else lp/lam if lam<=lr else 1.24*(lp/lam)**2
    return dict(kv=kv,lambda_=lam,lambda_p=lp,lambda_r=lr,Aw_mm2=Aw,
                Vpl_kn=vpl/1000,Vrd_kn=factor*vpl/m.gamma_a1/1000,factor=factor)


def fatigue_allowable(category:str,cycles:int) -> float:
    Cf,threshold=FATIGUE_CATEGORIES[category]
    return max((329*Cf/cycles)**.333,threshold)


def fatigue_checks(p:Project) -> list[Check]:
    if not p.fatigue:
        return [Check("fatigue","Fadiga e vida útil","PENDENTE",source=SOURCE_FATIGUE,detail="Cadastrar cada ponto/detalhe crítico com histórico de serviço, categoria rastreável e ciclos da vida útil.")]
    checks=[]
    for i,f in enumerate(p.fatigue):
        delta=f.stress_max_mpa-f.stress_min_mpa
        source=SOURCE_FATIGUE
        values=dict(sigma_min_mpa=f.stress_min_mpa,sigma_max_mpa=f.stress_max_mpa,delta_mpa=delta,cycles=f.cycles,category=f.category)
        pending=[]
        if not f.constant_amplitude: pending.append("amplitude variável/não confirmada")
        if not f.same_point_confirmed: pending.append("extremos no mesmo ponto material não confirmados")
        if not f.fatigue_combination_confirmed: pending.append("combinação frequente de fadiga não confirmada")
        if not f.fabrication_requirements_confirmed: pending.append("requisitos do detalhe e fabricação não confirmados")
        if not f.corrosion_protected or f.temperature_c>=150: pending.append("corrosão/temperatura fora das condições H.2.7")
        if not all(x.strip() for x in (f.detail_reference,f.cycle_source,f.stress_source)): pending.append("fonte do detalhe, ciclos ou tensões ausente")
        if max(abs(f.stress_min_mpa),abs(f.stress_max_mpa))>.66*p.material.fy_mpa+1e-10: pending.append("tensão normal ultrapassa 0,66fy, limite de aplicabilidade H.2.2")
        if sum(x.name.strip().casefold()==f.name.strip().casefold() for x in p.fatigue)>1: pending.append("mais de um bloco com a mesma identificação de ponto exige avaliação de espectro, não soma de aprovações")
        if pending:
            checks.append(Check(f"fatigue_{i}","Fadiga normal por detalhe","PENDENTE",f.name,demand=delta,unit="MPa",source=source,equation="Δσ = σmax − σmin",detail="; ".join(pending)+".",values=values)); continue
        if f.cycles<20000:
            checks.append(Check(f"fatigue_{i}","Fadiga normal por detalhe","DISPENSADA NO DOMÍNIO",f.name,source=source,detail="N < 20 000 durante toda a vida útil do detalhe (H.2.6); demais requisitos de aplicação confirmados externamente.",values=values)); continue
        if f.stress_max_mpa<0:
            checks.append(Check(f"fatigue_{i}","Fadiga normal por detalhe","DISPENSADA NO DOMÍNIO",f.name,source=source,detail="Ambos os extremos de tensão do mesmo ponto são de compressão (H.2.5); domínio e origem confirmados externamente.",values=values)); continue
        Cf,threshold=FATIGUE_CATEGORIES[f.category]
        allowable=fatigue_allowable(f.category,f.cycles)
        values.update(Cf=Cf,threshold_mpa=threshold,exponent=.333)
        checks.append(ratio_check(f"fatigue_{i}","Fadiga normal por detalhe",f.name,delta,allowable,"MPa",source,"Δσ ≤ σSR = max[(329 Cf/N)^0,333; σTH]",f"Amplitude constante. Categoria {f.category}, detalhe {f.detail_reference}; seleção do detalhe, histórico e fabricação informados pelo responsável. Não cobre fadiga de cisalhamento, contato nem outros pontos.",values))
    return checks


def runway_local_resistances(p:Project,q) -> dict:
    """NBR8800 5.7.3–5.7.6, centered compressed outer-flange force.

    No rail spread/stiffener credit. Caller must qualify load path and lengths.
    """
    s=p.section;m=p.material;g=section_properties(s)
    d,tw,tf=s.d_mm,s.tw_mm,s.tf_mm
    n=q.bearing_length_mm;a=q.distance_to_end_mm
    k=tf+(s.root_radius_mm if s.fabrication=="rolled" else q.weld_leg_parallel_web_mm)
    coeff=5 if a>d else 2.5
    fyield=1.10*(coeff*k+n)*m.fy_mpa*tw/m.gamma_a1/1000
    near=a<d/2
    coeff_cr=.33 if near else .66
    term=(4*n/d-.2) if near and n/d>.2 else 3*n/d
    fcrip=coeff_cr*tw**2/m.gamma_a1*(1+term*(tw/tf)**1.5)*math.sqrt(m.E_mpa*m.fy_mpa*tf/tw)/1000
    seg=next(x for x in p.segments if x.name==q.segment)
    ell=max(seg.top_lb_m,seg.bottom_lb_m)*1000
    slender_ratio=(g.h_mm/tw)/(ell/s.bf_mm)
    threshold=2.3 if q.loaded_flange_rotation_restrained else 1.7
    Mr=m.fy_mpa*g.Wx_mm3/1e6
    qual=q.patch_qualification
    major_only=(qual.first_yield_basis=="qualified_major_axis"
                and qual.major_axis_first_yield_confirmed and bool(qual.first_yield_source.strip()))
    if major_only:
        from .runway_patch_8800 import patch_input_signature
        major_only=(qual.inputs_current_confirmed
                    and qual.qualified_input_signature==patch_input_signature(p,q,qual))
    Cr=(32 if major_only and abs(q.concomitant_Mx_knm)<Mr else 16)*m.E_mpa
    Cr_basis=("primeiro escoamento fyWx qualificado para flexão no eixo forte" if major_only
              else "Cr=16E conservador, menor dos dois ramos de 5.7.5.2; sem presumir ausência de N/My/empenamento")
    bracket=(.94 if q.loaded_flange_rotation_restrained else 0)+.37*slender_ratio**3
    flateral=Cr*tw**3*tf/(m.gamma_a1*g.h_mm**2)*bracket/1000
    fopposed=24*tw**3*math.sqrt(m.E_mpa*m.fy_mpa)/(m.gamma_a1*g.h_mm)/1000*(.5 if near else 1)
    return dict(k_mm=k,bearing_mm=n,end_distance_mm=a,h_mm=g.h_mm,web_yield_kn=fyield,web_crippling_kn=fcrip,
                near_end=near,lateral_ell_mm=ell,lateral_ratio=slender_ratio,lateral_threshold=threshold,
                Cr_mpa=Cr,Cr_basis=Cr_basis,Mr_knm=Mr,web_lateral_kn=flateral,opposed_compression_kn=fopposed)


def _runway_local_checks_core(p:Project) -> list[Check]:
    source="ABNT NBR 8800:2024 + Er1:2025, 5.7.1 e 5.7.3–5.7.6; pp. 63–66"
    if p.mode!="runway":
        return []
    if not p.runway_local:
        return [Check("local_wheels","Efeitos locais de roda no rolamento","PENDENTE",source=source,detail="Cadastrar força local ELU, comprimento efetivo de apoio na mesa, distância à extremidade e vínculos locais. Carga/contato de serviço não são automaticamente convertidos.")]
    checks=[]
    for i,q in enumerate(p.runway_local):
        prefix=f"local_{i}"
        gate=[]
        if not q.load_centered_on_web:gate.append("força centrada em relação à alma")
        if not q.load_on_top_compression:gate.append("força de compressão perpendicular na face externa da mesa superior")
        if not q.no_overlapping_bearing_zones:gate.append("ausência de sobreposição/interação de áreas carregadas")
        if not q.action_source.strip() or not q.bearing_source.strip():gate.append("origem do ELU e do comprimento efetivo de apoio na mesa")
        if gate:
            checks.append(Check(prefix+"_domain","Força concentrada local","PENDENTE",q.name,source=source,detail="Confirmar: "+", ".join(gate)+". Sem dispersão automática pelo trilho."));continue
        r=runway_local_resistances(p,q)
        def local_values(*names):
            return {name:r[name] for name in names}
        checks.append(ratio_check(prefix+"_yield","Escoamento local da alma",q.name,q.uls_load_kn,r['web_yield_kn'],"kN",source,"FRd = 1,10 (a k + ln) fy tw/γa1; a=5 se distância>d; a=2,5 nos demais casos", "k=tf+r para laminado; k=tf+perna paralela à alma para soldado.",local_values('k_mm','bearing_mm','end_distance_mm','web_yield_kn')))
        checks.append(ratio_check(prefix+"_cripple","Enrugamento local da alma",q.name,q.uls_load_kn,r['web_crippling_kn'],"kN",source,"FRd = c tw² [1 + q (tw/tf)^1,5] √(E fy tf/tw)/γa1; c,q conforme distância à extremidade", "c=0,66 no interior; c=0,33 perto da extremidade. q=3ln/d ou 4ln/d−0,2 conforme 5.7.4.",local_values('bearing_mm','end_distance_mm','near_end','web_crippling_kn')))
        if q.concomitant_Mx_knm < 0:
            checks.append(Check(prefix+"_lateral", "Flambagem lateral local da alma", "FORA DO DOMÍNIO", q.name, source=source, detail="Mx concomitante negativo traciona a mesa superior carregada. O ramo implementado de 5.7.5 exige carga sobre a mesa comprimida pela flexão; não extrapolar a resistência para este estado."))
        elif r["h_mm"]/p.section.tw_mm > 3.76*math.sqrt(p.material.E_mpa/p.material.fy_mpa):
            checks.append(Check(prefix+"_lateral","Flambagem lateral local da alma","FORA DO DOMÍNIO",q.name,source=source,detail="Alma fora da faixa compacta: primeiro escoamento e Cr dependem da qualificação do Anexo E. Não usar fyWx sem a redução aplicável."))
        elif not q.restraint_state_confirmed:
            checks.append(Check(prefix+"_lateral","Flambagem lateral local da alma","PENDENTE",q.name,source=source,detail="Confirmar deslocamento lateral relativo das mesas e restrição de rotação da mesa carregada."))
        elif q.relative_lateral_displacement_prevented:
            checks.append(Check(prefix+"_lateral","Flambagem lateral local da alma","NÃO APLICÁVEL NO DOMÍNIO",q.name,source=source,detail="Movimento lateral relativo das mesas impedido no ponto de carga, conforme vínculo externo declarado; 5.7.5."))
        elif r['lateral_ratio']>r['lateral_threshold']:
            checks.append(Check(prefix+"_lateral","Flambagem lateral local da alma","NÃO APLICÁVEL NO DOMÍNIO",q.name,source=source,detail="Relação (h/tw)/(ell/bf) acima do limite de 5.7.5.3; modo excluído dentro deste domínio.",values=local_values('h_mm','lateral_ell_mm','lateral_ratio','lateral_threshold')))
        else:
            checks.append(ratio_check(prefix+"_lateral","Flambagem lateral local da alma",q.name,q.uls_load_kn,r['web_lateral_kn'],"kN",source,"FRd=Cr tw³ tf/(γa1 h²) [a+0,37r³]; a=0,94 com rotação impedida, senão 0", "ell considera o maior comprimento destravado das duas mesas; "+r['Cr_basis']+".",local_values('h_mm','lateral_ell_mm','lateral_ratio','lateral_threshold','Cr_mpa','Cr_basis','Mr_knm','web_lateral_kn')))
        if not q.opposed_pair_status_confirmed:
            checks.append(Check(prefix+"_opposed","Compressões opostas nas duas mesas","PENDENTE",q.name,source=source,detail="Confirmar existência ou ausência de par de forças de compressão nas duas mesas da mesma seção, por exemplo roda sobre reação de apoio."))
        elif q.opposed_compression_pair:
            checks.append(ratio_check(prefix+"_opposed","Flambagem da alma por compressões opostas",q.name,q.uls_load_kn,r['opposed_compression_kn'],"kN",source,"FRd=24 tw³ √(E fy)/(γa1 h), reduzido à metade se distância<d/2", "Verificação do par de compressões declarado. Confirmar a força de compressão aplicável ao par.",local_values('h_mm','end_distance_mm','near_end','opposed_compression_kn')))
        else:
            checks.append(Check(prefix+"_opposed","Compressões opostas nas duas mesas","NÃO APLICÁVEL NO DOMÍNIO",q.name,source=source,detail="Ausência de forças opostas na mesma seção declarada pelo responsável."))
        if not q.flange_web_transfer_verified:
            checks.append(Check(prefix+"_transfer","Transferência da força entre mesa e alma","PENDENTE",q.name,detail="Verificar ligação mesa-alma/soldas e demais interfaces reais. As fórmulas de alma não dimensionam essa transferência."))
        checks.append(Check(prefix+"_rail","Trilho, contato e fixação","RESPONSABILIDADE EXTERNA",q.name,source="NBR 10084:2020, 9.1.3/9.1.4; NBR 8800:2024, 5.7.2.1",detail="Projeto do trilho, contato roda–trilho e fixações pertencem à interface externa. A rota local superior exige compressão centrada e apoio qualificado. Tração/levantamento, excentricidade fora do domínio, apoio de borda/parcial e descontinuidades exigem avaliação específica; não se importa a regra de roda na mesa inferior para este caso."))
    return checks


def runway_local_checks(p:Project) -> list[Check]:
    """Keep original numeric checks; append the separately qualified subset.

    The adapter calls only the core above, never this wrapper. Its coverage
    note is informative, not an invented universal shell-analysis requirement.
    """
    checks = _runway_local_checks_core(p)
    if p.mode != "runway":
        return checks
    from .runway_patch_8800 import qualify_local_web_8800, SOURCES
    for i, q in enumerate(p.runway_local):
        result = qualify_local_web_8800(p, q, q.patch_qualification)
        detail = " ".join(result["errors"] + result["pending"])
        status = result["local_web_status"]
        if not result["input_valid"]:
            status = "ENTRADA INVÁLIDA"
        if result["local_web_subset_verified"]:
            detail = "Conjunto de mecanismos locais de alma de 5.7.3–5.7.6 avaliado quanto à aplicabilidade e à resistência no domínio declarado, sem crédito resistente de enrijecedores. Não constitui aprovação integral da viga."
        elif not detail:
            detail = "O subconjunto local não está encerrado; consultar resultados individuais e domínio aplicável."
        checks.append(Check(f"local_{i}_qualification", "Qualificação do conjunto local da alma", status,
            q.name, source=SOURCES["supplement"] + "; " + SOURCES["gamma"] + "; " + SOURCES["ends"],
            detail=detail, values={"local_web_subset_verified": result["local_web_subset_verified"],
                                  "qualification": asdict(q.patch_qualification)}))
        checks.append(Check(f"local_{i}_coverage", "Alcance da verificação de alma e painel", "INFORMATIVO",
            q.name, source=SOURCES["panel"], detail=result["remaining_assessments"][0]["detail"]))
    return checks


def monorail_local_elastic(p:Project,q) -> dict:
    """Dowswell2013 eq1–3,10,48–49. Nominal elastic screen, no ABNT factor."""
    c=(p.section.bottom_width-p.section.tw_mm)/2
    b=q.b_mm;tf=p.section.bottom_thickness;fy=p.material.fy_mpa
    be=b*(3.5-1.5*b/c)
    Se=be*tf**2/6
    sigma=q.service_load_kn*1000*b/Se
    n=abs(q.longitudinal_service_stress_mpa)/fy
    alpha=math.sqrt(1-.75*n*n)-n/2 if n<1 else 0.0
    Py=Se*fy/b/1000
    return dict(loaded_flange='bottom',loaded_flange_width_mm=p.section.bottom_width,loaded_flange_thickness_mm=tf,b_mm=b,c_mm=c,b_over_c=b/c,be_mm=be,Se_mm3=Se,sigma_local_mpa=sigma,
                longitudinal_stress_mpa=q.longitudinal_service_stress_mpa,n=n,alpha=alpha,
                nominal_yield_load_kn=Py,interaction_yield_load_kn=alpha*Py)


def monorail_local_checks(p:Project) -> list[Check]:
    if p.mode!="monorail":return []
    source="Dowswell, Flange Bending in Single Curvature, AISC Engineering Journal 50(2), 2013, pp. 71–73, 78–80; equações 1–3, 10, 48–49. https://ej.aisc.org/index.php/engj/article/view/1043"
    checks=[]
    if not p.monorail_local:
        checks.append(Check("mono_missing", "Mesa inferior sob as rodas", "PENDENTE", source=source,
                            detail="Cadastrar carga por roda, posição transversal, tensão longitudinal concomitante e domínio para a avaliação elástica complementar."))
    checks.append(Check("mono_local_completion", "ELU local, contato e fadiga local da monovia", "PENDENTE", source=source,
                        detail="O limiar elástico nominal de Dowswell não conclui a resistência ELU normativa da mesa, contato roda-mesa, transferência mesa-alma ou fadiga local. Qualificar esses modos e a interação local/global real antes de liberar a viga. Fadiga global cadastrada separadamente não resolve estes itens."))
    for i,q in enumerate(p.monorail_local):
        gate=[];c=(p.section.bottom_width-p.section.tw_mm)/2
        if not .25<=q.b_mm/c<=1:gate.append("b/c fora do domínio adotado de 0,25 a 1,00")
        if not q.straight_parallel_flange:gate.append("viga reta e mesa paralela não confirmadas")
        if not q.fixed_flange_root:gate.append("engastamento da raiz da aba não confirmado")
        if not q.no_relevant_shear_or_torsion:gate.append("cisalhamento/torção relevantes ou não excluídos")
        if not q.wheel_loads_isolated or q.same_outstand_spacing_mm<1.5*p.section.bottom_width:gate.append("rodas próximas/interação não excluídas")
        if q.distance_to_end_mm<p.section.bottom_width+p.section.d_mm:gate.append("carga próxima à extremidade; afastamento conservador adotado é bf+d")
        if not q.load_source.strip() or not q.longitudinal_stress_source.strip():gate.append("fonte da carga de serviço ou tensão longitudinal ausente")
        if gate:
            checks.append(Check(f"mono_{i}","Mesa inferior pelo método elástico complementar","PENDENTE",q.name,source=source,detail="; ".join(gate)+". Não extrapolar para curva, transferência, contato especial ou roda em proximidade."));continue
        r=monorail_local_elastic(p,q)
        if r['n']>=1:
            limit_check=ratio_check(f"mono_{i}","Tensão longitudinal e limiar elástico nominal",q.name,abs(q.longitudinal_service_stress_mpa),p.material.fy_mpa,"MPa",source,"n=|σlong,serv|/fy", "A tensão longitudinal isolada já atinge/excede fy e a carga local é positiva. Não há reserva elástica local pelo modelo complementar, inclusive quando n=1.",r)
            limit_check.status="EXCEDE LIMIAR COMPLEMENTAR"
            checks.append(limit_check);continue
        qcheck=ratio_check(f"mono_{i}","Mesa inferior pelo método elástico complementar",q.name,q.service_load_kn,r['interaction_yield_load_kn'],"kN",source,
                         "be=b(3,5−1,5b/c); Se=be tf²/6; σlocal=Pserv b/Se; α=√(1−3n²/4)−n/2; Py,comb=α Se fy/b",
                         "Comparação de serviço com o limiar nominal de início de escoamento do modelo elástico, sem gamma de resistência ABNT. Usa |σlong| conservador na interação. Não é resistência ELU normativa, não fornece todo o campo local bidimensional e não verifica contato nem fadiga local.",r)
        qcheck.status="ABAIXO DO LIMIAR COMPLEMENTAR" if qcheck.utilization<=1+1e-10 else "EXCEDE LIMIAR COMPLEMENTAR"
        checks.append(qcheck)
    return checks

def normative_checks(p):
    from .normative import evaluate, LABELS
    from .normative_report_labels import CHECK_TITLES
    import json
    checks=[]
    if p.mode != 'runway':
        return checks
    for route,rows in p.normative_inputs.items():
        if not rows and route not in ("continuous_restraint_8400","runway_torsion_8400") and not (route == "flt_8400" and (p.normative_inputs["continuous_restraint_8400"] or p.normative_inputs.get("runway_torsion_8400"))):
            checks.append(Check('missing_'+route,LABELS[route],'PENDENTE',detail='Rota específica não cadastrada. Os dados ELU NBR 8800 não substituem esta avaliação.'))
    from .coverage_integration import evaluate_project_coverage,resolved_local_requirements,coverage_checks
    outputs=evaluate(p.normative_inputs,p)
    coverage=evaluate_project_coverage(p,outputs)
    for block in outputs:
        result=block['result']; prefix=f"{block['route']}_{block['index']}";case=block['input'].get('name','')
        src=result.get('source') or result.get('sources',{})
        def format_source(value):
            if isinstance(value,str):
                return format_source(result.get('sources',{}).get(value,{})) if value in result.get('sources',{}) else value
            if isinstance(value,dict) and 'standard' in value:
                pages=', '.join(str(n) for n in value.get('printed_pages',[]))
                return value['standard']+'; '+value.get('clause','')+('; páginas impressas '+pages if pages else '')
            if isinstance(value,dict):return ' | '.join(dict.fromkeys(format_source(v) for v in value.values()))
            return str(value)
        source=format_source(src)
        for j,c in enumerate(result.get('checks',[])):
            status=c.get('status','INFORMATIVO')
            if status=='ATENDE NO DOMÍNIO':status='ATENDE'
            if status not in ('ATENDE','NÃO ATENDE','PENDENTE','FORA DO DOMÍNIO','FORA DO ESCOPO','ENTRADA INVÁLIDA','DADOS INVÁLIDOS'):status='INFORMATIVO'
            csource=format_source(c.get('source',source))
            checks.append(Check(prefix+'_'+str(j),c.get('title',c.get('name',CHECK_TITLES.get(c.get('id',''),block['label']+' / '+c.get('id','')))),status,case,
                c.get('demand'),c.get('capacity'),c.get('unit',''),c.get('utilization'),csource,c.get('formula',c.get('equation','')),
                c.get('message',c.get('detail','')),exceedance_policy=c.get('exceedance_policy','')))
        resolved=resolved_local_requirements(block,coverage)
        details=result.get('errors',[])+[x for x in result.get('pending',[]) if x not in resolved]
        for n,item in enumerate(result.get('external_responsibilities',[])):
            checks.append(Check(prefix+'_external_'+str(n),block['label']+' — interface externa','RESPONSABILIDADE EXTERNA',case,source=source,detail=item))
        if result.get('input_valid') is False and not details:
            details=['Entrada normativa inválida; revise o registro antes de usar o resultado.']
        if result.get('status') in ('FORA DO DOMÍNIO','FORA DO ESCOPO') and not details:
            details=['Caso fora do domínio implementado: '+result['status']+'.']
        if details:checks.append(Check(prefix+'_pending',block['label']+' — limites e pendências','PENDENTE',case,source=source,detail='; '.join(str(x) for x in details)))
        checks.append(Check(prefix+'_audit',block['label']+' — entradas e desenvolvimento','INFORMATIVO',case,source=source,
            detail='Rota independente, sem aplicar novamente fatores. Não representa conformidade integral.',
            values={'entradas':block['input'],'intermediarios':result.get('intermediates',result.get('values',{})),
                    'tensoes':result.get('stresses',{}),'limites_do_metodo':result.get('limitations',[]),
                    'desenvolvimento':[{**step,'source':format_source(step.get('source',source))} for step in result.get('audit',[])]}))
    for row in coverage_checks(coverage):
        checks.append(Check(row['id'],row.get('title',row.get('name','Cobertura')),row['status'],row.get('case',''),row.get('demand'),row.get('capacity'),row.get('unit',''),row.get('utilization'),row.get('source',''),row.get('formula',row.get('equation','')),row.get('detail',row.get('message','')),row.get('values',{}),exceedance_policy=row.get('exceedance_policy','')))
    return checks


def _calculate(p:Project) -> Result:
    errors=validate(p)
    if errors:
        return Result(False,errors,{},[],[],"Corrija os dados antes do cálculo.","DADOS INVÁLIDOS")
    g=section_properties(p.section); m=p.material
    checks=[]; warnings=[]
    lp_f=.38*math.sqrt(m.E_mpa/m.fy_mpa)
    lp_w=3.76*math.sqrt(m.E_mpa/m.fy_mpa)
    compact_f=g.flange_lambda<=lp_f+1e-10
    compact_w=g.web_lambda<=lp_w+1e-10
    if g.Ix_mm4 <= g.Iy_mm4:
        return Result(True,[],g.to_dict(),[Check("axis_domain","Orientação dos eixos principais","FORA DO DOMÍNIO",detail="O motor exige Ix > Iy; esta geometria inverte ou iguala os eixos forte/fraco. Nenhuma resistência normativa foi calculada.")],[],"Geometria fora da orientação forte/fraca qualificada.","FORA DO DOMÍNIO DE RESISTÊNCIA")
    if not p.section.doubly_symmetric:
        checks=[Check("monosymmetric_scope","Seção com mesas diferentes","FORA DO DOMÍNIO",source="Mecânica de seções compostas por retângulos",detail="Propriedades e tensões elásticas calculadas com centroide real. FLT, resistência, efeitos locais e interação de seção monossimétrica ainda não qualificados. Não usar as fórmulas de I duplamente simétrico.")]
        for i,c in enumerate(p.uls):
            checks.append(Check(f"uls_{i}_elastic","Tensões normais elásticas nos quatro cantos","INFORMATIVO",c.name,unit="MPa",source="Mecânica elástica de barras",equation="σ=N/A−Mx·(y−yg)/Ix+My·x/Iy",detail="Não inclui torção, empenamento ou tensões locais de roda.",values=elastic_extreme_stresses(c.N_kn,c.Mx_knm,c.My_knm,g)))
        return Result(True,[],g.to_dict(),checks,["Mesas desiguais: pré-dimensionamento geométrico apenas; cálculo normativo não concluído."],"Prévia de geometria e tensões elásticas. Resistências não calculadas para mesas diferentes.","FORA DO DOMÍNIO DE RESISTÊNCIA")
    checks.append(Check("geometry","Geometria e unidades","VÁLIDO",source="Geometria da seção e validações dimensionais do aplicativo",detail="I duplamente simétrico. Propriedades e dimensões coerentes dentro das tolerâncias do cadastro."))
    if p.mode!="runway" or p.supplement_global_8800:checks.append(Check("compact_flange","Domínio da mesa para flexão","NO DOMÍNIO" if compact_f else "FORA DO DOMÍNIO",demand=g.flange_lambda,capacity=lp_f,unit="b/t",source=SOURCE_BENDING,equation="λf = bf/(2tf); λp = 0,38 √(E/fy)",detail="Este módulo 8800 verifica somente mesas compactas. Exceder λp não significa ruptura; exige cálculo de FLM não compacta/esbelta."))
    if p.mode!="runway" or p.supplement_global_8800:checks.append(Check("compact_web","Domínio da alma para flexão forte","NO DOMÍNIO" if compact_w else "FORA DO DOMÍNIO",demand=g.web_lambda,capacity=lp_w,unit="h/tw",source=SOURCE_BENDING,equation="λw = h/tw; λp = 3,76 √(E/fy)",detail="Este módulo 8800 verifica somente almas compactas à flexão forte. Não confundir este limite com a esbeltez de cisalhamento."))
    if p.mode=="runway":
        selected={"supplement_global_8800":p.supplement_global_8800,"supplement_service_8800":p.supplement_service_8800,"supplement_fatigue_8800":p.supplement_fatigue_8800}
        selection_ok=all(selected.values()) or bool(p.supplement_selection_source.strip())
        checks.append(Check("supplement_selection","Seleção das verificações complementares 8800","REGISTRADO" if selection_ok else "PENDENTE",source="ABNT NBR 10084:2020, 9.1.1",detail="A rota principal 10084/8400 permanece ativa. Desativar um complemento não significa dispensar a verificação correspondente: justificar a rota substituta e seu domínio. "+p.supplement_selection_source,values=selected))
    a=p.actions_review
    review_ok=(all((a.criterion_document.strip(),a.manufacturer_load_sheet.strip(),a.service_group_source.strip(),a.temperature_basis.strip())) and a.temperature_status!="pending" and a.wheel_positions_confirmed and a.horizontal_actions_confirmed and a.dynamic_factors_confirmed and a.torsion_warping_confirmed)
    checks.append(Check("actions_review","Critérios, temperatura e ações do modelo","REGISTRADO" if review_ok else "PENDENTE",detail="Registro de conferência do responsável, não verificação independente do modelo Robot. Temperatura: "+{"pending":"pendente","included":"incluída no modelo","not_applicable":"não aplicável com justificativa"}.get(a.temperature_status,a.temperature_status)+". "+a.temperature_basis,values=asdict(a)))
    qualified_actions=p.simultaneous_actions_confirmed and p.sign_convention_confirmed and bool(p.robot_model.strip())
    if not qualified_actions:
        checks.append(Check("action_traceability","Origem e convenções dos esforços","PENDENTE",detail="Identifique o modelo/combinações Robot e confirme esforços concomitantes e mapeamento dos eixos/sinais. Os números abaixo são diagnósticos das entradas fornecidas."))
    warnings.append("Os esforços ELU são usados exatamente como informados, sem impacto ou coeficiente de ponderação adicional. O aplicativo não procura posições de rodas nem substitui o modelo global.")
    warnings.append("As verificações cobrem somente as linhas fornecidas. O responsável deve incluir os extremos relevantes de cada combinação/trecho e os pontos de aplicação de cargas concentradas.")
    if abs(m.gamma_a1-1.10)>1e-8:
        warnings.append("gamma_a1 difere de 1,10. Justificar a combinação e a tabela normativa adotada; o programa não escolhe o coeficiente automaticamente.")
    compact=compact_f and compact_w
    mx_local=min(m.fy_mpa*g.Zx_mm3,1.5*m.fy_mpa*g.Wx_mm3)/m.gamma_a1/1e6
    my_rd=min(m.fy_mpa*g.Zy_mm3,1.5*m.fy_mpa*g.Wy_mm3)/m.gamma_a1/1e6
    shear=vertical_shear_resistance(p.section,g,m)
    horizontal_shear=horizontal_shear_resistance(p.section,m)
    for i,c in enumerate(p.uls if p.mode!="runway" or p.supplement_global_8800 else []):
        prefix=f"uls_{i}"
        seg=next(s for s in p.segments if s.name==c.segment)
        case=f"{c.name} | {c.segment} | s={c.position_m:.2f} m"
        stresses=elastic_extreme_stresses(c.N_kn,c.Mx_knm,c.My_knm,g)
        checks.append(Check(prefix+"_elastic","Tensões normais elásticas nos quatro cantos","INFORMATIVO",case,unit="MPa",source="Mecânica elástica de barras; não é verificação isolada de resistência",equation="σ = N/A ± Mx/Wx ± My/Wy",detail="N positivo em tração; Mx positivo comprime a mesa superior. Não inclui tensões locais de roda, empenamento ou torção.",values=stresses))
        if abs(c.N_kn)>1e-9:
            checks.append(Check(prefix+"_axial","Força axial e interação com flexão","FORA DO ESCOPO",case,detail="Há N diferente de zero. Compressão/tração e flexocompressão/flexotração não são verificadas nesta versão; as capacidades isoladas não aprovam a seção."))
        if abs(c.T_knm)>1e-9:
            checks.append(Check(prefix+"_torsion","Torção e empenamento","FORA DO ESCOPO",case,detail="T diferente de zero requer tensões de torção/empenamento e interação. Flexão/cortante isolados permanecem resultados parciais."))
        # Local flexural capacities are useful even if FLT cannot be concluded.
        if compact:
            checks.append(ratio_check(prefix+"_local_major","Flexão forte FLM e FLA compactas",case,c.Mx_knm,mx_local,"kN.m",SOURCE_BENDING,"MRd,local = min(Zx fy; 1,50 Wx fy)/γa1","Capacidade local da seção. A resistência de flexão da barra ainda depende de FLT."))
        else:
            checks.append(Check(prefix+"_local_major","Flexão forte FLM e FLA","FORA DO DOMÍNIO",case,source=SOURCE_BENDING,detail="Mesa ou alma não compacta; aplicação das demais faixas de Anexo D/E pendente."))
        if compact_f:
            checks.append(ratio_check(prefix+"_minor","Flexão fraca FLM compacta",case,c.My_knm,my_rd,"kN.m",SOURCE_BENDING,"MRd,y = min(Zy fy; 1,50 Wy fy)/γa1","Para I duplamente simétrico à flexão fraca não se aplica FLA da alma (D.2.8c)."))
        else:
            checks.append(Check(prefix+"_minor","Flexão fraca FLM","FORA DO DOMÍNIO",case,source=SOURCE_BENDING,detail="Mesa não compacta."))
        flange="superior" if c.Mx_knm>=0 else "inferior"
        Lb=seg.top_lb_m if c.Mx_knm>=0 else seg.bottom_lb_m
        Cb=seg.cb_top if c.Mx_knm>=0 else seg.cb_bottom
        stability_ok=seg.brace_stiffness_verified and seg.torsion_rotation_restrained_at_ends and seg.load_application_qualified
        mx_rd=None
        if abs(c.Mx_knm)<1e-9:
            checks.append(Check(prefix+"_ltb","Flambagem lateral com torção","NÃO SOLICITADA",case,source=SOURCE_BENDING,detail="Mx é nulo nesta linha. Esta condição não dispensa a verificação nos demais pontos da barra."))
            mx_rd=mx_local if compact else None
        elif not compact:
            checks.append(Check(prefix+"_ltb","Flambagem lateral com torção","FORA DO DOMÍNIO",case,source=SOURCE_BENDING,detail="Este motor exige seção compacta para a resistência final de flexão forte."))
        elif not stability_ok:
            missing=[]
            if not seg.brace_stiffness_verified: missing.append("resistência/rigidez efetiva dos travamentos")
            if not seg.torsion_rotation_restrained_at_ends: missing.append("vínculos de torção/rotação nas extremidades de Lb")
            if not seg.load_application_qualified: missing.append("altura da carga e Cb qualificado")
            checks.append(Check(prefix+"_ltb","Flambagem lateral com torção","PENDENTE",case,source=SOURCE_LTB_LOAD,detail=f"Mesa {flange}; Lb={Lb:.2f} m. Falta confirmar/documentar: {', '.join(missing)}. Carga no trilho acima da semialtura pode desestabilizar a viga; Cb=1 não é automaticamente conservador."))
        else:
            r=ltb_resistance(g,m,Lb,Cb); mx_rd=r['Mrd_knm']
            if r['lambda_r']<=r['lambda_p']:
                mx_rd=None
                checks.append(Check(prefix+"_ltb","Flambagem lateral com torção","FORA DO DOMÍNIO",case,source=SOURCE_BENDING,detail="Cb informado produz λr ≤ λp; a sequência de faixas implementada não é aplicável. Requer outro procedimento de estabilidade qualificado."))
            else:
                checks.append(ratio_check(prefix+"_ltb","Flambagem lateral com torção",case,c.Mx_knm,mx_rd,"kN.m",SOURCE_BENDING,"λ=Lb/ry; λp=1,76√(E/fy); β1=0,70fyWx/(EJ); λr=[1,38Cb√(IyJ)/(ryJβ1)]√[1+√(1+27Cwβ1²/(Cb²Iy))]; Mpl=fyZx; Mr=0,70fyWx; Mcr=Cbπ²EIy/Lb²√[(Cw/Iy)(1+0,039JLb²/Cw)]; Mn=Mpl (λ≤λp), Mpl−(Mpl−Mr)(λ−λp)/(λr−λp) (λp<λ≤λr), Mcr (λ>λr); MRd=min(Mn,Mpl,1,50Wxfy)/γa1",f"Mesa comprimida {flange}. {r['branch']}. Origem externa de vínculos/Cb: {seg.stability_basis}",r))
        checks.append(ratio_check(prefix+"_shear_vertical","Cortante vertical na alma",case,c.Vy_kn,shear['Vrd_kn'],"kN",SOURCE_SHEAR,"Aw=d tw; Vpl=0,60 Aw fy; kv=5,34; λ=h/tw; λp=1,10√(kvE/fy); λr=1,37√(kvE/fy); VRd=(Vpl/γa1)×[1 se λ≤λp; λp/λ se λp<λ≤λr; 1,24(λp/λ)² se λ>λr]", "Alma sem crédito de enrijecedores transversais. Resistência isolada ao cortante.",shear))
        checks.append(ratio_check(prefix+"_shear_horizontal","Cortante horizontal nas mesas",case,c.Vx_kn,horizontal_shear['Vrd_kn'],"kN","ABNT NBR 8800:2024 + Er1:2025, 5.4.3.5; p. 59","Aw=2 bf tf; Vpl=0,60 Aw fy; λ=(bf/2)/tf; kv=1,2; λp=1,10√(kvE/fy); λr=1,37√(kvE/fy); VRd=(Vpl/γa1)×[1 se λ≤λp; λp/λ se λp<λ≤λr; 1,24(λp/λ)² se λ>λr]","Resistência isolada ao cortante horizontal.",horizontal_shear))
        if abs(c.Vx_kn)>1e-9 and abs(c.Vy_kn)>1e-9:
            checks.append(Check(prefix+"_shear_biaxial","Cisalhamento simultâneo em duas direções","PENDENTE",case,source="ABNT NBR 8800:2024 + Er1:2025, 5.5.1.3 e 5.5.2.3(b,d); pp. 61,63",detail="As resistências ao cortante são isoladas. A combinação exige tensões de cisalhamento e estabilidade; não se aplica soma inventada de V/VRd."))
        if abs(c.Mx_knm)>1e-9 and abs(c.My_knm)>1e-9:
            if mx_rd is not None and compact_f and abs(c.N_kn)<1e-9 and abs(c.T_knm)<1e-9:
                eta=abs(c.Mx_knm)/mx_rd+abs(c.My_knm)/my_rd
                checks.append(ratio_check(prefix+"_biaxial","Interação de flexão biaxial sem N",case,eta,1.0,"adimensional","ABNT NBR 8800:2024 + Er1:2025, 5.5.1.2(b), com N=0; p. 61","|Mx|/MRd,x + |My|/MRd,y ≤ 1","Esforços concomitantes da mesma linha.",dict(Mx_knm=c.Mx_knm,My_knm=c.My_knm,MRdx_knm=mx_rd,MRdy_knm=my_rd)))
            else:
                checks.append(Check(prefix+"_biaxial","Interação de flexão biaxial","PENDENTE",case,detail="Depende das resistências qualificadas de ambos os eixos e de N=T=0 no domínio implementado."))
    for i,c in enumerate(p.service if p.mode!="runway" or p.supplement_service_8800 else []):
        detail=f"Combinação: {c.combination_source}. Origem do deslocamento e adequação do limite confirmadas pelo projeto."
        source=c.criterion_source
        vertical_ratio,horizontal_ratio=c.vertical_ratio,c.horizontal_ratio
        if c.criterion_kind in ELS_PRESETS:
            if p.mode!="runway":
                checks.append(Check(f"els_{i}_scope","Critério ELS automático","FORA DO DOMÍNIO",c.name,source=SOURCE_ELS,detail="A linha de Tabela B.1 aplica-se a vigas de rolamento de pontes. Para monovia, cadastrar critério específico documentado.")); continue
            vertical_ratio,horizontal_ratio=ELS_PRESETS[c.criterion_kind]; source=SOURCE_ELS
            if not c.vertical_impact_excluded:
                checks.append(Check(f"els_{i}_vertical","Flecha vertical normativa","PENDENTE",c.name,source=source,detail="A nota f da Tabela B.1 exige ação vertical sem amplificação por impacto. Confirmar a origem do deslocamento antes de comparar."))
            else:
                checks.append(ratio_check(f"els_{i}_vertical","Flecha vertical",c.name,c.vertical_mm,c.span_m*1000/vertical_ratio,"mm",source,"δlim=L/n; η=|δRobot|/δlim",detail,dict(L_m=c.span_m,n=vertical_ratio)))
        else:
            checks.append(ratio_check(f"els_{i}_vertical","Flecha vertical pelo critério informado",c.name,c.vertical_mm,c.span_m*1000/vertical_ratio,"mm",source,"δlim=L/n; η=|δRobot|/δlim",detail,dict(L_m=c.span_m,n=vertical_ratio)))
        checks.append(ratio_check(f"els_{i}_horizontal","Deslocamento horizontal",c.name,c.horizontal_mm,c.span_m*1000/horizontal_ratio,"mm",source,"δlim=L/n; η=|δRobot|/δlim",detail,dict(L_m=c.span_m,n=horizontal_ratio)))
    if not p.service and (p.mode!="runway" or p.supplement_service_8800):
        checks.append(Check("els_missing","Estado limite de serviço","PENDENTE",detail="Cadastrar deslocamentos do Robot, combinação e limites com fonte."))
    checks.extend(runway_local_checks(p))
    checks.extend(monorail_local_checks(p))
    for i,w in enumerate(p.wheels):
        ts=w.service_load_kn*w.eccentricity_mm/1000+w.horizontal_force_kn*w.horizontal_lever_mm/1000
        checks.append(Check(f"wheel_{i}_torsion","Momento torsor de serviço por excentricidade","INFORMATIVO",w.name,demand=ts,unit="kN.m",source="Equilíbrio: Tserv = Pserv e + Hserv z",equation="Tserv [kN.m] = (Pserv [kN] e [mm] + Hserv [kN] z [mm])/1000",detail="Diagnóstico de serviço. Não é somado aos esforços ELU do Robot nem convertido automaticamente em ELU."))
        if abs(w.eccentricity_mm)>1e-9 or abs(w.horizontal_force_kn*w.horizontal_lever_mm)>1e-9:
            warnings.append(f"{w.name}: há aplicação excêntrica; confirmar torção/empenamento no modelo global mesmo quando T ELU informado for zero.")
    if p.mode!="runway" or p.supplement_fatigue_8800:checks.extend(fatigue_checks(p))
    checks.extend(normative_checks(p))
    blockers=[c for c in checks if c.status in ("PENDENTE","FORA DO ESCOPO","FORA DO DOMÍNIO","ENTRADA INVÁLIDA","DADOS INVÁLIDOS")]
    failed=[c for c in checks if c.status in ("NÃO ATENDE", "EXCEDE LIMIAR COMPLEMENTAR")]
    if failed:
        status="NÃO ATENDE NAS VERIFICAÇÕES CALCULADAS"
        summary=f"{len(failed)} verificação(ões) calculada(s) excede(m) o limite; {len(blockers)} pendência(s) ou domínio(s) não coberto(s). Não liberar a viga."
    else:
        status="RESULTADO PARCIAL"
        summary=f"As verificações calculadas atendem aos critérios informados; restam {len(blockers)} pendência(s) ou domínio(s) não coberto(s). Não há aprovação integral da viga."
    coverage={}
    if p.mode=='runway':
        from .coverage_integration import final_scope_assessment
        coverage=final_scope_assessment(p,checks)
        summary=coverage['summary'];status=coverage['status']
        scope=coverage['scope_evidence']
        checks.append(Check('declared_scope','Abrangência do escopo calculado','REGISTRADO' if scope.get('coverage_complete') else 'PENDENTE',detail='; '.join(scope.get('pending',[])+scope.get('errors',[])) or p.coverage_inputs['scope']['evidence_source'],values={'declaracao':p.coverage_inputs['scope'],'cobertura_estabilidade':coverage['stability_coverage']}))
    return Result(True,[],g.to_dict(),checks,warnings,summary,status,coverage)


def calculate(p:Project) -> Result:
    """Public safe boundary: malformed numeric inputs must not crash a session."""
    try:
        result=_calculate(p)
        def representable(value):
            if isinstance(value,float):return math.isfinite(value)
            if isinstance(value,dict):return all(representable(v) for v in value.values())
            if isinstance(value,(list,tuple)):return all(representable(v) for v in value)
            return True
        if not representable(result.to_dict()):
            raise ValueError("non-finite intermediate")
        return result
    except (OverflowError,ZeroDivisionError,ValueError):
        return Result(False,["Cálculo fora da faixa numérica representável. Confira unidades, dimensões, comprimentos destravados e propriedades."],{},[],[],"Corrija os dados antes do cálculo.","DADOS INVÁLIDOS")
