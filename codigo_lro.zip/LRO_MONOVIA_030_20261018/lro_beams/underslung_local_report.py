"""Editable report for the bounded underslung bottom-flange nominal-stress route.

No member certificate, catalogue substitution, hidden action sharing, or solver
lives here. The report exports one current signed result snapshot only.
"""
from __future__ import annotations

from io import BytesIO
import math

from .document_metadata import DOCUMENT_FIELDS, validate_document_metadata
from .underslung_local_model import validate_project

UNKNOWN = 'não informado'
FACE = {'bottom': 'inferior', 'top': 'superior', 'both': 'ambas'}
BASIS = {'unselected': 'base não selecionada',
         'mechanical': 'tensões locais mecânicas sem verificação de resistência',
         'nbr8400': 'comparação nominal elástica NBR 8400',
         'en_service': 'verificação elástica de serviço EN independente'}


def _num(value, places=2):
    if value is None:
        return UNKNOWN
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        raise ValueError('O relatório requer números finitos ou valores não informados.')
    if value == 0:
        value=0.0  # Avoid a visually misleading negative zero after face reversal.
    if value != 0 and abs(value) < 10 ** (-places):
        return f'{value:.2e}'.replace('.', ',')
    return f'{value:.{places}f}'.replace('.', ',')


def _text(value):
    return str(value).strip() if value is not None and str(value).strip() else UNKNOWN


def _yes(value):
    return 'confirmado' if value is True else 'não confirmado'


def _unique(values):
    return list(dict.fromkeys(str(v).strip() for v in values if v is not None and str(v).strip()))


def _verdict(check):
    # Preserve the source's decision/tolerance, including arbitrarily small FAILs.
    if check.get('status') == 'NÃO ATENDE' or check.get('passed') is False:
        return 'NÃO ATENDE'
    if check.get('state') == 'calculated' and (check.get('status') == 'ATENDE' or check.get('passed') is True):
        return 'ATENDE LOCAL'
    utilization = check.get('utilization')
    if isinstance(utilization, (int, float)) and not isinstance(utilization, bool) and utilization > 1:
        return 'NÃO ATENDE'
    if check.get('state') == 'calculated' and utilization is not None:
        return 'ATENDE LOCAL'
    return {'unsupported': 'FORA DO DOMÍNIO', 'failed': 'NÃO ATENDE'}.get(check.get('state'), 'PENDENTE')


def _vertex_component(vertex, component):
    aliases={'x':('sigma_x_mpa','sigma_x_MPa','sigma_x'),
             'y':('sigma_y_mpa','sigma_y_MPa','sigma_y'),
             'tau':('tau_mpa','tau_MPa','tau_xy_mpa','tau')}
    return next((vertex[k] for k in aliases[component] if k in vertex),None)


def _bounds_text(bounds, component):
    value=next((bounds[k] for k in {'x':('sigma_x_mpa','sigma_x'),
               'y':('sigma_y_mpa','sigma_y'),'tau':('tau_mpa','tau_xy_mpa','tau')}[component] if k in bounds),None)
    if not isinstance(value,(list,tuple)) or len(value)!=2:return UNKNOWN
    return _num(value[0])+' a '+_num(value[1])


def _validate_result(project, result):
    validate_project(project)
    if not isinstance(result, dict) or result.get('input_signature') != project.signature():
        raise ValueError('Resultado desatualizado ou sem vínculo com as entradas atuais. Recalcule antes de exportar.')
    if result.get('whole_beam_complete') is not False:
        raise ValueError('O resultado local não pode declarar qualificação integral da viga.')
    for name in ('states', 'checks', 'pending', 'limitations'):
        if not isinstance(result.get(name), list):
            raise ValueError('Resultado local incompleto: ' + name + '.')
    names = {state.name for state in project.states}
    if any(not isinstance(row, dict) or row.get('name') not in names for row in result['states']):
        raise ValueError('Estado do resultado não corresponde ao projeto atual.')
    for check in result['checks']:
        if not isinstance(check, dict):
            raise ValueError('Registro de verificação local inválido.')
        for key in ('demand', 'capacity', 'utilization'):
            if check.get(key) is not None:
                _num(check[key])
    return result


def local_schematic_png(project) -> bytes | None:
    """Native drawing: transverse lower flange plus schematic top suspension.

    The diagram is always marked not to scale. Unknown dimensions are symbols,
    never substituted project inputs. It conveys no bolt design or load split.
    """
    validate_project(project)
    from matplotlib.figure import Figure
    from matplotlib.backends.backend_agg import FigureCanvasAgg
    from matplotlib.patches import Rectangle, Circle, Polygon

    ink, muted, steel, accent = '#172C3C', '#586773', '#DBE4EA', '#9A451F'
    fig = Figure(figsize=(8.3, 3.6), facecolor='white')
    FigureCanvasAgg(fig)
    ax = fig.add_axes([.015, .13, .64, .79])
    ax.set(xlim=(-2.0, 11.5), ylim=(-1.65, 5.7)); ax.axis('off')
    tf = .4
    tw = .46
    n = 2.45
    # Geometry can position the contact only when its actual range is valid.
    if project.bottom_b_mm and project.edge_to_contact_n_mm:
        ratio = project.edge_to_contact_n_mm / project.bottom_b_mm
        if .03 <= ratio <= .44:
            n = 10 * ratio
    ax.add_patch(Rectangle((0, 0), 10, tf, fc=steel, ec=ink, lw=1.3))
    ax.add_patch(Rectangle((5-tw/2, tf), tw, 4.1, fc=steel, ec=ink, lw=1.3))
    ax.add_patch(Rectangle((2.4, 4.5), 5.2, .28, fc=steel, ec=ink, lw=1.3))
    for sign in (-1, 1):
        x = 5 + sign*tw/2
        ax.add_patch(Polygon([(x,tf), (x+sign*.38,tf), (x,tf+.4)], closed=True,
                             fc='#B1BDC5', ec=ink, lw=.8))
    for x, label in ((n, 'P esquerdo'), (10-n, 'P direito')):
        ax.add_patch(Circle((x, 1.05), .65, fc='white', ec=ink, lw=1.4))
        ax.plot([x,x],[.38,1.06],color=muted,ls=':',lw=.8)
        ax.annotate('',xy=(x,.43),xytext=(x,2.4),arrowprops=dict(arrowstyle='-|>',lw=1.5,color=accent))
        ax.text(x,2.53,label,ha='center',fontsize=9,color=accent)
    ax.text(5,5.15,'Seção transversal do caminho',ha='center',fontsize=11,fontweight='bold',color=ink)
    ax.annotate('raiz ou solda\nfora da pista',xy=(5.42,.57),xytext=(6.35,3.65),
                ha='center',fontsize=8.5,color=muted,arrowprops=dict(arrowstyle='-',lw=.8,color=muted))
    ax.annotate('face superior\nda mesa inferior',xy=(9.6,.4),xytext=(10.65,1.4),
                ha='center',fontsize=8,color=ink,arrowprops=dict(arrowstyle='-',lw=.8,color=muted))
    ax.text(5,-.35,'face inferior',ha='center',fontsize=8.5,color=ink)
    def dim(a,b,label,label_xy):
        ax.annotate('',xy=b,xytext=a,arrowprops=dict(arrowstyle='<->',lw=.8,color=muted))
        ax.text(*label_xy,label,ha='center',va='center',fontsize=8.5,color=ink,
                bbox=dict(fc='white',ec='none',pad=.5))
    for x in (0,10):ax.plot([x,x],[-1.4,-.05],lw=.65,color=muted)
    dim((0,-1.25),(10,-1.25),'b = '+(_num(project.bottom_b_mm)+' mm' if project.bottom_b_mm else '?'),(5,-1.25))
    for x in (0,n):ax.plot([x,x],[-.8,-.03],lw=.65,color=muted)
    dim((0,-.7),(n,-.7),'n = '+(_num(project.edge_to_contact_n_mm)+' mm' if project.edge_to_contact_n_mm else '?'),(n/2,-.94))
    ax.plot([-.6,-.6],[0,tf],lw=.8,color=muted)
    for y in (0,tf):ax.plot([-.75,-.45],[y,y],lw=.8,color=muted)
    ax.text(-.9,.2,'t_f\n'+(_num(project.bottom_tf_mm)+' mm' if project.bottom_tf_mm else '?'),
            ha='right',va='center',fontsize=8,color=ink)
    ax.annotate('alma\nt_w = '+(_num(project.web_tw_mm)+' mm' if project.web_tw_mm else '?'),
            xy=(4.8,3.0),xytext=(2.2,3.8),ha='center',fontsize=8.5,color=ink,
            arrowprops=dict(arrowstyle='-',lw=.8,color=muted))

    con = fig.add_axes([.69,.21,.295,.64]); con.axis('off'); con.set(xlim=(0,6),ylim=(0,6))
    con.text(3,5.8,'Conceito de suspensão',ha='center',fontsize=10,fontweight='bold',color=ink)
    con.add_patch(Rectangle((.5,4.55),5,.55,fc='#EAEDEF',ec=ink,lw=1))
    con.text(3,4.83,'viga do piso',ha='center',va='center',fontsize=8.5,color=ink)
    con.add_patch(Rectangle((1.5,4.08),3,.27,fc=steel,ec=ink,lw=1))
    con.add_patch(Rectangle((2.84,1.6),.32,2.48,fc=steel,ec=ink,lw=1))
    con.add_patch(Rectangle((1.5,1.32),3,.28,fc=steel,ec=ink,lw=1))
    for x in (2,4):
        con.plot([x,x],[4.34,4.55],color=accent,lw=2)
        con.add_patch(Circle((x,1.95),.34,fc='white',ec=ink,lw=1))
        con.plot([x,x],[.55,1.6],color=muted,lw=1)
    con.plot([2,4],[.55,.55],color=muted,lw=2)
    con.text(3,.13,'ponte suspensa',ha='center',fontsize=8.5,color=ink)
    con.annotate('mesa superior\nsob a viga do piso',xy=(4.35,4.18),xytext=(5.9,3.25),ha='right',fontsize=8,color=ink,
                 arrowprops=dict(arrowstyle='-',lw=.8,color=muted))
    fig.text(.5,.055,'Esquema sem escala. n parte da borda livre até o centro de contato. Ligações e repartição de cargas não detalhadas.',
             ha='center',fontsize=8,color=muted)
    out=BytesIO();fig.savefig(out,format='png',dpi=180,facecolor='white');return out.getvalue()


def export_local_word(project, result, document_metadata=None) -> bytes:
    """Export a concise editable current local report; missing input stays unknown."""
    _validate_result(project,result)
    metadata=validate_document_metadata({} if document_metadata is None else document_metadata)
    from docx import Document
    from docx.shared import Inches, Pt, RGBColor
    from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn

    doc=Document();sec=doc.sections[0]
    sec.page_width=Inches(8.5);sec.page_height=Inches(11)
    sec.top_margin=sec.bottom_margin=Inches(.65)
    sec.left_margin=sec.right_margin=Inches(.65)
    sec.footer_distance=Inches(.28)
    width=7.2
    for name,size in (('Normal',9),('Title',19),('Subtitle',10),('Heading 1',12),('Heading 2',10)):
        st=doc.styles[name];st.font.name='Arial';st.font.size=Pt(size);st.font.color.rgb=RGBColor(0,0,0)
        st.paragraph_format.space_after=Pt(4)
        if name.startswith('Heading'):st.paragraph_format.space_before=Pt(8)
    doc.styles['Normal'].paragraph_format.line_spacing=1.04
    # Remove theme title rules and style-level borders inherited from Word defaults.
    for node in list(doc.styles.element.iter(qn('w:pBdr'))):node.getparent().remove(node)
    doc.core_properties.title='Verificação local da mesa inferior de caminho suspenso'
    doc.core_properties.subject='Tensões nominais locais e globais externas'
    doc.core_properties.author='LRO'
    doc.core_properties.identifier=result['input_signature']
    def para(text='',bold=False):
        p=doc.add_paragraph();r=p.add_run(text);r.bold=bold;return p
    def heading(text,level=1):return doc.add_heading(text,level)
    def table(headers, rows, ratios=None):
        t=doc.add_table(rows=1,cols=len(headers));t.autofit=False
        fractions=ratios or [1/len(headers)]*len(headers)
        for col,f in zip(t.columns,fractions):col.width=Inches(width*f)
        for cell,label in zip(t.rows[0].cells,headers):cell.text=label
        for values in rows:
            for cell,value in zip(t.add_row().cells,values):cell.text=str(value)
        borders=OxmlElement('w:tblBorders')
        for edge in ('top','left','bottom','right','insideH','insideV'):
            x=OxmlElement('w:'+edge);x.set(qn('w:val'),'single');x.set(qn('w:sz'),'4');x.set(qn('w:color'),'D9D9D9');borders.append(x)
        t._tbl.tblPr.append(borders)
        for ri,row in enumerate(t.rows):
            props=row._tr.get_or_add_trPr();props.append(OxmlElement('w:cantSplit'))
            if ri==0:props.append(OxmlElement('w:tblHeader'))
            for ci,cell in enumerate(row.cells):
                cell.width=Inches(width*fractions[ci]);cell.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
                tc=cell._tc.get_or_add_tcPr();m=OxmlElement('w:tcMar')
                for edge,v in (('top','65'),('bottom','65'),('left','75'),('right','75')):
                    e=OxmlElement('w:'+edge);e.set(qn('w:w'),v);e.set(qn('w:type'),'dxa');m.append(e)
                tc.append(m)
                if ri==0 or ri%2==0:
                    shade=OxmlElement('w:shd');shade.set(qn('w:fill'),'E8EDF1' if ri==0 else 'F7F8F9');tc.append(shade)
                for p in cell.paragraphs:
                    p.paragraph_format.space_after=Pt(0);p.paragraph_format.line_spacing=1.0
                    if ci>0:p.alignment=WD_ALIGN_PARAGRAPH.CENTER
                    for r in p.runs:r.font.size=Pt(8.2);r.bold=ri==0
        spacer=doc.add_paragraph();spacer.paragraph_format.space_after=Pt(3);spacer.paragraph_format.line_spacing=Pt(1);spacer.add_run(' ').font.size=Pt(1)
        return t

    doc.add_paragraph('Verificação local da mesa inferior',style='Title')
    doc.add_paragraph('Caminho de rolamento de ponte suspensa',style='Subtitle')
    if metadata:
        for key,label in DOCUMENT_FIELDS.items():
            if key in metadata:para(label+': '+metadata[key])
    failed=[c for c in result['checks'] if _verdict(c)=='NÃO ATENDE']
    status=_text(result.get('status'))
    if failed and 'NÃO ATENDE' not in status:status+=' · NÃO ATENDE'
    para(status,bold=True)
    para('Este documento verifica somente o efeito nominal local das rodas na mesa inferior, combinado, quando qualificado, com tensões globais externas por estados concomitantes ou limites de envoltória explicitamente qualificados. Não constitui certificado da viga ou do sistema de suspensão.')
    if failed:
        para('Há '+str(len(failed))+' verificação(ões) local(is) não atendida(s); os pontos e valores são preservados na tabela de resultados.')
    elif result.get('local_scope_complete') is not True:
        para('As pendências indicadas impedem concluir integralmente o escopo local selecionado.')
    else:
        para('O escopo local selecionado foi avaliado para os estados registrados, sujeito aos limites declarados ao final.')

    heading('1 Configuração e dados do elemento')
    capacity=_num(project.capacity_tf)+' tf' if project.capacity_tf is not None else UNKNOWN
    para('Ponte suspensa com rodas sobre a face superior da mesa inferior. Capacidade nominal: '+capacity+'. A capacidade de içamento não é a ação de uma roda.')
    if project.equipment_source.strip():para('Identificação e fonte do equipamento: '+project.equipment_source.strip())
    if project.suspension_description.strip():para('Suspensão declarada: '+project.suspension_description.strip())
    image=local_schematic_png(project)
    if image:doc.add_picture(BytesIO(image),width=Inches(width))
    rows=[('Largura inferior b',_num(project.bottom_b_mm),'Espessura inferior t_f',_num(project.bottom_tf_mm)),
          ('Espessura da alma t_w',_num(project.web_tw_mm),'Borda livre ao contato n',_num(project.edge_to_contact_n_mm)),
          ('Raio de raiz r',_num(project.root_radius_mm),'Garganta de solda a',_num(project.weld_throat_mm)),
          ('f_y na espessura real',_num(project.fy_mpa),'f_u na espessura real',_num(project.fu_mpa))]
    table(('Grandeza','mm ou MPa','Grandeza','mm ou MPa'),rows,[.3,.2,.3,.2])
    para('Fabricação: '+{'rolled':'laminada','welded':'soldada','unselected':'não selecionada'}[project.construction]+
         '; seção I reta e mesas paralelas: '+_yes(project.straight_parallel_i_confirmed)+'.')
    para('Material e fonte: '+_text(project.material_source)+'.')
    qualifications=[('supplemental_model_adopted','Modelo suplementar'),
                    ('plane_stress_nominal_confirmed','tensões nominais no plano'),
                    ('base_material_points_confirmed','pontos de material base')]
    if project.fy_mpa is None or project.fu_mpa is None or project.fy_mpa/project.fu_mpa>=.70:
        qualifications.append(('high_ratio_route_confirmed','rota de razão fy/fu elevada'))
    para('; '.join(label+': '+_yes(getattr(project,key)) for key,label in qualifications)+'.')
    if project.notes.strip():para('Observações do projeto: '+project.notes.strip())

    result_states={r['name']:r for r in result['states']}
    all_pending=list(result['pending'])
    for index,state in enumerate(project.states,2):
        sr=result_states.get(state.name,{})
        envelope=getattr(state,'global_input_mode','point_states')=='section_envelope'
        heading(str(index)+' Estado '+state.name)
        para('Base: '+BASIS[state.action_basis]+('. Caso NBR '+state.nbr_case if state.action_basis=='nbr8400' else '')+
             '. Combinação: '+_text(state.combination_id)+'.',bold=True)
        side={'left':'esquerdo','right':'direito','unselected':'não selecionado'}.get(getattr(state,'outstand_side','unselected'),'não selecionado')
        if envelope:
            para('Modo global de envoltória por componentes e sinais. Os vértices de cálculo não representam tensões simultâneas.',bold=True)
            para('Cobertura dos dois lados, duas faces e posições relevantes: '+_yes(state.envelope_coverage_confirmed)+
                 '; ações e geometria abrangendo o domínio: '+_yes(state.envelope_load_geometry_confirmed)+
                 '. Fonte e abrangência: '+_text(state.envelope_scope_source)+'.')
        else:
            para('Lado físico da alma: '+side+'. Os seis pontos e faces deste estado pertencem somente a esse lado.',bold=True)
        para('Ações por roda e fonte: '+_text(state.action_source))
        para('Registro dos fatores de dinâmica, grupo e combinação: '+_text(state.factors_source)+'. '+
             'Fatores aplicados uma única vez: '+_yes(state.factors_already_applied)+
             '; ações qualificadas para a base: '+_yes(state.action_case_qualified)+'.')
        if envelope:
            para('Origem, eixos e sinais dos limites: '+_text(state.coordinate_source)+'.')
        else:
            para('Seção x = '+_num(state.section_x_m)+' m; posição longitudinal do trem = '+_num(state.wheel_translation_m)+
                 ' m. Origem, eixos e sinais: '+_text(state.coordinate_source)+'.')
        table(('Roda no mesmo lado','Ação aplicada individual P em kN','Distância da anterior em mm'),
              [(str(i+1),_num(load), 'início do grupo' if i==0 else _num(state.longitudinal_spacings_mm[i-1]))
               for i,load in enumerate(state.wheel_actions_kn)],[.25,.35,.4])
        cluster=len(state.wheel_actions_kn)>1
        para('Par oposto com ações iguais: '+_yes(state.equal_opposite_wheels_confirmed)+
             ('; grupo fornecido completo, sem roda próxima omitida: ' if cluster else '; estação longitudinal isolada: ')+
             _yes(state.isolated_station_confirmed)+'. '+
             ('Distância à roda ou grupo externo mais próximo: ' if cluster else 'Espaçamento longitudinal mais próximo: ')+
             _num(state.nearest_longitudinal_spacing_mm)+' mm; menor distância de qualquer roda à extremidade física: '+_num(state.distance_to_physical_end_mm)+
             (' mm, limite inferior em todas as posições da envoltória.' if envelope else ' mm.'))
        para('Tensões globais e fonte: '+_text(state.global_source)+
             ('. Mesmo estado da roda: '+_yes(state.same_state_confirmed) if not envelope else '')+
             '; componentes globais pertinentes completas: '+_yes(state.global_effects_complete)+'.')
        if state.action_basis=='en_service':
            para('EN serviço somente: γ_M,ser = '+_num(state.en_gamma_mser)+'. Fonte do coeficiente: '+_text(state.en_gamma_source)+'.')
        if envelope:
            heading('Limites globais assinados da envoltória',2)
            table(('Componente','Mínimo em MPa','Máximo em MPa'),
                  [(label,_num(state.global_component_bounds[key][0]),_num(state.global_component_bounds[key][1]))
                   for key,label in (('sigma_x_mpa','σx global'),('sigma_y_mpa','σy global'),('tau_mpa','τxy global'))],
                  [.4,.3,.3])
        else:
            heading('Tensões globais externas',2)
            table(('Ponto','Face da mesa inferior','σx global MPa','σy global MPa','τxy global MPa'),
                  [(str(r['point']),FACE[r['face']],_num(r['sigma_x_mpa']),_num(r['sigma_y_mpa']),_num(r['tau_mpa']))
                   for r in state.global_points],[.08,.26,.22,.22,.22])
        local={r['point']:r for r in sr.get('local_stresses',[]) if isinstance(r,dict) and 'point' in r}
        heading('Tensões locais mecânicas de referência' if envelope or len(state.wheel_actions_kn)>1 else 'Tensões locais nominais',2)
        local_rows=[]
        for point in range(3):
            row=local.get(point,{})
            for face,sign in (('bottom',1),('top',-1)):
                sx=row.get('sigma_x_mpa');sy=row.get('sigma_y_mpa')
                local_rows.append((str(point),FACE[face],_num(None if sx is None else sign*sx),_num(None if sy is None else sign*sy)))
        table(('Ponto','Face da mesa inferior','σx local MPa','σy local MPa'),local_rows,[.08,.32,.3,.3])
        para('Os sinais locais são os da face inferior; ambas as componentes se invertem juntas na face superior. Tração é positiva. Valores ausentes não representam zero.')
        combined=sr.get('combined_points',[])
        has_bounds=any(r.get('envelope') is True for r in combined)
        if combined and has_bounds:
            para('Para a envoltória, os limites locais adotados são ±Σ|σx,local de cada roda| e ±Σ|σy,local de cada roda|, independentes. A tabela de referência acima não autoriza cancelamento favorável. A soma de intervalos fornece os limites totais abaixo.')
            heading('Intervalos totais usados na comparação',2)
            para('Limites algébricos conservadores, não tensões simultâneas. Cada critério retém seu próprio vértice governante. As pendências de qualificação continuam válidas.')
            table(('Ponto','Face','σx total MPa','σy total MPa','τxy total MPa'),
                  [(str(r.get('point','?')),FACE.get(r.get('face'),'?'),
                    _bounds_text(r.get('total_component_bounds',{}),'x'),
                    _bounds_text(r.get('total_component_bounds',{}),'y'),
                    _bounds_text(r.get('total_component_bounds',{}),'tau')) for r in combined],
                  [.08,.14,.26,.26,.26])
        elif combined and not envelope:
            qualified=all(r.get('state')=='calculated' for r in combined)
            heading('Soma concomitante no ponto material' if qualified else 'Somas algébricas não qualificadas',2)
            if not qualified:para('Diagnóstico numérico somente. A presença de uma soma não confirma concomitância, qualificação do material ou atendimento; as pendências abaixo permanecem impeditivas.')
            def component(row,key):
                if isinstance(row.get('total'),dict):return row['total'].get(key)
                return row.get('total_'+key,row.get(key))
            table(('Ponto','Face','σx total MPa','σy total MPa','τxy total MPa'),
                  [(str(r.get('point','?')),FACE.get(r.get('face'),'?'),_num(component(r,'sigma_x_mpa')),
                    _num(component(r,'sigma_y_mpa')),_num(component(r,'tau_mpa'))) for r in combined],[.08,.23,.23,.23,.23])
        checks=[c for c in result['checks'] if c.get('state_name')==state.name]
        if checks:
            bounded_checks=envelope or has_bounds
            heading('Limites conservadores por critério' if bounded_checks else 'Comparações do estado',2)
            table(('Critério e ponto','Solicitação','Limite','Unidade','Uso','Resultado'),
                  [(str(c.get('title',c.get('id',''))).replace('concomitante','por envoltória' if bounded_checks else 'concomitante')+' · P'+str(c.get('point','?'))+' '+FACE.get(c.get('face'),str(c.get('face',''))),
                    _num(c.get('demand')),_num(c.get('capacity')),c.get('unit',''),_num(c.get('utilization')),_verdict(c)) for c in checks],
                  [.38,.13,.13,.09,.08,.19])
            vertices=[]
            for c in checks:
                vertex=c.get('governing_vertex')
                if isinstance(vertex,dict):
                    vertices.append((str(c.get('title',c.get('id',''))).replace('concomitante','por envoltória')+
                        ' · P'+str(c.get('point','?'))+' '+FACE.get(c.get('face'),str(c.get('face',''))),
                        _num(_vertex_component(vertex,'x')),_num(_vertex_component(vertex,'y')),_num(_vertex_component(vertex,'tau'))))
            if vertices:
                heading('Vértices governantes por critério',2)
                para('Componentes totais em MPa dos vértices matemáticos avaliados. Não representam um tensor simultâneo observado.')
                table(('Critério e ponto','σx do vértice','σy do vértice','τxy do vértice'),vertices,[.46,.18,.18,.18])
            reasons=_unique(c.get('reason') for c in checks if c.get('reason') not in ('Comparação local nominal no estado externo declarado; não qualifica a viga completa.','Comparação local nominal nos estados/limites externos declarados; não qualifica a viga completa.'))
            for reason in reasons:para(reason)
        else:para('Nenhuma comparação de resistência concluída para este estado.')
        all_pending += [state.name+': '+str(p) for p in sr.get('pending',[])]
    orphan_checks=[c for c in result['checks'] if c.get('state_name') not in result_states]
    if orphan_checks:
        heading('Outras verificações registradas')
        for c in orphan_checks:
            para(_text(c.get('title'))+': '+_verdict(c)+'. '+_text(c.get('reason')))
    pending=_unique(all_pending)
    if pending:
        heading('Pendências para o escopo local')
        for text in pending:
            for field,label in (('bottom_b_mm','largura inferior b'),('bottom_tf_mm','espessura inferior t_f'),
                                ('web_tw_mm','espessura da alma t_w'),('edge_to_contact_n_mm','borda livre ao contato n'),
                                ('construction','fabricação'),('root_radius_mm','raio da raiz'),('weld_throat_mm','garganta da solda')):
                text=text.replace(field,label)
            doc.add_paragraph(text,style='List Bullet')

    heading('Método e limites de aplicação')
    if any(getattr(s,'global_input_mode','point_states')=='section_envelope' for s in project.states):
        para('Modo de envoltória: uma excedência representa não atendimento ao limite conservador adotado, não prova de ruptura nem de ocorrência simultânea daquele vértice. Cada componente global pertence ao intervalo assinado informado. As combinações extremas dos intervalos são avaliadas por critério; não são apresentadas como um tensor concomitante real. A validade exige que os limites e as ações locais abranjam ambos os balanços, faces, posições e casos declarados.')
    para('ABNT NBR 10084:2020, 9.1.4 e Tabela 2, com modelo correspondente EN 1993-6:2007 com AC:2009, 5.8: modelo mecânico elástico de tensões nominais da mesa inferior, com geometria, raiz, roda individual, par oposto, espaçamento longitudinal e distância à extremidade dentro do domínio. σx,local = cx P/t_f² e σy,local = cy P/t_f², com P em N. Pontos 0, 1 e 2: transição alma–mesa, linha da roda e borda livre, respectivamente. No modo de pontos concomitantes, cada estado se refere a um único lado físico da alma. A igualdade das rodas opostas não demonstra igualdade das tensões globais; o lado contrário exige estado próprio. A localização física e os eixos devem ser compatíveis com o modelo externo.')
    para('Na rota NBR por pontos, usa-se σcx = σx,global + 0,75 σx,local; a componente local y permanece integral. Combinam-se as componentes com seus sinais, na mesma face, ponto, seção, posição da roda e combinação. Na rota por envoltória, a caixa local simétrica integral contém também a parcela longitudinal reduzida de 0,75, sem crédito de cancelamento favorável. ABNT NBR 8400-2:2019, versão corrigida 2022, 5.2.1.2 e 5.2.1.3: |σx| ≤ σa; |σy| ≤ σa; |τxy| ≤ σa/√3; √(σx² + σy² − σxσy + 3τxy²) ≤ σa. O limite do material e do caso é o do módulo NBR 8400 qualificado, sem reaplicar fatores na ação.')
    if any(s.action_basis=='en_service' for s in project.states):
        para('EN de serviço, quando selecionada: comparação independente de acordo com EN 1993-6, 7.5(3), com limite f_y/γ_M,ser explicitamente informado para esse estado.')
    para('A roda deve chegar com os fatores do caso já aplicados uma única vez. γ_M,ser da rota EN de serviço não participa do limite NBR. A resistência plástica EN 6.7 e suas tensões globais na linha média da mesa não integram esta rota nominal de faces.')
    para('A seleção de estados não demonstra que todos os casos críticos foram fornecidos. Fora deste escopo: resistência global, torção/empenamento, vibração e transmissão de forças na alma e nas mesas; pressão e dano de contato, Hertz, desgaste e esmagamento da borda; raiz, soldas e junções; flambagem local e global, continuidade e contenções; ligação parafusada superior, efeito de alavanca e viga de piso receptora; folgas e deslocamentos. Enrijecedores parciais não recebem contenção integral presumida.')
    para('Fadiga requer histórias locais e globais com sinais no mesmo ponto material, contagem de ciclos e categoria de detalhe qualificada. O efeito local da roda permanece na demanda; não há conversão automática de categoria EN para NBR nem dispensa por aprovação estática.')
    # The adapter's fixed scope text is fully consolidated above; retain custom
    # limitations verbatim rather than silently omitting an added qualification.
    from .underslung_local_adapter import LIMITATIONS
    for limitation in _unique(result['limitations']):
        if limitation not in LIMITATIONS:para(limitation)
    p=sec.footer.paragraphs[0];p.alignment=WD_ALIGN_PARAGRAPH.RIGHT
    p.add_run('Verificação local  |  '+result['input_signature'][:12]+'  |  ')
    field=OxmlElement('w:fldSimple');field.set(qn('w:instr'),'PAGE');p._p.append(field)
    for r in p.runs:r.font.size=Pt(8);r.font.color.rgb=RGBColor.from_string('586773')
    out=BytesIO();doc.save(out);return out.getvalue()
