"""Audit a fixed weld proposal before reusing its geometry for fatigue.

A project signature identifies the input record; it does not prove that an
attached detail respects that input. These guards reproduce geometry contracts,
not resistance formulae, and never resize a detail during fatigue evaluation.
"""
from __future__ import annotations
import math
from .autonomous_local_resistance import _weld_leg_limits

SOURCE='NBR 8800:2024, 6.2.6.2/Tabela 11; geometria fixa proposta pelo dimensionamento ELU.'


def _number(value,label):
    if isinstance(value,bool) or not isinstance(value,(int,float)) or not math.isfinite(value) or value<=0:
        raise ValueError(label+': dimensão positiva e finita obrigatória.')
    return float(value)


def _equal(value,expected,label):
    actual=_number(value,label)
    if not math.isclose(actual,expected,rel_tol=1e-10,abs_tol=1e-9):
        raise ValueError(label+': dimensão não corresponde à geometria fixa do projeto.')
    return actual


def _selected(row,label):
    if not isinstance(row,dict):raise ValueError(label+': detalhe ausente.')
    geometry=row.get('design') or row.get('limiting_design')
    if not isinstance(geometry,dict):raise ValueError(label+': geometria fixa ausente.')
    return geometry


def _limits(project,summary,connection,thin):
    limits=_weld_leg_limits(project,connection,thin)
    for name in ('requested_minimum_leg_mm','normative_minimum_leg_mm','minimum_leg_mm','maximum_leg_mm'):
        value=summary.get(name)
        if isinstance(value,bool) or not isinstance(value,(int,float)) or not math.isfinite(value) or not math.isclose(value,limits[name],rel_tol=0,abs_tol=1e-9):
            raise ValueError(connection+': proveniência do mínimo de filete não corresponde ao projeto atual.')
    if summary.get('requested_minimum_within_geometry') is not True or not limits['requested_minimum_within_geometry']:
        raise ValueError(connection+': mínimo solicitado fora da geometria disponível.')
    return limits


def _leg(geometry,limits,label):
    leg=_number(geometry.get('leg_mm'),label+' perna')
    if leg<limits['minimum_leg_mm']-1e-9 or leg>limits['maximum_leg_mm']+1e-9:
        raise ValueError(label+': perna adotada não respeita mínimo solicitado/normativo ou máximo geométrico.')
    _equal(geometry.get('throat_mm'),leg/math.sqrt(2),label+' garganta')
    return leg


def audit_fixed_weld_geometry(project,detail,kind):
    """Reject stale/relabelled or geometrically inconsistent fixed details."""
    if not isinstance(detail,dict):raise ValueError('Detalhe fixo de solda ausente.')
    s=project.section
    if kind=='flange_web':
        if s.fabrication!='welded':raise ValueError('Perfil laminado não possui filete contínuo alma–mesa.')
        limits=_limits(project,detail,'flange_web',min(s.tw_mm,s.tf_mm,s.bottom_thickness))
        geometry=_selected(detail,'Alma–mesa');_leg(geometry,limits,'Alma–mesa')
        _equal(detail.get('length_each_mm'),project.span_m*1000+project.beam_end_left_mm+project.beam_end_right_mm,'Comprimento alma–mesa')
        if geometry.get('number_of_lines_per_interface')!=2 or detail.get('number_of_lines')!=4:
            raise ValueError('Alma–mesa exige dois filetes iguais em cada interface.')
        return
    if kind!='stiffener':raise ValueError('Família de solda desconhecida.')
    summaries=detail.get('connections')
    if not isinstance(summaries,list) or len(summaries)!=2 or {row.get('connection') for row in summaries if isinstance(row,dict)}!={'alma','mesa'}:
        raise ValueError('Detalhe exige as duas famílias de filetes do enrijecedor.')
    clearance=max(10.,s.root_radius_mm+2.)
    length={'mesa':project.stiffener_outstand_mm-clearance,'alma':s.d_mm-s.tf_mm-s.bottom_thickness-2*clearance}
    thin={'mesa':min(project.stiffener_thickness_mm,s.tf_mm,s.bottom_thickness),'alma':min(project.stiffener_thickness_mm,s.tw_mm)}
    templates={}
    def geometry_check(geometry,connection,limits):
        leg=_leg(geometry,limits,connection)
        ell=length[connection]
        if ell<40 or ell<4*leg:raise ValueError(connection+': comprimento insuficiente para o filete adotado.')
        beta=min(1.,max(.6,1.2-.002*ell/leg)) if connection=='alma' else 1.
        effective=min(ell*beta,180*leg) if connection=='alma' and ell>300*leg else ell*beta
        for name,expected in (('length_each_mm',ell),('beta',beta),('effective_length_each_mm',effective)):
            _equal(geometry.get(name),expected,connection+' '+name)
        if geometry.get('number_of_lines')!=4:raise ValueError('Cada interface do par exige quatro filetes.')
    for summary in summaries:
        connection=summary['connection'];limits=_limits(project,summary,connection,thin[connection])
        geometry=_selected(summary,connection);geometry_check(geometry,connection,limits)
        _equal(summary.get('available_length_each_mm'),length[connection],connection+' comprimento disponível')
        templates[connection]=(geometry,limits)
    if detail.get('station_based') is not True:return
    from .autonomous_stiffener_actions import stiffener_station_geometry
    expected={row['station_id']:row['x_m'] for row in stiffener_station_geometry(project)}
    stations=detail.get('stations')
    if not isinstance(stations,list) or len(stations)!=len(expected) or {row.get('station_id') for row in stations if isinstance(row,dict)}!=set(expected):
        raise ValueError('Geometria fixa não cobre exatamente as estações físicas do projeto.')
    for station in stations:
        sid=station['station_id'];x=station.get('x_m')
        if isinstance(x,bool) or not isinstance(x,(int,float)) or not math.isfinite(x) or not math.isclose(x,expected[sid],rel_tol=0,abs_tol=1e-9):
            raise ValueError('Estação do detalhe fixo deslocada do projeto.')
        faces=station.get('connections')
        if not isinstance(faces,list) or len(faces)!=3 or {row.get('interface_id') for row in faces if isinstance(row,dict)}!={'top','bottom','web'}:
            raise ValueError('Cada estação exige as três interfaces físicas do detalhe fixo.')
        for face in faces:
            connection='alma' if face['interface_id']=='web' else 'mesa'
            if face.get('connection')!=connection:raise ValueError('Família de filete incompatível com a interface física.')
            geometry=_selected(face,sid+'/'+face['interface_id']);template,limits=templates[connection]
            geometry_check(geometry,connection,limits)
            for key in ('leg_mm','throat_mm','length_each_mm','effective_length_each_mm','beta'):
                _equal(geometry.get(key),template[key],'Detalhe uniforme '+sid+'/'+face['interface_id']+' '+key)
