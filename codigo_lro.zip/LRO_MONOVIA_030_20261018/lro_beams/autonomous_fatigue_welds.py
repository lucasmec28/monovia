"""Explicit nominal fatigue checks for prescribed fillets, with fixed geometry.

D.3.1 refers normal capacities to the adjoining detail and uses K0/sqrt(2)
for weld shear. The static weld comparison from Annex B is also retained.
This module neither sizes a weld from fatigue demand nor certifies workmanship.
"""
from __future__ import annotations
import math
from .autonomous_fatigue import (FatigueAbsoluteBounds,evaluate_8400_absolute_envelope,
    normal_interval_ratio_bound,elastic_allowables_autonomous)

SOURCE='ABNT NBR 8400-2:2019, corrigida 20.10.2022: D.3.1.1–D.3.1.3, p.65; Anexo B, pp.44–45; 5.2.2.3/Tabela12, pp.29–30; D.5, pp.62–63'


def evaluate_flange_web_weld_fatigue(bounds:FatigueAbsoluteBounds, *,fy_mpa,fu_mpa,
        thickness_mm,material_grade,fabrication='specified_h6_qc',
        component_group='E8_conservative',group_source='',joint_profile='flange_web'):
    """Whole-kappa sufficient bound for two continuous QC flange/web fillets.

    Longitudinal K0,31 and concentrated transverse K4,41 are the same adjoining
    base detail used by D.3.1.1. Orthogonal throat shear components enter by their
    resultant; its squared bound covers their sum of squares. Static comparison
    uses the lesser of the two yield-scaled transverse-tension limits in Table12,
    even for compression/longitudinal loading. This is an explicit conservative
    choice, not interpolation of a hidden category or repair of Eq.D.3.
    """
    from .stress_8400 import K0_MPA,K4_MPA
    if joint_profile not in ('flange_web','stiffener_load_transfer'):raise ValueError('Perfil físico de junta não implementado.')
    r=evaluate_8400_absolute_envelope(bounds,profile='web_flange_fillet_adjacent_base' if joint_profile=='flange_web' else 'stiffener_load_transfer_fillet_base',
        fy_mpa=fy_mpa,fu_mpa=fu_mpa,thickness_mm=thickness_mm,material_grade=material_grade,
        fabrication=fabrication,component_group=component_group,group_source=group_source)
    r['kind']='autonomous_fatigue_flange_web_weld'
    if r.get('domain_complete') is not True:return r
    group=r['intermediates']['adopted_group'];i=int(group[1:])-1
    elastic=elastic_allowables_autonomous(fy_mpa,fu_mpa,'I')['sigma_a_mpa']
    normal_static=min(.75*fu_mpa,elastic)
    transverse_static=min(113*fy_mpa/240,170*fy_mpa/355,normal_static)
    sx=bounds.sigma_longitudinal_abs_mpa;sy=bounds.sigma_transverse_abs_mpa;t=bounds.shear_abs_mpa
    longitudinal_sw=K0_MPA[i] if joint_profile=='flange_web' else K4_MPA[i]
    cx=min(longitudinal_sw,normal_static);cy=min(K4_MPA[i],transverse_static)
    ct=min(K0_MPA[i]/math.sqrt(2),normal_static/math.sqrt(2),transverse_static)
    interval_results={}
    for key,interval,sw,static in [('longitudinal',bounds.longitudinal_interval_mpa,longitudinal_sw,normal_static),
                                   ('transverse',bounds.transverse_interval_mpa,K4_MPA[i],transverse_static)]:
        if interval is not None:interval_results[key]=normal_interval_ratio_bound(*interval,sigma_w_mpa=sw,static_normal_cap_mpa=static)
    if 'longitudinal' in interval_results:sx=interval_results['longitudinal']['absolute_bound_mpa'];cx=interval_results['longitudinal']['equivalent_capacity_mpa']
    if 'transverse' in interval_results:sy=interval_results['transverse']['absolute_bound_mpa'];cy=interval_results['transverse']['equivalent_capacity_mpa']
    rx,ry,rt=sx/cx,sy/cy,t/ct
    combined=math.sqrt(rx*rx+ry*ry+rx*ry+rt*rt)
    static_equivalent=math.sqrt(sx*sx+sy*sy+sx*sy+2*t*t)
    checks=[]
    for identifier,label,demand,capacity,formula,unit in [
        ('weld_longitudinal','Normal longitudinal na garganta',sx,cx,'|sigma_parallel| <= admissivel K0,31; D.3.1.1','MPa'),
        ('weld_transverse','Normal transversal na garganta',sy,cy,'|sigma_perpendicular| <= admissivel K4,41, com limite Tabela12','MPa'),
        ('weld_shear','Cisalhamento resultante na garganta',t,ct,'tau_resultante <= min[sigma_w(K0)/sqrt(2), limites estaticos]','MPa'),
        ('weld_combined','Interação conservadora de fadiga da garganta',combined,1.,'sqrt(rx²+ry²+rx ry+rt²) <= 1','—'),
        ('weld_static_comparison','Limite estático da comparação da garganta',static_equivalent,transverse_static,
            'sqrt(Sx²+Sy²+Sx Sy+2T²) <= min(113fy/240,170fy/355,sigma_a,0.75fu)','MPa')]:
        exceeded=demand>capacity
        check=dict(id=identifier,name=label,demand=demand,capacity=capacity,utilization=demand/capacity,
            formula=formula,unit=unit,source=SOURCE,status='PENDENTE' if exceeded else 'ATENDE NO DOMÍNIO',
            detail='ENVELOPE EXCEDIDO; verificar critério conservador adotado.' if exceeded else 'ATENDE AO ENVELOPE CONSERVADOR')
        if exceeded:check['exceedance_policy']='requires_specific_assessment'
        checks.append(check)
    r['checks']=checks;r['domain_pending']=[]
    r['criterion_exceedances']=[c['id'] for c in checks if c['utilization']>1]
    r['pending']=['Critério conservador da garganta excedido.'] if r['criterion_exceedances'] else []
    r['status']='RESULTADO PARCIAL — ENVELOPE EXCEDIDO' if r['criterion_exceedances'] else 'ATENDE AO ENVELOPE CONSERVADOR'
    r['intermediates']=dict(adopted_group=group,normal_parallel_detail='K0,31' if joint_profile=='flange_web' else 'K4,4/K4,5',normal_perpendicular_detail='K4,41' if joint_profile=='flange_web' else 'K4,4/K4,5',
        shear_detail='K0/sqrt(2)',capacities_mpa=dict(longitudinal=cx,transverse=cy,shear=ct),
        ratios=dict(longitudinal=rx,transverse=ry,shear=rt),interaction_squared=combined**2,
        static_comparison_mpa=static_equivalent,static_transverse_limit_mpa=transverse_static,
        interval_results=interval_results,source=SOURCE,uses_fabricated_history=False,
        proof='Valores absolutos limitam cada parcela; −uv≤|u||v|; tau_resultante²=tau_parallel²+tau_perpendicular².',
        fixed_geometry_required=True)
    r['limitations']=[
        'Dois filetes contínuos iguais Q.C. por interface; K0,31 longitudinal e K4,41 transversal na ligação alma–mesa.',
        'Metal depositado fyw≥fy e fuw≥fu é exigência de fornecimento/execução, não inspeção declarada.',
        'As duas componentes de cisalhamento da garganta são combinadas pelo módulo resultante; não são uma história com sinal.',
        'O menor limite transversal de tração da Tabela12, escalado por fy, limita conservadoramente toda comparação estática.',
        'A geometria deve ser única para o projeto e proveniente do dimensionamento ELU; o cálculo FAT não a altera.']
    if joint_profile=='stiffener_load_transfer':
        r['limitations'][0]='Par de chapas de enrijecedor, quatro filetes Q.C. por interface; normais sob envelope K4,4/K4,5 da TabelaD.5 p.77.'
        for check in r['checks']:check['formula']=check['formula'].replace('K0,31','K4,4/K4,5').replace('K4,41','K4,4/K4,5')
    return r
