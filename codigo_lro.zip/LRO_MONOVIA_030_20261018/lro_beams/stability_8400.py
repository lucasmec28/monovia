"""Bounded web-panel buckling under NBR 8400-2:2019 §5.4 / Annex C.2.

This is NOT a column-omega approximation to beam lateral-torsional buckling.
Domain: symmetric I-beam, N=0, pure longitudinal bending (psi=-1) plus shear,
qualified four-edge web-panel support, no transverse wheel-patch compression.
For C.2 combined loading, reduce the combined critical stress, never the two
constituent critical stresses before combination. Units: mm and MPa.
"""
from __future__ import annotations
from dataclasses import asdict, dataclass
import math
from typing import Any

from .stress_8400 import _type_errors, _check

STANDARD = "ABNT NBR 8400-2:2019"
CASE_FACTORS_BENDING = {"I": 1.35, "II": 1.25, "III": 1.20}
CASE_FACTORS_UNIFORM = {"I": 1.70, "II": 1.50, "III": 1.35}
C6_240 = ((190.,190.),(200.,194.),(210.,197.),(220.,200.),(230.,202.),
          (240.,204.),(250.,206.),(260.,208.),(280.,212.),(300.,215.),(340.,221.))
C6_355 = ((290.,290.),(300.,294.),(310.,297.),(320.,300.),(330.,303.),
          (340.,306.),(350.,308.),(360.,309.),(380.,312.),(400.,316.),(440.,322.))


@dataclass
class WebPanel8400Input:
    name: str = "Painel de alma 8400"
    load_case: str = "I"
    fy_mpa: float = 0.0
    E_mpa: float = 210000.0
    poisson: float = 0.30
    panel_length_mm: float = 0.0
    panel_height_mm: float = 0.0
    web_thickness_mm: float = 0.0
    sigma_bending_edge_mpa: float = 0.0
    tau_mpa: float = 0.0
    axial_force_kn: float = 0.0
    section_symmetry: str = "unqualified"
    action_basis: str = "unqualified"
    material_source: str = ""
    panel_source: str = ""
    stress_source: str = ""
    action_source: str = ""
    factors_source: str = ""
    restraint_source: str = ""
    method_selection_source: str = ""
    action_case_qualified: bool = False
    factors_already_applied: bool = False
    four_edges_supported_confirmed: bool = False
    support_rigidity_verified: bool = False
    linear_antisymmetric_bending_confirmed: bool = False
    uniform_shear_envelope_confirmed: bool = False
    no_openings_or_longitudinal_stiffeners: bool = False
    no_transverse_compression_confirmed: bool = False
    same_panel_concurrent: bool = False
    annex_c_method_selected: bool = False


def _number(value: Any, *, positive: bool = False) -> bool:
    if type(value) not in (int,float):
        return False
    try:
        return math.isfinite(value) and abs(value)<=1e12 and (value==0 or abs(value)>=1e-12) and (not positive or value>0)
    except (OverflowError,ValueError):
        return False


def plate_coefficients_pure_bending(alpha: float) -> dict[str, Any]:
    """Table C.5 rows 3 and 5, printed p52, with conservative boundary choice."""
    if not _number(alpha,positive=True):
        raise ValueError("alpha=a/b deve ser finito e positivo.")
    short = 15.87 + 1.87 / alpha**2 + 8.6*alpha**2
    boundary = math.isclose(alpha,2/3,rel_tol=0,abs_tol=1e-12)
    if boundary:
        k_sigma=min(23.9,short)
        bending_branch="alpha=2/3: menor limite dos dois ramos, convenção conservadora"
    elif alpha>2/3:
        k_sigma=23.9
        bending_branch="alpha>2/3"
    else:
        k_sigma=short
        bending_branch="alpha<2/3"
    k_tau=5.34+4/alpha**2 if alpha>=1 else 4+5.34/alpha**2
    return {"alpha":alpha,"k_sigma":k_sigma,"k_tau":k_tau,
            "bending_branch":bending_branch,
            "shear_branch":"alpha>=1" if alpha>=1 else "alpha<1"}


def reduce_plate_critical_8400(critical_mpa: float, fy_mpa: float) -> dict[str,Any]:
    """C.2.1 reduced normal/equivalent critical stress, printed pp51–53.

    Exact fy=240/355: Table C.6 above 190/290 MPa, conservative lower tabular
    bracket between rows, never extrapolate beyond 340/440 MPa. Other fy>240:
    the explicitly permitted general expression above sigmaP=.76fy. For lower
    steels only the elastic subdomain is supported.
    """
    if not _number(critical_mpa,positive=True) or not _number(fy_mpa,positive=True):
        raise ValueError("Tensão crítica e fy devem ser finitos positivos em MPa.")
    table = C6_240 if math.isclose(fy_mpa,240.,rel_tol=0,abs_tol=1e-10) else C6_355 if math.isclose(fy_mpa,355.,rel_tol=0,abs_tol=1e-10) else None
    proportional = table[0][0] if table else .76*fy_mpa
    if critical_mpa<=proportional:
        return {"critical_reduced_mpa":critical_mpa,"proportional_limit_mpa":proportional,
                "reduction_factor":1.0,"reduction_branch":"elástico abaixo do limite de proporcionalidade",
                "reduction_formula":"sigma_cr,R = sigma_cr"}
    if table:
        if critical_mpa>table[-1][0]:
            raise ValueError(f"fy={fy_mpa:g} MPa: crítico acima de {table[-1][0]:g} MPa ultrapassa a Tabela C.6 qualificada; não extrapolar.")
        lower=next(row for row in reversed(table) if row[0]<=critical_mpa)
        reduced=lower[1]
        return {"critical_reduced_mpa":reduced,"proportional_limit_mpa":proportional,
                "reduction_factor":reduced/critical_mpa,
                "reduction_branch":"Tabela C.6: menor limite tabulado entre linhas (restrição conservadora)",
                "table_critical_lower_mpa":lower[0],
                "reduction_formula":"sigma_cr,R = valor reduzido da linha inferior da Tabela C.6; sem extrapolação"}
    if fy_mpa<=240:
        raise ValueError("fy<240 MPa acima do limite de proporcionalidade: redução inelástica não qualificada no domínio implementado.")
    # Express the same ratio without squaring large dimensional critical values.
    reduced=fy_mpa/(1+.1836*(fy_mpa/critical_mpa)**2)
    reduced=min(reduced,critical_mpa)
    return {"critical_reduced_mpa":reduced,"proportional_limit_mpa":proportional,
            "reduction_factor":reduced/critical_mpa,
            "reduction_branch":"expressão geral C.2.1 para fy intermediário/superior à Tabela C.6",
            "reduction_formula":"sigma_cr,R = fy*sigma_cr²/(0,1836*fy² + sigma_cr²)"}


def calculate_web_panel_8400(data: WebPanel8400Input) -> dict[str,Any]:
    result={"kind":"web_panel_buckling_8400","source":f"{STANDARD}, 5.4 e Anexo C.2",
            "input_valid":True,"status":"PENDENTE","full_compliance":False,
            "errors":[],"pending":[],"checks":[],"intermediates":{},
            "limitations":[
                "Verificação local de um painel de alma, não estabilidade integral da viga.",
                "Não cobre FLT, flambagem local das abas em balanço, compressão axial, aberturas ou reforços longitudinais.",
                "Compressão transversal/local de roda e sua interação exigem verificação própria; o painel desta avaliação deve estar fora dessa solicitação relevante.",
                "As quatro bordas devem ter apoio efetivo e rigidez/resistência verificadas; a distância entre apoios transversais não é automaticamente o vão da viga.",
                "Tensões e ações dos casos I/II/III fornecidas externamente; sem conversão ELU ou reaplicação de fatores.",
                "Limite elástico, fadiga, ligações, enrijecedores e demais painéis/posições de carga continuam verificações separadas.",
            ]}
    errors=_type_errors(data,WebPanel8400Input)
    if errors:
        result.update(input_valid=False,status="ENTRADA INVÁLIDA",errors=errors)
        return result
    for field in ("fy_mpa","E_mpa","panel_length_mm","panel_height_mm","web_thickness_mm"):
        if getattr(data,field)<=0:
            errors.append(f"{field}: informar valor positivo na unidade indicada.")
    if not 0<data.poisson<.5:
        errors.append("Coeficiente de Poisson deve estar entre 0 e 0,5.")
    if data.load_case not in CASE_FACTORS_BENDING:
        errors.append("Caso de solicitação deve ser I, II ou III.")
    if data.web_thickness_mm>=min(data.panel_height_mm,data.panel_length_mm):
        errors.append("Espessura incompatível com painel de chapa.")
    if errors:
        result.update(input_valid=False,status="ENTRADA INVÁLIDA",errors=errors)
        return result
    result['input']=asdict(data)
    if data.axial_force_kn!=0 or data.section_symmetry!='doubly_symmetric_i':
        result['status']='FORA DO DOMÍNIO'
        result['pending'].append('Domínio restrito à alma de I duplamente simétrico sem força axial N; não aplicar coeficiente de coluna à FLT.')
        return result
    if data.action_basis!='nbr8400_cases':
        result['pending'].append('Exige base própria dos casos I/II/III NBR 10084/8400, sem conversão dos esforços ELU 8800.')
    texts={
        'material_source':'Identificar material, fy, E, Poisson e espessura aplicáveis.',
        'panel_source':'Identificar o painel, a altura livre entre apoios e distância real entre apoios transversais.',
        'stress_source':'Identificar tensões longitudinais nas bordas da alma e cisalhamento concomitante do painel.',
        'action_source':'Identificar o caso/combinação e a posição do equipamento.',
        'factors_source':'Registrar os fatores de ação/dinâmica já incluídos uma vez.',
        'restraint_source':'Registrar cálculo/detalhe da rigidez e resistência dos quatro apoios do painel.',
        'method_selection_source':'Registrar a seleção justificada do método prático do Anexo C pelo responsável.',
    }
    for field,message in texts.items():
        if not getattr(data,field).strip():result['pending'].append(message)
    flags={
        'action_case_qualified':'Qualificar o caso de solicitação I/II/III.',
        'factors_already_applied':'Confirmar fatores aplicáveis já incluídos sem duplicação.',
        'four_edges_supported_confirmed':'Confirmar apoio ao longo das quatro bordas do painel.',
        'support_rigidity_verified':'Verificar rigidez/resistência dos apoios, mesas e enrijecedores que delimitam o painel.',
        'linear_antisymmetric_bending_confirmed':'Confirmar flexão longitudinal pura, linear e antissimétrica na alma (psi=-1, N=0).',
        'uniform_shear_envelope_confirmed':'Qualificar o cisalhamento uniforme/equivalente conservador do painel.',
        'no_openings_or_longitudinal_stiffeners':'Confirmar painel sem aberturas, descontinuidades ou enrijecedor longitudinal.',
        'no_transverse_compression_confirmed':'Há compressão transversal/patch de roda não coberta: confirmar sua ausência relevante neste painel e caso.',
        'same_panel_concurrent':'Confirmar flexão e cisalhamento concomitantes no mesmo painel e posição do equipamento.',
        'annex_c_method_selected':'Confirmar seleção justificada do método prático do Anexo C.',
    }
    for field,message in flags.items():
        if not getattr(data,field):result['pending'].append(message)
    if result['pending']:return result
    sigma=abs(data.sigma_bending_edge_mpa)
    tau=abs(data.tau_mpa)
    if sigma==0 and tau==0:
        result['pending'].append('Tensões informadas nulas: não há solicitação para esta linha, mas os demais casos e painéis ainda precisam ser avaliados.')
        return result
    try:
        coefficients=plate_coefficients_pure_bending(data.panel_length_mm/data.panel_height_mm)
    except (ValueError, OverflowError, ZeroDivisionError) as exc:
        result.update(input_valid=False,status='ENTRADA INVÁLIDA',errors=[f'Relação geométrica fora do domínio computacional: {exc}'])
        return result
    euler=(math.pi**2*data.E_mpa/(12*(1-data.poisson**2)))*(data.web_thickness_mm/data.panel_height_mm)**2
    sigma_critical=coefficients['k_sigma']*euler
    tau_critical=coefficients['k_tau']*euler
    equivalent=math.hypot(sigma,math.sqrt(3)*tau)
    interaction_denominator=math.hypot(sigma/sigma_critical,tau/tau_critical)
    critical_equivalent=equivalent/interaction_denominator
    result['intermediates']={**coefficients,'psi':-1.0 if sigma else None,
        'plate_euler_mpa':euler,'sigma_critical_elastic_mpa':sigma_critical,
        'tau_critical_elastic_mpa':tau_critical,'sigma_edge_signed_mpa':data.sigma_bending_edge_mpa,
        'tau_signed_mpa':data.tau_mpa,'sigma_equivalent_demand_mpa':equivalent,
        'interaction_denominator':interaction_denominator,
        'combined_critical_elastic_mpa':critical_equivalent}
    try:
        reduced=reduce_plate_critical_8400(critical_equivalent,data.fy_mpa)
    except ValueError as exc:
        result['status']='FORA DO DOMÍNIO'
        result['pending'].append(str(exc))
        return result
    nu=(CASE_FACTORS_BENDING if sigma else CASE_FACTORS_UNIFORM)[data.load_case]
    allowable=reduced['critical_reduced_mpa']/nu
    result['intermediates'].update(reduced)
    result['intermediates'].update(nu_v=nu,allowable_equivalent_mpa=allowable,
        safety_basis='Tabela 13, psi=-1' if sigma else 'Cisalhamento puro, psi indefinido: maior nu_v da Tabela 13, restrição conservadora')
    check=_check('web_panel_buckling','Flambagem local do painel de alma: flexão + cisalhamento',
        equivalent,allowable,
        'sigma_cp=sqrt(sigma²+3*tau²); sigma_cr,c=sigma_cp/sqrt[(sigma/sigma_cr)²+(tau/tau_cr)²]; sigma_cp <= sigma_cr,c,R/nu_v',
        '5.4, Tabela 13; Anexo C.2.1/C.2.2, Tabelas C.5/C.6')
    result['checks']=[check]
    result['status']='RESULTADO PARCIAL — NÃO ATENDE' if check['status']=='NÃO ATENDE' else 'RESULTADO PARCIAL'
    return result
