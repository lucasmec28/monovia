"""Read-only help for NBR 8400-1 equipment/dynamic choices.

No catalog classification inference, input mutation, factor implementation or
new mandatory provenance field. The choices remain the existing persisted IDs.
"""
from __future__ import annotations
from .autonomous_actions import _HC, mx_for_equipment_group, DYNAMIC_SOURCE, MX_SOURCE
from .crane_catalog import get_catalog_record

HD_DESCRIPTIONS = {
    'HD1': 'Sem operação em velocidade lenta',
    'HD2': 'Velocidade lenta selecionável pelo operador',
    'HD3': 'Controle mantém velocidade lenta até desprender a carga do solo',
    'HD4': 'Velocidade continuamente variável pelo operador',
    'HD5': 'Pré-tensionamento e variação contínua independentes do operador',
}
_HD_SPEEDS = {
    'HD1': ('Nominal', 'Não fornecida na Tabela 13'),
    'HD2': ('Lenta', 'Nominal'),
    'HD3': ('Lenta', 'Não fornecida na Tabela 13'),
    'HD4': ('Metade da nominal', 'Nominal'),
    'HD5': ('Zero, mantendo Ψ mínimo', 'Metade da nominal'),
}
# Table 3: each row is Q1..Q4, columns U0..U9. Consultation only.
_GROUP_MATRIX = (
    ('Q1', ('A1','A1','A1','A2','A3','A4','A5','A6','A7','A8')),
    ('Q2', ('A1','A1','A2','A3','A4','A5','A6','A7','A8','A8')),
    ('Q3', ('A1','A2','A3','A4','A5','A6','A7','A8','A8','A8')),
    ('Q4', ('A2','A3','A4','A5','A6','A7','A8','A8','A8','A8')),
)
# Selected examples from Table 4, not a classification algorithm.
_APPLICATION_EXAMPLES = (
    ('Oficinas e indústria em geral, com gancho', 'A3 a A5', 'HC2 ou HC3'),
    ('Transporte de metal líquido', 'A6 a A8', 'HC2 ou HC3'),
    ('Carregamento de fundição, com garra ou eletroímã', 'A6 a A8', 'HC3 ou HC4'),
    ('Forjamento', 'A6 a A8', 'HC4'),
    ('Contêineres, com gancho ou spreader', 'A5 a A6', 'HC2'),
)


def _decimal(value, digits=2):
    return f'{value:.{digits}f}'.replace('.', ',')


def hc_label(value):
    if value == 'unselected':
        return 'Não informado · usar Ψ informado'
    if value not in _HC:
        return str(value)
    minimum,beta = _HC[value]
    return f'{value} · Ψ mínimo {_decimal(minimum)}; β₂ {_decimal(beta)} s/m'


def hd_label(value):
    if value == 'unselected':
        return 'Não informado · usar Ψ informado'
    return f'{value} · {HD_DESCRIPTIONS[value]}' if value in HD_DESCRIPTIONS else str(value)


def equipment_group_label(value):
    if value not in tuple(f'A{i}' for i in range(1,9)):
        return str(value)
    return f'{value} · Mx = {_decimal(mx_for_equipment_group(value))}'


def hc_rows():
    return [{'Classe':code,'Ψ mínimo':_decimal(values[0]),'β₂ (s/m)':_decimal(values[1])}
            for code,values in _HC.items()]


def hd_rows():
    return [{'Classe':code,'Como funciona a elevação':meaning,
             'Velocidade usada · casos I e II':_HD_SPEEDS[code][0],
             'Velocidade usada · caso III':_HD_SPEEDS[code][1]}
            for code,meaning in HD_DESCRIPTIONS.items()]


def equipment_group_rows():
    return [{'Grupo':f'A{i}','Mx':_decimal(mx_for_equipment_group(f'A{i}'))} for i in range(1,9)]


def equipment_group_matrix():
    return [{'Espectro de carga':q,**dict(zip((f'U{i}' for i in range(10)),groups))}
            for q,groups in _GROUP_MATRIX]


def catalog_classification_note(project):
    """Explain exact selected reference without supplying any classification."""
    record_id = getattr(getattr(project,'equipment_basis',None),'reference_record_id','')
    if not record_id:
        return {'selected':False,'text':
            'Nenhum registro de catálogo foi vinculado a este projeto. Os catálogos disponíveis não fornecem HC/HD explícitos nem um grupo A único com equivalência NBR 8400 confirmada; as seleções acima permanecem editáveis.'}
    try:
        row = get_catalog_record(record_id)
    except ValueError:
        return {'selected':True,'recognized':False,'text':
            f'A referência importada {record_id} não consta no catálogo desta versão. Suas seleções foram preservadas; nenhuma classificação foi preenchida por inferência.'}
    raw = row.get('duty')
    # Keep a published label intact. A3-A4, DIN H2/B3 and FEM are not a unique
    # NBR equipment group and are never converted into one by this help panel.
    return {'selected':True,'recognized':True,'record_id':row['record_id'],
            'manufacturer':row['manufacturer'],'published_class':raw,
            'source_url':row['source_url'],'source_pdf_page':row['source_pdf_page'],
            'text':f"Referência: {row['manufacturer']} · {row['record_id']}. "
                + (f'Classificação publicada: {raw}. ' if raw else 'HC, HD e grupo A NBR não estão explicitados neste registro. ')
                + 'Não há preenchimento automático de HC/HD nem conversão desta indicação para um grupo A único. As escolhas do projeto são preservadas.'}


def render_dynamic_class_help(st, project):
    """Consultation next to existing selectors; never alters project/session."""
    with st.expander('Ajuda para escolher HC, HD e grupo A'):
        st.write('HC descreve as características dinâmicas da elevação; HD descreve o acionamento e seu controle. O grupo A classifica o equipamento pelo número de utilizações e pelo espectro de cargas. Não são a classe de serviço CMAA nem o grupo E do componente.')
        tabs=st.tabs(['HC · dinâmica','HD · acionamento','A · equipamento','Dados do catálogo'])
        with tabs[0]:
            st.write('O coeficiente de elevação é Ψ = Ψ mínimo + β₂ × velocidade efetiva. A classe HC escolhe os dois coeficientes abaixo; não é deduzida da capacidade nominal.')
            st.table(hc_rows())
            st.caption(DYNAMIC_SOURCE)
            st.write('Exemplos orientadores da Tabela 4, não enquadramento automático:')
            st.table([{'Aplicação':a,'Grupo A orientador':g,'HC orientadora':h} for a,g,h in _APPLICATION_EXAMPLES])
            st.caption('NBR 8400-1:2019, seção 5 e Tabela 4, pp.6–7 e 11. Os exemplos não são obrigatórios; a utilização real e o controle de elevação devem ser considerados.')
        with tabs[1]:
            st.table(hd_rows())
            st.caption('NBR 8400-1:2019, 6.2.2.1 e Tabela 13, pp.20–21. O limite de 1,5 m/s é aplicado depois de escolher a velocidade efetiva. Um traço na Tabela 13 não significa velocidade ou dinâmica nula. HD5 conserva Ψ mínimo.')
            st.caption('A tabela informa a regra do fator; não cria nem ativa um cenário de ensaio. Os cenários aplicáveis são escolhidos separadamente abaixo.')
        with tabs[2]:
            st.write('A1 a A8 são grupos do equipamento. A seleção usa a classe de utilização U0 a U9 e a classe do espectro de cargas Q1 a Q4. O mesmo grupo A pode representar combinações diferentes; não existe correspondência automática com C da CMAA ou E5 de fadiga.')
            st.table(equipment_group_rows())
            st.caption(MX_SOURCE + '. Mx entra nos casos I/II da base 8400/10084, não é reaplicado nas combinações ELU 8800 nem na base de fadiga 8400.')
            st.write('Consulta da Tabela 3: linha = espectro Q; coluna = utilização U.')
            st.table(equipment_group_matrix())
            st.caption('NBR 8400-1:2019, 6.1.2.1 a 6.1.2.4 e Tabela 3, pp.8–10. Este quadro não calcula U ou Q a partir de horas de trabalho nem altera a seleção.')
        with tabs[3]:
            note=catalog_classification_note(project)
            st.write(note['text'])
            if note.get('recognized'):
                st.caption(f"Fonte do registro: {note['source_url']} · página PDF {note['source_pdf_page']}.")
            st.caption('Indicações A3–A4 de outra ficha, DIN H2/B3, FEM ou classe de isolamento do motor não são convertidas para estas escolhas. Uma proposta conservadora separada do assistente de catálogo não é uma classificação confirmada pelo fabricante.')
