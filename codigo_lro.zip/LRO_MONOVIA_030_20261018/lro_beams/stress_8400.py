"""Bounded NBR 8400-2:2019 material-stress and fatigue checks, in MPa.

This module deliberately has no dependency on Project. NBR 8800 factored ELU
forces are NOT admissible inputs to either route, and no action coefficient is
applied here. The caller supplies externally qualified, signed point stresses.

Source qualification: supplied NBR 8400-2:2019 PDF, printed pp. 18, 20, 21,
33, 34, 58–62, 67–69 and 77. Annex D.3/D.5 in that scan are incomplete;
The corrected 20.10.2022 copy was visually checked. Positive kappa has an
optional conservative constant envelope supported by the worked example on
printed p.81; combined fatigue remains unqualified. No NBR 8800 fatigue-category equivalence is used.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, fields
import math
from typing import Any, get_type_hints

STANDARD = "ABNT NBR 8400-2:2019"
NU_E = {"I": 1.50, "II": 1.33, "III": 1.10}

# Table D.1, printed p.60 / source PDF p.68. Values already include 4/3;
# do NOT apply the fatigue safety factor again.
W0_LOW_MPA = (249.1, 224.4, 202.2, 182.1, 164.1, 147.8, 133.2, 120.0)
W0_HIGH_MPA = (298.0, 261.7, 229.8, 201.8, 177.2, 155.6, 136.6, 120.0)
K0_MPA = (361.9, 293.8, 238.4, 193.5, 157.1, 127.5, 103.5, 84.0)
K4_MPA = (116.3, 94.4, 76.6, 62.2, 50.5, 41.0, 33.3, 27.0)
LOW_GRADES = ("S235", "S275", "ASTM A36")
HIGH_GRADES = ("S355", "ASTM A572 GR50")

# Deliberately selected source-qualified details, NOT an arbitrary K0-K4 map.
FATIGUE_DETAILS = {
    "W0": {
        "category": "W0", "source": "Anexo D, Tabela D.4, p.68; D.2",
        "description": "Metal base homogêneo, sem junta, descontinuidade ou entalhe no ponto avaliado.",
        "direction": "unnotched", "weld_quality": "not_applicable",
    },
    "K0_31": {
        "category": "K0", "source": "Anexo D, Tabela D.5, referência K0,31, p.69",
        "description": "Material adjacente a solda de filete Q.C.; tensão normal longitudinal, paralela à solda.",
        "direction": "parallel_to_weld", "weld_quality": "QC",
    },
    "K4_41": {
        "category": "K4", "source": "Anexo D, Tabela D.5, referência K4,41, p.77",
        "description": "Material adjacente a filete Q.C. entre aba e alma; carga concentrada no plano da alma, perpendicular à solda.",
        "direction": "perpendicular_to_weld_in_web_plane", "weld_quality": "QC",
    },
}


@dataclass
class Stress8400Input:
    """One signed, concurrent plane-stress state in base material, excluding joints.

    `factors_source` records all dynamic/action/group factors already present in
    the Robot model or stress calculation; `factors_already_applied` confirms
    they were applied exactly once, according to the selected solicitation case.
    The high-ratio route uses the reference steel 360/510 MPa and sigma_ar=360/nuE
    and requires explicit confirmation because it is not a table-steel preset.
    """
    name: str = "Ponto 8400"
    load_case: str = "I"
    fy_mpa: float = 0.0
    fu_mpa: float = 0.0
    thickness_mm: float = 0.0
    sigma_x_mpa: float = 0.0
    sigma_y_mpa: float = 0.0
    tau_xy_mpa: float = 0.0
    point_id: str = ""
    material_source: str = ""
    stress_source: str = ""
    action_basis: str = "unqualified"
    action_source: str = ""
    factors_source: str = ""
    same_point_concurrent: bool = False
    action_case_qualified: bool = False
    plane_stress_confirmed: bool = False
    base_material_confirmed: bool = False
    factors_already_applied: bool = False
    high_ratio_route_confirmed: bool = False


@dataclass
class Fatigue8400Input:
    """A same-point signed fatigue history, independently supplied from static ELU.

    stress_a/b are its two extremes in ANY order. sigma_max follows §5.6.3:
    the signed extreme with largest absolute value. Equal opposite values give
    kappa=-1 regardless of tie choice. Only one relevant stress component and
    kappa<=0 use the direct supported equations; positive kappa requires an
    explicitly adopted conservative envelope. This is not an S-N/Miner implementation.
    """
    name: str = "Fadiga 8400"
    fy_mpa: float = 0.0
    fu_mpa: float = 0.0
    thickness_mm: float = 0.0
    material_grade: str = ""
    material_source: str = ""
    group: str = ""
    group_source: str = ""
    detail_code: str = ""
    detail_source: str = ""
    load_direction: str = ""
    weld_quality: str = ""
    stress_kind: str = "normal"
    stress_a_mpa: float = 0.0
    stress_b_mpa: float = 0.0
    point_id: str = ""
    stress_source: str = ""
    action_basis: str = "unqualified"
    action_source: str = ""
    factors_source: str = ""
    evaluation_location: str = "base_material"
    positive_kappa_route: str = "unqualified"
    conservative_envelope_selected: bool = False
    same_point_history_confirmed: bool = False
    group_classification_confirmed: bool = False
    construction_detail_confirmed: bool = False
    fabrication_quality_confirmed: bool = False
    single_component_confirmed: bool = False
    case_i_no_Mx_confirmed: bool = False
    buckling_factor_excluded: bool = False
    local_effects_included: bool = False
    high_ratio_route_confirmed: bool = False


def _type_errors(value: Any, cls: type) -> list[str]:
    if not isinstance(value, cls):
        return [f"Entrada deve ser {cls.__name__}."]
    errors = []
    annotations = get_type_hints(cls)
    for field in fields(cls):
        v = getattr(value, field.name)
        expected = annotations[field.name]
        if expected is str and not isinstance(v, str):
            errors.append(f"{field.name}: texto obrigatório.")
        elif expected is bool and type(v) is not bool:
            errors.append(f"{field.name}: booleano obrigatório.")
        elif expected is float:
            if isinstance(v, bool) or not isinstance(v, (int, float)):
                errors.append(f"{field.name}: número finito obrigatório.")
            else:
                try:
                    if not math.isfinite(v) or abs(v) > 1e12 or (v != 0 and abs(v) < 1e-12):
                        errors.append(f"{field.name}: magnitude numérica inválida; confira as unidades.")
                except (OverflowError, ValueError):
                    errors.append(f"{field.name}: número finito obrigatório.")
    return errors


def _material_errors(fy: float, fu: float, thickness: float) -> list[str]:
    errors = []
    if fy <= 0 or fu <= 0 or thickness <= 0:
        errors.append("fy, fu e espessura devem ser positivos, em MPa e mm.")
    if fu < fy:
        errors.append("fu não pode ser inferior a fy.")
    return errors


def _result(kind: str) -> dict[str, Any]:
    return {
        "kind": kind, "source": STANDARD, "input_valid": True,
        "status": "PENDENTE", "full_compliance": False,
        "errors": [], "pending": [], "checks": [], "intermediates": {},
        "limitations": [
            "Resultado parcial por ponto; não aprova integralmente a viga ou suas ligações.",
            "Não verifica estabilidade global/local, tenacidade, fabricação, ligações ou todos os estados de carregamento.",
            "Tensões externas devem incluir efeitos locais, torção e empenamento aplicáveis; nenhum fator é reaplicado.",
        ],
    }


def _invalid(result: dict, errors: list[str]) -> dict:
    result.update(input_valid=False, status="ENTRADA INVÁLIDA", errors=errors)
    return result


def _check(id_: str, name: str, demand: float, capacity: float, formula: str, clause: str) -> dict:
    utilization = demand / capacity
    # Compare dimensional values, with only floating-point roundoff tolerance;
    # never round a displayed utilization before deciding the status.
    ok = demand <= capacity or math.isclose(demand, capacity, rel_tol=1e-12, abs_tol=1e-12)
    return {
        "id": id_, "name": name, "source": f"{STANDARD}, {clause}",
        "formula": formula, "unit": "MPa", "demand": demand,
        "capacity": capacity, "utilization": utilization,
        "status": "ATENDE NO DOMÍNIO" if ok else "NÃO ATENDE",
    }


def _finite_core_number(value: Any) -> bool:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return False
    try:
        return math.isfinite(value) and abs(value) <= 1e12
    except (OverflowError, ValueError):
        return False


def elastic_allowables_8400(fy_mpa: float, fu_mpa: float, load_case: str) -> dict[str, Any]:
    """Numerical core only; qualification/traceability is enforced by the evaluator.

    The unassigned equality fy/fu=0.70 is rejected, not silently assigned to a
    neighboring clause. Unit: MPa. No action factors are applied.
    """
    for value in (fy_mpa, fu_mpa):
        if not _finite_core_number(value) or value <= 0:
            raise ValueError("fy/fu devem ser finitos positivos em MPa.")
    if fu_mpa < fy_mpa or not isinstance(load_case, str) or load_case not in NU_E:
        raise ValueError("Material ou caso de solicitação inválido.")
    ratio = fy_mpa / fu_mpa
    if math.isclose(ratio, 0.70, rel_tol=0, abs_tol=1e-12):
        raise ValueError("fy/fu=0,70: fronteira não atribuída expressamente em 5.2.1.1.1/2; qualificação externa necessária.")
    nu_e = NU_E[load_case]
    if ratio < 0.70:
        normal = fy_mpa / nu_e
        clause = "5.2.1.1.1; Tabela 8"
        formula = "sigma_a = fy / nu_E"
        reference = None
    else:
        reference = 360.0 / nu_e
        normal = (fy_mpa + fu_mpa) / (360.0 + 510.0) * reference
        clause = "5.2.1.1.2; Tabela 8 (aço de referência)"
        formula = "sigma_a = (fy + fu)/(360 + 510) * (360/nu_E)"
    return {
        "fy_fu_ratio": ratio, "nu_e": nu_e, "sigma_a_mpa": normal,
        "tau_a_mpa": normal / math.sqrt(3), "reference_sigma_a_mpa": reference,
        "clause": clause, "formula": formula,
    }


def equivalent_plane_stress(sigma_x_mpa: float, sigma_y_mpa: float, tau_xy_mpa: float) -> float:
    """Signed plane-stress von Mises expression, §5.2.1.3, in MPa."""
    values = (sigma_x_mpa, sigma_y_mpa, tau_xy_mpa)
    if not all(_finite_core_number(v) for v in values):
        raise ValueError("Tensões devem ser números finitos em MPa.")
    # Algebraically identical to sx²+sy²-sx*sy+3*tau², nonnegative by construction.
    return math.sqrt(0.5 * ((sigma_x_mpa - sigma_y_mpa) ** 2 + sigma_x_mpa ** 2 + sigma_y_mpa ** 2) + 3 * tau_xy_mpa ** 2)


def calculate_stress_8400(data: Stress8400Input) -> dict[str, Any]:
    result = _result("elastic_8400")
    errors = _type_errors(data, Stress8400Input)
    if errors:
        return _invalid(result, errors)
    errors = _material_errors(data.fy_mpa, data.fu_mpa, data.thickness_mm)
    if data.load_case not in NU_E:
        errors.append("load_case deve ser I, II ou III.")
    if errors:
        return _invalid(result, errors)
    result["input"] = asdict(data)
    if data.action_basis != "nbr8400_cases":
        result["pending"].append("Usar tensões dos casos I/II/III NBR 10084/8400; entrada ELU 8800 ou base não qualificada não é convertida.")
    required_texts = {
        "point_id": "Identificar o ponto físico e os eixos/sinais.",
        "material_source": "Identificar aço/certificado e propriedades para a espessura informada.",
        "stress_source": "Identificar modelo, barra, posição e cálculo das tensões no ponto.",
        "action_source": "Identificar a combinação e o enquadramento do caso I/II/III.",
        "factors_source": "Registrar fatores dinâmicos/majoração já incluídos nas ações, sem duplicação.",
    }
    for field, explanation in required_texts.items():
        if not getattr(data, field).strip():
            result["pending"].append(explanation)
    required_flags = {
        "same_point_concurrent": "Confirmar tensões concomitantes no mesmo ponto material.",
        "action_case_qualified": "Qualificar o caso de solicitação NBR 10084/8400.",
        "plane_stress_confirmed": "Confirmar estado plano de tensões; componentes fora do plano não cobertas.",
        "base_material_confirmed": "Confirmar avaliação do material base; resistência da junta/solda não coberta por 5.2.1.",
        "factors_already_applied": "Confirmar que os fatores aplicáveis já foram incluídos exatamente uma vez.",
    }
    for field, explanation in required_flags.items():
        if not getattr(data, field):
            result["pending"].append(explanation)
    if data.fy_mpa / data.fu_mpa > 0.70 and not data.high_ratio_route_confirmed:
        result["pending"].append("Qualificar o ramo 5.2.1.1.2 com aço de referência 360/510 MPa e sigma_a,r=360/nu_E; sem preset por Tabela 9/10.")
    try:
        limits = elastic_allowables_8400(data.fy_mpa, data.fu_mpa, data.load_case)
    except ValueError as exc:
        result.update(status="FORA DO DOMÍNIO")
        result["pending"].append(str(exc))
        return result
    if result["pending"]:
        return result
    sx, sy, tau = data.sigma_x_mpa, data.sigma_y_mpa, data.tau_xy_mpa
    eq = equivalent_plane_stress(sx, sy, tau)
    result["intermediates"] = {**limits, "sigma_eq_mpa": eq, "sigma_x_signed_mpa": sx,
                               "sigma_y_signed_mpa": sy, "tau_xy_signed_mpa": tau}
    result["checks"] = [
        _check("sigma_x", "Tensão normal x", abs(sx), limits["sigma_a_mpa"], limits["formula"], limits["clause"]),
        _check("sigma_y", "Tensão normal y", abs(sy), limits["sigma_a_mpa"], limits["formula"], limits["clause"]),
        _check("tau_xy", "Cisalhamento xy", abs(tau), limits["tau_a_mpa"], "tau_a = sigma_a / sqrt(3)", "5.2.1.2"),
        _check("equivalent", "Tensão equivalente concomitante", eq, limits["sigma_a_mpa"],
               "sigma_eq = sqrt(sigma_x² + sigma_y² - sigma_x*sigma_y + 3*tau_xy²)", "5.2.1.3"),
    ]
    result["status"] = "RESULTADO PARCIAL — NÃO ATENDE" if any(c["status"] == "NÃO ATENDE" for c in result["checks"]) else "RESULTADO PARCIAL"
    return result


def fatigue_extremes_8400(stress_a_mpa: float, stress_b_mpa: float) -> dict[str, Any]:
    """§5.6.3/4 extrema, preserving sign and selecting greatest absolute value."""
    values = (stress_a_mpa, stress_b_mpa)
    if not all(_finite_core_number(v) for v in values):
        raise ValueError("Extremos devem ser números finitos em MPa.")
    # The tie convention is deterministic and changes no result at kappa=-1.
    extreme = max(values, key=lambda v: (abs(v), v))
    other = stress_b_mpa if extreme == stress_a_mpa else stress_a_mpa
    return {"sigma_max_signed_mpa": extreme, "sigma_min_signed_mpa": other,
            "absolute_max_mpa": abs(extreme), "kappa": other / extreme if extreme else None,
            "stress_range_mpa": max(values) - min(values),
            "predominance": "compression" if extreme < 0 else "tension" if extreme > 0 else "zero"}


def calculate_fatigue_8400(data: Fatigue8400Input) -> dict[str, Any]:
    result = _result("fatigue_8400")
    result["limitations"].extend([
        "Somente W0 e detalhes K0,31/K4,41 qualificados, material base e uma componente. κ positivo requer opção explícita pelo envelope conservador.",
        "Não verifica cordão de solda, parafuso/rebite, espectro por Miner ou interação de fadiga D.2.3.",
        "A versão corrigida 20/10/2022 mantém ambiguidades em D.3/D.5. O envelope opcional usa D.2.1 e o exemplo D.4.2.2.1(a), p.81, sem declarar correção da equação D.3.",
        "O grupo E1–E8 é do componente e deve incorporar vida/ciclos e espectro conforme NBR 8400-1; não é classe CMAA ou categoria 8800.",
        "Aplicado limite adicional conservador 0,75fu também à compressão; verificação elástica completa do caso I permanece separada.",
    ])
    errors = _type_errors(data, Fatigue8400Input)
    if errors:
        return _invalid(result, errors)
    errors = _material_errors(data.fy_mpa, data.fu_mpa, data.thickness_mm)
    if data.positive_kappa_route not in ("unqualified", "conservative_zero_envelope"):
        errors.append("Rota para κ positivo desconhecida.")
    if data.stress_kind not in ("normal", "shear"):
        errors.append("stress_kind deve ser normal ou shear.")
    if errors:
        return _invalid(result, errors)
    result["input"] = asdict(data)
    ext = fatigue_extremes_8400(data.stress_a_mpa, data.stress_b_mpa)
    result["intermediates"] = ext
    unsupported = []
    if data.detail_code not in FATIGUE_DETAILS:
        unsupported.append("Detalhe não implementado; escolher W0, K0_31 ou K4_41 somente quando a configuração real corresponder à fonte.")
    if data.material_grade not in LOW_GRADES + HIGH_GRADES or not 370 <= data.fu_mpa <= 520:
        unsupported.append("Anexo D qualificado somente para S235/S275/S355/ASTM A36/ASTM A572 GR50 e 370 <= fu <= 520 MPa; equivalências não presumidas.")
    if data.evaluation_location != "base_material":
        unsupported.append("O módulo cobre material base (ou adjacente à solda), não a garganta/metal da solda.")
    if data.group not in tuple(f"E{i}" for i in range(1, 9)):
        unsupported.append("Grupo de componente deve ser E1 a E8, sem conversão automática de classe do equipamento.")
    if data.stress_kind == "shear" and data.detail_code != "W0":
        unsupported.append("Cisalhamento implementado somente em material base W0, conforme D.2.2; soldas exigem D.3.")
    if ext["kappa"] is None:
        unsupported.append("Ambos os extremos são nulos: kappa indefinido; não se conclui a fadiga do componente a partir deste registro.")
    elif ext["kappa"] > 0 and not (data.positive_kappa_route == "conservative_zero_envelope" and data.conservative_envelope_selected):
        unsupported.append("κ > 0: selecionar expressamente o envelope conservador constante, fundamentado em D.2.1 e no exemplo D.4.2.2.1(a). Não há dispensa automática para compressão pulsante.")
    if unsupported:
        result.update(status="FORA DO DOMÍNIO")
        result["pending"].extend(unsupported)
        return result
    detail = FATIGUE_DETAILS[data.detail_code]
    required_texts = {
        "point_id": "Identificar o mesmo ponto físico e a componente do histórico.",
        "material_source": "Registrar aço/certificado e propriedades na espessura informada.",
        "group_source": "Registrar a classificação E do componente, vida e espectro considerados.",
        "detail_source": "Identificar desenho, direção das forças e correspondência com o detalhe normativo.",
        "stress_source": "Identificar a obtenção dos extremos do histórico no mesmo ponto.",
        "action_source": "Identificar os casos/combinações operacionais I usados no histórico.",
        "factors_source": "Registrar tratamento dinâmico e exclusão do coeficiente Mx de majoração (não é momento fletor).",
    }
    for field, explanation in required_texts.items():
        if not getattr(data, field).strip():
            result["pending"].append(explanation)
    if data.action_basis != "nbr8400_fatigue_case_i_no_Mx":
        result["pending"].append("A fadiga requer caso I sem coeficiente de majoração Mx; esforços ELU 8800 e tensões estáticas 8400 não são convertidos.")
    required_flags = {
        "same_point_history_confirmed": "Confirmar extremos do mesmo ponto, componente e histórico operacional.",
        "group_classification_confirmed": "Confirmar classificação do componente por ciclos e espectro.",
        "construction_detail_confirmed": "Confirmar a geometria real e a direção da tensão do detalhe selecionado.",
        "fabrication_quality_confirmed": "Confirmar qualidade de fabricação/inspeção e superfície/entalhe do detalhe selecionado.",
        "single_component_confirmed": "Há interação de fadiga pendente: confirmar uma única componente relevante ou verificar D.2.3 externamente.",
        "case_i_no_Mx_confirmed": "Confirmar caso I sem o coeficiente de majoração Mx, mantendo o tratamento dinâmico aplicável.",
        "buckling_factor_excluded": "Confirmar exclusão do coeficiente de flambagem no histórico de fadiga.",
        "local_effects_included": "Confirmar que os extremos incluem efeitos locais, torção/empenamento e concentrações aplicáveis ao ponto.",
    }
    for field, explanation in required_flags.items():
        if not getattr(data, field):
            result["pending"].append(explanation)
    if data.load_direction != detail["direction"] or data.weld_quality != detail["weld_quality"]:
        result["pending"].append(f"Detalhe {data.detail_code}: requer direção '{detail['direction']}' e qualidade '{detail['weld_quality']}'. {detail['description']}")
    if data.fy_mpa / data.fu_mpa > .70 and not data.high_ratio_route_confirmed:
        result["pending"].append("Qualificar ramo elástico 5.2.1.1.2 para o limite adicional do caso I (aço de referência 360/510 MPa).")
    try:
        elastic = elastic_allowables_8400(data.fy_mpa, data.fu_mpa, "I")
    except ValueError as exc:
        result["pending"].append(str(exc))
        result["status"] = "FORA DO DOMÍNIO"
        return result
    if result["pending"]:
        return result
    index = int(data.group[1:]) - 1
    if detail["category"] == "W0":
        table = W0_LOW_MPA if data.material_grade in LOW_GRADES else W0_HIGH_MPA
    else:
        table = K0_MPA if detail["category"] == "K0" else K4_MPA
    sigma_w = table[index]
    kappa = ext["kappa"]
    if kappa > 0:
        raw_normal = sigma_w * (1.992 if data.stress_kind == "normal" and ext["predominance"] == "compression" else 1.66)
        formula = "Envelope conservador κ>0: sigma_t = 1,66*sigma_w; sigma_c = 1,2*1,66*sigma_w"
        clause = "Anexo D.2.1 e exemplo D.4.2.2.1(a), p.81; envelope conservador declarado"
        result["intermediates"]["positive_kappa_method"] = "Envelope constante conservador; κ real preservado; não avalia D.3 diretamente"
    elif data.stress_kind == "normal" and ext["predominance"] == "compression":
        raw_normal = sigma_w * 2 / (1 - kappa)
        formula = "sigma_c = sigma_w * 2/(1-kappa)"
        clause = "Anexo D.2.1, Eq. D.2; Tabela D.1"
    else:
        raw_normal = sigma_w * 5 / (3 - 2 * kappa)
        formula = "sigma_t = sigma_w * 5/(3-2*kappa)"
        clause = "Anexo D.2.1, Eq. D.1; Tabela D.1"
    capped_normal = min(raw_normal, .75 * data.fu_mpa, elastic["sigma_a_mpa"])
    if data.stress_kind == "shear":
        capacity = capped_normal / math.sqrt(3)
        raw_capacity = raw_normal / math.sqrt(3)
        formula += "; tau_a = sigma_t(W0)/sqrt(3); limites 0,75fu e sigma_a,I antes de dividir por sqrt(3)"
        clause += "; D.2.2"
    else:
        capacity = capped_normal
        raw_capacity = raw_normal
        formula += "; capacidade = min(sigma_fadiga, 0,75fu, sigma_a,I)"
    result["intermediates"].update({
        "sigma_w_mpa": sigma_w, "construction_category": detail["category"],
        "detail_description": detail["description"], "detail_reference": detail["source"],
        "fatigue_raw_capacity_mpa": raw_capacity, "rupture_cap_normal_mpa": .75 * data.fu_mpa,
        "elastic_case_i_sigma_a_mpa": elastic["sigma_a_mpa"],
        "elastic_case_i_tau_a_mpa": elastic["tau_a_mpa"],
        "final_capacity_mpa": capacity, "safety_factor_already_in_table": 4 / 3,
    })
    check_name = "Envelope conservador de fadiga (κ positivo)" if kappa > 0 else "Fadiga da componente no ponto"
    result["checks"] = [_check("fatigue_component", check_name, ext["absolute_max_mpa"], capacity, formula, clause)]
    if kappa > 0:
        result["limitations"].append("Ultrapassar o envelope conservador exige avaliação específica; não demonstra, isoladamente, reprovação pelo critério positivo completo.")
    result["status"] = "RESULTADO PARCIAL — NÃO ATENDE" if result["checks"][0]["status"] == "NÃO ATENDE" else "RESULTADO PARCIAL"
    if kappa > 0:
        check = result["checks"][0]
        if check["status"] == "NÃO ATENDE":
            reason = "Envelope conservador excedido; avaliação específica necessária. Não demonstra reprovação pelo critério positivo completo."
            check["status"] = "PENDENTE"
            check["exceedance_policy"] = "requires_specific_assessment"
            check["detail"] = reason
            result["pending"].append(reason)
            result["status"] = "RESULTADO PARCIAL — ENVELOPE EXCEDIDO"
        else:
            check["detail"] = "ATENDE AO ENVELOPE CONSERVADOR de κ positivo explicitamente adotado."
    return result
