"""Stable engineering snapshots: 4 and 4.0 represent the same input.

Booleans remain distinct from numbers; no rounding of nonintegral values.
"""
import math

def canonical_numbers(value):
    if isinstance(value,bool):return value
    if isinstance(value,float) and math.isfinite(value) and value.is_integer():return int(value)
    if isinstance(value,dict):return {k:canonical_numbers(v) for k,v in value.items()}
    if isinstance(value,(list,tuple)):return [canonical_numbers(v) for v in value]
    return value
