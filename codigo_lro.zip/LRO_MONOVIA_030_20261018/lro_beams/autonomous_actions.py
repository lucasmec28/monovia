"""Source-qualified action factors for an autonomous, bounded runway model.

All inputs are characteristic action COMPONENTS, before factors. The 10084/8400
admissible-stress basis and the complementary 8800 limit-state basis are separate.
This module selects coefficients; it does not establish the physical action
patterns, applicable events, group classification, or completeness of a project.
Sources were checked on images of the supplied primary standards; printed pages
are used below. No equipment or component group is inferred from rated capacity.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, replace
from itertools import product
import math

DYNAMIC_SOURCE = 'ABNT NBR 8400-1:2019, 6.2.2.1, Tabelas 12/13, pp.20–21'
MX_SOURCE = 'ABNT NBR 8400-1:2019, 6.3.4, Tabela 20, p.38'
CASES_SOURCE = 'ABNT NBR 10084:2020, 6.2.2, 7 e 8; ABNT NBR 8400-1:2019, 6.3, pp.36–38'
ULS_SOURCE = 'ABNT NBR 8800:2024/Er1:2025, 4.8.7.2.1 e Tabelas 1/2, pp.20–22'
SLS_SOURCE = 'ABNT NBR 8800:2024/Er1:2025, 4.8.7.3 e Tabela 2, pp.21,23–24'
FATIGUE_8800_SOURCE = 'ABNT NBR 8800:2024/Er1:2025, H.2.1 e Tabela 2, nota d, pp.21,153'

_HC = {'HC1': (1.05, .17), 'HC2': (1.10, .34), 'HC3': (1.15, .51), 'HC4': (1.20, .68)}
_MX = dict(zip(('A1','A2','A3','A4','A5','A6','A7','A8'), (1.,1.02,1.05,1.08,1.11,1.14,1.17,1.20)))
# Separate physical origins. These factors are not applied to signed fragments
# of a single permanent load pattern: the same-origin factor is spatially uniform.
_NORMAL_G = {'steel_or_equipment':1.25, 'precast_or_timber':1.30,
             'cast_in_place_or_permanent_thrust':1.35,
             'industrial_with_in_situ_additions':1.40, 'general_construction':1.50}
_PSI_8800 = {'crane':(1.,.8,.5), 'wind':(.6,.3,0.), 'thermal':(.6,.5,.3)}
_GAMMA_Q = {'crane':1.50, 'wind':1.40, 'thermal':1.20}


def _number(value, name, *, minimum=0., positive=False):
    if isinstance(value,bool) or not isinstance(value,(int,float)):
        raise ValueError(f'{name}: número finito obrigatório.')
    try:
        valid = math.isfinite(value) and abs(value) <= 1e12
    except (OverflowError,ValueError):
        valid = False
    if not valid or (value <= minimum if positive else value < minimum):
        raise ValueError(f'{name}: valor fora do domínio.')
    return float(value)


def _text(value, name, *, required=False):
    if not isinstance(value,str) or len(value)>4000 or (required and not value.strip()):
        raise ValueError(f'{name}: texto válido obrigatório.')
    return value


def _flag(value, name):
    if type(value) is not bool:
        raise ValueError(f'{name}: booleano explícito obrigatório.')
    return value


@dataclass(frozen=True)
class HoistDynamics:
    hoist_class: str = ''
    drive_class: str = ''
    nominal_speed_m_s: float = 0.0
    creep_speed_m_s: float | None = None
    source: str = ''


def compute_hoist_dynamic(data: HoistDynamics, load_case: str = 'I') -> dict:
    """Return ψ and effective speed; Table 13 dashes raise, never imply zero ψ.

    HC and HD are documented physical classifications, not inferred from capacity.
    The 1.5 m/s limit applies to the SELECTED effective speed, not to nominal speed
    before the HD4/HD5 reduction. ψ is applied only to the lifted-load component.
    """
    if not isinstance(data,HoistDynamics):
        raise ValueError('Entrada deve ser HoistDynamics.')
    _text(data.hoist_class,'Classe HC'); _text(data.drive_class,'Classe HD')
    if data.hoist_class not in _HC or data.drive_class not in ('HD1','HD2','HD3','HD4','HD5'):
        raise ValueError('Informe classes HC1–HC4 e HD1–HD5 documentadas.')
    if load_case not in ('I','II','III'):
        raise ValueError('Caso dinâmico deve ser I, II ou III.')
    nominal = _number(data.nominal_speed_m_s,'Velocidade nominal',positive=True)
    creep = data.creep_speed_m_s
    if creep is not None:
        creep = _number(creep,'Velocidade lenta')
        if creep > nominal:
            raise ValueError('Velocidade lenta não pode exceder a nominal.')
    _text(data.source,'Fonte HC/HD',required=True)
    if load_case == 'III':
        if data.drive_class in ('HD1','HD3'):
            raise ValueError('Tabela 13 não fornece vh para esse HD no caso III; qualificar o evento e a dinâmica específica.')
        chosen = nominal * (.5 if data.drive_class=='HD5' else 1.)
        rule = '0,5 vh,max' if data.drive_class=='HD5' else 'vh,max'
    elif data.drive_class in ('HD2','HD3'):
        if creep is None or creep <= 0:
            raise ValueError('HD2/HD3 nos casos I/II exige velocidade lenta positiva documentada.')
        chosen,rule = creep,'vh,CS'
    else:
        chosen = nominal * {'HD1':1.,'HD4':.5,'HD5':0.}[data.drive_class]
        rule = {'HD1':'vh,max','HD4':'0,5 vh,max','HD5':'0'}[data.drive_class]
    effective = min(chosen,1.5)
    psi_min,beta = _HC[data.hoist_class]
    return {'psi':psi_min+beta*effective, 'psi_min':psi_min,'beta2_s_per_m':beta,
            'selected_speed_m_s':chosen,'effective_speed_m_s':effective,'speed_rule':rule,
            'speed_limited':chosen>1.5,'load_case':load_case,'source':DYNAMIC_SOURCE,
            'classification_source':data.source,
            'limitations':('Classificação HC/HD e velocidades requerem dados do equipamento.',
                            'Não cobre juntas defeituosas, queda de carga nem dinâmica específica não qualificada.')}


def mx_for_equipment_group(group: str) -> float:
    _text(group,'Grupo do equipamento')
    if group not in _MX:
        raise ValueError('Grupo do equipamento deve ser A1–A8; grupo E não é grupo A.')
    return _MX[group]


@dataclass(frozen=True)
class ActionFactors:
    code: str
    basis: str
    dead_support: float
    dead_equipment: float
    extra_dead: float
    lifted: float
    transverse: float
    longitudinal: float
    wind: float = 0.0
    thermal: float = 0.0
    event_action: float = 0.0
    source: str = ''
    limitations: tuple[str,...] = ()
    # Deflection-only flag: omitted G1 defines the self-weight reference, not an
    # assertion that self-weight disappears from equilibrium/resistance checks.
    incremental_service: bool = False
    event_source: str = ''

    def to_dict(self):
        return asdict(self)


def factors_10084(load_case: str, *, psi: float, equipment_group: str | None = None,
                  event: str = '', event_source: str = '',
                  test_multiplier: float | None = None, service_case: str = 'I',
                  extra_dead_is_support_self_weight: bool = False) -> ActionFactors:
    """I/II, fatigue_8400, service_10084, or explicitly qualified III event.

    H inputs are the relevant already assembled characteristic horizontal action
    patterns (including acceleration/couple dynamics); they are NOT percentages
    generated from rated capacity. Simultaneity and opposite signs are solved by
    the caller. III event_action is a supplied event-specific vector, not ordinary H.
    """
    _text(load_case,'Caso'); _text(event,'Evento'); _text(event_source,'Fonte do evento')
    psi = _number(psi,'Coeficiente dinâmico',minimum=1.)
    _flag(extra_dead_is_support_self_weight,'G adicional pertence ao peso próprio do suporte')
    if service_case not in ('I','II'):
        raise ValueError('Serviço 10084 exige caso I ou II.')
    if equipment_group is not None:
        mx_for_equipment_group(equipment_group)
    if test_multiplier is not None:
        test_multiplier = _number(test_multiplier,'Coeficiente de ensaio',minimum=1.)
    basic = ('Ações características por origem; não aplicar coeficientes ELU 8800 a este vetor.',
             'O vetor não decide aplicabilidade, sentidos ou simultaneidade das ações.',
             'As componentes H devem conter a dinâmica horizontal aplicável e a distribuição entre rodas.')
    if load_case in ('I','II'):
        if event or test_multiplier is not None:
            raise ValueError('Evento especial não pode ser misturado aos casos I/II.')
        mx = mx_for_equipment_group(equipment_group)
        return ActionFactors(load_case,'nbr10084_8400_admissible',mx,mx,mx,mx*psi,mx,mx,
                             wind=1. if load_case=='II' else 0.,
                             thermal=1. if load_case=='II' else 0.,
                             source=CASES_SOURCE+'; '+MX_SOURCE,limitations=basic)
    if load_case == 'fatigue_8400':
        if event or test_multiplier is not None:
            raise ValueError('Fadiga normal não inclui automaticamente eventos especiais.')
        return ActionFactors(load_case,'nbr8400_fatigue_case_i_without_mx',1.,1.,1.,psi,1.,1.,
                             source='ABNT NBR 8400-2:2019, 5.6; '+CASES_SOURCE,
                             limitations=basic+('Caso I sem Mx e sem coeficiente de flambagem; histórico no mesmo ponto.',))
    if load_case == 'service_10084':
        if event or test_multiplier is not None:
            raise ValueError('Eventos especiais não pertencem à flecha operacional básica.')
        return ActionFactors(load_case+':'+service_case,'nbr10084_service_incremental',0.,1.,
                             0. if extra_dead_is_support_self_weight else 1.,1.,1.,1.,
                             wind=1. if service_case=='II' else 0.,
                             thermal=1. if service_case=='II' else 0.,
                             source='ABNT NBR 10084:2020, 10 e Tabela 4, pp.11–14',
                             limitations=basic+('Somente deslocamento incremental desde a referência sob peso próprio da estrutura de suporte.',
                                                'G adicional só é removido se explicitamente incluído no peso próprio do suporte.',
                                                'Sem ψ e Mx; não reutilizar este vetor para resistência ou tensões de fadiga.',),
                             incremental_service=True)
    if load_case != 'III':
        raise ValueError('Caso 10084 desconhecido.')
    _text(event_source,'Fonte do evento III',required=True)
    if event not in ('out_of_service_wind','bumper','emergency_braking','dynamic_test','skew'):
        raise ValueError('Caso III exige evento físico identificado e ações específicas.')
    if event != 'dynamic_test' and test_multiplier is not None:
        raise ValueError('Coeficiente de ensaio só se aplica ao ensaio dinâmico.')
    if event == 'dynamic_test' and test_multiplier is None:
        raise ValueError('Ensaio dinâmico exige coeficiente p1 qualificado, além de ψ do caso III.')
    wind = 1. if event=='out_of_service_wind' else 0.
    lifted = 0. if event=='out_of_service_wind' else (psi*test_multiplier if event=='dynamic_test' else 1.)
    special = ('Evento III sem Mx; vetor do evento deve incluir reações/ancoragens e efeitos aplicáveis.',
               'Não dispensa estabilidade local/global nem demonstra que outros eventos III foram cobertos.')
    return ActionFactors('III:'+event,'nbr10084_8400_admissible',1.,1.,1.,lifted,0.,0.,
                         wind=wind,event_action=1. if event in ('bumper','emergency_braking','skew') else 0.,
                         source=CASES_SOURCE,limitations=basic+special,event_source=event_source)


def dynamic_test_multiplier(capacity_t: float, psi: float, *, series_produced: bool,
                            qualification_source: str) -> dict:
    """Minimum p for eligible non-series equipment; no inference from capacity alone."""
    capacity = _number(capacity_t,'Capacidade nominal (t)',positive=True)
    psi = _number(psi,'ψ de ensaio',minimum=1.)
    _flag(series_produced,'Equipamento produzido em série')
    _text(qualification_source,'Enquadramento do ensaio',required=True)
    if series_produced:
        raise ValueError('NBR 8400-5 Tabela 1 exclui equipamentos produzidos em série, como talhas.')
    row = (1.2,1.25,1.3) if capacity<=30 else ((1.15,1.2,1.25) if capacity<=100 else (1.1,1.15,1.2))
    index = 0 if psi<=1.2 else (1 if psi<=1.4 else 2)
    return {'test_multiplier':row[index],
            'source':'ABNT NBR 8400-5:2019, 4.1, Tabela 1, p.2',
            'qualification_source':qualification_source,
            'limitations':('Valor mínimo para o enquadramento informado; procedimento conforme NBR 16147.',
                            'A capacidade seleciona apenas esta linha de ensaio, não grupo A/E nem classe HC/HD.')}


def factors_8800(combination: str, *, psi: float, principal: str = 'crane',
                 variables: tuple[str,...] = ('crane',), favorable_dead_support: bool = False,
                 favorable_dead_equipment: bool = False, favorable_extra_dead: bool = False,
                 extra_dead_kind: str = 'steel_or_equipment') -> ActionFactors:
    """Complementary NBR 8800 normal ULS and service/fatigue action vectors.

    Supported variable families: correlated crane Q/H, wind, atmospheric thermal.
    For a family omitted from `variables` its coefficient is zero. Iterate every
    physically possible leading action and applicable presence/absence pattern;
    favorable variables must be omitted, never retained to improve resistance.
    Nominal crane capacity is NOT automatic qualification as a truncated action.
    ψ belongs to the physical lifted Q. H already contains its own characteristic
    dynamics. No Mx is added. 10084 runway deflections use service_10084 instead.
    """
    _text(combination,'Combinação'); _text(principal,'Ação principal'); _text(extra_dead_kind,'Origem de G adicional')
    psi = _number(psi,'Coeficiente físico de elevação',minimum=1.)
    for name,value in (('G suporte favorável',favorable_dead_support),('G equipamento favorável',favorable_dead_equipment),('G adicional favorável',favorable_extra_dead)):
        _flag(value,name)
    if extra_dead_kind not in _NORMAL_G:
        raise ValueError('Classifique a natureza física de G adicional; não há fator genérico implícito.')
    if not isinstance(variables,(tuple,list)) or len(variables)>3 or any(not isinstance(x,str) or x not in _PSI_8800 for x in variables) or len(set(variables))!=len(variables):
        raise ValueError('Famílias variáveis válidas, sem repetição: crane, wind, thermal.')
    if combination not in ('uls_normal','service_rare','service_frequent','service_quasi_permanent','fatigue'):
        raise ValueError('Combinação não implementada; evento especial/excepcional exige qualificação própria.')
    if variables and combination in ('uls_normal','service_rare','service_frequent') and principal not in variables:
        raise ValueError('Ação principal deve constar das ações presentes.')
    if combination=='fatigue' and tuple(variables)!=('crane',):
        raise ValueError('Esta rota de fadiga cobre apenas o histórico operacional da ponte; qualificar outros ciclos separadamente.')
    factors = {k:0. for k in _PSI_8800}
    for kind in variables:
        p0,p1,p2 = _PSI_8800[kind]
        if combination=='uls_normal':factor = _GAMMA_Q[kind]*(1. if kind==principal else p0)
        elif combination=='service_rare':factor = 1. if kind==principal else p1
        elif combination=='service_frequent':factor = p1 if kind==principal else p2
        elif combination=='service_quasi_permanent':factor = p2
        else:factor = 1.
        factors[kind] = factor
    if combination=='uls_normal':
        gs = 1. if favorable_dead_support else 1.25
        ge = 1. if favorable_dead_equipment else 1.25
        gx = 1. if favorable_extra_dead else _NORMAL_G[extra_dead_kind]
        source = ULS_SOURCE
    else:
        gs=ge=gx=1.
        source = FATIGUE_8800_SOURCE if combination=='fatigue' else SLS_SOURCE
    crane = factors['crane']
    return ActionFactors(combination,'nbr8800_'+combination,gs,ge,gx,crane*psi,crane,crane,
                         wind=factors['wind'],thermal=factors['thermal'],source=source,
                         limitations=('Rota complementar NBR 8800; não substituir indiscriminadamente o método 10084/8400.',
                                      'Não contém Mx. Aplicar o fator físico de elevação exatamente uma vez somente a Q.',
                                      'G de mesma origem recebe fator uniforme no padrão inteiro; variar fatores entre combinações, não entre trechos favoráveis/desfavoráveis.',
                                      'Q e H da mesma ocorrência da ponte permanecem correlacionados; ações favoráveis e eventos incompatíveis não são combinados.',
                                      'ELS 8800 geral não substitui a referência e exclusão de impacto prescritas na NBR 10084, seção 10.'))


def variants_8800(*, psi: float, extra_dead_kn_per_m: float = 0.0,
                  extra_dead_kind: str = 'steel_or_equipment',
                  principal: str = 'crane', variables: tuple[str,...] = ('crane',),
                  gamma_g_override: float | None = None,
                  gamma_q_override: float | None = None,
                  override_source: str = '') -> list[ActionFactors]:
    """All independent permanent-origin vertices for normal complementary ULS.

    Support (including its rail), moving equipment, and any present extra G each
    receive ONE uniform factor throughout their complete spatial load pattern.
    Each present origin takes the favorable value 1.0 and unfavorable normative
    value (or the explicitly supplied override). Thus there are four vertices,
    or eight with extra G. Labels do not predetermine which response is favorable.
    No claim is made that a vertex is redundant under N, torsion or interaction.

    gamma_q_override changes only the crane Q/H family, preserving its principal
    or accompanying multiplier and physical psi. Wind/thermal keep their own
    factors. Variables/presence/leading-action permutations remain caller-owned.
    Overrides below the normative value are calculated and explicitly flagged;
    this helper cannot establish normative conformity for those alterations.
    """
    extra = _number(extra_dead_kn_per_m,'G adicional por comprimento')
    _text(override_source,'Fonte dos coeficientes editados')
    for value,name in ((gamma_g_override,'γG informado'),(gamma_q_override,'γQ informado')):
        if value is not None:_number(value,name,positive=True)
    if (gamma_g_override is not None or gamma_q_override is not None) and not override_source.strip():
        raise ValueError('Coeficientes editados exigem origem/justificativa explícita.')
    baseline = factors_8800('uls_normal',psi=psi,principal=principal,
        variables=variables,extra_dead_kind=extra_dead_kind)
    results=[]
    for fs,fe,fx in product((False,True),(False,True),(False,True) if extra>0 else (False,)):
        a=factors_8800('uls_normal',psi=psi,principal=principal,variables=variables,
            favorable_dead_support=fs,favorable_dead_equipment=fe,
            favorable_extra_dead=fx,extra_dead_kind=extra_dead_kind)
        gg=gamma_g_override
        gs=1. if fs else (a.dead_support if gg is None else float(gg))
        ge=1. if fe else (a.dead_equipment if gg is None else float(gg))
        gx=1. if fx else (a.extra_dead if gg is None else float(gg))
        # An absent origin has exactly zero coefficient and no phantom vertex.
        if extra==0:gx=0.
        qratio=1. if gamma_q_override is None else gamma_q_override/_GAMMA_Q['crane']
        labels=f'Gs{"F" if fs else "D"}/Ge{"F" if fe else "D"}/Gx{("F" if fx else "D") if extra>0 else "0"}'
        notes=a.limitations+('Vértice de origens permanentes: '+labels+'; F = 1,0; D = desfavorável.',)
        source=a.source
        if gg is not None or gamma_q_override is not None:
            source+='; coeficientes editados: '+override_source
            notes+=('Coeficientes ELU editados: '+override_source+'; não alteram Mx nem os casos 10084/8400.',)
            limits=[baseline.dead_support,baseline.dead_equipment]
            if extra>0:limits.append(baseline.extra_dead)
            if (gg is not None and any(gg<v for v in limits)) or (gamma_q_override is not None and gamma_q_override<_GAMMA_Q['crane']):
                notes+=('Coeficiente abaixo do valor normal da NBR 8800; conformidade normativa depende de justificativa específica.',)
        results.append(replace(a,code='uls_normal/'+labels,dead_support=gs,dead_equipment=ge,
            extra_dead=gx,lifted=a.lifted*qratio,transverse=a.transverse*qratio,
            longitudinal=a.longitudinal*qratio,source=source,limitations=notes))
    return results


def lifetime_passages(life_years: float, uses_per_year: float,
                      loaded_passages_per_use: float, empty_passages_per_use: float) -> dict:
    """Bookkeeping only: passages are NOT automatically fatigue cycles at a point."""
    vals = [_number(v,n) for v,n in zip((life_years,uses_per_year,loaded_passages_per_use,empty_passages_per_use),
                                       ('Vida útil','Usos/ano','Passagens carregadas/uso','Passagens vazias/uso'))]
    uses = vals[0]*vals[1]
    loaded,empty = uses*vals[2],uses*vals[3]
    if not all(math.isfinite(v) and v<=1e15 for v in (uses,loaded,empty)):
        raise ValueError('Quantidade de passagens fora da faixa numérica.')
    return {'lifetime_uses':uses,'loaded_passages':loaded,'empty_passages':empty,
            'total_passages':loaded+empty,'fatigue_cycles':None,
            'source':'ABNT NBR 8400-1:2019, 6.1.2/6.1.4; ABNT NBR 8800:2024/Er1:2025, H.4(a)',
            'limitations':('Uma passagem pode produzir vários ciclos no mesmo ponto; contar o histórico ou justificar ciclos por passagem.',
                            'Não determina grupo A ou E nem espectro de amplitudes.')}


@dataclass(frozen=True)
class ActionApplicability:
    """Physical location/exposure selections; unknown defaults never exclude III."""
    environment: str = 'unknown'
    bumper_load_path: str = 'unknown'
    test_location: str = 'unknown'
    test_equipment: str = 'unknown'
    test_method: str = 'unknown'
    test_multiplier: float | None = None
    test_capacity_t: float | None = None
    test_dynamic_method: str = 'nominal_speed_envelope'
    test_dynamic_psi: float | None = None
    # Discriminated extension: old methods retain their historical serialized
    # shape; the adopted class envelope has its OWN test speed and provenance.
    test_nominal_speed_m_s: float | None = None
    test_speed_source: str = ''
    test_regular_lifting_adopted: bool = False
    # Complete vertical reaction per wheel in the test, including equipment
    # self-weight AND test dynamics. It REPLACES ordinary G2+ψpQ, never adds to it.
    test_wheel_vertical_kn: tuple[float,...] = ()


APPLICABILITY_OPTIONS = {
    'environment': {'unknown':'Exposição ainda não definida','indoor_sheltered':'Interior protegido do vento direto','outdoor':'Exposto ao vento'},
    'bumper_load_path': {'unknown':'Caminho da reação do batente desconhecido','this_beam':'Batente transmite reação a esta viga','independent_support':'Batente em suporte independente desta viga'},
    'test_location': {'unknown':'Local do ensaio ainda não definido','on_this_runway':'Ensaio realizado sobre este caminho','outside_this_segment':'Ensaio não carrega este trecho'},
    'test_equipment': {'unknown':'Elegibilidade do equipamento não definida','nbr8400_5_non_series':'Ponte não seriada no escopo da NBR 8400-5','series_or_other':'Equipamento de série ou outro enquadramento'},
    'test_method': {'unknown':'Método do carregamento de ensaio não definido','factor_table':'p pela Tabela 1, com capacidade nominal','factor_explicit':'p informado para este ensaio','factor_1_30_envelope':'p = 1,30 · envelope dos mínimos da Tabela 1','wheel_vertical':'Reação vertical total de ensaio informada por roda'},
    'test_dynamic_method': {'class_nominal_speed_envelope':'Envelope adotado HC1–HC4 na velocidade nominal máxima de ensaio','nominal_speed_envelope':'Envelope pela velocidade nominal máxima de ensaio','table_13_case_iii':'Velocidade efetiva da Tabela 13, caso III','explicit_psi':'Ψ específico do ensaio informado'},
}

TEST_CLASS_ENVELOPE_METHOD='class_nominal_speed_envelope'
TEST_CLASS_ENVELOPE_FIELDS={'test_nominal_speed_m_s','test_speed_source','test_regular_lifting_adopted'}


def action_applicability_dict(data):
    """Canonical additive shape; untouched old projects retain exact signatures."""
    result=asdict(data)
    if (data.test_dynamic_method!=TEST_CLASS_ENVELOPE_METHOD and
            data.test_nominal_speed_m_s is None and data.test_speed_source=='' and
            data.test_regular_lifting_adopted is False):
        for name in TEST_CLASS_ENVELOPE_FIELDS:result.pop(name)
    return result


def test_envelope_summary(data):
    """Human-readable provenance, independent of a computed approval."""
    if data.test_dynamic_method!=TEST_CLASS_ENVELOPE_METHOD:return []
    speed='não definida' if data.test_nominal_speed_m_s is None else f'{data.test_nominal_speed_m_s:.6g} m/s'.replace('.',',')
    return [('Dinâmica do ensaio',APPLICABILITY_OPTIONS['test_dynamic_method'][TEST_CLASS_ENVELOPE_METHOD]),
            ('Capacidade nominal do ensaio','não definida' if data.test_capacity_t is None else f'{data.test_capacity_t:g} t métricas; sobrecarga p tratada separadamente'.replace('.',',')),
            ('Velocidade nominal do ensaio',speed+'; '+(data.test_speed_source or 'fonte pendente')),
            ('Escopo da hipótese de ensaio','Elevação regular adotada; HC/HD físicos não confirmados. Local, elegibilidade não seriada e sobrecarga permanecem próprios do ensaio.' if data.test_regular_lifting_adopted else 'Adoção da elevação regular ainda pendente.')]


def action_applicability_errors(data: ActionApplicability) -> list[str]:
    if not isinstance(data,ActionApplicability):return ['Entrada deve ser ActionApplicability.']
    errors=[]
    for name,options in APPLICABILITY_OPTIONS.items():
        value=getattr(data,name)
        if not isinstance(value,str) or value not in options:errors.append(name+': seleção física inválida.')
    for name in ('test_multiplier','test_capacity_t','test_dynamic_psi','test_nominal_speed_m_s'):
        value=getattr(data,name)
        if value is not None:
            try:_number(value,name,positive=True)
            except ValueError as exc:errors.append(str(exc))
    if not isinstance(data.test_speed_source,str) or len(data.test_speed_source)>3000:errors.append('Fonte da velocidade de ensaio deve ser texto de até 3000 caracteres.')
    if type(data.test_regular_lifting_adopted) is not bool:errors.append('Adoção da elevação regular deve ser explícita e booleana.')
    if not isinstance(data.test_wheel_vertical_kn,(tuple,list)) or len(data.test_wheel_vertical_kn)>20:
        errors.append('Informe no máximo vinte reações de ensaio.')
    else:
        for value in data.test_wheel_vertical_kn:
            try:_number(value,'Reação vertical de ensaio')
            except ValueError as exc:errors.append(str(exc))
    return errors


def compute_test_dynamic(data: HoistDynamics, method: str='nominal_speed_envelope',
                         explicit_psi: float | None=None) -> dict:
    """Test-specific dynamics, distinct from the operational override.

    8400-5 4.1 requires nominal maximum speeds. The named nominal-speed envelope
    uses ψmin+β*min(vnom,1.5); each applicable Table13 effective speed is <=vnom.
    It does not silently replace Table13 dashes or claim a new normative row.
    """
    if method not in APPLICABILITY_OPTIONS['test_dynamic_method']:raise ValueError('Método dinâmico de ensaio desconhecido.')
    if method=='table_13_case_iii':
        result=compute_hoist_dynamic(data,'III');result['conservative_envelope']=False;return result
    if not isinstance(data,HoistDynamics):raise ValueError('Dados de elevação necessários.')
    if method=='explicit_psi':
        psi=_number(explicit_psi,'Ψ específico do ensaio',minimum=1.)
        result={'psi':psi,'source':'Coeficiente específico do ensaio informado; NBR 8400-1, 6.2.2.1 admite avaliação dinâmica',
                'conservative_envelope':False,'method':method,'pending':[]}
        # When the ordinary table gives a definite III minimum, disclose a
        # reduction. A user's operational override is never copied here.
        try:
            reference=compute_hoist_dynamic(data,'III')['psi']
            result['table_reference_psi']=reference
            if psi<reference:result['pending'].append('Ψ de ensaio informado abaixo do valor da Tabela 13; avaliação dinâmica específica necessária.')
        except ValueError:
            result['pending'].append('Ψ de ensaio informado sem comparação normativa disponível; registrar avaliação dinâmica específica antes de afirmar conformidade.')
        return result
    if method=='class_nominal_speed_envelope':
        speed=_number(data.nominal_speed_m_s,'Velocidade nominal máxima de ensaio',positive=True)
        _text(data.source,'Fonte da velocidade e enquadramento do ensaio regular',required=True)
        effective=min(speed,1.5)
        candidates={hc:minimum+beta*effective for hc,(minimum,beta) in _HC.items()}
        maximizing=max(candidates,key=candidates.get)
        return {'psi':candidates[maximizing],'effective_speed_m_s':effective,
                'nominal_speed_m_s':speed,'conservative_envelope':True,'method':method,
                'adoption_kind':'engineering_class_and_speed_envelope',
                'class_domain':tuple(_HC),'candidate_psi':candidates,
                'maximizing_class':maximizing,'physical_hc_confirmed':False,
                'input_hoist_class':data.hoist_class,'input_drive_class':data.drive_class,
                'qualification_source':data.source,
                'source':'ABNT NBR 8400-5:2019, 4.1; NBR 8400-1:2019, 6.2.2.1, Tabelas 12/13; envoltória de engenharia adotada',
                'formula':'max_HC1..HC4[ψmin(HC) + β2(HC) min(vnom, 1,5 m/s)]',
                'limitations':('HC4 maximiza a envoltória; não é classificação física confirmada.',
                    'Somente dinâmica regular de elevação com velocidade nominal máxima documentada; traços HD1/HD3 do caso III não são preenchidos.',
                    'Não transfere Ψ operacional nem cobre eventos especiais, juntas defeituosas ou carga presa.',
                    'Não dispensa elegibilidade não seriada, localização real do ensaio, vento ou batente.')}
    _text(data.hoist_class,'Classe HC')
    if data.hoist_class not in _HC:raise ValueError('Envelope nominal de ensaio exige classe HC física.')
    speed=_number(data.nominal_speed_m_s,'Velocidade nominal máxima de ensaio',positive=True)
    _text(data.source,'Fonte dos dados de elevação',required=True)
    minimum,beta=_HC[data.hoist_class]
    return {'psi':minimum+beta*min(speed,1.5),'effective_speed_m_s':min(speed,1.5),
            'nominal_speed_m_s':speed,'conservative_envelope':True,'method':method,
            'source':'ABNT NBR 8400-5:2019, 4.1; NBR 8400-1:2019, 6.2.2.1, Tabelas 12/13',
            'formula':'ψensaio,envelope = ψmin(HC) + β2(HC) min(vnom, 1,5 m/s)',
            'limitations':('Envelope por velocidade nominal, não preenchimento dos traços de HD1/HD3 na linha III.',
                           'Não usa automaticamente Ψ informado para operação normal; limita-se à dinâmica regular de elevação.')}


def evaluate_action_applicability(data: ActionApplicability, *, dynamics: HoistDynamics | None=None,
                                  wheel_count: int | None=None) -> dict:
    """Identify physically applicable special events and assemble test case IIIc.

    Returns test_case={factors:ActionFactors, wheel_vertical_override_kn:tuple|None,
    conservative_envelope:bool, ...}. Overrides are COMPLETE wheel reactions and
    must replace G2/Q; no generic operational H is added to IIIc. The function
    does not verify wind/bumpers or classify all actions of a complete project.
    """
    result={'input_valid':True,'errors':[],'pending':[],'requirements':[],
            'test_case':None,'special_events_ready':False,'full_compliance':False,
            'source':'ABNT NBR 10084:2020, 8.3(a–c); NBR 8400-1:2019, 6.2.3.5/6.3.3'}
    errors=action_applicability_errors(data)
    if wheel_count is not None and (type(wheel_count) is not int or not 1<=wheel_count<=20):errors.append('Número de rodas inválido.')
    if errors:result.update(input_valid=False,errors=errors);return result
    result['physical_inputs']=action_applicability_dict(data)
    def record(code,applicable,reason):
        result['requirements'].append({'code':code,'applicable':applicable,'reason':reason})
    if data.environment=='unknown':
        result['pending'].append('Definir exposição ao vento; desconhecido não significa vento ausente.');record('III_out_of_service_wind',None,'Exposição desconhecida.')
    elif data.environment=='outdoor':
        record('III_out_of_service_wind',True,'Equipamento/caminho exposto ao vento máximo fora de serviço.')
        result['pending'].append('Calcular caso II e III de vento, incluindo ancoragens; vetor climático não é produzido por este helper.')
    else:record('III_out_of_service_wind',False,'Interior protegido: sem vento direto nesta viga; deslocamentos da estrutura de apoio permanecem fora desta exclusão.')
    if data.bumper_load_path=='unknown':
        record('III_bumper',None,'Transmissão da reação do batente desconhecida.');result['pending'].append('Definir o caminho físico da reação do batente.')
    elif data.bumper_load_path=='this_beam':
        record('III_bumper',True,'A colisão transmite ação a esta viga.');result['pending'].append('Fornecer/calcular vetor de impacto e distribuição do batente; H operacional não o substitui.')
    else:record('III_bumper',False,'Suporte do batente independente: esta viga não recebe sua reação, inclusive pelo caminho de fixações.')
    if data.test_location=='unknown':
        record('III_dynamic_test',None,'Local do ensaio desconhecido.');result['pending'].append('Definir se o ensaio carrega este trecho.')
    elif data.test_location=='outside_this_segment':
        record('III_dynamic_test',False,'O ensaio não carrega este trecho; esta exclusão não dispensa ensaio/verificação nos trechos efetivamente carregados.')
    else:
        record('III_dynamic_test',True,'Ensaio dinâmico sobre este caminho; NBR 10084, 8.3(c).')
        try:
            if data.test_method=='wheel_vertical':
                if wheel_count is None or len(data.test_wheel_vertical_kn)!=wheel_count or not any(data.test_wheel_vertical_kn):
                    raise ValueError('Informe reação vertical total dinâmica de ensaio para cada roda do trem.')
                factors=ActionFactors('III:dynamic_test','nbr10084_8400_admissible',1.,0.,1.,0.,0.,0.,
                    source=result['source']+'; reações totais de ensaio informadas por roda',
                    limitations=('Reações informadas já incluem G2 e efeitos dinâmicos/sobrecarga do ensaio; substituem, não somam, as rodas operacionais.',))
                result['test_case']={'factors':factors,'wheel_vertical_override_kn':tuple(data.test_wheel_vertical_kn),
                                     'conservative_envelope':False,'method':'wheel_vertical'}
            else:
                if data.test_equipment!='nbr8400_5_non_series':
                    raise ValueError('Fator p da NBR 8400-5 exige equipamento elegível não produzido em série; não inferir elegibilidade.')
                if data.test_method not in ('factor_table','factor_explicit','factor_1_30_envelope'):
                    raise ValueError('Selecionar forma de determinar o carregamento de ensaio.')
                test_dynamics=dynamics
                if data.test_dynamic_method==TEST_CLASS_ENVELOPE_METHOD:
                    if data.test_regular_lifting_adopted is not True:
                        raise ValueError('Adote explicitamente o escopo de elevação regular para a envoltória de classes do ensaio.')
                    _text(data.test_speed_source,'Fonte da velocidade nominal máxima do ensaio',required=True)
                    speed=_number(data.test_nominal_speed_m_s,'Velocidade nominal máxima própria do ensaio',positive=True)
                    if not isinstance(dynamics,HoistDynamics):raise ValueError('Dados de elevação necessários.')
                    test_dynamics=replace(dynamics,nominal_speed_m_s=speed,source=data.test_speed_source)
                dynamic=compute_test_dynamic(test_dynamics,data.test_dynamic_method,data.test_dynamic_psi)
                result['pending'].extend(dynamic.get('pending',[]))
                psi=dynamic['psi'];p=None
                if data.test_method=='factor_table':
                    if data.test_capacity_t is None:raise ValueError('Tabela 1 requer capacidade nominal do equipamento; soma de rodas em um caminho não a determina.')
                    p=dynamic_test_multiplier(data.test_capacity_t,psi,series_produced=False,qualification_source='Enquadramento físico informado')['test_multiplier']
                elif data.test_method=='factor_1_30_envelope':p=1.30
                else:
                    p=_number(data.test_multiplier,'p de ensaio',minimum=1.)
                    minimum=1.30 if data.test_capacity_t is None else dynamic_test_multiplier(data.test_capacity_t,psi,series_produced=False,qualification_source='Enquadramento físico informado')['test_multiplier']
                    if p<minimum:
                        result['pending'].append('p informado abaixo do mínimo aplicável ou do envelope sem capacidade; não afirmar conformidade sem qualificação específica.')
                factors=factors_10084('III',psi=psi,event='dynamic_test',test_multiplier=p,
                    event_source='Ensaio sobre este caminho; '+dynamic['source']+'; NBR 8400-5, 4.1/Tabela 1')
                result['test_case']={'factors':factors,'wheel_vertical_override_kn':None,'psi':psi,'test_multiplier':p,
                    'dynamic':dynamic,'conservative_envelope':dynamic.get('conservative_envelope',False) or data.test_method=='factor_1_30_envelope',
                    'method':data.test_method}
        except ValueError as exc:result['pending'].append(str(exc))
    result['special_events_ready']=not result['pending']
    result['limitations']=['Aplicabilidade física declarada por trecho; não é dispensa genérica de caso III.',
        'Enviesamento e frenagem de emergência especiais, quando pertinentes ao equipamento, exigem seus próprios vetores e critérios.',
        'Se um carregamento de ensaio for envelope conservador, ultrapassá-lo requer avaliação específica antes de concluir falha real.']
    return result
