"""Catálogo rastreável: W Gerdau e dimensões de soldados CS/CVS/VS.

Dados históricos: a seleção não confirma aço, disponibilidade ou aprovação.
As funções devolvem cópias para que a interface não altere o catálogo carregado.
"""
from __future__ import annotations
from copy import deepcopy
from functools import lru_cache
from pathlib import Path
from collections.abc import Mapping
import hashlib
import json
from .model import Section

CATALOG_FAMILIES = ("W", "CS", "CVS", "VS")
FAMILY_LABELS = {"W": "W Gerdau (laminado)", "CS": "CS (soldado)",
                 "CVS": "CVS (soldado)", "VS": "VS (soldado)"}
_DATA = Path(__file__).with_name("data")


def catalog_manifest() -> dict:
    return json.loads((_DATA / "catalog_manifest.json").read_text(encoding="utf-8"))


@lru_cache(maxsize=1)
def _load() -> tuple[dict, ...]:
    raw = (_DATA / "profiles.json").read_bytes()
    if hashlib.sha256(raw).hexdigest() != catalog_manifest()["data_sha256"]:
        raise ValueError("Integridade do catálogo inválida: confira o pacote de dados.")
    records = json.loads(raw)
    if len({r["id"] for r in records}) != len(records):
        raise ValueError("Identificadores duplicados no catálogo.")
    return tuple(records)


def list_profiles(family: str | None = None) -> list[dict]:
    """Devolve registros completos; family é W, CS, CVS ou VS."""
    if family is not None:
        family = family.strip().upper()
        if family not in CATALOG_FAMILIES:
            raise ValueError(f"Família desconhecida: {family}")
    return deepcopy([r for r in _load() if family is None or r["family"] == family])


def get_profile(identifier: str) -> dict:
    """Resolve ID/nome exato. Nomes repetidos de VS incluem bf e tf."""
    matches = [r for r in _load() if identifier in (r["id"], r["name"])]
    if len(matches) != 1:
        raise ValueError(f"Perfil ausente ou ambíguo: {identifier}")
    return deepcopy(matches[0])


def profile_names(family: str | None = None) -> list[str]:
    return [r["name"] for r in list_profiles(family)]


def section_from_profile(profile: str | Mapping) -> Section:
    """Constrói Section a partir do registro original, nunca de dimensões alteradas."""
    identifier = profile if isinstance(profile, str) else profile.get("id", profile.get("name"))
    r = get_profile(identifier)
    return Section(name=r["name"], catalog_id=r["id"], fabrication=r["fabrication"],
                   d_mm=r["d_mm"], bf_mm=r["bf_mm"], tw_mm=r["tw_mm"],
                   tf_mm=r["tf_mm"], root_radius_mm=r["root_radius_mm"],
                   property_basis=r["property_basis"], property_source=r["source"],
                   catalog=deepcopy(r["catalog"]))


def has_equivalent_root_radius(section: Section) -> bool:
    """Informa se o raio representa d′ tabulado, não medição independente."""
    return section.fabrication == "rolled" and "r equivalente=" in section.property_source


def profile_metadata(profile: str | Mapping) -> dict:
    identifier = profile if isinstance(profile, str) else profile.get("id", profile.get("name"))
    return get_profile(identifier)["metadata"]
