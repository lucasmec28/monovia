"""Explicit independent normative routes and strict persisted-input boundary."""
from .signatures import canonical_numbers
from dataclasses import fields, asdict
from typing import get_type_hints, get_args
import math
from .stress_8400 import Stress8400Input, Fatigue8400Input, calculate_stress_8400, calculate_fatigue_8400
from .runway_local_10084 import Local10084Input, Wheel10084, Service10084Input, calculate_local_10084, service_limits_10084

from .stability_8400 import WebPanel8400Input,calculate_web_panel_8400

from .restraint_exclusion_8400 import ContinuousRestraint8400Input,calculate_continuous_restraint_8400

from .stability_flt_8400 import FLT8400Input,calculate_flt_8400
from .stability_flange_8400 import FlangeOutstand8400Input,calculate_flange_outstand_8400

from .runway_torsion_8400 import RunwayTorsion8400Input,calculate_runway_torsion_8400

SCHEMAS={'stress_8400':Stress8400Input,'fatigue_8400':Fatigue8400Input,'local_10084':Local10084Input,'service_10084':Service10084Input,'web_panel_8400':WebPanel8400Input,'continuous_restraint_8400':ContinuousRestraint8400Input,'flt_8400':FLT8400Input,'flange_outstand_8400':FlangeOutstand8400Input,'runway_torsion_8400':RunwayTorsion8400Input}
LABELS={'stress_8400':'Tensões NBR 8400-2','fatigue_8400':'Fadiga NBR 8400-2','local_10084':'Efeitos locais NBR 10084','service_10084':'Serviço NBR 10084','web_panel_8400':'Flambagem de painel de alma NBR 8400-2','continuous_restraint_8400':'Contenção contínua qualificada','flt_8400':'FLT por método prático declarado','flange_outstand_8400':'Flambagem local de aba em balanço','runway_torsion_8400':'Flexão e torção por mesa equivalente'}

def input_errors(blocks):
    errors=[]
    def check(row,cls,path):
        if not isinstance(row,dict):errors.append(path+': objeto obrigatório.');return
        hints=get_type_hints(cls)
        if set(row)!=set(hints):errors.append(path+': campos ausentes ou desconhecidos.');return
        for name,value in row.items():
            t=hints[name]; args=get_args(t)
            if name=='wheels':
                if not isinstance(value,list) or len(value)>100:errors.append(path+'.wheels: lista limitada a 100 rodas.');continue
                for i,w in enumerate(value):check(w,Wheel10084,f'{path}.wheels[{i}]')
            elif value is None and type(None) in args:continue
            elif t is bool:
                if type(value) is not bool:errors.append(path+'.'+name+': booleano obrigatório.')
            elif t is str:
                if not isinstance(value,str):errors.append(path+'.'+name+': texto obrigatório.')
            elif t is float or float in args:
                limit={'I_w_mm6':1e30,'I_weak_mm4':1e20,'I_t_mm4':1e20,'W_major_mm3':1e15,'W_minor_mm3':1e15,'Z_major_mm3':1e15}.get(name,1e12)
                if type(value) not in (int,float) or abs(value)>limit or not math.isfinite(value):errors.append(path+'.'+name+': número finito dentro da magnitude admitida obrigatório.')
    if not isinstance(blocks,dict) or set(blocks)!=set(SCHEMAS):return ['Blocos normativos incompatíveis.']
    for route,rows in blocks.items():
        if not isinstance(rows,list) or len(rows)>100:errors.append(route+': lista limitada a 100 casos.');continue
        for i,row in enumerate(rows):check(row,SCHEMAS[route],f'{route}[{i}]')
    return errors

def context_signature(project):
    import hashlib,json
    context={'section':asdict(project.section),'material':asdict(project.material),'span_m':project.span_m,'mode':project.mode,'segments':[asdict(s) for s in project.segments],'robot_model':project.robot_model}
    return hashlib.sha256(json.dumps(canonical_numbers(context),sort_keys=True,allow_nan=False).encode()).hexdigest()

def reset_changed_context(project):
    current=context_signature(project)
    if project.normative_context==current:return False
    had_data=any(project.normative_inputs.values())
    for route,rows in project.normative_inputs.items():
        hints=get_type_hints(SCHEMAS[route])
        for row in rows:
            for name,t in hints.items():
                if t is bool:row[name]=False
    project.normative_context=current
    return had_data


def evaluate(blocks, project=None):
    """Keep source inputs/results distinct; no force/stress factor conversion."""
    outputs=[]
    for route,rows in blocks.items():
        for i,row in enumerate(rows):
            mismatch_message='Entradas vinculadas divergentes da seção, material, travamentos ou modelo atual. Revisar esta rota na etapa 5A e requalificar suas hipóteses antes de calcular.'
            mismatch=project is not None and project.normative_context!=context_signature(project)
            if project is not None:
                if route=='local_10084':
                    s=project.section
                    linked=dict(d_mm=s.d_mm,bf_mm=s.bf_mm,tf_mm=s.tf_mm,tw_mm=s.tw_mm,bottom_bf_mm=s.bottom_width,bottom_tf_mm=s.bottom_thickness,beam_length_mm=project.span_m*1000,top_running=project.mode=='runway')
                    mismatch=mismatch or any(row.get(k)!=v for k,v in linked.items())
                elif route=='service_10084':mismatch=mismatch or row.get('span_mm')!=project.span_m*1000 or row.get('top_running')!=(project.mode=='runway')
                elif route=='flt_8400':
                    from .geometry import section_properties
                    g=section_properties(project.section)
                    linked={'fy_mpa':project.material.fy_mpa,'fu_mpa':project.material.fu_mpa,'E_mpa':project.material.E_mpa,'G_mpa':project.material.G_mpa,'I_weak_mm4':g.Iy_mm4,'I_t_mm4':g.J_mm4,'I_w_mm6':g.Cw_mm6,'W_major_mm3':g.Wx_mm3,'Z_major_mm3':g.Zx_mm3,'material_source':project.material.specification}
                    if row.get('resistance_route')=='adopted_biaxial_omega':linked['W_minor_mm3']=g.Wy_mm3
                    segment=next((s for s in project.segments if s.name==row.get('segment_name')),None)
                    mismatch=mismatch or any(row.get(k)!=v for k,v in linked.items()) or segment is None
                    if g.Ix_mm4 <= g.Iy_mm4 or not project.section.doubly_symmetric or g.flange_lambda>.38*math.sqrt(project.material.E_mpa/project.material.fy_mpa) or g.web_lambda>3.76*math.sqrt(project.material.E_mpa/project.material.fy_mpa):
                        mismatch=True
                        mismatch_message='FLT: seção real não é I duplamente simétrica compacta com x como eixo forte no domínio geométrico implementado. Uma confirmação manual não substitui estes limites.'
                    if segment is not None:
                        length=(segment.top_lb_m if row['moment_major_knm']>=0 else segment.bottom_lb_m)*1000
                        mismatch=mismatch or row.get('unrestrained_length_mm')!=length
                elif route=='runway_torsion_8400':
                    from .geometry import section_properties
                    sec=project.section; mat=project.material; g=section_properties(sec)
                    linked=dict(fy_mpa=mat.fy_mpa,fu_mpa=mat.fu_mpa,E_mpa=mat.E_mpa,depth_mm=sec.d_mm,flange_width_mm=sec.bf_mm,flange_thickness_mm=sec.tf_mm,web_thickness_mm=sec.tw_mm,span_mm=project.span_m*1000,material_source=mat.specification)
                    mismatch=mismatch or any(row.get(k)!=v for k,v in linked.items())
                    if not sec.doubly_symmetric or g.Ix_mm4<=g.Iy_mm4 or g.flange_lambda>.38*math.sqrt(mat.E_mpa/mat.fy_mpa) or g.web_lambda>3.76*math.sqrt(mat.E_mpa/mat.fy_mpa):
                        mismatch=True
                        mismatch_message='Mesa equivalente: seção real fora do domínio I duplamente simétrico compacto com x forte; não basta confirmação manual.'
                elif route=='flange_outstand_8400':
                    linked={'fy_mpa':project.material.fy_mpa,'E_mpa':project.material.E_mpa,'outstand_width_mm':(project.section.bf_mm-project.section.tw_mm)/2,'flange_thickness_mm':project.section.tf_mm,'material_source':project.material.specification}
                    mismatch=mismatch or not project.section.doubly_symmetric or any(row.get(k)!=v for k,v in linked.items())
                elif route=='continuous_restraint_8400':mismatch=mismatch or not project.section.doubly_symmetric or row.get('member_segment') not in [s.name for s in project.segments]
                elif route=='web_panel_8400':mismatch=mismatch or row.get('fy_mpa')!=project.material.fy_mpa or row.get('E_mpa')!=project.material.E_mpa or row.get('web_thickness_mm')!=project.section.tw_mm or row.get('panel_height_mm')!=project.section.d_mm-project.section.tf_mm-project.section.bottom_thickness or row.get('material_source')!=project.material.specification
                else:mismatch=mismatch or row.get('fy_mpa')!=project.material.fy_mpa or row.get('fu_mpa')!=project.material.fu_mpa or row.get('material_source')!=project.material.specification
            if mismatch:
                outputs.append({'route':route,'index':i,'label':LABELS[route],'input':row,'result':{'input_valid':False,'checks':[],'pending':[mismatch_message]}})
                continue
            if route=='stress_8400':result=calculate_stress_8400(Stress8400Input(**row))
            elif route=='fatigue_8400':result=calculate_fatigue_8400(Fatigue8400Input(**row))
            elif route=='local_10084':result=calculate_local_10084(row)
            elif route=='runway_torsion_8400':result=calculate_runway_torsion_8400(RunwayTorsion8400Input(**row))
            elif route=='flt_8400':result=calculate_flt_8400(FLT8400Input(**row))
            elif route=='flange_outstand_8400':result=calculate_flange_outstand_8400(FlangeOutstand8400Input(**row))
            elif route=='continuous_restraint_8400':result=calculate_continuous_restraint_8400(ContinuousRestraint8400Input(**row))
            elif route=='web_panel_8400':result=calculate_web_panel_8400(WebPanel8400Input(**row))
            else:result=service_limits_10084(row)
            outputs.append({'route':route,'index':i,'label':LABELS[route],'input':row,'result':result})
    return outputs
