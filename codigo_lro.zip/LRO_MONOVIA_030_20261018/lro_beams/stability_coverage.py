"""Case/segment coverage of evaluated global-stability alternatives.

This is a necessary, not sufficient, condition for completing a declared beam
scope. Local plate stability, point stresses, fatigue and service remain their
own checks. Geometry/domain evaluation belongs to the upstream evaluator; this
module deliberately does not import geometry, normative, model or engine.
"""
from __future__ import annotations

from collections.abc import Mapping
import math
from typing import Any

from .result_summary import summarize_checks


_CASE_ROUTES = {
    'stress_8400': 'load_case', 'local_10084': 'case',
    'flt_8400': 'load_case', 'continuous_restraint_8400': 'load_case',
    'runway_torsion_8400': 'load_case', 'web_panel_8400': 'load_case',
    'flange_outstand_8400': 'load_case',
}
_GLOBAL_ROUTES = ('flt_8400', 'continuous_restraint_8400', 'runway_torsion_8400')
_CASES = ('I', 'II', 'III')


def _name(value):
    return value if isinstance(value, str) and value.strip() else None


def _numeric_pass(result, required_ids):
    if result.get('status') != 'RESULTADO PARCIAL':
        return False
    checks = result.get('checks')
    if not isinstance(checks, list) or not all(isinstance(check, Mapping) for check in checks):
        return False
    if not required_ids.issubset({check.get('id') for check in checks}):
        return False
    return summarize_checks(checks, coverage_complete=True)['coverage_complete']


def _qualified(route, row, result, project):
    if not isinstance(result, Mapping) or result.get('input_valid') is not True:
        return False, 'entrada/resultado inválido ou não avaliado'
    if result.get('errors') or result.get('pending'):
        return False, str(result.get('status') or 'PENDENTE')
    if not isinstance(result.get('input'), Mapping) or result['input'] != row:
        return False, 'resultado não corresponde às entradas atuais'
    if route == 'flt_8400':
        required = {'flt_practical'}
        if row.get('resistance_route') == 'adopted_biaxial_omega':
            required.update(('minor_axis_flexure', 'biaxial_flexure_interaction'))
        if _numeric_pass(result, required):
            return True, ''
    elif route == 'continuous_restraint_8400':
        checks = result.get('checks')
        if (result.get('status') == 'EXCLUSÃO QUALIFICADA NO CASO'
                and isinstance(checks, list)
                and any(isinstance(c, Mapping) and c.get('id') == 'continuous_free_flange'
                        and c.get('status') == 'INFORMATIVO' for c in checks)
                and all(isinstance(c, Mapping) and c.get('status') == 'INFORMATIVO' for c in checks)):
            return True, ''
    else:
        span = row.get('span_mm')
        project_span = getattr(project, 'span_m', None)
        full_span = (type(span) in (int, float) and type(project_span) in (int, float)
                     and math.isfinite(span) and math.isfinite(project_span)
                     and span > 0 and span == project_span*1000
                     and row.get('full_span_system_qualified') is True
                     and row.get('full_span_envelopes_qualified') is True)
        if not full_span:
            return False, 'rota não qualificada para o vão inteiro atual'
        if _numeric_pass(result, {'runway_flange_stability', 'runway_flange_longitudinal_stress'}):
            return True, ''
    return False, str(result.get('status') or 'resultado sem verificação concluída')


def evaluate_stability_coverage(project: Any, evaluated_outputs) -> dict[str, Any]:
    """Match global-stability coverage to every required (case, segment) pair.

    Required cases come from all stress/local/stability input rows. Each case
    requires every registered segment. The accepted evidence is exclusively a
    current output block from normative.evaluate: matching route/index/input,
    valid result and passing numerical checks, or a qualified continuous
    exclusion. A valid full-span equivalent-flange route covers every segment
    for its own case, without credit for intermediate restraints.

    A failed/pending/invalid configured global-stability row remains a gap even
    when another route covers the same pair. This prevents an alternative from
    hiding an unresolved selected calculation. No row-presence shortcut exists.
    """
    blocks = getattr(project, 'normative_inputs', {})
    gaps = []
    if not isinstance(blocks, Mapping):
        return {'required_pairs': [], 'covered_pairs': [],
                'gaps': ['Entradas normativas inválidas para conferir estabilidade.'],
                'coverage_complete': False}
    segments = []
    for segment in getattr(project, 'segments', ()):
        name = _name(getattr(segment, 'name', None))
        if name is None or name in segments:
            gaps.append('Trechos de estabilidade precisam de nomes válidos e únicos.')
        elif name is not None:
            segments.append(name)
    if not segments:
        gaps.append('Cadastrar os trechos necessários à cobertura de estabilidade.')
    required_cases = set()
    for route, case_field in _CASE_ROUTES.items():
        rows = blocks.get(route, [])
        if not isinstance(rows, list):
            gaps.append(f'Lista de casos inválida: {route}.')
            continue
        for index, row in enumerate(rows):
            case = row.get(case_field) if isinstance(row, Mapping) else None
            if case not in _CASES:
                gaps.append(f'Caso I/II/III não qualificado em {route}[{index}].')
            else:
                required_cases.add(case)
    if not required_cases:
        gaps.append('Nenhum caso de solicitação foi declarado para conferir a estabilidade.')
    required = [(case, segment) for case in _CASES if case in required_cases for segment in segments]
    evaluated = {}
    for block in evaluated_outputs:
        if not isinstance(block, Mapping) or block.get('route') not in _GLOBAL_ROUTES:
            continue
        route, index = block['route'], block.get('index')
        rows = blocks.get(route, [])
        if type(index) is not int or not isinstance(rows, list) or not 0 <= index < len(rows):
            gaps.append(f'Resultado de estabilidade sem linha atual correspondente: {route}.')
            continue
        identity = (route, index)
        if identity in evaluated:
            gaps.append(f'Resultado de estabilidade duplicado/ambíguo: {route}[{index}].')
        evaluated[identity] = block
    covered = set()
    for route in _GLOBAL_ROUTES:
        rows = blocks.get(route, [])
        if not isinstance(rows, list):
            continue
        for index, row in enumerate(rows):
            identity = f'{route}[{index}]'
            if not isinstance(row, Mapping):
                gaps.append(f'Entrada de estabilidade inválida: {identity}.')
                continue
            case = row.get('load_case')
            if case not in _CASES:
                continue  # The invalid case was already reported above.
            segment = row.get('member_segment' if route == 'continuous_restraint_8400' else 'segment_name')
            if route != 'runway_torsion_8400' and segment not in segments:
                gaps.append(f'{identity}: trecho de estabilidade não cadastrado ({segment!r}).')
                continue
            block = evaluated.get((route, index))
            if block is None:
                gaps.append(f'{identity}, caso {case}: avaliação de estabilidade ausente.')
                continue
            if block.get('input') != row:
                gaps.append(f'{identity}, caso {case}: avaliação desatualizada para as entradas atuais.')
                continue
            qualified, reason = _qualified(route, row, block.get('result'), project)
            if not qualified:
                gaps.append(f'{identity}, caso {case}: {reason}.')
                continue
            covered.update((case, name) for name in segments) if route == 'runway_torsion_8400' else covered.add((case, segment))
    covered_pairs = [pair for pair in required if pair in covered]
    gaps.extend(f'Estabilidade sem cobertura concluída: caso {case}, trecho {segment}.'
                for case, segment in required if (case, segment) not in covered)
    gaps = list(dict.fromkeys(gaps))
    return {'required_pairs': required, 'covered_pairs': covered_pairs, 'gaps': gaps,
            'coverage_complete': bool(required) and len(covered_pairs) == len(required) and not gaps}
