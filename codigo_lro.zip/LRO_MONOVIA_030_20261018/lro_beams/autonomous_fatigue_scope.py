"""Fail-closed nominal-field qualification, preserving diagnostic arithmetic."""
MESA_PARALLEL_PENDING=('A tensão normal paralela ao cordão transversal da mesa e o campo nominal da mesa receptora ainda requerem recuperação compatível. Tração de interface ou valor zero presumido não qualifica esse campo.')

def mark_unqualified_nominal_field(result,reason=MESA_PARALLEL_PENDING):
    result['domain_complete']=False
    result['diagnostic_only']=True
    result['domain_pending']=[reason]
    result['pending']=[reason]
    result['criterion_exceedances']=[]
    for check in result.get('checks',[]):
        check['status']='PENDENTE'
        check['detail']=reason+' Valores numéricos mantidos somente como diagnóstico.'
    for row in result.get('station_results',[]):
        mark_unqualified_nominal_field(row['result'],reason)
    return result
