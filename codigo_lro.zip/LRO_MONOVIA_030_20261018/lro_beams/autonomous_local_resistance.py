"""Prescribed local-web and bearing-stiffener components, NBR 8800:2024.

Independent normal-ULS actions, not a conversion of 10084 admissible stresses.
The force's centered component is checked here; eccentricity/torsion is retained
and explicitly requires the concurrent local/global stress route. No fabricated
external qualification flag and no generic declaration of full compliance.
"""
from __future__ import annotations
from .autonomous_restraint_mode import analysis_brace_positions
import math
from dataclasses import replace
from .autonomous_model import validate_autonomous
from .autonomous_response import CaseFactors,case_loads,fixed_permanent_loads
from .autonomous_actions import ActionFactors
from .moving_beam import BeamModel,translate_train,solve_position
from .autonomous_resistance import reduction_chi,_effective_width
from .autonomous_local import stiffener_positions_mm

SOURCE='ABNT NBR 8800:2024 + Er1:2025, 5.7.1–5.7.9, pp.63–68'
STIFFENER_SOURCE='ABNT NBR 8800:2024 + Er1:2025, 5.7.9.2–5.7.9.6; 5.3.2–5.3.4, Tabelas 4/5; 5.4.3.1.3'
WELD_SOURCE='ABNT NBR 8800:2024 + Er1:2025, 5.7.9.2/3; 6.2.2.2, 6.2.5.1/Tabela 9 e 6.2.6.2/Tabela 11'


def _positive(v,zero=False):
    if isinstance(v,bool) or not isinstance(v,(int,float)) or not math.isfinite(v) or (v<0 if zero else v<=0):
        raise ValueError('Dimensão/ação numérica fora do domínio.')
    return float(v)


def local_web_capacities(s,m,*,bearing_length_mm,end_distance_mm,lateral_length_mm,loaded_flange='top',rotation_restrained=False):
    """5.7.3–6, no stiffener credit; k=tf for welded omits weld benefit.

    For wheels, ln=0 is an explicit conservative lower-bound choice at the
    OUTER flange, not the 10084 effective web length. Cr=16E is the lower branch
    regardless of the unknown first-yield moment; no unrelated M snapshot.
    """
    if loaded_flange not in ('top','bottom') or type(rotation_restrained) is not bool:raise ValueError('Mesa carregada ou vínculo inválido.')
    ln=_positive(bearing_length_mm,True);distance=_positive(end_distance_mm,True);ell=_positive(lateral_length_mm)
    tf=s.tf_mm if loaded_flange=='top' else s.bottom_thickness
    d=s.d_mm;tw=s.tw_mm;h=d-s.tf_mm-s.bottom_thickness-(2*s.root_radius_mm if s.fabrication=='rolled' else 0)
    for v in (tf,d,tw,h,m.E_mpa,m.fy_mpa,m.gamma_a1):_positive(v)
    k=tf+(s.root_radius_mm if s.fabrication=='rolled' else 0)
    yield_cap=1.10*((5 if distance>d else 2.5)*k+ln)*m.fy_mpa*tw/m.gamma_a1/1000
    near=distance<d/2
    c=.33 if near else .66
    q=(4*ln/d-.2) if near and ln/d>.2 else 3*ln/d
    cripple=c*tw**2/m.gamma_a1*(1+q*(tw/tf)**1.5)*math.sqrt(m.E_mpa*m.fy_mpa*tf/tw)/1000
    bf=s.bf_mm if loaded_flange=='top' else s.bottom_width
    ratio=(h/tw)/(ell/bf);limit=2.3 if rotation_restrained else 1.7
    lateral=16*m.E_mpa*tw**3*tf/(m.gamma_a1*h*h)*((.94 if rotation_restrained else 0)+.37*ratio**3)/1000
    opposed=24*tw**3*math.sqrt(m.E_mpa*m.fy_mpa)/(m.gamma_a1*h)/1000*(.5 if near else 1)
    return {'web_yield_kn':yield_cap,'web_crippling_kn':cripple,'web_sidesway_kn':lateral,
            'opposed_compression_kn':opposed,'lateral_mode_excluded':ratio>limit,'lateral_ratio':ratio,
            'lateral_threshold':limit,'Cr_mpa':16*m.E_mpa,'h_mm':h,'k_mm':k,'near_end':near,
            'bearing_length_mm':ln,'end_distance_mm':distance,'lateral_length_mm':ell,'source':SOURCE}


def bearing_stiffener(p,*,at_end=True):
    """Physical two-plate section + web strip, flexural axis in the web plane.

    End strip 12tw, interior 25tw; effective length .75h per 5.7.9.4.
    Treat every free strip arm as AL with limit .56 sqrt(E/fy), including the
    two web-strip outstands; local effective widths are therefore not omitted.
    """
    s=p.section;m=p.material;c=_positive(p.stiffener_outstand_mm);t=_positive(p.stiffener_thickness_mm)
    tw=s.tw_mm;h=s.d_mm-s.tf_mm-s.bottom_thickness
    strip=(12 if at_end else 25)*tw
    # End strip cannot borrow material beyond the real member end. Using 12tw
    # at supports is conservative even with a physical end projection.
    A=2*c*t+strip*tw
    I=2*t*((c+tw/2)**3-(tw/2)**3)/3+strip*tw**3/12
    Le=.75*h;Ne=math.pi**2*m.E_mpa*I/Le**2
    lam=math.sqrt(A*m.fy_mpa/Ne);chi=reduction_chi(lam)
    limit=.56*math.sqrt(m.E_mpa/m.fy_mpa)
    ce=_effective_width(c,t,limit,chi,m.fy_mpa,.22,1.49)
    we=_effective_width(strip/2,tw,limit,chi,m.fy_mpa,.22,1.49)
    Ae=2*ce*t+2*we*tw
    positions=stiffener_positions_mm(p)
    panels=[b-a for a,b in zip(positions,positions[1:])]
    # Controlling NBR 8800:2024/Er1:2025, p.1 corrects 5.4.3.1.3(c):
    # j = [2.5/(a/h)^2] - 2 >= 0.5, replacing the original body typo.
    required_I=max((a*tw**3*max(.5,2.5/(a/h)**2-2) for a in panels),default=0.)
    min_c=max(s.bf_mm,s.bottom_width)/3-tw/2
    min_t=max(max(s.tf_mm,s.bottom_thickness)/2,c/16)
    geometry_ok=c>=min_c and t>=min_t and c<=(min(s.bf_mm,s.bottom_width)-tw)/2
    attachment_ok=p.stiffener_layout!='none_or_unknown' and p.stiffener_connection=='web_and_both_flanges_welded'
    plate_slenderness_ok=c/t<=limit
    return {'capacity_kn':chi*Ae*m.fy_mpa/m.gamma_a1/1000,'Ag_mm2':A,'Aef_mm2':Ae,'I_axis_in_web_mm4':I,
            'web_strip_mm':strip,'effective_outstand_mm':ce,'effective_web_half_width_mm':we,'effective_length_mm':Le,'lambda_zero':lam,'chi':chi,
            'minimum_outstand_mm':min_c,'minimum_thickness_mm':min_t,'geometry_ok':geometry_ok,
            'attachment_ok':attachment_ok,'plate_slenderness_ok':plate_slenderness_ok,
            'panel_required_I_mm4':required_I,'panel_rigidity_ok':I>=required_I,
            'required_thickness_for_panel_rigidity_mm':max(0.,(required_I-strip*tw**3/12)/(2*((c+tw/2)**3-(tw/2)**3)/3)),
            'panels_mm':panels,'four_edges_supported':geometry_ok and attachment_ok and plate_slenderness_ok and I>=required_I,
            'restraint_evidence':{'verified_by_calculation':False,
                'transverse_edges':'Pares de enrijecedores de altura total soldados à alma e às duas mesas, rigidez I_st conforme 5.4.3.1.3.',
                'longitudinal_edges':'Linhas de união contínua alma–mesa da seção I: apoio local de translação relativa; rotação liberada no modelo de placa. Modos globais e distorcionais verificados separadamente.',
                'source':STIFFENER_SOURCE},
            'panel_rigidity_formula':'I_st >= a tw³ max[0.5, 2.5/(a/h)²−2], NBR 8800:2024/Er1:2025, p.1; correção de 5.4.3.1.3(c)',
            'source':STIFFENER_SOURCE}


def _weld_leg_limits(p,connection,thin):
    """User minimum is a lower bound on the existing automatic proposal."""
    field={'flange_web':'flange_web_weld_min_leg_mm','mesa':'stiffener_flange_weld_min_leg_mm',
           'alma':'stiffener_web_weld_min_leg_mm'}[connection]
    requested=_positive(getattr(p,field,0.),True)
    normative=3 if thin<=6.3 else 5 if thin<=12.5 else 6 if thin<=19 else 8
    maximum=thin if thin<6.3 else thin-1.5
    minimum=max(normative,requested)
    return {'minimum_leg_mm':minimum,'maximum_leg_mm':maximum,
        'normative_minimum_leg_mm':normative,'requested_minimum_leg_mm':requested,
        'requested_minimum_within_geometry':requested<=maximum,
        'minimum_selection_rule':'Maior entre mínimo normativo e mínimo informado; proposta automática em passos de 0,5 mm, limitada pela geometria.'}


def design_stiffener_welds(p,force_kn,*,fuw_mpa=485.):
    """Proposed continuous two-sided fillets for TWO plates, not as-built proof.

    Full applied force is used, even when 5.7.9 requires only a residual force.
    A 10 mm corner clearance or larger actual root radius is reserved. The
    selected minimum fuw is an explicit procurement requirement. No directional
    weld-strength enhancement, bearing-fit benefit, or fatigue approval.
    """
    force=_positive(force_kn,True);s=p.section;m=p.material;fuw=max(_positive(fuw_mpa),m.fu_mpa)
    c=p.stiffener_outstand_mm;t=p.stiffener_thickness_mm;h=s.d_mm-s.tf_mm-s.bottom_thickness
    clearance=max(10.,s.root_radius_mm+2.)
    result={'force_kn':force,'specified_minimum_fuw_mpa':fuw,'specified_minimum_fyw_mpa':m.fy_mpa,'corner_clearance_mm':clearance,
            'proposed_detail':True,'approval':False,'source':WELD_SOURCE,'connections':[],'detail_feasible':True}
    for name,length,thin,longitudinal in [('mesa',c-clearance,min(t,s.tf_mm,s.bottom_thickness),False),
                                         ('alma',h-2*clearance,min(t,s.tw_mm),True)]:
        limits=_weld_leg_limits(p,name,thin)
        minimum=limits['minimum_leg_mm'];maximum=limits['maximum_leg_mm']
        chosen=None
        for i in range(math.ceil(minimum*2),math.floor(maximum*2)+1):
            leg=i/2
            beta=min(1.,max(.6,1.2-.002*length/leg)) if longitudinal else 1.
            effective=min(length*beta,180*leg) if longitudinal and length>300*leg else length*beta
            weld=4*effective*(leg/math.sqrt(2))*.6*fuw/1.35/1000
            # Two plate load paths; do not count the same base strip four times.
            base_yield=2*max(0.,length)*thin*.6*m.fy_mpa/m.gamma_a1/1000
            base_rupture=2*max(0.,length)*thin*.6*m.fu_mpa/1.35/1000
            base=min(base_yield,base_rupture)
            if length>=40 and length>=4*leg and min(weld,base)>=force:
                chosen={'leg_mm':leg,'throat_mm':leg/math.sqrt(2),'length_each_mm':length,
                        'number_of_lines':4,'beta':beta,'effective_length_each_mm':effective,
                        'weld_capacity_kn':weld,'base_yield_capacity_kn':base_yield,'base_rupture_capacity_kn':base_rupture,'base_metal_shear_capacity_kn':base,'capacity_kn':min(weld,base)}
                break
        if chosen is None:result['detail_feasible']=False
        result['connections'].append({'connection':name,**limits,
                                      'available_length_each_mm':length,'design':chosen})
    result['requirements']=['Especificar metal depositado com fyw≥fy e fuw≥fu do metal-base e mínimos indicados; qualificar procedimento conforme 6.2.1/AWS D1.1.',
                            'Detalhar quatro filetes por interface, nos dois lados de cada uma das duas chapas, com recortes de canto indicados.',
                            'Fadiga, retornos e terminações conforme 6.2.6.2.6 e Anexo H; este dimensionamento é estático.',
                            'A geometria proposta precisa constar do desenho de fabricação; não é constatação de solda existente.']
    return result


def _check(identifier,name,demand,capacity,source=SOURCE,**extra):
    return {'id':identifier,'name':name,'demand_kn':demand,'capacity_kn':capacity,
            'utilization':demand/capacity if capacity>0 else None,'status':'within_adopted_bound' if demand<=capacity else 'envelope_exceeded',
            'source':source,**extra}


def calculate_local_8800(p,factors:ActionFactors,translation_m:float,*,longitudinal_sign=1,wheel_vertical_kn=None):
    """Prescribed wheel/support local components using independent normal ELU.

    No rail spread is credited in wheel ln. All simultaneously present wheel
    forces are grouped conservatively for each unbraced sidesway component.
    Web yield/crippling groups have overlapping maximum d-long influence zones;
    each group uses its sum as a zero-length patch at the nearest member end.
    This may exceed a refined group's demand; it is not proof of actual failure.
    """
    errors=validate_autonomous(p)
    if errors:raise ValueError('; '.join(errors))
    if not isinstance(factors,ActionFactors) or not factors.basis.startswith('nbr8800_uls_normal'):
        raise ValueError('Esta rota exige ações ELU normal NBR 8800 independentes dos casos admissíveis 10084.')
    cf=CaseFactors(factors.code,factors.dead_support,factors.dead_equipment,factors.lifted,factors.transverse,
                   factors.longitudinal,factors.source,extra_dead=factors.extra_dead)
    g,udl,train=case_loads(p,cf,longitudinal_sign=longitudinal_sign)
    if wheel_vertical_kn is not None:
        if len(wheel_vertical_kn)!=len(train):raise ValueError('Uma força vertical total por roda é obrigatória.')
        train=tuple(replace(w,vertical_kn=_positive(v,True)) for w,v in zip(train,wheel_vertical_kn))
    beam=BeamModel(p.span_m,p.material.E_mpa,g.Ix_mm4,g.Iy_mm4)
    loads=translate_train(beam,train,translation_m);sol=solve_position(beam,loads,udl,fixed_loads=fixed_permanent_loads(p,cf,udl))
    R=(sol.reactions.vertical_left_kn,sol.reactions.vertical_right_kn)
    checks=[];pending=[];rows=[]
    out={'case':factors.code,'translation_m':translation_m,'basis':factors.basis,'approval':False,
         'checks':checks,'pending':pending,'wheels':rows,'supports':[],'reactions_kn':dict(zip(('A','B'),R)),
         'component_checks_calculated':False,'source':SOURCE,
         'method':'Verificações prescritivas de mecanismos locais, sem conversão de base e sem crédito do trilho na resistência.',
         'limitations':['Força vertical centrada equivalente mais torque excêntrico: torque e flexão local permanecem na verificação elástica concomitante.',
                        'Grupos de rodas usam soma de forças e ln=0 conservadores; exceder o limite adotado requer refinamento.',
                        '5.7.7 é painel de ligação rígida viga–pilar e não se aplica aos apoios simples deste modelo.',
                        '5.7.2 exige tração da alma; rodas/reação de contato compressivas não são esse mecanismo.']}
    if p.wheel_travel_scope!='between_support_axes':pending.append('Passagem carregada sobre projeções exige solução global de balanços.')
    if abs(p.rail.offset_from_web_mm)>1e-9:pending.append('§5.7 pressupõe força centrada sobre a alma; trilho fisicamente deslocado requer outro método.')
    if p.support_contact!='centered_under_web':pending.append('Apoio não centrado sob alma fora do domínio §5.7.')
    if min(R)<-1e-9:pending.append('Arrancamento não pertence ao contato compressivo; avaliar tração/ancoragem e §5.7.2.')
    if pending:return out
    lower=-p.beam_end_left_mm;upper=p.span_m*1000+p.beam_end_right_mm
    total=math.fsum(w.vertical_kn for w in loads)
    # Largest real unbraced interval of either flange surrounding a wheel.
    def ell_at(x):
        lengths=[]
        for positions in (analysis_brace_positions(p,'upper_braces_m'),analysis_brace_positions(p,'lower_braces_m')):
            stations=sorted({0.,p.span_m,*positions})
            lengths.extend(b-a for a,b in zip(stations,stations[1:]) if a-1e-10<=x<=b+1e-10)
        return max(lengths)*1000
    sorted_loads=sorted(loads,key=lambda w:w.position_m)
    groups=[]
    for w in sorted_loads:
        if groups and (w.position_m-groups[-1][-1].position_m)*1000<=p.section.d_mm:
            groups[-1].append(w)
        else:groups.append([w])
    for i,group in enumerate(groups):
        force=math.fsum(w.vertical_kn for w in group)
        distance=min(min(w.position_m*1000-lower,upper-w.position_m*1000) for w in group)
        cap=local_web_capacities(p.section,p.material,bearing_length_mm=0,end_distance_mm=distance,
                                 lateral_length_mm=max(ell_at(w.position_m) for w in group))
        rows.append({'names':[w.name for w in group],'force_kn':force,'capacities':cap,'zero_length_patch_bound':True})
        checks += [_check(f'wheel_group_{i}_yield','Escoamento local da alma sob rodas',force,cap['web_yield_kn']),
                   _check(f'wheel_group_{i}_cripple','Enrugamento local da alma sob rodas',force,cap['web_crippling_kn'])]
        if not cap['lateral_mode_excluded']:
            checks.append(_check(f'wheel_group_{i}_sidesway','Flambagem lateral da alma sob rodas',total,cap['web_sidesway_kn'],
                                 grouped_all_present_wheels=True))
    from .autonomous_fullheight_actions import enabled as fullheight_enabled
    nominal_fullheight=fullheight_enabled(p)
    stiff=bearing_stiffener(p,at_end=True) if not nominal_fullheight and p.stiffener_layout!='none_or_unknown' and p.stiffener_outstand_mm>0 else None
    out['fullheight_bearing_separate_consumer']=nominal_fullheight
    out['stiffener']=stiff
    fixed_detail=design_project_stiffener_welds(p,factors) if stiff else None
    out['fixed_weld_detail']=fixed_detail
    out['panel_restraint']=panel_restraint_evidence(p,fixed_detail) if stiff else {'four_edges_supported':False,'restraint_evidence':{'verified_by_calculation':False}}
    for x,name,reaction,projection in ((0.,'A',R[0],p.beam_end_left_mm),(p.span_m*1000,'B',R[1],p.beam_end_right_mm)):
        if projection<p.support_bearing_length_mm/2:
            pending.append('Apoio '+name+': contato informado ultrapassa a extremidade física.');continue
        cap=local_web_capacities(p.section,p.material,bearing_length_mm=p.support_bearing_length_mm,
            end_distance_mm=projection,lateral_length_mm=p.span_m*1000,loaded_flange='bottom',rotation_restrained=True)
        residual=max(0.,reaction-min(cap['web_yield_kn'],cap['web_crippling_kn']))
        checks += [_check('support_'+name+'_yield','Escoamento local da alma no apoio '+name,reaction,cap['web_yield_kn']),
                   _check('support_'+name+'_cripple','Enrugamento local da alma no apoio '+name,reaction,cap['web_crippling_kn'])]
        # Contact zones of the opposed loads at the SAME section. ln=0 at each
        # wheel: only wheel axes inside the actual lower contact interval pair.
        opposite=sum(w.vertical_kn for w in loads if abs(w.position_m*1000-x)<=p.support_bearing_length_mm/2+1e-7)
        if opposite>0:
            opposed=max(opposite,reaction) # upper bound for either unequal force
            checks.append(_check('support_'+name+'_opposed','Compressões opostas junto ao apoio '+name,opposed,cap['opposed_compression_kn']))
            residual=max(residual,opposed-cap['opposed_compression_kn'])
        row={'name':name,'reaction_kn':reaction,'capacities':cap,'residual_force_kn':residual}
        if stiff:
            checks.append(_check('support_'+name+'_stiffener','Par de enrijecedores de apoio '+name,max(reaction,opposite),stiff['capacity_kn'],STIFFENER_SOURCE,
                geometry_ok=stiff['geometry_ok'],attachment_ok=stiff['attachment_ok'],full_reaction_instead_of_residual=True))
            row['proposed_weld_design']=fixed_detail
            if not stiff['geometry_ok'] or not stiff['attachment_ok']:pending.append('Apoio '+name+': geometria/ligação dos enrijecedores não atende ao detalhe calculado.')
            if not row['proposed_weld_design']['detail_feasible']:pending.append('Apoio '+name+': filete proposto não cabe ou não transfere a força; rever chapas/ligação.')
        elif residual>0 and not nominal_fullheight:pending.append('Apoio '+name+': força excede alma sem reforço e não há par de enrijecedores modelado.')
        if stiff and stiff['geometry_ok'] and stiff['attachment_ok'] and fixed_detail['detail_feasible']:
            for check in checks:
                if check['id'] in ('support_'+name+'_yield','support_'+name+'_cripple','support_'+name+'_opposed'):
                    raw=check['capacity_kn'];cap_total=max(raw,stiff['capacity_kn'])
                    check.update(unreinforced_web_capacity_kn=raw,capacity_kn=cap_total,
                        residual_force_required_kn=max(0.,check['demand_kn']-raw),
                        reinforcement_basis='Par de altura total e filetes propostos dimensionados para a força inteira; não somar resistências sem compatibilidade.',
                        utilization=check['demand_kn']/cap_total,
                        status='within_adopted_bound' if check['demand_kn']<=cap_total else 'envelope_exceeded')
        out['supports'].append(row)
    out['component_checks_calculated']=not pending
    return out


def project_vertical_transfer_bound(p, factors):
    """Position-independent force bound; no sampled maximum is certified here."""
    if not isinstance(factors,ActionFactors):raise TypeError('Vetor de ações obrigatório.')
    cf=CaseFactors(factors.code,factors.dead_support,factors.dead_equipment,factors.lifted,
        factors.transverse,factors.longitudinal,factors.source,extra_dead=factors.extra_dead)
    _,udl,train=case_loads(p,cf)
    fixed=fixed_permanent_loads(p,cf,udl)
    return math.fsum(abs(w.vertical_kn) for w in train+fixed)+abs(udl.vertical_kn_per_m)*p.span_m+math.fsum(abs(w.major_moment_knm) for w in train+fixed)/p.span_m


def design_project_stiffener_welds(p, uls_factors, *,fuw_mpa=485.):
    """One deterministic detail for every position, sized with a ULS force bound.

    This is the explicit vertical-transfer requirement of 5.7.9.2/3. It does not
    purport to design the support's lateral/axial/torque anchorage. The latter
    must retain its own force path; ordinary bearing cannot transfer uplift.
    """
    if not isinstance(uls_factors,ActionFactors) or not uls_factors.basis.startswith('nbr8800_uls_normal'):
        raise ValueError('Dimensionamento fixo requer vetor ELU normal NBR 8800.')
    from .autonomous_actions import variants_8800
    from .autonomous_cases import hoist_dynamics
    candidates=variants_8800(psi=hoist_dynamics(p)['psi'],extra_dead_kn_per_m=p.extra_dead_kn_per_m,
        gamma_g_override=p.gamma_g_override,gamma_q_override=p.gamma_q_override,override_source=p.factor_basis)
    force=max(project_vertical_transfer_bound(p,f) for f in (*candidates,uls_factors))
    result=design_stiffener_welds(p,force,fuw_mpa=fuw_mpa)
    result.update(fixed_project_detail=True,action_basis=uls_factors.basis,
        force_bound_derivation='Σ|Fz,rodas| + |q|L + Σ|My,aplicado|/L limita a reação e a parcela vertical de cada enrijecedor, sem beneficiamento por posição.')
    return result


def stiffener_weld_vertical_stress_bounds(p, factors, fixed_detail):
    """Nominal force-transfer traction for the prescribed vertical mechanism.

    Same fixed throat and effective lengths at every action level; full force
    instead of residual. Return a resultant traction bound, not a classification
    of throat stress as base metal or an invented signed fatigue history.
    """
    force=project_vertical_transfer_bound(p,factors)
    result={'vertical_force_bound_kn':force,'connections':[],'complete':False,
        'scope':'Transferência vertical §5.7.9; ancoragens lateral/axial/torcional do apoio possuem caminhos próprios.',
        'source':WELD_SOURCE,'fixed_detail':fixed_detail,'approval':False}
    if not fixed_detail.get('fixed_project_detail') or not fixed_detail.get('detail_feasible'):return result
    for row in fixed_detail['connections']:
        d=row['design'];area=d['number_of_lines']*d['throat_mm']*d['effective_length_each_mm']
        result['connections'].append({'connection':row['connection'],'area_effective_mm2':area,
            'traction_bound_mpa':force*1000/area,'throat_mm':d['throat_mm'],
            'length_each_mm':d['length_each_mm'],'effective_length_each_mm':d['effective_length_each_mm'],
            'number_of_lines':d['number_of_lines'],'beta':d['beta']})
    result['complete']=True
    return result


def panel_restraint_evidence(p, fixed_weld_detail):
    """Derived geometric/rigidity evidence, with a feasible specified connection.

    Longitudinal borders are the continuous flange-web junction of an I section.
    They restrain LOCAL relative displacement, not global displacement of the
    whole section. No rotational fixity of either plate border is claimed.
    """
    stiff=bearing_stiffener(p)
    ready=bool(stiff['four_edges_supported'] and fixed_weld_detail.get('fixed_project_detail')
               and fixed_weld_detail.get('detail_feasible')
               and (not fixed_weld_detail.get('station_based') or fixed_weld_detail.get('member_design_satisfied',False)))
    evidence=dict(stiff['restraint_evidence'],verified_by_calculation=ready,
        specified_weld_detail=fixed_weld_detail,
        separation_of_modes='Apoios locais relativos da placa; deslocamento lateral/torção global e distorção da seção são verificações independentes.')
    return {'four_edges_supported':ready,'restraint_evidence':evidence,
        'panels_mm':stiff['panels_mm'],'a_max_mm':max(stiff['panels_mm'],default=0.),
        'b_mm':p.section.d_mm-p.section.tf_mm-p.section.bottom_thickness,'t_mm':p.section.tw_mm,
        'stiffener':stiff}


def flange_web_weld_stress_bounds(p, *,throat_mm,transverse_normal_bound_mpa,shear_transfer_bound_mpa):
    """Two equal continuous fillets; line equilibrium plus 45° throat transform.

    σz and resultant longitudinal-interface shear are nominal WEB-side bounds at
    the junction. qz=tw*σz and qx=tw*τ. Each symmetric weld takes half the line
    force. Vertical transfer resolves equally into throat normal/perpendicular
    shear; qx is parallel shear. Local web-bending is included in supplied σz.
    This is a nominal throat model, not a toe hot-spot field. No averaging of the
    local flow over the entire beam length and no fictitious load spread.
    """
    a=_positive(throat_mm);z=_positive(transverse_normal_bound_mpa,True);t=_positive(shear_transfer_bound_mpa,True)
    scale=p.section.tw_mm/(2*a)
    normal=scale*z/math.sqrt(2);parallel=scale*t;perpendicular=normal
    return {'normal_perpendicular_bound_mpa':normal,'shear_perpendicular_bound_mpa':perpendicular,
        'shear_parallel_bound_mpa':parallel,'shear_resultant_bound_mpa':math.hypot(parallel,perpendicular),
        'traction_resultant_bound_mpa':scale*math.hypot(z,t),
        'line_vertical_n_per_mm':z*p.section.tw_mm,'line_longitudinal_n_per_mm':t*p.section.tw_mm,
        'throat_mm':a,'number_of_lines_per_interface':2,'complete':True,
        'source':'NBR 8800, 5.4.5 e 5.7.1; equilíbrio q=t_w σ e transformação da garganta de filete a 45°.',
        'requirements':['Dois filetes iguais, contínuos, um em cada lado da alma, em ambas as mesas.',
            'Metal depositado com resistência ao escoamento e à ruptura não inferiores ao metal-base; procedimento e qualidade especificados.',
            'Tensões longitudinais globais do detalhe e fadiga são combinadas pela rota própria; não classificar garganta como metal-base.']}


def design_flange_web_welds(p, *,transverse_normal_bound_mpa,shear_transfer_bound_mpa,fuw_mpa=485.):
    """One proposed uniform flange/web fillet size for the WHOLE ULS envelope.

    Inputs must envelope all ULS cases, positions and relevant interfaces. The
    actual local flow bound, not total force divided by full weld length, is
    checked per unit length, so no long-lap average or beta benefit is invoked.
    """
    z=_positive(transverse_normal_bound_mpa,True);tau=_positive(shear_transfer_bound_mpa,True)
    fuw=max(_positive(fuw_mpa),p.material.fu_mpa)
    if p.section.fabrication=='rolled':
        return {'applicable':False,'detail_feasible':True,'reason':'Seção laminada: não existe solda longitudinal alma–mesa.','proposed_detail':False,'approval':False}
    thin=min(p.section.tw_mm,p.section.tf_mm,p.section.bottom_thickness)
    limits=_weld_leg_limits(p,'flange_web',thin)
    minimum=limits['minimum_leg_mm'];maximum=limits['maximum_leg_mm']
    chosen=None;limiting=None
    capacity=.6*fuw/1.35
    for i in range(math.ceil(minimum*2),math.floor(maximum*2)+1):
        leg=i/2
        demand=flange_web_weld_stress_bounds(p,throat_mm=leg/math.sqrt(2),
            transverse_normal_bound_mpa=z,shear_transfer_bound_mpa=tau)
        limiting=dict(demand,leg_mm=leg,capacity_mpa=capacity,utilization=demand['traction_resultant_bound_mpa']/capacity)
        if demand['traction_resultant_bound_mpa']<=capacity:
            chosen=limiting
            break
    return {'applicable':True,'detail_feasible':chosen is not None,'fixed_project_detail':True,
        'proposed_detail':True,'approval':False,**limits,'design':chosen,'limiting_design':limiting if chosen is None else None,
        'specified_minimum_fuw_mpa':fuw,'specified_minimum_fyw_mpa':p.material.fy_mpa,
        'length_each_mm':p.span_m*1000+p.beam_end_left_mm+p.beam_end_right_mm,
        'number_of_lines':4,'source':'NBR 8800, 5.4.5, 5.7.1, 6.2.2.2, Tabela 9 e Tabela 11.',
        'requirements':['Geometria proposta para execução; não é comprovação de solda existente.',
            'O metal-base e a alma são verificados nas rotas de tensões, escoamento, instabilidade e fadiga correspondentes.',
            'Dois filetes contínuos iguais por interface; acabamento, transições e controle de qualidade conforme o detalhe de fadiga especificado.']}


_GROUP_KEYS=('force_longitudinal_kn','force_transverse_kn','force_vertical_kn',
    'moment_about_longitudinal_knm','moment_about_transverse_knm','moment_about_vertical_knm')


def _group_actions(values):
    if not isinstance(values,dict) or any(k not in values for k in _GROUP_KEYS):
        raise ValueError('São necessários os seis limites de forças/binários do grupo de soldas.')
    return {key:_positive(values[key],True) for key in _GROUP_KEYS}


def _weld_group_connection(p,connection,design,action_bounds,*,moments_at_group=False):
    """Rigid elastic 3-D line group: t=F/A+(J^-1 M)×r, then triangle bound.

    Symmetric groups have zero first moments and diagonal J=∫(r²I−rrT)dA.
    Thus the recovered field has exactly the prescribed force and moment.
    Reduced effective lengths are centred for a conservative moment inertia;
    extreme coordinates retain the FULL physical lengths. No weld-return credit.
    """
    b=_group_actions(action_bounds);a=design['throat_mm'];le=design['effective_length_each_mm']
    length=design['length_each_mm'];ts=p.stiffener_thickness_mm;tw=p.section.tw_mm
    hw=p.section.d_mm-p.section.tf_mm-p.section.bottom_thickness
    clearance=max(10.,p.section.root_radius_mm+2.)
    xmax=ts/2;meanx2=xmax*xmax
    if connection=='mesa':
        inner=tw/2+clearance;outer=tw/2+p.stiffener_outstand_mm
        ymax=outer;zmax=0.;meany2=(outer**3-inner**3)/(3*(outer-inner));meanz2=0.
        # Inputs refer to the section centroid. Both top/bottom interfaces are
        # enveloped by shifting resultants through half the clear-web height.
        extra_x=0. if moments_at_group else b['force_transverse_kn']*hw/2000
        extra_y=0. if moments_at_group else b['force_longitudinal_kn']*hw/2000
        thin=min(ts,p.section.tf_mm,p.section.bottom_thickness)
    elif connection=='alma':
        ymax=tw/2;zmax=length/2;meany2=ymax*ymax;meanz2=le*le/12
        extra_x=extra_y=0.;thin=min(ts,tw)
    else:raise ValueError('Interface do enrijecedor desconhecida.')
    area=4*a*le
    J=(area*(meany2+meanz2),area*(meanx2+meanz2),area*(meanx2+meany2))
    F=tuple(b[k]*1000 for k in _GROUP_KEYS[:3])
    M=((b[_GROUP_KEYS[3]]+extra_x)*1e6,(b[_GROUP_KEYS[4]]+extra_y)*1e6,b[_GROUP_KEYS[5]]*1e6)
    omega=tuple(m/j for m,j in zip(M,J))
    tx=F[0]/area+omega[1]*zmax+omega[2]*ymax
    ty=F[1]/area+omega[2]*xmax+omega[0]*zmax
    tz=F[2]/area+omega[0]*ymax+omega[1]*xmax
    if connection=='mesa':normal=(tx+tz)/math.sqrt(2);perp=normal;parallel=ty
    else:normal=(tx+ty)/math.sqrt(2);perp=normal;parallel=tz
    traction=math.sqrt(tx*tx+ty*ty+tz*tz)
    # Each plate has two fillets sharing ONE base strip. This deliberately
    # doubles the throat/base-area ratio instead of counting base metal twice.
    base_traction=2*a/thin*traction
    return {'connection':connection,'area_effective_mm2':area,'rotation_inertias_mm4':dict(zip(('x','y','z'),J)),
        'coordinate_bounds_mm':dict(zip(('x','y','z'),(xmax,ymax,zmax))),
        'force_bounds_n':dict(zip(('x','y','z'),F)),'moment_bounds_at_group_nmm':dict(zip(('x','y','z'),M)),
        'cartesian_traction_bounds_mpa':dict(zip(('x','y','z'),(tx,ty,tz))),
        'normal_perpendicular_bound_mpa':normal,'shear_perpendicular_bound_mpa':perp,
        'shear_parallel_bound_mpa':parallel,'shear_resultant_bound_mpa':math.hypot(perp,parallel),
        'traction_resultant_bound_mpa':traction,'base_metal_traction_bound_mpa':base_traction,
        'throat_mm':a,'leg_mm':design['leg_mm'],'length_each_mm':length,
        'effective_length_each_mm':le,'number_of_lines':4,'beta':design['beta'],
        'model':'Grupo elástico rígido nominal: t=F/A+(J⁻¹M)×r; limites triangulares; garganta a45°.',
        'scope':('Resultantes já transportados ao plano físico desta interface pelo corpo livre da estação.' if moments_at_group else 'Cada interface recebe o envelope inteiro dos resultantes locais; não há repartição favorável entre interfaces.')}


def stiffener_weld_group_stress_bounds(p,fixed_detail,action_bounds):
    """Complete six-resultant nominal weld-group bound for one fixed detail.

    Caller supplies actual reaction/introduction resultants for the SAME case or
    their justified bounds, including intermediate brace reactions if present.
    Coordinates are physical: x longitudinal, y transverse, z vertical. This is
    not a claim that a group is present in an existing fabricated structure.
    """
    bounds=_group_actions(action_bounds)
    result={'complete':False,'connections':[],'action_bounds':bounds,'approval':False,
        'source':WELD_SOURCE+'; equilíbrio elástico tridimensional do grupo e transformação da garganta.',
        'requirements':['Prescrever cordões e qualidade do detalhe calculado; metal depositado fyw≥fy e fuw≥fu.',
            'Incluir forças e binários de introdução, reações dos apoios e de todos os travamentos físicos no envelope do chamador.',
            'Verificações de resistência/estabilidade das chapas e detalhe de metal-base permanecem separadas da garganta.']}
    if not fixed_detail.get('fixed_project_detail') or not fixed_detail.get('detail_feasible'):return result
    for row in fixed_detail['connections']:
        result['connections'].append(_weld_group_connection(p,row['connection'],row['design'],bounds))
    result['complete']=True
    return result


def design_stiffener_weld_group(p,action_bounds,*,fuw_mpa=485.):
    """Fixed proposed fillets sized for six full ULS resultants of the project.

    Bounds must be the envelope of all applicable ULS positions/directions and
    real brace reactions. A single consistent detail is then used for service
    and fatigue; it is never resized at every train position.
    """
    bounds=_group_actions(action_bounds)
    result=design_stiffener_welds(p,0.,fuw_mpa=fuw_mpa)
    result.update(fixed_project_detail=True,design_action_bounds=bounds,force_kn=bounds['force_vertical_kn'],
        design_basis='ELU 8800: envoltória dos seis resultantes físicos, sem repartição favorável entre interfaces.')
    result['detail_feasible']=True
    weld_allow=.6*result['specified_minimum_fuw_mpa']/1.35
    base_allow=min(p.material.fy_mpa/(math.sqrt(3)*p.material.gamma_a1),.6*p.material.fu_mpa/1.35)
    for row in result['connections']:
        chosen=None;limiting=None;length=row['available_length_each_mm'];longitudinal=row['connection']=='alma'
        for i in range(math.ceil(row['minimum_leg_mm']*2),math.floor(row['maximum_leg_mm']*2)+1):
            leg=i/2
            if length<40 or length<4*leg:continue
            beta=min(1.,max(.6,1.2-.002*length/leg)) if longitudinal else 1.
            le=min(length*beta,180*leg) if longitudinal and length>300*leg else length*beta
            design={'leg_mm':leg,'throat_mm':leg/math.sqrt(2),'length_each_mm':length,
                'effective_length_each_mm':le,'beta':beta,'number_of_lines':4}
            demand=_weld_group_connection(p,row['connection'],design,bounds)
            limiting=dict(design,group_demand=demand,weld_traction_capacity_mpa=weld_allow,
                base_traction_capacity_mpa=base_allow,
                utilization=max(demand['traction_resultant_bound_mpa']/weld_allow,demand['base_metal_traction_bound_mpa']/base_allow))
            if demand['traction_resultant_bound_mpa']<=weld_allow and demand['base_metal_traction_bound_mpa']<=base_allow:
                chosen=limiting
                break
        row['design']=chosen
        row['limiting_design']=limiting if chosen is None else None
        if chosen is None:result['detail_feasible']=False
    return result


def bearing_stiffener_combined_bounds(p,action_bounds):
    """Short full-height pair: axial qualification and mixed-force diagnostics.

    The section is the two actual plates plus the prescribed END web strip.
    Normal load is along z. Both flexural Euler modes and cruciform torsional
    mode are bounded; Cw=0 discards any warping benefit. Sum of exact rectangular
    torsion constants is a lower stiffness bound (joining restricts free warping).
    The combined energy proof conservatively uses h in BOTH flexural modes;
    .75h remains in the separate prescribed pure-compression check. Uniform-compression effective widths
    are used even in bending. Poincare/Cauchy bound response energy, then
    displacement/twist bounds and equilibrium recover second-order moments
    and shears. Energy is never substituted directly for a pointwise stress.
    Initial vertical-axis torque is outside this conservative functional.
    Only the centered purely axial family on stocky attached plates is qualified.
    Mixed-force stress/energy bounds below are retained as diagnostics only;
    their historical upper-reference/q resistance normalization is withdrawn.
    This does not apply the beam's global M to the stiffener: inputs are LOCAL
    force-path/reaction resultants referred to this transverse section.
    """
    from .autonomous_local import rectangle_torsion_constant
    b=_group_actions(action_bounds);base=bearing_stiffener(p)
    s=p.section;m=p.material;t=p.stiffener_thickness_mm;c=p.stiffener_outstand_mm;tw=s.tw_mm
    h=s.d_mm-s.tf_mm-s.bottom_thickness;strip=base['web_strip_mm']
    A=2*c*t+strip*tw
    Ix=base['I_axis_in_web_mm4'];Iy=2*c*t**3/12+tw*strip**3/12
    J=2*rectangle_torsion_constant(c,t)+rectangle_torsion_constant(strip,tw)
    Nex=math.pi**2*m.E_mpa*Ix/h**2
    Ney=math.pi**2*m.E_mpa*Iy/h**2
    Net=m.G_mpa*J/((Ix+Iy)/A)
    Ne=min(Nex,Ney,Net);chi=reduction_chi(math.sqrt(A*m.fy_mpa/Ne))
    limit=.56*math.sqrt(m.E_mpa/m.fy_mpa)
    ce=_effective_width(c,t,limit,chi,m.fy_mpa,.22,1.49)
    we=_effective_width(strip/2,tw,limit,chi,m.fy_mpa,.22,1.49)
    Ae=2*ce*t+2*we*tw
    Ixe=2*t*((ce+tw/2)**3-(tw/2)**3)/3+2*we*tw**3/12
    Iye=2*ce*t**3/12+tw*(2*we)**3/12
    # Use physical extreme fibres with reduced effective inertia: conservative.
    Wx=Ixe/(c+tw/2);Wy=Iye/max(t/2,strip/2)
    N=b['force_vertical_kn']*1000;normal_compression=N/Ae
    Fx=b['force_longitudinal_kn']*1000;Fy=b['force_transverse_kn']*1000
    # Whole-height transport bounds internal moments at every possible cut.
    Mx=(b['moment_about_longitudinal_knm']+b['force_transverse_kn']*h/1000)*1e6
    My=(b['moment_about_transverse_knm']+b['force_longitudinal_kn']*h/1000)*1e6
    Mcrx=math.pi/h*math.sqrt(m.E_mpa*Iy*m.G_mpa*J)
    Mcry=math.pi/h*math.sqrt(m.E_mpa*Ix*m.G_mpa*J)
    energy_ratio=N/Ne+Mx/Mcrx+My/Mcry
    no_vertical_torque=b['moment_about_vertical_knm']==0.
    elastic=N<min(Nex,Ney) and energy_ratio<1
    raw_bending=Mx/Wx+My/Wy
    normal_reference=normal_compression+raw_bending
    shear_reference=1.5*Fy/(2*ce*t)+1.5*Fx/(2*we*tw)
    # Response of the SAME conservative classical functional used for q.
    # Energy is not treated as a pointwise stress. Poincare/Green bounds give
    # displacements and twist; equilibrium then recovers section resultants.
    energy0=math.sqrt(h*(Mx*Mx/(m.E_mpa*Ix)+My*My/(m.E_mpa*Iy)))
    energy=energy0/(1-energy_ratio) if elastic else None
    response={}
    if energy is not None:
        u_slope=math.sqrt(h/(m.E_mpa*Iy))*energy
        v_slope=math.sqrt(h/(m.E_mpa*Ix))*energy
        u=h/math.pi*u_slope;v=h/math.pi*v_slope
        theta=math.sqrt(h/(m.G_mpa*J))*energy
        theta_prime=(Mx*math.sqrt(h/(m.E_mpa*Iy))+My*math.sqrt(h/(m.E_mpa*Ix)))*energy/(m.G_mpa*J-N*(Ix+Iy)/A)
        mx2=Mx+N*v+My*theta;my2=My+N*u+Mx*theta
        fy2=Fy+N*v_slope+Fx*theta+My*theta_prime
        fx2=Fx+N*u_slope+Fy*theta+Mx*theta_prime
        induced_torsion_shear=m.G_mpa*max(t,tw)*theta_prime
        response={'energy_first_order_sqrt_nmm':energy0,'energy_response_sqrt_nmm':energy,
            'displacement_x_bound_mm':u,'displacement_y_bound_mm':v,
            'slope_x_bound_rad':u_slope,'slope_y_bound_rad':v_slope,'twist_bound_rad':theta,
            'twist_rate_bound_rad_per_mm':theta_prime,'moment_x_bound_nmm':mx2,'moment_y_bound_nmm':my2,
            'force_x_bound_n':fx2,'force_y_bound_n':fy2,'induced_torsion_shear_bound_mpa':induced_torsion_shear}
        bending=mx2/Wx+my2/Wy
        shear=1.5*fy2/(2*ce*t)+1.5*fx2/(2*we*tw)+induced_torsion_shear
    else:
        bending=raw_bending;shear=shear_reference
    # Direct initial torque is shown diagnostically, but does not qualify this
    # functional (Greenhill follower/dead-couple problems need their own model).
    shear+=b['moment_about_vertical_knm']*1e6*max(t,tw)/J
    amp=bending/raw_bending if raw_bending>0 and elastic else (1. if elastic else None)
    normal=normal_compression+bending
    # An UPPER stress envelope divided by q is not a lower critical stress.
    # No mixed-force resistance normalization is qualified by this helper.
    # The exact centered axial-only family remains the prescribed column check;
    # its shear is identically zero, not an assumed zero-reference chi shortcut.
    pure_axial=all(b[key]==0. for key in _GROUP_KEYS if key!='force_vertical_kn')
    chi_combined_normal=chi if pure_axial else None
    chi_combined_shear=1. if pure_axial else None
    equivalent=math.sqrt(normal*normal+3*shear*shear)
    capacity=chi*m.fy_mpa/m.gamma_a1
    strip_contained=min(p.beam_end_left_mm,p.beam_end_right_mm)>=strip/2
    geometry_domain=bool(base['geometry_ok'] and base['attachment_ok'] and base['plate_slenderness_ok'] and strip_contained)
    domain=bool(pure_axial and geometry_domain)
    mixed_pending=('A resistência combinada do par requer um modelo do campo de transferência e uma referência crítica inferior qualificados; os limites legados são apenas diagnósticos.')
    geometry_pending='Geometria, vínculo, esbeltez das chapas ou faixa de alma do par requer refinamento.'
    normal_capacity=chi*m.fy_mpa/m.gamma_a1 if pure_axial else None
    shear_capacity=.6*m.fy_mpa/m.gamma_a1 if pure_axial else None
    checks=[{'id':'stiffener_combined_elastic','name':'Par de enrijecedores: resultantes locais combinadas',
        'demand':equivalent,'capacity':capacity,'unit':'MPa','utilization':equivalent/capacity,
        'sufficient_pass':domain and equivalent<=capacity,'conservative_envelope':True,'source':STIFFENER_SOURCE},
        {'id':'stiffener_column','name':'Par de enrijecedores: compressão e três modos elásticos',
        'demand':N/1000,'capacity':chi*Ae*m.fy_mpa/m.gamma_a1/1000,'unit':'kN',
        'utilization':N/(chi*Ae*m.fy_mpa/m.gamma_a1),'sufficient_pass':domain and N<=chi*Ae*m.fy_mpa/m.gamma_a1,
        'conservative_envelope':True,'source':STIFFENER_SOURCE},
        {'id':'stiffener_energy_stability','name':'Par de enrijecedores: estabilidade combinada por energia',
        'demand':energy_ratio,'capacity':1/m.gamma_a1,'unit':'razão','utilization':energy_ratio*m.gamma_a1,
        'sufficient_pass':domain and energy_ratio*m.gamma_a1<=1,'conservative_envelope':True,
        'source':'Modelo energético clássico de barra com garfos: Poincaré + Cauchy; derivação explícita no registro.'},
        {'id':'stiffener_combined_normal_stability','name':'Par de enrijecedores: tensão normal e modo combinado',
        'demand':normal,'capacity':normal_capacity,'unit':'MPa',
        'utilization':normal/normal_capacity if normal_capacity else None,
        'sufficient_pass':domain and normal<=normal_capacity,
        'source':'NBR 8800: compressão centrada do par; somente família puramente axial, sem extensão por σref superior/q.'},
        {'id':'stiffener_combined_shear_stability','name':'Par de enrijecedores: cisalhamento e modo combinado',
        'demand':shear,'capacity':shear_capacity,'unit':'MPa',
        'utilization':shear/shear_capacity if shear_capacity else None,
        'sufficient_pass':domain and shear==0.,
        'source':'Cisalhamento identicamente nulo na família puramente axial; estabilidade axial verificada separadamente.'}]
    for check in checks:
        # Axial column resistance is an independent necessary check, not a
        # replacement for the unresolved combined-force qualification.
        qualified=geometry_domain if check['id']=='stiffener_column' else domain
        check['qualified']=qualified
        check['diagnostic_only']=not qualified
        check['qualification_reason']='' if qualified else (geometry_pending if not geometry_domain else mixed_pending)
        if check['id']=='stiffener_column':
            check['sufficient_pass']=qualified and check['utilization']<=1.
        elif not qualified:
            check['capacity']=None
            check['utilization']=None
            check['sufficient_pass']=False
            check['source']='Diagnóstico legado de barra; não qualifica o campo de transferência combinado nem sua resistência.'
    return {'complete':domain,'approval':False,'qualified_member_scope':'pure_axial' if domain else 'diagnostic_only',
        'pure_axial_family':pure_axial,'normal_bound_mpa':normal,'normal_compression_bound_mpa':normal_compression,
        'normal_bending_bound_mpa':bending,'normal_interval_mpa':[-normal,bending],
        'shear_bound_mpa':shear,'von_mises_bound_mpa':equivalent,'capacity_normal_mpa':capacity,'checks':checks,
        'column_capacity_kn':chi*Ae*m.fy_mpa/m.gamma_a1/1000,'Ag_mm2':A,'Aef_mm2':Ae,
        'Ix_mm4':Ix,'Iy_mm4':Iy,'J_lower_bound_mm4':J,'Wx_effective_mm3':Wx,'Wy_effective_mm3':Wy,
        'Nex_kn':Nex/1000,'Ney_kn':Ney/1000,'Net_kn':Net/1000,'chi':chi,'moment_amplification':amp,
        'moment_cut_bounds_knm':{'x':Mx/1e6,'y':My/1e6},'Mcrx_knm':Mcrx/1e6,'Mcry_knm':Mcry/1e6,
        'energy_stability_ratio':energy_ratio,'vertical_torque_in_proof':no_vertical_torque,
        'direct_vertical_torque_zero':no_vertical_torque,
        'torque_scope':'Sem torque inicial sobre o eixo vertical do par; cisalhamento torsional induzido pela flexo-torção incluído na recuperação.',
        'chi_combined_normal':chi_combined_normal,'chi_combined_shear':chi_combined_shear,
        'normal_first_order_reference_mpa':normal_reference,'shear_first_order_reference_mpa':shear_reference,
        'second_order_response_bounds':response,
        'energy_stability_proof':{'formula':'q=N/min(Nex,Ney,Net)+|Mx|/Mcrx+|My|/Mcry; γa1 q≤1',
            'length_mm':h,'end_conditions':'Deslocamentos transversais e rotação torsional nulos nas duas mesas soldadas; empenamento livre e seção local rígida no plano.',
            'derivation':'Poincaré: ∫u′²≤(h/π)²∫u″² e ∫θ²≤(h/π)²∫θ′². Cauchy: cada termo 2|M∫u″θ| é limitado por (|M|/Mcr) vezes a soma das energias de flexão e torção. A compressão é limitada por N/min(Ne). A soma q majoriza a energia geométrica desestabilizante.',
            'moments':'Limites em todos os cortes: binários locais fornecidos mais |Ftrans|h ou |Flong|h.',
            'response':'E0²≤h(Mx²/EIx+My²/EIy); E≤E0/(1−q). |u′|≤√(h/EIy)E, |u|≤(h/π)|u′|; idem v. |θ|≤√(h/GJ)E. p=(GJ−Nr0²)θ′ cruza zero pelos garfos; |θ′|≤[Mx√(h/EIy)+My√(h/EIx)]E/(GJ−Nr0²). Mx,2≤Mx+Nv+Myθ; My,2≤My+Nu+Mxθ. Cisalhamentos incluem derivadas destes momentos e Gtmax|θ′|.',
            'force_field':'Envelopes constantes conservadores de força axial/transversal e de momentos ao longo de toda a altura; |Mx′|≤Fy e |My′|≤Fx no modelo local.',
            'not_covered':'Torque em torno do eixo vertical do par exige termo adicional de estabilidade.'},
        'elastic_column_domain':elastic,'stocky_plate_domain':base['plate_slenderness_ok'],'symmetric_web_strip_contained':strip_contained,
        'source':STIFFENER_SOURCE+'; modelo complementar elástico de coluna cruciforme e limite triangular.',
        'pending':[] if domain else ([geometry_pending] if not geometry_domain else [mixed_pending]),
        'limitations':['Envelope nominal suficiente; superar o limite conservador não demonstra, sozinho, falha física.',
            'Não inserir os momentos globais da viga no grupo: somente introdução local e reações físicas.',
            'Concentrações do detalhe de fabricação pertencem à categoria de fadiga pertinente, sem misturar tensão nominal e pico.',
            'Cisalhamento de torção Tt/J é tensão nominal do modelo aberto de paredes; não é teorema de pico elástico tridimensional na junção cruciforme.']}


def _station_rows(data):
    """Validate the station contract without inventing omitted force components."""
    rows=data.get('stations') if isinstance(data,dict) else data
    if not isinstance(rows,(list,tuple)) or not rows:raise ValueError('Informe as estações físicas dos enrijecedores.')
    result=[];ids=set()
    for original in rows:
        identifier=original.get('station_id')
        if not isinstance(identifier,str) or not identifier or identifier in ids:raise ValueError('ID de estação ausente ou repetido.')
        ids.add(identifier);x=_positive(original.get('x_m'),True)
        member=_group_actions(original.get('member_action_bounds'))
        interfaces=[];seen=set()
        for interface in original.get('interfaces',[]):
            name=interface.get('interface_id')
            if name not in ('top','bottom','web') or name in seen:raise ValueError('Interface de estação inválida ou repetida.')
            seen.add(name)
            reference='web_midheight' if name=='web' else 'inner_flange_face'
            if interface.get('reference')!=reference:raise ValueError('O momento deve estar referido ao plano físico da interface: '+reference)
            interfaces.append(dict(interface,action_bounds=_group_actions(interface.get('action_bounds',interface))))
        if seen!={'top','bottom','web'}:raise ValueError('Cada estação exige interfaces top, bottom e web explícitas.')
        result.append(dict(original,x_m=x,member_action_bounds=member,interfaces=interfaces))
    return result



def _station_member_bounds(p,station):
    result=bearing_stiffener_combined_bounds(p,station['member_action_bounds'])
    body=_positive(station.get('body_weight_kn',0.),True)
    if body>station['member_action_bounds']['force_vertical_kn']+1e-10:
        raise ValueError('Limite axial do par não contém seu próprio peso.')
    own_normal=body*1000/result['Aef_mm2']
    result['body_weight_kn']=body
    result['body_weight_axial_tension_bound_mpa']=own_normal
    result['normal_interval_mpa'][1]+=own_normal
    result['body_weight_basis']='Carga de corpo centrada: |N| já inclui W; extremo de tração acrescido de W/Aef, sem classificar gravidade como compressão obrigatória.'
    return result


def design_stiffener_station_welds(p,station_envelope,*,fuw_mpa=485.):
    """Uniform specified detail, evaluated on separate physical station bodies.

    One common leg is selected for all top/bottom interfaces; another for all
    web interfaces. No resultants are summed between unrelated stations. ULS
    input must already envelope all applicable cases/positions after signed
    moment transport. Both successful and limiting details retain location.
    """
    stations=_station_rows(station_envelope)
    actions_complete=(not isinstance(station_envelope,dict) or station_envelope.get('complete',True) is True) and all(row.get('complete',True) is True for row in stations)
    result=design_stiffener_welds(p,0.,fuw_mpa=fuw_mpa)
    result.update(fixed_project_detail=True,station_based=True,stations=[],detail_feasible=True,design_actions_complete=actions_complete,
        pending=[] if actions_complete else ['A envoltória de ações por estação não está completa; os detalhes calculados são diagnósticos.'],
        design_basis='ELU8800 por estação e corpo livre da interface; detalhe uniforme suficiente para todas as estações.')
    weld_allow=.6*result['specified_minimum_fuw_mpa']/1.35
    base_allow=min(p.material.fy_mpa/(math.sqrt(3)*p.material.gamma_a1),.6*p.material.fu_mpa/1.35)
    for summary in result['connections']:
        connection=summary['connection'];length=summary['available_length_each_mm'];longitudinal=connection=='alma'
        candidates=[(station,face) for station in stations for face in station['interfaces']
                    if ('alma' if face['interface_id']=='web' else 'mesa')==connection]
        chosen=None;limiting=None
        for i in range(math.ceil(summary['minimum_leg_mm']*2),math.floor(summary['maximum_leg_mm']*2)+1):
            leg=i/2
            if length<40 or length<4*leg:continue
            beta=min(1.,max(.6,1.2-.002*length/leg)) if longitudinal else 1.
            le=min(length*beta,180*leg) if longitudinal and length>300*leg else length*beta
            geometry={'leg_mm':leg,'throat_mm':leg/math.sqrt(2),'length_each_mm':length,
                'effective_length_each_mm':le,'beta':beta,'number_of_lines':4}
            demands=[]
            for station,face in candidates:
                demand=_weld_group_connection(p,connection,geometry,face['action_bounds'],moments_at_group=True)
                utilization=max(demand['traction_resultant_bound_mpa']/weld_allow,demand['base_metal_traction_bound_mpa']/base_allow)
                demands.append(dict(demand,station_id=station['station_id'],x_m=station['x_m'],interface_id=face['interface_id'],
                    utilization=utilization,weld_traction_capacity_mpa=weld_allow,base_traction_capacity_mpa=base_allow))
            governing=max(demands,key=lambda row:row['utilization'])
            limiting=dict(geometry,group_demand=governing,weld_traction_capacity_mpa=weld_allow,
                base_traction_capacity_mpa=base_allow,utilization=governing['utilization'],
                governing_station_id=governing['station_id'],governing_interface_id=governing['interface_id'])
            if governing['utilization']<=1:
                chosen=limiting;break
        summary.update(design=chosen,limiting_design=limiting if chosen is None else None)
        if chosen is None:result['detail_feasible']=False
    summaries={row['connection']:row for row in result['connections']}
    for station in stations:
        connections=[]
        for face in station['interfaces']:
            connection='alma' if face['interface_id']=='web' else 'mesa';summary=summaries[connection]
            standard=summary['design'] or summary['limiting_design']
            own=None
            if standard is not None:
                demand=_weld_group_connection(p,connection,standard,face['action_bounds'],moments_at_group=True)
                utilization=max(demand['traction_resultant_bound_mpa']/weld_allow,demand['base_metal_traction_bound_mpa']/base_allow)
                own=dict(standard,group_demand=dict(demand,station_id=station['station_id'],x_m=station['x_m'],interface_id=face['interface_id']),
                    utilization=utilization,criterion_satisfied=utilization<=1)
            connections.append({'interface_id':face['interface_id'],'connection':connection,
                'reference':face['reference'],'design':own if summary['design'] is not None else None,
                'limiting_design':own if summary['design'] is None else None,
                'action_bounds':face['action_bounds'],'source':face.get('source','Corpo livre da interface.')})
        result['stations'].append({'station_id':station['station_id'],'x_m':station['x_m'],'kind':station.get('kind',''),
            'member_action_bounds':station['member_action_bounds'],'connections':connections,'interfaces':connections,
            'member_bounds':_station_member_bounds(p,station)})
    result['detail_feasible']=result['detail_feasible'] and actions_complete
    result['member_design_satisfied']=actions_complete and all(row['member_bounds']['complete'] and all(check['sufficient_pass'] for check in row['member_bounds']['checks']) for row in result['stations'])
    return result


def stiffener_station_weld_stress_bounds(p,fixed_detail,station_actions):
    """Current nominal stresses on the SAME fixed ULS station/interface detail.

    Geometrically available limiting details may be evaluated diagnostically;
    static_detail_feasible stays false and gives NO panel-restraint credit.
    Parallel normal stress follows seam direction, not the magnitude of an
    already resolved traction. Web seams are vertical; flange seams transverse.
    """
    stations=_station_rows(station_actions)
    action_scope_complete=(not isinstance(station_actions,dict) or station_actions.get('complete',True) is True) and all(row.get('complete',True) is True for row in stations)
    result={'complete':False,'station_based':True,'stations':[],'connections':[],
        'static_detail_feasible':bool(fixed_detail.get('detail_feasible')),'action_scope_complete':action_scope_complete,
        'approval':False,'pending':[] if action_scope_complete else ['Ações locais desta posição não estão completas.']}
    if not fixed_detail.get('fixed_project_detail') or not fixed_detail.get('station_based'):
        result['pending'].append('É necessário o detalhe fixo dimensionado por estação.');return result
    if fixed_detail.get('design_actions_complete',True) is not True:
        result['pending'].append('A envoltória ELU usada no detalhe fixo por estação está incompleta.')
    fixed={row['station_id']:row for row in fixed_detail.get('stations',[])}
    for station in stations:
        identifier=station['station_id'];target=fixed.get(identifier)
        if target is None or not math.isclose(target['x_m'],station['x_m'],abs_tol=1e-9,rel_tol=0):
            result['pending'].append('Estação sem detalhe fixo correspondente: '+identifier);continue
        member=_station_member_bounds(p,station)
        local={'station_id':identifier,'x_m':station['x_m'],'kind':station.get('kind',''),
            'member_bounds':member,'connections':[],'member_action_bounds':station['member_action_bounds']}
        byface={row['interface_id']:row for row in target['connections']}
        for face in station['interfaces']:
            row=byface.get(face['interface_id'])
            geometry=(row.get('design') or row.get('limiting_design')) if row else None
            if geometry is None:
                result['pending'].append(identifier+'/'+face['interface_id']+': sem geometria admissível de filete.');continue
            connection='alma' if face['interface_id']=='web' else 'mesa'
            stress=_weld_group_connection(p,connection,geometry,face['action_bounds'],moments_at_group=True)
            web=face['interface_id']=='web'
            stress.update(station_id=identifier,x_m=station['x_m'],interface_id=face['interface_id'],reference=face['reference'],
                seam_direction_xyz=[0,0,1] if web else [0,1,0],
                normal_parallel_member_interval_mpa=member['normal_interval_mpa'] if web else [0.,0.],
                normal_parallel_member_complete=bool(member['complete']) if web else False,
                parallel_normal_pending=('' if web else 'A tensão normal paralela ao cordão transversal da mesa requer campo compatível na ligação; o valor zero legado não qualifica a fadiga.'),
                requires_web_transverse_interval=web,
                static_design_satisfied=bool(geometry.get('criterion_satisfied',row['design'] is not None)),
                limiting_geometry_used=row['design'] is None,
                parallel_normal_basis=('Cordão vertical: intervalo σzz do par; envolver com σz da alma nesta estação, sem somar a tração de interface.' if web else 'Cordão transversal y: σyy nominal compatível ainda não recuperada; tração de garganta não substitui esse campo.'))
            local['connections'].append(stress);result['connections'].append(stress)
        local['interfaces']=local['connections']
        result['stations'].append(local)
    result['complete']=not result['pending'] and len(result['stations'])==len(stations)
    result['source']=WELD_SOURCE+'; corpo livre por estação, orientação real dos cordões; NBR8400-2 Anexo B, p.45.'
    return result
