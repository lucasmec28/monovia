"""Resistance-only layout, independent of the bi-fork response operator.

No reaction, stiffness matrix, force, stress, or service span is returned.
Only coincident effective centre and upper-flange constraints define a nominal
lateral/twist fork.  A centre constraint alone does not shorten LTB.
"""
from __future__ import annotations
from dataclasses import asdict,dataclass
from math import isfinite
from .autonomous_restraint_mode import resistance_lengths_only

CONTRACT_SHA256='7ce4358daba4ae0cb28302683ce9a6b89a80785b0f4f0047ce20bf26fda92be8'


def _positive(v,label):
    if type(v) not in (int,float) or not isfinite(v) or v<=0:
        raise ValueError(label+': valor positivo finito obrigatório.')
    return float(v)


def _positions(values,L,label):
    if type(values) is not list:
        raise ValueError(label+': lista obrigatória.')
    result=tuple(_positive(v,label)*1000 for v in values)
    if any(v>=L for v in result) or len(set(result))!=len(result):
        raise ValueError(label+': posições únicas estritamente dentro do vão.')
    if result!=tuple(sorted(result)):
        raise ValueError(label+': posições devem estar em ordem crescente.')
    return result


@dataclass(frozen=True)
class NominalResistancePlan:
    analysis_span_mm:float
    major_flexural_mm:float
    minor_flexural_mm:float
    torsional_mm:float
    center_positions_mm:tuple[float,...]
    upper_positions_mm:tuple[float,...]
    fork_positions_mm:tuple[float,...]
    ltb_intervals_mm:tuple[tuple[float,float],...]
    uncredited_upper_positions_mm:tuple[float,...]
    uncredited_lower_positions_mm:tuple[float,...]
    source:str='Seleção no cálculo: contenções eficazes para os comprimentos resistentes, ligadas diretamente à seção.'
    contract_sha256:str=CONTRACT_SHA256
    mode:str='nominal_resistance_lengths_only'

    def __post_init__(self):
        L=_positive(self.analysis_span_mm,'Vão da análise')
        if self.major_flexural_mm!=L or self.torsional_mm!=L:
            raise ValueError('Esta extensão mantém os comprimentos forte e torcional integrais.')
        for label,values in [('centro',self.center_positions_mm),('mesa superior',self.upper_positions_mm)]:
            if type(values) is not tuple or any(type(x) not in (int,float) or not isfinite(x) or not 0<x<L for x in values) or tuple(sorted(set(values)))!=values:
                raise ValueError('Estações nominais inválidas: '+label)
        forks=tuple(sorted(set(self.center_positions_mm)&set(self.upper_positions_mm)))
        nodes=(0.,*forks,L)
        intervals=tuple(zip(nodes,nodes[1:]))
        weak_nodes=(0.,*self.center_positions_mm,L)
        if self.fork_positions_mm!=forks or self.ltb_intervals_mm!=intervals:
            raise ValueError('Intervalos FLT devem provir da interseção exata centro + mesa superior.')
        if self.minor_flexural_mm!=max(b-a for a,b in zip(weak_nodes,weak_nodes[1:])):
            raise ValueError('Comprimento fraco incompatível com as contenções centrais.')
        if self.uncredited_upper_positions_mm!=tuple(x for x in self.upper_positions_mm if x not in forks):
            raise ValueError('Estações superiores sem crédito inconsistentes.')
        if type(self.uncredited_lower_positions_mm) is not tuple or any(type(x) not in (int,float) or not isfinite(x) or not 0<x<L for x in self.uncredited_lower_positions_mm) or tuple(sorted(set(self.uncredited_lower_positions_mm)))!=self.uncredited_lower_positions_mm:
            raise ValueError('Estações inferiores sem crédito inválidas.')
        if self.contract_sha256!=CONTRACT_SHA256 or self.mode!='nominal_resistance_lengths_only' or type(self.source) is not str or not self.source.strip():
            raise ValueError('Contrato resistente nominal inválido.')

    def evidence(self):
        return {**asdict(self),
            'physical_supports_added':False,'physical_brace_reactions_calculated':False,
            'physical_action_redistribution_claimed':False,
            'original_actions_bound_every_physical_braced_response_claimed':False,
            'physical_brace_strength_or_stiffness_qualified':False,
            'local_web_restraint_credit':False,'service_or_fatigue_lengths_changed':False,
            'lateral_torsional_mm':max(b-a for a,b in self.ltb_intervals_mm),
            'premise_status':'design_requirement','warping_restraint_credit':False,
            'first_order_gate_span_mm':self.analysis_span_mm}


def resolve_nominal_lengths(project):
    if not resistance_lengths_only(project):return None
    L=_positive(project.span_m,'Vão')*1000
    upper=_positions(project.upper_braces_m,L,'Contenções superiores')
    lower=_positions(project.lower_braces_m,L,'Contenções inferiores')
    lateral=_positions(project.lateral_only_braces_m,L,'Contenções laterais')
    if lateral and (project.lateral_only_brace_level!='shear_center' or project.lateral_only_brace_model!='rigid_discrete'):
        raise ValueError('Comprimentos nominais: contenção central eficaz rígida é necessária; não inferir crédito de mola ou de outro nível.')
    center=lateral
    # Unit conversion may collapse adjacent floating-point coordinates. Do
    # not create a coincident physical restraint from that rounding event.
    if any(u!=c and u*1000==c*1000 for u in project.upper_braces_m for c in project.lateral_only_braces_m):
        raise ValueError('Posições distintas em metros coincidem somente após arredondamento de unidade; informar coincidência física exata.')
    forks=tuple(x*1000 for x in sorted(set(project.upper_braces_m)&set(project.lateral_only_braces_m)))
    nodes=(0.,*forks,L);weak=(0.,*center,L)
    return NominalResistancePlan(L,L,max(b-a for a,b in zip(weak,weak[1:])),L,
        center,upper,forks,tuple(zip(nodes,nodes[1:])),tuple(x for x in upper if x not in forks),lower)


def nominal_ltb_reference(plan,*,EIweak_Nmm2,ECw_Nmm4,moment_abs_bound_Nmm,global_radius_bound_Nmm):
    if type(plan) is not NominalResistancePlan:raise ValueError('Plano nominal tipado obrigatório.')
    # Revalidate the complete derived identity; a mutated/fabricated plan must
    # not create shorter unqualified intervals.
    plan.__post_init__()
    from top_unstiffened_candidate.reference_bound import critical_reference
    D=global_radius_bound_Nmm
    if type(D) not in (int,float) or not isfinite(D) or D<0:raise ValueError('Raio desestabilizante global inválido.')
    rows=[]
    for a,b in plan.ltb_intervals_mm:
        r=critical_reference(length_mm=b-a,EIweak_Nmm2=EIweak_Nmm2,ECw_Nmm4=ECw_Nmm4,
            moment_abs_bound_Nmm=moment_abs_bound_Nmm,point_radius_actions=(),unlocated_radius_sum_Nmm=D)
        rows.append(dict(start_mm=a,end_mm=b,global_moment_bound_Nmm=moment_abs_bound_Nmm,
            global_radius_bound_Nmm=D,**r))
    governing=min(rows,key=lambda r:r['critical_multiplier_lower'])
    return dict(load_factor_lower_bound=governing['critical_multiplier_lower'],Mmax_nmm=moment_abs_bound_Nmm,
        compression_max_n=0.,model='nominal_resistance_intervals_global_M_and_global_D',
        nominal_length_plan=plan.evidence(),intervals=rows,governing_interval_mm=[governing['start_mm'],governing['end_mm']],
        global_radius_bound_Nmm=D,favorable_GJ_discarded=True,physical_redistribution_claimed=False)
