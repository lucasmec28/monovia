"""Propriedades geométricas elásticas em N, mm e MPa."""
from __future__ import annotations
from dataclasses import dataclass, asdict
import math
from .model import Section

@dataclass(frozen=True)
class Properties:
    A_mm2: float
    Ix_mm4: float
    Iy_mm4: float
    Wx_mm3: float
    Wy_mm3: float
    Zx_mm3: float
    Zy_mm3: float
    J_mm4: float
    Cw_mm6: float
    rx_mm: float
    ry_mm: float
    h_mm: float
    h0_mm: float
    flange_lambda: float
    web_lambda: float
    centroid_from_bottom_mm: float
    Wx_top_mm3: float
    Wx_bottom_mm3: float
    Wy_top_mm3: float
    Wy_bottom_mm3: float
    def to_dict(self):
        return asdict(self)


def section_properties(s: Section) -> Properties:
    d,b,tw,tf = s.d_mm,s.bf_mm,s.tw_mm,s.tf_mm
    bb,tb=s.bottom_width,s.bottom_thickness
    h = d-tf-tb
    centroid=d/2
    if s.property_basis == "catalog":
        v = dict(s.catalog)
    else:
        rects=[(bb,tb,tb/2),(tw,h,tb+h/2),(b,tf,d-tf/2)]
        A=sum(w*t for w,t,_ in rects)
        centroid=sum(w*t*y for w,t,y in rects)/A
        Ix=sum(w*t**3/12+w*t*(y-centroid)**2 for w,t,y in rects)
        Iy=sum(t*w**3/12 for w,t,_ in rects)
        # Plastic neutral axis obtained by bisecting rectangular area, exact for each piece.
        target=A/2; passed=0.; z0=0.
        for width,height,center in rects:
            if passed+width*height>=target:
                z0=center-height/2+(target-passed)/width; break
            passed+=width*height
        Zx=0.
        for width,height,center in rects:
            lo,hi=center-height/2,center+height/2
            Zx+=width*((z0-lo)**2+(hi-z0)**2)/2 if lo<=z0<=hi else width*height*abs(center-z0)
        iy_top=tf*b**3/12; iy_bottom=tb*bb**3/12
        cw=iy_top*iy_bottom/(iy_top+iy_bottom)*(d-(tf+tb)/2)**2
        # Preserve the qualified legacy double-symmetric approximation including web Iy.
        if s.doubly_symmetric:cw=Iy*(d-tf)**2/4
        v=dict(A_mm2=A,Ix_mm4=Ix,Iy_mm4=Iy,Wx_mm3=Ix/max(centroid,d-centroid),Wy_mm3=2*Iy/max(b,bb),
               Zx_mm3=Zx,Zy_mm3=sum(t*w*w/4 for w,t,_ in rects),
               J_mm4=(b*tf**3+bb*tb**3+h*tw**3)/3,Cw_mm6=cw)
    # Cw thin-wall doubly symmetric I approximation; source/domain disclosed in report.
    return Properties(**v,rx_mm=math.sqrt(v['Ix_mm4']/v['A_mm2']),
                      ry_mm=math.sqrt(v['Iy_mm4']/v['A_mm2']),h_mm=h-2*s.root_radius_mm,
                      h0_mm=d-(tf+tb)/2,flange_lambda=max(b/(2*tf),bb/(2*tb)),web_lambda=(h-2*s.root_radius_mm)/tw,
                      centroid_from_bottom_mm=centroid,Wx_top_mm3=v["Ix_mm4"]/(d-centroid),Wx_bottom_mm3=v["Ix_mm4"]/centroid,
                      Wy_top_mm3=2*v["Iy_mm4"]/b,Wy_bottom_mm3=2*v["Iy_mm4"]/bb)


def elastic_extreme_stresses(N_kn:float,Mx_knm:float,My_knm:float,g:Properties) -> dict[str,float]:
    """Four outer corners; N positive in tension, Mx positive compresses top."""
    axial=N_kn*1000/g.A_mm2
    st=Mx_knm*1e6/g.Wx_top_mm3; sb=Mx_knm*1e6/g.Wx_bottom_mm3
    yt=My_knm*1e6/g.Wy_top_mm3; yb=My_knm*1e6/g.Wy_bottom_mm3
    return {"top_right":axial-st+yt,"top_left":axial-st-yt,
            "bottom_right":axial+sb+yb,"bottom_left":axial+sb-yb}


def simple_beam_midspan_deflection(P_kn:float,q_kn_per_m:float,L_m:float,E_mpa:float,I_mm4:float) -> float:
    """Static educational benchmark only. Not a load-combination/Robot generator."""
    L=L_m*1000
    return P_kn*1000*L**3/(48*E_mpa*I_mm4)+5*q_kn_per_m*L**4/(384*E_mpa*I_mm4)
