"""Traceable rail definitions, independent of the beam's section properties.

This module supplies rail self-weight, load-height/head geometry and the rail's
own centroidal bending inertia for LOCAL wheel-load dispersion. No function
combines a rail with the beam's global section or resistance.
"""
from __future__ import annotations

from dataclasses import dataclass
import math
from types import MappingProxyType

RECTANGULAR = 'rectangular_demonstration'
MANUAL = 'catalog_or_manufacturer'
CATALOG = 'verified_catalog'
RAIL_SHAPES = (RECTANGULAR, CATALOG, MANUAL)
STEEL_DENSITY_KG_M3 = 7850.0
RECTANGULAR_SOURCE = 'Retângulo maciço: I = b·h³/12; massa = b·h·7.850 kg/m³; br = b.'
CATALOG_URL = ('https://rails.arcelormittal.com/ckeditor_assets/attachments/1154/'
               'general_rail_catalog_-_catalogo_general_carril_-arcelormittal.pdf')
CATALOG_EDITION = 'ArcelorMittal, General rail catalogue, 2013, REV. CPIE-V1.0/13'
CATALOG_SHA256 = 'a08f42abab98dd96af53c95cb72cfe14f510dd75f8acb7802e53c120c2309ae9'
PROPERTY_FIELDS = ('width_mm', 'height_mm', 'head_width_mm', 'inertia_cm4', 'mass_kg_per_m')


def _nonnegative_number(value):
    return (isinstance(value, (int, float)) and not isinstance(value, bool)
            and math.isfinite(value) and value >= 0)


def rectangular_rail_properties(width_mm, height_mm):
    """Return derived quantities without mutating the input or project.

Both dimensions may be zero to preserve the existing no-rail representation;
local-model applicability is checked separately. A single zero is invalid.
"""
    if not all(_nonnegative_number(v) for v in (width_mm, height_mm)):
        raise ValueError('Largura e altura do trilho devem ser finitas e não negativas.')
    if (width_mm == 0) != (height_mm == 0):
        raise ValueError('Largura e altura do trilho devem ser ambas positivas ou ambas zero.')
    b, h = float(width_mm), float(height_mm)
    try:
        inertia = b * h ** 3 / 120000.0  # mm4 / 10000 = cm4
        mass = b * h * STEEL_DENSITY_KG_M3 / 1e6
    except OverflowError as exc:
        raise ValueError('Dimensões do trilho excedem a faixa numérica.') from exc
    if not all(math.isfinite(v) for v in (inertia, mass)):
        raise ValueError('Dimensões do trilho excedem a faixa numérica.')
    return dict(width_mm=b, height_mm=h, head_width_mm=b,
                inertia_cm4=inertia, mass_kg_per_m=mass)


@dataclass(frozen=True)
class RailProfile:
    id: str
    designation: str
    width_mm: float
    height_mm: float
    head_width_mm: float
    inertia_cm4: float
    mass_kg_per_m: float
    printed_page: int
    web_thickness_mm: float
    head_height_mm: float
    foot_height_mm: float

    @property
    def label(self):
        return self.designation + ' · ArcelorMittal 2013'

    @property
    def source_url(self):
        return CATALOG_URL + f'#page={self.printed_page}'

    @property
    def source(self):
        return f'{CATALOG_EDITION}, p. {self.printed_page}; {self.source_url}'

    def properties(self):
        return {name: getattr(self, name) for name in PROPERTY_FIELDS}

    def drawing_dimensions(self):
        """Verified dimensions only; insufficient to reconstruct all fillets.

The foot dimension is its full vertical depth, not a uniform plate thickness.
A view using these few dimensions must be marked schematic.
"""
        names = ('width_mm', 'height_mm', 'head_width_mm', 'web_thickness_mm',
                 'head_height_mm', 'foot_height_mm')
        return {name: getattr(self, name) for name in names}


# All five values in each entry come from the SAME printed catalogue page,
# including dimensions read from its drawing. Do not combine these pinned
# edition/variant data with the manufacturer's current overview table.
_PROFILES = (
    RailProfile('am2013_tr45_90ara_a', 'TR45 · 90ARA-A',
                130.2, 142.9, 65.0, 1610.8, 44.65, 26, 14.3, 37.3, 25.4),
    RailProfile('am2013_tr57_115re_r8', 'TR57 · 115RE R8',
                139.7, 168.3, 69.1, 2725.8, 56.97, 28, 15.9, 42.9, 28.6),
    RailProfile('am2013_tr68_136re_r8', 'TR68 · 136RE R8',
                152.4, 185.7, 74.6, 3920.2, 67.50, 32, 17.5, 49.2, 30.2),
)
_BY_ID = MappingProxyType({p.id: p for p in _PROFILES})


def list_rail_profiles():
    return _PROFILES


def get_rail_profile(profile_id):
    if not isinstance(profile_id, str) or profile_id not in _BY_ID:
        raise ValueError('Trilho de catálogo não reconhecido; selecione uma variante qualificada.')
    return _BY_ID[profile_id]


def rectangular_rail_updates(width_mm, height_mm):
    """Values for an explicit UI/type change, BEFORE calculation fingerprinting."""
    return dict(rectangular_rail_properties(width_mm, height_mm),
                shape=RECTANGULAR, catalog_id='', property_source=RECTANGULAR_SOURCE)


def catalog_rail_updates(profile_id):
    profile = get_rail_profile(profile_id)
    return dict(profile.properties(), shape=CATALOG,
                catalog_id=profile.id, property_source=profile.source)


def _same_number(actual, expected):
    return (_nonnegative_number(actual)
            and math.isclose(actual, expected, rel_tol=1e-12, abs_tol=1e-12))


def rail_definition_errors(rail):
    """Reject contradictory definitions. Validation NEVER repairs/mutates data.

The enclosing project's validator still validates physical attachment and
guidance. A manual source is a supplied reference, not certification of a rail.
"""
    values = rail if isinstance(rail, dict) else vars(rail)
    shape = values.get('shape')
    if shape not in RAIL_SHAPES:
        return ['Origem das propriedades do trilho inválida.']
    errors = []
    for name in PROPERTY_FIELDS:
        if not _nonnegative_number(values.get(name)):
            errors.append('Trilho ' + name + ': valor numérico fora da faixa.')
    source = values.get('property_source', '')
    catalog_id = values.get('catalog_id', '')
    if not isinstance(source, str):
        errors.append('Origem das propriedades do trilho deve ser texto.')
    if not isinstance(catalog_id, str):
        errors.append('Identificação do trilho de catálogo deve ser texto.')
    if errors:
        return errors
    if shape == RECTANGULAR:
        try:
            expected = rectangular_rail_properties(values['width_mm'], values['height_mm'])
        except ValueError as exc:
            return [str(exc)]
        if catalog_id:
            errors.append('Trilho retangular não deve manter identificação de catálogo.')
        if any(not _same_number(values[name], expected[name]) for name in PROPERTY_FIELDS):
            errors.append('Trilho retangular: I, massa e br devem corresponder automaticamente a b e h; recalcule as propriedades ou escolha propriedades informadas.')
    elif shape == CATALOG:
        try:
            profile = get_rail_profile(catalog_id)
        except ValueError as exc:
            return [str(exc)]
        if any(not _same_number(values[name], getattr(profile, name)) for name in PROPERTY_FIELDS):
            errors.append('Propriedades do trilho catalogado alteradas: selecione novamente o trilho ou use propriedades informadas.')
        if source != profile.source:
            errors.append('Fonte do trilho catalogado alterada: selecione novamente o trilho.')
    else:
        if catalog_id:
            errors.append('Propriedades informadas não devem manter identificação de catálogo qualificado.')
        if source == RECTANGULAR_SOURCE:
            errors.append('Propriedades informadas: substitua a fonte automática retangular pela referência realmente utilizada.')
        if not source.strip():
            errors.append('Identifique o fabricante, catálogo/desenho e revisão das propriedades informadas do trilho.')
        if (values['width_mm'] == 0) != (values['height_mm'] == 0):
            errors.append('Largura e altura do trilho devem ser ambas positivas ou ambas zero.')
    return errors


def migrate_legacy_rail_fields(raw):
    """Add the two new metadata fields to a COMPLETE pre-0.4.1 rail dictionary.

The caller must first verify the exact old key set. Never fill in a partial
new dictionary. Conflicting legacy rectangle numbers are preserved explicitly
as supplied properties, instead of silently recomputing engineering inputs.
"""
    if 'catalog_id' in raw or 'property_source' in raw:
        raise ValueError('A migração do trilho exige os dois metadados ausentes do formato anterior.')
    result = dict(raw, catalog_id='', property_source='')
    if result.get('shape') == RECTANGULAR:
        try:
            expected = rectangular_rail_properties(result['width_mm'], result['height_mm'])
        except (KeyError, ValueError):
            return result  # Main validation reports invalid old data unchanged.
        coherent = all(_same_number(result.get(name), expected[name]) for name in PROPERTY_FIELDS)
        if coherent:
            result['property_source'] = RECTANGULAR_SOURCE
            return result
        result['shape'] = MANUAL
        result['property_source'] = ('JSON anterior à versão 0.4.1: valores preservados como propriedades informadas '
            'porque I, massa ou br não correspondem ao retângulo b × h; conferir a fonte do trilho.')
    elif result.get('shape') == MANUAL:
        result['property_source'] = ('JSON anterior à versão 0.4.1: propriedades informadas preservadas; '
            'o arquivo não identificava fabricante/catálogo; conferir a fonte do trilho.')
    return result


def rail_source_text(rail):
    values = rail if isinstance(rail, dict) else vars(rail)
    if values.get('shape') == RECTANGULAR:
        return RECTANGULAR_SOURCE
    if values.get('shape') == CATALOG:
        return get_rail_profile(values.get('catalog_id')).source
    return values.get('property_source', '')
