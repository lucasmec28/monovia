"""Explicit bounded action families, generated from characteristic wheel data."""
from dataclasses import dataclass,replace
from .autonomous_model import AutonomousProject,validate_autonomous
from .autonomous_actions import HoistDynamics,compute_hoist_dynamic,factors_10084,factors_8800,evaluate_action_applicability,variants_8800
from .autonomous_response import CaseFactors

@dataclass(frozen=True)
class GeneratedCase:
    id:str
    family:str
    factors:CaseFactors
    transverse_sign:int
    longitudinal_sign:int
    loaded:bool
    description:str
    limitations:tuple[str,...]=()
    action_factors:object=None
    conservative_envelope:bool=False


def hoist_dynamics(p):
    errors=validate_autonomous(p)
    if errors:raise ValueError('; '.join(errors))
    if p.dynamic_psi_override is not None:
        return dict(psi=p.dynamic_psi_override,source=p.factor_basis,method='Coeficiente dinâmico informado; não recalculado por HC/HD')
    return compute_hoist_dynamic(HoistDynamics(p.hoist_class,p.drive_class,p.hoist_speed_m_s,
        p.creep_speed_m_s or None,'Valores sintéticos de demonstração' if p.demonstration else 'Classes e velocidades informadas no projeto'),'I')


def _adapter(a,name,empty=False):
    return CaseFactors(name,a.dead_support,a.dead_equipment,0. if empty else a.lifted,
        a.transverse,a.longitudinal,a.source,a.extra_dead)


def generate_basic_cases(p:AutonomousProject):
    """Indoor operational I + separate 8800 ELU/SLS/fatigue families.

    This named generator deliberately does not assert that extraordinary events,
    wind, thermal restraint or equipment tests are covered. Applicability must
    be assembled at project level; absence of a case is never a pass.
    """
    psi=hoist_dynamics(p)['psi']
    families=[('I','Resistência 10084/8400 · caso I',factors_10084('I',psi=psi,equipment_group=p.equipment_group)),
        ('SLS10084','Flecha operacional 10084',factors_10084('service_10084',psi=psi)),
        ('SLS8800','Flecha rara 8800',factors_8800('service_rare',psi=1.0)),
        ('FAT8400','Histórico de fadiga 8400',factors_10084('fatigue_8400',psi=psi)),
        ('FAT8800','Histórico de fadiga 8800',factors_8800('fatigue',psi=psi))]
    families.extend(('ULS8800','Resistência complementar8800 · '+a.code,a) for a in variants_8800(psi=psi,extra_dead_kn_per_m=p.extra_dead_kn_per_m,gamma_g_override=p.gamma_g_override,gamma_q_override=p.gamma_q_override,override_source=p.factor_basis))
    cases=[]
    transverse=(-1,1) if any(w.transverse_kn for w in p.wheels) else (1,)
    longitudinal=(-1,1) if any(w.longitudinal_kn for w in p.wheels) else (1,)
    for family,label,actions in families:
        for loaded in (True,False):
            for ts in transverse:
                for ls in longitudinal:
                    name=f'{family}{("/"+actions.code) if family=="ULS8800" else ""}/{"carregada" if loaded else "vazia"}/HT{ts:+d}/HL{ls:+d}'
                    cases.append(GeneratedCase(name,family,_adapter(actions,name,not loaded),ts,ls,loaded,
                        label+' · '+('com carga içada' if loaded else 'sem carga içada'),actions.limitations,actions if loaded else replace(actions,lifted=0.)))
    if hasattr(p,'action_applicability'):
        applicability=evaluate_action_applicability(p.action_applicability,dynamics=HoistDynamics(p.hoist_class,p.drive_class,p.hoist_speed_m_s,p.creep_speed_m_s or None,'Classes e velocidades declaradas'),wheel_count=len(p.wheels))
        test=applicability.get('test_case')
        if test:
            a=test['factors'];name='III/ensaio dinâmico'
            factors=replace(_adapter(a,name),wheel_vertical_override_kn=test.get('wheel_vertical_override_kn'))
            cases.append(GeneratedCase(name,'III',factors,1,1,True,'Resistência10084/8400 · ensaio dinâmico',a.limitations,a,test.get('conservative_envelope',False)))
    return tuple(cases)
