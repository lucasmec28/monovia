"""Autonomous, explicitly supplemental EN C.2 adapter.

Every sampled train position has its own exact quadratic major-moment diagram
and actual wheel height. The smallest reference Mcr lower bound is combined
with same-case response maxima, never with purported simultaneous maxima.
Two successive nested-grid changes must converge in Mcr and interactions.
This is numerical convergence, not a continuous-position interval proof.
"""
from dataclasses import replace
import math
from .autonomous_model import validate_autonomous
from .autonomous_nominal_lengths import resolve_nominal_lengths
from .autonomous_restraint_mode import resistance_lengths_only
from .autonomous_response import case_loads,fixed_permanent_loads,stiffener_self_weight_loads
from .autonomous_result import input_signature
from .autonomous_fatigue import elastic_allowables_autonomous
from .beam_torsion import LateralBrace
from .autonomous_lateral_restraints import physical_lateral_braces,lateral_only_braces,lateral_restraint_policy
from .beam_stability import StabilitySegment,HeightPointLoad,HeightLineLoad
from .moving_beam import BeamModel,translate_train,solve_position
from .runway_stability_en2025 import EN2025C2Input,calculate_supplemental_c2,web_class3_limit,SOURCE


def _pending(message):
    return dict(kind='autonomous_supplemental_en2025_c2',input_valid=True,
        member_check_complete=False,full_compliance=False,native_nbr8800_verified=False,adopted_route_qualified=False,
        checks=[],pending=[message],errors=[],intermediates={},limitations=[],status='PENDENTE')


def evaluate_supplemental_en2025(project,case,sweep):
    """Project + GeneratedCase + its unchanged CoupledSweep -> result dict.

    The caller must pass the sweep from the current project/case calculation.
    No user declarations and no implicit conversion from ELU to admissible
    cases are introduced. The adopted global route is identified under4.1.1; it is not a literal5.5.2.3 implementation.
    """
    try:return _evaluate(project,case,sweep)
    except (ValueError,TypeError,OverflowError,ZeroDivisionError,AttributeError,KeyError) as exc:
        r=_pending('Dados insuficientes para o suplemento EN C.2.');r['input_valid']=False;r['errors']=[str(exc)];return r


def _evaluate(p,case,sweep):
    errors=validate_autonomous(p)
    if errors:raise ValueError('; '.join(errors))
    if p.wheel_travel_scope!='between_support_axes':return _pending('Referência física das projeções exige rodas restritas aos eixos dos apoios; cargas verticais, horizontais ou longitudinais nas caudas fora do domínio.')
    if (p.beam_end_left_mm or p.beam_end_right_mm) and p.rail.offset_from_web_mm*p.rail.mass_kg_per_m*case.factors.dead_support!=0:
        return _pending('Torque distribuído do trilho excêntrico nas projeções não está no domínio de caudas sob peso vertical centrado.')
    if not p.section.doubly_symmetric:return _pending('C.2 autônomo implementado somente para I duplamente simétrico.')
    if case.family not in ('I','II','III','ULS8800'):return _pending('Família de ações não é de resistência para o suplemento EN C.2.')
    if sweep.case_id!=case.id:raise ValueError('Envoltória pertence a outro caso.')
    if sweep.project_signature!=input_signature(p):raise ValueError('Envoltória não vinculada aos dados atuais do projeto.')
    if type(sweep.converged) is not bool or not sweep.converged:return _pending('A passagem acoplada precisa convergir antes do suplemento EN C.2.')
    if not math.isfinite(sweep.equilibrium_relative_residual) or sweep.equilibrium_relative_residual>1e-8:
        return _pending('Equilíbrio da passagem não qualificado para o suplemento EN C.2.')
    required=('N_kn','Mx_knm','My_knm','bimoment_nmm2','shear_magnitude_upper_bound_mpa')
    maxima={key:abs(sweep.maxima[key].value) for key in required}
    if any(not math.isfinite(x) for x in maxima.values()):raise ValueError('Envelope não finito.')
    positions=tuple(sorted(set(sweep.translation_positions)))
    if len(positions)<9 or any(not math.isfinite(x) for x in positions):raise ValueError('Malha da passagem ausente/inválida.')
    if positions[0]>=-max(w.offset_m for w in p.wheels) or positions[-1]<=p.span_m-min(w.offset_m for w in p.wheels):
        raise ValueError('Passagem deve incluir estados descarregados antes da entrada e após a saída.')
    g,udl,wheels=case_loads(p,case.factors,case.transverse_sign,case.longitudinal_sign)
    if case.family=='ULS8800':
        gamma=max(1.1,p.material.gamma_a1)
        adoption='Método complementar EN 1993-1-1:2025 C.2 adotado sob NBR 8800:2024 4.1.1/4.2.2; ações ELU8800, gamma>=max(1.10,gamma_a1), chi<=min(ENd,NBR5.3.3). Não é aplicação literal de5.5.2.3.'
        safety={'resistance_gamma':gamma,'mapping':'Margem >=gamma_a1 e1.10; curva ENd limitada por chi8800, método complementar sob4.1.1.'}
    else:
        cap=elastic_allowables_autonomous(p.material.fy_mpa,p.material.fu_mpa,case.family)
        alpha=min(1/cap['nu_e'],cap['sigma_a_mpa']/p.material.fy_mpa)
        gamma=1/alpha
        adoption='Método prático EN 1993-1-1:2025 C.2 adotado sob NBR 8400-2 5.3; margem comum min(1/nu_E,sigma_a/fy), sem refatorar ações.'
        safety={'resistance_gamma':gamma,'alpha_common':alpha,'allowables_8400':cap,'mapping':adoption}
    s=p.section;m=p.material;L=p.span_m*1000;rail_z=s.d_mm/2+p.rail.height_mm
    h0=s.d_mm-s.tf_mm
    nominal_plan=resolve_nominal_lengths(p)
    braces=tuple(LateralBrace(x*1000,h0/2,None,'Mesa superior') for x in sorted(set(p.upper_braces_m)) if 0<x<p.span_m)
    braces+=tuple(LateralBrace(x*1000,-h0/2,None,'Mesa inferior') for x in sorted(set(p.lower_braces_m)) if 0<x<p.span_m)
    if nominal_plan is not None:braces=()
    from .autonomous_fullheight_runtime import stationary_radius_terms_nmm
    stationary_D_terms=stationary_radius_terms_nmm(p,case.factors.dead_support) if nominal_plan is not None else ()
    nominal_D=math.fsum([max(w.vertical_kn*1000*rail_z,0.) for w in wheels]+[abs(w.horizontal_kn*1000*(p.rail.offset_from_web_mm+p.rail.lateral_eccentricity_mm)) for w in wheels]+[max(udl.vertical_kn_per_m*rail_z,0.)*L]+list(stationary_D_terms)) if nominal_plan is not None else 0.
    base=EN2025C2Input(span_mm=L,E_mpa=m.E_mpa,G_mpa=m.G_mpa,fy_mpa=m.fy_mpa,
        depth_mm=s.d_mm,flange_width_mm=s.bf_mm,flange_thickness_mm=s.tf_mm,web_thickness_mm=s.tw_mm,
        area_mm2=g.A_mm2,major_inertia_mm4=g.Ix_mm4,minor_inertia_mm4=g.Iy_mm4,
        major_elastic_modulus_mm3=g.Wx_mm3,minor_elastic_modulus_mm3=g.Wy_mm3,
        axial_abs_max_n=maxima['N_kn']*1000,compression_max_n=maxima['N_kn']*1000,
        major_moment_max_nmm=maxima['Mx_knm']*1e6,minor_moment_max_nmm=maxima['My_knm']*1e6,
        bimoment_max_nmm2=maxima['bimoment_nmm2'],shear_stress_bound_mpa=maxima['shear_magnitude_upper_bound_mpa'],
        resistance_gamma=gamma,uniform_fork_free_warping_system=p.support_model=='simple_forks_free_warping',
        structural_steel_ambient=True,complete_same_case_envelopes=True,method_adoption_source=adoption,use_nbr8800_chi_cap=case.family=='ULS8800',lateral_braces=braces,
        left_projection_mm=p.beam_end_left_mm,right_projection_mm=p.beam_end_right_mm,
        projection_vertical_n_per_mm=udl.vertical_kn_per_m,projection_load_height_mm=rail_z,
        nominal_length_plan=nominal_plan,nominal_radius_sum_nmm=nominal_D)
    beam=BeamModel(p.span_m,m.E_mpa,g.Ix_mm4,g.Iy_mm4)
    data_by_position={}
    def position_data(a):
        loads=translate_train(beam,wheels,a);v=solve_position(beam,loads,udl,fixed_loads=fixed_permanent_loads(p,case.factors,udl))
        nodes=sorted({0.,p.span_m,*(w.position_m for w in v.all_loads)})
        segments=tuple(StabilitySegment(x0*1000,x1*1000,
            v.at(x0,'right').Mx_knm*1e6,v.at((x0+x1)/2).Mx_knm*1e6,v.at(x1,'left').Mx_knm*1e6,-v.at((x0+x1)/2).N_kn*1000)
            for x0,x1 in zip(nodes,nodes[1:]))
        points=tuple(HeightPointLoad(w.position_m*1000,w.vertical_kn*1000,rail_z) for w in loads)
        from .autonomous_fullheight_actions import enabled as fullheight_enabled
        if fullheight_enabled(p):
            from .autonomous_fullheight_runtime import pair_mass
            from .autonomous_local import stiffener_positions_mm
            points+=tuple(HeightPointLoad(x,-body['Fz_N']*case.factors.dead_support,body['z_mm'])
                for x in stiffener_positions_mm(p) for body in pair_mass(p)['points'])
        else:
            points+=tuple(HeightPointLoad(w.position_m*1000,w.vertical_kn*1000,0.) for w in stiffener_self_weight_loads(p,case.factors))
        # Placing ALL positive distributed weight at rail top is a conservative
        # height envelope of this model (beam/rail/extra weight no higher).
        lines=(HeightLineLoad(0.,L,udl.vertical_kn_per_m,rail_z),) if udl.vertical_kn_per_m else ()
        return dict(major_segments=segments,height_points=points,height_lines=lines)
    # Mcr can vary more sharply than the already-converged response maxima,
    # especially at a lateral brace. Refine this cheap reference scan itself;
    # never ask the user to declare a discretization adequate.
    reference_grids=[positions]
    if braces:
        for _ in range(2):
            previous=reference_grids[-1]
            midpoints={(a+b)/2 for a,b in zip(previous,previous[1:]) if b-a>1e-8*max(1.,p.span_m)}
            reference_grids.append(tuple(sorted(set(previous)|midpoints)))
    classification_positions=reference_grids[-1]
    for a in classification_positions:data_by_position[a]=position_data(a)
    all_segments=tuple(s for d in data_by_position.values() for s in d['major_segments'])
    # A new reference station may improve the major-action envelope too.
    # Increase it conservatively; no new fictitious simultaneous state arises.
    reconstructed=max(max(s.max_abs_moment() for s in all_segments),
                      udl.vertical_kn_per_m*max(p.beam_end_left_mm,p.beam_end_right_mm)**2/2)
    base=replace(base,classification_segments=all_segments,
                 major_moment_max_nmm=max(base.major_moment_max_nmm,reconstructed))
    maxima['Mx_knm']=base.major_moment_max_nmm/1e6
    tail_moment=udl.vertical_kn_per_m*max(p.beam_end_left_mm,p.beam_end_right_mm)**2/2
    if tail_moment:
        # Classification depends on concurrent N/M, not physical coordinate.
        # A constant pure-bending witness represents the tail's worst membrane
        # gradient; it is not inserted into the main-span stability diagram.
        all_segments=all_segments+(StabilitySegment(0.,L,-tail_moment,-tail_moment,-tail_moment,0.),)
        base=replace(base,classification_segments=all_segments)
    classification=web_class3_limit(base)
    web_ratio=(s.d_mm-2*s.tf_mm)/s.tw_mm
    if classification['limit'] is not None and web_ratio>classification['limit']:
        base=replace(base,section_resistance_mode='flanges_only')
    cache={}
    def position_result(a):
        if a in cache:return cache[a]
        data=replace(base,**data_by_position[a])
        r=calculate_supplemental_c2(data)
        if not r['input_valid']:raise ValueError('; '.join(r['errors']))
        cache[a]=r;return r
    history=[];changes=[];best=None;best_a=None;converged=False
    selected_grids=[set(positions[::stride])|{positions[0],positions[-1]} for stride in (4,2,1)]
    selected_grids.extend(set(grid) for grid in reference_grids[1:])
    for selected in selected_grids:
        for a in sorted(selected):
            r=position_result(a);cr=r['intermediates']['Mcr_lower_bound_nmm']
            if maxima['Mx_knm']==0 and best is None:best,best_a=r,a
            elif cr is not None and (best is None or cr<best['intermediates']['Mcr_lower_bound_nmm']):best,best_a=r,a
        if best is None:raise ValueError('Nenhum momento crítico de flexão disponível na passagem.')
        history.append({'positions':len(selected),'Mcr_lower_bound_nmm':best['intermediates']['Mcr_lower_bound_nmm'],
            'translation_m':best_a,'C1_bound':best['intermediates'].get('C1_bound'),'C2_bound':best['intermediates'].get('C2_bound')})
        if len(history)>1:
            old,new=history[-2:]
            deltas=[abs(new[k]-old[k])/max(abs(new[k]),abs(old[k]),1e-12)
                for k in ('Mcr_lower_bound_nmm','C1_bound','C2_bound') if new[k] is not None and old[k] is not None]
            changes.append(max(deltas,default=0.))
        converged=len(changes)>=2 and all(x<=p.sampling_tolerance for x in changes[-2:])
        if converged:break
    best.update(kind='autonomous_supplemental_en2025_c2',case_id=case.id,action_family=case.family,
                native_nbr8800_verified=False,method_adoption_source=adoption,use_nbr8800_chi_cap=case.family=='ULS8800')
    best['intermediates'].update(safety_mapping=safety,critical_Mcr_translation_m=best_a,
        moving_stability_history=history,moving_stability_relative_changes=changes,
        moving_stability_converged=converged,reference_positions_evaluated=len(cache),same_case_envelopes=maxima,
        classification_translation_count=len(classification_positions),classification_segments_evaluated=len(all_segments),
        projection_pure_bending_classification_witness=bool(tail_moment),
        original_response_translations=len(positions),additional_stability_refinements=max(0,len(history)-3),
        physical_lateral_brace_count=len(physical_lateral_braces(p)),nominal_length_mode=nominal_plan is not None,lateral_braces_in_Mcr=bool(braces),
        flt_reference_brace_count=len(braces),lateral_only_brace_count=len(lateral_only_braces(p)),
        lateral_only_restraints_excluded_from_Mcr=True,lateral_only_restraint_policy=lateral_restraint_policy(p))
    best['limitations'].extend([
        'Mcr mínimo entre posições da malha convergente própria, com até dois refinamentos adicionais automáticos quando há travas; não é certificado por intervalos da passagem contínua.',
        'Máximos absolutos de N/M/B/cisalhamento do mesmo caso são somados como limite; compressão limitada pelo máximo axial absoluto.',
        'Todo peso distribuído é colocado conservadoramente no nível superior do trilho para o efeito desestabilizante; pesos do modelo não atuam acima desse nível.',
        'Rota global complementar adotada sob4.1.1; não calcula diretamente sigma_e/tau_e de5.5.2.3. Modos locais/contato/cisalhamento/distorção permanecem nas verificações próprias.'])
    if p.lateral_only_braces_m and not resistance_lengths_only(p):
        best['limitations'].append('Contenções horizontais adicionais entram na resposta real v+zθ e nas reações, mas seu benefício estabilizante é deliberadamente omitido de Mcr, Lb, Cb e comprimentos axiais integrais; theta não é imposto por um vínculo lateral isolado.')
    if not converged:
        best['pending'].append('Mcr/interações EN não convergiram em dois refinamentos da malha de translação; refinar a passagem.')
        best['member_check_complete']=False;best['status']='PENDENTE'
    best['adopted_route_qualified']=bool(best['input_valid'] and best['member_check_complete'])
    best['adopted_route_scope']='global_combined_member_stability_only'
    best['adoption_clause']='NBR 8800:2024 4.1.1/4.2.2' if case.family=='ULS8800' else 'NBR 8400-2 5.3'
    return best
