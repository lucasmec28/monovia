"""Descriptive fatigue details and conservative same-point passage envelopes.

No Miner rule, no automatic A/E classification, and no mapping between normative
categories. A sampled passage must include entry and exit with the same baseline;
convergence must resolve both extrema and reversals, including local wheel peaks.
A cycle bound is obtained from monotonic excursions, then every cycle is assigned
the largest same-point range. Exceedance of this bound is inconclusive.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
import math
from .autonomous_actions import lifetime_passages, _number, _flag, _text

STANDARD_8800 = 'ABNT NBR 8800:2024/Er1:2025, Anexo H'
# Selected descriptions are paraphrases, not a reproduction of Tables H.1/H.2.
FATIGUE_DETAIL_OPTIONS = {
    'plain_base_no_notch': {
        'label':'Metal-base afastado de soldas, furos e entalhes',
        'category_8800':'A','source_8800':'Tabela H.1, caso 1.1, p.158',
        'detail_8400':'W0','source_8400':'Anexo D, Tabela D.4, p.68',
        'components':('normal_longitudinal','normal_transverse','shear'),
        'criteria':'Ponto homogêneo afastado de ligações; sem cantos reentrantes; bordas térmicas com rugosidade ≤25 µm; não é aço patinável sem pintura.',
        'thickness_rule':'Sem mudança de categoria por espessura neste detalhe; usar fy/fu aplicáveis à espessura real.',
        'conservative_category':False,
    },
    'continuous_longitudinal_fillet': {
        'label':'Filete longitudinal contínuo, sem acessórios, longe das extremidades',
        'category_8800':"B'",'source_8800':'Tabela H.1, casos 3.1/3.2, p.159; envelope conservador B′',
        'detail_8400':'K0_31','source_8400':'Anexo D, Tabela D.5, K0,31, p.69',
        'components':('normal_longitudinal',),
        'criteria':'Tensão normal paralela ao filete contínuo de elemento composto, em região sem acessórios e afastada de términos; qualidade Q.C. para a rota 8400.',
        'thickness_rule':'Sem corte de espessura nos casos 3.1/3.2; fy/fu correspondem à chapa avaliada.',
        'conservative_category':True,
    },
    'continuous_longitudinal_cjp_backgouged': {
        'label':'Solda longitudinal de penetração total, extração de raiz e contrassolda',
        'category_8800':'B','source_8800':'Tabela H.1, caso 3.1, p.159',
        'detail_8400':None,'source_8400':'Sem equivalência automática',
        'components':('normal_longitudinal',),
        'criteria':'Solda longitudinal contínua de penetração total com extração de raiz e contrassolda; elemento sem acessórios; ponto longe das extremidades.',
        'thickness_rule':'Sem mudança de categoria por espessura no caso 3.1; requisitos de execução/inspeção H.6 permanecem.',
        'conservative_category':False,
    },
    'transverse_stiffener_fillet_base': {
        'label':'Metal-base no pé do filete de enrijecedor transversal',
        'category_8800':'C','source_8800':'Tabela H.1, caso 5.8, p.163',
        'detail_8400':None,'source_8400':'Sem equivalência automática',
        'components':('normal_longitudinal',),
        'criteria':'Metal-base da alma/mesa junto ao pé do filete de um enrijecedor transversal; não verifica raiz, garganta ou transferência cíclica da ligação.',
        'thickness_rule':'Sem mudança de categoria por espessura no caso 5.8; não aplicar regras de acessórios ou lamelas em seu lugar.',
        'conservative_category':False,
    },
    'longitudinal_intermittent_fillet_end': {
        'label':'Metal-base na extremidade de filete longitudinal intermitente',
        'category_8800':'E','source_8800':'Tabela H.1, caso 3.4, p.160',
        'detail_8400':None,'source_8400':'Sem equivalência automática',
        'components':('normal_longitudinal',),
        'criteria':'Ponto no metal-base no início/fim de um segmento longitudinal de filete intermitente; não verifica a garganta.',
        'thickness_rule':'Sem corte de espessura no caso 3.4; não confundir com término de lamela, casos 3.5–3.7.',
        'conservative_category':False,
    },
    'web_flange_fillet_local_patch': {
        'label':'Filete alma–mesa: tensão local perpendicular no plano da alma',
        'category_8800':None,'source_8800':'Sem categoria automática implementada',
        'detail_8400':'K4_41','source_8400':'Anexo D, Tabela D.5, K4,41, p.77',
        'components':('normal_transverse',),
        'criteria':'Material adjacente a filete Q.C. entre mesa e alma; ação concentrada no plano da alma, perpendicular à solda; uma componente relevante.',
        'thickness_rule':'Usar espessura/propriedades da alma no ponto, sem substituição pela espessura da mesa.',
        'conservative_category':False,
    },
}
_CATEGORY = {'A':(250e8,165.),'B':(120e8,110.),"B'":(61e8,83.),'C':(44e8,69.),'E':(11e8,31.)}


@dataclass(frozen=True)
class PassageHistory:
    point_id: str = ''
    component: str = 'normal_longitudinal'
    stresses_mpa: tuple[float,...] = ()
    action_basis: str = ''
    complete_passage: bool = False
    sampling_converged: bool = False
    effects_complete: bool = False
    source: str = 'Solver autônomo: passagem completa no mesmo ponto material'


def _history_values(history: PassageHistory) -> list[float]:
    if not isinstance(history,PassageHistory):raise ValueError('Histórico deve ser PassageHistory.')
    _text(history.point_id,'Ponto do histórico',required=True)
    _text(history.component,'Componente',required=True)
    if history.component not in ('normal_longitudinal','normal_transverse','shear'):
        raise ValueError('Componente de tensão desconhecida.')
    _text(history.action_basis,'Base de ações',required=True)
    _text(history.source,'Origem do histórico',required=True)
    for name in ('complete_passage','sampling_converged','effects_complete'):
        if not _flag(getattr(history,name),name):raise ValueError('Histórico incompleto: '+name)
    if not isinstance(history.stresses_mpa,(tuple,list)) or not 2<=len(history.stresses_mpa)<=200000:
        raise ValueError('Histórico exige entre 2 e 200000 amostras ordenadas.')
    values=[]
    for v in history.stresses_mpa:
        if isinstance(v,bool) or not isinstance(v,(int,float)) or not math.isfinite(v) or abs(v)>1e8:
            raise ValueError('Tensão finita em MPa obrigatória.')
        values.append(float(v))
    if not math.isclose(values[0],values[-1],rel_tol=1e-10,abs_tol=1e-9):
        raise ValueError('Passagem deve incluir entrada e saída na mesma linha de base; não fechar artificialmente histórico aberto.')
    # Tiny solver closure residual is retained as an extra excursion, not deleted.
    if values[0]!=values[-1]:values.append(values[0])
    return values


def reversal_cycle_bound(history: PassageHistory) -> dict:
    """N <= ceil(monotonic excursions/2), a conservative finite-record bound.

    Remove only EXACT duplicates and intermediate monotonic samples. Rainflow
    full cycles consume two excursions; residual half-cycles one. Thus assigning
    each excursion half a cycle, rounding upward, cannot undercount the total.
    Concatenating closed passages can merge excursions; it cannot increase this
    sum. No range filter, rounding or noise threshold discards small cycles.
    This is a bound, not an ASTM rainflow range/mean spectrum implementation.
    """
    values=_history_values(history)
    unique=[values[0]]
    for v in values[1:]:
        if v!=unique[-1]:unique.append(v)
    turns=[] if len(unique)==1 else [unique[0]]
    for a,b,c in zip(unique,unique[1:],unique[2:]):
        if (b-a)*(c-b)<0:turns.append(b)
    if len(unique)>1:turns.append(unique[-1])
    excursions=max(len(turns)-1,0)
    return {'turning_points_mpa':turns,'monotonic_excursions':excursions,
            'cycles_upper_bound':math.ceil(excursions/2),
            'sigma_min_mpa':min(values),'sigma_max_mpa':max(values),
            'range_mpa':max(values)-min(values),'baseline_mpa':values[0],
            'method':'ceil(monotonic_excursions / 2); residual excursions retained',
            'source':'Limite matemático conservador por reversões; terminologia de ciclos: ASTM E1049-85(2023)'}


def same_point_lifetime_envelope(loaded: PassageHistory | None, empty: PassageHistory | None, *,
        life_years: float, uses_per_year: float, loaded_passages_per_use: float,
        empty_passages_per_use: float, required_basis: str) -> dict:
    _number(life_years,'Vida útil',positive=True);_number(uses_per_year,'Usos/ano',positive=True)
    usage=lifetime_passages(life_years,uses_per_year,loaded_passages_per_use,empty_passages_per_use)
    if usage['total_passages']<=0:raise ValueError('É necessária alguma passagem operacional na vida útil.')
    active=[];audit={};cycles=0
    for key,history,n in (('loaded',loaded,usage['loaded_passages']),('empty',empty,usage['empty_passages'])):
        if n==0:continue
        if history is None:raise ValueError('Histórico ausente para passagem '+key)
        bounds=reversal_cycle_bound(history)
        if history.action_basis!=required_basis:raise ValueError('Base de ações incompatível com a fadiga solicitada.')
        active.append(history)
        count=math.ceil(n)
        cycles+=count*bounds['cycles_upper_bound']
        audit[key]={'passages_raw':n,'passages_conservative':count,**bounds}
    first=active[0]
    for h in active[1:]:
        if h.point_id!=first.point_id or h.component!=first.component:
            raise ValueError('Extremos carregado/vazio devem representar o mesmo ponto e a mesma componente.')
        if not math.isclose(h.stresses_mpa[0],first.stresses_mpa[0],rel_tol=1e-10,abs_tol=1e-9):
            raise ValueError('Históricos carregado/vazio têm linhas de base diferentes.')
    low=min(a['sigma_min_mpa'] for a in audit.values());high=max(a['sigma_max_mpa'] for a in audit.values())
    return {'point_id':first.point_id,'component':first.component,'action_basis':required_basis,
            'sigma_min_mpa':low,'sigma_max_mpa':high,'range_mpa':high-low,
            'cycles_upper_bound':cycles,'usage':usage,'passages':audit,
            'conservative_amplitude':True,'full_compliance':False,
            'limitations':['Toda amplitude foi substituída pela maior faixa no mesmo ponto; não é cálculo de Miner.',
                'Contagem só é válida quando o solver resolve reversões e picos locais, além dos extremos globais.',
                'Históricos de outros pontos/componentes não podem ser misturados nesta comparação.']}


def _base_result(kind):
    return {'kind':kind,'input_valid':True,'status':'PENDENTE','full_compliance':False,
            'errors':[],'pending':[],'checks':[],'intermediates':{},'limitations':[]}


def _detail(detail_id,component):
    _text(detail_id,'Detalhe')
    if detail_id not in FATIGUE_DETAIL_OPTIONS:raise ValueError('Selecione um detalhe físico implementado.')
    detail=FATIGUE_DETAIL_OPTIONS[detail_id]
    if component not in detail['components']:raise ValueError('Direção/componente incompatível com o detalhe selecionado.')
    return detail


def evaluate_8800_envelope(loaded: PassageHistory | None, empty: PassageHistory | None, *,
        life_years: float, uses_per_year: float, loaded_passages_per_use: float,
        empty_passages_per_use: float, detail_id: str, fy_mpa: float, thickness_mm: float,
        fabrication: str='unqualified', corrosion: str='unqualified', temperature_c: float=20.) -> dict:
    result=_base_result('autonomous_fatigue_8800')
    try:
        fy=_number(fy_mpa,'fy',positive=True);_number(thickness_mm,'Espessura',positive=True)
        if isinstance(temperature_c,bool) or not isinstance(temperature_c,(int,float)) or not math.isfinite(temperature_c):
            raise ValueError('Temperatura finita obrigatória.')
        _text(fabrication,'Fabricação');_text(corrosion,'Corrosão')
        env=same_point_lifetime_envelope(loaded,empty,life_years=life_years,uses_per_year=uses_per_year,
            loaded_passages_per_use=loaded_passages_per_use,empty_passages_per_use=empty_passages_per_use,
            required_basis='nbr8800_fatigue')
        detail=_detail(detail_id,env['component'])
    except ValueError as exc:
        result.update(input_valid=False,status='ENTRADA INVÁLIDA',errors=[str(exc)]);return result
    result['intermediates']={**env,'detail_id':detail_id,'detail':detail,'thickness_mm':thickness_mm}
    result['limitations']=env['limitations']+[detail['criteria'],detail['thickness_rule'],
        'Fabricação e proteção especificadas são premissas de projeto, não inspeção da peça construída.',
        'Somente tensão normal no metal-base; não verifica garganta/raiz de solda, contato, cisalhamento ou interação multiaxial.']
    if fabrication!='specified_h6':result['pending'].append('Especificar fabricação e inspeção compatíveis com H.6 e com o detalhe selecionado.')
    if corrosion not in ('protected','mild_atmosphere') or temperature_c>=150:
        result['pending'].append('H.2.7 exige proteção adequada/atmosfera levemente corrosiva e temperatura inferior a 150 °C.')
    if env['component']=='shear':result['pending'].append('Esta rota 8800 não implementa fadiga de cisalhamento; categoria normal não pode ser reutilizada.')
    category=detail['category_8800']
    if category is None:result['pending'].append('Não há categoria 8800 implementada para esse detalhe; não converter categoria 8400.')
    maxabs=max(abs(env['sigma_min_mpa']),abs(env['sigma_max_mpa']))
    if maxabs>.66*fy:result['pending'].append('Tensão normal excede 0,66fy: fora da aplicabilidade H.2.2.')
    if result['pending']:return result
    n=env['cycles_upper_bound'];delta=env['range_mpa']
    if n<20000 or env['sigma_max_mpa']<0:
        reason='N conservador < 20000 (H.2.6).' if n<20000 else 'Ambos os extremos são compressivos (H.2.5).'
        result['checks']=[{'id':'fatigue_normal','name':'Fadiga normal no ponto','status':'DISPENSADA NO DOMÍNIO','source':STANDARD_8800,'detail':reason}]
        result['status']='RESULTADO PARCIAL';return result
    cf,threshold=_CATEGORY[category]
    capacity=max((329*cf/n)**.333,threshold)
    result['intermediates'].update(category=category,Cf=cf,threshold_mpa=threshold,capacity_mpa=capacity)
    ok=delta<=capacity
    check={'id':'fatigue_normal_envelope','name':'Envelope conservador de fadiga normal','status':'ATENDE' if ok else 'PENDENTE',
           'demand':delta,'capacity':capacity,'utilization':delta/capacity,'unit':'MPa',
           'source':STANDARD_8800+'; '+detail['source_8800'],
           'formula':'Δσenvelope ≤ max[(329 Cf/Nsuperior)^0,333; σTH]',
           'detail':'ATENDE AO ENVELOPE CONSERVADOR.' if ok else 'Envelope excedido; avaliar espectro/ciclos específicos antes de concluir reprovação.'}
    if not ok:
        check['exceedance_policy']='requires_specific_assessment';result['pending'].append(check['detail'])
    result['checks']=[check];result['status']='RESULTADO PARCIAL' if ok else 'RESULTADO PARCIAL — ENVELOPE EXCEDIDO'
    return result


def e8_envelope_justification() -> dict:
    from .stress_8400 import W0_LOW_MPA,W0_HIGH_MPA,K0_MPA,K4_MPA
    arrays=(W0_LOW_MPA,W0_HIGH_MPA,K0_MPA,K4_MPA)
    monotonic=all(all(a>=b for a,b in zip(v,v[1:])) for v in arrays)
    return {'adopted_group':'E8','is_actual_classification':False,'supported_details':('W0','K0_31','K4_41'),
            'monotonic_verified':monotonic,'source':'ABNT NBR 8400-2:2019, Tabela D.1 e D.2.1/D.2.2',
            'proof':'As tensões σw das quatro linhas suportadas não aumentam de E1 a E8. Os fatores de κ implementados são positivos e independentes de E; os mesmos limites 0,75fu/elástico e a divisão por √3 preservam a ordem.',
            'limitation':'E8 é envelope adotado, não classificação real por ciclos/espectro. Detalhes e modelo de tensões precisam de qualificação; interação é tratada somente pelo helper absoluto específico.'}


def elastic_allowables_autonomous(fy_mpa: float, fu_mpa: float, load_case: str) -> dict:
    """Automatic sourced branch; at ratio .70 adopt min of both one-sided limits."""
    from .stress_8400 import elastic_allowables_8400, NU_E
    fy=_number(fy_mpa,'fy',positive=True);fu=_number(fu_mpa,'fu',positive=True)
    if fy>fu or load_case not in NU_E:raise ValueError('Material/caso de solicitação inválido.')
    ratio=fy/fu
    if not math.isclose(ratio,.70,rel_tol=0,abs_tol=1e-12):
        result=elastic_allowables_8400(fy,fu,load_case)
        result['automatic_branch']=True;result['conservative_boundary']=False
        return result
    nu=NU_E[load_case]
    low=fy/nu;high=(fy+fu)/870.*(360./nu)
    cap=min(low,high)
    return {'fy_fu_ratio':ratio,'nu_e':nu,'sigma_a_mpa':cap,'tau_a_mpa':cap/math.sqrt(3),
            'reference_sigma_a_mpa':360./nu,'automatic_branch':True,'conservative_boundary':True,
            'branch_limits_mpa':(low,high),
            'clause':'5.2.1.1.1/2; Tabela 8; envelope mínimo declarado na fronteira fy/fu=0,70',
            'formula':'sigma_a = min[fy/nu_E; (fy+fu)/(360+510) * (360/nu_E)]',
            'limitation':'A igualdade não é atribuída expressamente a um ramo na fonte; o mínimo não excede qualquer limite lateral.'}


def _boundary_fatigue_result(data, previous):
    """Only the explicit legacy equality gap is replaced by a declared bound."""
    from .stress_8400 import (W0_LOW_MPA,W0_HIGH_MPA,K0_MPA,K4_MPA,LOW_GRADES,FATIGUE_DETAILS)
    elastic=elastic_allowables_autonomous(data.fy_mpa,data.fu_mpa,'I')
    ext=previous['intermediates'];k=ext['kappa'];detail=FATIGUE_DETAILS[data.detail_code]
    table=(W0_LOW_MPA if data.material_grade in LOW_GRADES else W0_HIGH_MPA) if data.detail_code=='W0' else (K0_MPA if data.detail_code=='K0_31' else K4_MPA)
    sw=table[int(data.group[1:])-1]
    compression=data.stress_kind=='normal' and ext['predominance']=='compression'
    raw=sw*(1.992 if compression else 1.66) if k>0 else (sw*2/(1-k) if compression else sw*5/(3-2*k))
    cap=min(raw,.75*data.fu_mpa,elastic['sigma_a_mpa'])
    if data.stress_kind=='shear':cap/=math.sqrt(3)
    demand=ext['absolute_max_mpa'];ok=demand<=cap
    previous['pending']=[]
    previous['intermediates'].update(sigma_w_mpa=sw,final_capacity_mpa=cap,
        elastic_case_i_sigma_a_mpa=elastic['sigma_a_mpa'],elastic_auto_branch=elastic,
        detail_reference=detail['source'])
    check={'id':'fatigue_component','name':'Fadiga: envelope na fronteira fy/fu=0,70',
        'status':'ATENDE NO DOMÍNIO' if ok else 'PENDENTE','demand':demand,'capacity':cap,
        'utilization':demand/cap,'unit':'MPa','source':'ABNT NBR 8400-2:2019, D.2; '+elastic['clause'],
        'formula':'Capacidade de fadiga limitada por '+elastic['formula'],
        'detail':'Envelope mínimo explicitamente adotado na fronteira não atribuída entre os dois ramos elásticos.'}
    if not ok:
        check['exceedance_policy']='requires_specific_assessment'
        previous['pending'].append('Envelope da fronteira elástica excedido; avaliação específica necessária.')
    previous['checks']=[check]
    previous['status']='RESULTADO PARCIAL' if ok else 'RESULTADO PARCIAL — ENVELOPE EXCEDIDO'
    previous['limitations'].append(elastic['limitation'])
    return previous


def evaluate_8400_envelope(loaded: PassageHistory | None, empty: PassageHistory | None, *,
        life_years: float, uses_per_year: float, loaded_passages_per_use: float,
        empty_passages_per_use: float, detail_id: str, fy_mpa: float, fu_mpa: float,
        thickness_mm: float, material_grade: str, component_group: str='E8_conservative',
        group_source: str='', fabrication: str='unqualified', single_component: bool=False,
        high_ratio_route: bool=False) -> dict:
    """Adopt E8 bound or documented group; always explicitly use positive-κ bound.

    No A/B/C → W/K translation: detail references are independently qualified.
    All E8-bound exceedances are pending, including κ<=0. A documented group's
    negative-κ exact route may retain its actual failure status.
    """
    from .stress_8400 import Fatigue8400Input,calculate_fatigue_8400,FATIGUE_DETAILS
    result=_base_result('autonomous_fatigue_8400')
    try:
        _flag(single_component,'Uma componente relevante');_flag(high_ratio_route,'Ramo fy/fu elevado')
        _number(fy_mpa,'fy',positive=True);_number(fu_mpa,'fu',positive=True);_number(thickness_mm,'Espessura',positive=True)
        _text(material_grade,'Grau do material',required=True)
        _text(component_group,'Grupo');_text(group_source,'Fonte do grupo');_text(fabrication,'Fabricação')
        env=same_point_lifetime_envelope(loaded,empty,life_years=life_years,uses_per_year=uses_per_year,
            loaded_passages_per_use=loaded_passages_per_use,empty_passages_per_use=empty_passages_per_use,
            required_basis='nbr8400_fatigue_case_i_without_mx')
        detail=_detail(detail_id,env['component'])
        if component_group not in ('E8_conservative','E1','E2','E3','E4','E5','E6','E7','E8'):
            raise ValueError('Grupo E desconhecido; não inferir de capacidade ou anos.')
    except ValueError as exc:
        result.update(input_valid=False,status='ENTRADA INVÁLIDA',errors=[str(exc)]);return result
    result['intermediates']=env
    code=detail['detail_8400']
    if code is None:result['pending'].append('Não há detalhe 8400 implementado correspondente; não converter categoria 8800.')
    if fabrication!='specified_h6_qc':result['pending'].append('Especificar qualidade de fabricação aplicável, incluindo Q.C. dos filetes da rota 8400.')
    if code in ('K0_31','K4_41') and thickness_mm>50:
        result['pending'].append('Chapa soldada acima de 50 mm requer experiência do fabricante e definição especializada da qualidade/ensaios, conforme 8400-2, 5.1.4(b); não abrangida pelo preset de fabricação.')
    if not single_component:result['pending'].append('D.2.3 permanece pendente quando há mais de uma componente relevante de fadiga.')
    conservative=component_group=='E8_conservative'
    if not conservative and not group_source.strip():result['pending'].append('Grupo E real exige classificação documentada por ciclos e espectro.')
    if result['pending']:return result
    proof=e8_envelope_justification()
    if conservative and not proof['monotonic_verified']:
        result['pending'].append('Não foi demonstrada a ordem conservadora das capacidades E8.');return result
    physical=FATIGUE_DETAILS[code]
    data=Fatigue8400Input(name=detail['label'],fy_mpa=fy_mpa,fu_mpa=fu_mpa,thickness_mm=thickness_mm,
        material_grade=material_grade,material_source='Aço/propriedades de projeto na espessura informada',
        group='E8' if conservative else component_group,
        group_source=proof['proof']+' E8 adotado, não classificação real.' if conservative else group_source,
        detail_code=code,detail_source=physical['source']+'; '+detail['criteria'],
        load_direction=physical['direction'],weld_quality=physical['weld_quality'],
        stress_kind='shear' if env['component']=='shear' else 'normal',
        stress_a_mpa=env['sigma_min_mpa'],stress_b_mpa=env['sigma_max_mpa'],point_id=env['point_id'],
        stress_source='Históricos completos e convergidos no mesmo ponto; componentes locais/torção/empenamento incluídas',
        action_basis='nbr8400_fatigue_case_i_no_Mx',action_source='Caso I operacional, separado do ELU 8800',
        factors_source='autonomous_actions.factors_10084(fatigue_8400): ψ preservado, Mx ausente',
        positive_kappa_route='conservative_zero_envelope',conservative_envelope_selected=True,
        same_point_history_confirmed=True,group_classification_confirmed=True,
        construction_detail_confirmed=True,fabrication_quality_confirmed=True,single_component_confirmed=True,
        case_i_no_Mx_confirmed=True,buckling_factor_excluded=True,local_effects_included=True,
        high_ratio_route_confirmed=(isinstance(fy_mpa,(int,float)) and not isinstance(fy_mpa,bool) and isinstance(fu_mpa,(int,float)) and not isinstance(fu_mpa,bool) and fu_mpa>0 and fy_mpa/fu_mpa>.70))
    result=calculate_fatigue_8400(data)
    boundary_error='fy/fu=0,70: fronteira não atribuída expressamente em 5.2.1.1.1/2; qualificação externa necessária.'
    if result.get('input_valid') and result.get('pending')==[boundary_error]:
        result=_boundary_fatigue_result(data,result)
    if result.get('checks'):
        result['intermediates']['elastic_auto_branch']=elastic_allowables_autonomous(fy_mpa,fu_mpa,'I')
    result['kind']='autonomous_fatigue_8400'
    result['intermediates']['passage_envelope']=env
    result['intermediates']['group_adoption']=proof if conservative else {'is_actual_classification':True,'group':component_group,'source':group_source}
    result['limitations']+=env['limitations']
    if conservative:
        result['limitations'].append('E8 adotado como envelope conservador dos detalhes suportados; não é classificação real do componente.')
        for check in result['checks']:
            check['name']='Envelope E8 de fadiga da componente no ponto'
            if check['status']=='NÃO ATENDE':
                check['status']='PENDENTE';check['exceedance_policy']='requires_specific_assessment'
                check['detail']='Envelope E8 excedido; classificar componente/espectro e realizar avaliação específica.'
                result['pending'].append(check['detail']);result['status']='RESULTADO PARCIAL — ENVELOPE EXCEDIDO'
    return result


@dataclass(frozen=True)
class FatigueAbsoluteBounds:
    """Absolute component limits for ONE material region, not a time history.

    A bound may be spatially uniform over a larger region, but all three limits
    must cover every considered point, operating case and time in that region.
    complete means the supplying model includes all applicable global AND local
    components. It is a computed model-coverage fact, not a user approval flag.
    A nominal section approximation cannot assert complete merely because all
    its own terms were calculated. Shear is a magnitude bound; no sign is needed.
    """
    region_id: str = ''
    sigma_longitudinal_abs_mpa: float = 0.0
    sigma_transverse_abs_mpa: float = 0.0
    shear_abs_mpa: float = 0.0
    action_basis: str = ''
    complete: bool = False
    source: str = ''
    # Optional proven interval, e.g. compression -C plus bending +/-T.
    # It is a set of admissible values, never a fabricated ordered history.
    transverse_interval_mpa: tuple[float,float] | None = None
    interval_source: str = ''
    longitudinal_interval_mpa: tuple[float,float] | None = None


FATIGUE_BOUND_PROFILES = {
    'unnotched_base': {
        'label':'Metal-base homogêneo afastado de juntas e entalhes',
        'longitudinal':'W0','transverse':'W0',
        'source':'Tabela D.4, caso W0, p.68; D.2.2',
        'criteria':'Material-base sem junta/descontinuidade/entalhe no domínio avaliado; não é metal da solda.',
    },
    'stiffener_load_transfer_fillet_base': {
        'label':'Metal-base no encontro cruciforme e na transferência do enrijecedor por filetes Q.C.',
        'longitudinal':'K4_4','transverse':'K4_5',
        'source':'Tabela D.5, casos K4,4 e K4,5, p.77; envelope K4 das normais; D.2.2',
        'criteria':'Par de chapas de altura total, filetes Q.C. contínuos nos dois lados, ligados à alma e às duas mesas; cruzamento de chapas e transferência por flexão/cisalhamento. Categoria K4 adotada para ambas as normais; não é equivalência automática com categoria C da NBR8800.',
    },
    'web_flange_fillet_adjacent_base': {
        'label':'Material-base da alma adjacente aos filetes longitudinais contínuos das duas mesas',
        'longitudinal':'K0_31','transverse':'K4_41',
        'source':'Tabela D.5, casos K0,31 (p.69) e K4,41 (p.77); D.2.2',
        'criteria':'Filete Q.C. contínuo; normal longitudinal paralela à solda; normal transversal no plano da alma sob carga concentrada perpendicular à solda. Encontros de acessórios, filetes interrompidos e términos de lamelas exigem detalhe próprio. A extremidade comum das partes contínuas conserva execução e acabamento do AnexoB. Não cobre garganta, raiz ou metal depositado.',
    },
}


def explicit_component_group_selection(component_group: str, group_source: str = '') -> dict:
    """Record an E1–E8 choice without inventing an operational classification.

    Blank legacy origins mean an ordinary manual code selection. A nonblank
    imported origin retains its historical meaning as a declared, documented
    classification; this helper does not independently verify that document.
    Neither path proves a finite-life cycle count or derives a stress history.
    The project/JSON fields themselves are left untouched.
    """
    _text(component_group,'Grupo do componente');_text(group_source,'Origem do grupo')
    if component_group not in tuple(f'E{i}' for i in range(1,9)):
        raise ValueError('Grupo de componente inválido: selecione E1 a E8.')
    documented=bool(group_source.strip())
    return dict(component_group=component_group,
        provenance='documented_input' if documented else 'manual_input',
        source=group_source if documented else 'Selecionado no cálculo pelo usuário; sem derivação de ciclos ou espectro.',
        is_actual_classification=documented,classification_verified=False,
        classification_derived_from_history=False,finite_life_cycle_proof=False,
        method='Grupo de componente declarado no projeto com origem registrada.' if documented else
            'Grupo E selecionado no cálculo; não representa classificação operacional verificada nem prova de vida finita.')


def evaluate_8400_absolute_envelope(bounds: FatigueAbsoluteBounds, *, profile: str,
        fy_mpa: float, fu_mpa: float, thickness_mm: float, material_grade: str,
        fabrication: str = 'unqualified', component_group: str = 'E8_conservative',
        group_source: str = '') -> dict:
    """Sufficient selected-group, all-kappa combined base-material bound.

    Primary corrected source PDF pp.74–75 (printed pp.62–63), Eq. D.5, was
    re-rendered and independently visually verified. Its cross term is the
    PRODUCT sigma_x*sigma_y/(|sigma_xa|*|sigma_ya|), not a malformed subtraction
    in the denominator. For |u|<=rx, |v|<=ry, |t|<=rt:
       u²+v²-u*v+t² <= rx²+ry²+rx*ry+rt².
    This also avoids assuming the separate component maxima are concurrent.
    The continuation explicitly permits combining component maxima and the
    most unfavorable kappa. The individual inequalities are retained.

    For -1<=kappa<=0, D.1/D.2 multipliers are >=1. For kappa>0 the separately
    justified zero-ratio conservative envelope is >=sigma_w before shared caps.
    Consequently min(sigma_w(E8),.75fu,sigma_a(case I)) is a sufficient normal
    capacity for any supported E1–E8 and kappa; base shear divides the W0 minimum
    by sqrt(3), D.2.2. No repair or interpolation of the malformed D.3 is used.
    Group E8 accounts for the most demanding supported cycle/spectrum group;
    it is neither an actual equipment classification nor an infinite-life claim.
    An exceeded upper envelope is PENDENTE, never actual structural failure.
    """
    from .stress_8400 import LOW_GRADES,HIGH_GRADES,W0_LOW_MPA,W0_HIGH_MPA,K0_MPA,K4_MPA
    result=_base_result('autonomous_fatigue_8400_absolute_envelope')
    try:
        if not isinstance(bounds,FatigueAbsoluteBounds):raise ValueError('Limites devem ser FatigueAbsoluteBounds.')
        _text(bounds.region_id,'Região material',required=True)
        _text(bounds.source,'Origem dos limites',required=True)
        _text(bounds.action_basis,'Base de ações',required=True)
        _flag(bounds.complete,'Cobertura dos limites')
        _text(bounds.interval_source,'Origem do intervalo')
        for interval,absolute,label in ((bounds.transverse_interval_mpa,bounds.sigma_transverse_abs_mpa,'transversal'),
                                        (bounds.longitudinal_interval_mpa,bounds.sigma_longitudinal_abs_mpa,'longitudinal')):
            if interval is None:continue
            if not isinstance(interval,(tuple,list)) or len(interval)!=2 or any(isinstance(v,bool) or not isinstance(v,(int,float)) or not math.isfinite(v) for v in interval) or interval[0]>interval[1]:
                raise ValueError('Intervalo '+label+' deve conter dois limites finitos ordenados.')
            if not bounds.interval_source.strip():raise ValueError('Intervalo exige demonstração da origem e sinais.')
            interval_absolute_limit=_number(absolute,'Limite absoluto '+label)
            if max(map(abs,interval))>interval_absolute_limit+1e-10*max(1.,interval_absolute_limit):raise ValueError('Intervalo excede o limite absoluto '+label+' informado.')
        sx=_number(bounds.sigma_longitudinal_abs_mpa,'Limite absoluto longitudinal')
        sy=_number(bounds.sigma_transverse_abs_mpa,'Limite absoluto transversal')
        tau=_number(bounds.shear_abs_mpa,'Limite absoluto de cisalhamento')
        fy=_number(fy_mpa,'fy',positive=True);fu=_number(fu_mpa,'fu',positive=True)
        thickness=_number(thickness_mm,'Espessura',positive=True)
        _text(profile,'Perfil de detalhe');_text(material_grade,'Grau do material',required=True)
        _text(fabrication,'Fabricação');_text(component_group,'Grupo do componente');_text(group_source,'Origem do grupo')
        if component_group not in ('E8_conservative',*(f'E{i}' for i in range(1,9))):raise ValueError('Grupo de componente inválido.')
        if fy>fu:raise ValueError('fy não pode exceder fu.')
        if profile not in FATIGUE_BOUND_PROFILES:raise ValueError('Perfil físico de fadiga combinada não implementado.')
        if bounds.action_basis!='nbr8400_fatigue_case_i_without_mx':raise ValueError('Fadiga exige caso I sem Mx e sem fator de flambagem, com dinâmica aplicável.')
    except ValueError as exc:
        result.update(input_valid=False,status='ENTRADA INVÁLIDA',errors=[str(exc)]);return result
    detail=FATIGUE_BOUND_PROFILES[profile]
    result['input']=dict(bounds=asdict(bounds),profile=profile,fy_mpa=fy,fu_mpa=fu,
        thickness_mm=thickness,material_grade=material_grade,fabrication=fabrication,component_group=component_group,group_source=group_source)
    group='E8' if component_group=='E8_conservative' else component_group
    selection=(dict(component_group='E8',provenance='conservative_envelope',
        source='E8 adotado como envelope conservador dos grupos E1–E8.',
        is_actual_classification=False,classification_verified=False,
        classification_derived_from_history=False,finite_life_cycle_proof=False)
        if component_group=='E8_conservative' else explicit_component_group_selection(component_group,group_source))
    result['group_selection']=selection
    if material_grade not in LOW_GRADES+HIGH_GRADES or not 370<=fu<=520:
        result['pending'].append('Anexo D limitado aos graus S235/S275/S355/ASTM A36/ASTM A572 GR50 e 370 ≤ fu ≤ 520 MPa; não inferir equivalência de material.')
    if not bounds.complete:
        result['pending'].append('O modelo não demonstrou cobertura dos limites absolutos de todas as componentes globais e locais na região; a prova de interação não supre efeitos ausentes.')
    allowed_fabrication=('specified_h6','specified_h6_qc') if profile=='unnotched_base' else ('specified_h6_qc',)
    if fabrication not in allowed_fabrication:
        result['pending'].append('Especificar fabricação aplicável e Q.C. quando houver filetes; esta rota não verifica garganta/raiz do cordão.')
    if profile!='unnotched_base' and thickness>50:
        result['pending'].append('Chapa soldada acima de 50 mm exige qualificação especializada de fabricação/ensaios, NBR 8400-2, 5.1.4(b).')
    if not e8_envelope_justification()['monotonic_verified']:
        result['pending'].append('Ordem conservadora E1–E8 não demonstrada para as linhas selecionadas.')
    result['limitations']=[detail['criteria'],
        'Limites absolutos, não histórico artificial [−B,+B]; não há contagem fictícia de ciclos nem uso de cisalhamento sem sinal como série.',
        ('E8 é envelope de todos os grupos suportados E1–E8, sem classificação real e sem alegação de vida infinita.' if component_group=='E8_conservative' else
         'Capacidades condicionadas ao grupo '+group+' declarado com origem registrada: '+group_source if selection['is_actual_classification'] else
         'Capacidades do grupo '+group+' selecionado no cálculo; a seleção não comprova ciclos, espectro ou vida finita.'),
        'Fabricação especificada é requisito de projeto a impor na execução e inspeção, não declaração de inspeção já realizada.',
        'O domínio material deve corresponder simultaneamente às direções/detalhes indicados; soldas, fixações e regiões diferentes exigem verificações próprias.',
        'A suficiência é condicional à validade e completude dos limites de tensão fornecidos para o modelo físico.',
        'Exceder o envelope requer avaliação específica do grupo, razões κ, concomitância e/ou modelo; não demonstra falha real.']
    result['domain_pending']=list(result['pending'])
    result['criterion_exceedances']=[]
    if result['domain_pending']:return result
    result['domain_complete']=True
    elastic=elastic_allowables_autonomous(fy,fu,'I')
    index=int(group[1:])-1
    w0=(W0_LOW_MPA if material_grade in LOW_GRADES else W0_HIGH_MPA)[index]
    sw={'W0':w0,'K0_31':K0_MPA[index],'K4_41':K4_MPA[index],'K4_4':K4_MPA[index],'K4_5':K4_MPA[index]}
    cap=lambda code:min(sw[code],.75*fu,elastic['sigma_a_mpa'])
    cx,cy,ct=cap(detail['longitudinal']),cap(detail['transverse']),cap('W0')/math.sqrt(3)
    longitudinal_interval_result=None
    if bounds.longitudinal_interval_mpa is not None:
        longitudinal_interval_result=normal_interval_ratio_bound(*bounds.longitudinal_interval_mpa,
            sigma_w_mpa=sw[detail['longitudinal']],static_normal_cap_mpa=min(.75*fu,elastic['sigma_a_mpa']))
        sx=longitudinal_interval_result['absolute_bound_mpa'];cx=longitudinal_interval_result['equivalent_capacity_mpa']
    interval_result=None
    if bounds.transverse_interval_mpa is not None:
        interval_result=normal_interval_ratio_bound(*bounds.transverse_interval_mpa,
            sigma_w_mpa=sw[detail['transverse']],static_normal_cap_mpa=min(.75*fu,elastic['sigma_a_mpa']))
        sy=interval_result['absolute_bound_mpa'];cy=interval_result['equivalent_capacity_mpa']
    rx,ry,rt=sx/cx,sy/cy,tau/ct
    quadratic=rx*rx+ry*ry+rx*ry+rt*rt
    source='ABNT NBR 8400-2:2019, versão corrigida 20.10.2022, D.2.1–D.2.3, Eq. D.5 e continuação pp.62–63; '+detail['source']
    checks=[]
    for ident,label,demand,capacity,unit,formula in (
        ('fatigue_bound_longitudinal','Envelope E8 longitudinal',sx,cx,'MPa','|sigma_x| <= min[sigma_w(E8, detalhe x), 0.75fu, sigma_a(I)]'),
        ('fatigue_bound_transverse','Envelope E8 transversal',sy,cy,'MPa','|sigma_y| <= min[sigma_w(E8, detalhe y), 0.75fu, sigma_a(I)]'),
        ('fatigue_bound_shear','Envelope E8 de cisalhamento no material-base',tau,ct,'MPa','|tau| <= min[sigma_w(E8,W0), 0.75fu, sigma_a(I)] / sqrt(3)'),
        ('fatigue_bound_combined','Interação conservadora de fadiga E8',math.sqrt(quadratic),1.,'—','sqrt(rx^2 + ry^2 + rx*ry + rt^2) <= 1')):
        ok=demand<=capacity
        label=label.replace('E8',group)
        formula=formula.replace('E8',group)
        if ident=='fatigue_bound_transverse' and interval_result is not None:
            formula=interval_result['formula']
        if ident=='fatigue_bound_longitudinal' and longitudinal_interval_result is not None:
            formula=longitudinal_interval_result['formula']
        check=dict(id=ident,name=label,status='ATENDE NO DOMÍNIO' if ok else 'PENDENTE',
            demand=demand,capacity=capacity,utilization=demand/capacity,unit=unit,source=source,formula=formula,
            detail='ATENDE AO ENVELOPE CONSERVADOR' if ok else 'ENVELOPE EXCEDIDO; avaliação específica necessária.')
        if not ok:check['exceedance_policy']='requires_specific_assessment'
        checks.append(check)
    result['checks']=checks
    result['intermediates']=dict(capacities_mpa=dict(longitudinal=cx,transverse=cy,shear=ct),
        ratios=dict(longitudinal=rx,transverse=ry,shear=rt),interaction_squared=quadratic,
        adopted_group=group,is_actual_classification=selection['is_actual_classification'],group_source=selection['source'],
        group_adoption=selection,adopted_minimum_kappa=-1. if interval_result is None and longitudinal_interval_result is None else None,
        transverse_interval_bound=interval_result,longitudinal_interval_bound=longitudinal_interval_result,interval_source=bounds.interval_source,
        elastic=elastic,profile=detail,source=source,
        proof='u²+v²−uv+t² ≤ rx²+ry²+rx ry+rt²; |u|≤rx, |v|≤ry, |t|≤rt. Capacidade mínima do grupo '+group+' em κ=−1 preservada pelos limites estáticos comuns.',
        uses_fabricated_history=False,requires_cycle_count=False,infinite_life_claim=False)
    if any(c['status']=='PENDENTE' for c in checks):
        result['criterion_exceedances']=[c['id'] for c in checks if c.get('exceedance_policy')=='requires_specific_assessment']
        result['pending'].append('Envelope combinado '+group+' ou limite individual excedido; avaliação específica necessária.')
        result['status']='RESULTADO PARCIAL — ENVELOPE EXCEDIDO'
    else:result['status']='ATENDE AO ENVELOPE CONSERVADOR'
    return result


def classify_component_group_p4(cycles_upper_bound: float, *, source: str) -> dict:
    """Conservative all-spectrum group from an independently established N.

    Table 11 was visually rechecked at 220 dpi: P3 really is nonmonotone at
    B6/B7/B8 and P4,B2 really is E2. No silent correction is made. The P4 row
    equals the largest printed group in each column and is nondecreasing, so it
    conservatively covers EVERY printed P1–P4 row for that usage class. This
    avoids using the uncertain interior P3 entries or estimating an unobserved
    load spectrum. It does not establish the number of stress cycles per use.
    """
    n=_number(cycles_upper_bound,'Limite de ciclos de tensão no ponto')
    _text(source,'Origem da contagem de ciclos',required=True)
    limits=(16000,32000,63000,125000,250000,500000,1000000,2000000,4000000,8000000)
    index=next((i for i,limit in enumerate(limits) if n<=limit),10)
    groups=(1,2,2,4,5,6,7,8,8,8,8)
    return dict(cycles_upper_bound=n,usage_class='B'+str(index),adopted_spectrum='P4_conservative',
        component_group='E'+str(groups[index]),is_actual_spectrum_classification=False,is_actual_classification=False,
        source='ABNT NBR 8400-1:2019, 6.1.4.2–6.1.4.4, Tabelas 9–11, pp.16–18',
        cycle_count_source=source,
        proof='P4 é o maior grupo impresso em cada coluna da Tabela 11 e sua sequência é não decrescente. O limite N seleciona a classe B, sem classificar automaticamente o equipamento.',
        limitations=('N refere-se a ciclos de tensão NO PONTO, não automaticamente a usos, içamentos, passagens ou número de rodas.',
            'Classe P4 é envelope conservador de espectro; não é espectro medido nem vida infinita.',
            'Os valores impressos incomuns não foram corrigidos: a rastreabilidade da edição permanece explícita.'))


def component_group_from_explicit_use(*,life_years: float,uses_per_year: float,
        stress_cycles_per_use: float,source: str) -> dict:
    """User/model supplies cycles per use; wheel count is never silently used."""
    years=_number(life_years,'Vida útil',positive=True)
    uses=_number(uses_per_year,'Usos por ano',positive=True)
    cycles=_number(stress_cycles_per_use,'Ciclos de tensão por uso',positive=True)
    total=years*uses*cycles
    if not math.isfinite(total) or total>1e12:raise ValueError('Contagem total de ciclos fora do domínio.')
    result=classify_component_group_p4(math.ceil(total),source=source)
    result.update(life_years=years,uses_per_year=uses,stress_cycles_per_use=cycles,
        cycles_raw=total,formula='N = ceil(anos × usos/ano × ciclos de tensão no ponto por uso)')
    return result


def normal_interval_ratio_bound(lower_mpa: float,upper_mpa: float,*,
        sigma_w_mpa: float,static_normal_cap_mpa: float) -> dict:
    """Bound |sigma_extreme|/allowable for ANY history inside [lower,upper].

    Let A=max(-lower,0), B=max(upper,0). For mixed-sign extrema, D.1 gives
    utilization (3p+2n)/(5sw) when p>=n; p<=B and n<=min(A,B). D.2 gives
    (n+p)/(2sw) when n>=p; n<=A and p<=min(A,B). Same-sign histories use the
    independently qualified conservative kappa=0 capacities 1.66sw (tension)
    and 1.992sw (compression). Shared static limits contribute max(A,B)/cap.
    The maximum of these bounds is sufficient without choosing an artificial
    kappa or time order. An equivalent capacity is supplied solely to report
    that utilization against the absolute demand; it is not a new S-N curve.
    """
    for v,name in ((lower_mpa,'Limite inferior'),(upper_mpa,'Limite superior')):
        if isinstance(v,bool) or not isinstance(v,(int,float)) or not math.isfinite(v):raise ValueError(name+': número finito obrigatório.')
    if lower_mpa>upper_mpa:raise ValueError('Limites de intervalo invertidos.')
    sw=_number(sigma_w_mpa,'σw',positive=True)
    cap=_number(static_normal_cap_mpa,'Limite estático normal',positive=True)
    a=max(0.,-lower_mpa);b=max(0.,upper_mpa);m=max(a,b);both=min(a,b)
    ratios=dict(mixed_tension=(3*b+2*both)/(5*sw),mixed_compression=(a+both)/(2*sw),
        same_sign_tension=b/(1.66*sw),same_sign_compression=a/(1.992*sw),static_cap=m/cap)
    upper=max(ratios.values())
    effective=m/upper if upper>0 else min(sw,cap)
    return dict(interval_mpa=(float(lower_mpa),float(upper_mpa)),absolute_bound_mpa=m,
        utilization_upper_bound=upper,equivalent_capacity_mpa=effective,branches=ratios,
        source='ABNT NBR 8400-2:2019, D.2.1, D.1/D.2; envelope κ positivo: D.2.1 e exemplo D.4.2.2.1(a), p.81',
        formula='r <= max[(3B+2min(A,B))/(5sw); (A+min(A,B))/(2sw); B/(1.66sw); A/(1.992sw); max(A,B)/static_cap]',
        proof='A=max(-lower,0), B=max(upper,0); maximização de cada ramo sobre extremos possíveis do intervalo. Não supõe que os extremos aconteçam simultaneamente nem cria série.',
        uses_fabricated_history=False)
