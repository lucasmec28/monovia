"""Streamlit front end for the autonomous calculation domain."""
from dataclasses import asdict
import json
import streamlit as st
from .autonomous_model import AutonomousProject,validate_autonomous,physical_premises
from .autonomous_actions import ActionApplicability
from .autonomous_rail import get_rail_profile,CATALOG
from .autonomous_ui_inputs import render_autonomous_inputs,reset_autonomous_inputs
from .crane_catalog_ui import render_catalog_assistant,reset_catalog_inputs
from .equipment_basis import equipment_basis_summary
from .autonomous_engine import calculate_core
from .autonomous_local import stiffener_positions_mm
from .autonomous_result import input_signature
from .autonomous_export import export_csv,export_word,export_calculation_json,result_rows,LABELS
from .runway_views import ViewGeometry,elevation_png,plan_png,section_png,isometric_png
from .visual_identity import render_app_header
from . import __version__
from .document_metadata import DOCUMENT_FIELDS, validate_document_metadata
from .autonomous_numerical_controls import (REFINEMENT_BUDGETS, default_calculation_controls,
    validate_calculation_controls, unpack_legacy_project_document, legacy_project_document,
    calculate_with_controls, result_matches_controls, numerical_word_cache_signature)

TOP_UNSTIFFENED_ROUTE = 'Ponte apoiada · cálculo interno'
UNDERSLUNG_AUTONOMOUS_ROUTE = 'Ponte suspensa · cálculo interno'
LEGACY_TOP_ROUTE = 'Ponte apoiada · trilho na mesa superior'
LOCAL_AUXILIARY_ROUTE = 'Ponte suspensa · verificação local com esforços externos'

# Keep the persisted route identifiers above stable. Only display labels change;
# switching routes does not migrate a project or replace either route's inputs.
ROUTE_LABELS = {
    TOP_UNSTIFFENED_ROUTE: 'TOP · Ponte apoiada · cálculo interno atual',
    UNDERSLUNG_AUTONOMOUS_ROUTE: 'UNDER · Ponte suspensa · cálculo interno atual',
    LEGACY_TOP_ROUTE: 'LEGADO · Ponte apoiada · modelo anterior',
    LOCAL_AUXILIARY_ROUTE: 'AUXILIAR · Mesa inferior · esforços externos',
}


def demonstration_project():
    p=AutonomousProject();p.upper_braces_m=[2.,4.]
    # New UI projects use the requested editable assumption. Deserialization
    # remains unchanged: an imported unknown/on-runway choice is never replaced.
    p.action_applicability=ActionApplicability(environment='indoor_sheltered',bumper_load_path='independent_support',test_location='outside_this_segment')
    return p


def drawing_geometry(p):
    s=p.section
    offsets=[w.offset_m for w in p.wheels];shift=(p.span_m-(max(offsets)-min(offsets)))/2-min(offsets)
    pictured=[(i,w,shift+w.offset_m) for i,w in enumerate(p.wheels) if 0<=shift+w.offset_m<=p.span_m]
    positions=tuple(x for i,w,x in pictured)
    nodes=sorted({0.,p.span_m,*p.upper_braces_m})
    segment=max(zip(nodes[:-1],nodes[1:]),key=lambda ab:ab[1]-ab[0])
    profile=get_rail_profile(p.rail.catalog_id) if p.rail.shape==CATALOG else None
    rail_drawing={} if profile is None else dict(rail_head_width_mm=profile.head_width_mm,rail_web_thickness_mm=profile.web_thickness_mm,rail_head_height_mm=profile.head_height_mm,rail_foot_height_mm=profile.foot_height_mm)
    return ViewGeometry(**rail_drawing,span_m=p.span_m,depth_mm=s.d_mm,top_width_mm=s.bf_mm,bottom_width_mm=s.bottom_width,
        flange_thickness_mm=s.tf_mm,web_thickness_mm=s.tw_mm,rail_height_mm=p.rail.height_mm,rail_width_mm=p.rail.width_mm,
        wheel_positions_m=positions,brace_positions_m=tuple(p.upper_braces_m),highlighted_segment=segment,
        wheel_loads_kN=tuple(w.dead_kn+w.lifted_kn for i,w,x in pictured),wheel_labels=tuple('R'+str(i+1) for i,w,x in pictured),
        wheel_load_basis='G + Q característicos; sem dinâmica ou majoração',
        bridge_span_m=p.equipment_basis.bridge_span_m,
        wheelbase_m=(max(offsets)-min(offsets)) if len(offsets)==2 else None,
        view_case_label='Posição ilustrativa do trem; não representa caso crítico',
        lower_brace_positions_m=tuple(p.lower_braces_m),lateral_only_positions_m=tuple(p.lateral_only_braces_m),lateral_only_level=p.lateral_only_brace_level,
        rail_profile_label=profile.designation if profile else "",
        bottom_flange_thickness_mm=s.bottom_thickness,rail_offset_mm=p.rail.offset_from_web_mm,
        wheel_lateral_offset_mm=p.rail.lateral_eccentricity_mm,beam_end_left_mm=p.beam_end_left_mm,beam_end_right_mm=p.beam_end_right_mm,
        stiffener_positions_m=tuple(x/1000 for x in stiffener_positions_mm(p)),stiffener_thickness_mm=p.stiffener_thickness_mm,stiffener_outstand_mm=p.stiffener_outstand_mm)


@st.cache_data(show_spinner=False)
def _views(serialized):
    p=AutonomousProject.from_json(serialized);g=drawing_geometry(p)
    return [('Elevação',elevation_png(g)),('Planta',plan_png(g)),('Seção transversal',section_png(g)),('Isométrica',isometric_png(g))]


def run():
    st.set_page_config(page_title='LRO · Viga de rolamento',layout='wide')
    render_app_header(st, __version__)
    if st.session_state.get('runway_calculation_route')=='Ponte apoiada · sem enrijecedores · cálculo interno':
        st.session_state['runway_calculation_route']=TOP_UNSTIFFENED_ROUTE
    route=st.radio('Rota de cálculo', [TOP_UNSTIFFENED_ROUTE, UNDERSLUNG_AUTONOMOUS_ROUTE, LEGACY_TOP_ROUTE, LOCAL_AUXILIARY_ROUTE], key='runway_calculation_route', horizontal=True, format_func=ROUTE_LABELS.get)
    previous_route=st.session_state.get('runway_previous_route',route)
    if previous_route!=route and route==LEGACY_TOP_ROUTE:
        reset_autonomous_inputs()
    st.session_state['runway_previous_route']=route
    if route==TOP_UNSTIFFENED_ROUTE:
        from top_unstiffened_candidate.ui import run as run_unstiffened
        run_unstiffened(embedded=True)
        return
    if route==UNDERSLUNG_AUTONOMOUS_ROUTE:
        from underslung_runway_candidate.autonomous_ui.ui import render
        render(st)
        return
    if route==LOCAL_AUXILIARY_ROUTE:
        st.caption('Ferramenta local complementar. Não substitui a rota suspensa com cálculo interno das ações e respostas.')
        from .underslung_local_ui import render_underslung_local
        render_underslung_local()
        return
    st.warning('Modo LEGADO: modelo anterior, mantido para estudos e arquivos compatíveis. Para o cálculo atual TOP, com ou sem intermediários, selecione a primeira opção. Os projetos das rotas são separados; mudar de opção não converte nem substitui suas entradas.')
    st.caption('Neste modo, apoios laterais adicionais são vínculos físicos e alteram esforços e deslocamentos. Para informar apenas comprimentos de flambagem, use TOP · cálculo interno atual → Modelo e fontes → Comprimentos de flambagem para verificação da resistência. Os créditos não qualificados do modelo anterior permanecem pendentes.')
    st.info('Escopo deste módulo: ponte apoiada, com rodas sobre trilho na mesa superior da viga de rolamento. Não abrange ponte suspensa com rodas na mesa inferior nem sua ligação suspensa às vigas de piso.')
    if 'auto_initial' not in st.session_state:st.session_state.auto_initial=demonstration_project()
    with st.expander('Abrir ou salvar projeto'):
        upload=st.file_uploader('Projeto JSON',type=['json'],key='auto_upload')
        if upload and st.button('Abrir projeto enviado'):
            try:
                raw,metadata,controls=unpack_legacy_project_document(json.loads(upload.getvalue()))
                loaded=AutonomousProject.from_json(json.dumps(raw))
                errors=validate_autonomous(loaded)
                if errors:raise ValueError('; '.join(errors))
                st.session_state.auto_initial=loaded
                st.session_state['auto_document_metadata']=metadata
                st.session_state['auto_calculation_controls']=controls
                st.session_state.pop('auto_max_refinements',None)
                st.session_state.pop('auto_budget_changed',None)
                st.session_state.pop('auto_calculation_timing',None)
                for key in list(st.session_state):
                    if isinstance(key,str) and key.startswith('auto_document:'):del st.session_state[key]
                reset_autonomous_inputs();reset_catalog_inputs();st.session_state.pop('auto_catalog_previous',None);st.session_state.pop('auto_result',None);st.session_state.pop('auto_word',None);st.rerun()
            except (ValueError,TypeError,KeyError,json.JSONDecodeError) as e:st.error('Não foi possível abrir: '+str(e))
        if st.button('Restaurar demonstração'):
            st.session_state.auto_initial=demonstration_project()
            st.session_state['auto_document_metadata']={}
            st.session_state['auto_calculation_controls']=default_calculation_controls()
            st.session_state.pop('auto_max_refinements',None)
            st.session_state.pop('auto_budget_changed',None)
            st.session_state.pop('auto_calculation_timing',None)
            for key in list(st.session_state):
                if isinstance(key,str) and key.startswith('auto_document:'):del st.session_state[key]
            reset_autonomous_inputs();reset_catalog_inputs();st.session_state.pop('auto_catalog_previous',None);st.session_state.pop('auto_result',None);st.session_state.pop('auto_word',None);st.rerun()
    metadata=dict(st.session_state.get('auto_document_metadata',{}))
    with st.expander('Identificação da memória · sem alterar o cálculo'):
        st.caption('Identificação documental informada pelo usuário. Não confirma o equipamento nem transforma uma demonstração em projeto.')
        for name,label in DOCUMENT_FIELDS.items():
            value=st.text_input(label,value=metadata.get(name,''),max_chars=500,key='auto_document:'+name).strip()
            if value:metadata[name]=value
            else:metadata.pop(name,None)
    try:metadata=validate_document_metadata(metadata)
    except ValueError as exc:
        st.error(str(exc));return
    if metadata!=st.session_state.get('auto_document_metadata',{}):st.session_state.pop('auto_word',None)
    st.session_state['auto_document_metadata']=metadata
    assistant_slot=st.container()
    p=render_autonomous_inputs(st.session_state.auto_initial)
    # Keep the complete edited model outside widget lifetime. Streamlit removes
    # hidden widgets on route switches; returning rebuilds them from this copy.
    from copy import deepcopy
    st.session_state.auto_initial=deepcopy(p)
    with assistant_slot:
        replacement=render_catalog_assistant(p)
    if replacement is not None:
        st.session_state.auto_initial=replacement
        reset_autonomous_inputs()
        st.session_state.pop('auto_result',None)
        st.session_state.pop('auto_word',None)
        st.rerun()
    errors=validate_autonomous(p)
    if p.demonstration and st.button('Adotar entradas atuais como premissas do projeto',help='Declara a adoção das entradas atuais. Não confirma o fabricante nem o atendimento estrutural.',disabled=bool(errors)):
        p.demonstration=False
        st.session_state.auto_initial=p
        reset_autonomous_inputs();reset_catalog_inputs()
        st.session_state.pop('auto_result',None);st.session_state.pop('auto_word',None)
        st.rerun()
    if p.demonstration:st.info('Modelo de demonstração: a viga e as condições ainda são exemplos. Confira e adote explicitamente as entradas do projeto; uma referência de catálogo não identifica o equipamento real.')
    if p.equipment_basis.status!='manual':
        st.caption('Origem do equipamento: '+equipment_basis_summary(p)[0][1]+'. Veja as hipóteses e fontes no assistente e na memória.')
    with st.expander('Modelo físico e premissas adotadas'):
        for text in physical_premises(p):st.write('• '+text)
    if errors:
        for text in errors:st.error(text)
        return
    serialized=json.dumps(p.to_dict(),sort_keys=True,ensure_ascii=False,allow_nan=False)
    views=_views(serialized)
    tabs=st.tabs([title for title,_ in views])
    for tab,(_,png) in zip(tabs,views):
        with tab:st.image(png,width='stretch')
    controls=validate_calculation_controls(st.session_state.get('auto_calculation_controls',default_calculation_controls()))
    budget=st.selectbox('Orçamento numérico · máximo de refinamentos',REFINEMENT_BUDGETS,
        index=REFINEMENT_BUDGETS.index(controls['max_refinements']),key='auto_max_refinements',
        help='Controle de execução, separado das entradas físicas. Opções qualificadas nesta interface: 6 ou 7.')
    if budget!=controls['max_refinements']:
        for key in ('auto_result','auto_word','auto_calculation_timing'):st.session_state.pop(key,None)
        st.session_state['auto_budget_changed']=True
    controls=validate_calculation_controls({'max_refinements':budget})
    # Persist separately from widget lifetime so route switches keep the choice.
    st.session_state['auto_calculation_controls']=controls
    st.caption(f'Controle numérico, não entrada física: início com 8 divisões; tolerância mantida em {p.sampling_tolerance:g}; 2 rodadas estáveis sucessivas. Aumentar o orçamento pode elevar substancialmente o tempo. O cálculo para antes se convergir. Não garante uma seção adequada nem resolve limitações do domínio geométrico.')
    if st.session_state.get('auto_budget_changed'):st.warning('O orçamento numérico mudou. Recalcule para atualizar os resultados e a memória Word.')
    st.download_button('Salvar entradas JSON',json.dumps(legacy_project_document(p,metadata,controls),ensure_ascii=False,indent=2).encode('utf-8'),'LRO_rolamento_projeto.json','application/json')
    st.caption('O cálculo completo percorre resistência, serviço e fadiga. O tempo depende dos casos, vínculos e refinamento e pode chegar a dezenas de minutos. A comparação vertical rápida é independente e não substitui esta verificação.')
    if st.button('Calcular viga',type='primary'):
        import time
        started=time.monotonic()
        bar=st.progress(0.,text='Preparando os casos de carga…')
        def update(index,total,label):bar.progress(index/max(1,total),text=f'Caso {index+1} de {total} · {(time.monotonic()-started)/60:.1f} min: {label}')
        try:
            r=calculate_with_controls(p,controls,progress=update,calculate=calculate_core)
            st.session_state.auto_result=r
            st.session_state['auto_calculation_timing']=(r.input_signature,time.monotonic()-started)
            st.session_state.pop('auto_word',None)
            st.session_state.pop('auto_budget_changed',None)
        except (ValueError,ArithmeticError) as e:
            st.error('O cálculo não pôde ser concluído: '+str(e));st.session_state.pop('auto_result',None)
        finally:bar.empty()
    r=st.session_state.get('auto_result')
    if r is None:return
    timing=st.session_state.get('auto_calculation_timing')
    if timing and timing[0]==r.input_signature:st.caption(f'Processamento realizado em {timing[1]/60:.1f} min. Situação e pendências das verificações são apresentadas abaixo.')
    if r.input_signature!=input_signature(p) or not result_matches_controls(p,r,controls):st.warning('As entradas ou o orçamento numérico mudaram. Recalcule para atualizar resultados e exportações.');return
    if r.complete and r.status.startswith('ATENDE'):st.success(r.status)
    elif r.status.startswith('NÃO ATENDE'):st.error(r.status)
    else:st.warning(r.status)
    import pandas as pd
    st.dataframe(pd.DataFrame(result_rows(r),columns=LABELS),hide_index=True,width='stretch')
    if r.coverage_issues:
        st.warning('Há '+str(len(r.coverage_issues))+' obrigações de cálculo sem conclusão. Os motivos aparecem nas verificações pendentes e no controle numérico.')
    if r.missing_mechanisms:
        from .autonomous_export import MECHANISM_LABELS
        st.warning('Ainda precisam de conclusão: '+', '.join(MECHANISM_LABELS[k] for k in r.missing_mechanisms))
    col1,col2,col3=st.columns(3)
    with col1:st.download_button('Resultados CSV',export_csv(p,r),'LRO_rolamento_resultados.csv','text/csv')
    with col2:st.download_button('Cálculo completo JSON',export_calculation_json(p,r,document_metadata=metadata),'LRO_rolamento_calculo.json','application/json')
    with col3:
        if st.button('Preparar memória Word'):
            st.session_state.auto_word=(numerical_word_cache_signature(r,metadata),export_word(p,r,views,document_metadata=metadata))
        word=st.session_state.get('auto_word')
        if word and word[0]==numerical_word_cache_signature(r,metadata):st.download_button('Baixar Word',word[1],'LRO_rolamento_MC.docx','application/vnd.openxmlformats-officedocument.wordprocessingml.document')
    with st.expander('Casos críticos e controle numérico'):
        st.json({'controle':r.numerical_evidence,'obrigacoes_pendentes':r.coverage_issues})
