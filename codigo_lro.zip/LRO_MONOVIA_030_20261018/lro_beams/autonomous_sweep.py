from .autonomous_restraint_mode import analysis_brace_positions
"""Concurrent coupled response survey with explicit numerical convergence.

Nested train/section grids supplement all wheel, support and brace events and
analytic flexural extrema. Convergence is a numerical check, not an interval
proof or a substitute for normative coverage. No independent maxima are
presented as a simultaneous load state.
"""
from dataclasses import dataclass,field
import math
from .autonomous_response import solve_concurrent_position,stiffener_self_weight_metadata
from .autonomous_critical import coupled_critical_positions
from .autonomous_lateral_restraints import all_lateral_positions,accumulate_lateral_restraint_evidence

# Bounded memoization only; eviction never removes a sample or observer call.
_MAX_CACHED_SECTION_STATES=4096

METRICS=('Mx_knm','My_knm','Vy_kn','Vx_kn','N_kn','vertical_mm','horizontal_mm','rail_horizontal_mm','bimoment_nmm2','theta_rad','total_torque_nmm','projection_vertical_mm','projection_left_vertical_mm','projection_right_vertical_mm','projection_left_rail_horizontal_bound_mm','projection_right_rail_horizontal_bound_mm')

@dataclass(frozen=True)
class CriticalResponse:
    metric:str
    value:float
    translation_m:float
    x_m:float
    side:str
    state:dict

@dataclass
class CoupledSweep:
    case_id:str
    maxima:dict=field(default_factory=dict)
    responses:int=0
    evaluated_sections:int=0
    converged:bool=False
    relative_change:float|None=None
    refinement:int=0
    cb_minimum:float=1.0
    cb_critical:dict=field(default_factory=dict)
    translation_positions:tuple=()
    equilibrium_relative_residual:float=0.0
    project_signature:str=''
    observer_sample_keys:tuple=()
    response_evaluations:int=0
    convergence_history:list=field(default_factory=list)
    lateral_restraint_evidence:dict=field(default_factory=dict)
    method:str='Malhas aninhadas com eventos exatos; convergência numérica de respostas acopladas'


def translation_grid(p,divisions,*,extra_events=()):
    if isinstance(divisions,bool) or not isinstance(divisions,int) or divisions<2:raise ValueError('Divisões da passagem inválidas.')
    offsets=[w.offset_m for w in p.wheels];lo=-max(offsets);hi=p.span_m-min(offsets)
    anchors={lo,hi}
    for w in p.wheels:
        for x in (0,p.span_m,*all_lateral_positions(p),*stiffener_self_weight_metadata(p)['positions_m']):anchors.add(x-w.offset_m)
    for event in extra_events:
        if isinstance(event,bool) or not isinstance(event,(int,float)) or not math.isfinite(event):
            raise ValueError('Evento adicional de translação inválido.')
        if lo<=event<=hi:anchors.add(event)
    events=sorted(x for x in anchors if lo<=x<=hi)
    # Uniform global grids are nested when divisions doubles; all event
    # neighbours are included independently. A few ulps survive offset addition.
    result={lo+(hi-lo)*i/divisions for i in range(divisions+1)}|set(events)
    epsilon=64*math.ulp(max(1.,abs(lo),abs(hi),p.span_m,*map(abs,offsets)))
    for event in events:
        result.update((event-epsilon,event+epsilon))
    # Explicit unloaded passage endpoints, beyond the first/last contact.
    result.update((lo-epsilon,hi+epsilon))
    return tuple(sorted(result))


def section_grid(p,response,divisions,*,critical_positions=None,vertical_critical_positions=None):
    positions={p.span_m*i/divisions for i in range(divisions+1)}
    positions.update(response.vertical.critical_positions() if vertical_critical_positions is None else vertical_critical_positions)
    positions.update(coupled_critical_positions(response) if critical_positions is None else critical_positions)
    positions.update(all_lateral_positions(p))
    jumps={w.position_m for w in response.vertical.all_loads}|set(all_lateral_positions(p))
    positions.update(jumps)
    return tuple((x,side) for x in sorted(positions) for side in
                 (('left','right') if (x==0 and p.beam_end_left_mm>0) or (x==p.span_m and p.beam_end_right_mm>0)
                  else ('right',) if x==0 else ('left',) if x==p.span_m else ('left','right') if x in jumps else ('right',)))


def response_metrics(state):
    result={k:state[k] for k in METRICS if k in state}
    t=state['torsion']
    result['bimoment_nmm2']=t['bimoment_nmm2'];result['theta_rad']=t['theta_rad']
    result['total_torque_nmm']=t['saint_venant_torque_nmm']+t['warping_torque_nmm']
    return result


def scan_coupled_case(p,case,*,initial_divisions=12,max_refinements=4,tolerance=None,observer=None,cache_responses=True):
    """Observer sees real concurrent states; it must not mutate the response.

    Numerical convergence requires two successive refinement changes below the
    tolerance. Samples include the no-wheel baseline at both passage ends.
    Histories for fatigue require a separate fixed-section ordered pass.
    A per-call deterministic response cache retains every observer call/sample
    and refinement level; observers must not mutate the supplied state.
    """
    if type(cache_responses) is not bool:raise ValueError('Indicador de cache deve ser booleano.')
    tolerance=p.sampling_tolerance if tolerance is None else tolerance
    if not 0<tolerance<.2:raise ValueError('Tolerância numérica inválida.')
    if max_refinements<2:raise ValueError('São necessários pelo menos dois refinamentos.')
    previous=None;previous_cb=None;stable=0;cache={};critical_cache={};vertical_critical_cache={};cb_cache={};state_cache={};response_evaluations=0;total_sections=0;equilibrium=0.;observer_keys=set()
    result=CoupledSweep(case.id);history=[];restraint_evidence={}
    extra_events=tuple(getattr(observer,'translation_events',()))
    for level in range(max_refinements+1):
        divisions=initial_divisions*2**level
        translations=translation_grid(p,divisions,extra_events=extra_events) if extra_events else translation_grid(p,divisions)
        maxima={} if previous is None else dict(previous);cb_min=math.inf;cb_record={}
        for a in translations:
            if a not in cache:
                cache[a]=solve_concurrent_position(p,case.factors,a,case.transverse_sign,case.longitudinal_sign)
                critical_cache[a]=coupled_critical_positions(cache[a])
                vertical_critical_cache[a]=cache[a].vertical.critical_positions()
                accumulate_lateral_restraint_evidence(restraint_evidence,p,cache[a])
            r=cache[a]
            v=r.vertical;L=p.span_m
            sums=[(v.reactions.vertical_left_kn+v.reactions.vertical_right_kn,sum(q.vertical_kn for q in v.all_loads)+v.udl.vertical_kn_per_m*L),
                  (v.reactions.vertical_right_kn*L,sum(q.vertical_kn*q.position_m+q.major_moment_knm for q in v.all_loads)+v.udl.vertical_kn_per_m*L*L/2)]
            lat=r.lateral_torsion;tor=lat.torsion
            sums.append((sum(lat.horizontal_support_reactions_n),-sum(q.horizontal_n for q in lat.loads)-lat.uniform_horizontal_n_per_mm*L*1000))
            sums.append((sum(tor.support_torques_nmm),-sum(q.torque_nmm for q in tor.point_torques)-tor.uniform_torque_nmm_per_mm*L*1000))
            equilibrium=max(equilibrium,*(abs(left-right)/max(1.,abs(left),abs(right)) for left,right in sums))
            for flange,braces in (('superior',analysis_brace_positions(p,'upper_braces_m')),('inferior',analysis_brace_positions(p,'lower_braces_m'))):
                nodes=sorted({0.,p.span_m,*braces})
                for start,end in zip(nodes[:-1],nodes[1:]):
                    # The response for this exact translation is immutable.
                    # Reuse its unchanged analytic Cb on nested refinements;
                    # do not skip any flange, interval, sample or comparison.
                    cb_key=(a,start,end)
                    if cb_key not in cb_cache:cb_cache[cb_key]=r.vertical.cb(start,end)
                    cb=cb_cache[cb_key]
                    if cb.maximum_abs_moment_knm>1e-12 and cb.cb<cb_min:
                        cb_min=cb.cb;cb_record=dict(translation_m=a,start_m=cb.start_m,end_m=cb.end_m,cb=cb.cb,flange=flange)
            cuts=set(section_grid(p,r,divisions,critical_positions=critical_cache[a],vertical_critical_positions=vertical_critical_cache[a]))
            extra=getattr(observer,'section_positions',None)
            if extra:
                epsilon=64*math.ulp(max(1.,p.span_m))
                for x in extra(r):
                    if not math.isfinite(x) or not 0<=x<=p.span_m:raise ValueError('Corte adicional fora do vão.')
                    for q in (x-epsilon,x,x+epsilon):
                        if 0<=q<=p.span_m:cuts.add((q,'right' if q<p.span_m else 'left'))
            for x,side in sorted(cuts):
                sample_key=(a,x,side)
                if cache_responses and sample_key in state_cache:
                    state=state_cache[sample_key]
                else:
                    state=r.at(x,side);response_evaluations+=1
                    if cache_responses:
                        if len(state_cache)>=_MAX_CACHED_SECTION_STATES:state_cache.clear()
                        state_cache[sample_key]=state
                total_sections+=1
                values=response_metrics(state)
                if observer:
                    additions=observer(r,x,side,state,level) or {}
                    observer_keys.add((a,x,side))
                    for key,value in additions.items():
                        if key in values:raise ValueError('O observador não pode substituir uma resposta física.')
                        if not isinstance(value,(int,float)) or not math.isfinite(value):raise ValueError('Critério de resposta não finito.')
                    values.update(additions)
                for key,value in values.items():
                    if key not in maxima or abs(value)>abs(maxima[key].value):maxima[key]=CriticalResponse(key,value,a,x,side,state)
        change=None
        if previous is not None:
            changes={k:abs(abs(v.value)-abs(previous[k].value))/max(abs(v.value),abs(previous[k].value),1e-10) for k,v in maxima.items()}
            change=max(changes.values())
            history.append(dict(refinement=level,changes=changes,cb=cb_min))
            if previous_cb is not None and cb_min!=math.inf:
                change=max(change,abs(cb_min-previous_cb)/max(cb_min,previous_cb,1.))
            stable=stable+1 if change<=tolerance else 0
        result=CoupledSweep(case.id,maxima,len(cache),total_sections,stable>=2,change,level,1. if cb_min==math.inf else cb_min,cb_record,translations,equilibrium)
        if result.converged:break
        previous=maxima
        previous_cb=1. if cb_min==math.inf else cb_min
    from .autonomous_result import input_signature
    result.project_signature=input_signature(p)
    result.observer_sample_keys=tuple(sorted(observer_keys))
    result.response_evaluations=response_evaluations
    result.convergence_history=history
    if restraint_evidence:
        restraint_evidence.update(case_id=case.id,project_signature=result.project_signature)
    result.lateral_restraint_evidence=restraint_evidence
    return result
