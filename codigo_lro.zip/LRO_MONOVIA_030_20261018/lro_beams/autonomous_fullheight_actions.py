"""Explicit functional actions of the published full-height nominal family.

An intermediate transverse stabilizer has its prescribed stabilizing function
and permanent body weight. Coincidence with a wheel/brace is not a load path.
Bearing stations additionally consume the actual vertical support reaction.
Lateral/torsional fork actions retain their original member response, but no
unsupported transfer to the transverse pair is fabricated.
"""
from __future__ import annotations
from math import isfinite
from copy import deepcopy
from .autonomous_stiffener_actions import stiffener_station_geometry
from .autonomous_result import input_signature

SOURCE='NBR8800 5.4.3.1.3 (estabilizador), 5.7.9 (bearing real), 6.1/6.2; inventário físico nominal por função.'


def enabled(p):
    value=getattr(p,'fullheight_nominal_detail',None)
    if value is None:return False
    if type(value) is not dict:raise ValueError('Objeto físico full-height inválido.')
    if p.restraint_application!='resistance_lengths_only':
        raise ValueError('Família nominal não cria apoios intermediários de análise.')
    return True


def _real(x,name,nonnegative=False):
    if type(x) not in (int,float) or not isfinite(x) or nonnegative and x<0:
        raise ValueError(name+': valor real finito no domínio obrigatório.')
    return float(x)


def _bearing_interval(row):
    """Compose an already compacted envelope without replacing it by its witness.

    ``vertical_bearing_kn`` remains the first physical witness for diagnostics;
    it is not the maximum of a compacted case.  Both endpoints and its bound
    are checked before a second level of case-family aggregation.
    """
    R=row['vertical_bearing_kn']
    if R is not None:R=_real(R,'Rz')
    if 'bearing_interval_kn' not in row:
        if 'bearing_abs_bound_kn' in row:raise ValueError('Bound bearing sem intervalo.')
        return None if R is None else [R,R]
    interval=row['bearing_interval_kn']
    if R is None:
        if interval is not None or _real(row.get('bearing_abs_bound_kn'),'Bound bearing',True)!=0:
            raise ValueError('Estabilizador sem reação não admite intervalo bearing.')
        return None
    if not isinstance(interval,(tuple,list)) or len(interval)!=2:raise ValueError('Intervalo bearing inválido.')
    lo,hi=(_real(v,'Extremo bearing') for v in interval)
    if lo>hi or not lo<=R<=hi:raise ValueError('Testemunha bearing fora do intervalo.')
    if _real(row.get('bearing_abs_bound_kn'),'Bound bearing',True)!=max(abs(lo),abs(hi)):
        raise ValueError('Bound bearing inconsistente com os extremos.')
    return [lo,hi]


def station_actions(p,response,local_record):
    if not enabled(p):raise ValueError('Família nominal não selecionada.')
    signature=input_signature(p)
    if local_record.get('project_signature')!=signature or local_record.get('translation_m')!=response.translation_m:
        raise ValueError('Registro local não corresponde ao projeto/translação nominal.')
    from .autonomous_response import stiffener_self_weight_loads
    weight={q.position_m:q.vertical_kn for q in stiffener_self_weight_loads(p,response.factors)}
    reactions=(response.vertical.reactions.vertical_left_kn,response.vertical.reactions.vertical_right_kn)
    stations=[];pending=[]
    for row in stiffener_station_geometry(p):
        x=row['x_m'];support=row['kind']!='intermediate'
        R=_real(reactions[0 if x==0 else 1],'Reação vertical') if support else None
        G=_real(weight.get(x,0.),'Peso da estação',True)
        issues=[]
        if R is not None and R<0:issues.append('Bearing compressivo não cobre reação de arrancamento.')
        stations.append(dict(**row,body_weight_kn=G,vertical_bearing_kn=R,
            complete=not issues,pending=issues,interfaces=[],
            function_inventory=dict(panel_stabilization='prescriptive',
                selfweight_transfer='constant_G_real_body',vertical_bearing='actual_support_reaction' if support else 'not_applicable',
                intermediate_brace_transfer='not_applicable_direct_flange_and_resistance_lengths_only',
                fork_horizontal_torsional_transfer='not_attributed_to_transverse_pair'),
            source=SOURCE,project_signature=signature,translation_m=response.translation_m,
            artificial_wheel_share_assigned=False,artificial_fork_wrench_assigned=False,
            cyclic_G_range_claimed=False))
        pending.extend(row['station_id']+': '+v for v in issues)
    return dict(stations=stations,complete=bool(stations) and not pending,pending=pending,
        project_signature=signature,translation_m=response.translation_m,source=SOURCE,
        physical_actions_changed=False)


def envelope_station_actions(records):
    records=list(records)
    if not records:raise ValueError('Envoltória de estações vazia.')
    result={};pending=[];signatures=set();count=0
    for record in records:
        if type(record) is not dict or not isinstance(record.get('stations'),(tuple,list)) or not record['stations']:
            raise ValueError('Registro de estações ausente.')
        signatures.add(record.get('project_signature'))
        if len(signatures)>1 or None in signatures:raise ValueError('Projetos diferentes/ausentes na envoltória.')
        n=record.get('snapshot_count',1)
        if type(n) is not int or n<1:raise ValueError('Contagem de registros inválida.')
        count+=n
        if record.get('complete') is not True:pending.extend(record.get('pending') or ['Registro de estações incompleto.'])
        pending.extend(record.get('pending',[]))
        rows=record['stations'];ids=[r['station_id'] for r in rows]
        if len(ids)!=len(set(ids)):raise ValueError('Estações repetidas.')
        if result and set(ids)!=set(result):raise ValueError('Cobertura de estações inconsistente.')
        for r in rows:
            if r.get('project_signature')!=record['project_signature']:raise ValueError('Estação sem identidade do projeto.')
            if r.get('complete') is not True:pending.extend(r.get('pending') or ['Estação incompleta.'])
            pending.extend(r.get('pending',[]))
            G=_real(r['body_weight_kn'],'G',True);interval=_bearing_interval(r)
            extra=r.get('bearing_additional_actions')
            if extra is not None:
                if type(extra) is not dict:raise ValueError('Ações adicionais bearing devem ser objeto explícito.')
                # Preserve additional actions without erasing valid vertical
                # evidence. Restricted consumers must condition their scope.
                # No force is inferred from names or replaced with zero.
            receiver_extra=r.get('receiver_additional_nominal_fields')
            if receiver_extra is not None and type(receiver_extra) is not dict:
                raise ValueError('Campos nominais adicionais dos receptores devem ser objeto explícito.')
            key=r['station_id']
            if key not in result:
                result[key]=dict(r,body_weight_kn=G,bearing_interval_kn=interval,
                    bearing_abs_bound_kn=0. if interval is None else max(map(abs,interval)))
                if extra:result[key]['bearing_additional_actions']={'records':[deepcopy(extra)]}
                if receiver_extra:result[key]['receiver_additional_nominal_fields']={'records':[deepcopy(receiver_extra)]}
            else:
                old=result[key]
                for field in ('x_m','kind','function_inventory'):
                    if old[field]!=r[field]:raise ValueError('Identidade física da estação mudou: '+field)
                if (old['bearing_interval_kn'] is None)!=(interval is None):raise ValueError('Função bearing inconsistente.')
                old['body_weight_kn']=max(old['body_weight_kn'],G)
                if extra:
                    old.setdefault('bearing_additional_actions',{}).setdefault('records',[]).append(deepcopy(extra))
                if receiver_extra:
                    old.setdefault('receiver_additional_nominal_fields',{}).setdefault('records',[]).append(deepcopy(receiver_extra))
                if interval is not None:
                    old['bearing_interval_kn']=[min(old['bearing_interval_kn'][0],interval[0]),max(old['bearing_interval_kn'][1],interval[1])]
                    old['bearing_abs_bound_kn']=max(map(abs,old['bearing_interval_kn']))
    for row in result.values():
        row['additional_actions_covered']=not bool(row.get('bearing_additional_actions') or row.get('receiver_additional_nominal_fields'))
    return dict(stations=list(result.values()),complete=not pending,pending=list(dict.fromkeys(pending)),
        additional_actions_covered=all(row['additional_actions_covered'] for row in result.values()),
        project_signature=next(iter(signatures)),snapshot_count=count,source=SOURCE)


def compact_nominal_case(local_records,project_signature):
    rows=[]
    for record in local_records:
        if record.get('project_signature')!=project_signature:raise ValueError('Registro ELU de outro projeto.')
        rows.append(dict(stations=record.get('stiffener_stations'),
            complete=record.get('stiffener_station_complete') is True,
            pending=list(record.get('stiffener_station_pending',[])),
            project_signature=project_signature))
    return envelope_station_actions(rows)
