"""Explicit adopted normal-operation patterns, not a universal crane envelope."""
from copy import deepcopy
import math
from .equipment_basis import G_KN_PER_METRIC_TONNE, wheel_signature

SOURCE_ACCELERATION='ABNT NBR 8400-1:2019, 6.2.3.1.1, p.24'
SOURCE_ROLLING='ABNT NBR 8400-1:2019, 6.2.3.3 e Figura 6, p.25'


def normal_horizontal_reference(wheels, *, capacity_tf, trolley_mass_kg, bridge_span_m, wheelbase_m, dynamic_factor=1.):
    """Two independent trolley/rolling relative senses, global signs solved by core.

    The all-driven and equal-wheel-transfer assumptions are adopted design
    conditions. The optional additional factor is explicit; one retains the prescribed wheel/rail design actions without extra margin.
    The output is not emergency braking, test, bumper, skew Annex C or a fatigue
    mixture. Compute both selected projects independently.
    """
    vals=(capacity_tf,trolley_mass_kg,bridge_span_m,wheelbase_m,dynamic_factor)
    if any(isinstance(v,bool) or not isinstance(v,(int,float)) or not math.isfinite(v) or abs(v)>1e12 for v in vals):
        raise ValueError('Dados horizontais devem ser números finitos.')
    if capacity_tf<=0 or trolley_mass_kg<0 or bridge_span_m<=0 or wheelbase_m<=0 or dynamic_factor<1:
        raise ValueError('Dados horizontais fora da faixa.')
    if len(wheels)!=2 or any(isinstance(v,bool) or not isinstance(v,(int,float)) or not math.isfinite(v) or v<0 or v>1e12 for w in wheels for v in (w.offset_m,w.dead_kn,w.lifted_kn)):
        raise ValueError('Referência horizontal exige duas rodas e parcelas verticais não negativas.')
    if not math.isclose(wheels[0].dead_kn+wheels[0].lifted_kn,wheels[1].dead_kn+wheels[1].lifted_kn,rel_tol=1e-9):
        raise ValueError('Esta hipótese exige divisão vertical simétrica nas duas rodas.')
    if not math.isclose(abs(wheels[1].offset_m-wheels[0].offset_m),wheelbase_m,rel_tol=1e-9,abs_tol=1e-9):
        raise ValueError('Entre-eixos da referência deve coincidir com o trem de rodas.')
    P=wheels[0].dead_kn+wheels[0].lifted_kn
    ratio=bridge_span_m/wheelbase_m
    lam=max(.05,min(.20,.025*ratio))
    longitudinal=.25*P*dynamic_factor
    trolley_total=.25*(capacity_tf+trolley_mass_kg/1000)*G_KN_PER_METRIC_TONNE*dynamic_factor
    half=trolley_total/2
    rolling=lam*P*dynamic_factor
    variants=[]
    for key,sign in (('HT-A',1.),('HT-B',-1.)):
        pair=deepcopy(wheels)
        pair[0].transverse_kn=half+sign*rolling
        pair[1].transverse_kn=half-sign*rolling
        for w in pair:w.longitudinal_kn=longitudinal
        variants.append(dict(id=key,wheels=pair,transverse_pattern='combined_a' if sign>0 else 'combined_b'))
    return dict(scenarios=variants,lambda_rolling=lam,span_wheelbase_ratio=ratio,
                trolley_total_transverse_kn=trolley_total,trolley_transverse_per_wheel_kn=half,
                rolling_per_wheel_kn=rolling,longitudinal_per_wheel_kn=longitudinal,
                dynamic_factor=dynamic_factor,sources=[SOURCE_ACCELERATION,SOURCE_ROLLING],
                status='HIPÓTESES ADOTADAS DE OPERAÇÃO NORMAL; NÃO ENVELOPE CERTIFICADO',
                limitations=['Pi = G+Q estático por roda é a base analítica adotada neste modelo; os parágrafos citados não resolvem expressamente a base estática/dinâmica de Pi.',
                    'Todas as rodas longitudinais adotadas como motrizes/freadas.',
                    '100% da resultante transversal do carro atribuída ao caminho analisado; repartição igual nas suas duas rodas.',
                    'Lambda é lido da relação vão da ponte/entre-eixos na geometria da Figura 6; não representa outro sistema de guiamento.',
                    'Fator horizontal adicional é margem adotada; um mantém as ações prescritas roda/trilho, sem criar uma exigência normativa extra.',
                    'Calcular HT-A e HT-B separadamente. Não agregar automaticamente os históricos de fadiga.',
                    'Ações extraordinárias e fornecimento real devem ser qualificados separadamente.'])


def apply_horizontal_reference(project, scenario_id, *, dynamic_factor=1.):
    p=deepcopy(project);b=p.equipment_basis
    if b.load_model!='symmetric_four_wheel_bridge':raise ValueError('Primeiro defina as massas e a geometria do modelo estático.')
    data=normal_horizontal_reference(p.wheels,capacity_tf=b.capacity_tf,trolley_mass_kg=b.trolley_mass_kg,
        bridge_span_m=b.bridge_span_m,wheelbase_m=b.wheelbase_m,dynamic_factor=dynamic_factor)
    selected=next((r for r in data['scenarios'] if r['id']==scenario_id),None)
    if selected is None:raise ValueError('Escolha HT-A ou HT-B.')
    p.wheels=selected['wheels'];b.status='adopted_assumption';b.horizontal_basis='normal_reference'
    b.horizontal_scenario_id=scenario_id;b.horizontal_dynamic_factor=dynamic_factor
    b.transverse_pattern=selected['transverse_pattern'];b.rolling_kn_per_wheel=data['rolling_per_wheel_kn']
    b.transverse_kn_per_wheel=data['trolley_transverse_per_wheel_kn'];b.longitudinal_kn_per_wheel=data['longitudinal_per_wheel_kn']
    b.applied_wheel_signature=wheel_signature(p.wheels)
    b.assumption_note+=' Cenário '+scenario_id+': ações horizontais de referência normativas com hipóteses all-driven, caminho crítico integral e repartição igual. Exige análise complementar '+('HT-B' if scenario_id=='HT-A' else 'HT-A')+'; não é certificado de ações do fabricante.'
    return p,data
