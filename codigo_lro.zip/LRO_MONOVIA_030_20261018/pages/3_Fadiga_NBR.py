"""Separate NBR nominal fatigue editor; no EN action or approval is consumed."""
from __future__ import annotations

from copy import deepcopy
from dataclasses import asdict
from pathlib import Path
import math
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
if not (ROOT / 'nbr_fatigue_project.py').exists():
    path = str(ROOT.parent / 'extension_nbr_fatigue')
    if path not in sys.path:
        sys.path.insert(0, path)

import pandas as pd
import streamlit as st
from monorail.model import Station
from analytical_scan import AxialTransfer
from lro_beams.stress_8400 import LOW_GRADES, HIGH_GRADES

st.set_page_config(page_title='Monovia · Fadiga nominal NBR', page_icon='🏗️', layout='wide')
try:
    from nbr_fatigue_project import NBRFatigueProject, demo_nbr_fatigue_project, from_nbr_json
except ImportError as exc:
    st.error('A camada de entrada da fadiga nominal NBR não está disponível nesta montagem. Nenhum resultado foi criado. ' + str(exc))
    st.stop()

PREFIX = 'nbr_fatigue_ui_'
STATUS = {'PASS': 'Limite suficiente satisfeito', 'BOUND_EXCEEDED': 'Majorante excedido',
    'PENDING': 'Pendente', 'NOT_CALCULATED': 'Não calculado', 'OUT_OF_SCOPE': 'Fora do domínio',
    'OUT_OF_DOMAIN': 'Fora do domínio', 'ERROR': 'Não calculado'}
EXAMPLES = {'vertical': 'Vertical · premissas sintéticas preenchidas',
    'horizontal': 'Hy · torção e alma fora do plano', 'combined': 'Hs + Hy · axial e torção',
    'bound_exceeded': 'Carga elevada · majorante excedido',
    'missing_axial': 'Hs · premissa axial ausente', 'missing_data': 'Dados de fadiga pendentes'}
PERMANENT_LIMITATIONS = (
    'São três regiões globais nominais e até doze faces locais prescritas (P0/P1/P2 × dois lados × duas faces), não aprovação da seção inteira.',
    'Não fecha contato rolante, desgaste, concentrações reais de raiz, regiões perturbadas, soldas, furos, entalhes, anexos ou ligações.',
    'Não verifica estabilidade, segunda ordem, rigidez/resistência dos apoios nem cobertura integral das ações reais do equipamento.',
    'Não reconstrói história temporal, não calcula dano de Miner, ciclos até ruptura ou vida ilimitada.',
    'Um resultado NBR desta página não se soma a um PASS EN para aprovar a monovia. As rotas e seus recibos permanecem separados.',
)


def invalidate():
    for name in ('result', 'word', 'word_signature', 'diagram'):
        st.session_state['nbr_fatigue_' + name] = None
    for key in ('nbr_fatigue_result_case', 'nbr_fatigue_diagram_translation'):
        if key in st.session_state: del st.session_state[key]


def reset(bundle, notice):
    st.session_state.nbr_fatigue_bundle = bundle
    invalidate()
    for key in list(st.session_state):
        if str(key).startswith(PREFIX) or key in ('nbr_fatigue_result_case', 'nbr_fatigue_diagram_translation'):
            del st.session_state[key]
    st.session_state.nbr_fatigue_notice = ('success', notice)


def load_example():
    mode = st.session_state.get('nbr_fatigue_example_choice', 'vertical')
    reset(demo_nbr_fatigue_project(mode),
        'Cenário sintético carregado explicitamente. As fontes são ilustrativas; recalcule para obter um resultado atual.')


def restore_demo():
    reset(demo_nbr_fatigue_project('vertical'), 'Exemplo sintético vertical restaurado. Nenhum resultado anterior foi mantido.')


def human(exc):
    value = str(exc)
    replacements = {
        'Explicit axial premise required': 'Premissa axial explícita obrigatória',
        'Physical source for axial-transfer idealization required': 'Informe a fonte da idealização da transferência axial',
        'Hx requires explicit equal opposed contacts and axial restraint at shear centre; transport is not omitted':
            'Hs exige contatos opostos iguais e vínculo axial no centro de cisalhamento; o transporte não foi omitido',
        'Actual end fork premise must be explicitly adopted': 'Adote explicitamente a premissa dos garfos extremos',
        'Initial canonical recovery domain is rolled parallel I': 'A recuperação nominal inicial exige seção I laminada de mesas paralelas',
        'max_refinements outside supported range': 'O scanner exige entre 2 e 8 refinamentos; o valor informado foi preservado, não corrigido automaticamente',
    }
    for source, translated in replacements.items():
        value = value.replace(source, translated)
    try:
        from nbr_fatigue_report import reason_pt
        value = reason_pt(value)
    except ImportError:
        pass
    return value


def import_bundle():
    invalidate()
    upload = st.session_state.get('nbr_fatigue_import_upload')
    pasted = st.session_state.get('nbr_fatigue_import_text', '').strip()
    try:
        if upload is not None and pasted:
            raise ValueError('Escolha arquivo ou texto, não ambos.')
        raw = upload.getvalue() if upload is not None else pasted
        if not raw:
            raise ValueError('Selecione um arquivo de entrada ou cole o JSON.')
        bundle = NBRFatigueProject.from_json(raw)
    except (ValueError, TypeError, UnicodeError, OverflowError) as exc:
        st.session_state.nbr_fatigue_notice = ('error', 'Importação recusada. ' + human(exc) +
            ' As entradas atuais foram preservadas; resultado e Word anteriores foram removidos.')
        return
    reset(bundle, 'Entradas da fadiga nominal NBR importadas. Calcule novamente; nenhum resultado externo foi aceito.')


def import_physical_nbr():
    invalidate()
    upload = st.session_state.get('nbr_fatigue_nbr_import_upload')
    pasted = st.session_state.get('nbr_fatigue_nbr_import_text', '').strip()
    try:
        if upload is not None and pasted:
            raise ValueError('Escolha arquivo ou texto, não ambos.')
        raw = upload.getvalue() if upload is not None else pasted
        if not raw:
            raise ValueError('Selecione uma entrada NBR 0.1 ou cole seu JSON.')
        bundle = from_nbr_json(raw)
    except (ValueError, TypeError, UnicodeError, OverflowError) as exc:
        st.session_state.nbr_fatigue_notice = ('error', 'Importação física recusada. ' + human(exc) +
            ' As entradas atuais foram preservadas; resultado e Word anteriores foram removidos.')
        return
    reset(bundle, 'Entradas físicas e ações NBR importadas explicitamente. Novas premissas e fontes de fadiga não foram preenchidas; resultados 0.1 e EN não foram importados.')


def n(label, value, key, *, minimum=None, maximum=None, step=None, help=None, format=None):
    """Preserve valid imports outside editorial ranges, including integral JSON numbers."""
    integer = type(value) is int and all(x is None or type(x) is int for x in (minimum, maximum, step))
    numeric = int if integer else float
    args = dict(value=numeric(value), key=PREFIX + key, on_change=invalidate, help=help)
    outside = (minimum is not None and value < minimum) or (maximum is not None and value > maximum)
    if minimum is not None: args['min_value'] = numeric(min(minimum, value))
    if maximum is not None: args['max_value'] = numeric(max(maximum, value))
    if step is not None: args['step'] = numeric(step)
    if format is not None: args['format'] = format
    elif isinstance(value, float) and 0 < abs(value) < .001: args['format'] = '%.8e'
    result = st.number_input(label, **args)
    if outside:
        st.caption('Valor importado preservado sem truncamento. A faixa editorial foi ampliada; a validação do modelo define o domínio.')
    return value if result == value else result


def t(label, value, key, *, area=False, help=None):
    return (st.text_area if area else st.text_input)(label, value=value, key=PREFIX + key,
        on_change=invalidate, help=help)


def flag(label, value, key, *, help=None):
    return st.checkbox(label, value=value, key=PREFIX + key, on_change=invalidate, help=help)


def select(label, options, value, key, *, labels=None, help=None):
    options = list(options)
    if value not in options: options.append(value)
    return st.selectbox(label, options, index=options.index(value), key=PREFIX + key,
        on_change=invalidate, format_func=lambda x: (labels or {}).get(x, x), help=help)


def explanation(value):
    if isinstance(value, (list, tuple)):
        return '; '.join(human(x) for x in value)
    return human(value or '')


def check_table(checks):
    try:
        from nbr_fatigue_report import region_label, point_label, face_label
    except ImportError:
        region_label = point_label = face_label = lambda value: str(value or '')
    return pd.DataFrame([{'Identificador': c.get('id', ''), 'Região nominal': region_label(c.get('region', '')),
        'Ponto': point_label(c.get('point_id', '')), 'Face': face_label(c.get('face', '')), 'Plano': c.get('plane', ''),
        'Situação': STATUS.get(c.get('status'), c.get('status', '')), 'Utilização do majorante': c.get('utilization'),
        'Pendências / motivos': explanation(c.get('reasons', [])), 'Fonte': c.get('source', '')}
        for c in checks if isinstance(c, dict)])


if 'nbr_fatigue_bundle' not in st.session_state:
    st.session_state.nbr_fatigue_bundle = demo_nbr_fatigue_project('vertical')
    invalidate()
b = deepcopy(st.session_state.nbr_fatigue_bundle)
p = b.project
errors = []

st.title('Monovia · Fadiga nominal NBR · análise complementar')
st.caption('Ações genuínas FAT8400 e recuperação nominal de N, My, Mz, B, Fy, Fz, Tsv e Tw. A resistência (D.5) é a herdada, não uma nova resistência de fadiga.')
st.info('Combinação nominal local/global: σN + σM + σB + 0,75σlocal,x, por leitura conjunta da NBR 10084 §9.1.4 com NBR 8400-2 §5.6 e D.2.3. Somente a parcela local longitudinal recebe 0,75; a transversal permanece integral. Não é transcrição literal de uma fórmula N/B nem um novo fator independente de fadiga. O fator 4/3 das admissíveis não é reaplicado.')
with st.sidebar:
    st.subheader('Entrada independente NBR')
    st.selectbox('Cenário sintético para explorar', list(EXAMPLES), key='nbr_fatigue_example_choice', format_func=EXAMPLES.get)
    st.button('Carregar cenário NBR selecionado', on_click=load_example, width='stretch')
    st.button('Restaurar exemplo de fadiga NBR', on_click=restore_demo, width='stretch')
    with st.expander('Importar entrada da fadiga nominal NBR'):
        st.caption('Esquema próprio desta página, com JSON estrito. Resultados e JSON EN não são entradas.')
        with st.form('nbr_fatigue_import_form'):
            st.file_uploader('Arquivo da entrada de fadiga NBR', type=['json'], key='nbr_fatigue_import_upload')
            st.text_area('Ou cole a entrada de fadiga NBR', key='nbr_fatigue_import_text', height=140)
            st.form_submit_button('Importar entrada de fadiga NBR', on_click=import_bundle, width='stretch')
    with st.expander('Importação explícita da base NBR 0.1'):
        st.caption('Somente entradas físicas e ações. Requer completar as novas premissas; não importa resultados, aprovações ou dados EN e não cria fontes.')
        with st.form('nbr_fatigue_physical_import_form'):
            st.file_uploader('Arquivo de entrada NBR 0.1', type=['json'], key='nbr_fatigue_nbr_import_upload')
            st.text_area('Ou cole a entrada NBR 0.1', key='nbr_fatigue_nbr_import_text', height=140)
            st.form_submit_button('Importar entradas físicas e ações NBR', on_click=import_physical_nbr, width='stretch')
    st.divider()
    st.caption('ABNT NBR 10084:2020; ABNT NBR 8400-2:2019 corrigida 2022, Anexo D, D.2.3, Equação (D.5). A fonte escrita não autentica documentos nem comprova inspeção.')

if 'nbr_fatigue_notice' in st.session_state:
    kind, message = st.session_state.pop('nbr_fatigue_notice')
    getattr(st, kind)(message)
if b.demonstration:
    st.warning('EXEMPLO SINTÉTICO. Geometria, ações, grupos, material e fontes são ilustrativos, não dados de fabricante nem comprovação de equipamento real.')

geometry, actions_tab, fatigue_tab, results_tab = st.tabs(['1 · Geometria e vínculos', '2 · Massas, rodas e dinâmica NBR', '3 · Premissas da fadiga', '4 · Resultados e arquivos'])
with geometry:
    c1, c2 = st.columns(2)
    with c1:
        p.project_name = t('Nome do projeto', p.project_name, 'project_name')
        p.member_name = t('Identificação da monovia', p.member_name, 'member_name')
        p.responsible = t('Responsável informado', p.responsible, 'responsible')
    with c2:
        b.demonstration = flag('Entrada demonstrativa / sintética', b.demonstration, 'demonstration',
            help='Desmarcar não verifica dados nem autentica fontes. Substitua todas as premissas ilustrativas por dados rastreáveis.')
        b.notes = t('Notas desta análise complementar', b.notes, 'notes', area=True)
    st.subheader('Um vão reto e seção I prismática')
    cols = st.columns(3)
    with cols[0]: p.span_m = n('Vão L (m)', p.span_m, 'span', minimum=.001, step=.1)
    with cols[1]: p.travel_min_m = n('Início da viagem do eixo de referência (m)', p.travel_min_m, 'travel_min', minimum=0., step=.05)
    with cols[2]: p.travel_max_m = n('Fim da viagem do eixo de referência (m)', p.travel_max_m, 'travel_max', minimum=0., step=.05)
    p.travel_source = t('Fonte dos limites físicos de viagem', p.travel_source, 'travel_source', area=True)
    p.section.name = t('Identificação da seção', p.section.name, 'section_name')
    st.caption('Recuperação inicial: I laminado, duplamente simétrico, de mesas paralelas. Fontes importadas não são convertidas automaticamente para esse domínio.')
    for col, key, label in zip(st.columns(5), ('d_mm', 'bf_mm', 'tw_mm', 'tf_mm', 'root_radius_mm'),
            ('Altura d (mm)', 'Largura bf (mm)', 'Alma tw (mm)', 'Mesa tf (mm)', 'Raio de raiz r (mm)')):
        with col: setattr(p.section, key, n(label, getattr(p.section, key), 'section_' + key, minimum=.001, step=1.))
    p.section.property_source = t('Fonte da geometria e do raio físico', p.section.property_source, 'section_source', area=True)
    p.edge_to_contact_mm = n('Distância da borda externa ao contato n (mm)', p.edge_to_contact_mm, 'contact', minimum=.001, step=1.)
    st.caption(f'Dois contatos opostos por estação: y = ±{(p.section.bf_mm / 2 - p.edge_to_contact_mm) / 1000:.6g} m; z = {(p.section.tf_mm - p.section.d_mm / 2) / 1000:.6g} m. A geometria de contato deriva da seção e de n; as estações não são reposicionadas ao editar o vão.')
    use_mass = flag('Usar massa linear documentada', p.section_mass_kg_per_m is not None, 'use_mass')
    if use_mass:
        p.section_mass_kg_per_m = n('Massa linear adotada (kg/m)', p.section_mass_kg_per_m if p.section_mass_kg_per_m is not None else 1., 'mass', minimum=.001, step=.1)
        p.section_mass_source = t('Fonte da massa linear', p.section_mass_source, 'mass_source')
    else:
        p.section_mass_kg_per_m = None
    cols = st.columns(2)
    with cols[0]: p.extra_dead_kn_per_m = n('Carga permanente distribuída adicional (kN/m)', p.extra_dead_kn_per_m, 'extra_dead', minimum=0., step=.01)
    with cols[1]: p.extra_dead_source = t('Fonte da carga adicional, inclusive zero', p.extra_dead_source, 'extra_dead_source')
    try: st.caption(f'Peso próprio atual: {p.self_weight_kn_m():.6g} kN/m. É recalculado da seção/massa linear atual; não inclui talha nem massas suspensas.')
    except (ValueError, TypeError, ZeroDivisionError, OverflowError) as exc: errors.append('Peso próprio: ' + human(exc))
    st.subheader('Garfos e condição axial independente')
    p.end_forks_confirmed = flag('Adotar garfos efetivos nas duas extremidades, com empenamento livre', p.end_forks_confirmed, 'end_forks')
    p.restraint_source = t('Fonte dos vínculos e do empenamento livre', p.restraint_source, 'restraint_source', area=True)
    st.info('O scanner utiliza o vão integral e garfos extremos. Travamentos cadastrados na base não criam apoios intermediários e não recebem crédito resistente nesta página de fadiga. O vínculo axial não é inferido do nome “garfo”.')
    with st.expander('Travamentos retidos apenas como registro da entrada'):
        st.json({'modo_de_origem': p.restraint_mode, 'mesa_superior_m': p.upper_braces_m,
            'mesa_inferior_m': p.lower_braces_m, 'eixo_lateral_m': p.lateral_axis_braces_m}, expanded=False)
        st.caption('Nenhum destes registros transforma esta análise em verificação de estabilidade.')
    axial_enabled = flag('Adotar transferência longitudinal Hs com vínculo axial explícito', b.axial_transfer is not None, 'axial_enabled')
    if axial_enabled:
        old = b.axial_transfer or AxialTransfer(False, False, False, '')
        equal = flag('Hs iguais nos dois contatos opostos de cada estação', old.equal_opposed_contacts_confirmed, 'axial_equal')
        left = flag('Restrição axial à esquerda no centro de cisalhamento', old.left_axial_restraint_at_shear_center_confirmed, 'axial_left')
        right = flag('Extremidade direita livre axialmente', old.right_axial_free_confirmed, 'axial_right')
        source = t('Fonte da premissa axial e da distribuição de Hs', old.source, 'axial_source', area=True)
        b.axial_transfer = AxialTransfer(equal, left, right, source) if equal and left and right and source.strip() else None
        if b.axial_transfer is None:
            st.caption('Premissa axial incompleta. Hs permanece na entrada; seus casos não serão apagados nem aprovados.')
    else:
        b.axial_transfer = None
    st.caption('Com pares longitudinais iguais, N e o transporte Hs·z permanecem. Apenas os transportes Mz/B fisicamente opostos se cancelam.')
    if st.button('Ver esquema físico NBR', key='nbr_fatigue_show_schematic'):
        try:
            from nbr_fatigue_report import schematic_nbr_fatigue
            st.image(schematic_nbr_fatigue(b), width='stretch')
        except (ImportError, ValueError, TypeError, KeyError) as exc: st.error('Esquema não disponível: ' + human(exc))

with actions_tab:
    st.subheader('Massas e carga útil separadas')
    for col, key, label, minimum in zip(st.columns(2), ('capacity_t', 'operating_payload_t'),
            ('Capacidade nominal de carga útil (t)', 'Carga útil operacional (t)'), (.001, 0.)):
        with col: setattr(p, key, n(label, getattr(p, key), key, minimum=minimum, step=.1))
    for col, key, label in zip(st.columns(2), ('trolley_hoist_mass_kg', 'retained_suspended_mass_kg'),
            ('Massa da talha/trole (kg)', 'Massa suspensa retida, sem carga útil (kg)')):
        with col: setattr(p, key, n(label, getattr(p, key), key, minimum=0., step=10.))
    p.equipment_source = t('Fonte da talha, carga útil e massas retidas', p.equipment_source, 'equipment_source', area=True)
    st.caption('Não some novamente acessórios/cabos já incluídos na massa retida. A capacidade nominal não determina CMAA, A, HC, HD nem E.')
    st.subheader('Estações longitudinais, duas rodas opostas por estação')
    p.equal_opposite_wheels = flag('Adotar duas rodas opostas iguais em cada estação', p.equal_opposite_wheels, 'equal_opposite_wheels')
    p.wheel_distribution_source = t('Fonte da distribuição de cargas e da igualdade das rodas', p.wheel_distribution_source, 'wheel_source', area=True)
    count = n('Número de estações longitudinais', len(p.stations), 'station_count', minimum=1, maximum=8, step=1)
    stations = []
    for i in range(count):
        old = p.stations[i] if i < len(p.stations) else Station(id=f'E{i+1}', offset_m=0., equipment_share=0., suspended_share=0.)
        with st.expander(f'Estação {i+1} · {old.id}', expanded=True):
            if i >= len(p.stations): st.caption('Nova estação: preencha offset e frações explicitamente. Não há redistribuição automática.')
            cols = st.columns(4)
            with cols[0]: sid = t('Identificação da estação', old.id, f'station_{i}_id')
            with cols[1]: offset = n('Offset longitudinal (m)', old.offset_m, f'station_{i}_offset', minimum=0., step=.1)
            with cols[2]: equipment = n('Fração da massa talha/trole', old.equipment_share, f'station_{i}_equipment', minimum=0., maximum=1., step=.05)
            with cols[3]: suspended = n('Fração das massas suspensas', old.suspended_share, f'station_{i}_suspended', minimum=0., maximum=1., step=.05)
            cols = st.columns(2)
            with cols[0]: hs = n('Hs longitudinal total do par (kN)', old.longitudinal_kn, f'station_{i}_hs', step=.1)
            with cols[1]: hy = n('Hy transversal total do par (kN)', old.transverse_kn, f'station_{i}_hy', step=.1)
            stations.append(Station(sid, offset, equipment, suspended, hs, hy))
    p.stations = stations
    st.caption('O primeiro offset é zero; os seguintes são crescentes. Cada coluna de frações soma 1 sem normalização silenciosa. Hs/Hy são forças totais por par, não por roda. Ambos os sinais são gerados quando a ação não é zero.')
    p.horizontal_action_source = t('Fonte das ações horizontais e sua cobertura física, inclusive zero', p.horizontal_action_source, 'horizontal_source', area=True)
    st.caption('Zero significa zero explicitamente adotado, nunca “não informado”. A cobertura de guiamento, rolamento e outros eventos reais exige documentação própria.')
    st.subheader('Dinâmica NBR da carga suspensa')
    p.dynamic_mode = select('Base do coeficiente dinâmico NBR', ('nbr8400_hc_hd', 'manual'), p.dynamic_mode, 'dynamic_mode',
        labels={'nbr8400_hc_hd': 'Classes HC/HD documentadas', 'manual': 'Coeficiente específico documentado'})
    cols = st.columns(3)
    with cols[0]: p.hoist_class = select('Classe HC da rota NBR', tuple(f'HC{i}' for i in range(1,5)), p.hoist_class, 'hc')
    with cols[1]: p.drive_class = select('Classe HD da rota NBR', tuple(f'HD{i}' for i in range(1,6)), p.drive_class, 'hd')
    with cols[2]: p.hoist_speed_m_s = n('Velocidade nominal de içamento (m/s)', p.hoist_speed_m_s, 'hoist_speed', minimum=.001, step=.01)
    has_creep = flag('Velocidade lenta explicitamente informada', p.creep_speed_m_s is not None, 'use_creep')
    if has_creep:
        p.creep_speed_m_s = n('Velocidade lenta de içamento (m/s)', p.creep_speed_m_s if p.creep_speed_m_s is not None else .01, 'creep_speed', minimum=.001, step=.01)
    else: p.creep_speed_m_s = None
    p.classification_source = t('Fonte das classes HC/HD e velocidades NBR', p.classification_source, 'dynamic_class_source', area=True)
    if p.dynamic_mode == 'manual':
        p.dynamic_psi_manual = n('Ψ específico adotado', p.dynamic_psi_manual, 'psi_manual', minimum=1., step=.05)
    p.dynamic_source = t('Fonte / justificativa do coeficiente específico', p.dynamic_source, 'dynamic_source', area=True)
    st.caption(f'Grupo do equipamento registrado na base: {p.equipment_group}. Não é o grupo E do componente. Os casos FAT8400 não usam a majoração de grupo Mₓ nem o coeficiente de flambagem ω.')
    try:
        dynamics = p.dynamics()
        st.caption(f'Ψ da entrada atual: {dynamics["psi"]:.6g}. Aplicado uma vez no gerador NBR, sem importar fatores EN.')
    except (ValueError, TypeError, OverflowError) as exc: errors.append('Dinâmica NBR: ' + human(exc))

with fatigue_tab:
    st.subheader('Material por produto e espessura')
    b.material_grade = select('Grau do material para fadiga NBR', ('não informado',) + LOW_GRADES + HIGH_GRADES, b.material_grade, 'material_grade')
    cols = st.columns(2)
    with cols[0]: p.material.fy_mpa = n('fy informado para a espessura (MPa)', p.material.fy_mpa, 'fy', minimum=1., step=5.)
    with cols[1]: p.material.fu_mpa = n('fu informado para a espessura (MPa)', p.material.fu_mpa, 'fu', minimum=1., step=5.)
    p.material.specification = t('Especificação física do material', p.material.specification, 'material_specification', area=True)
    b.material_source = t('Fonte do grau, fy/fu e faixa de espessura', b.material_source, 'material_source', area=True)
    cols = st.columns(2)
    with cols[0]: p.material.E_mpa = n('Módulo E da mecânica NBR (MPa)', p.material.E_mpa, 'E', minimum=1., step=1000.)
    with cols[1]: p.material.G_mpa = n('Módulo G da mecânica NBR (MPa)', p.material.G_mpa, 'G', minimum=1., step=1000.)
    st.caption('fy/fu e espessuras são lidos da entrada física acima. A espessura efetiva de cada região é selecionada pelo consumidor, não digitada como capacidade. E/G não são substituídos pelos valores da rota EN.')
    p.high_ratio_material_confirmed = flag('Adotar explicitamente o ramo material fy/fu > 0,70 quando aplicável', p.high_ratio_material_confirmed, 'high_ratio')
    b.high_ratio_material_source = t('Fonte da adoção do ramo fy/fu > 0,70', b.high_ratio_material_source, 'high_ratio_source', area=True)
    st.caption('Na igualdade fy/fu = 0,70, esta camada preserva a pendência da base. Nenhum ramo é adotado silenciosamente.')
    st.subheader('Grupo do componente, sem conversão de classes')
    b.component_group = select('Grupo E do componente', ('não informado',) + tuple(f'E{i}' for i in range(1,9)), b.component_group, 'component_group')
    b.classification_kind = select('Natureza da seleção do grupo',
        ('manual_code_selection', 'documented_component_classification', 'adopted_conservative_E8'), b.classification_kind, 'classification_kind',
        labels={'manual_code_selection': 'Seleção manual do código E, não classificação comprovada',
            'documented_component_classification': 'Classificação do componente documentada',
            'adopted_conservative_E8': 'Adoção conservadora de E8, não classe real inferida'})
    b.classification_source = t('Fonte do grupo E ou de sua adoção', b.classification_source, 'classification_source', area=True)
    st.caption('E1–E8 se refere ao componente. CMAA, grupo A do equipamento, HC/HD, ciclos isolados e categorias NBR 8800 não são convertidos em E nem controlam esta capacidade.')
    st.subheader('Detalhe nominal e requisito de fabricação')
    b.construction_detail = select('Detalhe construtivo abrangido', ('não selecionado', 'W0_plain_rolled_unnotched'), b.construction_detail, 'construction_detail',
        labels={'W0_plain_rolled_unnotched': 'W0 · material-base laminado sem entalhes nas regiões declaradas'})
    b.detail_source = t('Fonte e limites físicos do detalhe W0', b.detail_source, 'detail_source', area=True,
        help='“Laminado” não comprova ausência de furos, soldas, cortes, anexos ou perturbações. Identifique as regiões realmente abrangidas.')
    b.fabrication_requirement = select('Requisito de fabricação especificado, não inspeção realizada',
        ('não informado', 'specified_h6', 'specified_h6_qc'), b.fabrication_requirement, 'fabrication_requirement',
        labels={'specified_h6': 'Requisito h6 especificado', 'specified_h6_qc': 'Requisito h6 com controle de qualidade especificado'})
    b.fabrication_source = t('Fonte do requisito de fabricação / controle especificado', b.fabrication_source, 'fabrication_source', area=True)
    st.caption('A seleção registra uma especificação. Não declara inspeção efetivamente realizada nem verifica o estado construído.')
    b.kappa_minus_one_adopted = flag('Adotar conservadoramente κ = −1', b.kappa_minus_one_adopted, 'kappa')
    b.kappa_source = t('Fonte da adoção conservadora de κ = −1', b.kappa_source, 'kappa_source', area=True)
    st.caption('κ adotado não é uma história temporal calculada. A interação continua sendo a Equação (D.5) com admissíveis específicas de fadiga, não uma faixa de von Mises.')
    with st.expander('Convergência e aceitação numérica', expanded=True):
        p.max_refinements = n('Máximo de refinamentos de translação', p.max_refinements, 'max_refinements', minimum=0, maximum=8, step=1)
        b.numerical_tolerance = n('Tolerância relativa de refinamento e aceitação da fadiga NBR', b.numerical_tolerance, 'accepted_tolerance', minimum=.0001, maximum=.02, step=.0005, format='%.4f')
        b.numerical_source = t('Fonte da aceitação numérica', b.numerical_source, 'numerical_source', area=True)
        st.caption('São necessários dois passes estáveis. J/Cw canônicos são escolhidos antes da solução; Cw difere intencionalmente da aproximação da base. Convergência é evidência numérica de engenharia, não certificado de majorante de todo o contínuo.')

b.project = p
st.session_state.nbr_fatigue_bundle = b
try:
    b.validate()
except (ValueError, TypeError, OverflowError, KeyError, AttributeError) as exc:
    errors.append(human(exc))
if errors:
    invalidate()
    st.error('Revise as entradas antes de calcular:\n\n' + '\n\n'.join(dict.fromkeys(errors)))
else:
    current = st.session_state.get('nbr_fatigue_result')
    if current is not None:
        try:
            from nbr_fatigue_analysis import assert_current_nbr_fatigue_result
            assert_current_nbr_fatigue_result(b, current)
        except (ValueError, TypeError, ImportError, KeyError, AttributeError):
            invalidate()

with results_tab:
    st.subheader('Domínio e fontes da análise')
    st.caption('Um vão reto, recuperação elástica nominal, casos carregado/vazio e todos os sinais prescritos da entrada. “Todos os casos gerados” não significa “todas as ações físicas possíveis”. As fontes não foram autenticadas automaticamente.')
    with st.expander('Fontes declaradas na entrada atual'):
        st.dataframe(pd.DataFrame([{'Premissa': label, 'Fonte declarada': value} for label, value in (
            ('Geometria', p.section.property_source), ('Talha/massas', p.equipment_source),
            ('Rodas opostas', p.wheel_distribution_source), ('Viagem', p.travel_source),
            ('Horizontais/cobertura', p.horizontal_action_source), ('Garfos', p.restraint_source),
            ('Transferência axial', b.axial_transfer.source if b.axial_transfer else 'Não adotada'),
            ('Material por espessura', b.material_source), ('Grupo do componente', b.classification_source),
            ('Detalhe W0', b.detail_source), ('Fabricação especificada', b.fabrication_source),
            ('κ = −1', b.kappa_source), ('Aceitação numérica', b.numerical_source))]), hide_index=True, width='stretch')
    st.subheader('Limitações permanentes')
    for limitation in PERMANENT_LIMITATIONS: st.write('• ' + limitation)
    st.caption('Hy pode manter a alma nominal não planar pendente, sem apagar as mesas. Eixos próximos ou distância insuficiente à extremidade podem impedir resultados locais sem eliminar os globais válidos.')
    if st.button('Calcular fadiga nominal NBR', type='primary', disabled=bool(errors), width='stretch', key='nbr_fatigue_calculate'):
        invalidate()
        progress = st.progress(0., text='Preparando casos genuínos FAT8400…')
        def report(fraction, title):
            progress.progress(max(0., min(1., float(fraction))), text=str(title))
        try:
            from nbr_fatigue_analysis import analyze_nbr_fatigue, assert_current_nbr_fatigue_result
            with st.spinner('Calculando mecânica e fadiga nominal NBR…'):
                result = analyze_nbr_fatigue(b, progress=report)
                assert_current_nbr_fatigue_result(b, result)
            st.session_state.nbr_fatigue_result = result
            progress.progress(1., text='Recibo atual produzido. Consulte as pendências e cada resultado nominal.')
        except (ValueError, TypeError, ImportError, KeyError, RuntimeError, OverflowError) as exc:
            invalidate()
            progress.empty()
            st.error('Não foi possível concluir: ' + human(exc))
    if not errors:
        st.download_button('Baixar entrada JSON da fadiga NBR', b.to_json(), file_name='monovia_entrada_fadiga_NBR.json', mime='application/json', key='nbr_fatigue_download_input')
    result = st.session_state.get('nbr_fatigue_result')
    if result is None:
        st.info('Nenhum resultado atual. Calcule após conferir as entradas. Qualquer edição de valor ou fonte remove o cálculo e seus downloads; Word e resultado só aparecem para um recibo atual.')
    else:
        summary = result.get('summary', {})
        checks = result.get('checks', [])
        cases = result.get('cases', [])
        st.caption(f'Casos FAT8400 gerados: {summary.get("generated_cases", len(cases))}; calculados: {summary.get("calculated_cases", 0)}; convergidos: {summary.get("converged_cases", 0)}. Isso não é uma contagem de partes aprovadas da viga.')
        st.subheader('Pendências e casos não calculados')
        pending = [c for c in checks if c.get('status') in ('PENDING', 'NOT_CALCULATED', 'OUT_OF_SCOPE', 'OUT_OF_DOMAIN', 'ERROR')]
        if pending: st.dataframe(check_table(pending), hide_index=True, width='stretch')
        else: st.caption('Nenhuma pendência nominal retornada nas verificações listadas. As limitações permanentes continuam válidas.')
        for case in cases:
            if case.get('error'): st.warning(case.get('title', case.get('id', 'Caso')) + ': ' + human(case['error']))
        st.subheader('Resultados por região, ponto e plano nominal')
        st.caption('Limite suficiente satisfeito é parcial e condicional. Majorante excedido exige análise adicional; não é falha física testemunhada. Nenhuma soma de resultados declara aprovação integral.')
        if checks: st.dataframe(check_table(checks), hide_index=True, width='stretch')
        else: st.caption('Não há verificação nominal disponível neste recibo.')
        numerical = [c for c in checks if isinstance(c.get('utilization'), (float, int)) and not isinstance(c.get('utilization'), bool) and math.isfinite(c['utilization'])]
        if numerical:
            st.subheader('Maiores utilizações numéricas dos majorantes')
            st.dataframe(check_table(sorted(numerical, key=lambda c: c['utilization'], reverse=True)[:5]), hide_index=True, width='stretch')
        with st.expander('Tensores, seis componentes, zeros nominais e interação (D.5)'):
            st.caption('Cada identificador preserva região, ponto, lado/face e plano. Zeros da idealização nominal não provam tensão nula nas concentrações reais. A caixa de extremos combina máximos potencialmente não concomitantes.')
            nominal = result.get('nominal') or {}
            st.json({'planos': nominal.get('planes', []), 'intervalos_de_esforcos': nominal.get('resultant_intervals', {}),
                'verificacoes_com_admissiveis_e_interacao': checks}, expanded=False)
        if cases:
            selected = st.selectbox('Caso FAT8400 para inspeção', range(len(cases)), key='nbr_fatigue_result_case',
                format_func=lambda i: cases[i].get('title', cases[i].get('id', '')) + ' · ' + cases[i].get('id', ''))
            case = cases[selected]
            if case.get('calculated'):
                st.subheader('Diagramas de um estado concomitante')
                st.caption('s longitudinal, y transversal, z vertical para cima, mão direita. My é momento forte em torno de y; Mz é momento fraco em torno de z. Os diagramas não são a caixa usada em D.5 nem uma história temporal.')
                translation = st.number_input('Translação do eixo de referência no diagrama (m)', min_value=float(p.travel_min_m),
                    max_value=float(p.travel_max_m), value=float((p.travel_min_m + p.travel_max_m) / 2), step=.05, key='nbr_fatigue_diagram_translation')
                if st.button('Gerar diagramas NBR deste estado', key='nbr_fatigue_generate_diagram'):
                    try:
                        from nbr_fatigue_analysis import diagram_nbr_fatigue
                        data = diagram_nbr_fatigue(b, result, case['id'], translation_m=translation)
                        st.session_state.nbr_fatigue_diagram = dict(signature=b.signature(), case_id=case['id'], translation=translation, data=data)
                    except (ImportError, ValueError, TypeError, KeyError) as exc: st.error('Diagramas: ' + human(exc))
                cached = st.session_state.get('nbr_fatigue_diagram')
                if cached and cached['signature'] == b.signature() and cached['case_id'] == case['id'] and cached['translation'] == translation:
                    try:
                        from nbr_fatigue_report import diagram_figure
                        data = cached['data']
                        st.image(diagram_figure(data), width='stretch')
                        st.caption('Reações do apoio SOBRE a viga; a carga transmitida pela viga ao apoio é o vetor oposto.')
                        if data.get('support_on_beam'):
                            st.dataframe(pd.DataFrame([{'Componente física e unidade': key, 'Apoio sobre viga': value,
                                'Viga sobre apoio': data.get('beam_on_support', {}).get(key)}
                                for key, value in data['support_on_beam'].items()]), hide_index=True, width='stretch')
                    except (ImportError, ValueError, TypeError, KeyError) as exc: st.error('Figura: ' + human(exc))
            with st.expander('Caso, ledger das rodas, intervalos e histórico de convergência'):
                st.caption('Fatores do caso e forças finais são conservados uma vez. Não reaplique dinâmica nem divida novamente a força individual por dois.')
                st.json(case, expanded=False)
        with st.expander('Trilha de auditoria, fontes e limites do recibo'):
            st.json({key: result.get(key) for key in ('summary', 'sources', 'limitations', 'interpretation', 'input_signature', 'result_signature', 'created_utc', 'whole_design_approved')}, expanded=False)
        st.subheader('Arquivos do cálculo atual')
        st.caption('Pendências, erros de casos e majorantes excedidos são exportáveis. Exportar não significa aprovar. O JSON de evidência não pode ser reimportado como entrada.')
        try:
            from nbr_fatigue_analysis import assert_current_nbr_fatigue_result
            from nbr_fatigue_report import export_nbr_fatigue_json, export_nbr_fatigue_word
            assert_current_nbr_fatigue_result(b, result)
            st.download_button('Baixar resultado JSON da fadiga NBR', export_nbr_fatigue_json(b, result), file_name='monovia_resultado_fadiga_NBR.json', mime='application/json', key='nbr_fatigue_download_result')
            if st.button('Preparar relatório Word da fadiga NBR', key='nbr_fatigue_prepare_word'):
                with st.spinner('Preparando relatório de fadiga nominal NBR…'):
                    st.session_state.nbr_fatigue_word = export_nbr_fatigue_word(b, result)
                    st.session_state.nbr_fatigue_word_signature = b.signature()
            if st.session_state.get('nbr_fatigue_word') and st.session_state.get('nbr_fatigue_word_signature') == b.signature():
                assert_current_nbr_fatigue_result(b, result)
                st.download_button('Baixar Word da fadiga NBR', st.session_state.nbr_fatigue_word, file_name='monovia_relatorio_fadiga_NBR.docx',
                    mime='application/vnd.openxmlformats-officedocument.wordprocessingml.document', key='nbr_fatigue_download_word')
        except (ImportError, ValueError, TypeError, KeyError) as exc: st.error('Exportação indisponível ou recusada: ' + human(exc))
