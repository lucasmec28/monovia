"""Independent EN editor. Does not import state, actions or results from NBR UI."""
from __future__ import annotations
from copy import deepcopy
from dataclasses import asdict, replace
from pathlib import Path
import json
import math
import sys

# Development-only layout; release packaging places these modules at app root.
ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
if not (ROOT / 'en_project.py').exists():
    for folder in ('extension_torsion', 'extension_en_actions'):
        path = str(ROOT.parent / folder)
        if path not in sys.path:
            sys.path.insert(0, path)

import pandas as pd
import streamlit as st
from en_project import ENProject, demo_en_project, synchronize_beam_gravity
from en_examples import complete_en_example, failed_en_example, out_of_domain_en_example
from en_actions import (ENWheel, ENFixedGravity, ENHoistDynamics, ENTravelDynamics,
    ENManufacturerWheelForce, ENManufacturerHorizontalSet, ENTestRequest, generate_actions)
from analytical_scan import AxialTransfer
from monorail.model import Station

st.set_page_config(page_title='Monovia · Complemento EN', page_icon='🏗️', layout='wide')
PREFIX = 'en_ui_'
STATUS = {'PASS':'Atende no domínio', 'FAIL':'Não atende', 'BOUND_EXCEEDED':'Majorante excedido',
          'PENDING':'Pendente', 'OUT_OF_SCOPE':'Fora do domínio', 'OUT_OF_DOMAIN':'Fora do domínio', 'NOT_CALCULATED':'Não calculado', 'ERROR':'Não calculado'}
FAMILIES = {'EN_ULS_STR':'ELU estrutural', 'EN_SLS_STRESS':'Serviço · tensões',
    'EN_SLS_DEFLECTION':'Serviço · flechas', 'EN_TEST_ULS':'Ensaio · ELU', 'EN_TEST_SLS':'Ensaio · serviço'}


def invalidate():
    st.session_state.en_result = None
    st.session_state.en_word = None
    st.session_state.en_word_signature = None
    st.session_state.en_diagram = None


def reset(bundle, notice):
    st.session_state.en_bundle = bundle
    invalidate()
    for key in list(st.session_state):
        if str(key).startswith(PREFIX):
            del st.session_state[key]
    st.session_state.en_notice = ('success', notice)


def demo():
    reset(complete_en_example(), 'Exemplo sintético EN preenchido restaurado. Nenhum resultado anterior foi mantido.')


def load_example():
    kind = st.session_state.get('en_example_choice','complete')
    factory = {'complete':complete_en_example,'basic':demo_en_project,
        'failed':failed_en_example,'outside':out_of_domain_en_example,'pending':demo_en_project}[kind]
    bundle = factory()
    if kind=='pending':
        bundle.axial_transfer = None
        bundle.notes += ' Cenário demonstrativo de pendência: vínculo axial não adotado; casos Hs não devem desaparecer nem ser aprovados.'
    reset(bundle, 'Cenário sintético carregado explicitamente. Todas as fontes são ilustrativas; calcule para obter o resultado atual.')


def import_bundle():
    # A rejected import must never leave a previous approval/export apparent.
    invalidate()
    upload = st.session_state.get('en_import_upload')
    pasted = st.session_state.get('en_import_text', '').strip()
    try:
        if upload is not None and pasted:
            raise ValueError('Escolha arquivo ou texto, não ambos.')
        raw = upload.getvalue() if upload is not None else pasted
        if not raw:
            raise ValueError('Selecione um arquivo de entrada ou cole o JSON.')
        bundle = ENProject.from_json(raw)
    except (ValueError, TypeError, UnicodeError, OverflowError) as exc:
        st.session_state.en_notice = ('error', 'Importação recusada. ' + human(exc) + ' As entradas atuais foram preservadas; o resultado anterior foi removido.')
        return
    reset(bundle, 'Entradas EN importadas. Calcule novamente para gerar um recibo local.')


def human(exc):
    value = str(exc)
    replacements = {
        'G_beam does not equal the adopted section/linear-mass self-weight; update the EN origin after changing section':
            'G da viga difere do peso da seção/massa linear atual. Use “Atualizar G da viga”.',
        'Missing/unknown EN bundle fields; results are not project inputs':
            'Formato EN inválido: campos ausentes ou desconhecidos. JSON de resultado, de ponte e da rota NBR não são entradas EN.',
        'Span and wheel travel must coincide in geometry and EN actions':'Vão e viagem devem coincidir entre geometria e ações EN.',
        'Every EN physical wheel station must match the mechanical geometry':'Os offsets das rodas EN devem coincidir com os eixos geométricos.',
        'EN wheel y/z does not match the declared lower-flange contact geometry; edit explicitly, never relocate silently':
            'As coordenadas y/z das rodas EN não coincidem com os contatos da seção. Revise explicitamente as tabelas de rodas e de fabricante; não houve deslocamento automático.',
        'Initial EN application requires exactly two opposed lower-flange contacts per station':
            'Esta versão exige exatamente dois contatos opostos na mesa inferior por eixo.',
        'Initial EN application requires equal opposed vertical shares for':
            'Esta versão exige frações verticais iguais entre os dois contatos opostos para',
        'Explicit axial premise required':'Premissa axial explícita obrigatória',
        'Typed physical geometry, independent EN actions and material basis required':'Geometria, ações EN e base de material tipadas são obrigatórias.',
    }
    for raw, translated in replacements.items():
        value = value.replace(raw, translated)
    return value


def n(label, value, key, *, minimum=None, maximum=None, step=None, disabled=False, help=None, format=None):
    args = dict(value=value, key=PREFIX+key, on_change=invalidate, disabled=disabled, help=help)
    # Widget convenience ranges must not reject a valid imported model before
    # model validation. Extend the visible range; never clamp/change its value.
    outside_editor = ((minimum is not None and value < minimum) or
                      (maximum is not None and value > maximum))
    integer_editor = type(value) is int and all(v is None or type(v) is int for v in (minimum,maximum,step))
    numeric = int if integer_editor else float
    args['value'] = numeric(value)
    if minimum is not None: args['min_value'] = numeric(min(minimum,value))
    if maximum is not None: args['max_value'] = numeric(max(maximum,value))
    if step is not None: args['step'] = numeric(step)
    if format is not None: args['format'] = format
    elif isinstance(value,float) and 0 < abs(value) < .001: args['format'] = '%.8e'
    result = st.number_input(label, **args)
    if outside_editor:
        st.caption('Entrada importada preservada sem truncamento. A faixa visual foi ampliada; a validação do modelo e o cálculo definem seu domínio.')
    return value if result == value else result


def t(label, value, key, *, help=None, area=False, disabled=False):
    return (st.text_area if area else st.text_input)(label, value=value, key=PREFIX+key,
        on_change=invalidate, help=help, disabled=disabled)


def flag(label, value, key, *, help=None):
    return st.checkbox(label, value=value, key=PREFIX+key, on_change=invalidate, help=help)


def select(label, options, value, key, *, labels=None, help=None):
    options = list(options)
    if value not in options: options.append(value)
    return st.selectbox(label, options, index=options.index(value), key=PREFIX+key,
        on_change=invalidate, format_func=lambda v: (labels or {}).get(v, v), help=help)


def table(data, key, labels, *, dynamic=False, disabled=()):
    frame = pd.DataFrame(data)
    return st.data_editor(frame, key=PREFIX+key, hide_index=True, width='stretch',
        num_rows='dynamic' if dynamic else 'fixed', on_change=invalidate,
        disabled=list(disabled), column_config={name:st.column_config.Column(label) for name,label in labels.items()})


def rows(frame):
    # Empty added cells are errors, not implicit zeros or copied declarations.
    result = frame.to_dict('records')
    for row in result:
        for key,value in row.items():
            if isinstance(value,float) and math.isnan(value): row[key] = None
    return result


def floats(row, names):
    row = dict(row)
    for name in names:
        if row[name] is None or isinstance(row[name],bool):
            raise ValueError('Preencha explicitamente a coluna ' + name + ', inclusive quando zero.')
        row[name] = float(row[name])
        if not math.isfinite(row[name]):
            raise ValueError('Número finito obrigatório na coluna ' + name + '.')
    return row


def check_table(checks):
    output = []
    for item in checks:
        if not isinstance(item,dict): continue
        demand,capacity,unit = item.get('demand'),item.get('capacity'),item.get('unit','')
        if 'demand_mm' in item:
            demand,capacity,unit = item['demand_mm'],item.get('limit_mm'),'mm'
        elif 'individual_wheel_N' in item:
            demand,capacity,unit = item['individual_wheel_N'],item.get('capacity_N'),'N'
        elif 'demand_mpa' in item:
            demand,capacity,unit = item['demand_mpa'],item.get('resistance_mpa'),'MPa'
        reasons = item.get('reasons',item.get('reason',''))
        if isinstance(reasons,(tuple,list)): reasons = '; '.join(str(x) for x in reasons)
        output.append({'Situação':STATUS.get(item.get('status'),item.get('status','')),
            'Mecanismo':item.get('mechanism_label',''),
            'Verificação':item.get('title',item.get('name',item.get('id',''))),
            'Solicitação / majorante':demand,'Resistência / limite':capacity,
            'Utilização':item.get('utilization'),'Unidade':unit,'Observação':reasons})
    return pd.DataFrame(output)


if 'en_bundle' not in st.session_state:
    st.session_state.en_bundle = complete_en_example()
    invalidate()
b = deepcopy(st.session_state.en_bundle)
p, a, basis = b.project, b.actions, b.resistance
errors = []

st.title('Monovia · Complemento EN')
st.caption('Rota independente de ações, material e verificações. A geometria pode ser comum; fatores e classes NBR/CMAA não são convertidos em EN.')
with st.sidebar:
    st.subheader('Projeto EN')
    st.selectbox('Cenário sintético para explorar',('complete','basic','pending','failed','outside'),
        key='en_example_choice',format_func=lambda x:{'complete':'Dados preenchidos + ensaios',
        'basic':'Exemplo básico sem ensaios','pending':'Pendência: vínculo axial ausente',
        'failed':'Critérios desfavoráveis: carga elevada','outside':'Fora do domínio global: alma esbelta'}[x])
    st.button('Carregar cenário selecionado',on_click=load_example,width='stretch')
    st.button('Restaurar exemplo EN', on_click=demo, width='stretch')
    with st.expander('Importar entrada JSON EN'):
        st.caption('Somente o bundle EN desta página. Resultados e entradas da rota NBR não são convertidos.')
        with st.form('en_import_form'):
            st.file_uploader('Arquivo JSON EN', type=['json'], key='en_import_upload')
            st.text_area('Ou cole a entrada JSON EN', key='en_import_text', height=140)
            st.form_submit_button('Importar entrada EN', on_click=import_bundle, width='stretch')
    st.divider()
    st.caption('Edições de ações: EN 1991-3:2006 + AC:2012; EN 1990:2002 + A1:2005. Serviço: EN 1993-6:2007 + AC:2009. A base resistente e suas edições são declaradas separadamente abaixo.')
    st.caption('Valores recomendados EN. Nenhum Anexo Nacional foi selecionado ou verificado. Não há aprovação global automática.')

if 'en_notice' in st.session_state:
    kind, message = st.session_state.pop('en_notice')
    getattr(st,kind)(message)
if b.demonstration:
    st.warning('EXEMPLO SINTÉTICO. Forças laterais, HC, Classe 1, material e fontes são ilustrativos, não dados de fabricante nem comprovação de equipamento real.')

geometry, actions_tab, material_tab, results_tab = st.tabs(['1 · Geometria e peso próprio', '2 · Ações e rodas EN', '3 · Material e vínculos', '4 · Resultados e arquivos'])
with geometry:
    c1,c2 = st.columns(2)
    with c1:
        p.project_name = t('Nome do projeto',p.project_name,'project_name')
        p.member_name = t('Identificação da monovia',p.member_name,'member_name')
        p.responsible = t('Responsável informado',p.responsible,'responsible')
    with c2:
        b.demonstration = flag('Projeto demonstrativo / sintético',b.demonstration,'demonstration',
            help='Desmarcar não verifica as fontes nem aprova o projeto. Substitua todas as premissas ilustrativas por dados rastreáveis.')
        p.demonstration = b.demonstration
        b.notes = t('Notas do bundle EN',b.notes,'notes',area=True)
    st.subheader('Viga reta, um vão e viagem física')
    c1,c2,c3 = st.columns(3)
    with c1: p.span_m = n('Vão L (m)',p.span_m,'span',minimum=.001,step=.1)
    with c2: p.travel_min_m = n('Início da viagem do eixo de referência (m)',p.travel_min_m,'travel_min',minimum=0.,step=.05)
    with c3: p.travel_max_m = n('Fim da viagem do eixo de referência (m)',p.travel_max_m,'travel_max',minimum=0.,step=.05)
    p.travel_source = t('Fonte dos limites de viagem',p.travel_source,'travel_source')
    st.caption('O primeiro offset de roda deve ser zero. Toda a composição de rodas precisa permanecer no vão durante a viagem.')
    st.subheader('Seção I laminada, duplamente simétrica')
    p.section.name = t('Identificação da seção',p.section.name,'section_name')
    columns = st.columns(5)
    for column,key,label in zip(columns,('d_mm','bf_mm','tw_mm','tf_mm','root_radius_mm'),('Altura d (mm)','Largura b (mm)','Alma tw (mm)','Mesa tf (mm)','Raio de raiz r (mm)')):
        with column: setattr(p.section,key,n(label,float(getattr(p.section,key)),'section_'+key,minimum=.001,step=1.))
    p.section.property_source = t('Fonte das dimensões e do raio físico',p.section.property_source,'section_source',area=True,
        help='A rigidez usa três retângulos, sem crédito de raios. O raio físico participa da geometria local. Nenhum catálogo é gerado por esta página.')
    p.edge_to_contact_mm = n('Distância da borda externa ao contato n (mm)',p.edge_to_contact_mm,'contact',minimum=.001,step=1.)
    st.caption(f'Contato geométrico esperado: y = ±{(p.section.bf_mm/2-p.edge_to_contact_mm)/1000:.6g} m; z = {(p.section.tf_mm-p.section.d_mm/2)/1000:.6g} m. Ao editar a seção, revise explicitamente y/z das rodas e das forças de fabricante. Essas coordenadas não são movidas silenciosamente.')
    use_mass = flag('Adotar massa linear documentada em vez da área geométrica',p.section_mass_kg_per_m is not None,'use_mass')
    if use_mass:
        p.section_mass_kg_per_m = n('Massa linear adotada (kg/m)',float(p.section_mass_kg_per_m or 1.),'mass',minimum=.001,step=.1)
        p.section_mass_source = t('Fonte da massa linear',p.section_mass_source,'mass_source')
    else:
        p.section_mass_kg_per_m = None
    st.caption('G_beam é um registro obrigatório independente das ações móveis. Alterar geometria não atualiza silenciosamente esse registro.')
    try:
        self_weight = p.self_weight_kn_m()
        recorded = next(x.downward_kn_per_m for x in a.fixed_gravity if x.origin_id=='G_beam')
        left,right = st.columns(2)
        left.metric('Peso próprio atual da seção (kN/m)',f'{self_weight:.6g}')
        right.metric('G_beam registrado nas ações EN (kN/m)',f'{recorded:.6g}')
        if st.button('Atualizar G da viga',key='en_sync_g'):
            b.actions = a
            synchronize_beam_gravity(b)
            a = b.actions
            invalidate()
            st.success('G_beam atualizado explicitamente a partir da seção/massa linear atual.')
    except (ValueError,StopIteration,ZeroDivisionError) as exc:
        errors.append('Peso próprio: '+human(exc))
    if st.button('Ver esquema físico EN',key='en_show_schematic'):
        try:
            from en_report import schematic_en
            st.image(schematic_en(b),width='stretch')
        except ImportError:
            st.caption('Adaptador de esquema ainda não está disponível nesta montagem de desenvolvimento.')
        except (ValueError,TypeError) as exc:
            st.error('Esquema: '+human(exc))
    with st.expander('Ações permanentes adicionais G, separadas da talha'):
        original = [asdict(x) for x in a.fixed_gravity if x.origin_id!='G_beam']
        frame = table(pd.DataFrame(original,columns=['origin_id','downward_kn_per_m','source']), 'extra_g',
            {'origin_id':'Origem','downward_kn_per_m':'Carga para baixo (kN/m)','source':'Fonte / justificativa'},dynamic=True)
        try:
            added = tuple(ENFixedGravity(**floats(x,('downward_kn_per_m',))) for x in rows(frame))
            if any(x.origin_id=='G_beam' for x in added): raise ValueError('G_beam é reservado ao peso próprio vinculado.')
            a = replace(a,fixed_gravity=tuple(x for x in a.fixed_gravity if x.origin_id=='G_beam')+added)
        except (TypeError,ValueError,KeyError) as exc: errors.append('G adicional: '+human(exc))

with actions_tab:
    st.subheader('Origens móveis, sempre separadas')
    st.caption('kN são forças, não massas. Qc é peso variável da talha/trole e NÃO é G fixo da viga. Qh reúne carga útil, acessórios retidos e cabos/correntes suspensos uma única vez.')
    values = {}
    for column,key,label in zip(st.columns(3),('qc_kn','nominal_payload_kn','operating_payload_kn'),('Qc · talha e trole (kN)','Carga útil nominal (kN)','Carga útil operacional (kN)')):
        with column: values[key] = n(label,float(getattr(a,key)),key,minimum=0.,step=.1)
    for column,key,label in zip(st.columns(2),('retained_lifting_accessories_kn','moving_suspended_ropes_kn'),('Acessórios suspensos retidos (kN)','Cabos/correntes suspensos móveis (kN)')):
        with column: values[key] = n(label,float(getattr(a,key)),key,minimum=0.,step=.1)
    values['equipment_name'] = t('Identificação da talha/trole',a.equipment_name,'equipment_name')
    values['component_source'] = t('Fonte das cargas e componentes',a.component_source,'component_source',area=True)
    values['domain_source'] = t('Fonte / adoção do domínio físico',a.domain_source,'domain_source',area=True,
        help='Monovia reta fixa, interna, talha de gancho, carga livre para oscilar; demais eventos precisam de cobertura própria.')
    a = replace(a,**values)
    st.subheader('Dinâmica EN própria')
    c1,c2 = st.columns(2)
    with c1:
        hc = select('Classe de içamento HC da rota EN',('HC1','HC2','HC3','HC4'),a.hoist_dynamics.hoist_class,'hc',
            help='Não depende da capacidade nominal. Não existe equivalência automática com HD, grupos NBR ou CMAA.')
        speed = n('Velocidade estável de içamento EN (m/s)',a.hoist_dynamics.steady_speed_m_s,'hoist_speed',minimum=0.,step=.01)
        hc_source = t('Fonte da classe HC EN',a.hoist_dynamics.classification_source,'hc_source')
        speed_source = t('Fonte da velocidade estável',a.hoist_dynamics.speed_source,'speed_source')
        a = replace(a,hoist_dynamics=ENHoistDynamics(hc,speed,hc_source,speed_source))
    with c2:
        travel_basis = select('Base de φ4 para translação',('unresolved','class1_documented','manufacturer'),a.travel_dynamics.basis,'phi4_basis',
            labels={'unresolved':'Não demonstrada · G6 pendente','class1_documented':'Classe 1 EN 1090-2 documentada','manufacturer':'Valor documentado de fabricante'})
        phi4 = None if travel_basis=='unresolved' else (1. if travel_basis=='class1_documented' else n('φ4 do fabricante',float(a.travel_dynamics.phi4 or 1.),'phi4',minimum=1.,step=.01))
        if travel_basis=='class1_documented': st.caption('φ4 = 1 somente sob a premissa Classe 1 comprovada. No exemplo, essa premissa é apenas ilustrativa.')
        phi4_source = t('Fonte / comprovação de φ4',a.travel_dynamics.source,'phi4_source',area=True)
        a = replace(a,travel_dynamics=ENTravelDynamics(travel_basis,phi4,phi4_source))
    st.subheader('Rodas físicas e distribuição por origem')
    st.caption('Uma linha por roda, não por par. Eixos físicos: s longitudinal; y transversal; z vertical para cima. Offset, y e z em m. Frações de cada origem devem somar 1; não há normalização nem divisão automática por dois. O adaptador inicial exige dois contatos opostos iguais por eixo.')
    wheel_labels = {'wheel_id':'Roda','offset_m':'Offset s (m)','y_m':'y (m)','z_m':'z (m)',
        'qc_fraction':'Fração Qc','payload_fraction':'Fração útil','retained_fraction':'Fração acessórios','ropes_fraction':'Fração cabos',
        'maximum_static_vertical_kn':'Máximo vertical estático (kN)','maximum_static_vertical_source':'Fonte do máximo estático'}
    frame = table([asdict(w) for w in a.wheels],'wheels',wheel_labels,dynamic=True)
    try:
        wheels = []
        for row in rows(frame):
            row = floats(row,('offset_m','y_m','z_m','qc_fraction','payload_fraction','retained_fraction','ropes_fraction'))
            if row['maximum_static_vertical_kn'] is not None: row['maximum_static_vertical_kn'] = float(row['maximum_static_vertical_kn'])
            wheels.append(ENWheel(**row))
        station_values_before = [(w.wheel_id,w.offset_m,w.qc_fraction,w.payload_fraction) for w in a.wheels]
        station_values_after = [(w.wheel_id,w.offset_m,w.qc_fraction,w.payload_fraction) for w in wheels]
        a = replace(a,wheels=tuple(wheels))
        # Preserve imported carrier provenance/IDs until the user actually edits
        # the wheel offsets or shares; its legacy action sources are inert EN.
        if wheels and station_values_before != station_values_after:
            old_stations = {station.offset_m:station for station in p.stations}
            p.stations = [Station(id=old_stations[offset].id if offset in old_stations else f'EN-E{i+1}',offset_m=offset,
                equipment_share=sum(w.qc_fraction for w in wheels if w.offset_m==offset),
                suspended_share=sum(w.payload_fraction for w in wheels if w.offset_m==offset)) for i,offset in enumerate(sorted({w.offset_m for w in wheels}))]
    except (ValueError,TypeError,KeyError) as exc: errors.append('Tabela de rodas: '+human(exc))
    distribution_source = t('Fonte da distribuição entre rodas',a.wheel_distribution_source,'distribution_source',area=True)
    a = replace(a,wheel_distribution_source=distribution_source)
    with st.expander('Posição declarada do gancho'):
        hooks = {}
        for column,key,label in zip(st.columns(3),('hook_offset_m','hook_y_m','hook_z_m'),('Offset do gancho (m)','y do gancho (m)','z do gancho (m)')):
            with column: hooks[key] = n(label,float(getattr(a,key)),key,step=.01)
        a = replace(a,**hooks)
        st.caption('A distribuição de forças nas rodas é uma entrada documentada, não deduzida automaticamente da posição do gancho.')
    st.subheader('Conjuntos horizontais correlacionados')
    st.caption('Hy não é inventado como porcentagem. Cada conjunto de fabricante precisa declarar todas as rodas, forças assinadas, alturas reais e simultaneidade. O fallback Hs = ±5% do máximo estático por roda é gerado separadamente, sem dinâmica e sem somá-lo automaticamente a Hy.')
    count = n('Número de conjuntos horizontais documentados',len(a.manufacturer_horizontal_sets),'horizontal_count',minimum=0,maximum=12,step=1)
    suppliers = []
    for i in range(count):
        old = a.manufacturer_horizontal_sets[i] if i<len(a.manufacturer_horizontal_sets) else ENManufacturerHorizontalSet(f'CONJUNTO_{i+1}','G6','','','','',False,())
        with st.expander(f'Conjunto horizontal {i+1} · {old.set_id}',expanded=count==1):
            sid = t('Identificação do conjunto',old.set_id,f'h_{i}_id')
            source = t('Fonte das forças características',old.source,f'h_{i}_source')
            simultaneous = t('Fonte da simultaneidade com o grupo G6',old.simultaneity_source,f'h_{i}_simultaneity',area=True)
            direction = t('Direção / evento coberto por este vetor',old.direction_description,f'h_{i}_direction')
            location = t('Fonte das coordenadas e altura real de aplicação',old.application_geometry_source,f'h_{i}_geometry')
            dynamic = flag('As forças fornecidas já são características, com dinâmica qualificada',old.characteristic_dynamic_included,f'h_{i}_dynamic',
                help='Força motriz estática não é automaticamente ação característica; o app não inventa φ5.')
            data = [asdict(x) for x in old.wheel_forces]
            if not data: data = [dict(wheel_id=w.wheel_id,offset_m=w.offset_m,y_m=w.y_m,z_m=w.z_m,fs_kn=None,fy_kn=None) for w in a.wheels]
            frame = table(data,f'h_{i}_forces',{'wheel_id':'Roda','offset_m':'Offset s (m)','y_m':'y real (m)','z_m':'z real (m)','fs_kn':'Hs em +s (kN)','fy_kn':'Hy em +y (kN)'})
            try:
                forces = tuple(ENManufacturerWheelForce(**floats(row,('offset_m','y_m','z_m','fs_kn','fy_kn'))) for row in rows(frame))
                suppliers.append(ENManufacturerHorizontalSet(sid,'G6',source,simultaneous,direction,location,dynamic,forces))
            except (ValueError,TypeError,KeyError) as exc: errors.append(f'Conjunto horizontal {i+1}: '+human(exc))
    if len(suppliers)==count: a = replace(a,manufacturer_horizontal_sets=tuple(suppliers))
    with st.expander('Ensaios e ausência física da talha'):
        st.caption('QT é a carga içada completa de ensaio: substitui Qh, sem duplicar acessórios ou cabos. Plano, posições e ações horizontais do ensaio precisam de comprovação própria.')
        test_count = n('Número de ensaios declarados',len(a.tests),'test_count',minimum=0,maximum=8,step=1)
        tests = []
        for i in range(test_count):
            old = a.tests[i] if i<len(a.tests) else ENTestRequest(f'T{i+1}','dynamic',0.,(), '')
            st.markdown(f'**Ensaio {i+1}**')
            tid = t('Identificação do ensaio',old.test_id,f'test_{i}_id')
            kind = select('Tipo de ensaio',('dynamic','static'),old.kind,f'test_{i}_kind',labels={'dynamic':'Dinâmico','static':'Estático'})
            qt = n('QT completo (kN)',old.total_hoist_test_kn,f'test_{i}_qt',minimum=0.,step=.1)
            fractions = t('Frações de QT na ordem das rodas (separadas por ;)', '; '.join(f'{x:g}' for x in old.wheel_fractions), f'test_{i}_fractions')
            source = t('Fonte do plano de ensaio',old.source,f'test_{i}_source')
            try: tests.append(ENTestRequest(tid,kind,qt,tuple(float(x.strip()) for x in fractions.split(';')),source))
            except ValueError: errors.append(f'Ensaio {i+1}: informe frações numéricas explícitas separadas por ponto e vírgula.')
        if len(tests)==test_count: a = replace(a,tests=tuple(tests))
        absence = flag('Ausência física da talha admissível e documentada',a.crane_absence_admissible,'absence')
        absence_source = t('Fonte da ausência física',a.crane_absence_source,'absence_source')
        a = replace(a,crane_absence_admissible=absence,crane_absence_source=absence_source)

with material_tab:
    st.subheader('Material EN explícito, sem conversão de aço ou fatores')
    st.caption('Aço estrutural em temperatura ambiente. Rota inicial pela norma de produto declarada, não por tabela simplificada ou catálogo inventado. A resistência não usa γa1 da rota NBR.')
    values = {}
    c1,c2 = st.columns(2)
    with c1:
        values['product_standard'] = t('Norma de produto EN adotada',basis.product_standard,'product_standard')
        values['material_grade'] = t('Designação do aço documentado',basis.material_grade,'material_grade')
    with c2:
        values['fy_mpa'] = n('fy para espessura adotada (MPa)',basis.fy_mpa,'fy',minimum=200.,maximum=700.,step=5.)
        values['fu_mpa'] = n('fu para espessura adotada (MPa)',basis.fu_mpa,'fu',minimum=200.,step=5.)
    values['strength_thickness_source'] = t('Fonte de fy/fu, produto e faixa de espessura',basis.strength_thickness_source,'strength_source',area=True)
    c1,c2 = st.columns(2)
    with c1: n('E EN prescrito (MPa)',basis.E_mpa,'E',disabled=True)
    with c2: n('G EN prescrito (MPa)',basis.G_mpa,'G',disabled=True)
    st.caption('Elasticidade desta rota: E = 210 000 MPa, ν = 0,30 e G = E / 2,6. Não é reaproveitada a rigidez NBR por renomeação.')
    values['elasticity_source'] = t('Fonte da elasticidade EN',basis.elasticity_source,'elasticity_source')
    values['ductility_basis'] = select('Base de ductilidade elástica',('listed_product_presumption_5_2_2_2','documented_elastic_elongation'),basis.ductility_basis,'ductility_basis',
        labels={'listed_product_presumption_5_2_2_2':'Presunção por produto listado, com fonte','documented_elastic_elongation':'Alongamento documentado ≥ 12%'})
    if values['ductility_basis']=='documented_elastic_elongation' or basis.elongation_percent is not None:
        values['elongation_percent'] = n('Alongamento documentado (%)',float(basis.elongation_percent or 12.),'elongation',minimum=0.,step=.1,
            help='Base de medida 5,65 √A0. A condição elástica e a relação fu/fy são validadas separadamente.')
    values['ductility_source'] = t('Fonte da ductilidade',basis.ductility_source,'ductility_source')
    values['toughness_source'] = t('Fonte / adoção da tenacidade',basis.toughness_source,'toughness_source')
    c1,c2 = st.columns(2)
    with c1: values['gamma_M0'] = n('γM0 · resistência da seção',basis.gamma_M0,'gamma_M0',minimum=1.,step=.05)
    with c2: values['gamma_M1'] = n('γM1 · estabilidade da barra',basis.gamma_M1,'gamma_M1',minimum=1.,step=.05)
    values['partial_factor_source'] = t('Fonte dos coeficientes resistentes',basis.partial_factor_source,'resistance_factors_source',area=True)
    values['method_adoption_source'] = t('Adoção explícita do método e edições resistentes',basis.method_adoption_source,'method_source',area=True)
    st.caption(f'Edição resistente: {basis.resistance_edition}. Estrutura de suporte: {basis.supporting_structure_edition}. Perfil: {basis.national_profile}.')
    st.subheader('Garfos extremos e transferência axial são premissas diferentes')
    p.end_forks_confirmed = flag('Garfos efetivos nas duas extremidades explicitamente adotados',p.end_forks_confirmed,'end_forks',
        help='Contenção lateral e torsional de garfo, com empenamento livre. As ligações e sua rigidez não são dimensionadas automaticamente.')
    p.restraint_source = t('Fonte do modelo de garfos e apoios',p.restraint_source,'restraint_source',area=True)
    values['physical_model_source'] = t('Fonte / adoção do modelo físico resistente',basis.physical_model_source,'physical_model_source',area=True)
    st.info('Esta rota EN usa o vão L integral e empenamento livre nas extremidades. Não credita travamentos intermediários nem estabilização pela mesa inferior. O vínculo axial abaixo não substitui um garfo e não cria apoio vertical adicional.')
    # The independent EN solver does not consume the NBR brace-length mode.
    axial_enabled = flag('Adotar transferência longitudinal Hs com vínculo axial explícito',b.axial_transfer is not None,'axial_enabled',
        help='Sem esta adoção, casos Hs permanecem pendentes; os demais casos podem ser calculados e exportados.')
    if axial_enabled:
        old = b.axial_transfer or AxialTransfer(False,False,False,'')
        equal = flag('Hs iguais nos dois contatos opostos de cada eixo',old.equal_opposed_contacts_confirmed,'axial_equal')
        left = flag('Restrição axial à esquerda aplicada no centro de cisalhamento',old.left_axial_restraint_at_shear_center_confirmed,'axial_left')
        right = flag('Extremidade direita livre axialmente',old.right_axial_free_confirmed,'axial_right')
        source = t('Fonte do vínculo axial e da distribuição Hs',old.source,'axial_source',area=True)
        b.axial_transfer = AxialTransfer(equal,left,right,source) if equal and left and right else None
        if not all((equal,left,right)):
            st.caption('Adoção axial incompleta: Hs será mantido como pendência, não apagado das ações.')
    else:
        b.axial_transfer = None
    with st.expander('Aceitação numérica e declarações de domínio'):
        values['maximum_accepted_numerical_relative_tolerance'] = n('Tolerância relativa máxima aceita',basis.maximum_accepted_numerical_relative_tolerance,'tolerance',minimum=.0001,maximum=.02,step=.0005,format='%.4f')
        values['numerical_acceptance_source'] = t('Fonte da aceitação numérica',basis.numerical_acceptance_source,'numerical_source',area=True)
        values['structural_steel_ambient'] = flag('Aço estrutural em temperatura ambiente',basis.structural_steel_ambient,'ambient')
        st.caption('Refinamento convergido numericamente não é majorante certificado de todo o contínuo. A condição de aprovação global permanece falsa.')
    basis = replace(basis,**values)
    for name in ('fy_mpa','fu_mpa','E_mpa','G_mpa'):
        setattr(p.material,name,getattr(basis,name))

# Only geometry and EN declarations are bound here. NBR classes/factors retained
# in the geometry carrier are never read to build an EN action or resistance.
a = replace(a,project_name=p.project_name,span_m=p.span_m,travel_min_m=p.travel_min_m,travel_max_m=p.travel_max_m)
b.project, b.actions, b.resistance = p, a, basis
st.session_state.en_bundle = b
try:
    b.validate()
except (ValueError,TypeError,OverflowError,KeyError,AttributeError) as exc:
    errors.append(human(exc))
if errors:
    invalidate()
    st.error('Revise as entradas antes de calcular:\n\n' + '\n\n'.join(dict.fromkeys(errors)))
else:
    current = st.session_state.get('en_result')
    if current is not None:
        try:
            from en_analysis import assert_current_en_result
            assert_current_en_result(b,current)
        except (ValueError,TypeError,ImportError,KeyError,AttributeError):
            invalidate()

with results_tab:
    st.subheader('Calcular os casos EN das entradas atuais')
    st.caption('Os casos são gerados por origem e grupo correlacionado. Cálculos incompletos, falhas e pendências continuam visíveis; não impedem exportar um recibo atual. Qualquer edição exige recalcular.')
    if st.button('Calcular complemento EN',type='primary',disabled=bool(errors),width='stretch',key='en_calculate'):
        invalidate()
        progress = st.progress(0.,text='Preparando grupos e casos EN…')
        def report(fraction,title):
            progress.progress(max(0.,min(1.,float(fraction))),text=str(title))
        try:
            from en_analysis import analyze_en, assert_current_en_result
            with st.spinner('Calculando ações e verificações EN…'):
                result = analyze_en(b,progress=report)
                assert_current_en_result(b,result)
            st.session_state.en_result = result
            progress.progress(1.,text='Cálculo concluído. Consulte cada mecanismo e suas pendências.')
        except (ValueError,TypeError,ImportError,KeyError,RuntimeError,OverflowError) as exc:
            invalidate()
            progress.empty()
            st.error('Não foi possível concluir: '+human(exc))
    if not errors:
        st.download_button('Baixar entrada JSON EN',b.to_json(),file_name='monovia_entrada_EN.json',mime='application/json',key='en_download_input')
    with st.expander('Prévia das ações e obrigações, sem cálculo resistente'):
        if not errors:
            try:
                receipt = generate_actions(a)
                st.dataframe(pd.DataFrame([{'Grupo':g.id,'Descrição':g.title,'Ações':g.generation_status,
                    'Horizontal':g.horizontal_status,'Pendências':'; '.join(x.code for x in g.requirements)} for g in receipt.groups]),hide_index=True,width='stretch')
                st.caption(f'{len(receipt.groups)} grupos e {len(receipt.cases)} casos. A prévia não é resultado resistente nem aprovação.')
                st.json(receipt.editions,expanded=False)
            except (ValueError,TypeError) as exc: st.error(human(exc))
    result = st.session_state.get('en_result')
    if result is None:
        st.info('Nenhum resultado atual. Calcule após conferir as entradas. Arquivos de resultado e Word só aparecem para um recibo local válido.')
    else:
        summary = result.get('summary',{})
        st.subheader('Resumo por mecanismo · variantes com ações completas')
        st.caption('Atendimento é condicional ao domínio e às premissas registradas. Um majorante excedido não prova uma falha testemunhada. Nenhum resultado desta página declara aprovação integral do equipamento.')
        counts = summary.get('counts',result.get('counts',{}))
        if isinstance(counts,dict) and counts:
            visible = [(status,count) for status,count in counts.items() if count]
            for start in range(0,len(visible),4):
                items = visible[start:start+4]
                for col,(status,count) in zip(st.columns(len(items)),items):
                    col.metric(STATUS.get(status,status),str(count))
        if summary.get('mechanisms'):
            mechanism_rows = [{'Mecanismo':m.get('title',m.get('id','')),
                'Situação':STATUS.get(m.get('status'),m.get('status','')),
                'Verificações':m.get('checks'), 'Utilização governante':m.get('governing_utilization'),
                'Caso governante':m.get('governing_case_id')} for m in summary['mechanisms']]
            st.dataframe(pd.DataFrame(mechanism_rows),hide_index=True,width='stretch')
        groups = result.get('action_receipt',{}).get('groups',[])
        if groups:
            st.subheader('Cobertura dos grupos de ações')
            st.caption('Grupos PENDING_INPUT não geram casos numéricos. Calcular todos os casos gerados não fecha grupos sem dados, outros eventos ou todas as direções do equipamento.')
            st.dataframe(pd.DataFrame([{'Grupo':g['id'],'Descrição':g.get('title',''),
                'Geração':{'ACTIONS_GENERATED':'Ações geradas','PENDING_INPUT':'Entrada pendente'}.get(g.get('generation_status'),g.get('generation_status','')),
                'Pendências / cobertura':'; '.join(g.get('pending',[]))} for g in groups]),hide_index=True,width='stretch')
        partial_ids = summary.get('diagnostic_partial_cases',[])
        if partial_ids:
            st.subheader('Diagnósticos de ações parciais, separados do resumo')
            st.caption('Estes subconjuntos não possuem todos os componentes do grupo e não são convertidos em atendimento. São conservados no recibo, nas contagens totais, na seleção de casos e nos arquivos.')
            partial_counts = summary.get('diagnostic_partial_counts',{})
            st.dataframe(pd.DataFrame([{'Situação':STATUS.get(k,k),'Verificações diagnósticas':v,
                'Total em todos os casos':summary.get('all_case_counts',{}).get(k,0)} for k,v in partial_counts.items() if v or summary.get('all_case_counts',{}).get(k,0)]),hide_index=True,width='stretch')
            st.dataframe(pd.DataFrame({'Caso diagnóstico parcial':partial_ids}),hide_index=True,width='stretch')
        all_checks = result.get('checks',[])
        if not all_checks:
            all_checks = [check for case in result.get('cases',[]) for check in case.get('checks',[])]
        if all_checks:
            with st.expander('Todas as verificações, inclusive diagnósticos parciais'):
                st.dataframe(check_table(all_checks),hide_index=True,width='stretch')
        cases = result.get('cases',[])
        if cases:
            selected = st.selectbox('Caso para inspeção',range(len(cases)),
                format_func=lambda i:FAMILIES.get(cases[i].get('family'),cases[i].get('family',''))+' · '+cases[i].get('title',cases[i].get('id',''))+' · '+cases[i].get('id',''),key='en_result_case')
            case = cases[selected]
            if case.get('error'): st.warning('Caso não calculado ou parcialmente calculado: '+human(case['error']))
            if case.get('checks'): st.dataframe(check_table(case['checks']),hide_index=True,width='stretch')
            action = case.get('action_case',{})
            if hasattr(action,'to_dict'): action = action.to_dict()
            with st.expander('Forças finais EN por roda e origem'):
                if action.get('wheel_loads'):
                    st.dataframe(pd.DataFrame(action['wheel_loads']).rename(columns={'wheel_id':'Roda','offset_m':'Offset s (m)','y_m':'y (m)','z_m':'z (m)','fs_kn':'Hs em +s (kN)','fy_kn':'Hy em +y (kN)','fz_kn':'Fz em +z (kN)'}),hide_index=True,width='stretch')
                st.caption('Forças finais já incluem todos os fatores deste caso. Gravidade é Fz negativa; não dividir por dois nem reaplicar dinâmica ou coeficientes.')
                if action.get('ledger'): st.dataframe(pd.DataFrame(action['ledger']),hide_index=True,width='stretch')
                if action.get('requirements'): st.json(action['requirements'],expanded=False)
            if case.get('calculated'):
                st.subheader('Diagramas de um estado concomitante')
                st.caption('Um estado de translação, não uma envoltória. Eixos físicos de mão direita: s longitudinal, y transversal, z vertical para cima. My é momento forte em torno de y; Mz é momento fraco em torno de z. As reações abaixo são do apoio SOBRE a viga; a viga aplica o vetor oposto no apoio.')
                default_translation = (p.travel_min_m+p.travel_max_m)/2
                translation = st.number_input('Translação do eixo de referência para os diagramas (m)',
                    min_value=float(p.travel_min_m),max_value=float(p.travel_max_m),value=float(default_translation),step=.05,key='en_diagram_translation')
                if st.button('Gerar diagramas deste estado',key='en_generate_diagram'):
                    try:
                        from en_analysis import diagram_en
                        data = diagram_en(b,result,case['id'],translation_m=translation)
                        st.session_state.en_diagram = dict(signature=b.signature(),case_id=case['id'],translation=translation,data=data)
                    except (ImportError,ValueError,TypeError,KeyError) as exc:
                        st.error('Diagramas: '+human(exc))
                cached = st.session_state.get('en_diagram')
                if cached and cached['signature']==b.signature() and cached['case_id']==case['id'] and cached['translation']==translation:
                    try:
                        from en_report import diagram_figure, displacement_figure
                        data = cached['data']
                        st.image(diagram_figure(data),width='stretch')
                        st.image(displacement_figure(data),width='stretch')
                        reactions = data.get('support_on_beam',{})
                        if reactions:
                            reaction_rows = []
                            for key,value in reactions.items():
                                parts = key.split('_')
                                side = 'Esquerdo' if 'left' in parts else 'Direito' if 'right' in parts else ''
                                unit = 'N·mm' if key.endswith('_Nmm') else 'N' if key.endswith('_N') else 'conforme chave técnica'
                                reaction_rows.append({'Apoio':side,'Componente física':parts[0],
                                    'Apoio sobre viga':value,'Viga sobre apoio':data.get('beam_on_support',{}).get(key),'Unidade':unit})
                            st.dataframe(pd.DataFrame(reaction_rows),hide_index=True,width='stretch')
                    except (ImportError,ValueError,TypeError,KeyError) as exc:
                        st.error('Figuras: '+human(exc))
            with st.expander('Evidência técnica do caso, convergência e convenções'):
                st.json(case,expanded=False)
        with st.expander('Resumo e rastreabilidade técnica'):
            st.json(summary,expanded=False)
        st.subheader('Arquivos do cálculo atual')
        st.caption('Pendências e verificações desfavoráveis são preservadas nos arquivos. Exportar não significa aprovar.')
        try:
            from en_analysis import assert_current_en_result
            from en_report import export_en_json, export_en_word
            assert_current_en_result(b,result)
            st.download_button('Baixar resultado JSON EN',export_en_json(b,result),file_name='monovia_resultado_EN.json',mime='application/json',key='en_download_result')
            if st.button('Preparar relatório Word EN',key='en_prepare_word'):
                with st.spinner('Preparando relatório EN…'):
                    st.session_state.en_word = export_en_word(b,result)
                    st.session_state.en_word_signature = b.signature()
            if st.session_state.get('en_word') and st.session_state.get('en_word_signature')==b.signature():
                assert_current_en_result(b,result)
                st.download_button('Baixar Word EN',st.session_state.en_word,file_name='monovia_relatorio_EN.docx',
                    mime='application/vnd.openxmlformats-officedocument.wordprocessingml.document',key='en_download_word')
        except ImportError:
            st.caption('Exportador EN ainda não está disponível nesta montagem de desenvolvimento.')
        except (ValueError,TypeError,KeyError) as exc:
            st.error('Exportação recusada: '+human(exc))
