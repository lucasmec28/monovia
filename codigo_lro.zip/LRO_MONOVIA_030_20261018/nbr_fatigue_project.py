"""Independent NBR nominal-fatigue inputs; never imports a prior approval."""
from __future__ import annotations
from copy import deepcopy
from dataclasses import asdict,dataclass,fields
import json,math,sys
from monorail.model import MonorailProject,demo_project,_typed
from monorail.analysis import digest
from lro_beams.stress_8400 import LOW_GRADES,HIGH_GRADES
from analytical_scan import AxialTransfer

FORMAT='LRO_MONORAIL_NBR_NOMINAL_FATIGUE_INPUT'
GRADES=('não informado',)+LOW_GRADES+HIGH_GRADES
GROUPS=('não informado',)+tuple('E'+str(i) for i in range(1,9))
CLASSIFICATIONS=('manual_code_selection','documented_component_classification','adopted_conservative_E8')
DETAILS=('não selecionado','W0_plain_rolled_unnotched')
FABRICATIONS=('não informado','specified_h6','specified_h6_qc')


def _domain(value,label='bundle'):
    if value is None or type(value) is bool:return
    if type(value) in (int,float):
        try:valid=math.isfinite(value) and abs(value)<=1e12 and (value==0 or abs(value)>=sys.float_info.min)
        except (ValueError,OverflowError,TypeError):valid=False
        if not valid:raise ValueError(label+': número fora do domínio finito/normal suportado')
        return
    if type(value) is str:_typed(value,str,label);return
    if type(value) in (list,tuple):
        for index,item in enumerate(value):_domain(item,f'{label}[{index}]')
        return
    if type(value) is dict:
        for key,item in value.items():_typed(key,str,label+' chave');_domain(item,label+'.'+key)
        return
    raise ValueError(label+': tipo de entrada não suportado')


def _parse(payload):
    if isinstance(payload,bytes):
        try:payload=payload.decode('utf-8-sig')
        except UnicodeError as exc:raise ValueError('JSON deve ser UTF-8 válido') from exc
    if type(payload) is not str:raise ValueError('Texto JSON ou bytes UTF-8 obrigatórios')
    def unique(pairs):
        result={}
        for key,value in pairs:
            if key in result:raise ValueError('Campo JSON duplicado: '+key)
            result[key]=value
        return result
    def floating(token):
        value=float(token)
        if value==0 and any(c in '123456789' for c in token.lower().split('e')[0]):raise ValueError('Decimal JSON não nulo convertido em zero')
        _domain(value,'decimal JSON');return value
    def constant(token):raise ValueError('Número JSON não finito: '+token)
    try:return json.loads(payload,object_pairs_hook=unique,parse_float=floating,parse_constant=constant)
    except (TypeError,UnicodeError,OverflowError,RecursionError,json.JSONDecodeError) as exc:raise ValueError('JSON de fadiga NBR inválido') from exc


@dataclass
class NBRFatigueProject:
    project: MonorailProject
    axial_transfer: AxialTransfer|None = None
    material_grade: str = 'não informado'
    material_source: str = ''
    component_group: str = 'não informado'
    classification_kind: str = 'manual_code_selection'
    classification_source: str = ''
    construction_detail: str = 'não selecionado'
    detail_source: str = ''
    fabrication_requirement: str = 'não informado'
    fabrication_source: str = ''
    kappa_minus_one_adopted: bool = False
    kappa_source: str = ''
    numerical_tolerance: float = .005
    numerical_source: str = ''
    high_ratio_material_source: str = ''
    demonstration: bool = True
    notes: str = ''
    format: str = FORMAT
    schema_version: int = 1

    def validate(self):
        try:
            _typed(self,type(self),'fadiga NBR');_domain(self.to_dict())
            if type(self.project) is not MonorailProject:raise ValueError('Projeto NBR físico tipado obrigatório')
            if self.format!=FORMAT or type(self.schema_version) is not int or self.schema_version!=1:raise ValueError('Formato/versão de fadiga NBR não suportado; não importar resultados ou dados EN')
            self.project.validate()
            for name,choices in [('material_grade',GRADES),('component_group',GROUPS),('classification_kind',CLASSIFICATIONS),('construction_detail',DETAILS),('fabrication_requirement',FABRICATIONS)]:
                if getattr(self,name) not in choices:raise ValueError(name+': opção fora do domínio de entrada')
            if not .0001<=self.numerical_tolerance<=.02:raise ValueError('Tolerância numérica deve ser de 0,0001 a 0,02')
            if self.classification_kind=='adopted_conservative_E8' and self.component_group not in ('não informado','E8'):
                raise ValueError('Adoção conservadora E8 não classifica outro grupo')
            if self.axial_transfer is not None:
                if type(self.axial_transfer) is not AxialTransfer:raise ValueError('Premissas axiais tipadas ou nulas obrigatórias')
                self.axial_transfer.validate()
            return self
        except (OverflowError,TypeError,AttributeError,RecursionError,ZeroDivisionError) as exc:
            raise ValueError('Entradas de fadiga NBR excedem o domínio tipado ou numérico') from exc

    def to_dict(self):return asdict(self)
    def signature(self):return digest(self.to_dict())
    def to_json(self):
        self.validate();return json.dumps(self.to_dict(),ensure_ascii=False,indent=2,allow_nan=False)

    @classmethod
    def from_json(cls,payload):
        data=_parse(payload)
        if type(data) is not dict or set(data)!={f.name for f in fields(cls)}:raise ValueError('Campos ausentes/desconhecidos; somente entradas de fadiga NBR são aceitas')
        try:
            data=dict(data);data['project']=MonorailProject.from_json(json.dumps(data['project'],allow_nan=False))
            raw=data['axial_transfer']
            if raw is not None:
                if type(raw) is not dict or set(raw)!={f.name for f in fields(AxialTransfer)}:raise ValueError('Premissas axiais com campos inválidos')
                data['axial_transfer']=AxialTransfer(**raw)
            return cls(**data).validate()
        except (TypeError,KeyError,OverflowError,AttributeError,RecursionError) as exc:raise ValueError('Entrada tipada de fadiga NBR inválida') from exc


def from_nbr_project(project):
    if type(project) is not MonorailProject:raise ValueError('Somente um projeto NBR de entrada, não resultados/EN')
    project.validate()
    return NBRFatigueProject(deepcopy(project),demonstration=project.demonstration,
        notes='Entradas físicas e ações NBR importadas explicitamente. Novas fontes de material, grupo, detalhe, fabricação, método e vínculo axial não foram presumidas.').validate()


def from_nbr_json(payload):
    """Strict lexical preflight for explicit 0.1 physical-input import.

    The preserved parser is not asked to round a nonzero JSON token to zero.
    This imports inputs only; it does not infer any new fatigue qualification.
    """
    try:
        data=_parse(payload)
        if type(data) is not dict:raise ValueError('A entrada física NBR deve ser um objeto JSON')
        _domain(data,'entrada física NBR')
        project=MonorailProject.from_json(json.dumps(data,ensure_ascii=False,allow_nan=False))
        return from_nbr_project(project)
    except RecursionError as exc:
        raise ValueError('Entrada física NBR excede a profundidade de dados suportada') from exc


def demo_nbr_fatigue_project(mode='vertical'):
    if mode not in ('vertical','horizontal','combined','bound_exceeded','missing_axial','missing_data'):raise ValueError('Exemplo NBR de fadiga desconhecido')
    source='EXEMPLO SINTÉTICO, sem fabricante, certificado ou inspeção real. Adoção ilustrativa para testar o aplicativo.'
    p=demo_project();p.project_name='Exemplo sintético de fadiga nominal NBR · '+mode
    p.horizontal_action_source=source+' Forças características nos pares, simultâneas por hipótese deste exemplo; ambos os sentidos são gerados.'
    if mode in ('horizontal','combined','missing_axial'):p.stations[0].transverse_kn=.25;p.stations[1].transverse_kn=-.08
    if mode in ('combined','missing_axial'):p.stations[0].longitudinal_kn=.12;p.stations[1].longitudinal_kn=.06
    if mode=='bound_exceeded':p.capacity_t=p.operating_payload_t=50.
    axial=AxialTransfer(True,True,True,source+' Hs iguais no par, vínculo axial esquerdo no centro de cisalhamento, direita livre.') if mode=='combined' else None
    if mode=='missing_data':return NBRFatigueProject(p,notes=source).validate()
    return NBRFatigueProject(p,axial,'ASTM A36',source,'E5','manual_code_selection',source,
        'W0_plain_rolled_unnotched',source,'specified_h6',source,True,source,.005,source,'',True,
        source+' Não é recomendação de talha ou perfil; não fecha contato, raízes reais, ligação, estabilidade ou vida ilimitada.').validate()
