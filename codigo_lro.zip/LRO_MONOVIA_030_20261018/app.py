"""Interface local de monovia. Nenhum resultado externo é aceito como cálculo.

Run: python -m streamlit run app.py
The mutable editor is kept separate from the signed, calculated receipt. A failed
criterion is exportable; a missing, stale or tampered receipt is not.
"""
from __future__ import annotations

from copy import deepcopy
import json
import math
import re

import pandas as pd
import streamlit as st

from lro_beams.catalog import list_profiles, section_from_profile
from lro_beams.stress_8400 import LOW_GRADES, HIGH_GRADES
from monorail.model import MonorailProject, Station, demo_project
from monorail.analysis import analyze, assert_current_result
from monorail.figures import schematic, diagram_figure, deflection_figure, envelope_figure, torsion_figure
from monorail.export import export_docx, export_json, LABELS


st.set_page_config(page_title="Monovia · LRO", page_icon="🏗️", layout="wide")

STATUS_ICONS = {"PASS": "✓", "FAIL": "×", "BOUND_EXCEEDED": "△", "PENDING": "○", "OUT_OF_SCOPE": "−"}
FAMILIES = {"nominal_deflection": "Flecha nominal · L/500", "NBR_I": "Operação normal · NBR 10084/8400", "FAT8400": "Ações de fadiga · NBR 8400", "ULS8800": "ELU complementar · NBR 8800", "operating_service": "Operação sem impacto · referência"}
METRIC_LABELS = {
    "Mx_knm": "Momento forte · alias Mx (kN·m)", "My_knm": "Momento fraco · alias My (kN·m)",
    "Vy_kn": "Cortante vertical · alias Vy (kN)", "Vx_kn": "Cortante horizontal · alias Vx (kN)",
    "N_kn": "Força normal · N (kN)", "vertical_mm": "Flecha vertical (mm)",
    "horizontal_mm": "Deslocamento lateral (mm)",
}
AXIS_HELP = ("Eixos físicos: s longitudinal, y horizontal transversal e z vertical. "
             "Aliases do núcleo: Mx = momento forte em torno de y; My = momento fraco em torno de z; "
             "Vy = cortante vertical na direção z; Vx = cortante horizontal na direção y; N = normal na direção s. "
             "Os nomes legados não são rótulos de eixos cartesianos físicos. Hx de entrada atua em s e Hy em y.")

FIELD_NAMES = {
    "operating_payload_t": "carga operacional (t)", "trolley_hoist_mass_kg": "massa da talha e do trole (kg)",
    "retained_suspended_mass_kg": "massa suspensa retida (kg)", "equipment_share": "frações do peso da talha/trole",
    "suspended_share": "frações da carga útil e da massa retida", "upper_braces_m": "posições da mesa superior",
    "lower_braces_m": "posições da mesa inferior", "lateral_axis_braces_m": "posições do centro de cisalhamento",
    "wheel_distribution_source": "fonte da distribuição entre rodas", "classification_source": "fonte das classes e dos grupos",
    "horizontal_action_source": "fonte das ações horizontais", "extra_dead_source": "fonte da ação permanente adicional",
    "equipment_source": "fonte dos dados da talha/trole", "travel_source": "fonte dos limites de viagem",
    "restraint_source": "fonte dos vínculos", "fatigue_source": "fonte da fadiga", "span_m": "vão (m)",
}


def human_error(exc):
    text = str(exc)
    for raw, label in FIELD_NAMES.items():
        text = text.replace(raw, label)
    return text


def ui_key(field):
    return "ui_" + field


def reset_editor(prefixes=("ui_",)):
    """Only explicit import/demo/catalog actions replace widget state."""
    for key in list(st.session_state):
        if any(str(key).startswith(prefix) for prefix in prefixes):
            del st.session_state[key]


def replace_project(project, message):
    st.session_state.project = project
    st.session_state.result = None
    st.session_state.word_bytes = None
    st.session_state.word_signature = None
    st.session_state.notice = ("success", message)
    reset_editor()


def restore_demo():
    replace_project(demo_project(), "Exemplo ilustrativo carregado. Nenhum dado é de uma talha real e nenhum resultado anterior foi mantido.")


def import_project():
    file = st.session_state.get("import_upload")
    pasted = st.session_state.get("import_text", "").strip()
    if file is not None and pasted:
        st.session_state.notice = ("error", "Escolha uma única origem: arquivo ou texto JSON. O projeto atual foi preservado.")
        return
    payload = file.getvalue() if file is not None else pasted
    if not payload:
        st.session_state.notice = ("error", "Selecione um arquivo de entrada ou cole seu JSON antes de importar.")
        return
    try:
        from nbr_fatigue_project import from_nbr_json
        project = from_nbr_json(payload).project
    except (ValueError, TypeError, UnicodeError, OverflowError) as exc:
        st.session_state.notice = ("error", "Importação recusada. " + human_error(exc) + " O projeto atual foi preservado.")
        return
    replace_project(project, "Entradas da monovia importadas. Calcule para gerar um novo resultado local.")


def apply_catalog():
    identifier = st.session_state.get("catalog_profile")
    try:
        row = next(row for row in list_profiles("W") if row["id"] == identifier)
        section = section_from_profile(row)
        # Preserve the record identity, original source and metadata, never mixed
        # catalogue stiffness/resistance properties in this adapter.
        section.property_basis = "rectangles"
        section.catalog = {}
        section.property_source = (
            row["source"] + " | Importadas somente dimensões; propriedades resistentes e rigidez por três retângulos. "
            + "Metadados do registro histórico: " + json.dumps(row.get("metadata", {}), ensure_ascii=False, sort_keys=True)
        )
        p = deepcopy(st.session_state.project)
        p.section = section
        p.weld_throat_mm = 0.0
        p.section_mass_kg_per_m = float(row["mass_kg_m"])
        p.section_mass_source = row["source"] + " | Massa linear nominal do registro " + row["id"] + "."
        st.session_state.project = p
        st.session_state.word_bytes = None
        reset_editor(("ui_section_", "ui_weld_throat_mm", "ui_use_mass", "ui_section_mass_"))
        st.session_state.notice = ("success", "Dimensões e massa do perfil histórico aplicadas. Confira material, posição de contato e resultados; a seleção não aprova o perfil.")
    except (ValueError, KeyError, StopIteration) as exc:
        st.session_state.notice = ("error", "Não foi possível aplicar o catálogo: " + human_error(exc))


def n(label, current, field, *, minimum=None, step=None, disabled=False, help=None, format=None):
    kwargs = dict(value=current, key=ui_key(field), disabled=disabled, help=help)
    if minimum is not None:
        kwargs["min_value"] = minimum
    if step is not None:
        kwargs["step"] = step
    if format is not None:
        kwargs["format"] = format
    return st.number_input(label, **kwargs)


def text(label, current, field, *, help=None, multiline=False, disabled=False):
    fn = st.text_area if multiline else st.text_input
    return fn(label, value=current, key=ui_key(field), help=help, disabled=disabled)


def choice(label, values, current, field, *, format_func=str, help=None, disabled=False):
    options = list(values)
    if current not in options:
        options.append(current)
    return st.selectbox(label, options, index=options.index(current), key=ui_key(field), format_func=format_func, help=help, disabled=disabled)


def flag(label, current, field, *, help=None, disabled=False):
    return st.checkbox(label, value=current, key=ui_key(field), help=help, disabled=disabled)


def positions(label, current, field, errors, *, disabled=False):
    value = text(label, "; ".join(f"{x:g}" for x in current), field, disabled=disabled,
                 help="Metros desde o apoio esquerdo. Use ponto decimal e ponto e vírgula: 1.5; 3; 4.5. Sem normalização ou arredondamento de posições.")
    if disabled:
        return current
    try:
        values = [] if not value.strip() else [float(v.strip()) for v in value.split(";")]
        if any(not math.isfinite(v) for v in values):
            raise ValueError
        return values
    except ValueError:
        errors.append(label + ": use números finitos separados por ponto e vírgula (ex.: 1.5; 3).")
        return current


@st.cache_data(show_spinner=False, max_entries=8)
def cached_schematic(payload):
    return schematic(MonorailProject.from_json(payload))


@st.cache_data(show_spinner=False, max_entries=12)
def cached_diagrams(case):
    return diagram_figure(case), deflection_figure(case), envelope_figure(case)


@st.cache_data(show_spinner=False, max_entries=8)
def cached_torsion(case):
    return torsion_figure(case)


def filename(p, suffix):
    member = re.sub(r"[^A-Za-z0-9_-]+", "_", p.member_name).strip("_") or "monovia"
    return member + suffix


def check_table(checks):
    return pd.DataFrame([{
        "Situação": STATUS_ICONS.get(row["status"], "") + " " + LABELS.get(row["status"], row["status"]),
        "Verificação": row["title"], "Solicitação / majorante": row.get("demand"), "Resistência / limite": row.get("capacity"),
        "Utilização": row.get("utilization"), "Unidade": row.get("unit", ""),
    } for row in checks])


def show_plan(p):
    if p.restraint_mode == "full_span":
        st.caption("Comprimentos resistentes integrais. Posições eventualmente registradas não são aplicadas ao cálculo.")
        st.dataframe(pd.DataFrame([
            {"Comprimento": "Flexão forte", "Valor (m)": p.span_m},
            {"Comprimento": "Flexão fraca", "Valor (m)": p.span_m},
            {"Comprimento": "Torção", "Valor (m)": p.span_m},
            {"Comprimento": "FLT", "Valor (m)": p.span_m},
        ]), hide_index=True, width="stretch")
        return
    try:
        plan = p.resistance_plan()
    except ValueError as exc:
        st.error("Plano resistente: " + human_error(exc))
        return
    st.caption("Prévia do plano nominal. Não cria apoios intermediários, reações de travamento ou redistribuição de esforços.")
    st.dataframe(pd.DataFrame([
        {"Comprimento": "Flexão forte", "Valor (m)": plan.major_flexural_mm / 1000},
        {"Comprimento": "Flexão fraca", "Valor (m)": plan.minor_flexural_mm / 1000},
        {"Comprimento": "Torção", "Valor (m)": plan.torsional_mm / 1000},
        {"Comprimento": "Maior intervalo de FLT", "Valor (m)": max(b-a for a,b in plan.ltb_intervals_mm) / 1000},
    ]), hide_index=True, width="stretch")
    st.dataframe(pd.DataFrame([
        {"Trecho FLT": i+1, "Início (m)": a/1000, "Fim (m)": b/1000, "Comprimento (m)": (b-a)/1000}
        for i,(a,b) in enumerate(plan.ltb_intervals_mm)
    ]), hide_index=True, width="stretch")
    if plan.uncredited_upper_positions_mm or plan.uncredited_lower_positions_mm:
        st.caption("Sem crédito FLT: mesa superior isolada " + str([x/1000 for x in plan.uncredited_upper_positions_mm])
                   + " m; mesa inferior " + str([x/1000 for x in plan.uncredited_lower_positions_mm]) + " m.")


def main():
    if "project" not in st.session_state:
        st.session_state.project = demo_project()
        st.session_state.result = None
        st.session_state.word_bytes = None
        st.session_state.word_signature = None

    st.markdown("""<style>
    .block-container {padding-top:2.3rem; max-width:1320px;}
    h1,h2,h3 {color:#244e62; letter-spacing:-.025em;}
    [data-testid="stMetric"] {background:#f3f6f8; border:1px solid #e5ebee; padding:14px; border-radius:10px;}
    [data-testid="stMetricValue"] {font-size:1.7rem;}
    [data-testid="stSidebar"] {background:#f5f7f9;}
    .intro-label {color:#88703f; font-size:.76rem; font-weight:650; letter-spacing:.14em; text-transform:uppercase;}
    </style>""", unsafe_allow_html=True)
    st.markdown('<div class="intro-label">Estruturas de elevação · LRO</div>', unsafe_allow_html=True)
    st.title("Monovia reta")
    st.write("Da carga móvel à memória de cálculo, com entradas rastreáveis e limites de aplicação explícitos.")
    st.caption("Página NBR preservada da versão 0.1. A rota EN tem ações, hipóteses e relatórios independentes; não há conversão automática entre as bases.")
    st.page_link("pages/2_Complemento_EN.py", label="Abrir complemento EN com torção e empenamento")
    st.page_link("pages/3_Fadiga_NBR.py", label="Abrir fadiga nominal NBR com axial, torção e empenamento")
    notice = st.session_state.pop("notice", None)
    if notice:
        getattr(st, notice[0])(notice[1])
    p = deepcopy(st.session_state.project)
    errors = []

    with st.sidebar:
        st.subheader("Projeto")
        p.project_name = text("Nome do projeto", p.project_name, "project_name")
        p.member_name = text("Identificação da monovia", p.member_name, "member_name")
        p.responsible = text("Responsável informado", p.responsible, "responsible", help="Não é preenchido ou presumido pelo aplicativo.")
        p.demonstration = flag("Dados ilustrativos / demonstração", p.demonstration, "demonstration")
        st.divider()
        run_slot = st.container()
        st.divider()
        with st.expander("Abrir entradas JSON"):
            st.caption("Somente o formato de entrada de monovia deste aplicativo. JSON de ponte, arquivo de resultado e campos desconhecidos são recusados.")
            with st.form("import_project_form", clear_on_submit=False):
                st.file_uploader("Arquivo de entradas", type=["json"], key="import_upload")
                st.text_area("Ou cole o JSON de entradas", key="import_text", height=100)
                st.form_submit_button("Importar entradas", on_click=import_project, width="stretch")
        with st.expander("Recomeçar pelo exemplo"):
            st.caption("Substitui as entradas atuais e remove o resultado da sessão. Salve o JSON antes, se necessário.")
            st.button("Carregar exemplo ilustrativo", key="restore_demo", on_click=restore_demo, width="stretch")
        st.caption("Execução local · nenhuma publicação automática")

    if p.demonstration:
        st.info("Exemplo ilustrativo: dimensões, cargas e classes iniciais não representam uma talha de fabricante. Substitua os dados e suas fontes antes de avaliar uma instalação real.")

    entry_tab, model_tab, results_tab, files_tab = st.tabs(["01 · Entradas", "02 · Modelo", "03 · Resultados", "04 · Arquivos"])

    with entry_tab:
        with st.expander("Carga, vão e viagem", expanded=True):
            c1,c2,c3 = st.columns(3)
            with c1:
                p.capacity_t = n("Capacidade nominal útil (t)", float(p.capacity_t), "capacity_t", minimum=0., step=0.1)
                p.operating_payload_t = n("Carga útil operacional (t)", float(p.operating_payload_t), "operating_payload_t", minimum=0., step=0.1,
                                          help="De zero à capacidade nominal. Ensaio/sobrecarga não pertence à operação normal deste modelo.")
            with c2:
                p.trolley_hoist_mass_kg = n("Massa da talha + trole (kg)", float(p.trolley_hoist_mass_kg), "trolley_hoist_mass_kg", minimum=0., step=10.)
                p.retained_suspended_mass_kg = n("Massa suspensa retida (kg)", float(p.retained_suspended_mass_kg), "retained_suspended_mass_kg", minimum=0., step=5.,
                                                help="Bloco e acessórios suspensos que permanecem no caso vazio. Não inclua novamente na carga útil ou na massa da talha/trole.")
            with c3:
                p.span_m = n("Vão entre apoios (m)", float(p.span_m), "span_m", minimum=0., step=0.1)
                p.extra_dead_kn_per_m = n("Ação permanente adicional (kN/m)", float(p.extra_dead_kn_per_m), "extra_dead_kn_per_m", minimum=0., step=0.01,
                                        help="Carga uniforme adicional, separada do peso próprio automático da viga.")
            c1,c2 = st.columns(2)
            with c1:
                p.travel_min_m = n("Início da viagem do primeiro eixo (m)", float(p.travel_min_m), "travel_min_m", minimum=0., step=0.05)
            with c2:
                p.travel_max_m = n("Fim da viagem do primeiro eixo (m)", float(p.travel_max_m), "travel_max_m", minimum=0., step=0.05)
            st.caption("A posição de viagem é a do eixo de offset zero. Todos os eixos precisam permanecer dentro do vão.")
            p.equipment_source = text("Fonte dos dados do equipamento", p.equipment_source, "equipment_source")
            c1,c2 = st.columns(2)
            with c1:
                p.travel_source = text("Fonte dos limites de viagem", p.travel_source, "travel_source")
            with c2:
                p.extra_dead_source = text("Fonte da ação adicional, inclusive se zero", p.extra_dead_source, "extra_dead_source")

        with st.expander("Perfil e material", expanded=False):
            st.caption("Seção I duplamente simétrica. Rigidez e propriedades resistentes sempre calculadas por três retângulos, sem misturar propriedades tabuladas.")
            try:
                records = list_profiles("W")
                ids = [record["id"] for record in records]
                st.selectbox("Catálogo histórico W · Gerdau 11/2018", ids, key="catalog_profile")
                st.button("Aplicar dimensões e massa do catálogo", on_click=apply_catalog, key="apply_catalog")
                st.caption("A escolha no menu não muda o projeto até aplicar. O catálogo não confirma disponibilidade atual, grau do aço ou adequação do perfil.")
            except (OSError, ValueError, KeyError) as exc:
                st.info("Catálogo indisponível nesta instalação. A entrada manual continua disponível. " + human_error(exc))
            p.section.name = text("Designação do perfil", p.section.name, "section_name")
            old_geometry = (p.section.d_mm,p.section.bf_mm,p.section.tw_mm,p.section.tf_mm,p.section.root_radius_mm,p.section.fabrication)
            p.section.fabrication = choice("Fabricação", ["rolled", "welded"], p.section.fabrication, "section_fabrication", format_func=lambda x:{"rolled":"Laminado", "welded":"Soldado"}.get(x,x))
            c1,c2,c3,c4 = st.columns(4)
            with c1:
                p.section.d_mm = n("Altura d (mm)", float(p.section.d_mm), "section_d_mm", minimum=0., step=1.)
            with c2:
                new_b = n("Largura das mesas bf (mm)", float(p.section.bf_mm), "section_bf_mm", minimum=0., step=1.)
                if new_b != p.section.bf_mm and p.section.bottom_bf_mm:
                    p.section.bottom_bf_mm = new_b
                p.section.bf_mm = new_b
            with c3:
                p.section.tw_mm = n("Espessura da alma tw (mm)", float(p.section.tw_mm), "section_tw_mm", minimum=0., step=0.1)
            with c4:
                new_tf = n("Espessura das mesas tf (mm)", float(p.section.tf_mm), "section_tf_mm", minimum=0., step=0.1)
                if new_tf != p.section.tf_mm and p.section.bottom_tf_mm:
                    p.section.bottom_tf_mm = new_tf
                p.section.tf_mm = new_tf
            c1,c2 = st.columns(2)
            with c1:
                p.section.root_radius_mm = n("Raio físico / equivalente da raiz (mm)", float(p.section.root_radius_mm), "section_root_radius_mm", minimum=0., step=0.1,
                                             help="Laminado: positivo. Soldado: zero. Catálogo W histórico usa raio equivalente obtido de d, tf e alma plana, não raio medido.")
            with c2:
                p.weld_throat_mm = n("Garganta da solda alma–mesa (mm)", float(p.weld_throat_mm), "weld_throat_mm", minimum=0., step=0.1,
                                     help="Soldado: positiva. Laminado: zero. Fadiga da raiz de solda não é coberta pelo detalhe W0.")
            new_geometry = (p.section.d_mm,p.section.bf_mm,p.section.tw_mm,p.section.tf_mm,p.section.root_radius_mm,p.section.fabrication)
            if new_geometry != old_geometry and p.section.catalog_id:
                st.caption("Dimensões editadas: a identidade do catálogo é apenas a origem histórica. Confirme a fonte e a massa linear para a nova geometria.")
            p.section.property_source = text("Fonte e hipóteses da geometria", p.section.property_source, "section_property_source", multiline=True)
            use_mass = flag("Informar massa linear de catálogo / fabricação", p.section_mass_kg_per_m is not None, "use_mass",
                            help="Obrigatória para seção soldada e inclui as soldas. Sem massa informada, laminados usam área geométrica com raios somente para peso próprio.")
            mass = n("Massa linear completa (kg/m)", float(p.section_mass_kg_per_m or 1.), "section_mass_kg_per_m", minimum=0., step=0.1, disabled=not use_mass)
            p.section_mass_kg_per_m = mass if use_mass else None
            p.section_mass_source = text("Fonte da massa linear", p.section_mass_source, "section_mass_source", disabled=not use_mass)
            st.markdown("**Material do perfil**")
            c1,c2,c3,c4 = st.columns(4)
            with c1:
                p.material.fy_mpa = n("Escoamento fy (MPa)", float(p.material.fy_mpa), "material_fy_mpa", minimum=0., step=5.)
            with c2:
                p.material.fu_mpa = n("Ruptura fu (MPa)", float(p.material.fu_mpa), "material_fu_mpa", minimum=0., step=5.)
            with c3:
                p.material.E_mpa = n("Módulo E (MPa)", float(p.material.E_mpa), "material_E_mpa", minimum=0., step=1000.)
            with c4:
                p.material.G_mpa = n("Módulo G (MPa)", float(p.material.G_mpa), "material_G_mpa", minimum=0., step=1000.)
            p.material.gamma_a1 = n("Coeficiente γa1 · NBR 8800", float(p.material.gamma_a1), "material_gamma_a1", minimum=1., step=0.05)
            p.material.specification = text("Especificação / certificado / espessura do aço", p.material.specification, "material_specification")
            p.high_ratio_material_confirmed = flag("Confirmo a rota normativa de material para relação fy/fu elevada", p.high_ratio_material_confirmed, "high_ratio_material_confirmed",
                                                   help="Declaração técnica quando exigida pelo núcleo; não força aprovação nem substitui a qualificação do material.")

        with st.expander("Eixos, rodas e ações nos contatos", expanded=False):
            c1,c2,c3 = st.columns(3)
            with c1:
                count = int(st.number_input("Quantidade de eixos longitudinais", min_value=1, max_value=8, value=len(p.stations), key="ui_station_count"))
            with c2:
                st.number_input("Rodas opostas por eixo", value=2, disabled=True, key="fixed_wheels_per_axis", help="Domínio atual: um par de duas rodas por eixo. Mais rodas ou pares desiguais exigem outro modelo, não uma divisão automática.")
            with c3:
                p.edge_to_contact_mm = n("Borda livre ao contato · n (mm)", float(p.edge_to_contact_mm), "edge_to_contact_mm", minimum=0., step=1., help="Distância da borda da mesa ao ponto de contato. Não é distância à alma.")
            p.equal_opposite_wheels = flag("Adoto duas rodas opostas com forças verticais iguais em cada eixo", p.equal_opposite_wheels, "equal_opposite_wheels")
            st.caption("Frações de G distribuem a massa da talha/trole; frações de Q+B distribuem a carga útil e a massa retida. Cada família deve somar 1. O app não normaliza valores.")
            original_count = len(p.stations)
            if count < original_count:
                for key in list(st.session_state):
                    match = re.match(r"ui_axis_(\d+)_", str(key))
                    if match and int(match.group(1)) >= count:
                        del st.session_state[key]
            axes = deepcopy(p.stations[:count])
            while len(axes) < count:
                index = len(axes)
                axes.append(Station(id=f"E{index+1}", offset_m=max(a.offset_m for a in axes)+0.8, equipment_share=0., suspended_share=0.))
            for index, axis in enumerate(axes):
                st.markdown(f"**Eixo {index+1}**")
                c1,c2,c3,c4 = st.columns([1,1,1,1])
                with c1:
                    axis.id = text("Identificação do eixo", axis.id, f"axis_{index}_id")
                with c2:
                    axis.offset_m = n("Offset longitudinal (m)", float(axis.offset_m), f"axis_{index}_offset", minimum=0., step=0.1)
                with c3:
                    axis.equipment_share = n("Fração G (adimensional)", float(axis.equipment_share), f"axis_{index}_g", minimum=0., step=0.05, format="%.6f")
                with c4:
                    axis.suspended_share = n("Fração Q+B (adimensional)", float(axis.suspended_share), f"axis_{index}_q", minimum=0., step=0.05, format="%.6f")
                c1,c2 = st.columns(2)
                with c1:
                    axis.longitudinal_kn = n("Hx longitudinal total do par (kN)", float(axis.longitudinal_kn), f"axis_{index}_hx", step=0.1)
                with c2:
                    axis.transverse_kn = n("Hy transversal total do par (kN)", float(axis.transverse_kn), f"axis_{index}_hy", step=0.1)
            p.stations = axes
            st.caption(f"Soma das frações: G = {sum(a.equipment_share for a in axes):.6g}; Q+B = {sum(a.suspended_share for a in axes):.6g}. Total: {2*len(axes)} rodas.")
            p.wheel_distribution_source = text("Fonte da distribuição de cargas e da simetria", p.wheel_distribution_source, "wheel_distribution_source")
            p.horizontal_action_source = text("Fonte das ações horizontais, inclusive se zero", p.horizontal_action_source, "horizontal_action_source",
                                               help="Hx e Hy são ações características totais por par nos contatos, com dinâmica horizontal pertinente já incluída. Não são percentuais criados pelo aplicativo.")
            if any(a.longitudinal_kn or a.transverse_kn for a in axes):
                st.info("Ações horizontais geram flexão, axial, momentos de transporte e diagnóstico de torção. A resistência combinada e a envoltória torsional desta adaptação permanecem pendentes ou fora do domínio, sem aprovação automática.")

        with st.expander("Classes, grupos e coeficiente dinâmico", expanded=False):
            st.caption("HC/HD descrevem elevação e acionamento; A1–A8 classifica o equipamento; E1–E8, abaixo, classifica o componente para fadiga. Capacidade em toneladas não define nenhuma dessas classes.")
            c1,c2,c3 = st.columns(3)
            with c1:
                p.hoist_class = choice("Classe de elevação HC", [f"HC{i}" for i in range(1,5)], p.hoist_class, "hoist_class")
            with c2:
                p.drive_class = choice("Classe de acionamento HD", [f"HD{i}" for i in range(1,6)], p.drive_class, "drive_class")
            with c3:
                p.equipment_group = choice("Grupo do equipamento A", [f"A{i}" for i in range(1,9)], p.equipment_group, "equipment_group")
            c1,c2 = st.columns(2)
            with c1:
                p.hoist_speed_m_s = n("Velocidade nominal de elevação (m/s)", float(p.hoist_speed_m_s), "hoist_speed_m_s", minimum=0., step=0.01, format="%.4f")
            with c2:
                use_creep = flag("Informar velocidade lenta", p.creep_speed_m_s is not None, "use_creep", help="Obrigatória para HD2/HD3 nos casos I/II.")
                creep = n("Velocidade lenta de elevação (m/s)", float(p.creep_speed_m_s or 0.), "creep_speed_m_s", minimum=0., step=0.01, disabled=not use_creep, format="%.4f")
                p.creep_speed_m_s = creep if use_creep else None
            p.classification_source = text("Fonte das classes HC/HD e do grupo A", p.classification_source, "classification_source", multiline=True)
            p.dynamic_mode = choice("Determinação do coeficiente Ψ", ["nbr8400_hc_hd","manual"], p.dynamic_mode, "dynamic_mode", format_func=lambda x:{"nbr8400_hc_hd":"NBR 8400 · classes HC/HD", "manual":"Coeficiente específico fundamentado"}[x])
            p.dynamic_psi_manual = n("Coeficiente específico Ψ", float(p.dynamic_psi_manual), "dynamic_psi_manual", minimum=1., step=0.01, disabled=p.dynamic_mode != "manual")
            p.dynamic_source = text("Justificativa / fonte do coeficiente específico", p.dynamic_source, "dynamic_source", disabled=p.dynamic_mode != "manual")
            try:
                dyn = p.dynamics()
                st.caption(f"Prévia: Ψ = {dyn['psi']:.5g}. Aplicado uma única vez às parcelas suspensas, não ao peso da viga ou da talha/trole.")
            except ValueError as exc:
                st.caption("Coeficiente ainda não definido: " + human_error(exc))
            c1,c2 = st.columns(2)
            with c1:
                p.cmaa_class = text("Classe CMAA · somente registro", p.cmaa_class, "cmaa_class")
            with c2:
                p.en_classification = text("Classificação EN · somente registro", p.en_classification, "en_classification")
            st.caption("Não há conversão automática entre CMAA, EN, A, E, HC e HD. O aplicativo não declara conformidade integral da monovia fixa com CMAA 70 ou 74.")

        with st.expander("Apoios e comprimentos resistentes", expanded=False):
            p.end_forks_confirmed = flag("Confirmo garfos ideais nas extremidades, com empenamento livre", p.end_forks_confirmed, "end_forks_confirmed",
                                         help="A análise adota apoio simples nas duas direções, garfos extremos e ancoragem axial à esquerda. Ligações reais são verificadas separadamente.")
            p.restraint_mode = choice("Uso dos travamentos intermediários", ["full_span", "resistance_lengths_only"], p.restraint_mode, "restraint_mode", format_func=lambda x:{"full_span":"Conservador · comprimentos integrais do vão", "resistance_lengths_only":"Nominal · apenas comprimentos resistentes"}[x])
            nominal = p.restraint_mode == "resistance_lengths_only"
            p.nominal_restraints_adopted = flag("Adoto o modelo nominal sem redistribuição de esforços", p.nominal_restraints_adopted, "nominal_restraints_adopted", disabled=not nominal)
            st.caption("Somente duas contenções laterais independentes na mesma posição longitudinal s, uma rígida no centro de cisalhamento e outra na mesa superior, delimitam intervalos de FLT. Não são o mesmo ponto da seção. A eficácia de garfo é requisito do projeto. Mesa inferior não recebe crédito FLT; centro isolado só altera o comprimento nominal de flexão fraca.")
            if not nominal:
                st.caption("As listas abaixo estão desabilitadas e servem apenas como registro. Selecione o modo nominal para editar e considerar comprimentos resistentes.")
            p.upper_braces_m = positions("Mesa superior · posições (m)", p.upper_braces_m, "upper_braces_m", errors, disabled=not nominal)
            p.lateral_axis_braces_m = positions("Centro de cisalhamento rígido · posições (m)", p.lateral_axis_braces_m, "lateral_axis_braces_m", errors, disabled=not nominal)
            p.lower_braces_m = positions("Mesa inferior · posições sem crédito FLT (m)", p.lower_braces_m, "lower_braces_m", errors, disabled=not nominal)
            p.restraint_source = text("Fonte dos vínculos e requisito de realização física", p.restraint_source, "restraint_source", multiline=True)
            show_plan(p)

        with st.expander("Fadiga nominal · rota opcional qualificada", expanded=False):
            st.caption("A rota inicial trata material-base laminado W0, sem entalhe, com grupo de componente explicitamente documentado. Sem essas declarações, a fadiga permanece pendente. Não qualifica soldas, contato roda–mesa ou desgaste.")
            p.fatigue_group = choice("Grupo do componente para fadiga", ["não informado"]+[f"E{i}" for i in range(1,9)], p.fatigue_group, "fatigue_group",
                                     help="O grupo E depende da classificação de utilização e espectro do componente. Não é o grupo A, a classe CMAA ou uma categoria A–E′ do Anexo H da NBR 8800.")
            p.fatigue_material_grade = choice("Grau do material para fadiga", list(LOW_GRADES+HIGH_GRADES), p.fatigue_material_grade, "fatigue_material_grade")
            p.fatigue_detail_confirmed = flag("Confirmo detalhe W0: laminado, material-base sem entalhe", p.fatigue_detail_confirmed, "fatigue_detail_confirmed")
            p.fatigue_kappa_minus_one_adopted = flag("Adoto redução conservadora de resistência com κ = −1", p.fatigue_kappa_minus_one_adopted, "fatigue_kappa_minus_one_adopted",
                                                    help="Adoção explícita de cálculo, não reconstrução de histórico real, vida infinita ou ausência de dano.")
            p.fatigue_fabrication_declared = flag("Declaro os requisitos de fabricação aplicáveis ao detalhe W0", p.fatigue_fabrication_declared, "fatigue_fabrication_declared")
            p.fatigue_source = text("Fonte do grupo E, detalhe, fabricação e adoção de κ", p.fatigue_source, "fatigue_source", multiline=True)
            ready = (p.fatigue_group in [f"E{i}" for i in range(1,9)] and p.fatigue_detail_confirmed and p.fatigue_kappa_minus_one_adopted and p.fatigue_fabrication_declared and bool(p.fatigue_source.strip()))
            if ready:
                st.caption("Declarações preenchidas: a rota de fadiga será avaliada no próximo cálculo, sujeita aos limites de material, geometria e ações.")
            else:
                st.caption("Fadiga ainda não habilitada: complete grupo, detalhe, adoções e fonte para avaliar a rota opcional.")
            with st.expander("Registros adicionais · não habilitam a rota de fadiga"):
                p.fatigue_cycles = int(n("Ciclos registrados (não convertem grupo E)", p.fatigue_cycles, "fatigue_cycles", minimum=1, step=10000, disabled=True))
                p.fatigue_category = choice("Categoria NBR 8800 · somente registro", ["não selecionada","A","B","B'","C","D","E","E'"], p.fatigue_category, "fatigue_category", disabled=True)
                p.fatigue_constant_amplitude = flag("Amplitude constante declarada · registro", p.fatigue_constant_amplitude, "fatigue_constant_amplitude", disabled=True)
                p.corrosion_protected = flag("Proteção contra corrosão declarada · registro", p.corrosion_protected, "corrosion_protected", disabled=True)

        with st.expander("Notas e controle numérico", expanded=False):
            p.notes = text("Notas do projeto", p.notes, "notes", multiline=True)
            c1,c2 = st.columns(2)
            with c1:
                percent = n("Tolerância relativa de busca (%)", float(p.numerical_tolerance*100), "numerical_tolerance_percent", minimum=0.01, step=0.05, format="%.3f")
                p.numerical_tolerance = percent/100
            with c2:
                p.max_refinements = int(st.number_input("Máximo de refinamentos", min_value=0, max_value=8, value=p.max_refinements, key="ui_max_refinements"))
            st.caption("Faixa de tolerância: 0,01% a 2%. Limites superiores incluem erro de discretização; exceder um limite conservador não equivale, sozinho, a comprovar falha física.")

    st.session_state.project = deepcopy(p)
    try:
        p.validate()
    except (ValueError, TypeError, OverflowError) as exc:
        errors.append(human_error(exc))
    st.session_state.input_errors = errors

    with run_slot:
        if errors:
            st.error("Revise as entradas antes de calcular.")
            for error in dict.fromkeys(errors):
                st.caption(error)
        elif st.session_state.result is None:
            st.caption("Entradas consistentes. Nenhum cálculo executado.")
        do_calculate = st.button("Calcular monovia", type="primary", width="stretch", disabled=bool(errors), key="calculate")
        if do_calculate:
            st.session_state.word_bytes = None
            st.session_state.word_signature = None
            for result_key in ("result_check", "result_case", "result_reaction", "result_reaction_end"):
                st.session_state.pop(result_key, None)
            progress = st.progress(0., text="Preparando casos de carga…")
            def update(index, total, case_id):
                progress.progress(index / max(total, 1), text=f"Caso {min(index+1,total)}/{total} · {case_id}")
            try:
                with st.spinner("Avaliando posições móveis e verificações…"):
                    st.session_state.result = analyze(p, progress=update)
                progress.empty()
                st.success("Cálculo concluído. Confira Resultados e Arquivos.")
            except Exception as exc:
                progress.empty()
                st.session_state.result = None
                st.error("Cálculo não concluído: " + human_error(exc))

    r = st.session_state.result
    current = False
    stale_reason = None
    if r is not None and not errors:
        try:
            assert_current_result(p, r)
            current = True
        except (ValueError, TypeError, OverflowError) as exc:
            stale_reason = human_error(exc)
    elif r is not None:
        stale_reason = "As entradas estão incompletas ou inválidas. Corrija e calcule novamente."
    if not current:
        st.session_state.word_bytes = None
        st.session_state.word_signature = None
    st.session_state.result_is_current = current

    with model_tab:
        st.subheader("Modelo físico e caminho de carga")
        if not errors:
            st.image(cached_schematic(p.to_json()), width="stretch")
            c1,c2,c3 = st.columns(3)
            c1.metric("Vão físico", f"{p.span_m:g} m")
            c2.metric("Rodas", str(2*len(p.stations)))
            c3.metric("Peso próprio da viga", f"{p.self_weight_kn_m():.4f} kN/m")
        else:
            st.info("O esquema será atualizado quando as entradas forem consistentes. " + errors[0])
        st.markdown("**O que o modelo representa**")
        st.write("Uma viga reta prismática, um equipamento e um vão, com duas rodas opostas iguais por eixo sobre a mesa inferior. A análise mantém apoios simples nas extremidades, garfos ideais e ancoragem axial à esquerda.")
        st.caption(AXIS_HELP)
        show_plan(p)
        st.markdown("**Bases independentes de verificação**")
        st.write("• NBR 10084/8400: operação normal, tensões e flexão local da mesa inferior.\n• NBR 8800: complemento global ELU, identificado separadamente.\n• Flecha nominal L/500: somente capacidade útil nominal, sem pesos próprios ou impacto.\n• Fadiga opcional: caso I sem coeficiente de amplificação Mₓ do grupo A, com detalhe e grupo de componente documentados. Esse coeficiente não é o momento forte Mx dos diagramas.")
        st.markdown("**Limites que continuam separados**")
        st.write("Apoios e ligações, contato/desgaste, regiões perturbadas, enrijecedores, curvas, desvios, múltiplos equipamentos, eventos especiais, vibração e segunda ordem não recebem aprovação por este modelo. Ações horizontais não implicam qualificação automática da resistência combinada.")
        st.caption("Travamentos nominais não modificam deslocamentos, ações ou reações da viga biapoiada. Os requisitos físicos de contenção precisam ser realizados e verificados no projeto real.")

    with results_tab:
        st.subheader("Verificações e estados calculados")
        if not current:
            if r is None:
                st.info("Preencha as entradas e use Calcular monovia. Nenhum resultado é mostrado antes do cálculo.")
            else:
                st.warning("Resultado desatualizado. " + (stale_reason or "As entradas mudaram. Calcule novamente."))
        else:
            if r["counts"].get("FAIL",0):
                st.error(r["summary"])
            elif r["counts"].get("BOUND_EXCEEDED",0):
                st.warning(r["summary"])
            else:
                st.info(r["summary"])
            st.caption("Atendimento de critérios não equivale à aprovação integral da instalação. Pendências e itens fora do escopo permanecem visíveis e não são tratados como aprovação.")
            cols = st.columns(5)
            for col,status in zip(cols,LABELS):
                col.metric(LABELS[status], r["counts"].get(status,0))
            st.dataframe(check_table(r["checks"]), hide_index=True, width="stretch", column_config={"Utilização":st.column_config.NumberColumn(format="%.4f"), "Solicitação / majorante":st.column_config.NumberColumn(format="%.5g"), "Resistência / limite":st.column_config.NumberColumn(format="%.5g")})
            with st.expander("Entender cada verificação", expanded=False):
                checks = r["checks"]
                selected = st.selectbox("Verificação detalhada", range(len(checks)), format_func=lambda i:checks[i]["title"], key="result_check")
                check = checks[selected]
                st.write(LABELS.get(check["status"],check["status"]) + ": " + check.get("reason", ""))
                if check.get("formula"):
                    st.caption("Expressão: " + check["formula"])
                if check.get("source"):
                    st.caption("Fonte: " + check["source"])
                st.json(check.get("values",{}), expanded=False)
            st.divider()
            st.markdown("**Diagramas de um estado concomitante**")
            cases = r["cases"]
            case_index = st.selectbox("Caso de carga", range(len(cases)), key="result_case",
                                      format_func=lambda i:f"C{i+1:02d} · {FAMILIES.get(cases[i]['case']['family'],cases[i]['case']['family'])} · {'carregada' if cases[i]['case']['loaded'] else 'vazia'} · {cases[i]['case']['id']}")
            case = cases[case_index]
            st.caption("Os diagramas mostram estados físicos de uma posição do trole, não uma colagem de máximos. A posição crítica de flecha pode diferir da posição dos esforços.")
            st.caption(AXIS_HELP)
            force_png, deflection_png, envelope_png = cached_diagrams(case)
            st.image(force_png, width="stretch")
            st.image(deflection_png, width="stretch")
            st.markdown("**Envoltórias espaciais amostradas**")
            st.caption("Mínimos e máximos entre posições amostradas do equipamento em cada seção. Estas curvas não são os majorantes certificados das métricas e não formam um estado concomitante.")
            st.image(envelope_png, width="stretch")
            if any(axis.transverse_kn for axis in p.stations):
                st.markdown("**Torção elástica · diagnóstico concomitante**")
                st.caption("T total, Saint-Venant, empenamento, bimomento e rotação na posição indicada. Não é envoltória torsional nem verificação de resistência qualificada.")
                st.image(cached_torsion(case), width="stretch")
            with st.expander("Ações por eixo, extremos e reações"):
                st.markdown("**Ações verticais por eixo**")
                st.dataframe(pd.DataFrame([{"Eixo":a["station_id"],"Offset (m)":a["offset_m"],"G talha/trole (kN)":a["pair_dead_kn"],"Q útil (kN)":a["pair_payload_kn"],"B retida (kN)":a["pair_retained_kn"],"Total do par (kN)":a["pair_vertical_kn"],"Por roda (kN)":a["individual_wheel_kn"]} for a in case["wheel_ledger"]]), hide_index=True, width="stretch")
                st.markdown("**Extremos com majorante numérico**")
                st.dataframe(pd.DataFrame([{"Grandeza":METRIC_LABELS.get(m["metric"],m["metric"]),"Máximo amostrado":m["absolute_value"],"Majorante certificado":m["upper_bound"],"Erro de discretização":m["discretization_error_bound"],"Translação (m)":m["translation_m"]} for m in case["maxima"]]), hide_index=True, width="stretch")
                st.caption(f"Amostras: {case['samples']} · refinamentos: {case['refinements']} · convergência: {'sim' if case['converged'] else 'não atingida'}. Reações extremas pertencem aos respectivos estados concomitantes.")
                st.markdown("**Reações vetoriais físicas · extremos amostrados do apoio sobre a viga**")
                st.caption("Forças positivas nos eixos físicos (s, y, z) do esquema; momento em torno de +s pela regra da mão direita. Os valores abaixo são ações do apoio SOBRE a viga. Para dimensionar o apoio, use o vetor oposto da viga sobre o apoio no estado concomitante, mostrado a seguir.")
                physical = case.get("physical_reaction_extrema")
                reaction_names = {
                    "R_s_left_kn": ("Esquerdo", "Rₛ · longitudinal", "kN"),
                    "R_y_left_kn": ("Esquerdo", "Rᵧ · horizontal", "kN"),
                    "R_z_left_kn": ("Esquerdo", "R_z · vertical", "kN"),
                    "M_s_left_knm": ("Esquerdo", "Mₛ · torçor", "kN·m"),
                    "R_s_right_kn": ("Direito", "Rₛ · longitudinal", "kN"),
                    "R_y_right_kn": ("Direito", "Rᵧ · horizontal", "kN"),
                    "R_z_right_kn": ("Direito", "R_z · vertical", "kN"),
                    "M_s_right_knm": ("Direito", "Mₛ · torçor", "kN·m"),
                }
                if physical:
                    st.dataframe(pd.DataFrame([
                        {"Apoio": label[0], "Componente": label[1], "Mínimo": physical[key]["min"]["value"],
                         "a do mínimo (m)": physical[key]["min"]["translation_m"],
                         "Máximo": physical[key]["max"]["value"], "a do máximo (m)": physical[key]["max"]["translation_m"],
                         "Unidade": label[2]}
                        for key,label in reaction_names.items()
                    ]), hide_index=True, width="stretch")
                    st.caption("Extremos entre as posições avaliadas do trole, não uma declaração de envoltória contínua qualificada de torção. Cada extremo pertence à sua própria posição. Não combine componentes extremas de linhas diferentes como se fossem um único estado de carga.")
                    c1,c2 = st.columns([3,1])
                    with c1:
                        reaction_key = st.selectbox("Componente para consultar o estado concomitante", list(reaction_names), key="result_reaction",
                                                    format_func=lambda key:reaction_names[key][0] + " · " + reaction_names[key][1])
                    with c2:
                        reaction_end = st.selectbox("Extremo", ["min", "max"], key="result_reaction_end", format_func=lambda value:{"min":"Mínimo", "max":"Máximo"}[value])
                    witness = physical[reaction_key][reaction_end]
                    st.caption(f"Todos os valores a seguir pertencem ao mesmo caso e à mesma translação a = {witness['translation_m']:.5g} m.")
                    st.dataframe(pd.DataFrame([
                        {"Apoio": label[0], "Componente": label[1], "Apoio sobre viga": witness["support_on_beam"][key],
                         "Viga sobre apoio": witness["beam_on_support"][key], "Unidade": label[2]}
                        for key,label in reaction_names.items()
                    ]), hide_index=True, width="stretch")
                else:
                    st.info("Reações vetoriais físicas indisponíveis neste recibo. Calcule novamente para apresentá-las.")
                with st.expander("Auditoria técnica · convenções e ordenadas legadas"):
                    st.caption("Não use as ordenadas legadas como vetores de apoio sem a transformação registrada. O sinal horizontal legado é diferente de Rᵧ físico; o torque físico em +s tem sinal oposto ao torque LRO. Os aliases são preservados exclusivamente para rastreabilidade.")
                    st.json(case.get("reaction_convention", {}), expanded=False)
                    st.json(case["reaction_extrema"], expanded=False)
            with st.expander("Rastreabilidade do cálculo e limitações"):
                st.write(f"Cálculo UTC: {r['calculated_at_utc']} · duração: {r['seconds']:.2f} s.")
                st.caption("Assinatura das entradas: " + r["project_signature"])
                st.caption("Assinatura das fontes: " + r["source"]["fingerprint"])
                for limitation in r["limitations"]:
                    st.write("• " + limitation)

    with files_tab:
        st.subheader("Salvar e revisar")
        st.write("Guarde as entradas para retomar o projeto; gere a memória e os dados somente a partir do cálculo atual.")
        input_data = p.to_json().encode("utf-8") if not errors else b""
        st.download_button("Baixar entradas JSON", data=input_data, file_name=filename(p,"_entradas.json"), mime="application/json", disabled=bool(errors), key="download_input", on_click="ignore")
        st.caption("O JSON de entradas pode ser reaberto no painel lateral. O JSON de resultados é um registro de cálculo, não um arquivo de entrada.")
        if not current:
            st.info("Word e JSON de resultados estão indisponíveis até existir cálculo válido e atualizado. Reprovação de perfil, por si só, nunca bloqueia a exportação.")
            st.download_button("Baixar resultados JSON", data=b"", file_name=filename(p,"_resultados.json"), disabled=True, key="download_result", on_click="ignore")
            st.button("Preparar memória Word", disabled=True, key="prepare_word")
        else:
            st.download_button("Baixar resultados JSON", data=export_json(p,r), file_name=filename(p,"_resultados.json"), mime="application/json", key="download_result", on_click="ignore")
            st.caption("O relatório inclui verificações atendidas, não atendidas, pendentes e fora do escopo. Não substitui a responsabilidade técnica nem a revisão do projeto completo.")
            if st.button("Preparar memória Word", key="prepare_word", type="primary"):
                try:
                    with st.spinner("Montando memória, tabelas e diagramas…"):
                        st.session_state.word_bytes = export_docx(p,r)
                        st.session_state.word_signature = r["result_signature"]
                except Exception as exc:
                    st.session_state.word_bytes = None
                    st.error("Não foi possível preparar o Word: " + human_error(exc))
            if st.session_state.word_bytes and st.session_state.word_signature == r["result_signature"]:
                st.download_button("Baixar memória Word", data=st.session_state.word_bytes, file_name=filename(p,"_memoria.docx"), mime="application/vnd.openxmlformats-officedocument.wordprocessingml.document", key="download_word", on_click="ignore")
                st.success("Memória pronta para baixar, inclusive os critérios que não atendem.")


if __name__ == "__main__":
    main()
