# Mapa de implementação da monovia 0.2

A rota NBR 0.1 permanece preservada. A tabela abaixo descreve o complemento EN independente; presença de um módulo legado no pacote não significa que a interface o executa.

| Mecanismo | Implementação e domínio | Evidência e limite |
|---|---|---|
| Ações EN | Uma talha de gancho interna, grupos correlacionados e origens G/Qc/Qh separados | Testes independentes de dinâmica, fatores, ensaios, retenção de massas e JSON; dados reais e cobertura de eventos dependem do projeto |
| Flexão e reações móveis | Um vão, rodas entre apoios, pares inferiores opostos | Fórmulas fechadas e equilíbrio físico de forças/momentos |
| Torção e empenamento | Modelo analítico Vlasov, garfos extremos, empenamento livre, J/Cw canônicos | Solução independente de EDO em alta precisão, saltos, sinais e contatos; não é prova de rigidez de ligação real |
| Força longitudinal | Forças iguais no par, vínculo axial esquerdo no centro de cisalhamento, direita livre | N e Hs·z mantidos; falta dessa idealização produz não calculado, não força zero |
| Busca móvel | Raízes espaciais e refinamento aninhado da translação | Convergência de engenharia declarada, não envoltória contínua certificada |
| Seção nominal ELU | N/My/Mz/B e cisalhamento Fy/Fz/Tsv/Tw, com γM0 | Limite suficiente conservador; não representa tensor 3D do contato/raiz |
| Estabilidade C.2 | Classe 1–3, condições axiais/bimomento/radiais verificadas, γM1 | Comprimento L integral; compressão+biflexão arbitrária pode ficar pendente sem apagar a seção calculável |
| Mesa inferior ELU | Ramo remoto publicado, força por roda, espaçamento real ou limite isolado | Resultado literal de flexão separado do suplemento de engenharia N/M/B; ponta/transição não interpoladas |
| Tensões de serviço | Componentes locais EN integrais mais recuperação global nominal | Critérios individuais/equivalentes; sem redutor longitudinal NBR 0,75 |
| Flecha nominal | Somente carga útil nominal, sem dinâmica/G/Qc/acessórios/cordas | L/500, distinta do total; solução fechada independente |
| Flecha total | G fixo + Qc + Qh nominal, sem dinâmica, contraflecha zero | min(L/600,25 mm), recomendação declarada, apoios rígidos |
| Ensaios | QT completo substitui Qh; grupos estático/dinâmico fornecidos | γF,test no grupo inteiro, sem reaplicar γQ comum; não inventa plano de ensaio real |
| Interface e documentos | Entradas próprias, JSON estrito, cálculo por caso, Word mesmo com falha/pendência | Edição/importação inválida remove recibo e Word; AppTest e renderização Word separados da inspeção visual em navegador |

## Estados que não podem ser confundidos

O resumo principal considera variantes com componentes de ação completos. Referências diagnósticas parciais continuam listadas em separado, com seus próprios estados e contagens. Grupos sem entradas suficientes permanecem visíveis mesmo quando não geram casos. Nenhum desses filtros altera forças, equações ou aprova a cobertura integral do equipamento.

Falha nominal testemunhada não é uma previsão de ruptura. Majorante excedido não é, sozinho, falha testemunhada. Domínio não fechado e erro aritmético de geometria extrema não viram PASS nem são ocultados: caso, etapa e motivo são preservados. Um consumidor indisponível não apaga outro mecanismo calculável.

## Fora do fechamento desta interface EN

Fadiga EN; raiz/concordância e contato tridimensionais; rolamentos; ligações, garfos e suspensões reais; enrijecedores; curvas/desvios; multivãos/continuidade; múltiplas talhas; trole em balanço; batentes e eventos completos; vibração; certificação de materiais/fabricante; aplicação de um Anexo Nacional não examinado.

Extremidades/prolongamentos e fadiga nominal NBR ampliada foram estudados/testados separadamente, mas não são automaticamente funcionalidades concluídas da página EN. Seus protótipos e testes, quando fornecidos, ficam identificados no pacote de evidências, não no fluxo de aprovação da interface.

Os relatórios de auditoria registram o freeze e o conjunto efetivamente executado. Contagem de testes não equivale a certificação nem a ausência universal de defeitos.
