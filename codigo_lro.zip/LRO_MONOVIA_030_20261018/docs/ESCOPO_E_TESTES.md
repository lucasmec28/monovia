# Escopo e evidência de teste

Estado da revisão 0.1.0, 18/10/2026. Os testes dizem respeito ao software e ao domínio descrito, não aprovam uma instalação real.

| Área | Implementado | Evidência / restrição |
|---|---|---|
| Resposta vertical e lateral, axial e flechas | Sim | Kernels preservados; carga pontual central/excêntrica, duas rodas, UDL e auto peso comparados com soluções analíticas e função de Green independente. |
| Movimento longitudinal e extremos | Sim | Reações em equilíbrio, cortes dos dois lados das rodas, busca e majorantes de discretização, refinamento e não convergência testados. Curvas por seção são amostradas. |
| Capacidade, massas e fatores | Sim | Nominal só capacidade; vazio mantém massa retida; dinâmica só parcela suspensa; fadiga sem amplificação do grupo A; distribuição e casos completos conferidos. |
| Reações físicas para apoios | Sim | Mapeamento explícito dos aliases do kernel a (s,y,z), vetores de apoio sobre viga e viga sobre apoio opostos, forças horizontais/axiais/torques testados. |
| FLT sem crédito adicional de altura | Sim, no domínio compacto | Cb=1, garfos nas extremidades; condição da carga abaixo da semialtura identificada. N/T não nulos não recebem aprovação combinada nesta versão. |
| Travamentos nominais | Sim, opcional | Centro sozinho, mesa superior sozinha, mesa inferior e quase-coincidência não encurtam FLT. Par longitudinal exato encurta apenas comprimento resistente, sem mudar os casos de resposta. |
| Mesa inferior interior, abas paralelas | Sim | Doze pontos e quatro critérios; sinais, fator 0,75 somente local longitudinal, caixas conservadoras contendo estados assinados testados. Sem crédito em ponta/transição. |
| Rodas próximas | Sim, estática conservadora | Superposição publicada, grupos separados sem duplicação de rodas opostas. Exceder majorante não vira falha física testemunhada. |
| Fadiga W0 nominal | Sim, condicional | Exige adoções e fontes; caso próprio e κ=−1. Categorias/detalhes diferentes, concentração real e histórias externas não são inventados. |
| Torção e empenamento | Resposta diagnóstica | T, Tsv, Tw, B e θ calculados no estado concomitante. A versão 0.1 não fecha resistência combinada nem envelope torsional contínuo. |
| JSON | Sim | Schema exato, tipos estritos, XML inválido, duplicatas, NaN/Infinity, campos extras/ausentes, classificações e distribuição invalidados. Importar não valida recibos externos. |
| Word | Sim | Geração com falhas e pendências; bloqueio quando não calculado/desatualizado/adulterado; imagens e tabelas. DOCX demonstrativo renderizado e páginas inspecionadas. |
| Interface | Teste funcional AppTest | Entradas, ajuda, catálogo, cálculo, importação, erro e exportações ensaiados no Streamlit real. Inspeção visual em navegador não concluída no ambiente de teste; não afirmada como aprovada. |
| Windows/macOS | Comandos fornecidos | Pacote Python e inicializadores portáveis; execução verificada em Linux, não em Windows/macOS. |
| Instalação real completa | Não | Dados reais, contato/desgaste, ligações, apoios, garfos, eventos especiais, fabricação e revisão profissional continuam necessários. |

## Status dos critérios

- **Atende no domínio:** demanda ou majorante está dentro da resistência do critério e suas hipóteses estão satisfeitas.
- **Não atende:** ao menos um estado físico avaliado excede o limite do critério.
- **Limite conservador excedido:** a caixa/majorante não permite concluir, mas sua excedência sozinha não prova falha física.
- **Pendente:** falta qualificação, dado, cobertura ou uma etapa do mecanismo.
- **Fora do escopo:** a rota não abrange aquele estado, geometria ou mecanismo.

Nenhum desses rótulos é convertido silenciosamente para outro. O resumo nunca ignora pendências para emitir aprovação global.

## Testes executáveis

O ZIP separado de evidências contém `tests/` (integração, resistência e AppTest) e `independent_tests/` (auditoria independente portátil). Seu `QA_REPORT.md` registra o fechamento da suíte. Esses arquivos não são necessários para operar o app. As auditorias independentes são identificadas separadamente para não somar comparações aleatórias como se fossem centenas de projetos reais aprovados.
