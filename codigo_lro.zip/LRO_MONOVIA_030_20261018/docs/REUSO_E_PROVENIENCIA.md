# Reuso e proveniência das rotas NBR e EN

Fonte: `LRO_043_FULLHEIGHT_NOMINAL_REV_20261017_2248.zip`, revisão recebida em 17/10/2026. SHA-256:

`4a2fca7a44eff3073f50c779eb74ebeb7ad450dae44d61257f41066daf0afdde`

A versão local antiga não foi usada como base. O ZIP atualizado foi extraído separadamente e preservado. Os três pacotes legados abaixo foram copiados sem editar seus arquivos. O manifesto `LEGACY_SOURCE_MANIFEST.json` permite comparar cada arquivo com essa origem. Esta entrega contém uma adaptação de entradas e composição de rotinas, não um segundo solver paralelo.

## Rota NBR preservada da versão 0.1

A tabela abaixo descreve a página NBR. Seus limites não são automaticamente os mesmos do complemento EN.

| Mecanismo | Núcleo reutilizado | Adaptação da monovia |
|---|---|---|
| Viga simples e trem móvel | `lro_beams/moving_beam.py` | Pares físicos de rodas, viagem delimitada, ledgers por origem, casos e recuperação de testemunhos. |
| Torção Vlasov | `lro_beams/beam_torsion.py` | Altura do contato na mesa inferior, torque da força lateral, resposta diagnóstica concomitante e sinais físicos explícitos. Sem liberação da resistência torsional. |
| Dinâmica e combinações | `lro_beams/autonomous_actions.py` | Capacidade, carga operante, talha/trole, massa retida e peso próprio separados. Cada base de cálculo mantém seus próprios fatores. |
| Propriedades de seção | `lro_beams/geometry.py` | Três retângulos para resistência/rigidez; massa do catálogo explícita ou massa geométrica ilustrativa com raios. |
| Comprimentos resistentes | `lro_beams/autonomous_nominal_lengths.py` | Modo opcional explicitamente adotado; duas contenções independentes em alturas distintas na mesma estação longitudinal formam garfo nominal, sem novos apoios no solver. |
| Resistência NBR 8800 | Rotinas preservadas de flexão, FLT e cisalhamento de `lro_beams` | Domínios compactos, Cb=1 e maior trecho nominal. Bases ELU não são relabeladas como tensões admissíveis. |
| Mesa inferior | Recuperação e rotinas locais de `underslung_runway_candidate`, rotas NBR 10084/8400 | Doze pontos, sinais/faces, parcela longitudinal local ×0,75, domínio interior e superposição conservadora de rodas próximas. |
| Tensões nominais globais | `section_stress/whole_section_bounds.py` e recuperação elástica preservada | Majorantes por região com N=T=0. Recuperação mecânica por equilíbrio/Jourawski não é apresentada como nova resistência normativa nem como limite universal de concentrações reais. |
| Fadiga | `underslung_runway_candidate/fatigue/` | Rota nominal W0 de seção laminada sem entalhe, grupo do componente e adoção conservadora κ=−1 explícitos; nenhum ciclo/detalhe é inferido de capacidade ou CMAA. |
| Catálogo | `lro_beams/catalog.py` e dados originais com verificação SHA | Importa dimensões, massa e origem, sem inventar novas séries ou atualidade comercial; não mistura propriedades tabuladas com rigidez de retângulos. |

`monorail/model.py`, `analysis.py`, `checks.py`, `figures.py`, `export.py` e `labels.py` são a camada nova. `app.py` é a interface própria de monovia. A presença de outras rotas no legado não significa ativação ou validação automática dessas rotas neste app.

## Complemento EN da versão 0.2

Os arquivos legados continuam sem alterações. A nova página compõe os mecanismos abaixo; não usa o gerador NBR de ações para produzir resultados EN.

| Mecanismo | Reuso e adaptação |
|---|---|
| Flexão, axial e torção | `moving_beam.py`, `beam_torsion.py`, resposta concomitante e raízes críticas analíticas preservadas. `analytical_scan.py` e `en_analytical_scan.py` conectam forças físicas EN, condições axiais e busca da translação; J/Cw canônicos são adotados antes de resolver, sem reescalar B posteriormente. |
| Ações | `en_actions/` é um gerador separado, construído a partir das edições EN declaradas e testado por casos fechados. Não reaplica dinâmica ou coeficientes sobre um resultado NBR. |
| Seção e estabilidade | Recuperação elástica, majorantes nominais e Anexo C.2 preservados, com consumidor `en_member.py`, condições de aplicabilidade, fatores de material e referências de Mcr explícitos. |
| Mesa inferior e serviço | Fórmulas locais EN preservadas, consumidas por `en_local_service.py`. Serviço usa parcela local integral. ELU literal de flexão e suplemento conservador N/M/B são distinguidos. |
| Interface e relatório | `en_project.py`, `en_analysis.py`, `en_examples.py`, `en_report.py` e página EN compõem entradas, casos, estados, figuras e exportação, sem importar aprovação da página NBR. |

A resistência combinada com torção é calculável em mecanismos EN identificados, dentro de seus domínios. Isso não altera a limitação torsional da rota NBR 0.1, não fecha fadiga EN e não constitui aprovação integral do equipamento. O mapa `ESCOPO_020.md` e a memória de cada cálculo detalham a distinção.

## Fadiga nominal NBR ampliada da versão 0.3

A nova página usa os casos `FAT8400` da camada NBR preservada e o mesmo solver mecânico analítico, com seu adaptador físico e sinais auditados. `nominal_scan.py` exige exatamente todos os casos regenerados e preserva os intervalos assinados. A recuperação em `prototype.py` é usada somente para construir os planos nominais; suas funções experimentais de estabilidade/ponte entre bases não são chamadas pela nova interface.

As equações e admissíveis de fadiga continuam em `underslung_runway_candidate/fatigue/`. `nbr_fatigue_project.py`, `nbr_fatigue_analysis.py` e `nbr_fatigue_report.py` são camadas de entrada, orquestração e apresentação, não uma segunda formulação resistente. O consumidor nominal e a recuperação foram copiados sem alterar as equações após os ensaios mecânicos independentes.

A combinação longitudinal elástica completa com 0,75 na parcela local tem sua interpretação conjunta documentada em `BASE_FADIGA_NBR.md`. Não se usa C.2 EN como resistência NBR, não se converte ELU em fadiga e não se altera o domínio da página NBR original. A alma com componente de cisalhamento fora do plano disponível permanece pendente.

## Resultados e integridade

As entradas e os arquivos Python de cálculo têm assinaturas SHA-256. O resultado guarda seu próprio digest e uma lista dos arquivos de código. A exportação recusa mudança de entrada, alteração do recibo ou edição do código após o cálculo. Isto é uma proteção de consistência do aplicativo, **não assinatura digital do responsável técnico nem mecanismo de segurança contra alguém que deliberadamente reescreva o programa**.

O JSON de entradas nunca carrega resultado ou aprovação importada. O JSON de resultados não é aceito pela tela de importação de projeto. Arquivos Python e dados de catálogo devem ser mantidos juntos; não copie somente `app.py`.
