# LRO Monovia 0.1.0

Aplicativo local para **monovia reta de um vão, viga I/H duplamente simétrica, talha/trole na mesa inferior**, sem crédito de enrijecedores. Revisão de 18/10/2026.

Reaproveita os núcleos da revisão LRO de 17/10/2026. Não depende de Robot, acesso ao computador do desenvolvedor, chave de API ou serviço de cálculo remoto. A interface abre no navegador, mas o Python calcula na máquina em que foi iniciado.

**Esta versão não é uma aprovação de instalação nem uma declaração de conformidade integral CMAA 70/74.** Critérios atendidos, falhas físicas testemunhadas, majorantes excedidos, dados pendentes e mecanismos fora do escopo são separados. Perfil reprovado continua exportável; resultado inexistente/desatualizado não vira memória válida.

## Iniciar

Ambiente de referência testado: Python 3.12.14, Linux. Use Python 3.12. No Windows, instale Python do distribuidor oficial antes de iniciar; a execução específica no Windows/macOS não foi ensaiada nesta entrega.

### Windows

1. Extraia o ZIP inteiro em uma pasta.
2. Execute `iniciar_windows.bat`. Na primeira execução, ele cria `.venv` e instala as versões de `requirements.txt` no índice Python padrão.
3. Abra o endereço local mostrado, normalmente `http://127.0.0.1:8501`.

### Linux / macOS

```sh
sh iniciar_linux_mac.sh
```

Ou execute manualmente, dentro da pasta do app:

```sh
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python -m streamlit run app.py --server.address 127.0.0.1 --browser.gatherUsageStats false
```

O endereço está limitado à própria máquina. **Não há publicação, cadastro ou alteração automática de GitHub/Streamlit Cloud.** A primeira instalação precisa de internet; os cálculos e a exportação não precisam.

## Primeiro cálculo

1. O exemplo aberto é inteiramente ilustrativo. Não representa uma talha, aço ou catálogo comercial aprovado.
2. Informe o vão, seção, material e suas fontes. A seleção opcional de W usa o catálogo histórico preservado do aplicativo original, não uma consulta de disponibilidade atual. Só dimensões e massa são transportadas; a rigidez continua sendo calculada por três retângulos. Confira o raio equivalente e o detalhe real.
3. Separe capacidade nominal, carga operacional, massa da talha/trole e massa suspensa retida. A carga operacional não pode superar a capacidade no modo de operação normal.
4. Cada linha de eixo longitudinal representa **duas rodas opostas iguais**. Frações de G e de Q/B devem somar 1 em cada coluna. Não há distribuição automática por centro de gravidade. O primeiro offset é zero, os demais crescem.
5. Informe `n`, distância da borda ao centro de contato, limites de viagem do primeiro eixo e forças horizontais características totais por par. O contato deve ficar fora da raiz/solda. A geometria da banda e o diâmetro não são inventados.
6. Confirme classificações, dinâmica e vínculos efetivamente realizados. Grupo A, grupo E, HC/HD, CMAA e EN não são intercambiáveis.
7. Clique em **Calcular monovia**. Consulte os resultados, as hipóteses e a linha específica de cada pendência, não apenas os números em verde.
8. Salve o JSON de **entradas** e gere a memória Word. JSON de **resultados** preserva os detalhes auditáveis; não é aceito como projeto nem como autorização importada de cálculo.

Qualquer alteração invalida a memória e os resultados anteriores. A importação não aceita arquivos antigos de ponte superior ou estruturas com outro schema renomeados como monovia.

## O que o cálculo faz

- Um trem móvel de até oito eixos, cada um com duas rodas simétricas, dentro do vão. Reações concomitantes e extremos de Mx, My, Vy, Vx, N e flechas.
- Extremos espaciais analíticos e controle de discretização da translação herdados. O maior valor amostrado, seu majorante e o erro são distintos. As curvas de envoltória por seção são **amostradas**, não estados concomitantes nem certificados de resistência.
- Forças horizontais explícitas produzem axial, momentos de transporte e torção Vlasov com empenamento livre nos garfos extremos. A torção permanece diagnóstica: sua resistência combinada e sua envoltória integral não estão qualificadas nesta adaptação.
- Flecha de monovia L/500 com **somente a capacidade nominal útil**, sem peso próprio, talha, retida, impacto ou ELU, pela NBR 10084:2020, Tabela 4(c).
- Caso I NBR 10084/8400, caso de fadiga sem fator de classificação Mx e ELU complementar NBR 8800 mantêm registros de fatores separados. A dinâmica de içamento é aplicada à parcela suspensa, não indiscriminadamente a todos os pesos.
- Resistência global complementar de seções compactas dentro das hipóteses NBR 8800, sem benefício extra do nível inferior da carga, com Cb=1.
- Tensões nominais globais NBR 8400 e tensões locais NBR 10084 §9.1.4 nas duas faces e lados da mesa, para abas paralelas e região interior. Rodas próximas recebem superposição conservadora publicada, não uma redução inventada.
- Fadiga nominal conservadora W0, material laminado sem entalhe, apenas quando o grupo do **componente** E1–E8, detalhe, material, fabricação e adoção de κ=−1 forem declarados. Ciclos/categoria EN ou NBR 8800 registrados não convertem grupo E nem fazem contagem de dano.

## Travamentos

O modo inicial usa comprimento integral. O modo opcional **comprimentos resistentes nominais** reaproveita o resolvedor do LRO:

- Uma contenção lateral no centro de cisalhamento, sozinha, não é garfo FLT.
- Uma contenção na mesa superior, sozinha, também não é garfo.
- Duas restrições independentes em **alturas distintas**, centro de cisalhamento e mesa superior, na **mesma coordenada longitudinal**, podem delimitar o garfo nominal explicitamente adotado.
- Mesa inferior não recebe crédito FLT automático. Quase-coincidência não é arredondada para coincidência.
- O maior trecho resistente é usado conservadoramente com o majorante global de momento e Cb=1. Não são adicionados apoios, reações, redistribuição ou rigidez à resposta da viga.
- A rigidez, resistência, ancoragem e ligação reais das contenções continuam fora do dimensionamento deste módulo. Declarar a hipótese não comprova o detalhe.

## Limites que permanecem visíveis

Não dimensiona monovia curva, desvios, multivãos/continuidade, múltiplas talhas simultâneas, seção variável, rodas verticais desiguais no mesmo par, aba cônica, enrijecedores, juntas, furos, apoio/ligação/suspensão, batentes/emergência/ensaio/vento, contato Hertz/vida de rolamento ou instalação completa. Região de ponta não usa indevidamente a fórmula interior; sua verificação fica pendente. Perfis não compactos e fabricação/detalhes fora dos kernels recebem estado próprio, nunca um PASS por ausência de cálculo.

CMAA 70/74 não são normas integrais da monovia fixa. A FAQ oficial permite correlação da interface quando igual, sem estender o escopo à estrutura-suporte. Nesta adaptação, a rota local executada é a NBR 10084/8400; a presença de módulos legados CMAA/EN no pacote não significa que foram aplicados.

Veja `docs/BASE_NORMATIVA.md`, `docs/ESCOPO_E_TESTES.md` e `docs/REUSO_E_PROVENIENCIA.md`.

## Testes e reprodução

```sh
.venv/bin/python -m pip install -r requirements-dev.txt
.venv/bin/python -m pytest -q tests independent_tests
```

No Windows, use `.venv\Scripts\python.exe` no lugar de `.venv/bin/python`. As pastas `tests/` e `independent_tests/` ficam no ZIP separado de evidências. Extraia-as ao lado de `app.py` para rodar a suíte. O conjunto abrange fórmulas analíticas, guardas de resistência, pipeline, exportação e estado da interface. Não substitui validação independente do projeto real. Alterar qualquer arquivo de cálculo muda sua assinatura e exige recalcular.

## Estrutura

- `app.py`: interface Streamlit.
- `monorail/`: entradas, adaptação de ações/resistência, figuras e Word.
- `lro_beams/`, `underslung_runway_candidate/`, `top_unstiffened_candidate/`: fontes legadas preservadas; nem todas as rotas desses pacotes são expostas pela monovia.
- `examples/`: entradas ilustrativas e memória demonstrativa, não dados de equipamento comercial.
- Regressões executáveis e relatório independente: ZIP separado de evidências, não necessários para operar o app.

A memória Word exige somente os pacotes Python acima. Não precisa de Microsoft Word ou LibreOffice instalados para ser gerada.
