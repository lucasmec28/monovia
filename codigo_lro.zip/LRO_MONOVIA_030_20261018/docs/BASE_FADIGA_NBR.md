# Base delimitada da fadiga nominal NBR com axial e torção

A análise usa as ações genuínas de fadiga da NBR 8400, caso I sem o coeficiente de majoração de grupo Mₓ e sem o coeficiente de flambagem ω. A flexão continua incluída. Casos ELU ou EN não são convertidos em fadiga pela troca de nome.

A NBR 8400-2:2019 corrigida 2022, seção 4, admite os procedimentos convencionais da resistência dos materiais para determinar tensões; a NBR 10084:2020, 9.1.2(b,c), requer considerar efeitos axiais e torção excêntrica. A recuperação elástica nominal N/My/Mz/B e Fy/Fz/Tsv/Tw é, portanto, uma etapa mecânica separada da equação resistente de fadiga. A mecânica de torção/empenamento tem apoio publicado no SCI P385, seção 2, e é testada independentemente no domínio de viga reta prismática e suas condições de contorno.

A combinação longitudinal local/global adotada é σN + σM + σB + 0,75σ0x. Somente a parcela local longitudinal recebe 0,75; a tensão local transversal entra integralmente. Essa expressão representa uma aplicação conjunta interpretativa da NBR 10084, 9.1.1–9.1.4, e da NBR 8400-2, seção 4, 5.6 e D.2.3. Não é transcrição literal de uma equação da NBR 10084 que escreva N e B, nem um novo fator independente de fadiga.

O consumidor mantém a Equação (D.5) e suas admissíveis específicas de fadiga. A seleção de grupo do componente, detalhe W0, domínio material e requisito de fabricação precisa ser declarada. A adoção κ=−1 é conservadora e explícita; não resulta de uma história temporal inventada. O fator 4/3 incorporado às admissíveis não é reaplicado.

Os intervalos assinados de todas as componentes são avaliados em cada ponto/plano nominal identificado. A maximização do polinômio de D.5 em uma caixa de intervalos é um limite suficiente dessa expressão, não uma nova equação normativa e não um estado físico concomitante. Um limite excedido exige análise adicional; não é testemunho de falha de fadiga ou previsão de vida.

Sob cortante lateral, a alma nominal pode ter uma componente fora do plano xz admitido pelo consumidor planar. Ela permanece pendente, com a componente mantida e explicitada. As mesas ou outros pontos calculáveis não são apagados. Tampouco a soma de quinze resultados parciais prova cobertura da seção inteira.

O modelo não fecha contato rolante, desgaste, concentrações reais de raiz, soldas, furos, entalhes, ligações, estabilidade, segunda ordem ou cobertura integral das ações físicas de um equipamento. Uma fonte escrita ou caixa marcada não autentica documentos nem dimensiona a ligação real. Os resultados são análises nominais parciais, não aprovação integral da monovia.
