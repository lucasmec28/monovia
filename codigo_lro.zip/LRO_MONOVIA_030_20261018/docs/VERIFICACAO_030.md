# Verificação da integração 0.3

## Escopo e conjuntos distintos

A integração de fadiga NBR recebeu 1.278 testes independentes de entradas, premissas e importação física, além de 46 testes independentes de orquestração, interface e exportação. Esses 1.324 testes são adicionais à auditoria EN/base descrita em `VERIFICACAO_020.md`; repetições da mesma suíte não devem ser somadas como testes novos.

Três regressões independentes adicionais verificaram o isolamento dos metadados entre casos e resultados das rotas inicial e EN, incluindo assinatura, importação, Word e recálculo da interface após mutação. As seis exportações NBR foram recalculadas e reinspecionadas após a alteração da identidade do código; somente horários e hashes mudaram.

A implementação também recebeu 91 testes próprios de modelo/orquestração, 42 de interface e 12 de relatório. Estes não são chamados de auditoria independente. As rodadas de figuras e Word usaram cálculos reais, incluindo cenários com limites excedidos, premissas ausentes e todos os casos sem cálculo.

Os testes portáteis e relatórios independentes ficam no pacote opcional de evidências, fora do runtime. A auditoria verifica códigos congelados e usa seus próprios oráculos e asserções. A seleção de 413 testes EN e a regressão de 126 testes da rota inicial permitem repetir o confronto das três páginas em uma distribuição limpa.

## O que foi conferido na nova rota

- Ações genuínas FAT8400, estados carregado/vazio, massas retidas, sentidos e preservação de todos os casos.
- Momento do trem móvel por solução fechada, equilíbrio físico, reações opostas, transportes de força e sinais de torque/bimomento.
- Deslocamento nos contatos distinto do centroide e manutenção da componente não planar da alma.
- Equação (D.5) nos vértices assinados e capacidade confrontada com a tabela-fonte, sem criar uma nova resistência.
- Independência de campos antigos, ausência de conversão EN, ausência de majoração de grupo Mₓ na fadiga e ausência de novos apoios por travamentos.
- JSON estrito, inclusive subfluxo lexical, números não finitos, Unicode inválido, campos duplicados e profundidade excessiva.
- Recibos independentes entre si; edição de entrada, alteração do resultado ou mudança do código impedem exportar como cálculo atual.
- Interface executada pelo Streamlit AppTest, com cálculo, diagrama, entrada/evidência/Word e invalidação real.
- Documentos efetivamente renderizados. A revisão visual de Word não equivale a inspeção visual em navegador.

## Estado e interpretação

O exemplo vertical preenche quinze planos nominais. No exemplo combinado, quatorze limites suficientes são atendidos e a alma permanece pendente pela componente fora do plano disponível. Nenhuma dessas contagens aprova a seção inteira, a instalação, o equipamento ou a cobertura completa de suas ações.

O exemplo de carga alta produz majorantes excedidos, sem inventar falha física de fadiga. Quando falta o vínculo axial, os casos são preservados como não calculados. Faltando fontes ou premissas de fadiga, a resposta mecânica pode existir sem uma capacidade resistente assumida.

Convergência numérica é evidência de engenharia, não prova formal de envoltória contínua. Contato, raiz real, ligações, estabilidade, segunda ordem e vida em ciclos continuam fora do fechamento desta página.
