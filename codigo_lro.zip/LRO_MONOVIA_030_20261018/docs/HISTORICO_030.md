# Histórico da entrega 0.3

## Versão principal para uso e avaliação

A entrega 0.3 reúne as três páginas descritas no guia rápido. Os marcos 0.1 e 0.2.1 foram preservados para comparação técnica, mas não são os pacotes recomendados para iniciar um novo trabalho. Não há publicação online automática.

## Acrescentado

- Página própria de fadiga nominal NBR com recuperação elástica de axial, flexão, torção e empenamento, casos FAT8400 completos, planos identificados e limites explícitos.
- Entradas, fontes, grupo do componente, detalhe W0, requisito de fabricação e adoção conservadora independentes, sem importar aprovações da página original.
- Exemplos sintéticos favoráveis no domínio nominal, com cortante lateral, com axial, com majorantes excedidos e com cálculos/premissas ausentes.
- Word e JSON exportáveis mesmo com pendências ou falta de cálculo, sem esforços fictícios.
- Guia curto para escolher a página pela base de projeto e pelo mecanismo, não pelo resultado mais favorável.

## Correções de integração

- As importações físicas da página inicial e da nova página de fadiga recebem uma validação lexical estrita antes do construtor preservado. Tokens não nulos que seriam convertidos em zero por subfluxo, valores não finitos, campos duplicados, texto inválido e estruturas excessivamente profundas são recusados de forma controlada. A reprodução incluía `operating_payload_t: 1e-9999`.
- A correção acima pertence à camada de importação do aplicativo de monovia. Não é um defeito identificado ou um hotfix das rotinas originais de viga de rolamento.
- Metadados de limitações e interpretação são independentes entre recibos NBR e EN. Na página inicial, o dicionário de convenções é copiado por caso. Alterar um resultado em memória não modifica constantes, outro caso ou o texto de um cálculo posterior.
- Os recibos das três páginas foram recalculados após esses ajustes de identidade do código, sem reaproveitar uma assinatura antiga. Os resultados numéricos usuais e as equações não foram alterados. O cache da interface é restrito a figuras em bytes; resultados de cálculo não são compartilhados por esse cache.
- Desenhos do complemento EN e da nova fadiga NBR mantêm cotas legíveis em seções muito largas e finas, sem limitar ou alterar silenciosamente as dimensões importadas.

## Preservado

Os 220 arquivos legados da fonte de 17/10/2026 permanecem idênticos ao manifesto original. As equações resistentes e os solvers preservados não foram reescritos para estes ajustes. As páginas mantêm bases NBR e EN separadas; um resultado não transforma a outra em aprovação.

As auditorias identificam hashes e casos efetivamente executados. Os relatórios dos marcos anteriores descrevem seus próprios conjuntos e datas; a auditoria específica da 0.3 e este histórico acrescentam as correções posteriores.
