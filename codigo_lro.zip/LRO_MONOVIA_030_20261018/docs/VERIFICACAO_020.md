# Verificação da entrega 0.2

## O que foi confrontado

- Flexão biapoiada e trem móvel com equilíbrio, funções de Green e máximos fechados independentes.
- Torção não uniforme com fórmulas fechadas e solução independente de equação diferencial por trechos, em alta precisão. Foram conferidos sinais, J/Cw, saltos, parcelas de Saint-Venant/empenamento e deslocamentos nos contatos inferiores.
- Ações EN próprias, por origem e grupo: dinâmica, coeficientes, ensaios, peso móvel versus fixo, carga retida e duas verificações distintas de flecha.
- Seção, estabilidade, mesa inferior e serviço com guardas de domínio, forças por roda, coeficientes e resultados nominais assinados. Um majorante excedido não é convertido em falha física testemunhada.
- Entradas JSON estritas, integridade de recibos, erros numéricos registrados, propagação da falta de cálculo aos mecanismos afetados e exportação mesmo com critérios não atendidos.
- Interface pelo AppTest do Streamlit: edição, importação válida/inválida, cálculo real, inspeção, exportação e invalidação do resultado ao editar.
- Word efetivamente renderizado e inspecionado visualmente. Não se confunde esse exame com uma inspeção visual da interface em navegador, que não foi concluída neste ambiente.

## Contagens sem dupla contagem

A seleção portátil de **413 testes independentes** cobre os módulos EN distribuídos no runtime. Foi executada também na pasta de distribuição limpa, antes da compactação. A regressão da rota NBR preservada teve **126 testes independentes aprovados** nessa mesma distribuição.

A bateria de pesquisa técnica mais ampla contém **834 testes independentes** de módulos/entradas, incluindo protótipos de extremidades, prolongamentos e fadiga nominal ampliada. A seleção isolada de 421 testes também foi repetida a partir das cópias do pacote de evidências, sem depender das pastas de desenvolvimento. Os 413 testes acima são uma seleção dessa bateria, não um conjunto a somar novamente. Os protótipos não são funcionalidades automaticamente liberadas pela interface EN.

Os ensaios posteriores do orquestrador, página e Word têm relatórios e logs próprios no ZIP de evidências. Asserções de testes, verificações de um cálculo e casos de ações são grandezas diferentes. Por exemplo, as muitas verificações de faces/seções do exemplo preenchido não são milhares de testes independentes.

## Limites da evidência

A busca da translação emprega convergência numérica de engenharia, não uma prova matemática de envoltória contínua. Os testes não certificam a instalação, a autenticidade de dados de fabricante/material, o modelo de ligação, o Anexo Nacional ou a ausência universal de defeitos. Os mecanismos e hipóteses não fechados permanecem visíveis no programa e no relatório.

O código legado foi preservado conforme `LEGACY_SOURCE_MANIFEST.json`. As identidades do código e dos documentos finais são registradas nos manifestos da entrega. As fontes normativas integrais não são redistribuídas.
