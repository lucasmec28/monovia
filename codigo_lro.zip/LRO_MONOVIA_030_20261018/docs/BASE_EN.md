# Bases do complemento EN

## Edições efetivamente adotadas

- EN 1991-3:2006 com AC:2012, ações de talhas e pontes. A edição 2026 existe, mas não é declarada como a edição implementada.
- EN 1990:2002 com A1:2005, princípios e combinações utilizados na rota delimitada.
- EN 1993-6:2007 com AC:2009, estruturas de suporte, mesa inferior e serviço.
- EN 1993-1-1:2022, adotada através da publicação DIN EN 1993-1-1:2025-04, para o núcleo de seção e Anexo C.2 preservado.

São edições declaradas para revisão técnica, não uma escolha automática da norma legalmente aplicável ou de um Anexo Nacional. Não se incluíram PDFs integrais de normas no pacote.

## Ações

EN 1991-3 §2.2.1–2.2.2 e §2.5.1 tratam a monovia fixa e classificam talha/trole `Qc` como ação variável móvel. G da viga e outros pesos distribuídos fixos permanecem separados. Cada grupo correlacionado recebe um único coeficiente variável; não se escolhem fatores favoráveis independentemente para cada componente.

Içamento usa `φ1 Qc + φ2 Qh`, incluindo os extremos de `φ1`. HC1–HC4 e velocidade real determinam `φ2`. Translação usa `φ4` com base explícita, respeitando a condição de classe 1 corrigida por AC:2012 quando aplicável. O fallback longitudinal é 5% da máxima carga vertical estática de roda, sem dinâmica. Não define força transversal nem simultaneidade com conjuntos de fabricante.

O valor recomendado `γQ=1,35` é empregado no ramo desfavorável STR. A talha presente favorável usa 1,00; ausência física é situação explicitamente declarada, não fator zero escolhido por conveniência. Ensaio usa o grupo G8 inteiro com `γF,test=1,1`, segundo a leitura conjunta EN 1991-3 §2.2.2(6)/Anexo A.1(3) e EN 1993-6 §2.8; G fixo conserva seu coeficiente próprio. Não se aplica 1,35 × 1,1 nem se amplifica somente QT.

O gerador conserva obrigações de dados, qualificação mecânica e cobertura externa como categorias separadas. Um subconjunto vertical incompleto não pode fechar o grupo de translação. Ele pode permanecer como referência diagnóstica, mas o resumo das variantes completas não o mistura com as variantes integralmente fornecidas.

## Mecânica e estabilidade

As equações analíticas de flexão e torção não uniforme de Vlasov, recuperação setorial e busca de raízes são reutilizadas. O modelo é de um vão, garfos extremos e empenamento livre. As rodas físicas inferiores mantêm forças, torques e momentos de transporte. Forças longitudinais precisam do vínculo axial declarado; não são eliminadas por falta de uma rota de apoio.

Os eixos de apresentação são físicos `(s,y,z)`, com z para cima e regra da mão direita. N é positivo em tração. My é a flexão forte, Mz a fraca. Reações do apoio sobre a viga e ações da viga sobre a estrutura receptora são opostas. A conversão dos sinais internos legados é explícita e testada.

J e Cw são escolhidos no modelo canônico antes da solução. Não se reescala um bimomento já calculado. As posições espaciais críticas vêm das raízes analíticas preservadas; a translação usa refinamento aninhado com duas comparações estáveis. É evidência de convergência numérica de engenharia, não certificação de um majorante contínuo.

Anexo C.2 e seção nominal são avaliações distintas, com `γM1` e `γM0` separados. Classe, primeira ordem axial, bimomento e trabalho radial das forças nos contatos têm guardas próprias. Compressão com biflexão de diagramas arbitrários não recebe uma qualificação implícita do fator Cm. Comprimento integral L e ausência de crédito da altura inferior são conservados; detalhes reais dos garfos e vínculos não são dimensionados.

A recuperação global de cisalhamento é um limite de tensões nominais, não uma nova resistência normativa. O programa distingue ultrapassar esse limite conservador de um estado físico nominal que testemunha uma falha.

## Mesa inferior e serviço

EN 1993-6 §5.8 fornece os pontos nominais da mesa de abas paralelas em região interior. O programa preserva o sinal por face/lado. Superposição de rodas próximas é tratada como limite conservador; um limite somado não é chamado de tensor físico concomitante na raiz ou no contato.

No ELU, §6.7/Eq.6.2–6.4/Tabela6.2(b) é usado somente no ramo remoto qualificado, com desigualdade estrita para a distância de extremidade. Uma roda longitudinal isolada usa o limite saturado do comprimento efetivo, sem inserir uma roda fictícia.

A tensão de flexão global publicada é avaliada separadamente. A composição adicional N/M/B, quando altera o resultado, é um complemento conservador de engenharia identificado e não uma prescrição literal da Eq.6.2. A menor capacidade evita aumento por cancelamento; isso não prova, sozinho, toda interação normativa. O relatório não declara fechamento integral do contato ou da concordância laminada.

EN 1993-6 §7.5 usa a combinação característica relevante ou de ensaio, com `γM,ser` recomendado. As tensões locais completas se somam às globais, preservando sinais; não se transporta o fator NBR 0,75. São verificadas componentes individuais e equivalentes nos pontos nominais e o limite global da seção.

EN 1993-6 §7.3/Tabela7.2 recomenda duas verificações distintas sem dinâmica: carga útil nominal isolada em monovia, `L/500`; total vertical, sem contraflecha adotada, `min(L/600,25 mm)`. Os apoios são rígidos e a flecha é relativa a eles. Não foi inventado um limite de giro dos contatos.

## Fontes públicas de apoio

- EN 1993-6 integral consultada: https://www.phd.eng.br/wp-content/uploads/2015/12/en.1993.6.2007.pdf
- Amostra editorial DIN/EN para o núcleo C.2: https://application.wiley-vch.de/books/sample/3433034680_c01.pdf
- SCI P360, referência elástica de estabilidade: https://www.steelconstruction.info/images/0/0e/Sci_p360.pdf
- NCCI SN003b, referência de momento crítico: https://steelconstruction.info/upload/Wiki-Files/0/0f/SN003b.pdf
- FAQ oficial CMAA sobre limites de escopo: https://og.mhi.org/downloads/industrygroups/cmaa/faqs/most-asked-action-alerts.pdf

O registro de fontes de ações, cláusulas e coeficientes acompanha o JSON gerado. Dados de fabricante/material são declarações de entrada; seu preenchimento não comprova a autenticidade ou aplicabilidade do documento real.
