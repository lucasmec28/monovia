# Base normativa e mecânica da versão 0.1

Referências verificadas em 18/10/2026. Este documento identifica o método e o domínio da implementação, não substitui os textos normativos nem constitui liberação do projeto.

## Escopo da monovia

A viga fixa que recebe a talha/trole é a monovia/estrutura-suporte, não a viga móvel de uma ponte rolante. A CMAA 70 trata pontes de múltiplas vigas. A CMAA 74 não abrange integralmente monovias; a FAQ oficial reconhece somente a correlação da interface talha/trole–viga quando igual e exclui estruturas-suporte do escopo de 70/74. [FAQ oficial CMAA, pp. 6–7](https://og.mhi.org/downloads/industrygroups/cmaa/faqs/most-asked-action-alerts.pdf).

Por isso, o aplicativo não emite declaração de conformidade integral CMAA 70/74. A execução desta versão usa **ABNT NBR 10084/8400**, com complemento NBR 8800 nomeado e separado. Não é uma combinação automática de todas as normas disponíveis.

## Aplicação por mecanismo

| Mecanismo | Referência | Uso e limite da implementação |
|---|---|---|
| Classificação | NBR 10084:2020 §5; NBR 8400-1:2019 §6.1 | Grupo do equipamento A e do componente E, classes HC/HD e referências CMAA/EN são independentes. Não se deduzem da capacidade nominal. |
| Posição do trem | NBR 10084 §§6.1.2–6.1.5 | Busca longitudinal da posição desfavorável; um equipamento. Cada eixo representa duas rodas simétricas apenas pela hipótese adotada. Não se transfere simultaneidade de várias talhas para esta versão. |
| Dinâmica | NBR 10084 §6.2.2; NBR 8400-1 §6.2.2 | Ψ incide sobre a parcela suspensa de serviço. Peso da estrutura e peso da talha/trole são parcelas distintas; impacto não é aplicado duas vezes. |
| Casos de carga | NBR 10084 §§6.3, 7 e 8; NBR 8400-1 §§6.2.3 e 6.3 | Caso normal I e caso próprio de fadiga. Ações horizontais nos contatos são entradas fundamentadas pelo responsável, não um skewing de ponte transplantado automaticamente. Eventos especiais não estão cobertos. |
| Bases de segurança | NBR 10084 §9.1.1 | NBR 8400-2 é a base principal; NBR 8800 é complemento nos casos identificados. Solicitações ELU não são comparadas silenciosamente com admissíveis de outra base. |
| Tensões globais | NBR 8400-2:2019, corrigida 2022, §5.2.1 | Resistências admissíveis normativas. Recuperação **mecânica** nominal por equilíbrio/Jourawski em três retângulos, usando o núcleo existente; majorante de cisalhamento vetorial. Esse campo não é nova resistência normativa nem solução dos picos reais de raiz/contato. |
| Resistência global suplementar | NBR 8800:2024, Errata 1:2025, §§5.4–5.5 e Anexo D | Rotas compactas de flexão/cisalhamento/FLT. Os demais ramos não viram aprovação implícita. |
| Nível inferior da carga e FLT | NBR 8800 §5.4.2.3 | Carga gravitacional abaixo da semialtura pode ser tratada conservadoramente como aplicada na semialtura. Adota-se Cb=1, sem estabilização adicional da carga pendurada. A hipótese não cria contenção lateral inexistente. |
| Garfos e comprimentos | NBR 8800 §§5.4.1.1–5.4.1.2 e 5.4.2.3–5.4.2.5 | O plano nominal identifica duas restrições laterais independentes em alturas distintas na mesma coordenada longitudinal. Não fornece rigidez/resistência da ligação nem altera o solver de resposta. |
| Torção real | NBR 10084 §9.1.2(c); NBR 8800 §5.5.2.3 | O torque de uma força lateral abaixo do centro de cisalhamento é preservado. Resposta Vlasov diagnóstica, garfos extremos/empenamento livre. A interação N+M de §5.5.1.1, sem torção, não é estendida automaticamente; escoamento sozinho não fecha instabilidade. |
| Mesa inferior interior | NBR 10084 §9.1.4, Tabela 2 e Figuras 6–7 | Abas paralelas, três pontos 0/1/2, duas faces e dois lados. Distância à extremidade física **maior que bf**. Rodas individuais separadas por pelo menos 1,5bf; grupos mais próximos recebem a superposição conservadora prevista, sem redução favorável. |
| Combinação local/global | NBR 10084 §9.1.4; NBR 8400-2 §5.2.1.1–3 | Parcela longitudinal local multiplicada por 0,75; transversal não recebe esse fator. São avaliados os limites normal/cortante/equivalente, com sinais e faces preservados. Caixas conservadoras são distintas de um estado físico concomitante. |
| Fadiga | NBR 8400-2 §5.6 e Anexo D | Grupo do componente, material e detalhe explícitos. Rota W0 sem entalhe, fabricação laminada e κ=−1 adotados. Fadiga usa caso I sem **coeficiente de amplificação Mₓ do grupo A**, não sem momento fletor. |
| Flecha | NBR 10084 §10, Tabela 4(c) | Limite L/500 para monovia de talha sob **somente carga nominal útil**, sem peso próprio, equipamento, massa retida, dinâmica ou ELU. Flecha total de operação é exibida separadamente. |
| Apoios e introdução de reação | NBR 8800 §§5.7 e 6; NBR 10084 §9.1.1 | Reações físicas concomitantes são fornecidas, mas não dimensionam o apoio. §5.7, para forças centradas na alma, não substitui a flexão da aba por rodas no balanço da mesa inferior. |

## Distinções importantes

### Extremidade não é apoio por definição

O método interior usa distância à **ponta física da viga**, não automaticamente ao eixo do apoio. Nesta versão as pontas físicas e os apoios coincidem. Prolongamentos/balanços não são aceitos apenas como artifício para aumentar o afastamento: exigem também tratar sua resposta e peso próprio.

A NBR 10084 §9.1.4 contém regra própria de extremidade sem reforço e alternativa de reforço. A sua expressão transversal usa coeficiente 3,335, enquanto a expressão EN consultada usa 3,225. Não se troca um pelo outro. A versão 0.1 não interpola o trecho entre ponta e região interior; a região fora do método interior fica explicitamente pendente.

### Fadiga: extremo assinado de maior módulo

NBR 8400-2 §§5.6.3–5.6.4 define a tensão dominante pelo maior valor absoluto, preservando seu sinal para κ. Por exemplo, extremos −200 e +50 produzem κ=−0,25, não −4. O ramo opcional desta versão adota diretamente o envelope conservador κ=−1; não fabrica uma história temporal a partir de máximos independentes.

W0 corresponde ao material sem entalhe. Furos, soldas, detalhes K0–K4 ou outras categorias exigem seus procedimentos próprios. Uma seção ser laminada não basta, por si só, para qualificar todo detalhe como W0.

### Abas cônicas

As expressões publicadas consultadas da NBR 10084 apresentam uma inconsistência na parcela cx2 de aba cônica em relação ao valor alternativo tabelado. Não há correção silenciosa na aplicação: o domínio desta versão é de abas paralelas.

## Referências complementares, sem aplicação automática

- EN 1993-6:2007+AC:2009: §§5.8, 6.7, 7.5 e 9.3.4 tratam rodas inferiores e sua resposta local; §6.3.2.2(3) limita o crédito de nível estabilizante inferior. [Exemplar consultado](https://www.phd.eng.br/wp-content/uploads/2015/12/en.1993.6.2007.pdf).
- SCI P385 (2011), *Design of steel beams in torsion*, §§2.1–2.2 e Apêndice B: referência da recuperação torsional nominal preservada. Não remove exigências de instabilidade nem concentrações locais.
- ASME B30.17 inclui monovias e seus suportes, no contexto de segurança, instalação, inspeção, ensaio e operação; o seu escopo não é um cálculo integral automaticamente executado aqui. [Página oficial](https://www.asme.org/codes-standards/find-codes-standards/b30-17-cranes-monorails).
- MMA MH27.1 é específica de *patented track*; MH27.2 de pista fechada. Não se apresenta uma viga I/W convencional como integralmente coberta. [MMA oficial](https://og.mhi.org/mma).

Os PDFs integrais das normas não são redistribuídos no pacote. O responsável deve consultar as edições aplicáveis e eventuais requisitos contratuais/nacionais.
