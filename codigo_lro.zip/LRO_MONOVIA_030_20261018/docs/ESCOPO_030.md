# Mapa da versão 0.3: fadiga nominal NBR ampliada

A página NBR original e o complemento EN mantêm seus próprios domínios, descritos em `GUIA_ROTA_NBR_010.md` e `ESCOPO_020.md`. A nova página não altera nem funde as bases resistentes. Ela acrescenta uma avaliação nominal de fadiga por aplicação conjunta NBR 10084/8400, com recuperação elástica de axial, flexão, torção e empenamento.

| Etapa | Implementado | Limite importante |
|---|---|---|
| Entradas físicas | Um vão reto, seção I laminada duplamente simétrica de abas paralelas, um equipamento e pares inferiores opostos | Não há curva, desvio, múltiplos vãos, rodas em balanço ou talhas múltiplas |
| Ações de fadiga | Todos os casos FAT8400 regenerados, carregado/vazio, sentidos e massas retidas | Não são ações ELU/EN renomeadas; cobertura de eventos reais depende dos dados do equipamento |
| Resposta mecânica | N, My, Mz, Fy, Fz, Tsv, Tw e B, com sinais, contato e reações físicas | Garfos extremos, empenamento livre e primeira ordem; ligações reais não são dimensionadas |
| Força longitudinal | Modelo axial explícito, restrição esquerda no centro de cisalhamento, direita livre e forças iguais no par | Sem essa idealização, os casos afetados ficam não calculados; não se apaga a força |
| Busca móvel | Pontos críticos espaciais e refinamento aninhado da posição do trole | Convergência numérica de engenharia, não prova matemática da envoltória contínua |
| Tensões nominais globais | Recuperação elástica dos oito componentes em paredes/planos identificados | Não representa concentrações reais de contato, raiz, ligação ou entalhe |
| Tensões locais inferiores | Pontos/faces publicados NBR 10084, no domínio interior com afastamentos e espaçamento compatíveis | Não interpola ponta/transição; os planos globais calculáveis permanecem disponíveis quando o local não é fechado |
| Combinação nominal | σN+σM+σB+0,75σ0x e parcela transversal local integral | Interpretação conjunta identificada, não transcrição literal de uma fórmula completa N/M/B da NBR 10084 |
| Fadiga | Equação (D.5), admissíveis e guardas materiais preservadas; grupo E1–E8, detalhe W0 e κ=−1 declarados | Não inventa equivalente CMAA/EN, história temporal, dano de Miner ou ciclos até falha |
| Limite por plano | Caixa de componentes assinadas, avaliada pelo consumidor nominal herdado | Majorante excedido não demonstra falha concomitante; resultados de planos não somam aprovação integral |
| Alma com cortante lateral | Componente fora do plano mantida e pendência localizada | Mesas calculáveis não são apagadas; não há fechamento 3D improvisado para a alma |
| JSON, Word e diagramas | Entradas estritas, recibos vinculados ao código/entrada, exportação de cálculos parciais e não calculados | Editar entrada/código invalida o recibo; importação não transfere aprovação |

## Exemplos sintéticos

- Vertical: dois estados, quinze planos nominais verificáveis.
- Horizontal: quatro casos, com torção/empenamento; a alma fica pendente quando há componente não planar.
- Axial e horizontal: oito casos e vínculo axial declarado, mantendo N/B/T.
- Majorante excedido: carga deliberadamente alta; demonstra a diferença entre limite suficiente excedido e falha física comprovada.
- Vínculo axial ausente: casos preservados com cálculo ausente e exportação do motivo.
- Dados de fadiga ausentes: resposta mecânica calculável e premissas resistentes pendentes, sem capacidade inventada.

Os números de casos podem mudar quando as entradas mudarem. Os exemplos não representam fabricante, material certificado, inspeção executada ou projeto real.

## Não fechado pela página de fadiga

Resistência estática NBR com torção; estabilidade e segunda ordem; contato rolante e desgaste; concentrações reais de raiz; soldas, furos, entalhes, anexos e regiões perturbadas; ligações e suportes reais; vida em ciclos; eventos completos de um equipamento. Os planos nominais não substituem essas verificações.

A fronteira fy/fu=0,70 permanece pendente na camada de integração. Acima dela, o ramo material exige adoção e fonte explícitas. O catálogo e o grau declarado não comprovam essas premissas.

## Evidência

A mecânica, os sinais e a recuperação nominal foram confrontados com soluções fechadas e integração independente antes da integração da página. Modelo, orquestração, interface e Word têm baterias próprias e auditoria independente identificadas no pacote de evidências. A aprovação de testes é evidência do domínio efetivamente executado, não certificação ou ausência universal de defeitos.
