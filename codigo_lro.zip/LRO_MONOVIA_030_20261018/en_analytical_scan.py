"""EN physical-action adapter to preserved analytical monorail mechanics.

No EN case is reconstructed from an NBR Case or its factors. The owned EN
receipt is regenerated, and its already factored physical contact forces are
transported once. The mechanical geometry carrier is shared with the baseline;
its NBR classifications, masses and station force values are NOT used here.
"""
from dataclasses import asdict, replace
from hashlib import sha256
from pathlib import Path
import math

from monorail.analysis import digest
from monorail.model import MonorailProject
from lro_beams.geometry import section_properties
from lro_beams.moving_beam import BeamModel,MovingWheel,UniformLoad,translate_train,solve_position
from lro_beams.beam_torsion import VlasovBeam,LateralTorqueLoad,solve_lateral_torsion,thin_wall_i_torsion_properties
from lro_beams.autonomous_response import ConcurrentResponse,CaseFactors
from analytical_scan import AxialTransfer,Controls,_scan_factory,assert_scan_current


def _owned_case(action_input,action_receipt,case_id,case_snapshot=None):
    from en_actions import assert_case_receipt,ENActionInput,ENActionReceipt
    if type(action_input) is not ENActionInput or type(action_receipt) is not ENActionReceipt:
        raise ValueError('Typed owned EN input and regenerated EN receipt required; imported results cannot authorize mechanics')
    return assert_case_receipt(action_input,action_receipt,case_id,case_snapshot=case_snapshot)


def _source_identity(action_input,action_receipt,case_id):
    case=_owned_case(action_input,action_receipt,case_id)
    return dict(adapter_sha256=sha256(Path(__file__).read_bytes()).hexdigest(),
        action_input_signature=action_input.signature(),
        action_receipt_signature=action_receipt.signature(),
        action_generator_fingerprint=action_receipt.generator_fingerprint,
        case_id=case.id,case_signature=case.signature())


def _binding(action_input,action_receipt,case):
    return dict(kind='ENActionCase',input_signature=action_input.signature(),
        receipt_signature=action_receipt.signature(),case_id=case.id,
        case_signature=case.signature(),case_snapshot=asdict(case))


def _validate_geometry(project,action_input,case,axial_transfer):
    if not isinstance(project,MonorailProject):raise ValueError('Typed mechanical geometry carrier required')
    project.validate();action_input.validate()
    if project.section.fabrication!='rolled' or not project.section.doubly_symmetric:
        raise ValueError('Initial analytical EN adapter: symmetric rolled parallel I section')
    if not project.end_forks_confirmed:raise ValueError('Actual end-fork model must be explicit')
    if (project.span_m,project.travel_min_m,project.travel_max_m)!=(action_input.span_m,action_input.travel_min_m,action_input.travel_max_m):
        raise ValueError('Mechanical span/travel differs from the EN action geometry')
    stations={s.offset_m:s for s in project.stations}
    pairs={offset:[] for offset in stations}
    for wheel in case.wheel_loads:
        if wheel.offset_m not in pairs:raise ValueError('EN wheel offset differs from mechanical station geometry')
        pairs[wheel.offset_m].append(wheel)
    if any(len(pair)!=2 for pair in pairs.values()):
        raise ValueError('Initial adapter requires exactly two opposed physical contacts at every station')
    s=project.section;y=(s.bf_mm/2-project.edge_to_contact_mm)/1000;z=(s.tf_mm-s.d_mm/2)/1000
    has_axial=False
    for offset,pair in pairs.items():
        left,right=sorted(pair,key=lambda w:w.y_m)
        if not (math.isclose(left.y_m,-y,rel_tol=0,abs_tol=1e-12) and math.isclose(right.y_m,y,rel_tol=0,abs_tol=1e-12)
                and math.isclose(left.z_m,z,rel_tol=0,abs_tol=1e-12) and math.isclose(right.z_m,z,rel_tol=0,abs_tol=1e-12)):
            raise ValueError('EN contacts must lie at the declared opposed lower-flange contact geometry')
        if left.fz_kn>0 or right.fz_kn>0:raise ValueError('Initial adapter excludes uplift at wheel contacts')
        if not math.isclose(left.fz_kn,right.fz_kn,rel_tol=0,abs_tol=1e-12):
            raise ValueError('Unequal opposed vertical wheel actions require a separate local/stability adapter; not averaged')
        if not math.isclose(left.fs_kn,right.fs_kn,rel_tol=0,abs_tol=1e-12):
            raise ValueError('Unequal opposed longitudinal forces create minor/sectorial couples; not discarded')
        has_axial=has_axial or left.fs_kn!=0 or right.fs_kn!=0
    if axial_transfer is not None:
        if not isinstance(axial_transfer,AxialTransfer):raise ValueError('Typed AxialTransfer required')
        axial_transfer.validate()
    if has_axial and axial_transfer is None:
        raise ValueError('EN Hlong requires explicit opposed allocation and left shear-centre axial restraint')
    return stations,pairs


def response_factory(project,action_input,action_receipt,case_id,axial_transfer=None):
    """Return a genuine same-case lower-contact response factory and full ledger."""
    case=_owned_case(action_input,action_receipt,case_id)
    stations,pairs=_validate_geometry(project,action_input,case,axial_transfer)
    s=project.section;m=project.material
    tp=thin_wall_i_torsion_properties(s.d_mm,s.bf_mm,s.tf_mm,s.tw_mm)
    g=replace(section_properties(s),J_mm4=tp['J_mm4'],Cw_mm6=tp['Cw_mm6'])
    beam=BeamModel(project.span_m,m.E_mpa,g.Ix_mm4,g.Iy_mm4)
    vb=VlasovBeam(project.span_m*1000,m.E_mpa,m.G_mpa,g.J_mm4,g.Cw_mm6)
    z_mm=s.tf_mm-s.d_mm/2
    train=[];pair_ledger=[];torques={}
    for offset,pair in sorted(pairs.items()):
        station=stations[offset]
        pv=-math.fsum(w.fz_kn for w in pair);hy=math.fsum(w.fy_kn for w in pair);hx=math.fsum(w.fs_kn for w in pair)
        my=math.fsum(w.z_m*w.fs_kn for w in pair)
        mz=-math.fsum(w.y_m*w.fs_kn for w in pair)
        physical_torque=math.fsum(w.y_m*w.fz_kn-w.z_m*w.fy_kn for w in pair)
        # Enforced equal axial contacts make the sectorial couple cancel.
        # The complete physical wheel ledger is retained for the radial guard.
        if abs(mz)>1e-10:raise ValueError('Uncancelled minor couple outside the opposed-contact adapter')
        train.append(MovingWheel(offset,pv,hy,station.id,hx,my,0.))
        torques[station.id]=-physical_torque*1e6
        pair_ledger.append(dict(station_id=station.id,offset_m=offset,
            physical_wheel_ids=[w.wheel_id for w in pair],pair_vertical_kn=pv,
            individual_wheel_kn=-pair[0].fz_kn,pair_longitudinal_kn=hx,pair_transverse_kn=hy,
            physical_major_couple_knm=my,physical_minor_couple_knm=mz,
            physical_torque_knm=physical_torque,green_torque_knm=-physical_torque,
            sectorial_couple_cancels_by_equal_opposed_axial_actions=True,
            per_contact_vertical_equal=True))
    udl=UniformLoad(math.fsum(q.downward_kn_per_m for q in case.fixed_loads))
    # These unit factors are metadata ONLY. EN forces above are already final.
    factors=CaseFactors(case.id,1.,1.,1.,1.,1.,
        'ENActionCase regenerated physical final loads; unit metadata factors, not a second action combination',extra_dead=1.)
    def factory(a):
        if not project.travel_min_m<=a<=project.travel_max_m:raise ValueError('Translation outside physical travel')
        loads=translate_train(beam,tuple(train),a)
        vertical=solve_position(beam,loads,udl)
        lateral=solve_lateral_torsion(vb,g.Iy_mm4,tuple(LateralTorqueLoad(w.position_m*1000,w.horizontal_kn*1000,torques[w.name],w.name) for w in loads))
        return ConcurrentResponse(case.id,a,1,1,vertical,lateral,g,factors,z_mm,
            longitudinal_transfer_basis=('EN final equal longitudinal pairs; Hs*z retained; Mz and applied B cancel. Explicit axial restraint at left shear centre, right axially free.' if axial_transfer else 'EN case has Hs=0; no longitudinal action omitted.'))
    metadata=dict(action_binding=_binding(action_input,action_receipt,case),
        original_case_ledger=asdict(case),wheel_ledger=pair_ledger,
        physical_wheel_loads=[asdict(w) for w in case.wheel_loads],
        fixed_loads=[asdict(q) for q in case.fixed_loads],uniform_load=asdict(udl),properties=asdict(g),
        contact_height_mm=z_mm,axial_transfer=None if axial_transfer is None else asdict(axial_transfer),
        initial_action_generator_eligibility=case.initial_scanner_eligible,
        action_generator_pending=list(case.pending),
        mechanical_geometry_role='Shared geometry/material/travel carrier only; NBR classification, input masses and station force values are not action sources in this EN route.',
        torque_properties_source='Preserved canonical flange-sectorial J/Cw chosen before solving',
        loads_already_factored=True,additional_load_factors_applied=False)
    return factory,metadata


def scan_case(project,action_input,action_receipt,case_id,controls=Controls(),progress=None,axial_transfer=None):
    factory,metadata=response_factory(project,action_input,action_receipt,case_id,axial_transfer)
    case=_owned_case(action_input,action_receipt,case_id)
    guard=lambda:_source_identity(action_input,action_receipt,case_id)
    result=_scan_factory(project,case,factory,metadata,controls,progress,source_guard=guard)
    result['action_binding']=metadata['action_binding']
    result['producer']='EN physical-action analytical monorail adapter'
    result['result_signature']=digest({k:v for k,v in result.items() if k!='result_signature'})
    return result


def assert_en_scan_current(project,action_input,action_receipt,case_id,scan):
    case=_owned_case(action_input,action_receipt,case_id)
    guard=lambda:_source_identity(action_input,action_receipt,case_id)
    assert_scan_current(project,scan,case,source_guard=guard)
    expected=_binding(action_input,action_receipt,case)
    if scan.get('action_binding')!=expected or scan['metadata'].get('action_binding')!=expected:
        raise ValueError('Mechanical result not bound to this genuine regenerated EN case')
    raw=scan['metadata'].get('axial_transfer')
    axial_transfer=None if raw is None else AxialTransfer(**raw)
    _,metadata=response_factory(project,action_input,action_receipt,case_id,axial_transfer)
    if metadata!=scan['metadata']:raise ValueError('EN physical load mapping changed after calculation')
    return scan
