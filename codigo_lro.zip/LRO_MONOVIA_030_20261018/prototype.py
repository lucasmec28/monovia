"""Isolated torsion integration audit. Does not modify or extend the stable app.

All actions/response/resistance equations remain in preserved LRO kernels.
This file contains units/convention adapters and explicit physical-input wiring.
No computed result is a native-NBR or whole-design certification.
"""
from __future__ import annotations
from dataclasses import asdict, replace
from hashlib import sha256
from pathlib import Path
import math

from lro_beams.beam_torsion import VlasovBeam,TorsionSolution,PointTorque,PointBimoment
from underslung_runway_candidate.section_stress.recovery import (
    ISection,geometric_properties,section_properties,Resultants,recover_bottom_flange,combine_local)
from underslung_runway_candidate.autonomous_workflow.project import (
    AutonomousUnderslungProject,physical_wheel,top_suspension_point)
from underslung_runway_candidate.autonomous_workflow.model import physical_train_at
from underslung_runway_candidate.autonomous_workflow.cases import generate_normal_cases
from underslung_runway_candidate.autonomous_workflow.pipeline import analyze_cases,AnalysisControls

ROOT=Path(__file__).resolve().parents[1]
GRAVITY=9.80665


def _finite(v,name):
    if isinstance(v,bool) or not isinstance(v,(int,float)) or not math.isfinite(v):
        raise ValueError(name+' must be finite real')
    return float(v)


def canonical_section(project):
    """One geometric model for Green torsion, FE recovery and C.2 properties."""
    project.validate()
    s=project.section
    if not s.doubly_symmetric or s.fabrication!='rolled':
        raise ValueError('First torsion extension: straight doubly-symmetric rolled I only')
    return ISection(d_mm=s.d_mm,bf_mm=s.bf_mm,tf_mm=s.tf_mm,tw_mm=s.tw_mm,
        construction='rolled',bottom_root_radius_mm=s.root_radius_mm)


def canonical_green_beam(project):
    """Do not use lro_beams.geometry.Cw (which includes web Iy) in this route."""
    s=canonical_section(project);p=geometric_properties(s)
    return VlasovBeam(project.span_m*1000.,project.material.E_mpa,project.material.G_mpa,p['J_mm4'],p['Cw_mm6'])


def green_solution_from_physical_loads(project, physical_loads):
    """Right-hand physical generalized loads -> legacy opposite-twist solver.

    phi_RH=-theta_Green, so both torque and work-conjugate applied bimoment
    change sign. Loads already carry their intended factor ledger.
    """
    beam=canonical_green_beam(project)
    torques=tuple(PointTorque(load['x'],-load['Mx'],load.get('id','')) for load in physical_loads if load['Mx'])
    bimoments=tuple(PointBimoment(load['x'],-load['B'],load.get('id','')) for load in physical_loads if load['B'])
    return TorsionSolution(beam,torques,point_bimoments=bimoments)


def map_green_state_to_recovery(project, green_solution, bending_state, *,
        x_mm, cut_side, case_id, translation_mm):
    """Audited signed adapter; refuses inconsistent stiffness before using B.

    bending_state follows moving_beam: N tension+, Mx sagging, My lateral,
    dMx/dx=Vy. Forces in kN/m. Green torsion is evaluated internally at the
    exact same x/cut. Resultants/recovery remain N/mm/MPa with RH +x twist.
    """
    s=canonical_section(project);p=geometric_properties(s)
    if not isinstance(green_solution,TorsionSolution):raise ValueError('Owned TorsionSolution required')
    b=green_solution.beam
    checks=((b.span_mm,project.span_m*1000.,'L'),(b.E_mpa,project.material.E_mpa,'E'),
        (b.G_mpa,project.material.G_mpa,'G'),(b.J_mm4,p['J_mm4'],'J'),(b.Cw_mm6,p['Cw_mm6'],'Cw'))
    if any(not math.isclose(a,v,rel_tol=1e-12,abs_tol=1e-12) for a,v,_ in checks):
        raise ValueError('Green/recovery geometric-stiffness mismatch: '+','.join(k for a,v,k in checks if not math.isclose(a,v,rel_tol=1e-12,abs_tol=1e-12)))
    if getattr(bending_state,'position_m',x_mm/1000.) != x_mm/1000.:
        raise ValueError('Bending/torsion states at different physical sections')
    t=green_solution.at(x_mm,cut_side)
    r=Resultants(N=bending_state.N_kn*1000.,My=-bending_state.Mx_knm*1e6,
        Mz=-bending_state.My_knm*1e6,Fy=bending_state.Vx_kn*1000.,Fz=-bending_state.Vy_kn*1000.,
        B=-t.bimoment_nmm2,Tsv=-t.saint_venant_torque_nmm,Tw=-t.warping_torque_nmm,
        x=x_mm,side=cut_side,combination_id=case_id,wheel_translation_mm=translation_mm,
        section_signature=s.signature,torsion_recovery='equilibrated')
    return dict(resultants=r,phi_RH=-t.theta_rad,chi_RH=-t.theta_prime_per_mm,
        T_RH=-t.total_torque_nmm,green_state=asdict(t),conversion=dict(
            phi='-theta',chi='-theta_prime',B='-B_green',Tsv='-Tsv_green',Tw='-Tw_green',
            omega='omega_recovery=-y*zmid=-omega_green_model'),
        section=s,section_properties=p,source='Preserved beam_torsion + recovery sign and virtual-work definitions')


def build_preserved_autonomous_project(project, *, horizontal_shares_by_station,
        horizontal_split_source, method_adoption_source, resistance_gamma,
        max_element_length_mm=None):
    """Map physical monorail to the existing autonomous frame workflow.

    Horizontal shares MUST be explicit per physical station and side. Equal
    vertical pairs alone do not establish equal lateral contact forces or
    favorable radial-work cancellation. This prototype accepts a shared split
    for Fx/Fy; a production route needs separate records if those differ.
    No intermediate braces or additional supports are inferred.
    """
    project.validate();s=canonical_section(project)
    if not project.end_forks_confirmed:raise ValueError('Actual ideal end-fork model must be selected explicitly')
    if any(station.longitudinal_kn for station in project.stations):
        raise ValueError('First isolated extension covers transverse-induced torsion only; longitudinal force/support-height and bimoment transfer need separate audit')
    if project.upper_braces_m or project.lower_braces_m or project.lateral_axis_braces_m:
        raise ValueError('This isolated prototype excludes intermediate restraints; stable app remains unchanged')
    if not isinstance(horizontal_split_source,str) or not horizontal_split_source.strip():
        raise ValueError('Explicit per-contact horizontal allocation source required')
    if not isinstance(method_adoption_source,str) or not method_adoption_source.strip():
        raise ValueError('Explicit supplementary EN2025 C.2 adoption required; not native NBR approval')
    gamma=_finite(resistance_gamma,'resistance_gamma')
    if gamma<1.:
        raise ValueError('Supplementary kernel requires explicit gamma>=1; this does not establish NBR/EN equivalence')
    keys={station.id for station in project.stations}
    if not isinstance(horizontal_shares_by_station,dict) or set(horizontal_shares_by_station)!=keys:
        raise ValueError('One explicit two-contact horizontal split per station required')
    wheels=[]
    for station in project.stations:
        shares=horizontal_shares_by_station[station.id]
        if not isinstance(shares,(tuple,list)) or len(shares)!=2:
            raise ValueError('Provide ordered [left,right] shares')
        shares=tuple(_finite(v,'horizontal share') for v in shares)
        if min(shares)<0 or not math.isclose(sum(shares),1.,rel_tol=0,abs_tol=1e-12):
            raise ValueError('Shares must be nonnegative and sum to one without normalization')
        for side,share in zip(('left','right'),shares):
            wheels.append(physical_wheel(s,id=station.id+'/'+side,offset_mm=station.offset_m*1000.,
                outstand_side=side,edge_to_contact_n_mm=project.edge_to_contact_mm,
                dead_N=project.trolley_hoist_mass_kg*GRAVITY*station.equipment_share/2.,
                lifted_N=project.operating_payload_t*1000.*GRAVITY*station.suspended_share/2.,
                longitudinal_N=station.longitudinal_kn*1000.*share,
                transverse_N=station.transverse_kn*1000.*share,
                retained_lifted_N=project.retained_suspended_mass_kg*GRAVITY*station.suspended_share/2.,
                provenance=project.wheel_distribution_source+'; horizontal: '+horizontal_split_source,
                point_force_transfer_adopted=True,suspended_mass_accounting='explicit_payload_plus_retained'))
    L=project.span_m*1000.
    supports=[top_suspension_point(s,id='left_fork',x_mm=0.,y_mm=0.,
        restrain={'ux':0.,'uy':0.,'uz':0.,'phi':0.},provenance=project.restraint_source),
        top_suspension_point(s,id='right_fork',x_mm=L,y_mm=0.,
        restrain={'uy':0.,'uz':0.,'phi':0.},provenance=project.restraint_source)]
    p=AutonomousUnderslungProject(section=s,length_mm=L,supports=supports,wheels=wheels,
        E_mpa=project.material.E_mpa,nu=project.material.E_mpa/(2*project.material.G_mpa)-1,
        material_source=project.material.specification,extra_dead_N_per_mm=project.extra_dead_kn_per_m,
        extra_dead_source=project.extra_dead_source,extra_dead_y_mm=0.,extra_dead_z_mm=0.,
        support_grid_spacing_mm=L,support_grid_source='Explicit monorail end-fork span; no 3m bridge grid inferred',
        max_element_length_mm=L/8 if max_element_length_mm is None else max_element_length_mm,
        capacity_tf=project.capacity_t,actual_project=not project.demonstration,
        source_notes='Isolated monorail prototype: direct physical wheel inputs, not a bridge inertia conversion',
        travel_min_mm=project.travel_min_m*1000.,travel_max_mm=project.travel_max_m*1000.,travel_source=project.travel_source,
        fy_mpa=project.material.fy_mpa,fu_mpa=project.material.fu_mpa,
        material_ratio_confirmed=project.high_ratio_material_confirmed,
        supplementary_en_resistance_gamma=gamma,supplementary_en_source=method_adoption_source,
        section_mass_kg_per_m=project.section_mass_kg_per_m,section_mass_source=project.section_mass_source)
    return p.validate()


def generated_cases(project, adapted):
    return generate_normal_cases(adapted.wheels,psi=project.dynamics()['psi'],equipment_group=project.equipment_group,
        classification_source=project.classification_source,include_8800=True,
        extra_dead_N_per_mm=project.extra_dead_kn_per_m)


def run_selected_preserved_cases(project, adapted, case_ids, *, controls=None, progress=None):
    """Retain original gates and known bridge-specific scope limitations.

    Selection is explicit and never promoted to all normal-operation cases.
    Original suspended_mass_basis expects a four-mass bridge receipt and will
    remain incomplete here. Do NOT forge such a receipt for a monorail.
    """
    catalogue=generated_cases(project,adapted);ids=set(case_ids)
    if not ids or ids-{c.id for c in catalogue}:raise ValueError('Select actual generated case IDs')
    selected=[c for c in catalogue if c.id in ids]
    result=analyze_cases(adapted,selected,controls=controls,progress=progress)
    result['diagnostic_exceedances']=result.pop('known_failures',[])
    result['known_failures']=[]
    result['pending'].insert(0,'ACTION/RESISTANCE COMPATIBILITY UNQUALIFIED: generated NBR actions and supplementary EN resistance are retained only as an audit diagnostic. A chosen gamma or adoption sentence does not prove normative consistency. No combined-member approval follows.')
    result['isolated_prototype']=dict(design_route_qualified=False,action_resistance_bridge_qualified=False,
        inherited_c2_results_diagnostic_only=True,stable_app_changed=False,all_generated_cases_evaluated=len(selected)==len(catalogue),
        selected_case_ids=[c.id for c in selected],generated_case_count=len(catalogue),
        monorail_four_mass_bridge_receipt_fabricated=False,whole_design_approved=False,
        actual_failure_proven=False,legacy_exceedances_preserved_as_diagnostics=True,
        mechanism_specific_numerical_evidence_may_qualify=True,
        retained_mass_is_physically_explicit=all(w.suspended_mass_accounting=='explicit_payload_plus_retained' for w in adapted.wheels),
        inherited_bridge_only_mass_gate_not_overridden=True)
    return result


def recover_nominal_mechanisms(project, converted, *, local=None):
    """Recover an audited same-state nominal field, independently of stability.

    `converted` is the output of map_green_state_to_recovery. Optional local
    kwargs are passed unchanged to the preserved combine_local; final wheel
    force and local-X multiplier remain explicit, with no automatic factors.
    A sampled mechanical state is not a certified travel/continuum bound.
    """
    s=canonical_section(project);r=converted['resultants']
    if not isinstance(r,Resultants) or converted['section'].signature!=s.signature:
        raise ValueError('Audited recovery state for this exact section required')
    rows=recover_bottom_flange(s,r,project.edge_to_contact_mm)
    combined=None
    if local is not None:
        if not isinstance(local,dict) or 'local_longitudinal_multiplier' not in local:
            raise ValueError('Explicit local source/multiplier required; NBR .75 and mechanical/EN 1.0 are not inferred')
        combined=combine_local(s,r,project.edge_to_contact_mm,**local)
    return dict(status='MECHANICAL_NOMINAL_STATE_ONLY',global_rows=rows,local_rows=combined,
        state_identity=rows[0]['state_identity'],resultants=asdict(r),
        certified_numerical_bound=False,travel_envelope_qualified=False,
        actual_3d_tensor_complete=False,member_stability_qualified=False,
        design_route_qualified=False,whole_design_approved=False,
        pending=['Same-state nominal response only; not a travel or physical-continuum bound.',
            'Root/contact/edge boundary layers and physical connections remain separate.',
            'Actions, resistances, local source domain and member instability require independent qualification.'])


def verify_selected_case_response(adapted, case, case_row):
    """Produce engineering numerical evidence independently of C.2.

    Uses the preserved producer directly with its valid parameters. Vertical
    dead-load height belongs to the separate radial-work audit, not an
    invented first-order torque. This does not qualify member stability.
    """
    from underslung_runway_candidate.global_response.numerical_producer import verify_moving_response
    from underslung_runway_candidate.autonomous_workflow.family_envelope import FIELDS
    adapted.validate()
    if case_row.get('case')!=asdict(case):raise ValueError('Selected computed row belongs to another case')
    history=case_row['mesh_history'];scan=case_row['sweep']
    if not history or scan is None:raise ValueError('Computed scan and mesh histories required')
    model=adapted.frame_model(history[-1]['max_element_length_mm'])
    return verify_moving_response(model,adapted.wheels,case,scan,
        selfweight=adapted.selfweight(),extra_dead=adapted.extra_dead_N_per_mm,
        extra_dead_y_mm=adapted.extra_dead_y_mm or 0.,observation_points=scan['spatial_base_stations_mm'],
        mesh_converged=case_row['numerical_converged'],mesh_history=history,fields=FIELDS)


def fatigue_nominal_prototype(project, *, resultant_bounds, wheel_vertical_actions,
        minimum_distance_to_physical_end_mm, action_basis, action_source,
        factors_source, bounds_source, nominal_model_source, material, duty, detail, method):
    """Conditional legacy NBR fatigue diagnostics retaining B/Tsv/Tw.

    Raw intervals/text cannot establish producer qualification. This prototype
    demonstrates independent nominal-plane reuse, not normative approval.
    Whole-section Fy web shear is retained as out-of-plane demand, never set
    to zero merely because the legacy ordinary-web helper is planar.
    """
    from underslung_runway_candidate.fatigue.nbr_member import (
        lower_flange_nominal_planes,ordinary_global_wall_nominal_planes,evaluate_nbr_member_plane)
    from underslung_runway_candidate.section_stress.whole_section_bounds import whole_section_shear_bound
    s=canonical_section(project)
    common=dict(resultant_bounds=resultant_bounds,action_basis=action_basis,
        action_source=action_source,factors_source=factors_source,bounds_source=bounds_source,
        nominal_model_source=nominal_model_source)
    glob=ordinary_global_wall_nominal_planes(s,**common)
    magnitude=lambda k:max(abs(resultant_bounds[k]['lower']),abs(resultant_bounds[k]['upper']))
    shear=whole_section_shear_bound(s,abs_Fy_N=magnitude('Fy'),abs_Fz_N=magnitude('Fz'),
        abs_Tsv_Nmm=magnitude('Tsv'),abs_Tw_Nmm=magnitude('Tw_equilibrated'))
    planes=list(glob['planes']);out_of_plane=shear['components']['web']['tau_xy_Fy_bound_mpa']
    if out_of_plane:
        for i,plane in enumerate(planes):
            if plane.region_id=='ordinary_global_web':
                tensor=dict(plane.tensor_intervals_mpa,txy=(-out_of_plane,out_of_plane))
                planes[i]=replace(plane,tensor_intervals_mpa=tensor,
                    plane_source=plane.plane_source+'; nonzero transverse-force web tau_xy retained from whole_section_shear_bound, so D.5 cannot silently pass this nonplanar uniform box')
    local=None;pending=[]
    try:
        local=lower_flange_nominal_planes(s,**common,wheel_vertical_actions=wheel_vertical_actions,
            edge_to_contact_n_mm=project.edge_to_contact_mm,
            minimum_distance_to_physical_end_mm=minimum_distance_to_physical_end_mm)
        planes.extend(local['planes'])
    except ValueError as exc:
        pending.append('Lower-flange nominal fatigue domain unresolved: '+str(exc))
    if material.fy_mpa!=project.material.fy_mpa or material.fu_mpa!=project.material.fu_mpa:
        raise ValueError('Fatigue material strength differs from the mechanical project')
    if material.fy_mpa/material.fu_mpa>.70 and not project.high_ratio_material_confirmed:
        raise ValueError('High fy/fu reference-material route requires explicit project adoption')
    diagnostics=[evaluate_nbr_member_plane(plane,
        material=replace(material,thickness_mm=s.tw_mm if plane.region_id=='ordinary_global_web' else s.tf_mm),
        duty=duty,detail=detail,method=method) for plane in planes]
    return dict(status='PENDING_SOURCE_QUALIFICATION',planes=tuple(planes),
        conditional_kernel_diagnostics=diagnostics,global_receipt={k:v for k,v in glob.items() if k!='planes'},
        local_receipt=None if local is None else {k:v for k,v in local.items() if k!='planes'},
        web_out_of_plane_tau_xy_bound_mpa=out_of_plane,
        certified_numerical_bound=False,producer_input_qualified=False,
        design_route_qualified=False,whole_design_approved=False,created_temporal_histories=0,
        pending=['Independent same-domain, same-section, signed global/local mechanics receipt required; source strings are not proof.',
            'Conditional kernel outcomes are nominal component results, not whole-member or C.2 approval.',
            'Physical root, junction and contact fatigue remain outside the nominal plane model.']+pending)


def dependency_receipt():
    paths=('lro_beams/beam_torsion.py','lro_beams/moving_beam.py','lro_beams/geometry.py',
        'underslung_runway_candidate/section_stress/recovery.py',
        'underslung_runway_candidate/section_stress/whole_section_bounds.py',
        'underslung_runway_candidate/fatigue/nbr_member.py',
        'underslung_runway_candidate/autonomous_frame/solver.py',
        'underslung_runway_candidate/stability/c2_adapter.py',
        'underslung_runway_candidate/stability/reference.py',
        'underslung_runway_candidate/global_response/moving_point_bounds.py',
        'underslung_runway_candidate/global_response/numerical_producer.py',
        'underslung_runway_candidate/autonomous_workflow/pipeline.py')
    return {name:sha256((ROOT/'package'/name).read_bytes()).hexdigest() for name in paths}


def source_preservation_receipt():
    return {name:dict(package_sha256=h,
        original_sha256=sha256((ROOT/'source'/'unpacked'/name).read_bytes()).hexdigest(),
        matches_preserved_original=h==sha256((ROOT/'source'/'unpacked'/name).read_bytes()).hexdigest())
        for name,h in dependency_receipt().items()}
