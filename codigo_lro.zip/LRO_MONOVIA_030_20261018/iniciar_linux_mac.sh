#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
if [ ! -x .venv/bin/python ]; then
  python3 -m venv .venv
fi
if [ ! -f .venv/lro_dependencies_ready ]; then
  .venv/bin/python -m pip install --disable-pip-version-check -r requirements.txt
  touch .venv/lro_dependencies_ready
fi
exec .venv/bin/python -m streamlit run app.py --server.address 127.0.0.1 --browser.gatherUsageStats false
