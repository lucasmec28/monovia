"""Genuine NBR FAT8400 orchestration; reuses the audited nominal consumer."""
from copy import deepcopy
from dataclasses import asdict
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,math,time
from monorail.analysis import generate_cases,digest,source_receipt
from analytical_scan import scan_case,response_factory,Controls,physical_reactions,_state_with_contacts
from nominal_scan import evaluate_nbr_fatigue_scans,NumericalAcceptance
from underslung_runway_candidate.fatigue.nbr_member import (
    NBRFatigueMaterial,NBRFatigueDuty,NBRFatigueDetail,NBRFatigueMethod,KAPPA_POLICY)
from nbr_fatigue_project import NBRFatigueProject

VERSION='0.3.0-nbr-nominal-fatigue'
STATUS_ORDER={'PASS':0,'BOUND_EXCEEDED':1,'PENDING':2,'OUT_OF_SCOPE':3,'NOT_CALCULATED':4}
INTERPRETATION=dict(
    title='Aplicação conjunta NBR 10084 e NBR 8400-2, com recuperação elástica nominal',
    longitudinal_combination='σx,nominal = σN + σM + σB + 0,75 σ0x,local',
    transverse_combination='σy,nominal = σy,global + σ0y,local; parcela local transversal integral',
    fatigue_equation='NBR 8400-2, Anexo D, seção D.2.3, Equação (D.5), sem alteração',
    mechanics_basis='NBR 8400-2:2019 corrigida 2022, seção 4: procedimentos convencionais da resistência dos materiais. NBR 10084:2020, 9.1.2(b,c): efeitos axiais e torção excêntrica.',
    local_basis='NBR 10084:2020, 9.1.1 e 9.1.4; NBR 8400-2, 5.6 e D.2.3. A soma completa N/M/B com 0,75 local é interpretação conjunta, não transcrição literal da 10084.',
    recovery_reference='SCI P385, seção 2, páginas 7 e 10–11: recuperação/superposição elástica de tensões por torção/empenamento; referência mecânica, sem importar fatores EN.',
    factor_scope='0,75 somente na parcela local longitudinal. Não reaplicar 4/3 nas admissíveis; não criar fator independente de fadiga.',
    material_boundary_policy='fy/fu exatamente 0,70 permanece pendente nesta camada, preservando a política da rota NBR inicial.',
    new_resistance_equation_created=False,literal_complete_formula_claimed=False)
LIMITATIONS=[
    'Apenas fadiga nominal em pontos/planos identificados; nenhum resultado aprova integralmente a monovia ou sua instalação.',
    'Um vão reto, seção I laminada duplamente simétrica de abas paralelas, garfos extremos e empenamento livre. Sem crédito de travamentos intermediários nem novos apoios.',
    'Todos os casos FAT8400 gerados devem estar presentes, carregado/vazio e sentidos. Isso não prova cobertura de todos os eventos físicos do equipamento.',
    'Caso I de fadiga sem o coeficiente de majoração de grupo Mₓ e sem ω; os momentos fletores e a torção permanecem incluídos.',
    'Adoção κ=−1 explícita; não é história temporal medida/reconstruída, cálculo de ciclos até ruptura, dano de Miner ou promessa de vida ilimitada.',
    'Caixas de componentes assinadas produzem limite suficiente de D.5, não estado concomitante. Majorante excedido não é testemunho de falha física.',
    'Cortante lateral pode tornar a alma não planar para o consumidor disponível. A componente é mantida e a alma fica pendente; outras regiões calculáveis são preservadas.',
    'Detalhe W0 somente em material-base laminado sem entalhe. Contato rolante, desgaste, raízes reais, furos, soldas, anexos e regiões perturbadas não são fechados.',
    'Estabilidade, segunda ordem, rigidez/resistência de ligações e da estrutura receptora são verificações separadas.',
    'Convergência da busca móvel é evidência numérica de engenharia, não prova matemática de envoltória contínua.',
    'Os campos de fadiga antigos dentro do projeto NBR importado são apenas preservados; esta rota usa os campos independentes de material/grupo/detalhe/método do novo bundle. Nenhuma aprovação é importada.',
]


def code_receipt():
    root=Path(__file__).resolve().parent
    import analytical_scan,nominal_scan,prototype
    paths=[Path(__file__),root/'nbr_fatigue_project.py',Path(analytical_scan.__file__),Path(nominal_scan.__file__),Path(prototype.__file__)]
    files={p.name:sha256(p.read_bytes()).hexdigest() for p in paths}
    legacy=source_receipt()
    return dict(files=files,legacy=legacy,fingerprint=digest(dict(files=files,legacy=legacy['fingerprint'])))


def _status(checks):return max((c['status'] for c in checks),key=lambda s:STATUS_ORDER.get(s,3),default='PENDING')


def _incomplete(status,reason,id_='nominal_fatigue/incomplete'):
    return dict(id=id_,region='complete_declared_action_domain',point_id='',face='',plane='',
        status=status,utilization=None,reasons=[reason],source='NBR 8400-2, 5.6 e D.2.3',actual_failure_proven=False)


def _premises(bundle):
    p=bundle.project;out=[]
    for name,value in [('fonte material',bundle.material_source),('fonte grupo do componente',bundle.classification_source),
        ('fonte detalhe W0',bundle.detail_source),('requisito de fabricação',bundle.fabrication_source),
        ('adoção κ=−1',bundle.kappa_source),('aceitação numérica',bundle.numerical_source),
        ('fonte ações do equipamento',p.equipment_source),('distribuição nas rodas',p.wheel_distribution_source),
        ('fonte das ações horizontais ou zero explícito',p.horizontal_action_source),('fonte dos vínculos',p.restraint_source),
        ('fonte da geometria',p.section.property_source),('fonte do percurso',p.travel_source)]:
        if not value.strip():out.append('Falta '+name+'.')
    if bundle.material_grade=='não informado':out.append('Grau material não informado; não inferir equivalência.')
    if bundle.component_group=='não informado':out.append('Grupo do componente E1–E8 não informado.')
    if bundle.construction_detail!='W0_plain_rolled_unnotched':out.append('Detalhe W0 material-base laminado sem entalhe não selecionado.')
    if bundle.fabrication_requirement=='não informado':out.append('Requisito de fabricação/inspeção não informado; não equivale a inspeção executada.')
    if not bundle.kappa_minus_one_adopted:out.append('Redução conservadora κ=−1 não adotada.')
    ratio=p.material.fy_mpa/p.material.fu_mpa
    if math.isclose(ratio,.70,rel_tol=0.,abs_tol=1e-14):out.append('Fronteira fy/fu=0,70 mantida pendente; ramo conservador autônomo não adotado silenciosamente.')
    if ratio>.70 and (not p.high_ratio_material_confirmed or not bundle.high_ratio_material_source.strip()):out.append('Ramo fy/fu>0,70 exige adoção explícita e fonte do aço de referência; não inferir pelo grau.')
    return out


def analyze_nbr_fatigue(bundle,progress=None):
    if type(bundle) is not NBRFatigueProject:raise ValueError('NBRFatigueProject tipado obrigatório')
    bundle.validate();signature=bundle.signature();sources=code_receipt();started=time.monotonic()
    p=bundle.project;cases=[c for c in generate_cases(p) if c.family=='FAT8400'];rows=[]
    controls=Controls(relative_tolerance=bundle.numerical_tolerance,max_refinements=p.max_refinements)
    for i,case in enumerate(cases):
        title=('Carregado' if case.loaded else 'Vazio com massas retidas')+f' · Hs {case.longitudinal_sign:+d} · Hy {case.transverse_sign:+d}'
        if progress:progress(i/max(1,len(cases)),title)
        row=dict(id=case.id,title=title,case=asdict(case),calculated=False,scan=None,error=None,error_type=None)
        try:
            row['scan']=scan_case(p,case,controls,axial_transfer=bundle.axial_transfer);row['calculated']=True
        except (ValueError,ArithmeticError) as exc:row.update(error=str(exc),error_type=type(exc).__name__)
        rows.append(row)
    nominal=None;checks=[];missing=_premises(bundle);consumer_error=None
    if not rows or not all(r['calculated'] for r in rows):
        checks=[_incomplete('NOT_CALCULATED','Não foi possível determinar todo o domínio FAT8400 declarado. Casos ausentes/não calculados não são apagados nem substituídos por zero.')]
    elif missing:
        checks=[_incomplete('PENDING',reason,'nominal_fatigue/premise/'+str(i)) for i,reason in enumerate(missing)]
    else:
        try:
            nominal=evaluate_nbr_fatigue_scans(p,[r['scan'] for r in rows],
                material=NBRFatigueMaterial(p.material.fy_mpa,p.material.fu_mpa,p.section.tf_mm,bundle.material_grade,bundle.material_source),
                duty=NBRFatigueDuty(bundle.component_group,bundle.classification_source,bundle.classification_kind),
                detail=NBRFatigueDetail(bundle.construction_detail,bundle.detail_source,bundle.fabrication_requirement,bundle.fabrication_source),
                method=NBRFatigueMethod(KAPPA_POLICY,bundle.kappa_source),
                acceptance=NumericalAcceptance(bundle.numerical_tolerance,bundle.numerical_source))
            checks=deepcopy(nominal['checks'])
        except (ValueError,ArithmeticError) as exc:
            consumer_error=dict(error_type=type(exc).__name__,message=str(exc))
            checks=[_incomplete('NOT_CALCULATED',type(exc).__name__+': '+str(exc),'nominal_fatigue/consumer')]
    if bundle.signature()!=signature or code_receipt()!=sources:raise ValueError('Entradas ou código mudaram durante o cálculo; descarte o recibo desatualizado')
    summary=dict(counts={s:sum(c['status']==s for c in checks) for s in STATUS_ORDER},
        generated_cases=len(rows),calculated_cases=sum(r['calculated'] for r in rows),
        converged_cases=sum(r['calculated'] and r['scan']['numerical_converged'] for r in rows),
        checks_status=_status(checks),whole_design_approved=False,
        nominal_planes=len(nominal['planes']) if nominal else 0,
        action_domain_complete=bool(rows) and all(r['calculated'] for r in rows),
        not_calculated_case_ids=[r['id'] for r in rows if not r['calculated']],
        actual_fatigue_failure_claimed=False,calculated_cycles_to_failure=False)
    result=dict(format='LRO_MONORAIL_NBR_NOMINAL_FATIGUE_CALCULATION',version=VERSION,
        created_utc=datetime.now(timezone.utc).isoformat(),input_signature=signature,input_snapshot=bundle.to_dict(),
        sources=sources,cases=rows,nominal=nominal,checks=checks,summary=summary,missing_premises=missing,
        consumer_error=consumer_error,limitations=deepcopy(LIMITATIONS),interpretation=deepcopy(INTERPRETATION),
        coordinate_convention='s longitudinal, y transversal, z para cima; momentos/torções pela mão direita em +s. N positivo em tração. Apoio sobre viga e viga sobre apoio são vetores opostos.',
        demonstration=bundle.demonstration,whole_design_approved=False,wall_seconds=time.monotonic()-started)
    result['result_signature']=digest(result)
    if progress:progress(1.,'Análise nominal de fadiga concluída; consulte as pendências por região.')
    return result


def assert_current_nbr_fatigue_result(bundle,result):
    if type(bundle) is not NBRFatigueProject:raise ValueError('Entrada tipada NBR obrigatória')
    bundle.validate()
    if type(result) is not dict or result.get('format')!='LRO_MONORAIL_NBR_NOMINAL_FATIGUE_CALCULATION':raise ValueError('Execute cálculo atual de fadiga NBR antes de exportar')
    if result.get('input_signature')!=bundle.signature() or digest(result.get('input_snapshot'))!=digest(bundle.to_dict()):raise ValueError('Entradas mudaram; recalcule a fadiga NBR')
    if result.get('sources')!=code_receipt():raise ValueError('Código mudou; recalcule a fadiga NBR')
    if result.get('result_signature')!=digest({k:v for k,v in result.items() if k!='result_signature'}):raise ValueError('Recibo de fadiga alterado ou incompleto')
    expected=[asdict(c) for c in generate_cases(bundle.project) if c.family=='FAT8400']
    if digest([r['case'] for r in result['cases']])!=digest(expected):raise ValueError('Casos de fadiga omitidos, alterados ou reordenados')
    return result


def diagram_nbr_fatigue(bundle,result,case_id,translation_m=None):
    assert_current_nbr_fatigue_result(bundle,result)
    row=next((r for r in result['cases'] if r['id']==case_id),None)
    if row is None or not row['calculated']:raise ValueError('Caso NBR calculado obrigatório para diagrama')
    p=bundle.project;case=next(c for c in generate_cases(p) if c.id==case_id and c.family=='FAT8400')
    factory,_=response_factory(p,case,axial_transfer=bundle.axial_transfer)
    if translation_m is None:translation_m=max(row['scan']['extrema']['Mstrong_Nmm'].values(),key=lambda x:abs(x['value']))['translation_m']
    if type(translation_m) not in (int,float) or not math.isfinite(translation_m) or not p.travel_min_m<=translation_m<=p.travel_max_m:raise ValueError('Posição fora do percurso físico')
    response=factory(translation_m);nodes={p.span_m*i/120 for i in range(121)};wheels={translation_m+s.offset_m for s in p.stations};nodes.update(wheels)
    data=[]
    for x in sorted(nodes):
        for side in ('left','right') if x in wheels else ('right',):
            state=_state_with_contacts(response,p,x,side);t=state['torsion']
            data.append(dict(s_m=x,side=side,N_kN=state['N_kn'],My_kNm=-state['Mx_knm'],Mz_kNm=-state['My_knm'],Vy_kN=state['Vx_kn'],Vz_kN=-state['Vy_kn'],
                T_kNm=-t['total_torque_nmm']/1e6,Tsv_kNm=-t['saint_venant_torque_nmm']/1e6,Tw_kNm=-t['warping_torque_nmm']/1e6,B_kNm2=-t['bimoment_nmm2']/1e9,
                uy_mm=state['horizontal_mm'],uz_mm=-state['vertical_mm'],phi_mrad=-t['theta_rad']*1000,
                contact_uy_mm=state['rail_horizontal_mm'],contact_left_uz_mm=-state['contact_vertical_left_mm'],contact_right_uz_mm=-state['contact_vertical_right_mm']))
    reactions=physical_reactions(response);assert_current_nbr_fatigue_result(bundle,result)
    return dict(case_id=case_id,title=row['title'],family='FAT8400',translation_m=translation_m,rows=data,
        support_on_beam=reactions,beam_on_support={k:-v for k,v in reactions.items()},coordinate_convention=result['coordinate_convention'],
        note='Um estado concomitante NBR de fadiga; não é histórico temporal nem união de máximos independentes.')
