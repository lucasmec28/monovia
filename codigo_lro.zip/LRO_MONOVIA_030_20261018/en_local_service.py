"""EN lower-flange/service consumers of owned physical-action scan receipts.

Preserved kernels supply local stresses, EN wheel resistance and linear nominal
stress recovery. Case factors are never recalculated here. Conservative boxes
are not coexistent states; only a real isolated-wheel sample may witness a
nominal service-criterion failure. Nothing here approves fatigue or contact.
"""
from dataclasses import asdict,replace
from functools import lru_cache
from hashlib import sha256
from itertools import product
from pathlib import Path
import math

from monorail.analysis import digest
from lro_beams.document_metadata import validate_xml_text
from lro_beams.stress_8400 import equivalent_plane_stress  # algebra only; no NBR factors/allowables
from underslung_runway_candidate.local_flange.kernel import (
    Geometry,Action,ENResistance,local_stresses,close_wheel_stresses,bottom_flange_resistance,SOURCE)
from underslung_runway_candidate.section_stress.recovery import (
    Resultants,recover_bottom_flange,combine_local,bottom_flange_points,geometric_properties)
from en_member import (ENResistanceBasis,_section,_intervals_from_scan,_numerical_pending,
    _evaluate_kernel_components,_reference_from_response,_radial_guard)
from en_analytical_scan import assert_en_scan_current

EN6_URL='https://www.phd.eng.br/wp-content/uploads/2015/12/en.1993.6.2007.pdf'
LOCAL_SOURCE='EN 1993-6:2007 + AC:2009 §§5.8, 6.7, 7.5; nominal parallel-flange wheel model'
COMPONENTS=('N','My','Mz','B','Fy','Fz','Tsv','Tw_equilibrated')


def _current_hashes():
    here=Path(__file__)
    return {p.name:sha256(p.read_bytes()).hexdigest() for p in (here,here.with_name('en_member.py'))}


def _context(project,action_input,action_receipt,case_id,scan,basis):
    from en_actions import assert_case_receipt
    if not isinstance(basis,ENResistanceBasis):raise ValueError('Independent EN material/resistance basis required')
    basis.validate(project)
    case=assert_case_receipt(action_input,action_receipt,case_id)
    assert_en_scan_current(project,action_input,action_receipt,case_id,scan)
    pending=_numerical_pending(scan,basis)
    if not case.action_generation_complete:pending.append('Components of this complete EN action group are missing.')
    for r in case.requirements:
        if r.category=='missing_input' and r.blocking_in_scope:pending.append(r.code+': '+r.detail)
        elif r.category=='mechanical_qualification' and r.code!='longitudinal_response_and_resistance_require_separate_consumer_qualification':
            pending.append('Unresolved mechanical requirement: '+r.code)
    if any(w.fs_kn for w in case.wheel_loads) and scan['metadata'].get('axial_transfer') is None:
        raise ValueError('Longitudinal action has no resolved physical axial-transfer model')
    return case,_section(project),_intervals_from_scan(scan),pending


def _linear_interval(coefficients,intervals):
    terms=[(coefficients[k]*intervals[k][0],coefficients[k]*intervals[k][1]) for k in coefficients]
    return math.fsum(min(a,b) for a,b in terms),math.fsum(max(a,b) for a,b in terms)


@lru_cache(maxsize=128)
def _recovery_coefficients(section,n_mm):
    result={p.id:{} for p in bottom_flange_points(section,n_mm)}
    for field in COMPONENTS:
        values=dict(N=0.,My=0.,Mz=0.,B=0.,Fy=0.,Fz=0.,Tsv=0.,Tw=0.)
        values['Tw' if field=='Tw_equilibrated' else field]=1.
        r=Resultants(**values,x=0.,side='right',combination_id='linear recovery basis',
            wheel_translation_mm=0.,section_signature=section.signature,torsion_recovery='equilibrated')
        for row in recover_bottom_flange(section,r,n_mm):
            result[row['id']][field]=(row['global_sigma_x_mpa'],row['global_sigma_y_mpa'],row['tau_xy_mpa'])
    return result


def _criterion_values(sx,sy,tau,capacity):
    return dict(normal_x=abs(sx)/capacity,normal_y=abs(sy)/capacity,
        shear=math.sqrt(3)*abs(tau)/capacity,equivalent=equivalent_plane_stress(sx,sy,tau)/capacity)


def _box_criteria(box,capacity):
    retained={}
    for corner in product(box['sx'],box['sy'],box['tau']):
        for name,value in _criterion_values(*corner,capacity).items():
            if name not in retained or value>retained[name]['utilization']:
                retained[name]=dict(criterion=name,utilization=value,mathematical_vertex=corner,
                    vertex_is_actual_state=False)
    return retained


def _geometry(project):
    s=project.section
    return Geometry(s.bf_mm,s.tw_mm,s.tf_mm,project.edge_to_contact_mm,'rolled',s.root_radius_mm,0.)


def _clusters(project,scan):
    rows=sorted(scan['metadata']['wheel_ledger'],key=lambda r:r['offset_m'])
    groups=[]
    for row in rows:
        if not groups or (row['offset_m']-groups[-1][-1]['offset_m'])*1000>=1.5*project.section.bf_mm:
            groups.append([row])
        else:groups[-1].append(row)
    return groups


def _distance(project,rows):
    return min((project.travel_min_m+min(r['offset_m'] for r in rows))*1000,
        (project.span_m-project.travel_max_m-max(r['offset_m'] for r in rows))*1000)


def _sample_resultants(section,sample,case_id):
    a=sample['state'];t=a['torsion']
    return Resultants(N=a['N_kn']*1000,My=-a['Mx_knm']*1e6,Mz=-a['My_knm']*1e6,
        B=-t['bimoment_nmm2'],Fy=a['Vx_kn']*1000,Fz=-a['Vy_kn']*1000,
        Tsv=-t['saint_venant_torque_nmm'],Tw=-t['warping_torque_nmm'],x=a['position_m']*1000,
        side=a['side'],combination_id=case_id,wheel_translation_mm=sample['translation_m']*1000,
        section_signature=section.signature,torsion_recovery='equilibrated')


def _service(project,case,section,intervals,scan,basis,pending,gamma_ser):
    geometry=_geometry(project);capacity=basis.fy_mpa/gamma_ser
    coefficients=_recovery_coefficients(section,project.edge_to_contact_mm)
    all_rows=scan['metadata']['wheel_ledger'];points=[];checks=[]
    for cluster_number,cluster in enumerate(_clusters(project,scan)):
        label='cluster'+str(cluster_number+1);distance=_distance(project,cluster)
        if distance<=geometry.bottom_b_mm:
            checks.append(dict(id=label+'/interior',status='PENDING',reason='Whole physical passage is not in xe > bf; no end-transition interpolation is invented.',
                minimum_end_distance_mm=distance,required_strictly_greater_mm=geometry.bottom_b_mm,source=LOCAL_SOURCE))
            continue
        actions=[Action(row['individual_wheel_kn']*1000,'service',SOURCE,case.id) for row in cluster]
        spacings=[(b['offset_m']-a['offset_m'])*1000 for a,b in zip(cluster,cluster[1:])]
        nearest=None
        if len(cluster)>1:
            local=close_wheel_stresses(geometry,actions,spacings,distance_to_nearest_end_mm=distance,symmetric_opposite_wheels_confirmed=True)
        else:
            distances=[abs(cluster[0]['offset_m']-r['offset_m'])*1000 for r in all_rows if r['station_id']!=cluster[0]['station_id']]
            nearest=min(distances) if distances else None
            local=local_stresses(geometry,actions[0],distance_to_nearest_end_mm=distance,symmetric_opposite_wheels_confirmed=True,
                nearest_longitudinal_spacing_mm=nearest,isolated_longitudinal_station_confirmed=nearest is None)
        witnesses={}
        # A full close-wheel superposition is a sufficient box, NOT an actual
        # field at any physical wheel; therefore it cannot witness failure.
        if len(cluster)==1:
            for sample in scan['sampled_wheel_states']:
                if sample['station_id']!=cluster[0]['station_id']:continue
                r=_sample_resultants(section,sample,case.id)
                rows=combine_local(section,r,project.edge_to_contact_mm,individual_wheel_N=actions[0].individual_wheel_N,
                    wheel_station_mm=r.x,distance_to_nearest_end_mm=min(r.x,project.span_m*1000-r.x),
                    symmetric_opposite_wheels_confirmed=True,nearest_longitudinal_spacing_mm=nearest,
                    isolated_longitudinal_station_confirmed=nearest is None,local_longitudinal_multiplier=1.)
                for row in rows:
                    for criterion,value in _criterion_values(row['sigma_x_mpa'],row['sigma_y_mpa'],row['tau_xy_mpa'],capacity).items():
                        key=(row['id'],criterion)
                        if key not in witnesses or value>witnesses[key]['utilization']:
                            witnesses[key]=dict(utilization=value,translation_m=sample['translation_m'],position_m=r.x/1000,
                                side=r.side,components_mpa=(row['sigma_x_mpa'],row['sigma_y_mpa'],row['tau_xy_mpa']),
                                physical_same_state_nominal_point=True)
        for pt in bottom_flange_points(section,project.edge_to_contact_mm):
            coeff=coefficients[pt.id]
            global_box={name:_linear_interval({k:v[index] for k,v in coeff.items()},intervals)
                for index,name in enumerate(('sx','sy','tau'))}
            lx,ly=local[pt.point];sign=1 if pt.face=='bottom' else -1
            local_x=(-abs(lx),abs(lx)) if len(cluster)>1 else (sign*lx,sign*lx)
            local_y=(-abs(ly),abs(ly)) if len(cluster)>1 else (sign*ly,sign*ly)
            box=dict(sx=(global_box['sx'][0]+local_x[0],global_box['sx'][1]+local_x[1]),
                sy=(global_box['sy'][0]+local_y[0],global_box['sy'][1]+local_y[1]),tau=global_box['tau'])
            point_checks=[]
            for criterion,check in _box_criteria(box,capacity).items():
                witness=witnesses.get((pt.id,criterion))
                if witness and witness['utilization']>check['utilization']+1e-9:
                    raise ValueError('Nominal same-state witness exceeds its computed stress box')
                status='PENDING' if pending else 'PASS' if check['utilization']<=1 else ('FAIL' if witness and witness['utilization']>1 else 'BOUND_EXCEEDED')
                item=dict(check,id=label+'/'+pt.id+'/'+criterion,status=status,source='EN 1993-6 §7.5(1),(3), equations7.2(a,b,d)',
                    gamma_Mser=gamma_ser,normal_capacity_mpa=capacity,shear_capacity_mpa=capacity/math.sqrt(3),
                    reasons=list(pending),witness=witness,actual_nominal_criterion_failure=status=='FAIL',
                    physical_failure_or_contact_failure_proven=False,whole_design_approved=False)
                checks.append(item);point_checks.append(item)
            points.append(dict(cluster=label,station_ids=[r['station_id'] for r in cluster],point=asdict(pt),
                global_box_mpa=global_box,local_box_mpa=dict(sx=local_x,sy=local_y),combined_box_mpa=box,
                local_longitudinal_multiplier=1.,local_transverse_multiplier=1.,
                close_wheel_superposition=len(cluster)>1,conservative_cluster_sign_box=len(cluster)>1,
                physical_state_not_claimed_for_box=True,opposite_wheels_double_counted=False,checks=point_checks))
    return dict(checks=checks,points=points,method='EN local elastic nominal plus recovered global stress, unreduced local components',
        gamma_Mser=gamma_ser,contact_root_and_fatigue_qualified=False)


def _midflange_bounds(section,intervals):
    p=geometric_properties(section);z=p['bottom_z_mid_mm'];values=[]
    for y in (-section.bottom_width/2,section.bottom_width/2):
        bending=_linear_interval(dict(My=z/p['Iy_mm4'],Mz=-y/p['Iz_mm4']),intervals)
        full=_linear_interval(dict(N=1/p['A_mm2'],My=z/p['Iy_mm4'],Mz=-y/p['Iz_mm4'],B=-y*(z-p['z_sc_mm'])/p['Cw_mm6']),intervals)
        values.append(dict(y_mm=y,z_mm=z,bending=bending,expanded_N_M_B=full))
    literal=max(abs(v) for row in values for v in row['bending'])
    expanded=max(abs(v) for row in values for v in row['expanded_N_M_B'])
    return dict(literal_bending_abs_bound_mpa=literal,expanded_N_M_B_abs_bound_mpa=expanded,
        governing_abs_bound_mpa=max(literal,expanded),rows=values,
        note='The published reduction is retained for global bending. A second conservative global N/M/B composition is checked; B cancellation never increases the published capacity. Independent extrema are not favorable simultaneous states.')


def _ultimate(project,case,section,intervals,scan,basis,pending):
    geometry=_geometry(project);threshold=2*math.sqrt(2)*(geometry.m_mm+geometry.edge_to_contact_n_mm)
    mid=_midflange_bounds(section,intervals);rows=scan['metadata']['wheel_ledger'];checks=[]
    resistance=ENResistance(basis.fy_mpa,basis.gamma_M0,basis.partial_factor_source)
    for row in rows:
        distance=_distance(project,[row]);identifier='local_uls/'+row['station_id']
        if distance<=max(threshold,geometry.bottom_b_mm):
            checks.append(dict(id=identifier,status='PENDING',reason='Remote branch requires xe > 2sqrt(2)(m+n), and interior local source xe > bf. End branch is not substituted.',
                minimum_end_distance_mm=distance,strict_remote_threshold_mm=threshold,source='EN1993-6 §6.7 Table6.2(b,c)'))
            continue
        distances=[abs(row['offset_m']-other['offset_m'])*1000 for other in rows if other['station_id']!=row['station_id']]
        actual_spacing=min(distances) if distances else None
        saturation=4*math.sqrt(2)*(geometry.m_mm+geometry.edge_to_contact_n_mm)
        evaluation_spacing=actual_spacing if actual_spacing is not None else saturation
        action=Action(row['individual_wheel_kn']*1000,'ultimate',SOURCE,case.id)
        evaluations={name:bottom_flange_resistance(geometry,action,resistance,
            global_midflange_sigma_MPa=mid[key],end_case='remote',wheel_spacing_mm=evaluation_spacing,remote_from_end_confirmed=True)
            for name,key in (('published_bending','literal_bending_abs_bound_mpa'),('expanded_global','expanded_N_M_B_abs_bound_mpa'))}
        capacity=min(v['capacity_N'] for v in evaluations.values())
        utilization=action.individual_wheel_N/capacity if capacity>0 else None
        global_domain_sufficient=mid['governing_abs_bound_mpa']<=basis.fy_mpa/basis.gamma_M0
        status='PENDING' if pending else 'BOUND_EXCEEDED' if not global_domain_sufficient else 'PASS' if capacity>=action.individual_wheel_N else 'BOUND_EXCEEDED'
        # The preserved kernel reports infinity at zero capacity; retain a
        # JSON-safe explicit undefined ratio instead of serializing infinity.
        for value in evaluations.values():
            if not math.isfinite(value['utilization']):value['utilization']=None
        checks.append(dict(id=identifier,status=status,individual_wheel_N=action.individual_wheel_N,
            capacity_N=capacity,utilization=utilization,reasons=list(pending)+([] if global_domain_sufficient else ['The global-stress bound exceeds fy/gammaM0; truncated zero capacity does not establish the source domain, even for zero wheel force.']),
            global_stress_domain_sufficient=global_domain_sufficient,global_stress_bound_ratio=mid['governing_abs_bound_mpa']/(basis.fy_mpa/basis.gamma_M0),evaluations=evaluations,
            actual_nearest_spacing_mm=actual_spacing,numerical_spacing_argument_mm=evaluation_spacing,
            spacing_kind='actual_nearest_neighbor' if actual_spacing is not None else 'isolated_station_saturated_effective_length_no_fictitious_wheel',
            minimum_end_distance_mm=distance,strict_remote_threshold_mm=threshold,
            midflange_stress_bounds=mid,source='EN1993-6 §6.7 equations6.2–6.4 Table6.2(b)',
            literal_bending_and_expanded_global_governed_separately=True,
            actual_failure_proven=False,whole_design_approved=False))
    return dict(checks=checks,method='Preserved EN remote bottom-flange wheel resistance; conservative global stress reduction',
        gamma_M0=basis.gamma_M0,midflange_stress_bounds=mid)


def evaluate_en_local_case(project,*,action_input,action_receipt,case_id,scan,basis,gamma_Mser=1.,service_factor_source='Recommended EN1993-6 §7.5 gammaM,ser=1.0; no national annex conformity claimed'):
    before=_current_hashes();case,section,intervals,pending=_context(project,action_input,action_receipt,case_id,scan,basis)
    if case.family in ('EN_SLS_STRESS','EN_TEST_SLS'):
        try:valid_gamma=type(gamma_Mser) in (int,float) and math.isfinite(gamma_Mser) and 1<=gamma_Mser<=1e6
        except (OverflowError,TypeError,ValueError):valid_gamma=False
        if not valid_gamma:raise ValueError('Explicit finite service resistance factor in numerical domain 1..1e6 required')
        if not isinstance(service_factor_source,str) or not service_factor_source.strip():raise ValueError('Service resistance factor source required')
        validate_xml_text(service_factor_source,'service factor source',max_length=10000)
        result=_service(project,case,section,intervals,scan,basis,pending,gamma_Mser)
        result['service_factor_source']=service_factor_source
        # Reuse the preserved nominal whole-section stress bound, NOT its C.2
        # verdict. The only resistance denominator in this service extraction
        # is fy/gammaM,ser, matching EN6 eq7.2(a,b,c).
        from en_analytical_scan import response_factory
        from analytical_scan import AxialTransfer
        raw=scan['metadata'].get('axial_transfer')
        axial=None if raw is None else AxialTransfer(**raw)
        factory,_=response_factory(project,action_input,action_receipt,case_id,axial_transfer=axial)
        reference=factory(project.travel_min_m)
        global_mechanics=_evaluate_kernel_components(project,replace(basis,gamma_M0=gamma_Mser),intervals,
            _reference_from_response(project,reference),radial_guard=_radial_guard(case),numerical_pending=pending)
        global_checks=[]
        for check in global_mechanics['section_checks']:
            item=dict(check,id='service/global_nominal',title='Global nominal elastic service stress bound',
                source='EN1993-6 §7.5 equations7.2(a,b,c); preserved whole-section N/M/B/shear stress recovery',
                gamma_Mser=gamma_Mser,not_a_C2_service_stability_approval=True)
            global_checks.append(item)
        result['global_stress_checks']=global_checks
        result['global_nominal_shear']=global_mechanics['whole_nominal_shear']
        result['global_stress_bound_mpa']=global_mechanics['kernel_section']['intermediates']['equivalent_stress_bound_mpa']
        result['checks'].extend(global_checks)
    elif case.family in ('EN_ULS_STR','EN_TEST_ULS'):result=_ultimate(project,case,section,intervals,scan,basis,pending)
    else:raise ValueError('EN local consumer requires actual EN_ULS_STR/EN_TEST_ULS or EN_SLS_STRESS/EN_TEST_SLS case')
    assert_en_scan_current(project,action_input,action_receipt,case_id,scan)
    if before!=_current_hashes():raise ValueError('EN local consumer changed during calculation')
    result.update(kind='independent_EN_local_mechanisms',case_id=case.id,case_family=case.family,
        source_url=EN6_URL,source_hashes=before,action_binding=scan['action_binding'],scan_signature=scan['result_signature'],
        basis=asdict(basis),producer_requirements=[asdict(r) for r in case.requirements],
        numerical_evidence='Converged engineering translation scan; no formal continuous-motion enclosure claimed',
        no_NBR_action_or_resistance_conversion=True,whole_design_approved=False,
        limitations=['Prescribed nominal points on parallel lower flanges, not the physical contact/root 3-D tensor.',
            'Instability, fatigue, vibration, connection detailing and complete equipment event coverage remain separate.',
            'A conservative stress/capacity box may pass a sufficient criterion; its exceedance alone is not a physical failure.'])
    result['result_signature']=digest(result);return result


def evaluate_en_deflection_case(project,*,action_input,action_receipt,case_id,scan,basis):
    before=_current_hashes();case,_,_,pending=_context(project,action_input,action_receipt,case_id,scan,basis)
    if case.family!='EN_SLS_DEFLECTION':raise ValueError('Dedicated no-dynamic EN deflection family required')
    effect=case.action_effect
    if effect=='nominal_payload_only_L500':
        limit=project.span_m*1000/500;source='EN1993-6 §7.3 Table7.2(c), nominal payload only, support-relative vertical deflection'
        if case.fixed_loads or any(w.fs_kn or w.fy_kn for w in case.wheel_loads):raise ValueError('Nominal payload deflection contains excluded actions')
    elif effect=='total_gravity_no_dynamics_L600_25mm':
        limit=min(project.span_m*1000/600,25.);source='EN1993-6 §7.3 Table7.2(a), total characteristic gravity without dynamics, zero camber explicitly adopted'
    else:raise ValueError('Unknown dedicated deflection action definition')
    if any(entry.dynamic_factor!=1 for entry in case.ledger):raise ValueError('Deflection ledger still includes dynamic amplification')
    extremes=scan['extrema']['vertical_mm'];witness=max(extremes.values(),key=lambda r:abs(r['value']));demand=abs(witness['value'])
    status='PENDING' if pending else 'PASS' if demand<=limit else 'FAIL'
    result=dict(kind='independent_EN_service_deflection',case_id=case.id,action_binding=scan['action_binding'],
        checks=[dict(id='service/'+effect,status=status,demand_mm=demand,limit_mm=limit,utilization=demand/limit,
            witness=witness,reasons=pending,source=source,source_url=EN6_URL,centroidal_vertical=True,
            support_settlement_mm=0.,adopted_camber_mm=0.,actual_sampled_criterion_exceedance=status=='FAIL')],
        contact_displacements_informative_only={k:scan['extrema'][k] for k in ('contact_vertical_left_mm','contact_vertical_right_mm','contact_horizontal_mm')},
        no_invented_contact_rotation_limit=True,recommended_EN_limit_not_verified_national_annex=True,
        scan_signature=scan['result_signature'],source_hashes=before,basis=asdict(basis),whole_design_approved=False)
    assert_en_scan_current(project,action_input,action_receipt,case_id,scan)
    if before!=_current_hashes():raise ValueError('EN service consumer changed during calculation')
    result['result_signature']=digest(result);return result
