"""Normal NBR Rlambda for UNDER nominal fatigue/service, never CMAA SK/SHE.

A station contains two real opposed contacts at identical x,z. Pure Fy has
identical linear beam influence at both, so sum(h_left,h_right)/(2*A) multiplies
the verified per-contact station/Fy basis. This is an exact projection of a
relaxed resultant bound, NOT physical equal lateral sharing. It is NOT a
stability load-radius projection and does not qualify lateral contact strength.
"""
from dataclasses import asdict, dataclass, replace
from math import isfinite, fsum
from ..autonomous_workflow.model import wheel_force_components, signature, checked_text
from ..autonomous_workflow.family_envelope import (
    FIELDS, GEOMETRY_FIELDS, interval_product, interval_sum, _response_interval)
from ..autonomous_workflow.nbr_rolling import (
    SOURCE, lambda_from_geometry, horizontal_pairs, rolling_source_receipt)

GUIDANCE_MODEL = 'two_station_opposed_contacts'


def _require(ok, message):
    if not ok:
        raise ValueError(message)


def _interval(lo, hi):
    _require(all(type(v) in (int, float) and isfinite(v) for v in (lo, hi)) and lo <= hi,
             'Finite ordered signed interval required')
    return dict(lower=float(lo), upper=float(hi))


def _scale(values, factor):
    return interval_product(values, _interval(factor, factor))


@dataclass(frozen=True)
class NBRRollingGuidance:
    """Explicit physical guidance premises, not numerical completeness flags.

    longitudinal_bogies_present includes physical longitudinal bogies/equalizers,
    not the existing mathematical bilinear allocation of the gravity/H ledger.
    """
    guidance_model: str
    guidance_source: str
    lateral_transfer_source: str
    longitudinal_bogies_present: bool
    separate_lateral_guides_present: bool
    internal_lateral_preload_present: bool

    def validate(self):
        _require(self.guidance_model == GUIDANCE_MODEL,
                 'UNDER Rlambda requires two longitudinal stations with opposed physical contacts')
        for key in ('guidance_source', 'lateral_transfer_source'):
            checked_text(getattr(self, key), key)
        for key in ('longitudinal_bogies_present', 'separate_lateral_guides_present', 'internal_lateral_preload_present'):
            _require(getattr(self, key) is False,
                     'Simple UNDER Rlambda excludes physical bogies/equalizers, separate guides and internal lateral preloads: '+key)
        return self


def station_rolling_projection(wheels, vertical_bounds_N, lambda_receipt):
    """Per-contact triangle bounds -> exact pure-Fy station response operator.

    No vertical forces, new bimoment, height correction or additional dynamics
    are introduced. x/z mismatch cannot be represented by the paired basis.
    """
    wheels = tuple(wheels)
    _require(len(wheels) == 4 and len({w.id for w in wheels}) == 4,
             'Four distinct physical contacts on the selected runway required')
    _require(len(vertical_bounds_N) == len(wheels), 'One vertical reference bound per physical contact required')
    offsets = sorted({w.offset_mm for w in wheels})
    _require(len(offsets) == 2, 'Exactly two longitudinal station coordinates required; no names-based inference')
    lam = lambda_receipt['coefficient']
    _require(type(lam) in (int, float) and isfinite(lam) and .05 <= lam <= .20,
             'Qualified source lambda coefficient required')
    rows = []
    for station, offset in enumerate(offsets):
        ids = [i for i, w in enumerate(wheels) if w.offset_mm == offset]
        _require(len(ids) == 2, 'Exactly two real contacts per station required')
        pair = [wheels[i] for i in ids]
        _require(pair[0].offset_mm == pair[1].offset_mm and pair[0].z_mm == pair[1].z_mm and
                 pair[0].y_mm*pair[1].y_mm < 0.,
                 'Opposed contacts must share exact x and z for the station/Fy projection')
        P = [vertical_bounds_N[i] for i in ids]
        _require(all(type(p) in (int, float) and isfinite(p) and p >= 0. for p in P),
                 'Finite nonnegative physical vertical-reference bounds required; no clipping')
        H = lam*fsum(P)
        _require(isfinite(H), 'Rlambda station force overflow')
        rows.append(dict(station_index=station, offset_mm=offset, z_mm=pair[0].z_mm,
            contact_ids=[w.id for w in pair], contact_y_mm=[w.y_mm for w in pair],
            contact_Pbound_N=P, contact_Fy_absolute_bounds_N=[lam*p for p in P],
            station_Fy_absolute_bound_N=H, per_contact_basis_force_interval_N=_interval(-H/2., H/2.),
            station_Mx_interval_Nmm=_scale(_interval(-H, H), -pair[0].z_mm),
            new_Fz_N=0., new_B_Nmm2=0., equal_lateral_hardware_sharing_assumed=False,
            lateral_local_transfer_qualified=False, stability_load_radius_qualified=False,
            projection='Pure Fy at common x,z: station H/(2*A); Mx=-z*H once, independent of contact y'))
    return rows


def _qualified_factors(plan, purpose):
    from lro_beams.autonomous_actions import factors_10084
    _require(purpose in ('fatigue', 'service'), 'Explicit NBR consumer purpose fatigue or service required')
    family = 'FAT8400' if purpose == 'fatigue' else 'SLS10084'
    factors = factors_10084('fatigue_8400' if purpose == 'fatigue' else 'service_10084',
                            psi=plan['action_generation']['psi'])
    members = [m for m in plan['members'] if m['family'] == family]
    _require(bool(members), 'Regenerated '+family+' membership is absent')
    for member in members:
        c = member['case']
        expected = dict(support_dead=factors.dead_support, equipment_dead=factors.dead_equipment,
            lifted=factors.lifted if c.loaded else 0., retained_lifted=factors.lifted,
            longitudinal=factors.longitudinal, transverse=factors.transverse, extra_dead=factors.extra_dead)
        _require(all(getattr(c, key) == value for key, value in expected.items()),
                 'Regenerated '+family+' factors changed, lost retained B or include an unqualified multiplier')
    return family, factors, members


def generate_nbr_rolling_family_coefficients(project, plan, guidance, *, purpose='fatigue',
                                             service_extra_dead_factor=None):
    """Regenerate all configurations and all three two-effect pairs, no FE.

    HX/HY are selected as COMPLETE vectors, including correlated signed Fz.
    Static and service wheel references plus all relevant signed vertical H
    extrema are covered before Rlambda; Psi applies only to Q+B and only once.
    For service, support-dead baseline remains the service consumer's concern.
    """
    _require(isinstance(guidance, NBRRollingGuidance),
             'Explicit UNDER NBRRollingGuidance required; missing guidance is not zero Rlambda')
    guidance.validate()
    project.validate()
    mass = project.suspended_mass_basis()
    _require(mass.get('complete_suspended_mass_accounting') and mass.get('retained_mass_explicit'),
             'Explicit separate equipment G, removable Q and retained suspended B required, including sourced zero B')
    configs = plan['configurations']
    _require(len(configs) == 8 and len({c['id'] for c in configs}) == 8,
             'All eight hook/height/rail configurations required')
    _require(set(plan['wheels_by_configuration']) == {c['id'] for c in configs},
             'Every physical configuration needs its own contact geometry')
    family, factors, source_members = _qualified_factors(plan, purpose)
    _require({m['configuration_id'] for m in source_members} == {c['id'] for c in configs},
             'Missing configuration in regenerated NBR action membership')
    inputs = project.bridge_reaction_ledger['inputs']
    if purpose == 'service':
        _require(type(service_extra_dead_factor) in (int, float) and service_extra_dead_factor in (0., 1.),
                 'Service requires an explicit regenerated accessory baseline factor 0 or 1')
        k = inputs['horizontal_dynamic_factor']
        _require(type(k) in (int, float) and isfinite(k) and k >= 1., 'Sourced horizontal dynamics required')
        factors = replace(factors, longitudinal=1./k, transverse=1./k, extra_dead=service_extra_dead_factor)
        source_members = [dict(m, case=replace(m['case'], longitudinal=1./k, transverse=1./k,
                          extra_dead=service_extra_dead_factor)) for m in source_members]
    else:
        _require(service_extra_dead_factor is None, 'Service accessory baseline cannot modify fatigue actions')
    lam = lambda_from_geometry(inputs['bridge_span_mm'], inputs['carriage_station_spacing_mm'])
    bases = {b.id: b for b in plan['bases']}
    _require(len(bases) == len(plan['bases']), 'Repeated physical basis identity')
    template = tuple(next(iter(plan['wheels_by_configuration'].values())))
    geometry = tuple(tuple(getattr(w, k) for k in GEOMETRY_FIELDS) for w in template)
    reference_receipts, projections, generated = {}, {}, []
    # Each new pair removes an entire H event, never just its Fx/Fy component.
    for config in configs:
        ident = config['id']; wheels = tuple(plan['wheels_by_configuration'][ident])
        _require(tuple(tuple(getattr(w, k) for k in GEOMETRY_FIELDS) for w in wheels) == geometry,
                 'Rlambda contact geometry differs from the verified mechanical basis')
        offsets = sorted({w.offset_mm for w in wheels})
        _require(len(offsets) == 2 and offsets[1]-offsets[0] == inputs['carriage_station_spacing_mm'],
                 'Actual contact station separation must equal source a; never runway support span')
        rows = [m for m in source_members if m['configuration_id'] == ident]
        _require({m['case'].loaded for m in rows} == {True, False}, 'Loaded and empty operation both required')
        seen = set(); candidates = []
        for member in rows:
            original = member['case']
            for pair in horizontal_pairs():
                hx, hy = 'HX' in pair, 'HY' in pair
                key = (original.loaded, pair, original.longitudinal_sign if hx else 1, original.transverse_sign if hy else 1)
                if key in seen:
                    continue
                seen.add(key)
                pair_id = '/'.join(pair)
                c = replace(original, id=family+'/'+pair_id+'/'+('loaded' if original.loaded else 'empty')+
                    '/HX'+str(key[2])+'/HY'+str(key[3]),
                    longitudinal=original.longitudinal if hx else 0.,
                    transverse=original.transverse if hy else 0.,
                    longitudinal_sign=key[2], transverse_sign=key[3])
                forces = [wheel_force_components(w, c) for w in wheels]
                _require(all(f[2] <= 0. for f in forces), 'NBR pair includes loss of compressive contact; no zero clipping')
                candidates.append((c, pair, forces))
        refs = [[] for _ in wheels]
        # The admitted vertical reference includes both load states, static,
        # Psi service and all selected-event H signs. Maxima are not a history.
        for loaded in (True, False):
            for j, w in enumerate(wheels):
                _require(min(w.dead_N, w.lifted_N, w.retained_lifted_N) >= 0.,
                         'Nonnegative G/Q/B physical gravity origins required')
                q = w.lifted_N if loaded else 0.
                static = w.dead_N+w.retained_lifted_N+q
                dynamic = w.dead_N+factors.lifted*(w.retained_lifted_N+q)
                refs[j].extend((dict(origin='static_G+B+Q', loaded=loaded, downward_N=static),
                    dict(origin='service_G+factor*(B+Q)', loaded=loaded, factor=factors.lifted, downward_N=dynamic)))
        for c, pair, forces in candidates:
            for j, force in enumerate(forces):
                refs[j].append(dict(origin='complete_correlated_H_vector', loaded=c.loaded,
                    horizontal_pair=list(pair), case_id=c.id, downward_N=-force[2]))
        P = [max(r['downward_N'] for r in items) for items in refs]
        reference_receipts[ident] = [dict(contact_id=w.id, Pbound_N=p, admitted_references=items)
                                     for w, p, items in zip(wheels, P, refs)]
        projections[ident] = station_rolling_projection(wheels, P, lam)
        for c, pair, forces in candidates:
            raw = {}; rolling = 'Rlambda' in pair
            for station in (0, 1):
                i = 2*station
                _require(forces[i] == forces[i+1],
                         'Base inertia/gravity opposed vectors differ; no averaging of vertical torque')
                fx, fy, fz = forces[i]
                raw[f'station{station}/Fx'] = _interval(fx, fx)
                raw[f'station{station}/Fy'] = interval_sum((_interval(fy, fy),
                    projections[ident][station]['per_contact_basis_force_interval_N'])) if rolling else _interval(fy, fy)
                raw[f'station{station}/downward_Fz'] = _interval(-fz, -fz)
            raw['selfweight'] = _interval(c.support_dead, c.support_dead)
            if project.extra_dead_N_per_mm:
                raw['accessory_dead'] = _interval(c.extra_dead, c.extra_dead)
            _require(set(raw) == set(bases), 'Required physical mechanical basis missing or unexpected; recompute, never zero demand')
            coefficients = {}
            for name, values in raw.items():
                amplitude = bases[name].amplitude
                active = values['lower'] != 0. or values['upper'] != 0.
                _require(amplitude != 0. or not active,
                         'Nonzero NBR demand needs a nonzero verified mechanical basis: '+name+'; recompute this basis, never substitute zero')
                coefficients[name] = _scale(values, 1/amplitude) if amplitude else _interval(0., 0.)
            generated.append(dict(configuration_id=ident, case_id=c.id, case=asdict(c),
                horizontal_pair=list(pair), raw_coefficient_intervals=raw, coefficient_intervals=coefficients,
                physical_contact_forces_N=[dict(contact_id=w.id, force_N=list(force)) for w, force in zip(wheels, forces)],
                rolling_projection=projections[ident] if rolling else [],
                physical_H_vectors_preserved=True, rolling_adds_vertical_redistribution=False,
                Rlambda_interval_is_relaxed_not_physical_history=rolling))
    def bounds(rows):
        return {name: _interval(min(m['coefficient_intervals'][name]['lower'] for m in rows),
                                max(m['coefficient_intervals'][name]['upper'] for m in rows)) for name in bases}
    pair_rows = []
    for pair in horizontal_pairs():
        members = [m for m in generated if m['horizontal_pair'] == list(pair)]
        pair_rows.append(dict(horizontal_pair=list(pair), pair_id='/'.join(pair), members=members,
                              coefficient_intervals=bounds(members)))
    # Preserve individual wheel Fz maxima, never substitute station sum or halve.
    wheel_ranges = [[-m['physical_contact_forces_N'][i]['force_N'][2] for m in generated] for i in range(len(template))]
    wheels = [dict(contact_index=i, **{k:getattr(w, k) for k in GEOMETRY_FIELDS},
        downward_N=_interval(min(wheel_ranges[i]), max(wheel_ranges[i]))) for i, w in enumerate(template)]
    payload = dict(schema='UNDER_NBR_NORMAL_ROLLING_FAMILY_V1', purpose=purpose, family=family,
        consumer_scope='nominal_D5_linear_response_only' if purpose == 'fatigue' else 'service_linear_response_only',
        pairs=pair_rows, wheel_vertical_actions=wheels, reference_receipts=reference_receipts,
        station_projections=projections, lambda_receipt=lam, source=SOURCE,
        source_receipt=rolling_source_receipt(), physical_guidance=asdict(guidance),
        total_configuration_count=8, total_case_count=len(generated), original_family_member_count=len(source_members),
        regenerated_factors=asdict(factors), suspended_mass_accounting=mass,
        reference_policy=('Conservative maximum of static/service G+B+Q and every admitted complete-H vertical reaction across loaded/empty states; Psi only on B+Q, no Mx, no second Psi on Rlambda'
            if purpose == 'fatigue' else 'Static G+B+Q and all admitted complete signed H/kH vertical reactions across loaded/empty states; no Psi, no Mx and no horizontal dynamic amplification; no fatigue maximum reused'),
        configuration_enclosure='Bilinear hook/height force vectors lie in the corner hull; per-contact maxima and sums are convex, so the corner station bounds enclose interior configurations. Independent station signs are a sufficient relaxation, not a physical history.',
        max_absolute_normalized_coefficient=max(abs(v) for m in generated for row in m['coefficient_intervals'].values() for v in row.values()),
        coefficient_magnification_allowed_with_scaled_verification_allowances=True,
        Mx_applied=False, additional_psi_on_Rlambda=False, new_rolling_vertical_redistribution=False,
        horizontal_inertia_dynamic_removed=purpose == 'service',
        original_H_multiplier_removed_once=inputs['horizontal_dynamic_factor'] if purpose == 'service' else None,
        equal_lateral_hardware_sharing_assumed=False, local_lateral_transfer_qualified=False,
        stability_load_radius_qualified=False, stability_consumer_authorized=False,
        reused_CMAA_SK_or_exceptional_SHE=False, temporal_histories_created=0, repeated_FE_sweeps=0)
    return dict(**payload, receipt_signature=signature(payload))


def compose_nbr_rolling_response_box(plan, evidence, coefficients):
    """Multiply COMPLETE verified response intervals, allowances included.

    Coefficients can exceed one. Neither demand nor verification allowance is
    clipped to the original binary normalization. Missing bases never mean zero.
    """
    bases = {b.id: b for b in plan['bases']}
    _require(set(coefficients) == set(bases), 'Complete physical coefficient set required')
    result = {}
    for field in FIELDS:
        terms = []
        for name, coefficient in coefficients.items():
            coefficient = _interval(coefficient['lower'], coefficient['upper'])
            if coefficient['lower'] == coefficient['upper'] == 0.:
                continue
            _require(bases[name].amplitude != 0. and name in evidence,
                     'Nonzero NBR demand requires verified nonzero mechanical basis '+name)
            verification = evidence[name]['verification']
            terms.append(interval_product(coefficient,
                _response_interval(verification['refined_extrema'], field, verification)))
        result[field] = interval_sum(terms)
    return result
