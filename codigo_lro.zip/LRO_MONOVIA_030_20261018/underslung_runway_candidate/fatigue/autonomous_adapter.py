"""Internal physical-input -> EN2025 nominal sufficient fatigue assessment.
No external stresses, caller proof receipts or user-set numerical pass flags.
"""
from dataclasses import dataclass,asdict
from math import sqrt,isclose
from ..autonomous_workflow.model import MovingCase,finite,signature,wheel_force_components,checked_text
from ..autonomous_workflow.pipeline import AnalysisControls,analyze_cases,source_receipt
from ..global_response.numerical_producer import verify_moving_response
from ..section_stress.recovery import geometric_properties,bottom_flange_points
from ..section_stress.whole_section_bounds import whole_section_shear_bound
from ..local_flange.kernel import Geometry
from .nominal_local import NominalLocalInputs,direct_design_box,compose_nominal_tensor
from .en2025 import EN2025Inputs,evaluate

class SufficientContactDomainError(ValueError):
    pass

FIELDS=('N','My','Mz','B_equilibrated','Fy','Fz','Tsv','Tw_equilibrated')
@dataclass(frozen=True)
class ENPhysicalFatigueInputs:
    dynamic_equipment: float
    dynamic_lifted: float
    action_source: str
    fixed_train_operating_limit_source: str
    detail_delivery: str # EN10163-3_C3_no_weld_repair
    detail_condition_source: str
    environment: str # normal_atmosphere_maintained_no_galvanizing_no_weathering
    environment_source: str
    execution_source: str
    nominal_method_adoption_source: str
    assessed_plain_region_condition: str # assessed ordinary plain regions ONLY, not holes/connections/disturbed regions
    vertical_operating_model: str
    minimum_equipment_gravity: float|None=None
    minimum_lifted_gravity: float|None=None
    minimum_gravity_source: str=''
    gamma_ff: float=1.
    gamma_mf: float=1.35
    gamma_mser: float=1.
    def validate(self):
        for k in ('dynamic_equipment','dynamic_lifted','gamma_ff','gamma_mf','gamma_mser'):
            if finite(getattr(self,k),k)<(1.35 if k=='gamma_mf' else 1.):raise ValueError('Insufficient conservative factor: '+k)
        for k in ('action_source','fixed_train_operating_limit_source','detail_condition_source','environment_source','execution_source','nominal_method_adoption_source'):
            checked_text(getattr(self,k),'Physical adoption source '+k)
        if self.assessed_plain_region_condition!='ordinary_unmodified_undamaged_rolled_plain_regions_excluding_discontinuities':raise ValueError('Explicit ordinary unmodified undamaged rolled plain-region condition required; holes, attachments, splices, net sections and disturbed connection regions remain separate')
        if self.detail_delivery!='EN10163-3_C3_no_weld_repair':raise ValueError('Only sound ordinary rolled C3/no-weld-repair detail implemented')
        if self.environment!='normal_atmosphere_maintained_no_galvanizing_no_weathering':raise ValueError('Environment/detail reduction outside implemented scope')
        checked_text(self.minimum_gravity_source,'Minimum dynamic gravity source/model',required=False)
        gravity_minima(self)
        return self

def gravity_minima(p):
    if p.vertical_operating_model=='quasistatic_suspended_gravity_plus_horizontal':
        if p.minimum_equipment_gravity is not None or p.minimum_lifted_gravity is not None:raise ValueError('Quasistatic preset derives minimum factors; do not supply conflicting overrides')
        return dict(equipment=.95,lifted=1.,source='EN13001-2 4.2.2.1 equipment vibration minimum phi1=.95, fatigue partial factor1; explicitly adopted quasistatic suspended payload gravity plus horizontal manoeuvres',scope='Excludes arbitrary downward hoist acceleration, release and reversal')
    if p.vertical_operating_model!='source_bounded_vertical_dynamics':raise ValueError('Explicit supported vertical operating model required')
    checked_text(p.minimum_gravity_source,'Minimum dynamic gravity source/model')
    for name,maximum in [('minimum_equipment_gravity',p.dynamic_equipment),('minimum_lifted_gravity',p.dynamic_lifted)]:
        v=finite(getattr(p,name),name)
        if not 0<=v<=maximum:raise ValueError('Minimum gravity factor outside [0,maximum]: '+name)
    return dict(equipment=p.minimum_equipment_gravity,lifted=p.minimum_lifted_gravity,source=p.minimum_gravity_source,scope='Explicit source-bounded vertical dynamics, no minimum inferred from maxima')

def basis_cases(physical,*,horizontal_scale=1.):
    physical.validate();horizontal_scale=finite(horizontal_scale,'Horizontal source multiplier')
    if horizontal_scale<=0:raise ValueError('Positive horizontal source multiplier required')
    out=[]
    specs=[('PERMANENT',1,0,0,0,0,True,1),('G',0,physical.dynamic_equipment,0,0,0,True,0),('Q',0,0,physical.dynamic_lifted,0,0,True,0),('B',0,0,0,0,0,True,0),
           ('HX_LOADED',0,0,0,1,0,True,0),('HY_LOADED',0,0,0,0,1,True,0),('HX_EMPTY',0,0,0,1,0,False,0),('HY_EMPTY',0,0,0,0,1,False,0)]
    for name,s,g,q,hx,hy,loaded,extra in specs:
        out.append(MovingCase('EN2025_BASIS_'+name,'EN_LINEAR_BASIS',s,g,q,hx*horizontal_scale,hy*horizontal_scale,1,1,loaded,
            physical.action_source+'; linear basis '+name+'; horizontal multiplier '+str(horizontal_scale)+' applied to entire correlated H vector once; gammaFf excluded',extra,
            retained_lifted=physical.dynamic_lifted if name=='B' else 0.))
    return tuple(out)

def horizontal_source_policy(project):
    ledger=project.bridge_reaction_ledger
    if ledger and ledger.get('schema')=='LRO_BOUND_BRIDGE_INERTIA_LEDGER_V1':
        k=finite(ledger['inputs']['horizontal_dynamic_factor'],'Input horizontal factor')
        if k<1:raise ValueError('Invalid inertia-ledger horizontal factor')
        return dict(multiplier=5./k,input_horizontal_factor=k,derived_rigid_effect_factor=5.,
            source='EN13001-2 4.2.2.5: S=Si+phi5(Sf-Si), |Si|,|Sf|<=Smax, 1<=phi5<=3 implies |S|<=5Smax',
            premise='Supplied absolute bridge/trolley accelerations bound initial and final rigid-drive effects in the declared normal operating domain',
            application='Divide inherited factor once and apply5 to complete HX/HY vectors, including vertical redistribution; known-maximum nominal structural fatigue box, not a simplified equivalent spectrum or rolling-contact fatigue rule',
            conditional_manual_force_input=False)
    return dict(multiplier=1.,input_horizontal_factor=None,derived_rigid_effect_factor=None,
        source='Explicit source-bounded physical wheel H input, not automatically EN-qualified by any NBR/default factor',
        premise='Wheel H input provenance and physical EN action source must genuinely bound actual horizontal dynamics',
        application='Supplemental conditional force-input route; autonomous mass/acceleration route does not require external efforts',
        conditional_manual_force_input=True)

def _hvertical(w,axis,loaded):
    key=('longitudinal' if axis=='x' else 'transverse')+'_vertical'
    v=getattr(w,key+'_N',0.)
    empty=getattr(w,key+'_empty_N',None)
    return v if loaded or empty is None else empty

def physical_domain(project,p):
    project.validate();p.validate();s=project.section;minimum=gravity_minima(p);horizontal=horizontal_source_policy(project);hscale=horizontal['multiplier']
    affine_payload=bool(project.bridge_reaction_ledger and project.bridge_reaction_ledger.get('schema')=='LRO_BOUND_BRIDGE_INERTIA_LEDGER_V1')
    if s.construction!='rolled' or not s.doubly_symmetric or s.bottom_root_radius_mm<=0:raise ValueError('Ordinary symmetric rounded as-rolled section required')
    if project.fy_mpa is None:raise ValueError('Actual material fy required')
    if project.travel_min_mm is None:raise ValueError('Physical travel/endstop limits required')
    end=min(min(project.travel_min_mm+w.offset_mm,project.length_mm-project.travel_max_mm-w.offset_mm) for w in project.wheels)
    if end<=s.bottom_width:raise ValueError('Physical wheel path enters local end-transition domain')
    gauges={round(s.bottom_width/2-abs(w.y_mm),10) for w in project.wheels}
    if len(gauges)!=1:raise ValueError('First automatic source envelope requires common opposed contact gauge')
    gauge=next(iter(gauges));groups={}
    for w in project.wheels:groups.setdefault(w.offset_mm,[]).append(w)
    wheel_max={};contact=[]
    for offset,ws in groups.items():
        if len(ws)!=2 or ws[0].y_mm*ws[1].y_mm>=0:raise ValueError('Exactly two opposed wheels per station required')
        a,b=ws
        for k in ('dead_N','lifted_N','retained_lifted_N'):
            if not isclose(getattr(a,k),getattr(b,k),rel_tol=1e-10,abs_tol=1e-8):raise ValueError('Unequal opposed vertical wheel loads outside nominal local source domain')
        for loaded in (False,True):
            for axis in ('x','y'):
                if not isclose(_hvertical(a,axis,loaded),_hvertical(b,axis,loaded),rel_tol=1e-10,abs_tol=1e-8):raise ValueError('Unequal opposed inertia redistribution outside local source domain')
        for w in ws:
            for loaded in (False,True):
                # Actual endpoints, not artificial zero-G/H basis contact states.
                # A regenerated point-mass bridge ledger establishes affine
                # payload gravity/inertia correlation. Manual force-only input
                # lacks that proof; retain a conservative no-payload-credit guard.
                down=minimum['equipment']*w.dead_N+minimum['lifted']*w.retained_lifted_N+(minimum['lifted']*w.lifted_N if loaded and affine_payload else 0.)
                inertia=hscale*(abs(_hvertical(w,'x',loaded))+abs(_hvertical(w,'y',loaded)))
                contact.append(dict(wheel_id=w.id,loaded=loaded,minimum_compressive_N=down-inertia))
                if down<inertia:raise SufficientContactDomainError('Sufficient compression-contact guard inconclusive under sourced minimum gravity and maximum H; not proof of actual lift-off')
            wheel_max[w.id]=w.dead_N*p.dynamic_equipment+(w.lifted_N+w.retained_lifted_N)*p.dynamic_lifted+hscale*sum(max(abs(_hvertical(w,a,l)) for l in (False,True)) for a in ('x','y'))
    all8=[]
    if project.bridge_reaction_ledger is not None:
        from ..autonomous_workflow.inertia_bridge_adapter import physical_case_contact_audit
        for loaded in (False,True):
            for hx in (-1,1):
                for hy in (-1,1):
                    case=MovingCase('EN_CONTACT_DOMAIN','EN_CONTACT_DOMAIN',1,minimum['equipment'],minimum['lifted'],hscale,hscale,hx,hy,loaded,'Correlated payload endpoint: sourced minimum G/Q, matching maximum H; retained hoist mass remains SL in empty state; contact sufficient guard only',1,retained_lifted=minimum['lifted'])
                    audit=physical_case_contact_audit(project.bridge_reaction_ledger,case)
                    if audit is None or not audit['no_hold_down_contact_valid']:raise SufficientContactDomainError('Complete bridge sufficient contact guard inconclusive/unavailable; not observed physical lift-off')
                    all8.append(audit)
    eps=sqrt(235/project.fy_mpa)
    cf=(s.bf_mm-s.tw_mm)/(2*s.tf_mm);cw=(s.d_mm-2*s.tf_mm)/s.tw_mm
    if cf>14*eps or cw>38*eps:raise ValueError('Conservative class1-3 uniform-compression gate not satisfied')
    return dict(gauge_mm=gauge,min_physical_end_distance_mm=end,wheel_max_N=wheel_max,contact_endpoints=contact,
                class_gate=dict(flange_ratio=cf,flange_limit=14*eps,web_ratio=cw,web_limit=38*eps),
                fixed_train_scope=p.fixed_train_operating_limit_source,suspended_mass_accounting=project.suspended_mass_basis(),
                lifted_dynamic_domain='Declared source maximum applies to all hoist load SL=B+payload; B remains in empty state, with its own physical point and independent stress-box coefficient; not an inferred universal pick-up factor',complete_bridge_contact_audits=all8,gravity_minima=minimum,horizontal_source_policy=horizontal,
                contact_correlation='Regenerated bridge point-mass affine empty/full payload endpoints' if affine_payload else 'Manual force-only train: conservative no-payload stabilizing credit; failure is inconclusive')

def _sum_basis(evidence):
    result={k:[0.,0.] for k in FIELDS}
    for name,e in evidence.items():
        for k in FIELDS:
            lo=e['refined_extrema'][k]['min']['value'];hi=e['refined_extrema'][k]['max']['value']
            if name.endswith('PERMANENT'):a,b=lo,hi
            elif name.endswith(('_G','_Q','_B')):a,b=min(0.,lo),max(0.,hi)
            else:a,b=-max(abs(lo),abs(hi)),max(abs(lo),abs(hi))
            result[k][0]+=a;result[k][1]+=b
    return {k:tuple(v) for k,v in result.items()}

def _linear(bounds,terms):
    lo=hi=0.
    for k,c in terms:
        a,b=bounds[k];lo+=min(c*a,c*b);hi+=max(c*a,c*b)
    return lo,hi

def evaluate_autonomous_fatigue(project,*,physical,controls=None,progress=None):
    """Compute all evidence internally. Missing physical data raises ValueError.
    Numerical evidence unavailable returns pending, not failure or a false pass.
    """
    if not isinstance(physical,ENPhysicalFatigueInputs):raise ValueError('Explicit physical EN fatigue input record required')
    try:domain=physical_domain(project,physical)
    except SufficientContactDomainError as exc:
        return dict(status='CONTACT_DOMAIN_SUFFICIENT_GUARD_INCONCLUSIVE',qualified_nominal_detail_modes=False,point_results=[],
            pending=[str(exc)],physical_inputs=asdict(physical),external_efforts_required=False,whole_design_complete=False,
            contact_complete=False,connection_complete=False,physical_unlimited_life_claim=False)
    cases=basis_cases(physical,horizontal_scale=domain['horizontal_source_policy']['multiplier'])
    # An exactly zero linear RHS has exactly zero response without an FE solve.
    # This is derived from physical parcels, not a user convergence checkbox.
    zero_cases=[];active=[]
    for case in cases:
        forces=[wheel_force_components(w,case) for w in project.wheels]
        zero=(project.selfweight()*case.support_dead==0 and project.extra_dead_N_per_mm*case.extra_dead==0 and all(all(v==0 for v in f) for f in forces))
        (zero_cases if zero else active).append(case)
    run=analyze_cases(project,active,controls=controls,progress=progress)
    base=dict(method='EN2025_SOURCE_PRESCRIBED_NOMINAL_AUTONOMOUS',external_efforts_required=False,physical_inputs=asdict(physical),
        physical_domain=domain,project_signature=signature(project.to_dict()),basis_cases=[asdict(c) for c in cases],source_receipt=run['source'],source_after=run.get('source_after'),
        whole_design_complete=False,contact_complete=False,connection_complete=False,physical_unlimited_life_claim=False,
        assessed_region='Ordinary plain nominal rolled regions: separate top/web global check and lower-flange global-plus-local check; no discontinuity/connection approval',
        assessed_regions=['Plain top flange and web: global nominal effects','Plain lower flange root/wheel/edge: global plus prescribed local effects'],
        excluded_regions=['Upper-flange bolt holes and suspension connection details','Local net-section/load-introduction regions not represented by this nominal model','Wheel Hertz/rolling-contact field'])
    pending=[];evidence={}
    for case in zero_cases:
        evidence[case.id]=dict(evidence_kind='exact_zero_linear_RHS',refined_extrema={k:{'min':{'value':0.},'max':{'value':0.}} for k in FIELDS},
            producer_receipt=dict(proof='Every physical load parcel and UDL is exactly zero in fixed linear model',case=asdict(case),project_signature=signature(project.to_dict())))
    if not run['source_unchanged_during_calculation']:pending.append('Source changed during basis computation')
    incomplete=[r for r in run['cases'] if not r['numerical_converged'] or r['sweep'] is None]
    if incomplete or not run['source_unchanged_during_calculation']:
        pending.extend(r['case']['id']+': '+(r['error'] or 'Moving/spatial/mesh convergence not established') for r in incomplete)
        return dict(base,status='NUMERICAL_EVIDENCE_PENDING',pending=pending,qualified_nominal_detail_modes=False,point_results=[],numerical_evidence=evidence,
            basis_run_summary=[dict(case=r['case']['id'],numerical_converged=r['numerical_converged'],error=r['error'],mesh_history=r['mesh_history'],moving_history=None if r['sweep'] is None else r['sweep']['history']) for r in run['cases']])
    for case,row in zip(active,run['cases']):
        if progress:progress(dict(stage='fatigue_fixed_FE_verification',case_id=case.id))
        scan=row['sweep']
        if not row['numerical_converged'] or scan is None:
            pending.append(case.id+': '+(row['error'] or 'Moving/spatial/mesh convergence not established'));continue
        model=project.frame_model(row['mesh_history'][-1]['max_element_length_mm'])
        e=verify_moving_response(model,project.wheels,case,scan,selfweight=project.selfweight(),extra_dead=project.extra_dead_N_per_mm,
            observation_points=scan['spatial_base_stations_mm'],mesh_converged=row['numerical_converged'],mesh_history=row['mesh_history'],
            extra_dead_y_mm=project.extra_dead_y_mm or 0.,fields=FIELDS)
        evidence[case.id]=e
        if e['evidence_kind']!='fixed_FE_extrema_mesh_converged':pending.extend(case.id+': '+v for v in e['pending'])
    base['numerical_evidence']=evidence
    base['basis_run_summary']=[dict(case=r['case']['id'],numerical_converged=r['numerical_converged'],error=r['error'],mesh_history=r['mesh_history']) for r in run['cases']]
    if pending or len(evidence)!=len(cases):return dict(base,status='NUMERICAL_EVIDENCE_PENDING',pending=pending,qualified_nominal_detail_modes=False,point_results=[])
    bounds=_sum_basis(evidence);s=project.section;props=geometric_properties(s)
    shear=whole_section_shear_bound(s,**{n:max(abs(x) for x in bounds[k]) for n,k in [('abs_Fy_N','Fy'),('abs_Fz_N','Fz'),('abs_Tsv_Nmm','Tsv'),('abs_Tw_Nmm','Tw_equilibrated')]})
    tau=shear['tau_bound_mpa'];local={}
    g=Geometry(s.bottom_width,s.tw_mm,s.bottom_thickness,domain['gauge_mm'],'rolled',s.bottom_root_radius_mm)
    ledger='Horizontal source: '+domain['horizontal_source_policy']['source']+'; '+domain['horizontal_source_policy']['premise']+'; Independent linear coefficient-box: fixed permanent; G, payload Q and retained suspended B independently in[0,declared source maximum dynamics]; each loaded/empty H in[-1,1]; includes actual endpoints and all frequent reductions without favorable psi; no equivalent fatigue spectrum.'
    receipt=signature(dict(evidence={k:v['producer_receipt'] for k,v in evidence.items()},domain=domain,physical=asdict(physical)))
    for side in ('left','right'):
        forces=tuple(domain['wheel_max_N'][w.id] for w in project.wheels if (w.y_mm<0)==(side=='left'))
        local[side]=direct_design_box(NominalLocalInputs(g,forces,domain['min_physical_end_distance_mm'],True,ledger,s.signature,receipt,True))
    results=[]
    for pt in bottom_flange_points(s,domain['gauge_mm']):
        sx=_linear(bounds,[('N',1/props['A_mm2']),('My',pt.z_mm/props['Iy_mm4']),('Mz',-pt.y_mm/props['Iz_mm4']),('B_equilibrated',pt.omega_mm2/props['Cw_mm6'])])
        globalbox=dict(sx=sx,sy=(0.,0.),sz=(0.,0.),txy=(-tau,tau),txz=(-tau,tau),tyz=(0.,0.))
        composed=compose_nominal_tensor(globalbox,local[pt.outstand_side],same_point_and_ledger_confirmed=True,source_model_adopted=True)
        box=composed['intervals_mpa']
        data=EN2025Inputs(box,box,box,project.fy_mpa,physical.gamma_ff,physical.gamma_mf,physical.gamma_mser,
            pt.id+'; eligible ordinary nominal regions across verified spatial grid',ledger,receipt,True,True,True,True,True,True,True,True)
        result=evaluate(data);result['point']=asdict(pt);result['composition']=composed;results.append(result)
    lower_ok=all(r['qualified_nominal_detail_modes'] for r in results)
    # Whole ordinary plain section: conservative linear normal-stress bound.
    # No inference from lower-face stress to top/web stress, and no assumption
    # that independent moment/resultant extrema occur together is needed.
    zmax=max(props['centroid_from_bottom_mm'],s.d_mm-props['centroid_from_bottom_mm'])
    ymax=s.bf_mm/2;omax=max(abs(pt.omega_mm2) for pt in bottom_flange_points(s,domain['gauge_mm']))
    normal_extra=sum(max(abs(v) for v in bounds[k])*c for k,c in [('My',zmax/props['Iy_mm4']),('Mz',ymax/props['Iz_mm4']),('B_equilibrated',omax/props['Cw_mm6'])])
    nlo,nhi=_linear(bounds,[('N',1/props['A_mm2'])])
    plainbox=dict(sx=(nlo-normal_extra,nhi+normal_extra),sy=(0.,0.),sz=(0.,0.),txy=(-tau,tau),txz=(-tau,tau),tyz=(0.,0.))
    plain_global=evaluate(EN2025Inputs(plainbox,plainbox,plainbox,project.fy_mpa,physical.gamma_ff,physical.gamma_mf,physical.gamma_mser,
        'Ordinary plain-section top/web global nominal regions over verified spatial grid',ledger,receipt,True,True,True,True,True,True,True,True))
    plain_global['scope']='Whole plain-section global nominal envelope; top/web covered; bottom local effects assessed separately; excludes holes, net sections, connections and locally disturbed regions'
    plain_global['tensor_box_mpa']=plainbox
    plain_global['normal_bound_coefficients']=dict(zmax_mm=zmax,ymax_mm=ymax,omega_max_mm2=omax)
    mass_complete=domain['suspended_mass_accounting']['complete_suspended_mass_accounting']
    ok=lower_ok and plain_global['qualified_nominal_detail_modes'] and mass_complete
    final_source=source_receipt()
    if final_source['fingerprint']!=run['source']['fingerprint']:
        return dict(base,status='NUMERICAL_EVIDENCE_PENDING',qualified_nominal_detail_modes=False,point_results=[],
            pending=['Numerical dependencies changed during fixed-FE verification or final fatigue composition; recompute'],
            final_source_receipt=final_source,plain_global_result=None,lower_local_result=None)
    base['final_source_receipt']=final_source
    return dict(base,status=('PHYSICAL_MASS_ACCOUNTING_PENDING' if not mass_complete else 'NOMINAL_METHOD_ZERO_CALCULATED_DAMAGE_SUFFICIENT' if ok else 'SUFFICIENT_CHECK_NOT_SATISFIED'),
        qualified_nominal_detail_modes=ok,point_results=results,
        lower_local_result=dict(qualified_nominal_detail_modes=lower_ok,point_results=results,scope='Prescribed lower-flange global-plus-local nominal details only'),
        plain_global_result=plain_global,resultant_domain_bounds=bounds,whole_nominal_shear=shear,
        local_source_boxes=local,action_domain_ledger=ledger,producer_receipt=receipt,pending=[] if mass_complete else ['Retained suspended mass and its physical application point are not explicitly bound; diagnostic stresses do not qualify complete operating fatigue'],
        spatial_scope='Prescribed bottom-flange nominal points over complete verified finite spatial grid; actual disturbed/net-section and connection regions excluded; engineering numerical convergence, not continuum theorem')
