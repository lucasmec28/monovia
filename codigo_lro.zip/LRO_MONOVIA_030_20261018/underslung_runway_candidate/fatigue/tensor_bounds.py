"""Finite conservative 3-D symmetric tensor box bounds. No fatigue category."""
from math import isfinite, sqrt
import numpy as np

def _finite(v):
    try:return isfinite(v)
    except (OverflowError,TypeError,ValueError):return False

COMPONENTS=('sx','sy','sz','txy','txz','tyz')

def _matrix(v):
    x,y,z,xy,xz,yz=v
    return np.array(((x,xy,xz),(xy,y,yz),(xz,yz,z)),float)

def tensor_box_bounds(intervals):
    if set(intervals)!=set(COMPONENTS):raise ValueError('All six physical tensor components are required')
    width=[];absolute=[]
    for k in COMPONENTS:
        v=intervals[k]
        if v is None or len(v)!=2:raise ValueError('Missing component, not equivalent to zero')
        a,b=v
        if any(isinstance(t,bool) or not isinstance(t,(int,float)) or not _finite(t) for t in v) or a>b:raise ValueError('Invalid component interval')
        w=b-a
        if not _finite(w):raise ValueError('Range overflow')
        width.append(w);absolute.append(max(abs(a),abs(b)))
    # |v.T A v| <= |v|.T |A| |v| <= lambda_max(B) for |Aij|<=Bij.
    # Applied to the difference tensor, Weyl bounds each ordered principal range.
    def spectral(v):
        s=max(v)
        if s==0:return 0.
        bound=float(np.linalg.eigvalsh(_matrix([x/s for x in v]))[-1])*s
        if not _finite(bound):raise ValueError('Spectral bound overflow')
        return bound
    r=spectral(width);a=spectral(absolute)
    return dict(principal_range_mpa=r,fixed_plane_normal_range_mpa=r,
                fixed_plane_shear_range_mpa=r,absolute_principal_mpa=a,
                absolute_fixed_plane_shear_mpa=a,
                component_widths_mpa=dict(zip(COMPONENTS,width)),
                proof='Entrywise absolute symmetric matrix majorant; Rayleigh quotient and Weyl',
                category_assigned=False)
