"""Independent EN2025 fatigue consumer of verified physical linear bases.

The original family producer happens to use NBR action combinations to select
its basis amplitudes. Neither those combinations nor their response boxes enter
this EN consumer. Every EN force coefficient is regenerated from the physical
bridge model; the unchanged FE basis responses are linear mechanical evidence.
No FE sweep is repeated and no prior numerical calculation is re-signed.

Only the adopted ordinary plain-section nominal fatigue modes can qualify.
Contact, connections, disturbed regions and whole-beam approval remain separate.
"""
from dataclasses import asdict, replace
from itertools import product
from pathlib import Path
import hashlib
import math

from .autonomous_adapter import (ENPhysicalFatigueInputs, SufficientContactDomainError,
                                 physical_domain)
from .en2025 import EN2025Inputs, evaluate
from .nominal_local import NominalLocalInputs, direct_design_box, compose_nominal_tensor
from ..autonomous_workflow.family_envelope import (FIELDS, GEOMETRY_FIELDS, _source,
    _response_interval, interval_product, interval_sum)
from ..autonomous_workflow.inertia_bridge_adapter import make_ledger
from ..autonomous_workflow.model import MovingCase, PhysicalWheel, signature, wheel_force_components
from ..local_flange.kernel import Geometry
from ..section_stress.recovery import geometric_properties, bottom_flange_points
from ..section_stress.whole_section_bounds import whole_section_shear_bound
from ..stability.family_adapter import validate_family_receipt


def _require(condition, message):
    if not condition:
        raise ValueError(message)


def consumer_source_receipt():
    """Separate dependency closure; never alters the original FE source receipt."""
    root = Path(__file__).resolve().parents[1]
    files = {name: hashlib.sha256((root/name).read_bytes()).hexdigest()
             for name in ('fatigue/family_adapter.py', 'stability/family_adapter.py')}
    payload = dict(original_basis_dependencies=_source(), consumer_files=files)
    return dict(**payload, fingerprint=signature(payload))


def _raw_coefficients(wheels, case, extra_dead):
    result = {}
    for station in (0, 1):
        a, b = (wheel_force_components(wheels[2*station+j], case) for j in (0, 1))
        _require(a == b, 'EN opposed-wheel force vectors differ; no inferred averaging')
        for field, value in zip(('Fx', 'Fy', 'downward_Fz'), (a[0], a[1], -a[2])):
            _require(math.isfinite(value), 'Nonfinite derived EN physical force')
            result[f'station{station}/{field}'] = value
    result['selfweight'] = 1.
    if extra_dead:
        result['accessory_dead'] = 1.
    return result


def _normalise_corners(corners, bases):
    """Use actual original N-per-contact amplitudes, not station resultants.

    Coefficients need not remain <=1: every numerical verification allowance is
    multiplied by its actual EN coefficient magnitude during interval recovery.
    A zero/absent basis can never be used to represent a nonzero EN force.
    """
    definitions = {b.id: b for b in bases}
    _require(len(definitions) == len(bases), 'Repeated physical basis identity')
    _require(bool(corners), 'No EN physical action corners')
    expected = set(corners[0]['raw_coefficients'])
    _require(set(definitions) == expected, 'EN physical action needs an absent or substituted basis')
    for row in corners:
        _require(set(row['raw_coefficients']) == expected, 'Incomplete EN action corner')
        normalized = {}
        for key, raw in row['raw_coefficients'].items():
            scale = definitions[key].amplitude
            _require(math.isfinite(scale) and scale >= 0., 'Invalid original physical basis amplitude')
            _require(scale != 0. or raw == 0., 'Zero original basis cannot represent nonzero EN force: '+key)
            coefficient = raw/scale if scale else 0.
            _require(math.isfinite(coefficient) and coefficient*scale == raw,
                     'EN force cannot be reconstructed in original physical amplitude units: '+key)
            normalized[key] = coefficient
        row['coefficients'] = normalized
    intervals = {}
    for key, basis in definitions.items():
        low = min(corners, key=lambda r: r['coefficients'][key])
        high = max(corners, key=lambda r: r['coefficients'][key])
        intervals[key] = dict(lower=low['coefficients'][key], upper=high['coefficients'][key],
            original_basis_amplitude=basis.amplitude,
            coefficient_abs_max=max(abs(low['coefficients'][key]), abs(high['coefficients'][key])),
            lower_corner_id=low['id'], upper_corner_id=high['id'],
            exact_zero_coefficient_domain=basis.amplitude == 0.)
    return intervals


def _en_domain(project, physical, plan):
    """Regenerate all EN action corners and REAL minimum-gravity contact guards.

    The artificial G=0/Q=0 stress-box vertices are not physical contact cases.
    For each of eight hook/height/rail configurations, physical_domain checks
    sourced minimum gravity against correlated empty/full H vectors at all eight
    bridge contacts. Point-mass affinity covers intermediate payload fractions;
    bilinear corner interpolation covers intermediate hook position and height.
    """
    _require(isinstance(physical, ENPhysicalFatigueInputs), 'Explicit physical EN fatigue input record required')
    physical.validate()
    _require(project.suspended_mass_basis()['complete_suspended_mass_accounting'], 'Explicit retained suspended mass B and physical application point required; legacy empty state is incomplete')
    corners, domains, maxima = [], [], {}
    templates = next(iter(plan['wheels_by_configuration'].values()))
    for configuration in plan['configurations']:
        ident = configuration['id']
        ledger = make_ledger(project.section, project.bridge_reaction_ledger['inputs'], ident)
        wheels = plan['wheels_by_configuration'][ident]
        selected = replace(project, bridge_reaction_ledger=ledger,
                           wheels=[PhysicalWheel(**w) for w in ledger['selected_configuration']['wheels']])
        try:
            domain = physical_domain(selected, physical)
        except SufficientContactDomainError as exc:
            raise SufficientContactDomainError(ident+': '+str(exc)) from exc
        policy = domain['horizontal_source_policy']
        _require(policy['conditional_manual_force_input'] is False and policy['derived_rigid_effect_factor'] == 5.,
                 'Internally regenerated EN whole-vector reversal domain required')
        hscale = policy['multiplier']
        domains.append(dict(configuration_id=ident, physical_domain=domain))
        for index, wheel in enumerate(wheels):
            value = domain['wheel_max_N'][wheel.id]
            if index not in maxima or value > maxima[index]['max_downward_N']:
                maxima[index] = dict(contact_index=index, max_downward_N=value,
                    bounding_configuration_id=ident,
                    **{key: getattr(wheel, key) for key in GEOMETRY_FIELDS})
        # This separate EN coefficient domain NEVER reads plan['members'] or
        # any original family bounds/factors. The binary choices independently
        # include zero and each physically sourced maximum, with gammaFf absent.
        for loaded, gmax, qmax, bmax, hx, hy in product((False, True), (False, True),
                                                (False, True), (False, True), (-1, 1), (-1, 1)):
            cid = ident+f'/loaded{int(loaded)}/G{int(gmax)}/Q{int(qmax)}/B{int(bmax)}/HX{hx}/HY{hy}'
            case = MovingCase(cid, 'EN2025_INDEPENDENT_PHYSICAL_DOMAIN', 1.,
                physical.dynamic_equipment if gmax else 0., physical.dynamic_lifted if qmax else 0.,
                hscale, hscale, hx, hy, loaded,
                physical.action_source+'; full correlated H5 reversal vector; G/Q/B independent physical maxima or zero; retained B remains at its own point; gammaFf excluded', 1.,
                retained_lifted=physical.dynamic_lifted if bmax else 0.)
            corners.append(dict(id=cid, configuration_id=ident, case=asdict(case),
                raw_coefficients=_raw_coefficients(wheels, case, project.extra_dead_N_per_mm)))
    _require(len(domains) == 8 and len(corners) == 512, 'Incomplete eight-configuration EN physical coefficient domain')
    common = domains[0]['physical_domain']
    for row in domains:
        d = row['physical_domain']
        for key in ('gauge_mm', 'min_physical_end_distance_mm', 'class_gate', 'horizontal_source_policy', 'gravity_minima'):
            _require(d[key] == common[key], 'EN configurations do not share fixed geometry/action policy: '+key)
    intervals = _normalise_corners(corners, plan['bases'])
    return dict(configuration_count=8, coefficient_corner_count=len(corners),
        configuration_domains=domains, coefficient_corners=corners, coefficient_intervals=intervals,
        wheel_maxima_by_geometry=[maxima[i] for i in range(len(templates))],
        gauge_mm=common['gauge_mm'], min_physical_end_distance_mm=common['min_physical_end_distance_mm'],
        horizontal_source_policy=common['horizontal_source_policy'], gravity_minima=common['gravity_minima'],
        physical_EN_inputs=asdict(physical), suspended_mass_accounting=project.suspended_mass_basis(), original_NBR_factors_reused=False,
        corner_states_are_relaxation_not_contact_events=True,
        sufficient_real_contact_domain_guard_satisfied=True,
        complete_normal_operating_rare_maxima_included=True,
        characteristic_and_frequent_containment=dict(
            method='Same unreduced all-state EN box; independent nonnegative G/payload-Q/retained-B reductions and H reductions lie inside its coefficient domain',
            permanent_factors=1., equipment_factor_interval=[0., physical.dynamic_equipment],
            lifted_factor_interval=[0., physical.dynamic_lifted], retained_lifted_factor_interval=[0., physical.dynamic_lifted], horizontal_signed_interval=[-1., 1.],
            favourable_psi_reduction_credited=False, gamma_Ff_applied_in_stress_box=False),
        continuum_configuration_coverage='Regenerated point-mass transfer is multilinear in hook position, height and payload fraction; extrema occur among physical parameter corners',
        scope='All eight generated normal hook/height/rail configurations and their intermediate physical parameters; source-bounded normal operating rare maxima, not emergency, bumper, test or skew actions')


def _en_resultant_bounds(plan, receipt, domain):
    result, allowances = {}, {}
    for field in FIELDS:
        terms = []
        for basis in plan['bases']:
            coefficient = domain['coefficient_intervals'][basis.id]
            if basis.amplitude == 0.:
                _require(coefficient['exact_zero_coefficient_domain'], 'Nonzero EN force has no verified response basis')
                continue
            evidence = receipt['basis_evidence'][basis.id]['verification']
            response = _response_interval(evidence['refined_extrema'], field, evidence)
            terms.append(interval_product(coefficient, response))
            allowances.setdefault(basis.id, {})[field] = response['verification_allowance']*coefficient['coefficient_abs_max']
        result[field] = interval_sum(terms)
    return result, allowances


def _linear(bounds, terms):
    answer = interval_sum(interval_product(dict(lower=c, upper=c), bounds[key]) for key, c in terms)
    return answer['lower'], answer['upper']


def _compose(project, physical, domain, bounds, provenance):
    section = project.section
    props = geometric_properties(section)
    magnitude = lambda key: max(abs(bounds[key]['lower']), abs(bounds[key]['upper']))
    shear = whole_section_shear_bound(section, **{name: magnitude(key) for name, key in (
        ('abs_Fy_N', 'Fy'), ('abs_Fz_N', 'Fz'), ('abs_Tsv_Nmm', 'Tsv'), ('abs_Tw_Nmm', 'Tw_equilibrated'))})
    tau = shear['tau_bound_mpa']
    geometry = Geometry(section.bottom_width, section.tw_mm, section.bottom_thickness,
                        domain['gauge_mm'], 'rolled', section.bottom_root_radius_mm)
    ledger = ('Independent EN physical coefficient domain; all eight regenerated hook/height/rail configurations; '
              'fixed permanent, G/payload-Q/retained-B independently in [0, physical maxima], correlated full H5 reversal vectors; '
              'source-bounded rare normal maxima and unreduced characteristic/frequent containment. '
              'No original NBR factors or NBR tensor boxes; no equivalent fatigue spectrum. '+physical.action_source)
    local = {}
    for side in ('left', 'right'):
        forces = tuple(row['max_downward_N'] for row in domain['wheel_maxima_by_geometry']
                       if (row['y_mm'] < 0.) == (side == 'left'))
        local[side] = direct_design_box(NominalLocalInputs(geometry, forces,
            domain['min_physical_end_distance_mm'], True, ledger, section.signature, provenance, True))

    def assess(box, point):
        # These booleans certify internally completed guards/composition, not
        # caller-supplied numerical-completeness or imported stress assertions.
        return evaluate(EN2025Inputs(box, box, box, project.fy_mpa, physical.gamma_ff,
            physical.gamma_mf, physical.gamma_mser, point, ledger, provenance,
            True, True, True, True, True, True, True, True))

    points = bottom_flange_points(section, domain['gauge_mm'])
    results = []
    for point in points:
        sx = _linear(bounds, [('N', 1/props['A_mm2']), ('My', point.z_mm/props['Iy_mm4']),
            ('Mz', -point.y_mm/props['Iz_mm4']), ('B_equilibrated', point.omega_mm2/props['Cw_mm6'])])
        global_box = dict(sx=sx, sy=(0., 0.), sz=(0., 0.), txy=(-tau, tau), txz=(-tau, tau), tyz=(0., 0.))
        composed = compose_nominal_tensor(global_box, local[point.outstand_side],
                                           same_point_and_ledger_confirmed=True, source_model_adopted=True)
        row = assess(composed['intervals_mpa'], point.id+'; full verified spatial/travel domain and all configurations')
        row.update(point=asdict(point), composition=composed, global_tensor_box_mpa=global_box,
                   actual_failure_proven=False)
        results.append(row)
    zmax = max(props['centroid_from_bottom_mm'], section.d_mm-props['centroid_from_bottom_mm'])
    ymax = section.bf_mm/2
    omax = max(abs(point.omega_mm2) for point in points)
    extra = math.fsum(magnitude(key)*factor for key, factor in (
        ('My', zmax/props['Iy_mm4']), ('Mz', ymax/props['Iz_mm4']), ('B_equilibrated', omax/props['Cw_mm6'])))
    nlo, nhi = _linear(bounds, [('N', 1/props['A_mm2'])])
    plain_box = dict(sx=(nlo-extra, nhi+extra), sy=(0., 0.), sz=(0., 0.),
                     txy=(-tau, tau), txz=(-tau, tau), tyz=(0., 0.))
    plain = assess(plain_box, 'Ordinary plain top/web global nominal regions; whole spatial/travel/configuration domain')
    plain.update(tensor_box_mpa=plain_box, normal_bound_coefficients=dict(zmax_mm=zmax, ymax_mm=ymax, omega_max_mm2=omax),
        actual_failure_proven=False,
        scope='Whole ordinary plain-section global nominal envelope; lower-flange local effects checked separately; holes, net sections, connections and disturbed regions excluded')
    lower_ok = all(row['qualified_nominal_detail_modes'] for row in results)
    return dict(point_results=results, plain_global_result=plain,
        lower_local_result=dict(qualified_nominal_detail_modes=lower_ok, point_results=results,
                               scope='Prescribed ordinary lower-flange global-plus-local nominal details only'),
        qualified_nominal_detail_modes=lower_ok and plain['qualified_nominal_detail_modes'],
        local_source_boxes=local, whole_nominal_shear=shear, action_domain_ledger=ledger)


def evaluate_family_fatigue(project, receipt, *, physical):
    """Fresh EN nominal-fatigue assessment, using original verified FE mechanics.

    Missing/stale/altered numerical lineage returns pending, never a pass.
    Sufficient contact or fatigue bounds that do not pass remain inconclusive,
    not actual failure witnesses. No external force import or user proof flag.
    """
    result = dict(kind='autonomous_EN2025_verified_physical_family_fatigue_consumer',
        status='NUMERICAL_EVIDENCE_PENDING', qualified_nominal_detail_modes=False,
        point_results=[], plain_global_result=None, lower_local_result=None, pending=[],
        external_efforts_required=False, whole_design_complete=False, whole_beam_qualified=False,
        contact_complete=False, connection_complete=False, physical_unlimited_life_claim=False,
        actual_failure_proven=False, concurrent_tensor_claimed=False, continuum_upper_bound_claimed=False,
        rigorous_roundoff_enclosure_claimed=False, numerical_engineering_result=True,
        original_NBR_tensor_boxes_reused=False, repeated_FE_sweeps=0)
    start = consumer_source_receipt()
    result['source_at_start'] = start
    try:
        before = signature(project.to_dict())
        original_signature = signature(receipt)
        _, plan = validate_family_receipt(project, receipt)
        domain = _en_domain(project, physical, plan)
        bounds, allowances = _en_resultant_bounds(plan, receipt, domain)
        binding = dict(schema='LRO_EN2025_PHYSICAL_FAMILY_FATIGUE_BINDING_V1',
            original_basis_receipt_signature=receipt['receipt_signature'],
            original_basis_source_fingerprint=receipt['source_at_end']['fingerprint'],
            original_generated_input_signature=receipt['generated_input_signature'],
            original_basis_definitions_signature=signature(receipt['basis_definitions']),
            project_signature=before, EN_physical_inputs=asdict(physical), EN_domain_signature=signature(domain),
            consumer_source_fingerprint=start['fingerprint'], all_state_resultant_bounds=bounds,
            propagated_numerical_allowances=allowances)
        provenance = signature(binding)
        composition = _compose(project, physical, domain, bounds, provenance)
        _require(before == signature(project.to_dict()), 'Project changed during family fatigue consumption')
        _require(original_signature == signature(receipt), 'Original numerical receipt changed during consumption')
        _require(start == consumer_source_receipt(), 'Numerical or EN consumer source changed during consumption')
        result.update(composition, physical_inputs=asdict(physical), physical_domain=domain,
            resultant_domain_bounds=bounds, propagated_numerical_allowances=allowances,
            producer_receipt=provenance, consumer_binding=binding,
            source_at_end=start, source_unchanged=True,
            status='NOMINAL_METHOD_ZERO_CALCULATED_DAMAGE_SUFFICIENT' if composition['qualified_nominal_detail_modes']
                   else 'INCONCLUSIVE_SUFFICIENT_FATIGUE_BOUND',
            spatial_scope='All configurations and physical travel in the original verified fixed-FE domain; whole plain-section global and 12 prescribed lower-flange nominal points; engineering numerical evidence, not continuum enclosure',
            excluded_regions=['Hertz/rolling-contact field', 'Suspension connection and bolt holes',
                              'Splices, attachments, net sections and locally disturbed load-introduction regions'])
    except SufficientContactDomainError as exc:
        result.update(status='CONTACT_DOMAIN_SUFFICIENT_GUARD_INCONCLUSIVE', pending=[str(exc)])
    except (ValueError, TypeError, KeyError, ArithmeticError, AttributeError) as exc:
        result['pending'].append(type(exc).__name__+': '+str(exc))
    result['consumer_receipt_signature'] = signature(result)
    return result
