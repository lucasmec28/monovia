"""Separately adopted EN1993-1-9:2025 all-range zero-damage sufficient check.
No duty count inferred; not NBR equivalence or physical unlimited-life promise.
"""
from dataclasses import dataclass
from math import isfinite,sqrt
from .tensor_bounds import tensor_box_bounds,COMPONENTS


def _finite(v):
    try:return isfinite(v)
    except (OverflowError,TypeError,ValueError):return False

@dataclass(frozen=True)
class EN2025Inputs:
    fatigue_intervals_mpa: dict
    characteristic_intervals_mpa: dict
    frequent_intervals_mpa: dict
    fy_mpa: float
    gamma_ff: float
    gamma_mf: float
    gamma_mser: float
    physical_point: str
    action_ledger: str
    producer_receipt: str
    rolled_c3_no_weld_repair: bool
    smooth_sound_as_rolled_detail: bool
    ungalvanized_nonweathering: bool
    environment_execution_qualified: bool
    nominal_model_composition_qualified: bool
    all_states_including_rare_maxima: bool
    characteristic_and_frequent_combinations_qualified: bool
    section_class_and_macrogeometry_qualified: bool
    basis: str='EN1993-1-9:2025_separate_nominal_method'

def evaluate(e):
    if e.basis!='EN1993-1-9:2025_separate_nominal_method':raise ValueError('Separate2025 adoption required')
    for k in ('rolled_c3_no_weld_repair','smooth_sound_as_rolled_detail','ungalvanized_nonweathering','environment_execution_qualified','nominal_model_composition_qualified','all_states_including_rare_maxima','characteristic_and_frequent_combinations_qualified','section_class_and_macrogeometry_qualified'):
        if getattr(e,k) is not True:raise ValueError('Unqualified physical/model condition: '+k)
    for k in ('physical_point','action_ledger','producer_receipt'):
        if not isinstance(getattr(e,k),str) or not getattr(e,k).strip():raise ValueError('Missing producer provenance: '+k)
    for v in (e.fy_mpa,e.gamma_ff,e.gamma_mf,e.gamma_mser):
        if isinstance(v,bool) or not isinstance(v,(float,int)) or not _finite(v) or v<=0:raise ValueError('Finite positive parameters required')
    if min(e.gamma_ff,e.gamma_mser)<1 or e.gamma_mf<1.35:raise ValueError('Bounded preset requires gammaFf/gammaMser >=1 and safe-life high-consequence gammaMf >=1.35')
    f=tensor_box_bounds(e.fatigue_intervals_mpa);c=tensor_box_bounds(e.characteristic_intervals_mpa);q=tensor_box_bounds(e.frequent_intervals_mpa)
    # Exact VAFL powers Fig8.1a / Fig8.4; NO old2005 curve.
    normal_limit=160*(.02**(1/9))/e.gamma_mf;shear_limit=100*(.02**(1/5))/e.gamma_mf
    elastic_n=e.fy_mpa/e.gamma_mser;elastic_t=elastic_n/sqrt(3)
    principal=f['principal_range_mpa']*e.gamma_ff
    widths=f['component_widths_mpa']
    direct=max(widths[k] for k in ('sx','sy','sz'))*e.gamma_ff
    shear=max(widths[k] for k in ('txy','txz','tyz'))*e.gamma_ff
    values=(normal_limit,shear_limit,elastic_n,elastic_t,principal,direct,shear)
    if not all(_finite(v) for v in values) or min(normal_limit,shear_limit,elastic_n,elastic_t)<=0:raise ValueError('Derived overflow/underflow')
    checks=dict(principal_below_vafl=principal<normal_limit,all_direct_below_vafl=direct<normal_limit,all_shear_below_vafl=shear<shear_limit,
        characteristic_normal_elastic=c['absolute_principal_mpa']<=elastic_n,
        characteristic_shear_elastic=c['absolute_fixed_plane_shear_mpa']<=elastic_t,
        frequent_normal_range=q['principal_range_mpa']/elastic_n<=1.5,
        frequent_shear_range=q['fixed_plane_shear_range_mpa']/elastic_t<=1.5)
    ok=all(checks.values())
    return dict(status='NOMINAL_METHOD_ZERO_CALCULATED_DAMAGE_SUFFICIENT' if ok else 'SUFFICIENT_CHECK_NOT_SATISFIED',
        qualified_nominal_detail_modes=ok,checks=checks,principal_range_mpa=principal,direct_range_mpa=direct,shear_range_mpa=shear,
        normal_vafl_design_mpa=normal_limit,shear_vafl_design_mpa=shear_limit,
        characteristic_absolute_normal_bound_mpa=c['absolute_principal_mpa'],
        characteristic_absolute_shear_bound_mpa=c['absolute_fixed_plane_shear_mpa'],
        characteristic_normal_limit_mpa=elastic_n,characteristic_shear_limit_mpa=elastic_t,
        frequent_normal_range_bound_mpa=q['principal_range_mpa'],frequent_shear_range_bound_mpa=q['fixed_plane_shear_range_mpa'],
        curve=dict(normal_category=160,normal_m1=5,normal_m2=9,shear_category=100,shear_m=5),
        factor_preset='Conservative safe-life high-consequence gammaMf>=1.35; not actual project consequence classification',method=e.basis,physical_point=e.physical_point,producer_receipt=e.producer_receipt,
        source='EN1993-1-9:2025 Table10.1, Figures8.1a/8.4, 9.1,9.4, AnnexA.4.1(4),(6),A.5(5)',
        whole_beam_qualified=False,rolling_contact_qualified=False,connection_qualified=False,physical_unlimited_life_claim=False)
