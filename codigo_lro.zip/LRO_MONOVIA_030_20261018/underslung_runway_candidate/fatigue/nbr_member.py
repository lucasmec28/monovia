"""Source-qualified, deliberately PLANAR NBR 8400-2 nominal fatigue consumer.

This isolated consumer does not generate actions, stress histories or numerical
proof. A trusted producer must supply signed bounds for the SAME material
point/face/plane, global plus local, under Case I without Mx or buckling omega.
All six nominal tensor components are retained to prevent silently discarding
out-of-plane demand. A non-planar or incomplete tensor cannot pass Annex D.5.

The explicit reversed-stress reduction uses sigma_w at kappa=-1 for a supplied
E1..E8 group. It is a conservative design adoption, NOT a reconstruction of the
ambiguous positive-kappa Eq. D.3, not automatic E8, and not an infinite-life or
zero-damage route. Source tables already incorporate the 4/3 fatigue factor.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from itertools import product
from math import fsum, isfinite, sqrt
from typing import Mapping

from .nbr_rolling_family import NBRRollingGuidance

from lro_beams.autonomous_fatigue import elastic_allowables_autonomous
from lro_beams.stress_8400 import LOW_GRADES, HIGH_GRADES, W0_LOW_MPA, W0_HIGH_MPA

SOURCE = 'ABNT NBR 8400-2:2019, corrected 20.10.2022'
SOURCE_SHA256 = 'b7cc645332f9945ed5df54aa737feed0a12d59a88f0890173aa2a30638209adb'
ACTION_BASIS = 'nbr8400_fatigue_case_i_without_mx'
KAPPA_POLICY = 'explicit_kappa_minus_one_resistance_reduction'
COMPONENTS = ('sx', 'sy', 'sz', 'txy', 'txz', 'tyz')
PLANES = {'xy': ('sx', 'sy', 'txy'), 'xz': ('sx', 'sz', 'txz')}
SOURCE_CONTRACT = dict(
    standard=SOURCE, primary_pdf_sha256=SOURCE_SHA256,
    actions_extrema='5.6.1–5.6.5, printed p.33 / PDF43: Case I, no Mx or omega',
    groups='D.1–D.2 and Table D.1, printed pp.58–60 / PDF69–71',
    base_shear='D.2.2, printed p.62 / PDF74: W0 tensile allowable / sqrt(3)',
    interaction='D.2.3, Eq. D.5, printed pp.62–63 / PDF74–75',
    positive_kappa='D.3 in PDF72 is ambiguous; exact positive-kappa branch is NOT implemented',
    envelope='D.2.3 permits maxima with worst kappa, or actual corresponding states',
    strict_limit=1., relaxed_1_05_limit_used=False,
)


def _real(value, name, *, positive=False):
    try:
        valid = (not isinstance(value, bool) and isinstance(value, (int, float))
                 and abs(value) <= 1e100 and isfinite(value))
    except (OverflowError, ValueError, TypeError):
        valid = False
    if not valid or positive and value <= 0.:
        raise ValueError(name+' requires a finite '+('positive ' if positive else '')+'real value')
    return float(value)


def _text(value, name):
    if not isinstance(value, str) or not value.strip():
        raise ValueError(name+' requires an explicit physical/source record')
    return value


def _interval(value, name):
    if not isinstance(value, (tuple, list)) or len(value) != 2:
        raise ValueError(name+' requires two signed interval endpoints')
    lo, hi = (_real(v, name) for v in value)
    if lo > hi:
        raise ValueError(name+' interval is reversed')
    return lo, hi


@dataclass(frozen=True)
class NBRFatigueMaterial:
    fy_mpa: float
    fu_mpa: float
    thickness_mm: float
    material_grade: str
    material_source: str


@dataclass(frozen=True)
class NBRFatigueDuty:
    """A component group, never a CMAA/equipment/mechanism class conversion."""
    component_group: str
    classification_source: str
    classification_kind: str


@dataclass(frozen=True)
class NBRFatigueDetail:
    """Initial domain: W0 plain rolled base, not welds/notches/contact."""
    construction_detail: str
    construction_detail_source: str
    fabrication_requirement: str
    fabrication_source: str
    evaluation_location: str = 'base_material'


@dataclass(frozen=True)
class NBRFatigueMethod:
    kappa_policy: str
    adoption_source: str


@dataclass(frozen=True)
class NBRNominalPlane:
    """Producer contract, not an importable user stress or completeness flag.

    Coordinates are global member x longitudinal, y lateral, z vertical. Each
    interval bounds every state at the SAME point/face (or every fixed point in
    the explicitly named region), not component maxima collected across unlike
    material planes. None marks a missing component; it never becomes zero.
    Zeros must follow the adopted nominal model or an actual boundary condition,
    identified by plane_source, not an assertion of a complete physical 3-D field.
    """
    region_id: str
    point_id: str
    face: str
    plane: str
    tensor_intervals_mpa: Mapping[str, tuple[float, float] | None]
    action_basis: str
    action_source: str
    factors_source: str
    bounds_source: str
    nominal_model_source: str
    plane_source: str
    same_point_scope: str


def signed_extrema(first_mpa, second_mpa):
    """5.6.4 semantics only; NEVER calls interval endpoints a real history.

    Equal opposite extrema retain both alternatives for a future same-state
    consumer. The present envelope consumer does not need or invent kappa.
    """
    a, b = _real(first_mpa, 'first extreme'), _real(second_mpa, 'second extreme')
    if a == b == 0.:
        return dict(active=False, sigma_max_candidates_mpa=(0.,),
                    sigma_min_candidates_mpa=(0.,), kappa=None)
    candidates = ((a, b), (b, a)) if abs(a) == abs(b) and a != b else ((a, b),) if abs(a) >= abs(b) else ((b, a),)
    return dict(active=True, sigma_max_candidates_mpa=tuple(row[0] for row in candidates),
                sigma_min_candidates_mpa=tuple(row[1] for row in candidates),
                kappa=candidates[0][1]/candidates[0][0])


def d5_interval_bound(sigma_x_interval_mpa, sigma_y_interval_mpa, tau_xy_interval_mpa,
                      *, normal_x_capacity_mpa, normal_y_capacity_mpa, shear_capacity_mpa):
    """Exact vertex maximum of the fixed-positive-capacity D.5 box polynomial.

    Q=(sx/Ax)^2+(sy/Ay)^2-sx*sy/(|Ax||Ay|)+(tau/T)^2.
    Its Hessian is positive semidefinite, so an interval-box maximum occurs at
    a vertex. All eight signs/endpoints are retained. A governing vertex is an
    optimization witness of the RELAXED box, never a physical coexistent state.
    Unlike a VM-range test, this uses three fatigue allowables and signed sx*sy.
    No rigorous floating-point enclosure is claimed.
    """
    intervals = tuple(_interval(v, name) for v, name in (
        (sigma_x_interval_mpa, 'sigma_x'), (sigma_y_interval_mpa, 'sigma_y'),
        (tau_xy_interval_mpa, 'tau_xy')))
    capacities = tuple(_real(v, name, positive=True) for v, name in (
        (normal_x_capacity_mpa, 'normal x capacity'),
        (normal_y_capacity_mpa, 'normal y capacity'), (shear_capacity_mpa, 'shear capacity')))
    vertices = []
    for sx, sy, tau in product(*intervals):
        u, v, t = sx/capacities[0], sy/capacities[1], tau/capacities[2]
        # Nonnegative form of u*u+v*v-u*v+t*t avoids cancellation.
        q = fsum((.5*(u-v)**2, .5*u*u, .5*v*v, t*t))
        if not isfinite(q):
            raise ValueError('Derived D.5 polynomial overflow')
        vertices.append(dict(sigma_x_mpa=sx, sigma_y_mpa=sy, tau_xy_mpa=tau,
                             normalized=(u, v, t), Q=q))
    governing = max(vertices, key=lambda r: r['Q'])
    ratios = tuple(max(abs(lo), abs(hi))/cap for (lo, hi), cap in zip(intervals, capacities))
    component_ok = all(r <= 1. for r in ratios)
    return dict(Q_upper_bound=governing['Q'], combined_utilization_upper_bound=sqrt(governing['Q']),
        component_utilizations=dict(zip(('sigma_x', 'sigma_y', 'tau_xy'), ratios)),
        individual_bounds_satisfied=component_ok, interaction_bound_satisfied=governing['Q'] <= 1.,
        sufficient_bound_satisfied=component_ok and governing['Q'] <= 1.,
        governing_box_vertex=governing, vertices=vertices, capacities_mpa=dict(
            sigma_x=capacities[0], sigma_y=capacities[1], tau_xy=capacities[2]),
        formula='Q=(sx/Ax)^2+(sy/Ay)^2-sx*sy/(abs(Ax)*abs(Ay))+(tau/T)^2 <= 1',
        envelope_derivation='Convex fixed-capacity quadratic over the complete signed rectangle; maximum at a vertex',
        vertex_is_actual_state=False, actual_failure_proven=False,
        rigorous_roundoff_enclosure_claimed=False, uses_fabricated_history=False,
        uses_von_mises_range=False)


def _material_and_capacity(material, duty, detail, method):
    for value, cls in ((material, NBRFatigueMaterial), (duty, NBRFatigueDuty),
                       (detail, NBRFatigueDetail), (method, NBRFatigueMethod)):
        if not isinstance(value, cls):
            raise ValueError(cls.__name__+' required')
    fy = _real(material.fy_mpa, 'fy', positive=True)
    fu = _real(material.fu_mpa, 'fu', positive=True)
    _real(material.thickness_mm, 'physical material thickness', positive=True)
    if fy > fu:
        raise ValueError('fy cannot exceed fu')
    for obj in (material, duty, detail, method):
        for key, value in asdict(obj).items():
            if key not in ('fy_mpa', 'fu_mpa', 'thickness_mm'):
                _text(value, key)
    pending = []
    if material.material_grade not in LOW_GRADES+HIGH_GRADES or not 370. <= fu <= 520.:
        pending.append('Table D.1/5.6.5 material domain requires S235/S275/A36/S355/A572 GR50 and 370 <= fu <= 520 MPa; no inferred equivalence')
    if duty.component_group not in tuple('E'+str(i) for i in range(1, 9)):
        pending.append('Explicit sourced COMPONENT group E1–E8 required; no E8 default or CMAA/equipment/mechanism mapping')
    if duty.classification_kind not in ('documented_component_classification', 'adopted_conservative_E8', 'manual_code_selection'):
        pending.append('Identify a manual component-group selection, documented component classification or explicitly adopted conservative E8')
    if duty.classification_kind == 'adopted_conservative_E8' and duty.component_group != 'E8':
        pending.append('Conservative unclassified group adoption is limited to explicitly selected E8; it does not represent manual selection of a different group')
    if detail.construction_detail != 'W0_plain_rolled_unnotched' or detail.evaluation_location != 'base_material':
        pending.append('Only W0 plain rolled unnotched base material is qualified here; weld metal, notches, holes and rolling-contact zones need their own detail')
    if detail.fabrication_requirement not in ('specified_h6', 'specified_h6_qc'):
        pending.append('Explicit applicable fabrication/inspection requirement required; this is not an as-built inspection')
    if method.kappa_policy != KAPPA_POLICY:
        pending.append('Explicit conservative kappa=-1 resistance adoption required; exact positive-kappa Eq. D.3 is unresolved')
    if pending:
        return None, pending
    elastic = elastic_allowables_autonomous(fy, fu, 'I')
    sw = (W0_LOW_MPA if material.material_grade in LOW_GRADES else W0_HIGH_MPA)[int(duty.component_group[1:])-1]
    normal = min(sw, .75*fu, elastic['sigma_a_mpa'])
    shear = min(sw/sqrt(3), .75*fu/sqrt(3), elastic['tau_a_mpa'])
    capacity = dict(sigma_w_mpa=sw, normal_x_capacity_mpa=normal, normal_y_capacity_mpa=normal,
        shear_capacity_mpa=shear, elastic_case_i=elastic, rupture_normal_cap_mpa=.75*fu,
        adopted_resistance_kappa=-1., actual_history_kappa=None,
        component_group=duty.component_group,
        actual_component_classification=duty.classification_kind == 'documented_component_classification',
        group_source=duty.classification_source, method_adoption_source=method.adoption_source,
        fatigue_factor_4_over_3_applied_again=False, exact_positive_kappa_equation_used=False,
        capacity_policy='Conservative min(sigma_w, 0.75fu, Case-I elastic); base-material shear divides tensile limits by sqrt(3)',
        classified_service_life_scope=True, calculated_cycles_to_failure=False,
        zero_damage_cutoff_used=False)
    if duty.classification_kind == 'manual_code_selection':
        capacity.update(classification_kind=duty.classification_kind,
                        project_group_adopted=True, actual_component_classification=False,
                        classification_derived_from_history=False)
    return capacity, []


def evaluate_nbr_member_plane(plane, *, material, duty, detail, method):
    """Conditional nominal plane result, never standalone whole-member approval.

    Upstream mechanics must independently establish the provenance and coverage
    declared in NBRNominalPlane. Missing source/model applicability is separate
    from an exceeded sufficient bound. No result of this consumer proves actual
    failure, since the resistance and rectangular demand may both be conservative.
    """
    result = dict(kind='NBR8400_2_source_qualified_planar_nominal_member_fatigue',
        status='APPLICABILITY_PENDING', input_valid=True, pending=[], errors=[],
        source_contract=dict(SOURCE_CONTRACT), sufficient_planar_bound_satisfied=False,
        qualified_nominal_detail_modes=False, actual_failure_proven=False,
        whole_member_qualified=False, whole_design_complete=False,
        physical_unlimited_life_claim=False, calculated_cycles_to_failure=False,
        zero_damage_cutoff_used=False, uses_fabricated_history=False,
        concurrent_tensor_claimed=False, external_efforts_required=False,
        mechanical_evidence_verified_by_this_consumer=False,
        contact_fatigue_in_scope=False, wheels_mechanisms_building_in_scope=False)
    try:
        if not isinstance(plane, NBRNominalPlane):
            raise ValueError('NBRNominalPlane generated by a qualified mechanics producer required')
        for key, value in asdict(plane).items():
            if key != 'tensor_intervals_mpa':
                _text(value, key)
        if not isinstance(plane.tensor_intervals_mpa, Mapping):
            raise ValueError('Full nominal tensor mapping required, including unknown components')
        unknown = set(plane.tensor_intervals_mpa)-set(COMPONENTS)
        if unknown:
            raise ValueError('Unknown tensor components: '+str(sorted(unknown)))
        tensor = {}
        for key in COMPONENTS:
            raw = plane.tensor_intervals_mpa.get(key)
            if raw is None:
                result['pending'].append('Unresolved nominal tensor component '+key+' is not a zero')
            else:
                tensor[key] = _interval(raw, key)
        if plane.action_basis != ACTION_BASIS:
            result['pending'].append('Case I fatigue actions without Mx/omega required; EN/CMAA/ULS actions are not relabeled')
        if plane.plane not in PLANES:
            result['pending'].append('Explicit member xy flange or xz web material plane required')
        elif len(tensor) == len(COMPONENTS):
            active = PLANES[plane.plane]
            outside = {key: value for key, value in tensor.items() if key not in active and value != (0., 0.)}
            if outside:
                result['pending'].append('Annex D.5 is planar; nonzero out-of-plane nominal terms remain: '+', '.join(sorted(outside)))
                result['out_of_plane_intervals_mpa'] = outside
        capacity, pending = _material_and_capacity(material, duty, detail, method)
        result['pending'].extend(pending)
        result['input'] = dict(plane=asdict(plane), material=asdict(material), duty=asdict(duty),
                               detail=asdict(detail), method=asdict(method))
        result['capacity'] = capacity
        if result['pending']:
            return result
        active = PLANES[plane.plane]
        bound = d5_interval_bound(*(tensor[k] for k in active),
            **{key: capacity[key] for key in ('normal_x_capacity_mpa', 'normal_y_capacity_mpa', 'shear_capacity_mpa')})
        passed = bound['sufficient_bound_satisfied']
        result.update(bound=bound, planar_components=dict(zip(('sigma_x', 'sigma_y', 'tau_xy'), active)),
            status='SUFFICIENT_PLANAR_NOMINAL_FATIGUE_BOUND_SATISFIED' if passed else 'INCONCLUSIVE_SUFFICIENT_FATIGUE_BOUND',
            sufficient_planar_bound_satisfied=passed, qualified_nominal_detail_modes=passed,
            scope='Conditional on trusted upstream same-point/face/plane global-plus-local nominal coverage; classified-use component-group fatigue, not cycles-to-failure',
            limitations=[
                'Box vertices and conservative kappa=-1 resistances do not establish actual corresponding stress histories.',
                'An exceeded sufficient envelope requires more specific admissibles/states/model; it is not witnessed failure.',
                'Physical 3-D/contact fatigue, joints, holes, attachments and disturbed connection regions are excluded.',
                'No member approval follows until all relevant member regions, action domains, local/global mechanics and other member checks are independently covered.',
                'Nominal omitted terms are justified by the supplied model/plane source, not measured physical zeros.',
            ])
        if not passed:
            result['criterion_exceedances'] = [key for key, val in bound['component_utilizations'].items() if val > 1.]
            if bound['Q_upper_bound'] > 1.:
                result['criterion_exceedances'].append('D.5_interaction')
        return result
    except (ValueError, TypeError, ArithmeticError, KeyError) as exc:
        result.update(status='INVALID_INPUT', input_valid=False, errors=[type(exc).__name__+': '+str(exc)])
        return result


def lower_flange_nominal_planes(section, *, resultant_bounds, wheel_vertical_actions,
                                edge_to_contact_n_mm, minimum_distance_to_physical_end_mm,
                                action_basis, action_source, factors_source, bounds_source,
                                nominal_model_source):
    """Reuse reviewed recovery coefficients for source-prescribed lower faces.

    This is a MECHANICAL producer helper. The orchestrator must first validate
    the family FE/source receipt and select its FAT8400 actions; arbitrary raw
    imported resultants cannot establish qualification. No FE solve or history
    is created here. Each physical P0/P1/P2 / side / face remains distinct.

    The local nominal component box deliberately discards favorable signs and
    envelopes the individual same-side station peaks in the source-prescribed
    isolated-wheel domain. It is not an elastic decay or 3-D field assertion.
    Opposed wheels are never summed into one local wheel. The NBR10084
    station/end domain remains mandatory. This covers the
    adopted source-prescribed nominal detail checks, not an interpolated 3-D or
    temporal stress field. Top-contact pressure and actual root hotspots remain
    outside this nominal bending model.
    """
    from ..autonomous_workflow.family_envelope import FIELDS, interval_sum, interval_product
    from ..section_stress.recovery import (
        ISection, Resultants, bottom_flange_points, bottom_contact,
        geometric_properties, flange_shear_components, NBR_LOCAL_COMBINATION,
    )
    from ..local_flange.kernel import Geometry, coefficients
    if not isinstance(section, ISection) or not section.doubly_symmetric or section.construction != 'rolled':
        raise ValueError('Doubly symmetric plain rolled section required')
    if action_basis != ACTION_BASIS:
        raise ValueError('Separate NBR Case-I fatigue domain required; never relabel EN/ULS boxes')
    for key, value in (('action_source', action_source), ('factors_source', factors_source),
                       ('bounds_source', bounds_source), ('nominal_model_source', nominal_model_source)):
        _text(value, key)
    if set(resultant_bounds) != set(FIELDS):
        raise ValueError('All eight signed verified global resultant bounds required')
    bounds = {}
    for key in FIELDS:
        value = resultant_bounds[key]
        if not isinstance(value, Mapping) or 'lower' not in value or 'upper' not in value:
            raise ValueError('Missing signed resultant interval '+key)
        low, high = _interval((value['lower'], value['upper']), key)
        bounds[key] = dict(lower=low, upper=high)
    end = _real(minimum_distance_to_physical_end_mm, 'physical end distance', positive=True)
    if end <= section.bottom_width:
        raise ValueError('NBR10084 nominal interior local model requires physical end distance > flange width')
    geometry = Geometry(section.bottom_width, section.tw_mm, section.bottom_thickness,
                        edge_to_contact_n_mm, 'rolled', section.bottom_root_radius_mm)
    if not isinstance(wheel_vertical_actions, (list, tuple)) or not wheel_vertical_actions:
        raise ValueError('Physical wheel geometry and same-fatigue-domain vertical bounds required')
    stations = {}
    for row in wheel_vertical_actions:
        if not isinstance(row, Mapping) or 'downward_N' not in row:
            raise ValueError('Physical wheel action record required')
        offset = _real(row['offset_mm'], 'wheel station')
        y = _real(row['y_mm'], 'physical wheel y')
        z = _real(row['z_mm'], 'physical wheel z')
        omega = _real(row['omega_mm2'], 'physical wheel omega')
        if y == 0.:
            raise ValueError('Lower flange wheel must belong to an explicit outstand')
        side = 'left' if y < 0. else 'right'
        contact = bottom_contact(section, edge_to_contact_n_mm, side)
        for value, expected, key in ((y, contact['y_mm'], 'y'), (z, contact['z_mm'], 'z'),
                                      (omega, contact['omega_mm2'], 'omega')):
            if abs(value-expected) > 1e-10*max(1., abs(expected)):
                raise ValueError('Wheel geometry differs from source nominal point model: '+key)
        low, high = _interval((row['downward_N']['lower'], row['downward_N']['upper']), 'wheel downward force')
        if low < 0.:
            raise ValueError('Nonnegative compression-only contact domain not established')
        if side in stations.setdefault(offset, {}):
            raise ValueError('Repeated wheel/outstand at one station')
        stations[offset][side] = (low, high)
    for row in stations.values():
        if set(row) != {'left', 'right'} or row['left'] != row['right']:
            raise ValueError('Source local model requires equal opposed physical wheels; no inferred averaging')
    offsets = sorted(stations)
    if any(b-a < 1.5*section.bottom_width for a, b in zip(offsets, offsets[1:])):
        raise ValueError('NBR10084 isolated-station spacing >= 1.5 flange widths required; close-wheel source applicability remains pending')
    forces = {side: max(row[side][1] for row in stations.values()) for side in ('left', 'right')}
    minimum_spacing = min((b-a for a, b in zip(offsets, offsets[1:])), default=None)
    properties = geometric_properties(section)
    local_coefficients = coefficients(geometry.mu)

    def linear(terms):
        r = interval_sum(interval_product(dict(lower=c, upper=c), bounds[key]) for key, c in terms)
        return r['lower'], r['upper']

    def with_local(global_interval, amplitude):
        r = interval_sum((dict(lower=global_interval[0], upper=global_interval[1]),
                          dict(lower=-amplitude, upper=amplitude)))
        return r['lower'], r['upper']

    planes, receipts = [], []
    for point in bottom_flange_points(section, edge_to_contact_n_mm):
        # Reuse the EXISTING linear recovery, including signs and free-edge rules.
        # A unit probing state is algebraic coefficient extraction, not a fatigue
        # operating state or physical same-time witness.
        shear_terms = []
        for field, key in (('Fy', 'Fy'), ('Fz', 'Fz'), ('Tsv', 'Tsv'), ('Tw', 'Tw_equilibrated')):
            values = {name: 0. for name in ('N', 'My', 'Mz', 'Fy', 'Fz', 'B', 'Tsv', 'Tw')}
            values[field] = 1.
            unit = Resultants(**values, x=0., side='right', combination_id='ALGEBRAIC_RECOVERY_COEFFICIENT_NOT_ACTION',
                wheel_translation_mm=0., section_signature=section.signature, torsion_recovery='equilibrated')
            row = flange_shear_components(section, unit, point.y_mm, point.z_mm)
            # Nominal face eta=+/-tf/2: the recovery equation is exactly zero.
            # Float cancellation can leave a tiny coefficient; identify its
            # analytical boundary origin, rather than applying a tolerance to
            # an unknown physical demand.
            if field == 'Fz':
                eta = point.z_mm-properties['bottom_z_mid_mm']
                if abs(abs(eta)-section.bottom_thickness/2) > 1e-10*max(1., section.d_mm):
                    raise ValueError('Requested point is not the nominal free flange face')
            shear_terms.append((key, row['tau_xy_mpa']))
        global_sx = linear((('N', 1/properties['A_mm2']), ('My', point.z_mm/properties['Iy_mm4']),
                            ('Mz', -point.y_mm/properties['Iz_mm4']),
                            ('B_equilibrated', point.omega_mm2/properties['Cw_mm6'])))
        tau = linear(shear_terms)
        cx, cy = local_coefficients[point.point]
        load = forces[point.outstand_side]/section.bottom_thickness**2
        local_x, local_y = .75*abs(cx)*load, abs(cy)*load
        sx = with_local(global_sx, local_x)
        tensor = dict(sx=sx, sy=(-local_y, local_y), sz=(0., 0.),
                      txy=tau, txz=(0., 0.), tyz=(0., 0.))
        planes.append(NBRNominalPlane(
            region_id='ordinary_lower_flange_source_prescribed_detail', point_id=point.id,
            face=point.face, plane='xy', tensor_intervals_mpa=tensor,
            action_basis=action_basis, action_source=action_source, factors_source=factors_source,
            bounds_source=bounds_source, nominal_model_source=nominal_model_source+'; '+NBR_LOCAL_COMBINATION,
            plane_source='Existing flange_shear_components on nominal eta=+/-tf/2 faces: tau_xz,Fz=Fz*(tf^2/4-eta^2)/(2Iy)=0; retained signed tau_xy from Fy/Fz/Tw/Tsv. No local 3-D contact traction or rolled-root hotspot is asserted zero.',
            same_point_scope='Fixed '+point.id+' over all verified spatial/travel/action states; source-prescribed local normal design box, global signed interval, same nominal face and axes'))
        receipts.append(dict(point=asdict(point), global_sigma_x_interval_mpa=global_sx,
            global_tau_xy_interval_mpa=tau, shear_linear_coefficients=dict(shear_terms),
            local_x_absolute_bound_mpa=local_x, local_y_absolute_bound_mpa=local_y,
            local_source_coefficients=dict(cx=cx, cy=cy),
            local_source_bottom_face_signs=(cx, cy), local_face_multiplier=1 if point.face == 'bottom' else -1,
            local_longitudinal_multiplier=.75, local_transverse_multiplier=1.,
            isolated_station_max_N=forces[point.outstand_side],
            per_station_force_upper_bounds_N=[dict(offset_mm=offset, force_upper_N=stations[offset][point.outstand_side][1]) for offset in offsets],
            aggregation_policy='nbr10084_9_1_4_isolated_station_envelope',
            governing_station_offsets_mm=[offset for offset in offsets if stations[offset][point.outstand_side][1] == forces[point.outstand_side]],
            minimum_longitudinal_spacing_mm=minimum_spacing,
            flange_width_mm=section.bottom_width, isolated_spacing_threshold_mm=1.5*section.bottom_width,
            minimum_physical_end_distance_mm=end,
            opposite_wheels_double_counted=False,
            local_sign_correlations_credited=False, local_history_created=False,
            zero_txz_basis='Exact nominal face boundary eta=+/-tf/2 in the reviewed recovery equation, not dropped whole-section shear',
            actual_3d_tensor_complete=False))
    return dict(planes=tuple(planes), point_receipts=receipts,
        action_basis=action_basis, physical_station_offsets_mm=offsets,
        minimum_physical_end_distance_mm=end,
        source_prescribed_nominal_detail_coverage=True, spatial_continuum_local_field_claimed=False,
        top_web_global_member_coverage=False, whole_member_qualified=False,
        repeated_FE_sweeps=0, created_temporal_histories=0,
        scope='12 prescribed ordinary lower-flange nominal points/faces only; remaining global member wall regions require separate coverage')


def ordinary_global_wall_nominal_planes(section, *, resultant_bounds, action_basis,
                                       action_source, factors_source, bounds_source,
                                       nominal_model_source):
    """Three separate ordinary thin-wall NOMINAL planes, never a 3-D collapse.

    Reuses the reviewed rectangular recovery and per-mechanism wall shear terms.
    The source-prescribed lower-flange local checks are intentionally separate.
    The nominal wall-plane model excludes 3-D root/junction/contact fields; those
    omissions are model scope, NOT physical zero stress evidence. No whole-section
    vector norm is passed to D.5 as if it were one shear stress in one plane.
    """
    from ..autonomous_workflow.family_envelope import FIELDS, interval_sum, interval_product
    from ..section_stress.recovery import ISection, geometric_properties
    from ..section_stress.whole_section_bounds import whole_section_shear_bound
    if not isinstance(section, ISection) or not section.doubly_symmetric or section.construction != 'rolled':
        raise ValueError('Doubly symmetric plain rolled section required')
    if action_basis != ACTION_BASIS:
        raise ValueError('Separate NBR Case-I fatigue domain required')
    for name, value in (('action_source', action_source), ('factors_source', factors_source),
                        ('bounds_source', bounds_source), ('nominal_model_source', nominal_model_source)):
        _text(value, name)
    if set(resultant_bounds) != set(FIELDS):
        raise ValueError('All eight signed global resultant bounds required')
    bounds = {}
    for key in FIELDS:
        row = resultant_bounds[key]
        lo, hi = _interval((row['lower'], row['upper']), key)
        bounds[key] = dict(lower=lo, upper=hi)
    magnitude = lambda key: max(abs(bounds[key]['lower']), abs(bounds[key]['upper']))
    props = geometric_properties(section)
    shear = whole_section_shear_bound(section, abs_Fy_N=magnitude('Fy'), abs_Fz_N=magnitude('Fz'),
        abs_Tsv_Nmm=magnitude('Tsv'), abs_Tw_Nmm=magnitude('Tw_equilibrated'))
    d, b, t, w = section.d_mm, section.bf_mm, section.tf_mm, section.tw_mm
    h, c = d-2*t, (d-t)/2
    planes, receipts = [], []
    for wall in ('top_flange', 'bottom_flange', 'web'):
        web = wall == 'web'
        z = (-h/2, h/2) if web else (h/2, d/2) if wall == 'top_flange' else (-d/2, -h/2)
        y = (-w/2, w/2) if web else (-b/2, b/2)
        omega = (0., 0.) if web else (-b*c/2, b*c/2)
        terms = []
        for key, coefficients in (
            ('N', (1/props['A_mm2'],)*2),
            ('My', tuple(a/props['Iy_mm4'] for a in z)),
            ('Mz', (-y[1]/props['Iz_mm4'], -y[0]/props['Iz_mm4'])),
            ('B_equilibrated', tuple(a/props['Cw_mm6'] for a in omega))):
            terms.append(interval_product(bounds[key], dict(lower=coefficients[0], upper=coefficients[1])))
        sx = interval_sum(terms)
        components = shear['components'][wall]
        if web:
            in_plane = dict(vertical_force=components['tau_xz_Fz_bound_mpa'],
                            saint_venant_nominal_wall_face=components['tau_saint_venant_vector_bound_mpa'])
        else:
            in_plane = dict(lateral_force=components['tau_xy_Fy_bound_mpa'],
                            vertical_force=components['tau_xy_Fz_bound_mpa'],
                            warping_torsion=components['tau_xy_Tw_bound_mpa'],
                            saint_venant_nominal_wall_face=components['tau_saint_venant_vector_bound_mpa'])
        tau = fsum(in_plane.values())
        tensor = dict(sx=(sx['lower'], sx['upper']), sy=(0., 0.), sz=(0., 0.),
            txy=(0., 0.) if web else (-tau, tau),
            txz=(-tau, tau) if web else (0., 0.), tyz=(0., 0.))
        plane = NBRNominalPlane(region_id='ordinary_global_'+wall,
            point_id=wall+'_uniform_nominal_wall_face_bound', face='both_nominal_wall_faces',
            plane='xz' if web else 'xy', tensor_intervals_mpa=tensor,
            action_basis=action_basis, action_source=action_source, factors_source=factors_source,
            bounds_source=bounds_source, nominal_model_source=nominal_model_source,
            plane_source=('SCI thin-wall nominal '+('web xz' if web else 'flange xy')+
                ' face model; individually retained signed/global action bounds and wall-tangential shear mechanisms. Not the finite 3-D transfer strip, actual rolled junction, contact tensor or a vector-norm substitution.'),
            same_point_scope='Uniform envelope at every fixed point of the ordinary nominal '+wall+
                ' wall over the supplied verified spatial/travel/action domain; lower local source details remain separately required')
        planes.append(plane)
        receipts.append(dict(wall=wall, plane=plane.plane, in_plane_shear_terms_mpa=in_plane,
            in_plane_shear_abs_mpa=tau, normal_sigma_x_interval_mpa=tensor['sx'],
            coordinate_bounds_mm=dict(z=z, y=y), omega_bounds_mm2=omega,
            physical_thickness_mm=w if web else t,
            whole_section_vector_norm_used=False, actual_3d_tensor_complete=False,
            lower_flange_local_effects_included=False,
            omitted_nonplanar_region='Actual root/junction/contact/finite transfer-strip field outside adopted ordinary thin-wall plane scope'))
    return dict(planes=tuple(planes), wall_receipts=receipts,
        adopted_model='SCI/open-I ordinary thin-wall nominal wall planes with computed rectangular section properties',
        global_wall_nominal_coverage=True, lower_flange_local_coverage=False,
        whole_member_qualified=False, whole_section_vector_norm_used=False,
        repeated_FE_sweeps=0, temporal_histories_created=0,
        source='SCI P385 nominal thin-wall torsion; reviewed longitudinal-equilibrium force shear and section recovery')


@dataclass(frozen=True)
class NBRMemberFatigueInputs:
    """Physical/detail/method premises, no external efforts or approval flags."""
    flange_material: NBRFatigueMaterial
    web_material: NBRFatigueMaterial
    duty: NBRFatigueDuty
    detail: NBRFatigueDetail
    method: NBRFatigueMethod
    nominal_model_source: str
    rolling_guidance: NBRRollingGuidance | None = None


def nbr_consumer_source_receipt():
    """Separate immutable consumer closure; never re-signs an old FE receipt."""
    import hashlib
    from pathlib import Path
    from ..autonomous_workflow.family_envelope import _source
    from ..autonomous_workflow.model import signature
    import lro_beams.autonomous_fatigue as fatigue_runtime
    import lro_beams.stress_8400 as material_runtime
    import importlib
    files = {'fatigue/nbr_member.py': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    # Hash the modules actually imported, also when a fresh consumer is loaded
    # against a frozen mechanics runtime. Never hash an unexecuted nearby copy.
    package = __package__.rsplit('.', 1)[0]
    for name in ('section_stress.recovery', 'section_stress.whole_section_bounds',
                 'local_flange.kernel', 'stability.family_adapter',
                 'fatigue.nbr_rolling_family', 'autonomous_workflow.nbr_rolling'):
        module = importlib.import_module(package+'.'+name)
        files[name.replace('.', '/')+'.py'] = hashlib.sha256(Path(module.__file__).read_bytes()).hexdigest()
    for name, module in (('lro_beams/autonomous_fatigue.py', fatigue_runtime),
                         ('lro_beams/stress_8400.py', material_runtime)):
        files[name] = hashlib.sha256(Path(module.__file__).read_bytes()).hexdigest()
    payload = dict(original_basis_dependencies=_source(), consumer_files=files,
                   primary_source_sha256=SOURCE_SHA256)
    return dict(**payload, fingerprint=signature(payload))


def _mark_incomplete_normal_rolling_actions(result, reason=None):
    """Keep valid computed planes; do not promote an incomplete Case-I domain."""
    message = ('NBR8400-1:2019 6.2.3.3 normal transverse rolling reaction and '
        '6.3.1 adverse horizontal-pair coverage are not established for this '
        'assessment. HX/HY inertia alone does not establish complete Case I; '
        'exceptional SHE and CMAA SK are not substitutes.')
    result['computed_partial_action_domain_sufficient'] = result.get('sufficient_nominal_member_fatigue_bounds_satisfied', False)
    result['normal_rolling_reaction_coverage_qualified'] = False
    result['case_I_action_domain_complete'] = False
    result['qualified_nominal_detail_modes'] = False
    result['sufficient_nominal_member_fatigue_bounds_satisfied'] = False
    result['pending'].append(message if reason is None else message+' '+reason)
    if result.get('status') != 'APPLICABILITY_PENDING':
        result['status'] = 'ACTION_DOMAIN_PENDING'
    for key in ('plain_global_result', 'lower_local_result'):
        row = result.get(key)
        if row is not None:
            row['computed_partial_action_domain_sufficient'] = row.get('qualified_nominal_detail_modes', False)
            row['qualified_nominal_detail_modes'] = False
            row['case_I_action_domain_complete'] = False
    return result


def evaluate_nbr_family_fatigue(project, receipt, *, physical):
    """Current explicit-four-mass family -> NBR ordinary global/local fatigue.

    Revalidates physical inputs, every FE basis/source and regenerated FAT8400
    membership, then consumes only that family's signed interval relaxation.
    Existing EN/ULS boxes are not relabeled. All receipt changes are detected;
    none is repaired/re-signed and no FE sweep is repeated. Sufficient nominal
    wall/detail checks remain separate from actual root/contact/system design.
    """
    from ..autonomous_workflow.model import signature
    from ..stability.family_adapter import validate_family_receipt
    from lro_beams.autonomous_actions import factors_10084
    from .nbr_rolling_family import generate_nbr_rolling_family_coefficients, compose_nbr_rolling_response_box
    result = dict(kind='underslung_NBR8400_verified_physical_family_nominal_fatigue',
        status='NUMERICAL_EVIDENCE_PENDING', qualified_nominal_detail_modes=False,
        sufficient_nominal_member_fatigue_bounds_satisfied=False,
        plain_global_result=None, lower_local_result=None, point_results=[], pending=[],
        external_efforts_required=False, actual_failure_proven=False,
        whole_beam_qualified=False, whole_design_complete=False,
        physical_unlimited_life_claim=False, calculated_cycles_to_failure=False,
        zero_damage_cutoff_used=False, concurrent_tensor_claimed=False,
        continuum_upper_bound_claimed=False, rigorous_roundoff_enclosure_claimed=False,
        numerical_engineering_result=True, repeated_FE_sweeps=0,
        wheels_mechanisms_building_in_scope=False, contact_fatigue_in_scope=False,
        original_EN_or_ULS_tensor_boxes_reused=False)
    try:
        if not isinstance(physical, NBRMemberFatigueInputs):
            raise ValueError('Explicit NBRMemberFatigueInputs required')
        _text(physical.nominal_model_source, 'nominal model source/adoption')
        project.validate()
        mass = project.suspended_mass_basis()
        result['suspended_mass_accounting'] = mass
        if not mass.get('complete_suspended_mass_accounting') or not mass.get('retained_mass_explicit'):
            result['status'] = 'SUSPENDED_MASS_ACCOUNTING_PENDING'
            result['pending'].append('Common physical ledger must explicitly separate retained suspended B from removable payload and equipment, including sourced zero B')
            return result
        section = project.section
        for name, material, thickness in (
            ('flange', physical.flange_material, section.tf_mm),
            ('web', physical.web_material, section.tw_mm)):
            if not isinstance(material, NBRFatigueMaterial) or material.thickness_mm != thickness:
                raise ValueError(name+' material must identify its actual physical thickness')
            for field in ('fy_mpa', 'fu_mpa'):
                actual = getattr(project, field)
                if actual is not None and getattr(material, field) != actual:
                    raise ValueError(name+' '+field+' conflicts with the current physical project material')
        before = signature(project.to_dict())
        original_receipt = signature(receipt)
        start = nbr_consumer_source_receipt()
        result['source_at_start'] = start
        _, plan = validate_family_receipt(project, receipt)
        fatigue_members = [member for member in plan['members'] if member['family'] == 'FAT8400']
        if not fatigue_members:
            raise ValueError('Current regenerated Case-I fatigue membership is absent')
        factors = factors_10084('fatigue_8400', psi=plan['action_generation']['psi'])
        if factors.basis != ACTION_BASIS:
            raise ValueError('Regenerated fatigue factor helper no longer matches the qualified action basis')
        for member in fatigue_members:
            case = member['case']
            expected = dict(support_dead=factors.dead_support, equipment_dead=factors.dead_equipment,
                lifted=factors.lifted if case.loaded else 0., retained_lifted=factors.lifted,
                longitudinal=factors.longitudinal, transverse=factors.transverse,
                extra_dead=factors.extra_dead)
            if any(getattr(case, key) != value for key, value in expected.items()):
                raise ValueError('Regenerated FAT8400 factors changed, lost retained B or include an unqualified multiplier')
        families = [row for row in receipt['families'] if row['family'] == 'FAT8400']
        if len(families) != 1 or len(families[0]['members']) != len(fatigue_members):
            raise ValueError('Exactly one complete validated FAT8400 family required')
        family = families[0]
        if not family['all_members_contact_valid']:
            result['status'] = 'CONTACT_DOMAIN_PENDING'
            raise ValueError('The regenerated physical NBR fatigue contact domain is not valid')
        if project.travel_min_mm is None or project.travel_max_mm is None:
            raise ValueError('Physical wheel travel endpoints required')
        rolling, rolling_pending = None, None
        try:
            rolling = generate_nbr_rolling_family_coefficients(project, plan, physical.rolling_guidance)
            domains = [dict(horizontal_pair=pair['horizontal_pair'],
                bounds=compose_nbr_rolling_response_box(plan, receipt['basis_evidence'], pair['coefficient_intervals']),
                members=pair['members']) for pair in rolling['pairs']]
        except (ValueError, TypeError, KeyError, ArithmeticError, AttributeError) as exc:
            rolling_pending = type(exc).__name__+': '+str(exc)
            # Retain independently valid old inertia-only diagnostics, but never
            # let a failed/missing rolling action masquerade as a zero increment.
            rolling = None
            domains = [dict(horizontal_pair=['HX', 'HY'], bounds=family['bounds'], members=family['members'])]
        wheels = family['wheel_vertical_actions'] if rolling is None else rolling['wheel_vertical_actions']
        end = min(min(project.travel_min_mm+w['offset_mm'],
                      project.length_mm-project.travel_max_mm-w['offset_mm']) for w in wheels)
        gauge = project.bridge_reaction_ledger['inputs']['contact_n_mm']
        binding = dict(schema='NBR8400_NOMINAL_FATIGUE_CONSUMER_BINDING_V2',
            original_receipt_signature=receipt['receipt_signature'],
            original_basis_source_fingerprint=receipt['source_at_end']['fingerprint'],
            project_signature=before, original_generated_input_signature=receipt['generated_input_signature'],
            physical_inputs=asdict(physical), consumer_source_fingerprint=start['fingerprint'],
            FAT8400_family_signature=signature(family), regenerated_factors=asdict(factors),
            normal_rolling_family_signature=None if rolling is None else rolling['receipt_signature'],
            suspended_mass_accounting=mass)
        provenance = signature(binding)
        common = dict(action_basis=ACTION_BASIS,
            action_source='; '.join(family['action_basis_sources'])+('' if rolling is None else '; '+rolling['source']),
            factors_source=factors.source+'; regenerated Case I without Mx/omega; retained B receives lifted factor in empty and loaded cases; no factors applied again',
            bounds_source='Validated current fixed-FE mechanical bases; complete allowances multiplied by actual coefficient magnitude, including >1; separate horizontal-pair intervals; binding '+provenance,
            nominal_model_source=physical.nominal_model_source)

        def assess(plane, pair):
            row = evaluate_nbr_member_plane(plane,
                material=physical.web_material if plane.plane == 'xz' else physical.flange_material,
                duty=physical.duty, detail=physical.detail, method=physical.method)
            row['horizontal_pair'] = pair
            row['nominal_identity'] = (plane.region_id, plane.point_id, plane.face)
            return row

        def producer_record(record):
            return {key: value for key, value in record.items() if key != 'planes'}

        pair_results, global_rows, lower_rows = [], [], []
        for domain in domains:
            global_producer = ordinary_global_wall_nominal_planes(section, resultant_bounds=domain['bounds'], **common)
            lower_producer = lower_flange_nominal_planes(section, resultant_bounds=domain['bounds'], **common,
                wheel_vertical_actions=wheels, edge_to_contact_n_mm=gauge,
                minimum_distance_to_physical_end_mm=end)
            gr = [assess(plane, domain['horizontal_pair']) for plane in global_producer['planes']]
            lr = [assess(plane, domain['horizontal_pair']) for plane in lower_producer['planes']]
            global_rows.extend(gr); lower_rows.extend(lr)
            pair_results.append(dict(horizontal_pair=domain['horizontal_pair'], member_count=len(domain['members']),
                bounds=domain['bounds'], point_results=gr+lr,
                all_nominal_bounds_satisfied=all(row['sufficient_planar_bound_satisfied'] for row in gr+lr),
                global_producer=producer_record(global_producer), lower_producer=producer_record(lower_producer)))
        rows = global_rows+lower_rows
        passed = bool(rows) and all(row['sufficient_planar_bound_satisfied'] for row in rows)
        # Presentation only: retain the actual worst assessed pair at each point.
        # No tensor is assembled from stresses belonging to different pairs.
        def governing(point_rows):
            selected = {}
            for row in point_rows:
                key = tuple(row['nominal_identity'])
                rank = row.get('bound', {}).get('combined_utilization_upper_bound', float('-inf'))
                if key not in selected or rank > selected[key][0]:
                    selected[key] = (rank, row)
            return [value[1] for value in selected.values()]
        result['domain_pending'] = sorted({message for row in rows for message in (*row.get('pending', []), *row.get('errors', []))})
        result['pending'].extend(result['domain_pending'])
        applicability_pending = any(row['status'] in ('APPLICABILITY_PENDING', 'INVALID_INPUT') for row in rows)
        if before != signature(project.to_dict()) or original_receipt != signature(receipt):
            result['status'] = 'INPUT_OR_RECEIPT_CHANGED_DURING_ASSESSMENT'
            raise ValueError('Physical project or original FE receipt changed during consumption')
        if start != nbr_consumer_source_receipt():
            result['status'] = 'SOURCE_CHANGED_DURING_ASSESSMENT'
            raise ValueError('Numerical or NBR consumer source changed during consumption')
        result.update(
            status='SUFFICIENT_NOMINAL_MEMBER_FATIGUE_BOUNDS_SATISFIED' if passed else
                   'APPLICABILITY_PENDING' if applicability_pending else 'INCONCLUSIVE_SUFFICIENT_FATIGUE_BOUND',
            qualified_nominal_detail_modes=passed,
            sufficient_nominal_member_fatigue_bounds_satisfied=passed,
            point_results=governing(rows), horizontal_pair_results=pair_results,
            plain_global_result=dict(qualified_nominal_detail_modes=all(r['sufficient_planar_bound_satisfied'] for r in global_rows),
                                     point_results=governing(global_rows), producer=pair_results[0]['global_producer']),
            lower_local_result=dict(qualified_nominal_detail_modes=all(r['sufficient_planar_bound_satisfied'] for r in lower_rows),
                                   point_results=governing(lower_rows), producer=pair_results[0]['lower_producer']),
            normal_rolling_family=rolling, normal_rolling_reaction_coverage_qualified=rolling is not None,
            case_I_action_domain_complete=rolling is not None,
            nominal_scope_only=True, local_lateral_transfer_qualified=False, stability_qualified_by_Rlambda=False,
            physical_inputs=asdict(physical), producer_receipt=provenance,
            consumer_binding=binding, source_at_end=start, source_unchanged=True,
            assessed_action_family='FAT8400', assessed_family_member_count=len(fatigue_members) if rolling is None else rolling['total_case_count'],
            assessed_horizontal_pair_count=len(domains), assessed_nominal_plane_count=len(rows),
            source_contract=dict(SOURCE_CONTRACT),
            scope='Adopted ordinary thin-wall global planes and all 12 prescribed lower-flange local nominal detail faces under current Case-I fatigue family; conservative group/kappa/box checks for classified use',
            excluded_regions=['Actual Hertz/rolling-contact field', 'Actual fillet/junction concentration and transfer-strip 3-D fields',
                              'Holes, splices, attachments, connections and disturbed load-introduction regions'],
            member_only_scope=True)
        if rolling is None:
            _mark_incomplete_normal_rolling_actions(result, rolling_pending)
    except (ValueError, TypeError, KeyError, ArithmeticError, AttributeError) as exc:
        result['pending'].append(type(exc).__name__+': '+str(exc))
    result['consumer_receipt_signature'] = signature(result)
    return result
