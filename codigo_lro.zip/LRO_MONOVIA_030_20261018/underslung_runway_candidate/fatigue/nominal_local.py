"""Source-prescribed nominal DIRECT-stress design box, not continuum enclosure.
EN1993-6:2007 5.8,9.3.1,9.3.4; EN15011:2011+A1:2014 informative E corroborates
fatigue use. No .75 reduction credited. Does not produce physical local shear.
"""
from dataclasses import dataclass
from math import isfinite
from ..local_flange.kernel import Geometry, coefficients


def _finite(v):
    try:return isfinite(v)
    except (OverflowError,TypeError,ValueError):return False

@dataclass(frozen=True)
class NominalLocalInputs:
    geometry: Geometry
    max_dynamic_individual_wheels_N: tuple
    minimum_distance_to_physical_end_mm: float
    symmetric_opposite_wheels: bool
    action_ledger: str
    geometry_provenance: str
    all_service_states_provenance: str
    all_contributing_wheels_included: bool
    basis: str='EN_characteristic_fatigue_dynamics_once_gammaFf_excluded'

def direct_design_box(i):
    if not isinstance(i.geometry,Geometry):raise ValueError('Validated local flange geometry required')
    if i.basis!='EN_characteristic_fatigue_dynamics_once_gammaFf_excluded':raise ValueError('Separate EN fatigue ledger required')
    if i.symmetric_opposite_wheels is not True:raise ValueError('Unequal/opposite-wheel torsion model not implemented in this adapter')
    if i.all_contributing_wheels_included is not True:raise ValueError('All contributing wheels must be included, no unproved isolation')
    if not _finite(i.minimum_distance_to_physical_end_mm) or i.minimum_distance_to_physical_end_mm<=i.geometry.bottom_b_mm:raise ValueError('Physical end transition outside nominal model')
    for v in (i.action_ledger,i.geometry_provenance,i.all_service_states_provenance):
        if not isinstance(v,str) or not v.strip():raise ValueError('Physical input and producer provenance required')
    if not i.max_dynamic_individual_wheels_N:raise ValueError('Individual wheel maxima required')
    for p in i.max_dynamic_individual_wheels_N:
        if isinstance(p,bool) or not isinstance(p,(float,int)) or not _finite(p) or p<0:raise ValueError('Finite nonnegative physical wheel forces required')
    c=coefficients(i.geometry.mu)
    denominator=i.geometry.bottom_tf_mm*i.geometry.bottom_tf_mm
    if not _finite(denominator) or denominator<=0:raise ValueError('Invalid derived thickness square')
    load=sum(i.max_dynamic_individual_wheels_N)/denominator
    if any(p>0 for p in i.max_dynamic_individual_wheels_N) and load==0:raise ValueError('Derived load underflow')
    bx=max(abs(v[0]) for v in c)*load;by=max(abs(v[1]) for v in c)*load
    if not all(_finite(v) for v in (load,bx,by)):raise ValueError('Derived local box overflow')
    return dict(producer_kind='SOURCE_PRESCRIBED_NOMINAL_DESIGN_BOX',basis=i.basis,
        sx_mpa=(-bx,bx),sy_mpa=(-by,by),local_twisting_shear_mpa=None,
        points=('root','wheel_line','free_edge'),faces=('upper','lower'),local_reduction=1.,
        scope='Nominal direct components at prescribed detail locations; not all continuum points or exact passage history',
        action_ledger=i.action_ledger,geometry_provenance=i.geometry_provenance,
        all_service_states_provenance=i.all_service_states_provenance,
        total_tensor_qualified=False,whole_beam_qualified=False,contact_fatigue_qualified=False)

def compose_nominal_tensor(global_intervals_mpa, local_box, *, same_point_and_ledger_confirmed, source_model_adopted):
    """Explicit EN6 nominal-method composition, NOT physical local-shear=zero.
    Global source must include shear, Saint-Venant/warping torsion and axial/bending.
    EN6 9.3.4 adopts 5.8's two local direct components; no additional local twisting
    term is prescribed in THIS nominal model. Other local/contact mechanisms excluded.
    """
    from .tensor_bounds import tensor_box_bounds
    if same_point_and_ledger_confirmed is not True or source_model_adopted is not True:raise ValueError('Explicit same-point, same-ledger nominal method adoption required')
    tensor_box_bounds(global_intervals_mpa)
    if local_box.get('producer_kind')!='SOURCE_PRESCRIBED_NOMINAL_DESIGN_BOX':raise ValueError('Wrong local producer')
    out=dict(global_intervals_mpa)
    for k in ('sx','sy'):
        a,b=out[k];c,d=local_box[k+'_mpa'];out[k]=(a+c,b+d)
    tensor_box_bounds(out)
    return dict(intervals_mpa=out,producer_kind='COMPOSED_SOURCE_PRESCRIBED_NOMINAL_TENSOR',
        local_shear_treatment='No additional local twisting term prescribed by adopted EN6 5.8/9.3.4 nominal model; not a physical zero claim',
        physical_full_3d_local_field_covered=False,contact_covered=False)
