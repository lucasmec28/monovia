"""Internally generated CMAA74:2020 nominal load origins, independent of NBR.

Mechanical bridge transfer is reused, not its EN/NBR dynamic factors. DL and TL
stay separate. DLF, HLF and IFD are rebuilt from physical speeds/accelerations;
IFD acts on the entire transferred vector, including vertical redistribution.
Skew is an explicitly conservative per-wheel force enclosure, not an invented
physical sign pattern, exact graph digitization, or proof of an actual failure.
"""
from dataclasses import dataclass, asdict, replace
from itertools import product
from .kernel import (SOURCE, EDITION, ACTION_BASIS, DomainError, number, text,
                     digest, CMAA74Case2Ledger)
from ..autonomous_workflow.model import PhysicalWheel, MovingCase
from ..autonomous_workflow.inertia_bridge_adapter import (
    BridgeInertiaInputs, from_dict, generate_inertia_configurations)
from ..bridge_inertia.statics import SEPARATE_MASS_CONVENTION, suspended_mass_accounting

FT_M = .3048
CASE2_FORMULA = 'DL*DLF_B + TL*DLF_T + LL*(1+HLF) + IFD + WLO + SK'


def dead_load_factor(travel_speed_m_s):
    v = number(travel_speed_m_s, 'physical travel speed m/s', nonnegative=True)
    return max(1.1, min(1.2, 1.05+(60*v/FT_M)/2000))


def hoist_load_factor(hoist_speed_m_s):
    v = number(hoist_speed_m_s, 'normal non-abrupt hoist speed m/s', nonnegative=True)
    return max(.15, min(.5, .005*60*v/FT_M))


def inertia_drive_factor(acceleration_m_s2):
    a = abs(number(acceleration_m_s2, 'nominal acceleration/deceleration m/s2'))
    # Source equation uses 32.2 ft/s2, rather than a rounded .078 multiplier.
    return max(.025, (2.50/32.2)*(a/FT_M))


def skew_coefficient_enclosure(span_mm, outermost_wheelbase_mm):
    span = number(span_mm, 'bridge span', positive=True)
    base = number(outermost_wheelbase_mm, 'outermost wheel base', positive=True)
    ratio = span/base
    if not 2 <= ratio <= 8:
        raise DomainError('Span/outermost wheelbase must be within inspected SK graph 2..8; no unplotted low-ratio extrapolation or >8 end-truck extension')
    # The source graph is flat .05 through ratio4, then rises to below .20 at8.
    # No claim that .20 is the graph's literal coefficient is made.
    value = .05 if ratio <= 4 else .20
    return dict(ratio=ratio, coefficient_upper=value,
                source=SOURCE+' 3.3.2.2.2 PDF20 graph; 3.6.1 PDF38',
                method='source_graph_plateau' if ratio <= 4 else 'conservative_0.20_graph_enclosure_not_literal_CMAA_coefficient',
                graph_digitized_exactly=False,implemented_graph_ratio_interval=[2.,8.])


@dataclass(frozen=True)
class CMAA74PhysicalInputs:
    bridge_travel_speed_m_s: float
    trolley_travel_speed_m_s: float
    hoist_speed_m_s: float
    operating_environment: str
    load_engagement: str
    lifted_mass_scope: str
    crane_configuration: str
    source: str
    empty_suspended_mass_kg: float | None = None
    empty_suspended_cg_x_mm: float | None = None
    empty_suspended_cg_z_mm: float | None = None

    def validate(self):
        for key in ('bridge_travel_speed_m_s', 'trolley_travel_speed_m_s', 'hoist_speed_m_s'):
            number(getattr(self, key), key, nonnegative=True)
        if self.operating_environment != 'indoor_no_operating_wind':
            raise DomainError('Outdoor/operating wind WLO requires a separate projected-area force-transfer model; not zero by default')
        if self.load_engagement != 'normal_non_abrupt':
            raise DomainError('Abrupt engagement requires at least 50% HLF and a separate qualified domain')
        if self.lifted_mass_scope not in ('capacity_includes_load_block_and_attachments','payload_plus_retained_common_ledger'):
            raise DomainError('CMAA LL includes load block and all lifting/holding attachments, not rated payload alone')
        if self.crane_configuration not in ('single_girder_under_running_trolley', 'not_established_adopted_nominal_method'):
            raise DomainError('Identify CMAA74 single-girder crane scope or explicit adopted nominal-method scope')
        if self.empty_suspended_mass_kg is None:
            raise DomainError('Explicit retained suspended block/accessory mass in empty operation is required, including a sourced zero')
        number(self.empty_suspended_mass_kg, 'empty retained suspended mass', nonnegative=True)
        for key in ('empty_suspended_cg_x_mm','empty_suspended_cg_z_mm'):
            if getattr(self,key) is not None:
                number(getattr(self,key),key)
        text(self.source, 'Physical speed, environment, load, retained block/accessory mass and crane configuration source')
        return self


@dataclass(frozen=True)
class CMAA74GeneratedCase:
    case: MovingCase
    wheels: tuple
    ledger: CMAA74Case2Ledger
    full_contact_forces: tuple
    physical_components: tuple
    skew_force_bounds: tuple
    contact_domain_valid: bool
    source_scope: dict


def _sum_vectors(rows):
    return [sum(r[i] for r in rows) for i in range(3)]



def validate_cmaa_mass_ledger(p,physical):
    """CMAA consumes the explicit common four-origin ledger, never another B."""
    physical.validate()
    if p.mass_accounting_convention!=SEPARATE_MASS_CONVENTION:
        raise DomainError('CMAA requires explicit common payload_plus_retained_suspended_mass accounting; legacy retained mass is unspecified, not zero. Convert from declared physical inputs first.')
    if physical.lifted_mass_scope!='payload_plus_retained_common_ledger':
        raise DomainError('CMAA lifted_mass_scope must identify payload_plus_retained_common_ledger; capacity is payload, not total LL')
    if physical.empty_suspended_mass_kg!=p.retained_suspended_mass_kg:
        raise DomainError('CMAA retained suspended mass differs from the common physical ledger; no duplicate B or override')
    if p.transfer_model=='free_suspended_at_crab':
        if physical.empty_suspended_cg_x_mm is not None or physical.empty_suspended_cg_z_mm is not None:
            raise DomainError('Free-rope residual load uses the identified crab transfer point, not payload CG')
    elif p.retained_suspended_mass_kg:
        if physical.empty_suspended_cg_x_mm is None or physical.empty_suspended_cg_z_mm is None:
            raise DomainError('Nonzero retained mass requires its own physical CG, bound to the common ledger')
        if (physical.empty_suspended_cg_x_mm,physical.empty_suspended_cg_z_mm)!=(p.retained_suspended_cg_x_mm,p.retained_suspended_cg_z_mm):
            raise DomainError('CMAA retained CG differs from the common physical ledger; regenerate physical inputs')
    return suspended_mass_accounting(p)

def generate_case2_actions(section, bridge_inputs, configuration_id, physical):
    """Return eight loaded/empty ±IFD cases and uncollapsed physical parcels.

    Contact SK is a normal-to-rail force applied at each contact itself. Thus
    it acquires the real beam-centre eccentric moment, but no invented CG
    redistribution. Independent force signs/magnitudes form an outer set that
    includes any physical skew pattern satisfying the per-wheel source limit.
    The source does not resolve VIF in SK: maximum dynamic vertical reaction
    over all IFD signs is used, so either undynamic/dynamic reading is enclosed.
    This enclosure can prove sufficient acceptance, not actual rejection.
    """
    if not isinstance(physical, CMAA74PhysicalInputs):
        raise DomainError('CMAA74PhysicalInputs required')
    physical.validate()
    p = from_dict(bridge_inputs) if isinstance(bridge_inputs, dict) else bridge_inputs
    if not isinstance(p, BridgeInertiaInputs):
        raise DomainError('Original physical BridgeInertiaInputs required')
    mass_accounting=validate_cmaa_mass_ledger(p,physical)
    dlf_b = dead_load_factor(physical.bridge_travel_speed_m_s)
    dlf_t = dead_load_factor(physical.trolley_travel_speed_m_s)
    hlf = hoist_load_factor(physical.hoist_speed_m_s)
    ifd_b = inertia_drive_factor(p.bridge_acceleration_m_s2)
    ifd_t = inertia_drive_factor(p.trolley_acceleration_m_s2)
    sk = skew_coefficient_enclosure(p.bridge_span_mm, p.carriage_station_spacing_mm)
    # Rebuild from physical masses, not scaled previously factored wheel totals.
    # Effective acceleration * mass = IFD * weight. Dynamic multiplier = 1.
    effective = replace(p, bridge_acceleration_m_s2=ifd_b*p.gravity_m_s2,
                        trolley_acceleration_m_s2=ifd_t*p.gravity_m_s2,
                        horizontal_dynamic_factor=1.)
    generated = generate_inertia_configurations(section, effective)
    configs = [r for r in generated['configurations'] if r['id'] == configuration_id]
    if len(configs) != 1:
        raise DomainError('Selected physical bridge configuration does not exist')
    configuration = configs[0]
    endpoint = next(r for r in generated['endpoint_receipts'] if r['id'] == configuration['endpoint_id'])
    g = endpoint['generated']
    if not g['statics_balanced']:
        raise DomainError('Underlying physical parcel equilibrium is not established')
    original = dict(section_signature=section.signature, bridge_inputs=asdict(p),
                    physical_inputs=asdict(physical), configuration_id=configuration_id)
    physical_sig = digest(original)
    components_by_state={}
    for loaded in (True,False):
        components=[]
        for contact in g['contacts']:
            origins={}
            for mass in ('bridge','trolley','payload','retained_suspended'):
                for action in ('gravity','HX','HY'):
                    parcel=next(r for r in g['parcels'] if r['mass_id']==mass and r['action']==action)
                    vector=list(next(r['force_N'] for r in parcel['loads'] if r['contact_id']==contact['id']))
                    origins[mass+'/'+action]=[0.,0.,0.] if mass=='payload' and not loaded else vector
            components.append(dict(contact_id=contact['id'],position_mm=contact['position_mm'],
                rail_index=contact['rail_index'],outstand_sign=contact['outstand_sign'],origins=origins,
                suspended_mass_state='payload_plus_retained' if loaded else 'retained_only',
                common_four_mass_ledger=True))
        components_by_state[loaded]=components
    component_sig=digest(components_by_state)
    source_scope = dict(edition=EDITION, source=SOURCE, formula=CASE2_FORMULA,
        nominal_ASD_not_ULS=True, original_horizontal_multiplier_not_reused=p.horizontal_dynamic_factor,
        IFD_250_percent_included_once=True, WLO='zero only within declared indoor_no_operating_wind domain',
        SK=sk, SK_signs='Independent per-wheel envelope, not a physical fore/aft skew witness',
        SK_vertical_basis='Upper of source ambiguity: dynamic downward contact reaction over both IFD signs; never less than gravity reaction',
        crane_configuration=physical.crane_configuration,
        full_CMAA_scope_established=physical.crane_configuration == 'single_girder_under_running_trolley',
        force_transfer_model=p.transfer_model, physical_drive_or_equalizer_qualified=False,
        global_NBR8800_actions_not_reused=True,
        loaded_LL_mass_kg=1000*p.capacity_t+p.retained_suspended_mass_kg,empty_retained_LL_mass_kg=p.retained_suspended_mass_kg,
        common_suspended_mass_accounting=mass_accounting,
        empty_LL_placement='Retained LL*(1+HLF) remains in retained_lifted_N under the suspended-load factor; never equipment dead_N.')
    out = []
    for loaded, sx, sy in product((True, False), (-1, 1), (-1, 1)):
        ident = 'CMAA74_CASE2/'+configuration_id+('/loaded' if loaded else '/empty')+f'/IFDX{sx:+d}/IFDY{sy:+d}'
        ledger = CMAA74Case2Ledger(ident, physical_sig, component_sig, dlf_b, dlf_t, hlf,
                                  ifd_b, ifd_t, loaded, sx, sy, 'conservative_case2_enclosure')
        components=components_by_state[loaded]
        wheels = []
        full = []
        skew_bounds = []
        for c in components:
            o = c['origins']
            dl = -o['bridge/gravity'][2]
            tl = -o['trolley/gravity'][2]
            payload = -o['payload/gravity'][2]
            retained = -o['retained_suspended/gravity'][2]
            ll=payload+retained
            mass_ids = ('bridge','trolley','payload','retained_suspended')
            hx = _sum_vectors([o[m+'/HX'] for m in mass_ids])
            hy = _sum_vectors([o[m+'/HY'] for m in mass_ids])
            dead = dlf_b*dl+dlf_t*tl
            lift = (1+hlf)*ll
            vec = [sx*hx[0]+sy*hy[0], sx*hx[1]+sy*hy[1], -dead-lift+sx*hx[2]+sy*hy[2]]
            p_upper = dead+lift+abs(hx[2])+abs(hy[2])
            sk_bound = sk['coefficient_upper']*p_upper
            full.append(dict(contact_id=c['contact_id'], position_mm=c['position_mm'], force_N=vec,
                             DL_N=dl, TL_N=tl, LL_N=ll, payload_N=payload,retained_LL_N=retained,vertical_dynamic_N=dead+lift,
                             IFD_bridge_vector_N=hx, IFD_trolley_vector_N=hy,
                             SK_transverse_abs_upper_N=sk_bound))
            if c['rail_index'] != configuration['rail_index']:
                continue
            template = next(w for w in configuration['wheels'] if w['id'].endswith('/'+c['contact_id']))
            wid = template['id']
            wheels.append(PhysicalWheel(wid, template['offset_mm'], template['y_mm'], template['z_mm'], template['omega_mm2'],
                        dead, (1+hlf)*payload, hx[0], hy[1], SOURCE+' internally regenerated component ledger '+physical_sig,
                        True, longitudinal_vertical_N=hx[2], transverse_vertical_N=hy[2],
                        retained_lifted_N=(1+hlf)*retained,suspended_mass_accounting='explicit_payload_plus_retained'))
            skew_bounds.append(dict(wheel_id=wid, force_abs_N=sk_bound,
                                    application='physical contact normal-to-rail at same y,z',
                                    ordinate_upper_N=p_upper, coefficient=sk['coefficient_upper']))
        case = MovingCase(ident, 'CMAA74_CASE2', 1., 1., 1., 1., 1., sx, sy, loaded,
                          SOURCE+' 3.3.2.5.2; rebuilt nominal origins; SK envelope separate', 1.)
        # Empty payload still retains its explicitly modelled suspended block/attachments.
        # Retained LL stays separate from permanent equipment in every state.
        out.append(CMAA74GeneratedCase(case, tuple(wheels), ledger, tuple(full), tuple(components),
                                      tuple(skew_bounds), all(r['force_N'][2] <= 1e-9 for r in full), source_scope))
    return tuple(out)


def generate_case2_cases(project, physical):
    """Verify current project and original bound physical ledger before rebuilding."""
    project.validate()
    ledger = project.bridge_reaction_ledger
    if not ledger or ledger.get('schema') != 'LRO_BOUND_BRIDGE_INERTIA_LEDGER_V1':
        raise DomainError('Internally bound physical bridge inertia ledger required; collapsed G/Q or external ULS tensors cannot identify DL/TL/IFD origins')
    return generate_case2_actions(project.section, ledger['inputs'], ledger['selected_configuration_id'], physical)
