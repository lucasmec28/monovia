"""CMAA74:2020 consumer of internally verified MECHANICAL response bases.

Original NBR family coefficients/combined boxes are never reused as CMAA demands.
All 8 physical configurations and 64 nominal loaded/empty IFD states are rebuilt
from source CMAA actions. SK is an independent force enclosure. Component boxes
are NOT simultaneous stresses, actual failure witnesses or physical governors.
"""
from dataclasses import asdict
from pathlib import Path
from math import isfinite
from itertools import product
from .actions import CMAA74PhysicalInputs, generate_case2_actions
from .kernel import (SOURCE, EDITION, DomainError, CMAA74Geometry,
                     parallel_flange_coefficients, plane_von_mises, number, digest)
from ..autonomous_workflow.model import signature, wheel_force_components
from ..autonomous_workflow.family_envelope import (FIELDS, GEOMETRY_FIELDS, interval_product,
    interval_sum, _response_interval, _source)
from ..section_stress.recovery import geometric_properties
from ..stability.family_adapter import validate_family_receipt


def _require(ok,message):
    if not ok:
        raise DomainError(message)


def _interval(lo,hi):
    _require(all(type(x) in (int,float) and isfinite(x) for x in (lo,hi)) and lo<=hi,'Finite ordered component interval required')
    return dict(lower=float(lo),upper=float(hi))


def _scale(interval,factor):
    return interval_product(interval,_interval(factor,factor))


def _same_mechanical_project(project,action_project):
    """Private LL aggregation may change actions, never response geometry/mass."""
    action_project.validate()
    a,b=project.to_dict(),action_project.to_dict()
    for key in ('wheels','bridge_reaction_ledger','capacity_tf','source_notes'):
        a.pop(key,None);b.pop(key,None)
    _require(a==b,'CMAA private action project changed the verified frame/material/permanent-load/travel model')
    ledger=action_project.bridge_reaction_ledger
    _require(isinstance(ledger,dict) and ledger.get('schema')=='LRO_BOUND_BRIDGE_INERTIA_LEDGER_V1','CMAA action project needs regenerated bound physical inputs')
    return ledger


def generate_cmaa_family_coefficients(project,plan,physical,*,cmaa_action_project=None,cmaa_conversion_receipt=None):
    """Pure source-based force composition, no numeric-response qualification.

    A basis applies amplitude to EACH opposed wheel. Two independent SK forces
    at identical x/z have the same beam influence; their summed interval divided
    by two is therefore the equivalent per-contact coefficient. This equivalence
    is NOT an assumption that the physical SK forces split equally.
    """
    _require(isinstance(physical,CMAA74PhysicalInputs),'CMAA physical action inputs required')
    physical.validate()
    action_project=project if cmaa_action_project is None else cmaa_action_project
    if cmaa_action_project is not None:
        from ..autonomous_ui.cmaa_inputs import validate_cmaa74_action_conversion
        validate_cmaa74_action_conversion(project,physical,cmaa_action_project,cmaa_conversion_receipt)
    else:
        _require(cmaa_conversion_receipt is None,
                 'CMAA conversion receipt requires its exact private action project')
    ledger=_same_mechanical_project(project,action_project)
    bases={b.id:b for b in plan['bases']}
    configs=plan['configurations']
    _require(len(configs)==8 and len({c['id'] for c in configs})==8,'All eight verified physical configurations required')
    template=next(iter(plan['wheels_by_configuration'].values()))
    template_geometry=tuple(tuple(getattr(w,k) for k in GEOMETRY_FIELDS) for w in template)
    members=[]
    wheel_ranges=[[] for _ in template]
    missing=set()
    for config in configs:
        for generated in generate_case2_actions(project.section,ledger['inputs'],config['id'],physical):
            _require(generated.contact_domain_valid,'At least one CMAA state has upward contact in the full eight-wheel bridge; no clipping or skipped state')
            wheels=tuple(sorted(generated.wheels,key=lambda w:(w.offset_mm,w.y_mm)))
            _require(tuple(tuple(getattr(w,k) for k in GEOMETRY_FIELDS) for w in wheels)==template_geometry,
                     'New CMAA physical contacts differ from verified mechanical force-basis geometry')
            forces=[wheel_force_components(w,generated.case) for w in wheels]
            sk={r['wheel_id']:r['force_abs_N'] for r in generated.skew_force_bounds}
            raw={}
            for station in (0,1):
                i=2*station
                _require(forces[i]==forces[i+1],'CMAA opposed gravity/IFD actions unequal; paired basis cannot silently average them')
                fx,fy,fz=forces[i]
                _require(fz<=1e-9,'CMAA downward contact prerequisite not established')
                half_sk=(sk[wheels[i].id]+sk[wheels[i+1].id])/2
                raw[f'station{station}/Fx']=_interval(fx,fx)
                raw[f'station{station}/Fy']=interval_sum((_interval(fy,fy),_interval(-half_sk,half_sk)))
                raw[f'station{station}/downward_Fz']=_interval(-fz,-fz)
            raw['selfweight']=_interval(1.,1.)
            if project.extra_dead_N_per_mm:
                raw['accessory_dead']=_interval(1.,1.)
            coefficients={}
            for name,values in raw.items():
                _require(name in bases,'Missing physical mechanical basis definition: '+name)
                amp=bases[name].amplitude
                if amp==0:
                    if values['lower']!=0 or values['upper']!=0:
                        missing.add(name)
                    coefficients[name]=_interval(0.,0.)
                else:
                    coefficients[name]=_scale(values,1/amp)
            for i,(_,_,fz) in enumerate(forces):
                wheel_ranges[i].append(-fz)
            members.append(dict(configuration_id=config['id'],case_id=generated.case.id,
                case=asdict(generated.case),ledger=asdict(generated.ledger),raw_coefficient_intervals=raw,
                coefficient_intervals=coefficients,skew_force_bounds=list(generated.skew_force_bounds)))
    _require(not missing,'CMAA IFD/SK requires previously zero/unverified mechanical bases: '+', '.join(sorted(missing))+'. Recompute these physical force bases; no false zero or NBR-factor substitution.')
    _require(len(members)==64,'Complete eight-configuration CMAA Case2 membership requires 64 states')
    coefficients={name:_interval(min(m['coefficient_intervals'][name]['lower'] for m in members),
                                 max(m['coefficient_intervals'][name]['upper'] for m in members)) for name in bases}
    wheels=[dict(contact_index=i,**{k:getattr(w,k) for k in GEOMETRY_FIELDS},
                 downward_N=_interval(min(wheel_ranges[i]),max(wheel_ranges[i]))) for i,w in enumerate(template)]
    return dict(members=members,coefficient_intervals=coefficients,wheel_vertical_actions=wheels,
                total_configuration_count=8,total_case_count=64,source=SOURCE,edition=EDITION,
                max_absolute_normalized_coefficient=max(abs(v) for row in coefficients.values() for v in row.values()),
                coefficient_magnification_allowed_with_scaled_verification_allowances=True,
                original_project_signature=signature(project.to_dict()),cmaa_action_project_signature=signature(action_project.to_dict()),
                reused_original_normative_coefficients=False,skew_is_conservative_enclosure=True,
                same_frame_geometry_validated=True,source_scope=generated.source_scope,
                configuration_domain=dict(
                    hook_from_left_mm=[ledger['inputs']['hook_min_from_left_mm'],ledger['inputs']['hook_max_from_left_mm']],
                    loaded_force_transfer_height_mm=([ledger['inputs']['suspension_point_z_mm']]*2
                        if ledger['inputs']['transfer_model']=='free_suspended_at_crab' else
                        [ledger['inputs']['lifted_cg_z_min_mm'],ledger['inputs']['lifted_cg_z_max_mm']]),
                    height_coordinate_basis=('Declared crab force-application point, not hanging payload CG'
                        if ledger['inputs']['transfer_model']=='free_suspended_at_crab' else
                        'Declared guided/rigid loaded LL centroid after any mass conversion'),
                    both_runway_rails=True,interior_configurations_enclosed=True,
                    method='Bilinear equalized gravity/IFD forces are convex combinations of hook/height corners. Absolute IFD terms in SK obey the triangle inequality, so their independent force intervals are enclosed by the corner coefficient intervals.',
                    actual_hardware_realization_confirmed=False))


def compose_cmaa_response_box(plan,evidence,coefficients):
    """Scale complete verified intervals INCLUDING their numerical allowances.

    New CMAA coefficient magnitudes may exceed the original binary normalization;
    interval multiplication scales both response and allowance, so no discarded
    error is magnified. This remains engineering-numerical evidence, not a proof
    of continuum or roundoff error bounds.
    """
    result={}
    for field in FIELDS:
        terms=[]
        for basis in plan['bases']:
            coef=coefficients[basis.id]
            if coef['lower']==coef['upper']==0:
                continue
            _require(basis.amplitude!=0 and basis.id in evidence,'Required CMAA mechanical basis is unverified: '+basis.id)
            verification=evidence[basis.id]['verification']
            response=_response_interval(verification['refined_extrema'],field,verification)
            terms.append(interval_product(coef,response))
        result[field]=interval_sum(terms)
    return result


def cmaa_nominal_vertex_checks(box,fy_MPa):
    """All eight mathematical vertices of signed CMAA (transverse,longitudinal,tau)."""
    fy=number(fy_MPa,'material fy',positive=True)
    for key in ('sigma_transverse','sigma_longitudinal','tau_xy'):
        _interval(*box[key])
    retained={}
    for sx,sy,tau in product(*(box[k] for k in ('sigma_transverse','sigma_longitudinal','tau_xy'))):
        values=(('sigma_transverse',abs(sx),.66*fy),('sigma_longitudinal',abs(sy),.66*fy),
                ('tau_xy',abs(tau),.40*fy),('combined_von_mises',plane_von_mises(sx,sy,tau),.66*fy))
        for name,demand,allowable in values:
            ratio=demand/allowable
            if name not in retained or ratio>retained[name]['utilization']:
                retained[name]=dict(id=name,demand_bound_MPa=demand,allowable_MPa=allowable,utilization=ratio,
                    status='PASS' if demand<=allowable else 'INCONCLUSIVE',qualified=True,
                    mathematical_vertex=dict(sigma_transverse=sx,sigma_longitudinal=sy,tau_xy=tau),
                    concurrent_tensor_claimed=False,actual_failure_proven=False,bound_exceedance_is_failure=False)
    return list(retained.values())


def cmaa_point_stress_box(section,response,*,point,outstand_side,contact_y_mm,wheel_vertical_interval):
    """CMAA P0 web face/P1 wheel underside; point-specific global shear box."""
    _require(point in (0,1) and outstand_side in ('left','right'),'CMAA rolled prescribed P0/P1 and physical outstand required')
    p=geometric_properties(section)
    sign=-1 if outstand_side=='left' else 1
    y=sign*section.tw_mm/2 if point==0 else contact_y_mm
    _require(y*sign>0,'Contact ordinate and outstand side differ')
    z=-p['centroid_from_bottom_mm'];zm=p['bottom_z_mid_mm'];eta=z-zm
    omega=-y*(zm-p['z_sc_mm'])
    geometry=CMAA74Geometry(section.bottom_width,section.tw_mm,section.bottom_thickness,
        section.bottom_width/2-abs(contact_y_mm),'rolled',section.root_extent)
    cx,cy=parallel_flange_coefficients(geometry.lambda_)[point]
    global_y=interval_sum((_scale(response['N'],1/p['A_mm2']),_scale(response['My'],z/p['Iy_mm4']),
                          _scale(response['Mz'],-y/p['Iz_mm4']),_scale(response['B_equilibrated'],omega/p['Cw_mm6'])))
    a=section.bottom_width/2;qshape=(a*a-y*y)/2
    tau=interval_sum((_scale(response['Fy'],qshape/p['Iz_mm4']),
        _scale(response['Fz'],zm*sign*(a-abs(y))/p['Iy_mm4']),
        _scale(response['Tw_equilibrated'],-(zm-p['z_sc_mm'])*qshape/p['Cw_mm6']),
        _scale(response['Tsv'],-2*eta/p['J_mm4'])))
    lx=_scale(wheel_vertical_interval,cx/section.bottom_thickness**2)
    ly=_scale(wheel_vertical_interval,cy/section.bottom_thickness**2)
    sx=_scale(lx,.75)
    sy=interval_sum((global_y,_scale(ly,.75)))
    return dict(point=point,outstand_side=outstand_side,face='bottom',y_mm=y,z_mm=z,omega_mm2=omega,
        local_multipliers=dict(transverse=.75,longitudinal=.75),global_multiplier=1.,
        unreduced_local_intervals_MPa=dict(transverse=lx,longitudinal=ly),global_longitudinal_interval_MPa=global_y,
        stress_box_MPa=dict(sigma_transverse=(sx['lower'],sx['upper']),sigma_longitudinal=(sy['lower'],sy['upper']),tau_xy=(tau['lower'],tau['upper'])),
        source=SOURCE+' 3.3.2.6.1-.2 / 3.4.4.1 / Table3.4-1 Case2',
        source_point_coordinates='CMAA P0 at web face, not EN/NBR fillet tangent; P1 below physical wheel')


def evaluate_cmaa74_family(project,receipt,*,physical,cmaa_action_project=None,cmaa_conversion_receipt=None):
    """Reuse verified mechanics for ALL regenerated CMAA configurations/states."""
    result=dict(kind='CMAA74_2020_verified_mechanical_family_consumer',status='CMAA_FAMILY_PENDING',points=[],pending=[],pending_obligations=[],
        ordinary_nominal_points_qualified=False,ordinary_nominal_ASD_sufficient=False,all_operating_positions_qualified=False,
        local_bottom_flange_complete=False,whole_design_complete=False,actual_failure_proven=False,known_failures=[],
        operating_configuration_envelope_complete=False,
        concurrent_tensor_claimed=False,governing_physical_state_invented=False,continuum_upper_bound_claimed=False,
        external_efforts_required=False,source_basis_separate_from_NBR8800_ULS=True,edition=EDITION)
    source_files=('__init__.py','family_adapter.py','actions.py','kernel.py','autonomous_adapter.py')
    conversion_path=Path(__file__).parents[1]/'autonomous_ui/cmaa_inputs.py'
    validator_path=Path(__file__).parents[1]/'stability/family_adapter.py'
    def consumer_source():
        return digest(dict(cmaa={n:Path(__file__).with_name(n).read_text() for n in source_files},
                           mass_conversion=conversion_path.read_text(),
                           mass_conversion_initializer=conversion_path.with_name('__init__.py').read_text(),
                           mechanical_receipt_validator=validator_path.read_text()))
    own=consumer_source()
    try:
        before=signature(project.to_dict())
        action_before=signature((project if cmaa_action_project is None else cmaa_action_project).to_dict())
        _,plan=validate_family_receipt(project,receipt)
        _require(project.section.construction=='rolled','CMAA ordinary family domain is rolled parallel flange; welded P2 is separate')
        _require(project.fy_mpa is not None,'Material fy required')
        family=generate_cmaa_family_coefficients(project,plan,physical,cmaa_action_project=cmaa_action_project,
            cmaa_conversion_receipt=cmaa_conversion_receipt)
        response=compose_cmaa_response_box(plan,receipt['basis_evidence'],family['coefficient_intervals'])
        s=project.section
        wheels=family['wheel_vertical_actions']
        offsets=sorted({w['offset_mm'] for w in wheels})
        _require(len(offsets)==2 and offsets[1]-offsets[0]>=1.5*s.bottom_width,
                 'Close-wheel interaction is outside implemented CMAA ordinary method; EN5.8 isolated spacing>=1.5b is only supplemental screening')
        end_distance=min(project.travel_min_mm+min(offsets),project.length_mm-project.travel_max_mm-max(offsets))
        _require(end_distance>s.bottom_width,
                 'Ordinary whole travel requires supplemental EN5.8 end-distance>b screen; no CMAA transfer/end formula is invented')
        transfer=[]
        for w in wheels:
            lo=project.travel_min_mm+w['offset_mm'];hi=project.travel_max_mm+w['offset_mm']
            for support in project.supports:
                if lo<=support['x']<=hi:
                    transfer.append(dict(wheel_contact_index=w['contact_index'],support_id=support['id'],section_x_mm=support['x']))
        for wheel in wheels:
            _require(wheel['downward_N']['lower']>=-1e-9,'Unilateral contact sign prerequisite failed')
            for point in (0,1):
                row=cmaa_point_stress_box(s,response,point=point,outstand_side='left' if wheel['y_mm']<0 else 'right',
                    contact_y_mm=wheel['y_mm'],wheel_vertical_interval=wheel['downward_N'])
                row.update(contact_index=wheel['contact_index'],station_offset_mm=wheel['offset_mm'],
                           checks=cmaa_nominal_vertex_checks(row['stress_box_MPa'],project.fy_mpa))
                result['points'].append(row)
        checks=[c for row in result['points'] for c in row['checks']]
        sufficient=bool(checks) and all(c['status']=='PASS' for c in checks)
        result.update(status='SUFFICIENT_CMAA_FAMILY_NOMINAL_BOUND' if sufficient else 'CMAA_FAMILY_BOUND_INCONCLUSIVE',
            ordinary_nominal_points_qualified=True,ordinary_nominal_ASD_sufficient=sufficient,
            all_operating_positions_qualified=not transfer,physical_configuration_count=8,physical_case_count=64,
            selected_configuration_only=False,paired_runway_mechanical_actions_included=True,
            operating_configuration_envelope_complete=True,
            operating_configuration_scope='Declared indoor non-abrupt normal Case2 domain within the bilinear equalized physical transfer model, not all crane actions or actual hardware qualification.',
            source_scope=family['source_scope'],minimum_end_distance_mm=end_distance,transfer_sections_excluded=transfer,
            coefficient_family=family,force_component_bounds=response,
            nominal_scope='CMAA74:2020 P0/P1 bottom nominal ordinary sections, both outstands, all8physical configurations/64Case2states and SK outer set; no simultaneous box tensor or physical governor.',
            separate_obligations=['global strength/buckling','contact','fatigue','suspension/load-transfer disturbances','extraordinary actions','actual drive/equalizer hardware'])
        if transfer:
            message='Physical passages cross suspension load-transfer sections; ordinary nominal sufficiency does not qualify these disturbed sections or complete local design.'
            result['pending_obligations'].append(dict(
                id='SUSPENSION_LOAD_TRANSFER_REGIONS',scope='disturbed_suspension_regions',
                status='BEAM_CHECK_NOT_QUALIFIED',pending_index=len(result['pending']),
                message=message,regions=transfer))
            result['pending'].append(message)
        _require(before==signature(project.to_dict()) and action_before==signature((project if cmaa_action_project is None else cmaa_action_project).to_dict()),'Physical input project changed during CMAA family consumption')
        _require(receipt['source_at_end']==_source(),'Verified mechanical source changed during CMAA family consumption')
        _require(own==consumer_source(),'CMAA family consumer or mass-conversion source changed')
        result['source_receipt']=dict(consumer_source_hash=own,producer_receipt_signature=receipt['receipt_signature'],
                                     original_project_signature=before,cmaa_action_project_signature=action_before,
                                     mass_conversion_receipt_signature=None if cmaa_conversion_receipt is None else cmaa_conversion_receipt['receipt_signature'])
    except (ValueError,TypeError,KeyError,ArithmeticError,AttributeError) as exc:
        result.update(status='CMAA_FAMILY_PENDING',points=[],ordinary_nominal_points_qualified=False,
                      ordinary_nominal_ASD_sufficient=False,all_operating_positions_qualified=False,
                      operating_configuration_envelope_complete=False)
        message=type(exc).__name__+': '+str(exc)
        result['pending_obligations'].append(dict(
            id='ORDINARY_CMAA_ASSESSMENT_ERROR',scope='ordinary_nominal_lower_flange',
            status='NOT_ASSESSED',pending_index=len(result['pending']),message=message))
        result['pending'].append(message)
    return result
