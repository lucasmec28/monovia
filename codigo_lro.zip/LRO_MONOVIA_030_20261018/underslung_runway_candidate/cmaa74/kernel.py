"""CMAA 74:2020 nominal lower-flange ASD, N, mm, MPa.

Native CMAA x = transverse, y = longitudinal. This is not the EN/NBR point
numbering: CMAA point 2 is TOP ROOT, never the free flange edge. The source is
user-supplied 2020 PDF pp.21-24 (printed 19-22), inspected visually. The 2025
edition was not read. Component ASD is additional to buckling/contact/fatigue.
"""
from dataclasses import dataclass, asdict
from math import exp, sqrt, isfinite
import hashlib
import json

SOURCE = 'CMAA 74:2020'
EDITION = 'cmaa74_2020_verified'
ACTION_BASIS = 'CMAA74_2020_CASE2_NOMINAL_ASD'


class DomainError(ValueError):
    pass


def number(value, name, *, positive=False, nonnegative=False):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not isfinite(value):
        raise DomainError(name + ' must be a finite real')
    if positive and value <= 0 or nonnegative and value < 0:
        raise DomainError(name + ' outside physical numerical domain')
    return float(value)


def text(value, name):
    if not isinstance(value, str) or not value.strip():
        raise DomainError(name + ' must identify the physical/source record')
    return value


def digest(value):
    return hashlib.sha256(json.dumps(value, default=asdict, sort_keys=True,
                                    separators=(',', ':'), allow_nan=False).encode()).hexdigest()


@dataclass(frozen=True)
class CMAA74Geometry:
    bottom_b_mm: float
    web_tw_mm: float
    thickness_at_contact_mm: float
    edge_to_contact_a_mm: float
    construction: str = 'rolled'
    root_extent_mm: float = 0.
    flange_shape: str = 'parallel'
    single_web_symmetric: bool = True

    def __post_init__(self):
        for key in ('bottom_b_mm', 'web_tw_mm', 'thickness_at_contact_mm', 'edge_to_contact_a_mm'):
            number(getattr(self, key), key, positive=True)
        number(self.root_extent_mm, 'root extent', nonnegative=True)
        if self.construction not in ('rolled', 'welded'):
            raise DomainError('Rolled or welded construction must be identified')
        if self.flange_shape != 'parallel' or self.single_web_symmetric is not True:
            raise DomainError('First implemented geometry is symmetric single-web parallel flange')
        if self.bottom_b_mm <= self.web_tw_mm:
            raise DomainError('Flange must be wider than web')
        clear = (self.bottom_b_mm-self.web_tw_mm)/2-self.root_extent_mm-self.edge_to_contact_a_mm
        if clear <= 0:
            raise DomainError('Contact centre must lie on clear outstand outside physical root/toe')
        if self.lambda_ > .65:
            raise DomainError('CMAA 74:2020 lambda must not exceed 0.65; no extrapolation')

    @property
    def lambda_(self):
        return 2*self.edge_to_contact_a_mm/(self.bottom_b_mm-self.web_tw_mm)


@dataclass(frozen=True)
class CMAA74Case2Ledger:
    """Identified nominal action origins. Built by actions.generate_case2_cases.

    This type records the engineering basis, not user-provided evidence of
    coverage. The autonomous adapter regenerates and binds its physical inputs.
    A user-set boolean cannot authorize an external or NBR ULS stress tensor.
    """
    case_id: str
    physical_input_signature: str
    component_signature: str
    DLF_B: float
    DLF_T: float
    HLF: float
    IFD_bridge: float
    IFD_trolley: float
    loaded: bool
    longitudinal_sign: int
    transverse_sign: int
    action_coverage: str
    source: str = SOURCE
    edition: str = EDITION
    basis: str = ACTION_BASIS

    def __post_init__(self):
        for key in ('case_id', 'physical_input_signature', 'component_signature'):
            text(getattr(self, key), key)
        if (self.source, self.edition, self.basis) != (SOURCE, EDITION, ACTION_BASIS):
            raise DomainError('Only separately generated nominal CMAA74:2020 Case2 actions accepted; no NBR ULS transfer')
        for key in ('DLF_B', 'DLF_T'):
            if not 1.1 <= number(getattr(self, key), key) <= 1.2:
                raise DomainError(key+' outside CMAA normal operating range')
        if not .15 <= number(self.HLF, 'HLF') <= .5:
            raise DomainError('Only normal non-abrupt HLF 0.15..0.50 is qualified')
        for key in ('IFD_bridge', 'IFD_trolley'):
            if number(getattr(self, key), key) < .025:
                raise DomainError('CMAA IFD minimum is 0.025')
        if type(self.loaded) is not bool:
            raise DomainError('Loaded/empty identity required')
        for key in ('longitudinal_sign', 'transverse_sign'):
            if type(getattr(self, key)) is not int or getattr(self, key) not in (-1, 1):
                raise DomainError('IFD signed direction must be +/-1')
        if self.action_coverage not in ('complete_case2', 'conservative_case2_enclosure', 'incomplete_case2'):
            raise DomainError('Explicit action coverage classification required')

    @property
    def signature(self):
        return digest(asdict(self))


@dataclass(frozen=True)
class CMAA74PointState:
    case_id: str
    ledger_signature: str
    wheel_id: str
    translation_mm: float
    section_x_mm: float
    cut_side: str
    outstand_side: str
    point: int
    individual_wheel_N: float
    global_sigma_transverse_MPa: float
    global_sigma_longitudinal_MPa: float
    global_tau_MPa: float
    global_tau_component_bound_MPa: float | None = None
    evidence: str = 'actual_same_state'

    def __post_init__(self):
        for key in ('case_id', 'ledger_signature', 'wheel_id'):
            text(getattr(self, key), key)
        for key in ('translation_mm', 'section_x_mm', 'global_sigma_transverse_MPa',
                    'global_sigma_longitudinal_MPa', 'global_tau_MPa'):
            number(getattr(self, key), key)
        number(self.individual_wheel_N, 'individual wheel action', nonnegative=True)
        if self.global_tau_component_bound_MPa is not None:
            number(self.global_tau_component_bound_MPa, 'same-point shear bound', nonnegative=True)
            if self.global_tau_component_bound_MPa+1e-12 < abs(self.global_tau_MPa):
                raise DomainError('Shear component bound smaller than signed same-point shear')
        if self.cut_side not in ('left', 'right') or self.outstand_side not in ('left', 'right'):
            raise DomainError('Physical cut side and outstand identity required')
        if type(self.point) is not int or self.point not in (0, 1, 2):
            raise DomainError('CMAA points are 0 underside root, 1 underside wheel, 2 topside root')
        if self.evidence not in ('actual_same_state', 'upper_bound'):
            raise DomainError('Actual same-state versus conservative upper-bound evidence required')


def parallel_flange_coefficients(lambda_):
    """Return native CMAA (Cx transverse, Cy longitudinal), points 0,1,2.

    §3.3.2.6.1 PDF pp.21-22. Source writes lambda<=.65, no positive lower
    bound; mathematical zero is accepted here, while physical geometry needs
    a positive edge clearance and contact outside the root.
    """
    q = number(lambda_, 'lambda', nonnegative=True)
    if q > .65:
        raise DomainError('CMAA lambda exceeds 0.65')
    x0 = -2.110+1.977*q+.0076*exp(6.53*q)
    x1 = 10.108-7.408*q-10.108*exp(-1.364*q)
    y0 = .050-.580*q+.148*exp(3.015*q)
    y1 = 2.230-1.49*q+1.390*exp(-18.33*q)
    return ((x0, y0), (x1, y1), (-x0, -y0))


def local_nominal_stresses(geometry, individual_wheel_N):
    if not isinstance(geometry, CMAA74Geometry):
        raise DomainError('CMAA geometry required')
    p = number(individual_wheel_N, 'individual wheel action including HLF', nonnegative=True)
    scale = p/geometry.thickness_at_contact_mm**2
    return tuple(tuple(v*scale for v in pair) for pair in parallel_flange_coefficients(geometry.lambda_))


def plane_von_mises(sigma_x, sigma_y, tau_xy):
    for v in (sigma_x, sigma_y, tau_xy):
        number(v, 'signed plane stress')
    return sqrt(max(0., sigma_x*sigma_x+sigma_y*sigma_y-sigma_x*sigma_y+3*tau_xy*tau_xy))


def principal_stresses(sigma_x, sigma_y, tau_xy):
    for v in (sigma_x, sigma_y, tau_xy):
        number(v, 'signed plane stress')
    mean = (sigma_x+sigma_y)/2
    radius = sqrt((sigma_x-sigma_y)**2+4*tau_xy*tau_xy)/2
    return mean+radius, mean-radius


def _check(name, actual, bound, allowable, *, actual_evidence, coverage_complete):
    actual_ratio = abs(actual)/allowable
    ratio = max(abs(actual), abs(bound))/allowable
    # An upper-bound exceedance does not prove failure. Independent witnessed
    # same-state component failure is retained even if another mode is pending.
    status = ('FAIL' if actual_evidence and actual_ratio > 1 else
              'INCONCLUSIVE' if ratio > 1 or not coverage_complete else 'PASS')
    return dict(id=name, demand_MPa=abs(actual), demand_bound_MPa=abs(bound),
                allowable_MPa=allowable, actual_utilization=actual_ratio,
                utilization=ratio, status=status, bound_exceedance_is_failure=False)


def evaluate_case2_point(geometry, ledger, state, *, fy_MPa):
    """Source-prescribed nominal P0/P1 ASD, never overall design acceptance.

    Signed tensors are coexistent at this point/cut/case. Both local normal
    components are multiplied by .75, never the global stress. P2's unreduced
    opposite-root stresses and principals are diagnostic until separate welded
    base/weld and category-E fatigue checks are supplied.
    """
    if not isinstance(ledger, CMAA74Case2Ledger) or not isinstance(state, CMAA74PointState):
        raise DomainError('Typed CMAA nominal Case2 ledger and point state required')
    if state.case_id != ledger.case_id or state.ledger_signature != ledger.signature:
        raise DomainError('Local/global state does not belong to the same generated Case2 ledger')
    fy = number(fy_MPa, 'material fy MPa', positive=True)
    lx, ly = local_nominal_stresses(geometry, state.individual_wheel_N)[state.point]
    factor = .75 if state.point in (0, 1) else 1.
    sx = state.global_sigma_transverse_MPa+factor*lx
    sy = state.global_sigma_longitudinal_MPa+factor*ly
    tau = state.global_tau_MPa
    bound = abs(tau) if state.global_tau_component_bound_MPa is None else state.global_tau_component_bound_MPa
    vm = plane_von_mises(sx, sy, tau)
    vmb = plane_von_mises(sx, sy, bound)
    if state.point == 2:
        if geometry.construction != 'welded':
            raise DomainError('CMAA point2 additional check is specified for welded plate girders, not rolled free-edge replacement')
        return dict(status='INCONCLUSIVE', checks=[], point=2, surface='top_root',
                    local_multiplier=1., sigma_transverse_MPa=sx, sigma_longitudinal_MPa=sy,
                    tau_MPa=tau, principal_stresses_MPa=principal_stresses(sx, sy, tau),
                    source=SOURCE+' 3.3.2.6.3 / 3.4.4.2-.3',
                    pending=['Welded root base-metal and weld-metal allowables/geometry and category E Case1 fatigue remain separate.'],
                    whole_design_complete=False)
    complete = ledger.action_coverage != 'incomplete_case2'
    actual = state.evidence == 'actual_same_state' and ledger.action_coverage == 'complete_case2'
    checks = [_check('sigma_transverse', sx, sx, .66*fy, actual_evidence=actual, coverage_complete=complete),
              _check('sigma_longitudinal', sy, sy, .66*fy, actual_evidence=actual, coverage_complete=complete),
              _check('tau_xy', tau, bound, .40*fy, actual_evidence=actual, coverage_complete=complete),
              _check('combined_von_mises', vm, vmb, .66*fy, actual_evidence=actual, coverage_complete=complete)]
    status = 'FAIL' if any(c['status'] == 'FAIL' for c in checks) else 'INCONCLUSIVE' if any(c['status'] == 'INCONCLUSIVE' for c in checks) else 'PASS'
    return dict(status=status, checks=checks, point=state.point, surface='bottom',
                sigma_transverse_MPa=sx, sigma_longitudinal_MPa=sy, tau_MPa=tau,
                tau_component_bound_MPa=bound, von_mises_MPa=vm, von_mises_bound_MPa=vmb,
                local_sigma_transverse_unreduced_MPa=lx, local_sigma_longitudinal_unreduced_MPa=ly,
                local_multiplier=.75, global_multiplier=1.,
                physical_identity=asdict(state), source=SOURCE+' 3.3.2.6.1-.2 / 3.4.4.1 / Table3.4-1 Case2',
                edition=EDITION, action_basis=ACTION_BASIS,
                nominal_point_scope_only=True, whole_design_complete=False,
                separate_obligations=['buckling', 'wheel contact', 'fatigue', 'connections', 'load-transfer/end disturbances'])
