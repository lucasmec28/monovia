"""Internally solved CMAA74 nominal ASD points with explicit skew outer bound.

Reuses existing elastic FrameModel and moving-event/convergence machinery only.
No NBR ULS stresses, NBR local multipliers, EN dynamic factors, external Robot
results, user proof toggle, or catalogue admissible load enters this route.
"""
from dataclasses import asdict, replace
from pathlib import Path
from copy import deepcopy
from math import isclose
from .actions import CMAA74PhysicalInputs, CMAA74GeneratedCase, generate_case2_cases
from .kernel import (SOURCE, EDITION, DomainError, CMAA74Geometry, CMAA74PointState,
                     evaluate_case2_point, digest)
from ..autonomous_workflow.model import physical_train_at
from ..autonomous_workflow.moving import scan_moving_case
from ..autonomous_workflow.pipeline import AnalysisControls, source_receipt, _mesh_delta
from ..section_stress.recovery import (geometric_properties, resultants_from_frame,
                                       flange_shear_components, section_properties)


METRICS = ('cmaa74_sigma_transverse_upper_MPa', 'cmaa74_sigma_longitudinal_upper_MPa',
           'cmaa74_tau_upper_MPa', 'cmaa74_vm_upper_MPa', 'cmaa74_utilization_upper')


def _own_source_hash():
    return digest({p.name:p.read_text() for p in sorted(Path(__file__).parent.glob('*.py')) if not p.name.startswith('test_')})


def _nominal_point(section, resultant, wheel, point):
    """Physical CMAA P0/P1 bottom points; no point-ID transplant from EN/NBR."""
    p = geometric_properties(section)
    sign = -1 if wheel.y_mm < 0 else 1
    # CMAA Fig3.3.2.6-1/-3 puts P0 at web face, not outer root-radius tangent.
    y = sign*section.tw_mm/2 if point == 0 else wheel.y_mm
    z = -p['centroid_from_bottom_mm']
    omega = -y*(p['bottom_z_mid_mm']-p['z_sc_mm'])
    longitudinal = (resultant.N/p['A_mm2']+resultant.My*z/p['Iy_mm4']
                    -resultant.Mz*y/p['Iz_mm4']+resultant.B*omega/p['Cw_mm6'])
    shear = flange_shear_components(section, resultant, y, z)
    return dict(y_mm=y, z_mm=z, omega_mm2=omega, global_sigma_longitudinal_MPa=longitudinal,
                global_sigma_transverse_MPa=0., global_tau_MPa=shear['tau_xy_mpa'],
                global_tau_component_bound_MPa=shear['tau_xy_component_bound_mpa'])


class CMAA74LocalObserver:
    """Observe source local points under generated Case2 actions.

    Additional SK forces are an interval at each physical wheel, not a guessed
    equal split. Solve each independent transverse endpoint once, then recover
    the stress influence at the SAME wheel/point/cut. Triangle shear bounds and
    interval normal endpoints are conservative. Norm convexity makes the two
    longitudinal-normal endpoints sufficient for this one-dimensional interval.
    """
    def __init__(self, project, generated_case):
        if not isinstance(generated_case, CMAA74GeneratedCase):
            raise DomainError('Internally generated CMAA case required')
        self.project = project
        self.generated = generated_case
        self.case = generated_case.case
        self.section = project.section
        self.wheels = tuple(generated_case.wheels)
        self._wheels = {w.id:w for w in self.wheels}
        self._sk = {r['wheel_id']:r['force_abs_N'] for r in generated_case.skew_force_bounds}
        self._identity = digest(dict(project=project.to_dict(), generated=generated_case))
        self._checks = {}
        self._pending = {}
        self._counts = dict(observed_calls=0, ordinary_point_evaluations=0, excluded_station_evaluations=0, skew_influence_solves=0)
        self._offsets = sorted({w.offset_mm for w in self.wheels})
        if self.section.construction != 'rolled':
            raise DomainError('Autonomous first domain is ordinary rolled parallel flange; welded point2/weld/fatigue obligations are not implemented')
        if project.fy_mpa is None:
            raise DomainError('Material yield stress fy is required for CMAA nominal ASD')
        if any(v != 0 for s in project.supports for v in s['restrain'].values()):
            raise DomainError('Nonzero prescribed support movement requires separate zero-load subtraction for skew influence; not silently superposed')
        self._props = section_properties(self.section, project.E_mpa, project.nu)
        self._geometries = {w.id:CMAA74Geometry(self.section.bottom_width, self.section.tw_mm,
            self.section.bottom_thickness,self.section.bottom_width/2-abs(w.y_mm),
            'rolled',self.section.root_extent) for w in self.wheels}

    def _pending_add(self, code, message, example):
        if code not in self._pending:
            self._pending[code] = dict(code=code,reason=message,example=deepcopy(example),occurrences=0)
        self._pending[code]['occurrences'] += 1

    def _station_supported(self, load, by_id):
        wheel = self._wheels[load['id']]
        x = load['x']
        if min(x,self.project.length_mm-x) <= self.section.bottom_width:
            return 'physical_end_region', 'CMAA 3.3.2.6.5 does not complete transfer/end stresses; supplemental EN1993-6 5.8 interior screen distance>b excludes this region, not a CMAA distance formula.'
        if any(isclose(x,s['x'],rel_tol=0,abs_tol=1e-8) for s in self.project.supports):
            return 'support_load_transfer', 'Wheel coincides with a suspension load-transfer section; nominal CMAA formulas are not a complete transfer-region design.'
        spacing = min((abs(wheel.offset_mm-o) for o in self._offsets if o != wheel.offset_mm), default=None)
        if spacing is not None and spacing < 1.5*self.section.bottom_width:
            return 'longitudinal_interaction', 'Close-wheel interaction is not supplied by the inspected CMAA equations; supplemental EN1993-6 5.8 isolated spacing>=1.5b screen only. No silent local superposition.'
        pair = [w for w in self.wheels if w.offset_mm == wheel.offset_mm]
        if len(pair) != 2 or pair[0].y_mm != -pair[1].y_mm or any(w.id not in by_id for w in pair):
            return 'opposed_pair_domain', 'First implemented ordinary symmetric pair domain requires both physical opposed contacts; no pair averaging or wheel division.'
        loads = [by_id[w.id] for w in pair]
        if loads[0]['x'] != loads[1]['x'] or not isclose(loads[0]['Fz'], loads[1]['Fz'], rel_tol=1e-12, abs_tol=1e-8):
            return 'opposed_pair_actions', 'Unequal opposed vertical actions need separately qualified local plate mechanics.'
        return None, None

    def __call__(self, solution, translation, active_loads, spatial_stations):
        if digest(dict(project=self.project.to_dict(), generated=self.generated)) != self._identity:
            raise DomainError('Physical project/generated CMAA ledger changed during observation')
        if solution.model.length != self.project.length_mm or tuple(solution.model.supports) != tuple(self.project.supports):
            raise DomainError('CMAA observer solution does not match physical support/length model')
        for k,v in self._props['frame_section'].items():
            if not isclose(solution.model.section[k],v,rel_tol=1e-12):
                raise DomainError('CMAA observer stiffness mismatch')
        exact = getattr(solution,'translation_exact',None)
        expected = physical_train_at(self.wheels,self.case,translation,self.project.length_mm,exact_translation=exact)
        if tuple(active_loads) != expected or tuple(solution.points) != expected:
            raise DomainError('CMAA nominal loads and solved same-state actions differ')
        q=-(self.project.selfweight()+self.project.extra_dead_N_per_mm)
        mx=-self.project.extra_dead_N_per_mm*(self.project.extra_dead_y_mm or 0.)
        expected_udls=[dict(start=0.,end=self.project.length_mm,qx=0.,qy=0.,qz=q,mx=mx)] if q or mx else []
        if solution.udls != expected_udls:
            raise DomainError('CMAA solution selfweight/accessory actions differ from physical project')
        self._counts['observed_calls'] += 1
        metrics = dict.fromkeys(METRICS,0.)
        by_id={r['id']:r for r in active_loads}
        accepted=[]
        for load in active_loads:
            code,message=self._station_supported(load,by_id)
            if code:
                self._counts['excluded_station_evaluations'] += 1
                self._pending_add(code,message,dict(case_id=self.case.id,translation_mm=translation,wheel_id=load['id'],x_mm=load['x']))
            elif load['Fz'] > 1e-9:
                raise DomainError('Upward wheel contact invalidates the adopted no-hold-down model')
            else:
                accepted.append(load)
        if not accepted:
            return metrics
        influences=[]
        # Opposed contacts at the same x/z have identical beam influence for
        # pure transverse force. Minkowski-sum their independent intervals,
        # rather than falsely treating them as an actual equal hardware split.
        grouped_sk={}
        for load in active_loads:
            w=self._wheels[load['id']]
            key=(load['x'],w.z_mm)
            grouped_sk[key]=grouped_sk.get(key,0.)+self._sk[w.id]
        for (x,z),force in grouped_sk.items():
            if force:
                # Fy applied at actual contact: Mx=-z*Fy. No artificial yaw,
                # vertical redistribution, or duplicated mass-height moment.
                point=dict(id='SK_ENCLOSURE/'+str(x)+'/'+str(z),x=x,Fx=0.,Fy=force,Fz=0.,
                           Mx=-z*force,My=0.,Mz=0.,B=0.)
                influences.append(solution.model.solve([point],[]))
                self._counts['skew_influence_solves'] += 1
        cache={}
        def recover(sol,x,cut,w,point):
            key=(id(sol),x,cut,w.id,point)
            if key not in cache:
                r=resultants_from_frame(self.section,sol.at(x,cut),combination_id=self.case.id,
                                        wheel_translation_mm=translation,torsion_recovery='equilibrated')
                cache[key]=_nominal_point(self.section,r,w,point)
            return cache[key]
        for load in accepted:
            w=self._wheels[load['id']]
            for cut in ('left','right'):
                for point in (0,1):
                    base=recover(solution,load['x'],cut,w,point)
                    skrows=[recover(s,load['x'],cut,w,point) for s in influences]
                    normal_radius=sum(abs(r['global_sigma_longitudinal_MPa']) for r in skrows)
                    shear_radius=sum(r['global_tau_component_bound_MPa'] for r in skrows)
                    tau_bound=base['global_tau_component_bound_MPa']+shear_radius
                    for corner in (-1,1):
                        state=CMAA74PointState(self.case.id,self.generated.ledger.signature,w.id,translation,
                            load['x'],cut,'left' if w.y_mm<0 else 'right',point,max(0.,-load['Fz']),
                            0.,base['global_sigma_longitudinal_MPa']+corner*normal_radius,
                            base['global_tau_MPa'],tau_bound,'upper_bound')
                        result=evaluate_case2_point(self._geometries[w.id],self.generated.ledger,state,fy_MPa=self.project.fy_mpa)
                        self._counts['ordinary_point_evaluations'] += 1
                        for c in result['checks']:
                            key='/'.join((state.outstand_side,'P'+str(point),cut,c['id']))
                            record=dict(c,case_id=self.case.id,identity=asdict(state),
                                sigma_transverse_MPa=result['sigma_transverse_MPa'],sigma_longitudinal_MPa=result['sigma_longitudinal_MPa'],
                                nominal_point_coordinates=dict(y_mm=base['y_mm'],z_mm=base['z_mm']),
                                skew_interval=dict(longitudinal_radius_MPa=normal_radius,shear_component_radius_MPa=shear_radius,normal_corner=corner),
                                actual_base_without_SK=deepcopy(base),evidence='conservative_case2_enclosure',
                                source=result['source'],edition=EDITION,qualified=False)
                            if key not in self._checks or c['utilization'] > self._checks[key]['utilization']:
                                self._checks[key]=record
                        values=(abs(result['sigma_transverse_MPa']),abs(result['sigma_longitudinal_MPa']),tau_bound,
                                result['von_mises_bound_MPa'],max(c['utilization'] for c in result['checks']))
                        for key,value in zip(METRICS,values):
                            metrics[key]=max(metrics[key],value)
        return metrics

    def result(self):
        checks=list(self._checks.values())
        return deepcopy(dict(status='INCONCLUSIVE' if not checks or any(c['status']=='INCONCLUSIVE' for c in checks) else 'PASS',
            checks=checks,counts=self._counts,excluded_regions=list(self._pending.values()),
            ordinary_nominal_points_observed=bool(checks),all_operating_positions_supported=bool(checks) and not self._pending,
            action_evidence='conservative_case2_enclosure',actual_failure_witnesses=[],
            nominal_scope='CMAA74:2020 P0/P1 bottom surface at each physical wheel station, both outstands and longitudinal cuts; not the NBR/EN free-edge point.',
            actual_3d_tensor_complete=False,mathematically_certified_envelope=False,whole_design_complete=False))


def evaluate_autonomous_cmaa74(project, *, physical, controls=None, progress=None):
    """Compute moving/FE-refined ordinary nominal ASD only, with clear gaps."""
    controls=AnalysisControls() if controls is None else AnalysisControls(**controls) if isinstance(controls,dict) else controls
    if not isinstance(controls,AnalysisControls):
        raise DomainError('AnalysisControls required')
    quality_gate=(controls.moving_tolerance<=.01 and controls.mesh_tolerance<=.01
                  and controls.moving_stable_passes>=2 and controls.mesh_stable_passes>=2)
    original_signature=digest(project.to_dict())
    source_start=source_receipt()
    own_start=_own_source_hash()
    generated=generate_case2_cases(project,physical)
    rows=[]
    pending=[]
    if not quality_gate:
        pending.append('Diagnostic controls do not meet internal numerical qualification: moving/mesh tolerance<=0.01 and at least two stable passes each; this is an engineering quality gate, not a printed CMAA requirement.')
    models={}
    for index,g in enumerate(generated):
        if not g.contact_domain_valid:
            pending.append(g.case.id+': full eight-contact no-hold-down domain fails; no clipping or implicit tensile restraint.')
            rows.append(dict(case=asdict(g.case),ledger=asdict(g.ledger),local=None,sweep=None,mesh_history=[],numerical_converged=False,error='Upward contact in physical generated case'))
            continue
        # Do not overwrite original bound bridge ledger with differently factored
        # wheel values. The immutable source ledger is retained in this result.
        working=replace(project,wheels=list(g.wheels),bridge_reaction_ledger=None)
        previous=None
        stable=0
        mesh_history=[]
        last=None
        local=None
        error=None
        for refinement in range(controls.max_mesh_refinements+1):
            try:
                if refinement not in models:
                    models[refinement]=working.frame_model(project.max_element_length_mm/2**refinement)
                model=models[refinement]
                observer=CMAA74LocalObserver(working,g)
                def tick(case_id,level,n,total):
                    if progress:
                        progress(dict(stage='cmaa74_moving',case_index=index,case_count=len(generated),case_id=case_id,
                                      mesh_refinement=refinement,moving_refinement=level,sample_index=n,sample_count=total))
                last=scan_moving_case(model,g.wheels,g.case,selfweight=project.selfweight(),extra_dead=project.extra_dead_N_per_mm,
                    divisions=controls.divisions,max_refinements=controls.max_refinements,tolerance=controls.moving_tolerance,
                    consecutive_stable=controls.moving_stable_passes,observer=observer,progress=tick,
                    travel_min_mm=project.travel_min_mm,travel_max_mm=project.travel_max_mm,
                    extra_dead_y_mm=project.extra_dead_y_mm or 0.)
                local=observer.result()
                delta=None if previous is None else _mesh_delta(last,previous)
                stable=stable+1 if previous is not None and previous['converged'] and last['converged'] and delta is not None and delta<=controls.mesh_tolerance else 0
                mesh_history.append(dict(refinement=refinement,max_element_length_mm=project.max_element_length_mm/2**refinement,
                    moving_converged=last['converged'],mesh_relative_change=delta,stable_passes=stable,
                    solver_source_hash=last['solver_source_hash'],scan_input_signature=last['input_signature'],
                    source_fingerprint_at_start=source_start['fingerprint']))
                previous=last
                if stable>=controls.mesh_stable_passes:
                    break
            except (ValueError,TypeError,ArithmeticError) as exc:
                error=type(exc).__name__+': '+str(exc)
                break
        converged=error is None and last is not None and last['converged'] and stable>=controls.mesh_stable_passes
        if local is not None:
            for c in local['checks']:
                c['qualified']=converged and quality_gate
                if not (converged and quality_gate) and c['status']=='PASS':
                    c['status']='INCONCLUSIVE'
            local['ordinary_nominal_points_qualified']=converged and quality_gate and local['ordinary_nominal_points_observed']
            local['status']='PASS' if converged and quality_gate and local['checks'] and all(c['status']=='PASS' for c in local['checks']) else 'INCONCLUSIVE'
        if error:
            pending.append(g.case.id+': '+error)
        elif not converged:
            pending.append(g.case.id+': moving and mesh convergence are not established within the declared numerical budget.')
        rows.append(dict(case=asdict(g.case),ledger=asdict(g.ledger),local=local,sweep=last,mesh_history=mesh_history,
                         numerical_converged=converged,error=error,skew_force_bounds=list(g.skew_force_bounds),
                         full_contact_forces=list(g.full_contact_forces),physical_components=list(g.physical_components)))
        if progress:
            progress(dict(stage='cmaa74_case_complete',case_index=index,case_count=len(generated),case_id=g.case.id,numerical_converged=converged))
    unchanged=(digest(project.to_dict())==original_signature and _own_source_hash()==own_start
               and source_start['fingerprint']==source_receipt()['fingerprint'])
    if not unchanged:
        pending.append('Physical inputs or numerical/source files changed during calculation; regenerate before relying on results.')
        for r in rows:
            if r['local']:
                r['local']['ordinary_nominal_points_qualified']=False
                for c in r['local']['checks']:
                    c['qualified']=False
                    if c['status']=='PASS':c['status']='INCONCLUSIVE'
                r['local']['status']='INCONCLUSIVE'
    qualified=bool(rows) and unchanged and all((r['local'] or {}).get('ordinary_nominal_points_qualified') for r in rows)
    sufficient=qualified and all(r['local']['status']=='PASS' for r in rows)
    all_positions=qualified and all(r['local']['all_operating_positions_supported'] for r in rows)
    return dict(format='LRO_CMAA74_2020_NOMINAL_ASD',edition=EDITION,
        status='SUFFICIENT_ORDINARY_NOMINAL_ASD' if sufficient else 'CMAA_NOMINAL_ASD_INCONCLUSIVE',
        cases=rows,physical_inputs=asdict(physical),source_scope=generated[0].source_scope,
        controls=asdict(controls),numerical_quality_gate=dict(satisfied=quality_gate,maximum_relative_tolerance=.01,
            minimum_stable_passes=2,basis='Internal engineering-numerical qualification criterion, not a literal CMAA clause'),
        ordinary_nominal_points_qualified=qualified,ordinary_nominal_ASD_sufficient=sufficient,
        all_operating_positions_qualified=all_positions,local_bottom_flange_complete=False,
        selected_configuration_only=True,paired_runway_complete=False,
        operating_configuration_envelope_complete=False,
        pending=pending,known_failures=[],source=source_start,cmaa_source_hash=own_start,
        source_unchanged_during_calculation=unchanged,external_efforts_required=False,
        source_basis_separate_from_NBR8800_ULS=True,whole_design_complete=False,
        separate_obligations=['global member strength/buckling','wheel contact','fatigue','suspension connections',
                              'end/load-transfer disturbances','endstop/test/emergency actions','actual drive/equalizer realization'])
