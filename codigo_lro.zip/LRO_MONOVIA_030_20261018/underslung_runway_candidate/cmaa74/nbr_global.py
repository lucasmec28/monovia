"""CMAA characteristic origins -> NBR8800 ULS -> adopted EN2025 C.2.

Only verified mechanical influence bases are reused. Neither the original NBR
family coefficients nor a combined CMAA Case2 stress/tensor are factored. CMAA
DLF_B/DLF_T/HLF/IFD are applied once to their physical origins, then NBR8800
normal partial factors are applied with psi=1. Independent SK contact forces
are a conservative outer set, not a physical event or failure witness.

The resistance route is explicitly supplementary EN2025 C.2, NOT native NBR
resistance. Its actual geometry, source, numerical and load-radius gates remain
mandatory. No global result completes local transfer, connections or fatigue.
"""
from dataclasses import asdict
from pathlib import Path
import hashlib
import math

from .actions import CMAA74PhysicalInputs, generate_case2_actions
from .family_adapter import _same_mechanical_project
from .kernel import SOURCE, EDITION, DomainError
from ..autonomous_workflow.model import signature
from ..autonomous_workflow.family_envelope import (FIELDS, GEOMETRY_FIELDS, VERIFIED,
    interval_product, interval_sum, _response_interval, _source)
from ..stability.family_adapter import validate_family_receipt
from ..stability.c2_adapter import Qualification, evaluate_component_box, SOURCE as RESISTANCE_SOURCE
from ..section_stress.whole_section_bounds import whole_section_shear_bound

FAMILY = 'CMAA_CHARACTERISTIC_NBR8800_ULS_EN2025_C2'


def _require(ok, message):
    if not ok:
        raise DomainError(message)


def _iv(lo, hi=None):
    hi = lo if hi is None else hi
    _require(all(type(x) in (int, float) and math.isfinite(x) for x in (lo, hi)) and lo <= hi,
             'Finite ordered component interval required')
    return dict(lower=float(lo), upper=float(hi))


def _scale(values, factor):
    return interval_product(values, _iv(factor))


def skew_load_radius_guard(contact_rows, *, distributed_parcels=()):
    """Exact-sign enclosure of Fy*y+Fz*z, BEFORE paired SK projection.

    Pure Fy at opposed contacts with equal x/z has identical linear response,
    but NOT identical radial work: each independent sign is multiplied by its
    own actual y. Projection to a paired Fy basis is therefore performed only
    after this guard. A negative lower bound is an unqualified reference domain,
    not proof that actual crane loading destabilizes the member.
    """
    _require(bool(contact_rows), 'Physical contact rows required for radial-work guard')
    grouped = {}
    for row in contact_rows:
        x, y, z = (row[k] for k in ('offset_mm', 'y_mm', 'z_mm'))
        _, fy, fz = row['force_N']
        sk = row['SK_ULS_abs_upper_N']
        _require(math.isfinite(sk) and sk >= 0, 'Nonnegative finite SK bound required')
        # Multiplication and summation retain outward interval rounding. No
        # favorable cancellation is inferred between independent SK signs.
        work = interval_sum((_scale(_iv(fy), y), _scale(_iv(fz), z),
                             _scale(_iv(-sk, sk), y)))
        grouped.setdefault(x, []).append(work)
    rows = [dict(offset_mm=x, radial_work_coefficient_Nmm=interval_sum(parts))
            for x, parts in sorted(grouped.items())]
    distributed = []
    for parcel in distributed_parcels:
        work = interval_sum((_scale(_iv(parcel['qy']), parcel['y']),
                             _scale(_iv(parcel['qz']), parcel['z'])))
        distributed.append(dict(origin=parcel['origin'], radial_work_coefficient_N=work))
    safe = all(r['radial_work_coefficient_Nmm']['lower'] >= 0 for r in rows)
    safe = safe and all(r['radial_work_coefficient_N']['lower'] >= 0 for r in distributed)
    return dict(no_destabilizing_transverse_load_radius=safe, wheel_station_coefficients=rows,
        distributed_coefficients=distributed, SK_independent_physical_y_retained=True,
        source='Rigid-section fixed-direction force second variation: +(Fy*y+Fz*z)*phi^2; independent SK interval enclosure.',
        factors_applied_once=True, ordinary_torque_actions_not_removed=True,
        beneficial_radius_credit_used=False, actual_failure_proven=False,
        follower_or_unqualified_attachment_loads_covered=False)


def _factored_contacts(generated, factors):
    """Partial factors on UNCOLLAPSED characteristic origins, all eight contacts."""
    rows = []
    sx, sy = generated.case.longitudinal_sign, generated.case.transverse_sign
    dlf_b, dlf_t, hlf = generated.ledger.DLF_B, generated.ledger.DLF_T, generated.ledger.HLF
    for c in generated.full_contact_forces:
        dl = factors.dead_equipment * dlf_b * c['DL_N']
        tl = factors.dead_equipment * dlf_t * c['TL_N']
        payload = factors.lifted * (1 + hlf) * c['payload_N']
        retained = factors.lifted * (1 + hlf) * c['retained_LL_N']
        hx = [factors.longitudinal * sx * x for x in c['IFD_bridge_vector_N']]
        hy = [factors.transverse * sy * x for x in c['IFD_trolley_vector_N']]
        parcels = dict(DL=[0., 0., -dl], TL=[0., 0., -tl],
            payload=[0., 0., -payload], retained_suspended=[0., 0., -retained],
            IFD_bridge=hx, IFD_trolley=hy)
        force = [math.fsum(v[i] for v in parcels.values()) for i in range(3)]
        # Source SK ordinate is CHARACTERISTIC. Gamma_Q is then applied once,
        # not recalculated from an already factored total vertical reaction.
        sk = factors.transverse * c['SK_transverse_abs_upper_N']
        _require(all(math.isfinite(v) for v in force) and math.isfinite(sk) and sk >= 0,
                 'Nonfinite source-origin ULS force')
        rows.append(dict(contact_id=c['contact_id'], position_mm=c['position_mm'], force_N=force,
            factored_origins_N=parcels, SK_characteristic_abs_upper_N=c['SK_transverse_abs_upper_N'],
            SK_ULS_abs_upper_N=sk))
    _require(len(rows) == 8 and len({r['contact_id'] for r in rows}) == 8,
             'Complete eight-contact physical bridge audit required')
    scale = max(1., *(abs(x) for row in rows for parcel in row['factored_origins_N'].values() for x in parcel))
    allowance = 2e-11 * scale  # Same explicit engineering roundoff scope as physical statics.
    uplift = [r['contact_id'] for r in rows if r['force_N'][2] > allowance]
    audit = dict(contact_count=8, no_hold_down_contact_valid=not uplift, uplift_contacts=uplift,
        vertical_roundoff_allowance_N=allowance,
        upward_Fz_N_by_contact={r['contact_id']: r['force_N'][2] for r in rows},
        SK_has_no_invented_vertical_redistribution=True, actual_failure_proven=False,
        physical_drive_or_equalizer_qualified=False)
    return rows, audit


def generate_cmaa_nbr_global_coefficients(project, plan, physical, *,
        cmaa_action_project=None, cmaa_conversion_receipt=None):
    """Regenerate every physical corner/state/permanent-origin ULS variant.

    This pure force/interval stage does NOT qualify numerical response. All
    original receipt validation is mandatory in evaluate_cmaa_nbr_global.
    """
    from lro_beams.autonomous_actions import variants_8800
    _require(isinstance(physical, CMAA74PhysicalInputs), 'CMAA physical action inputs required')
    physical.validate()
    action_project = project if cmaa_action_project is None else cmaa_action_project
    if cmaa_action_project is not None:
        from ..autonomous_ui.cmaa_inputs import validate_cmaa74_action_conversion
        validate_cmaa74_action_conversion(project, physical, action_project, cmaa_conversion_receipt)
    else:
        _require(cmaa_conversion_receipt is None, 'Conversion receipt requires its exact private action project')
    ledger = _same_mechanical_project(project, action_project)
    variants = variants_8800(psi=1., extra_dead_kn_per_m=project.extra_dead_N_per_mm,
                             extra_dead_kind=project.extra_dead_kind)
    bases = {b.id: b for b in plan['bases']}
    configs = plan['configurations']
    _require(len(configs) == 8 and len({c['id'] for c in configs}) == 8,
             'All eight verified physical configurations required')
    template = next(iter(plan['wheels_by_configuration'].values()))
    template_geometry = tuple(tuple(getattr(w, k) for k in GEOMETRY_FIELDS) for w in template)
    members, missing = [], set()
    for config in configs:
        generated_cases = generate_case2_actions(project.section, ledger['inputs'], config['id'], physical)
        _require(len(generated_cases) == 8, 'Both load states and both signs of each IFD required')
        for generated in generated_cases:
            wheels = tuple(sorted(generated.wheels, key=lambda w: (w.offset_mm, w.y_mm)))
            _require(tuple(tuple(getattr(w, k) for k in GEOMETRY_FIELDS) for w in wheels) == template_geometry,
                     'CMAA contact geometry differs from the verified physical bases')
            for factors in variants:
                full, audit = _factored_contacts(generated, factors)
                selected = []
                for w in wheels:
                    matches = [c for c in full if w.id.endswith('/' + c['contact_id'])]
                    _require(len(matches) == 1, 'Unique full-contact to runway-wheel mapping required')
                    selected.append(dict(matches[0], wheel_id=w.id,
                        **{k: getattr(w, k) for k in GEOMETRY_FIELDS}))
                raw = {}
                for station in (0, 1):
                    a, b = selected[2*station:2*station+2]
                    _require(a['force_N'] == b['force_N'],
                             'Unequal opposed origin-factored vectors cannot be averaged into paired bases')
                    fx, fy, fz = a['force_N']
                    half_sk = (a['SK_ULS_abs_upper_N'] + b['SK_ULS_abs_upper_N']) / 2
                    raw[f'station{station}/Fx'] = _iv(fx)
                    raw[f'station{station}/Fy'] = interval_sum((_iv(fy), _iv(-half_sk, half_sk)))
                    raw[f'station{station}/downward_Fz'] = _iv(-fz)
                raw['selfweight'] = _iv(factors.dead_support)
                distributed = [dict(origin='runway_selfweight', qy=0.,
                    qz=-project.selfweight()*factors.dead_support, y=0., z=0.)]
                if project.extra_dead_N_per_mm:
                    raw['accessory_dead'] = _iv(factors.extra_dead)
                    distributed.append(dict(origin='extra_permanent', qy=0.,
                        qz=-project.extra_dead_N_per_mm*factors.extra_dead,
                        y=project.extra_dead_y_mm, z=project.extra_dead_z_mm))
                _require(set(raw) == set(bases), 'Required physical force-basis definitions differ')
                coefficients = {}
                for name, values in raw.items():
                    amp = bases[name].amplitude
                    if amp == 0:
                        if values['lower'] != 0 or values['upper'] != 0:
                            missing.add(name)
                        coefficients[name] = _iv(0.)
                    else:
                        coefficients[name] = _scale(values, 1/amp)
                members.append(dict(configuration_id=config['id'],
                    case_id=generated.case.id.replace('CMAA74_CASE2/', 'CMAA_NBR_ULS/', 1)+'/'+factors.code,
                    loaded=generated.case.loaded, IFD_bridge_sign=generated.case.longitudinal_sign,
                    IFD_trolley_sign=generated.case.transverse_sign,
                    partial_factors=asdict(factors), characteristic_ledger=asdict(generated.ledger),
                    full_contact_forces=full, physical_contact_receipt=audit,
                    selected_contact_forces=selected, raw_coefficient_intervals=raw,
                    coefficient_intervals=coefficients,
                    load_radius_receipt=skew_load_radius_guard(selected, distributed_parcels=distributed)))
    _require(not missing, 'CMAA IFD/SK requires previously zero/unverified mechanical bases: '+
             ', '.join(sorted(missing))+'. Recompute these bases; no false zero.')
    _require(len(members) == 64*len(variants), 'Incomplete ULS physical membership')
    coefficients = {name: _iv(min(m['coefficient_intervals'][name]['lower'] for m in members),
                              max(m['coefficient_intervals'][name]['upper'] for m in members)) for name in bases}
    return dict(family=FAMILY, members=members, coefficient_intervals=coefficients,
        total_configuration_count=8, characteristic_state_count=64,
        partial_factor_variant_count=len(variants), total_case_count=len(members),
        all_members_contact_valid=all(m['physical_contact_receipt']['no_hold_down_contact_valid'] for m in members),
        all_members_non_destabilizing_radius=all(m['load_radius_receipt']['no_destabilizing_transverse_load_radius'] for m in members),
        all_eight_contacts_audited=True,
        source_scope=dict(characteristic_origin_producer=generated.source_scope,
            final_actions='Complementary NBR8800 ULS, not CMAA nominal ASD',
            resistance='Separately adopted EN2025 C.2 and nominal section checks, not native NBR resistance'),
        dynamic_action_source=SOURCE+' 3.3.2.1-.2, 3.3.2.5.2; characteristic parcels, not ASD resistance',
        partial_factor_sources=sorted({a.source for a in variants}),
        action_adoption='CMAA characteristic dynamic origins with complementary NBR8800 normal ULS partial factors, applied per origin; not blanket CMAA74 compliance.',
        origin_equation='gamma_Ge*(DLF_B*DL+DLF_T*TL)+gamma_Q*(1+HLF)*(payload+B)+gamma_HX*IFD_X+gamma_HY*(IFD_Y+SK); runway Gs and extra Gx separately',
        NBR_psi=1., NBR_impact_reapplied=False, EN5_actions_used=False,
        combined_Case2_tensor_factored=False, original_normative_coefficients_reused=False,
        SK_characteristic_then_partial_factor_once=True, SK_independent_physical_contact_outer_set=True,
        coefficient_intervals_are_relaxation=True, concurrent_tensor_claimed=False,
        actual_failure_proven=False, governing_physical_state_invented=False,
        max_absolute_normalized_coefficient=max(abs(v) for row in coefficients.values() for v in row.values()),
        coefficient_magnification_allowed_with_scaled_verification_allowances=True,
        operating_configuration_envelope_complete=True,
        interior_configuration_enclosure='Bilinear gravity/IFD corner convexity and triangle inequality for characteristic SK. Radius lower bounds are concave under this outer set; nonnegative corner guards suffice for interiors.',
        original_project_signature=signature(project.to_dict()), action_project_signature=signature(action_project.to_dict()))


def compose_cmaa_nbr_segment_boxes(plan, evidence, coefficients, segments):
    """Use each actual segment's verified extrema and SCALE its full allowance."""
    rows = []
    for i, segment in enumerate(segments):
        bounds = {}
        for field in FIELDS:
            terms = []
            for basis in plan['bases']:
                coef = coefficients[basis.id]
                if coef['lower'] == coef['upper'] == 0:
                    continue
                _require(basis.amplitude != 0 and basis.id in evidence,
                         'Required CMAA/NBR mechanical basis is unverified: '+basis.id)
                verification = evidence[basis.id]['verification']
                own = verification['segment_extrema'][i]
                _require(own['start_mm'] == segment['start_mm'] and own['end_mm'] == segment['end_mm'],
                         'Verified mechanical segment boundaries differ')
                response = _response_interval(own['extrema'], field, verification)
                terms.append(interval_product(coef, response))
            bounds[field] = interval_sum(terms)
        rows.append(dict(start_mm=segment['start_mm'], end_mm=segment['end_mm'], bounds=bounds))
    return rows


def consumer_source():
    """Hash both producer-validation and action/resistance consumer code."""
    import lro_beams.autonomous_actions as action_factors
    root = Path(__file__).parents[1]
    relative = ('cmaa74/nbr_global.py', 'cmaa74/actions.py', 'cmaa74/kernel.py',
        'cmaa74/family_adapter.py', 'cmaa74/autonomous_adapter.py', 'cmaa74/__init__.py', 'stability/family_adapter.py',
        'stability/c2_adapter.py', 'stability/reference.py', 'section_stress/whole_section_bounds.py',
        'autonomous_ui/cmaa_inputs.py', 'autonomous_ui/__init__.py')
    files = {name: hashlib.sha256((root/name).read_bytes()).hexdigest() for name in relative}
    files['lro_beams.autonomous_actions'] = hashlib.sha256(Path(action_factors.__file__).read_bytes()).hexdigest()
    return dict(files=files, fingerprint=signature(files))


def evaluate_cmaa_nbr_global(project, receipt, *, physical,
        cmaa_action_project=None, cmaa_conversion_receipt=None):
    """Verified mechanics + adopted origin-factored actions + separate EN C.2."""
    result = dict(kind='CMAA_characteristic_NBR8800_ULS_supplementary_EN2025_global',
        status='CMAA_NBR_GLOBAL_PENDING', pending=[], segments=[], edition=EDITION,
        sufficient_member_criteria_satisfied=False, sufficient_nominal_section_criteria_satisfied=False,
        global_member_qualified=False, global_nominal_section_qualified=False,
        whole_beam_qualified=False, whole_design_complete=False, actual_failure_proven=False,
        known_failures=[], concurrent_tensor_claimed=False, governing_physical_state_invented=False,
        continuum_upper_bound_claimed=False, numerical_engineering_result=True,
        native_NBR_resistance_claimed=False, resistance_source=RESISTANCE_SOURCE,
        separate_obligations=['local wheel/transfer disturbances', 'connections/support strength',
            'contact', 'fatigue', 'service', 'extraordinary actions', 'actual drive/equalizer hardware'])
    own = consumer_source()
    try:
        before = signature(project.to_dict())
        action_project = project if cmaa_action_project is None else cmaa_action_project
        action_before = signature(action_project.to_dict())
        model, plan = validate_family_receipt(project, receipt)
        _require(project.fy_mpa is not None and project.supplementary_en_resistance_gamma is not None
                 and project.supplementary_en_source.strip(),
                 'Explicit material and supplementary EN C.2 resistance adoption required')
        family = generate_cmaa_nbr_global_coefficients(project, plan, physical,
            cmaa_action_project=cmaa_action_project, cmaa_conversion_receipt=cmaa_conversion_receipt)
        result['coefficient_family'] = family
        _require(family['all_members_contact_valid'],
                 'Factored CMAA/NBR load state lifts off at a physical bridge contact; no-hold-down model is not qualified. Inspect eight-contact receipts; do not clip or skip states.')
        segments = compose_cmaa_nbr_segment_boxes(plan, receipt['basis_evidence'], family['coefficient_intervals'],
                                                  receipt['true_fork_boundary_audit']['segments'])
        q = Qualification(case_id=FAMILY,
            action_basis_source=family['action_adoption']+'; '+family['dynamic_action_source']+'; '+'; '.join(family['partial_factor_sources']),
            method_adoption_source=project.supplementary_en_source, bounds_are_upper=False,
            bounds_source='Verified mechanical basis receipt '+receipt['receipt_signature']+'; regenerated CMAA/NBR origin coefficient signature '+signature(family),
            torsion_mesh_qualified=True,
            no_destabilizing_transverse_load_radius=family['all_members_non_destabilizing_radius'],
            uniform_undistorted_thin_wall_i_adopted=True, structural_steel_ambient=True,
            producer_kind=VERIFIED, producer_receipt=receipt)
        for segment in segments:
            magnitude = lambda key: max(abs(segment['bounds'][key]['lower']), abs(segment['bounds'][key]['upper']))
            shear = whole_section_shear_bound(project.section, abs_Fy_N=magnitude('Fy'), abs_Fz_N=magnitude('Fz'),
                abs_Tsv_Nmm=magnitude('Tsv'), abs_Tw_Nmm=magnitude('Tw_equilibrated'))
            row = evaluate_component_box(model, project.section, segment, q, E_mpa=project.E_mpa, nu=project.nu,
                fy_mpa=project.fy_mpa, resistance_gamma=project.supplementary_en_resistance_gamma,
                shear_upper_mpa=shear['tau_bound_mpa'], shear_bound_source=shear['source'])
            _require(row.get('input_valid') is True and
                     {c['id'] for c in row.get('checks', [])} ==
                     {'C1_major_interaction', 'C2_minor_interaction', 'global_elastic_section'},
                     'Incomplete supplementary C.2 segment criteria at '+str(segment['start_mm'])+'..'+
                     str(segment['end_mm'])+': '+'; '.join(row.get('errors', [])+row.get('pending', [])))
            if 'response_producer' in row:
                row['response_producer']['receipt'] = dict(receipt_signature=receipt['receipt_signature'], evidence_kind=VERIFIED)
            row['nominal_shear_bound'] = shear
            row['component_box'] = segment
            result['segments'].append(row)
        checks = [c for row in result['segments'] for c in row['checks']]
        _require(bool(checks), 'No global member criteria produced')
        result['pending'] = [p for row in result['segments'] for p in row.get('pending', [])]
        member = [c for c in checks if c['id'] != 'global_elastic_section']
        nominal = [c for c in checks if c['id'] == 'global_elastic_section']
        result['global_member_qualified'] = bool(member) and all(c['qualified'] for c in member)
        result['global_nominal_section_qualified'] = bool(nominal) and all(c['qualified'] for c in nominal)
        result['sufficient_member_criteria_satisfied'] = result['global_member_qualified'] and all(c['status'] == 'ATENDE' for c in member)
        result['sufficient_nominal_section_criteria_satisfied'] = result['global_nominal_section_qualified'] and all(c['status'] == 'ATENDE' for c in nominal)
        if all(c['qualified'] for c in checks):
            result['status'] = ('SUFFICIENT_CMAA_NBR_GLOBAL_BOUND' if all(c['status'] == 'ATENDE' for c in checks)
                                else 'INCONCLUSIVE_CMAA_NBR_GLOBAL_BOUND')
        _require(before == signature(project.to_dict()) and action_before == signature(action_project.to_dict()),
                 'Physical project changed during global CMAA/NBR consumption')
        _require(receipt['source_at_end'] == _source(), 'Verified numerical source changed during global consumption')
        _require(own == consumer_source(), 'Global action/resistance/validator consumer source changed')
        result['source_receipt'] = dict(consumer_source=own, producer_receipt_signature=receipt['receipt_signature'],
            original_project_signature=before, action_project_signature=action_before,
            mass_conversion_receipt_signature=None if cmaa_conversion_receipt is None else cmaa_conversion_receipt['receipt_signature'],
            coefficient_family_signature=signature(family))
    except (ValueError, TypeError, KeyError, ArithmeticError, AttributeError) as exc:
        result.update(status='CMAA_NBR_GLOBAL_PENDING', segments=[], global_member_qualified=False,
            global_nominal_section_qualified=False, sufficient_member_criteria_satisfied=False,
            sufficient_nominal_section_criteria_satisfied=False)
        result['pending'].append(type(exc).__name__+': '+str(exc))
    return result
