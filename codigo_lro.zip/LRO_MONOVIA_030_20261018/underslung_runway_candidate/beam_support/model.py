"""Physical inputs for isolated beam-side suspension checks, N / mm / MPa.

No approvals, bolt capacities, inferred footprints, or default zero actions.
Axes: x beam longitudinal, y lateral, z upward. Positive My tensions top.
Attachment actions are forces ON the beam, referred to the supplied point.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from hashlib import sha256
import json
from math import cos, sin, isfinite, isclose

AXES = "x=beam longitudinal; y=lateral; z=up; My>0 tensions top; attachment=on beam"


def number(value, name, *, positive=False, nonnegative=False):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(name + " must be a finite real number")
    try:
        converted = float(value)
    except (OverflowError, ValueError) as exc:
        raise ValueError(name + " outside the finite floating-point domain") from exc
    if not isfinite(converted):
        raise ValueError(name + " must be a finite real number")
    if positive and value <= 0 or nonnegative and value < 0:
        raise ValueError(name + " outside the positive/nonnegative domain")
    return converted


def text(value, name, *, required=True):
    if not isinstance(value, str) or len(value) > 10000:
        raise ValueError(name + " must be XML-safe text of at most 10000 characters")
    # Same XML 1.0/UTF-8 domain as lro_beams.document_metadata.validate_xml_text,
    # kept dependency-free so the candidate does not import a research runtime.
    for char in value:
        code = ord(char)
        allowed = code in (9, 10, 13) or 0x20 <= code <= 0xD7FF or 0xE000 <= code <= 0xFFFD or 0x10000 <= code <= 0x10FFFF
        if not allowed:
            raise ValueError(name + " contains a prohibited Unicode/XML character")
    if required and not value.strip():
        raise ValueError(name + " requires its actual source/identity")
    return value


def fingerprint(value):
    return sha256(json.dumps(asdict(value), sort_keys=True, separators=(",", ":"),
                             allow_nan=False).encode()).hexdigest()


@dataclass(frozen=True)
class Steel:
    fy_mpa: float
    fu_mpa: float
    gamma_a1: float
    material_source: str
    factor_source: str

    def __post_init__(self):
        for name in ("fy_mpa", "fu_mpa", "gamma_a1"):
            number(getattr(self, name), name, positive=True)
        if self.fu_mpa < self.fy_mpa or self.gamma_a1 < 1:
            raise ValueError("Require fu >= fy and gamma_a1 >= 1")
        text(self.material_source, "material_source")
        text(self.factor_source, "factor_source")


@dataclass(frozen=True)
class Hole:
    id: str
    x_mm: float
    y_mm: float
    major_mm: float
    minor_mm: float
    angle_rad: float
    shape: str
    manufacturing: str
    geometry_source: str
    manufacturing_source: str

    def __post_init__(self):
        text(self.id, "hole identity")
        for name in ("x_mm", "y_mm", "angle_rad"):
            number(getattr(self, name), name)
        for name in ("major_mm", "minor_mm"):
            number(getattr(self, name), name, positive=True)
        if self.shape not in ("round", "obround") or self.major_mm < self.minor_mm:
            raise ValueError("Only physical round/obround holes with major >= minor are supported")
        if self.shape == "round" and self.major_mm != self.minor_mm:
            raise ValueError("Round-hole dimensions must agree")
        if self.manufacturing not in ("drilled", "punched", "thermal_cut", "unknown"):
            raise ValueError("Unknown hole manufacturing classification")
        text(self.geometry_source, "hole geometry source")
        text(self.manufacturing_source, "manufacturing source", required=self.manufacturing != "unknown")

    def extent(self, axis):
        """Actual projected maximum dimension of a circle/capsule, before allowance."""
        if axis not in ("x", "y"):
            raise ValueError("Hole projection requires physical x or y axis")
        direction = abs(cos(self.angle_rad)) if axis == "x" else abs(sin(self.angle_rad))
        return number(self.minor_mm + (self.major_mm-self.minor_mm)*direction, "projected hole dimension", positive=True)

    def deduction(self, axis):
        return self.extent(axis) + (0.0 if self.manufacturing == "drilled" else 2.0)


@dataclass(frozen=True)
class HolePattern:
    """A complete physical rectangular plate inventory, not just one chosen path.

    x runs from x_start to x_end; y from -width/2 to width/2. holes=None is
    UNKNOWN; holes=() requires a source documenting the absence of holes.
    Individual plate paths are not a whole I-section rupture/shear-lag model.
    """
    x_start_mm: float
    x_end_mm: float
    width_mm: float
    thickness_mm: float
    holes: tuple[Hole, ...] | None
    inventory_source: str

    def __post_init__(self):
        number(self.x_start_mm, "plate x start")
        number(self.x_end_mm, "plate x end")
        number(self.width_mm, "plate width", positive=True)
        number(self.thickness_mm, "plate thickness", positive=True)
        if self.x_end_mm <= self.x_start_mm:
            raise ValueError("Physical plate boundaries must be ordered")
        text(self.inventory_source, "hole inventory source", required=self.holes is not None)
        if self.holes is not None:
            if not isinstance(self.holes, tuple) or not all(isinstance(h, Hole) for h in self.holes):
                raise ValueError("holes must be an immutable tuple of physical Hole inputs or None")
            if len({h.id for h in self.holes}) != len(self.holes):
                raise ValueError("Hole identities must be unique")
            for h in self.holes:
                if not (self.x_start_mm <= h.x_mm-h.extent("x")/2 and
                        h.x_mm+h.extent("x")/2 <= self.x_end_mm and
                        abs(h.y_mm)+h.extent("y")/2 <= self.width_mm/2):
                    raise ValueError("Hole extends beyond actual plate boundaries")
            # This deliberately bounded input domain rejects overlapping projected
            # hole boxes, including any possible merged/crossed slots. Such cuts
            # require a union-geometry model, never duplicated deductions.
            for i, a in enumerate(self.holes):
                for b in self.holes[i+1:]:
                    if (abs(a.x_mm-b.x_mm) < (a.extent("x")+b.extent("x"))/2 and
                            abs(a.y_mm-b.y_mm) < (a.extent("y")+b.extent("y"))/2):
                        raise ValueError("Overlapping projected hole boxes require a separate union-geometry model")


@dataclass(frozen=True)
class SupportSection:
    d_mm: float
    top_width_mm: float
    top_thickness_mm: float
    bottom_width_mm: float
    bottom_thickness_mm: float
    web_thickness_mm: float
    W_top_mm3: float
    W_bottom_mm3: float
    construction: str
    top_root_radius_mm: float | None
    top_weld_leg_parallel_web_mm: float | None
    geometry_source: str
    properties_source: str
    top_root_source: str

    def __post_init__(self):
        for name in ("d_mm", "top_width_mm", "top_thickness_mm", "bottom_width_mm",
                     "bottom_thickness_mm", "web_thickness_mm", "W_top_mm3", "W_bottom_mm3"):
            number(getattr(self, name), name, positive=True)
        if (self.d_mm <= self.top_thickness_mm+self.bottom_thickness_mm or
                min(self.top_width_mm, self.bottom_width_mm) <= self.web_thickness_mm):
            raise ValueError("Invalid I/H-section physical dimensions")
        if self.construction not in ("rolled", "welded"):
            raise ValueError("I/H construction must be rolled or welded")
        for name in ("top_root_radius_mm", "top_weld_leg_parallel_web_mm"):
            value = getattr(self, name)
            if value is not None:
                number(value, name, nonnegative=True)
        if self.construction == "rolled" and self.top_weld_leg_parallel_web_mm not in (0, None):
            raise ValueError("Rolled section cannot include a web-flange weld leg")
        if self.construction == "welded" and self.top_root_radius_mm not in (0, None):
            raise ValueError("Welded section cannot include a rolled fillet radius")
        text(self.top_root_source, "actual top root source", required=self.top_root_extension_mm is not None)
        if self.top_root_extension_mm is not None:
            if self.top_root_extension_mm >= min((self.d_mm-self.top_thickness_mm-self.bottom_thickness_mm)/2,
                                               (self.top_width_mm-self.web_thickness_mm)/2):
                raise ValueError("Top root geometry consumes the clear web or flange outstand")
        text(self.geometry_source, "geometry source")
        text(self.properties_source, "section modulus source")

    @property
    def top_root_extension_mm(self):
        return self.top_root_radius_mm if self.construction == "rolled" else self.top_weld_leg_parallel_web_mm


def from_runtime_section(section, properties, *, geometry_source, top_root_source,
                         top_weld_leg_parallel_web_mm=None):
    """Copy physical runtime lro_beams.model.Section/geometry.Properties inputs.

    No research imports. Moduli map runtime major-axis x to physical beam My;
    actions are NOT converted here. Weld leg is not inferred from throat or UI.
    """
    return SupportSection(section.d_mm, section.bf_mm, section.tf_mm,
                          section.bottom_width, section.bottom_thickness, section.tw_mm,
                          properties.Wx_top_mm3, properties.Wx_bottom_mm3,
                          section.fabrication,
                          section.root_radius_mm if section.fabrication == "rolled" else None,
                          top_weld_leg_parallel_web_mm, geometry_source,
                          section.property_source, top_root_source)


@dataclass(frozen=True)
class DemandIdentity:
    support_id: str
    case_id: str
    moving_position_mm: float
    section_x_mm: float
    section_side: str
    combination_basis: str
    calculation_source: str
    axes: str = AXES

    def __post_init__(self):
        for name in ("support_id", "case_id", "combination_basis", "calculation_source"):
            text(getattr(self, name), name)
        number(self.moving_position_mm, "moving position")
        number(self.section_x_mm, "section x")
        if self.section_side not in ("left", "right") or self.axes != AXES:
            raise ValueError("Explicit cut side and this module's signed physical axes are required")


@dataclass(frozen=True)
class ConcurrentDemand:
    identity: DemandIdentity
    N_N: float
    My_Nmm: float
    Mz_Nmm: float
    Vy_N: float
    Vz_N: float
    T_Nmm: float
    B_Nmm2: float
    attachment_Fx_N: float
    attachment_Fy_N: float
    attachment_Fz_N: float
    attachment_Mx_Nmm: float
    attachment_My_Nmm: float
    attachment_Mz_Nmm: float
    attachment_B_Nmm2: float
    attachment_point_mm: tuple[float, float, float]

    def __post_init__(self):
        if not isinstance(self.identity, DemandIdentity):
            raise ValueError("A single calculated concurrent demand identity is mandatory")
        for name in self.__dataclass_fields__:
            if name not in ("identity", "attachment_point_mm"):
                number(getattr(self, name), name)
        if not isinstance(self.attachment_point_mm, tuple) or len(self.attachment_point_mm) != 3:
            raise ValueError("Explicit physical attachment x/y/z point required")
        for value in self.attachment_point_mm:
            number(value, "attachment coordinate")


@dataclass(frozen=True)
class SignedInterval:
    """Sufficient calculated scalar interval; never an actual failure witness.

    A bound cannot create missing traction, contact or combined-stress recovery.
    Its signed lower/upper range must cover every state named in coverage_source.
    """
    quantity: str
    lower: float
    upper: float
    support_id: str
    section_x_mm: float
    section_side: str
    combination_basis: str
    calculation_source: str
    coverage_source: str
    axes: str = AXES

    def __post_init__(self):
        if self.quantity not in ("My_Nmm", "attachment_Fz_N") or self.axes != AXES:
            raise ValueError("Only the explicit signed major moment or top normal-force interval is supported")
        number(self.lower, "interval lower"); number(self.upper, "interval upper")
        number(self.section_x_mm, "section x")
        if self.lower > self.upper or self.section_side not in ("left", "right"):
            raise ValueError("Invalid ordered interval or section side")
        for name in ("support_id", "combination_basis", "calculation_source", "coverage_source"):
            text(getattr(self, name), name)


@dataclass(frozen=True)
class BeamEnds:
    left_x_mm: float
    right_x_mm: float
    physical_end_source: str

    def __post_init__(self):
        number(self.left_x_mm, "physical left end")
        number(self.right_x_mm, "physical right end")
        if self.right_x_mm <= self.left_x_mm:
            raise ValueError("Physical beam ends must be ordered, not support pitch")
        text(self.physical_end_source, "physical end source")


@dataclass(frozen=True)
class NormalFootprint:
    x_start_mm: float
    x_end_mm: float
    y_start_mm: float
    y_end_mm: float
    application_z_mm: float
    field_model: str
    footprint_source: str
    traction_field_source: str

    def __post_init__(self):
        for name in ("x_start_mm", "x_end_mm", "y_start_mm", "y_end_mm", "application_z_mm"):
            number(getattr(self, name), name)
        if self.x_end_mm <= self.x_start_mm or self.y_end_mm <= self.y_start_mm:
            raise ValueError("Actual longitudinal and transverse loaded extents must be positive")
        if self.field_model not in ("continuous_uniform_normal_traction", "discrete_bearing_patches", "unresolved"):
            raise ValueError("Unknown physical traction-field model")
        text(self.footprint_source, "actual footprint source")
        text(self.traction_field_source, "traction-field calculation/source", required=self.field_model != "unresolved")

    @property
    def centroid(self):
        return (self.x_start_mm/2+self.x_end_mm/2, self.y_start_mm/2+self.y_end_mm/2,
                self.application_z_mm)

    @property
    def longitudinal_length_mm(self):
        return self.x_end_mm-self.x_start_mm

    @property
    def transverse_length_mm(self):
        return self.y_end_mm-self.y_start_mm


@dataclass(frozen=True)
class UniformPressureInterval:
    """Calculated bounds for a prescribed spatially uniform top-face traction.

    This is NOT a scalar reaction relabelled as local traction. The physical
    footprint/field and its pressure envelope must be established upstream.
    Integrating that declared field gives all attachment actions, including
    zero tangent force and zero moments about its centroid, for every state.
    """
    footprint: NormalFootprint
    lower_mpa: float
    upper_mpa: float
    support_id: str
    section_x_mm: float
    section_side: str
    combination_basis: str
    calculation_source: str
    coverage_source: str
    axes: str = AXES

    def __post_init__(self):
        if not isinstance(self.footprint, NormalFootprint) or self.footprint.field_model != "continuous_uniform_normal_traction":
            raise ValueError("A physically prescribed continuous uniform normal traction field is required")
        number(self.lower_mpa, "lower physical traction bound")
        number(self.upper_mpa, "upper physical traction bound")
        number(self.section_x_mm, "section x")
        if self.lower_mpa > self.upper_mpa or self.section_side not in ("left", "right") or self.axes != AXES:
            raise ValueError("Invalid pressure interval, section side or axes")
        for name in ("support_id", "combination_basis", "calculation_source", "coverage_source"):
            text(getattr(self, name), name)

    @property
    def force_bounds_N(self):
        area = self.footprint.longitudinal_length_mm*self.footprint.transverse_length_mm
        return (number(self.lower_mpa*area, "integrated lower force bound"),
                number(self.upper_mpa*area, "integrated upper force bound"))
