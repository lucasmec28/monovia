"""Strict physical-only JSON entry for the optional beam-support scalar adapter.

Units are N/mm/MPa. This is not an imported effort, pressure, approval or proof
format. Omission/null means unknown; an empty hole inventory is a documented
unperforated stated flange region, not a replacement for missing drawings.
"""
from __future__ import annotations

from copy import deepcopy
from dataclasses import asdict, dataclass
import json
from .model import BeamEnds, Hole, NormalFootprint, number, text

SCHEMA = "LRO_BEAM_SUPPORT_PHYSICAL_V1"


def _object(value, name, required, optional=()):
    if type(value) is not dict:
        raise ValueError(name + " must be a JSON object")
    if any(type(key) is not str for key in value):
        raise ValueError(name + " must have JSON string property names")
    missing = set(required)-set(value)
    extra = set(value)-set(required)-set(optional)
    if missing or extra:
        raise ValueError(name + ": missing " + str(sorted(missing)) + "; unknown " + str(sorted(extra)))
    return value


@dataclass(frozen=True)
class HoleInventory:
    x_start_mm: float
    x_end_mm: float
    holes: tuple[Hole, ...]
    inventory_source: str

    def __post_init__(self):
        number(self.x_start_mm, "Inventory region start")
        number(self.x_end_mm, "Inventory region end")
        if self.x_end_mm <= self.x_start_mm:
            raise ValueError("Hole-inventory region boundaries must be ordered")
        if not isinstance(self.holes, tuple) or not all(isinstance(h, Hole) for h in self.holes):
            raise ValueError("Known holes require an immutable complete Hole inventory")
        if len({h.id for h in self.holes}) != len(self.holes):
            raise ValueError("Hole IDs must be unique within each flange inventory")
        text(self.inventory_source, "Complete stated-region hole inventory source")


@dataclass(frozen=True)
class TopRootGeometry:
    kind: str
    extension_mm: float
    source: str

    def __post_init__(self):
        if self.kind not in ("rolled_radius", "web_parallel_weld_leg"):
            raise ValueError("Top root must identify an actual rolled radius or web-parallel weld leg")
        number(self.extension_mm, "Actual top root extension", nonnegative=True)
        text(self.source, "Actual top root source")


@dataclass(frozen=True)
class FootprintInput:
    id: str
    support_id: str
    x_start_mm: float
    x_end_mm: float
    y_start_mm: float
    y_end_mm: float
    application_z_mm: float
    contact_model: str
    footprint_source: str
    contact_source: str

    def __post_init__(self):
        text(self.id, "Footprint identity")
        text(self.support_id, "Footprint support identity")
        if self.contact_model not in ("discrete_bearing_patch", "unresolved"):
            raise ValueError("Only an actual discrete bearing patch or unresolved contact geometry is accepted; a uniform traction proof is not a physical input")
        self.to_kernel()

    def to_kernel(self):
        return NormalFootprint(self.x_start_mm, self.x_end_mm, self.y_start_mm,
            self.y_end_mm, self.application_z_mm,
            "discrete_bearing_patches" if self.contact_model == "discrete_bearing_patch" else "unresolved",
            self.footprint_source, self.contact_source)


@dataclass(frozen=True)
class BeamSupportPhysicalInputs:
    beam_ends: BeamEnds
    geometry_source: str
    gamma_a1: float
    factor_source: str
    top_holes: HoleInventory | None = None
    bottom_holes: HoleInventory | None = None
    top_root: TopRootGeometry | None = None
    footprints: tuple[FootprintInput, ...] = ()

    def __post_init__(self):
        if not isinstance(self.beam_ends, BeamEnds):
            raise ValueError("Actual physical beam ends required")
        text(self.geometry_source, "Actual section geometry source")
        number(self.gamma_a1, "NBR gamma_a1", positive=True)
        if self.gamma_a1 < 1:
            raise ValueError("NBR gamma_a1 must be at least one")
        text(self.factor_source, "NBR gamma_a1 source")
        for name in ("top_holes", "bottom_holes"):
            value = getattr(self, name)
            if value is not None and not isinstance(value, HoleInventory):
                raise ValueError(name + " must be an actual inventory or unknown")
        if self.top_root is not None and not isinstance(self.top_root, TopRootGeometry):
            raise ValueError("Actual top root geometry required")
        if not isinstance(self.footprints, tuple) or not all(isinstance(f, FootprintInput) for f in self.footprints):
            raise ValueError("Footprints must be an immutable tuple of physical patches")
        if len({f.id for f in self.footprints}) != len(self.footprints):
            raise ValueError("Footprint identities must be unique")

    def to_dict(self):
        return dict(schema=SCHEMA, **json.loads(json.dumps(asdict(self), allow_nan=False)))


def physical_from_dict(value):
    """Parse strict JSON; unknown fields are rejected at every depth.

    Missing top_holes/bottom_holes are unknown. Supplied lists cover every hole
    in that stated rectangular region. Metal beyond a partial region remains
    unknown; it is never replaced by an empty inventory. Bolt-group envelopes,
    loads, imported stresses and proof booleans are not accepted. The adapter
    binds dimensions and ends to the original project.
    """
    d = _object(value, "Beam-support physical input",
        ("schema", "beam_ends", "geometry_source", "gamma_a1", "factor_source"),
        ("top_holes", "bottom_holes", "top_root", "footprints"))
    if d["schema"] != SCHEMA:
        raise ValueError("Unsupported beam-support physical schema")
    end_keys = tuple(BeamEnds.__dataclass_fields__)
    ends = BeamEnds(**_object(d["beam_ends"], "beam_ends", end_keys))
    def inventory(name):
        raw = d.get(name)
        if raw is None:
            return None
        row = _object(raw, name, tuple(HoleInventory.__dataclass_fields__))
        if type(row["holes"]) is not list:
            raise ValueError(name + ".holes must be a complete JSON array; unknown inventory is null")
        holes = tuple(Hole(**_object(h, name+".hole", tuple(Hole.__dataclass_fields__))) for h in row["holes"])
        return HoleInventory(row["x_start_mm"], row["x_end_mm"], holes, row["inventory_source"])
    root = d.get("top_root")
    if root is not None:
        root = TopRootGeometry(**_object(root, "top_root", tuple(TopRootGeometry.__dataclass_fields__)))
    raw_patches = d.get("footprints", [])
    if type(raw_patches) is not list:
        raise ValueError("footprints must be an array of individual actual patches")
    footprints = tuple(FootprintInput(**_object(f, "footprint", tuple(FootprintInput.__dataclass_fields__))) for f in raw_patches)
    return BeamSupportPhysicalInputs(ends, d["geometry_source"], d["gamma_a1"], d["factor_source"],
        inventory("top_holes"), inventory("bottom_holes"), root, footprints)


def _obj(properties, required=None):
    return dict(type="object", additionalProperties=False, properties=properties,
                required=list(properties) if required is None else required)


_TEXT = dict(type="string", minLength=1, maxLength=10000, pattern=r"\S")
_OPTIONAL_TEXT = dict(type="string", maxLength=10000)
_NUMBER = dict(type="number")
_POSITIVE = dict(type="number", exclusiveMinimum=0)
_HOLE = _obj(dict(id=_TEXT, x_mm=_NUMBER, y_mm=_NUMBER, major_mm=_POSITIVE,
    minor_mm=_POSITIVE, angle_rad=_NUMBER, shape=dict(enum=["round", "obround"]),
    manufacturing=dict(enum=["drilled", "punched", "thermal_cut", "unknown"]),
    geometry_source=_TEXT, manufacturing_source=_OPTIONAL_TEXT))
_HOLE["allOf"] = [{"if": {"properties": {"manufacturing": {"not": {"const": "unknown"}}}},
    "then": {"properties": {"manufacturing_source": _TEXT}}}]
_INVENTORY = _obj(dict(x_start_mm=_NUMBER, x_end_mm=_NUMBER, holes=dict(type="array", items=_HOLE), inventory_source=_TEXT))
_ROOT = _obj(dict(kind=dict(enum=["rolled_radius", "web_parallel_weld_leg"]),
    extension_mm=dict(type="number", minimum=0), source=_TEXT))
_FOOTPRINT = _obj(dict(id=_TEXT, support_id=_TEXT, x_start_mm=_NUMBER, x_end_mm=_NUMBER,
    y_start_mm=_NUMBER, y_end_mm=_NUMBER, application_z_mm=_NUMBER,
    contact_model=dict(enum=["discrete_bearing_patch", "unresolved"]),
    footprint_source=_TEXT, contact_source=_OPTIONAL_TEXT))
_FOOTPRINT["allOf"] = [{"if": {"properties": {"contact_model": {"const": "discrete_bearing_patch"}}},
    "then": {"properties": {"contact_source": _TEXT}}}]
PHYSICAL_JSON_SCHEMA = dict(_obj(dict(schema=dict(const=SCHEMA),
    beam_ends=_obj(dict(left_x_mm=_NUMBER, right_x_mm=_NUMBER, physical_end_source=_TEXT)),
    geometry_source=_TEXT, gamma_a1=dict(type="number", minimum=1), factor_source=_TEXT,
    top_holes=dict(anyOf=[dict(type="null"), _INVENTORY]),
    bottom_holes=dict(anyOf=[dict(type="null"), _INVENTORY]),
    top_root=dict(anyOf=[dict(type="null"), _ROOT]),
    footprints=dict(type="array", items=_FOOTPRINT)),
    required=["schema", "beam_ends", "geometry_source", "gamma_a1", "factor_source"]),
    **{"$schema": "https://json-schema.org/draft/2020-12/schema", "title": "Physical beam-support geometry only",
       "$comment": "Use physical_from_dict and project binding for finite numbers, XML-safe sources, ordered boundaries, hole extents/overlap, round/slot consistency, complete stated-region inventories, matching ends, support identity and actual section dimensions. No efforts or qualification switches are accepted."})


def physical_schema():
    """Return a caller-owned JSON Schema document; runtime validation is stricter."""
    return deepcopy(PHYSICAL_JSON_SCHEMA)
