"""NBR 8800:2024 + supplied Er1 beam component kernels, never a whole-beam gate."""
from __future__ import annotations

from dataclasses import asdict
from functools import wraps
from math import isclose
from .model import (HolePattern, SupportSection, Steel, ConcurrentDemand, SignedInterval,
                    BeamEnds, NormalFootprint, UniformPressureInterval, fingerprint, number, text)

SOURCE_NET = "ABNT NBR 8800:2024+Er1:2025, 5.2.4, printed p40 / PDF62"
SOURCE_BENDING = "ABNT NBR 8800:2024+Er1:2025, 5.4.2.6, printed p56 / PDF78"
SOURCE_TRANSVERSE = "ABNT NBR 8800:2024+Er1:2025, 5.7.1-5.7.3, printed pp63-64 / PDF85-86"


def _finite_kernel(function):
    """Reject overflowing intermediate arithmetic and nonfinite report scalars."""
    @wraps(function)
    def checked(*args, **kwargs):
        try:
            result = function(*args, **kwargs)
        except (OverflowError, ZeroDivisionError) as exc:
            raise ValueError(function.__name__ + ": derived arithmetic outside the finite numerical domain") from exc
        def validate(value):
            if isinstance(value, (int, float)) and not isinstance(value, bool):
                number(value, function.__name__ + " derived report value")
            elif isinstance(value, dict):
                for item in value.values():
                    validate(item)
            elif isinstance(value, (tuple, list)):
                for item in value:
                    validate(item)
        validate(result)
        return result
    return checked


@_finite_kernel
def minimum_net_section(pattern: HolePattern, *, force_axis="beam_x"):
    """Global minimum over all strictly transverse-monotone hole chains, O(n²).

    Each chain may start/end at any hole. All straight, diagonal and zigzag
    choices are represented by a DAG ordered by transverse hole coordinate.
    Edge cost is s²/(4g), node cost is minus projected width/allowance. Equal
    transverse-coordinate holes cannot occur consecutively (g=0). The intact
    path is retained. No selected nominal bolt row is presumed governing.
    """
    if not isinstance(pattern, HolePattern):
        raise ValueError("Physical HolePattern required")
    if force_axis not in ("beam_x", "flange_y"):
        raise ValueError("Specify physical force axis beam_x or flange_y")
    width = pattern.width_mm if force_axis == "beam_x" else pattern.x_end_mm-pattern.x_start_mm
    gross_area = number(width*pattern.thickness_mm, "derived gross plate area", positive=True)
    result = dict(source=SOURCE_NET, force_axis=force_axis, gross_width_mm=width,
                  gross_area_mm2=gross_area, pattern_signature=fingerprint(pattern),
                  scope="single rectangular plate; no Ct, axial resistance or whole-section rupture inferred")
    if pattern.holes is None:
        return dict(result, status="BEAM_CHECK_NOT_QUALIFIED", net_width_mm=None, net_area_mm2=None,
                    governing_path=None, reason="Physical hole inventory is unknown, not unperforated")
    axis = "y" if force_axis == "beam_x" else "x"
    def coordinates(h):
        return (h.x_mm, h.y_mm) if force_axis == "beam_x" else (h.y_mm, h.x_mm)
    holes = sorted(pattern.holes, key=lambda h: (coordinates(h)[1], coordinates(h)[0], h.id))
    best, paths = [], []
    for i, h in enumerate(holes):
        u, v = coordinates(h)
        value, path = -h.deduction(axis), (h.id,)
        for j, previous in enumerate(holes[:i]):
            up, vp = coordinates(previous)
            if v <= vp:
                continue
            proposed = best[j] + (u-up)**2/(4*(v-vp)) - h.deduction(axis)
            if proposed < value:
                value, path = proposed, paths[j]+(h.id,)
        best.append(value); paths.append(path)
    candidates = [(0.0, ())] + list(zip(best, paths))
    minimum, path = min(candidates, key=lambda pair: (pair[0], pair[1]))
    net_width = width+minimum
    if net_width <= 0:
        return dict(result, status="BEAM_CHECK_NOT_QUALIFIED", net_width_mm=net_width,
                    net_area_mm2=None, governing_path=path,
                    reason="Deductions exhaust the plate width; connected net-section domain is invalid")
    return dict(result, status="CALCULATED", net_width_mm=net_width,
                net_area_mm2=net_width*pattern.thickness_mm, governing_path=path,
                deductions_mm={h.id: h.deduction(axis) for h in holes},
                manufacturing_allowance_mm={h.id: 0.0 if h.manufacturing == "drilled" else 2.0 for h in holes},
                algorithm="minimum-weight transverse-monotone chain; intact path included")


@_finite_kernel
def flange_hole_limit(section: SupportSection, steel: Steel, pattern: HolePattern, *, flange):
    """5.4.2.6 scalar major-axis tension-flange limit, without other flexural limits."""
    if not isinstance(section, SupportSection) or not isinstance(steel, Steel):
        raise ValueError("Explicit SupportSection and Steel required")
    if flange not in ("top", "bottom"):
        raise ValueError("Actual tension-side flange must be top or bottom")
    if not isinstance(pattern, HolePattern):
        raise ValueError("Unknown holes must be supplied as HolePattern(holes=None)")
    width, thickness = getattr(section, flange+"_width_mm"), getattr(section, flange+"_thickness_mm")
    if not isclose(pattern.width_mm, width, rel_tol=1e-12) or not isclose(pattern.thickness_mm, thickness, rel_tol=1e-12):
        raise ValueError("Flange hole geometry does not match the actual section")
    net = minimum_net_section(pattern)
    result = dict(source=SOURCE_BENDING, flange=flange, net_section=net,
                  gamma_a1=steel.gamma_a1, Wt_mm3=getattr(section, "W_"+flange+"_mm3"),
                  section_signature=fingerprint(section), material_signature=fingerprint(steel))
    if net["net_area_mm2"] is None:
        return dict(result, status="BEAM_CHECK_NOT_QUALIFIED", gross_properties_permitted=None,
                    hole_limit_Nmm=None)
    yt = 1.0 if steel.fy_mpa/steel.fu_mpa <= 0.8 else 1.10
    afn, afg = net["net_area_mm2"], net["gross_area_mm2"]
    rupture_threshold = number(steel.fu_mpa*afn, "fu*Afn", positive=True)
    yielding_threshold = number(yt*steel.fy_mpa*afg, "Yt*fy*Afg", positive=True)
    allowed = rupture_threshold >= yielding_threshold
    limit = None if allowed else number(steel.fu_mpa*afn/afg*result["Wt_mm3"]/steel.gamma_a1,
                                       "derived flange-hole resistance", positive=True)
    return dict(result, status="NO_ADDITIONAL_HOLE_LIMIT" if allowed else "HOLE_LIMIT_CALCULATED",
                gross_properties_permitted=allowed, Yt=yt, fu_Afn_N=steel.fu_mpa*afn,
                Yt_fy_Afg_N=yt*steel.fy_mpa*afg, hole_limit_Nmm=limit,
                formula="MRd=(fu*Afn/Afg)*Wt/gamma_a1; no Yt in fallback; all other flexural limits retained")


def _assessment(demand, capacity, *, is_bound):
    if capacity is None:
        return dict(status="BEAM_CHECK_NOT_QUALIFIED", demand=demand, resistance=None, utilization=None)
    if capacity <= 0:
        raise ValueError("Positive component resistance required")
    eta = demand/capacity
    status = "PASS_COMPONENT" if eta <= 1 else ("INCONCLUSIVE_BOUND" if is_bound else "FAIL_COMPONENT")
    return dict(status=status, demand=demand, resistance=capacity, utilization=eta,
                demand_kind="sufficient_interval_bound" if is_bound else "actual_concurrent_state")


@_finite_kernel
def check_flange_hole_bending(section, steel, top_pattern, bottom_pattern, demand,
                             *, other_flexural_limit_Nmm=None, other_flexural_limit_source=""):
    """Sign-aware major-bending component; retains other limits without inventing them.

    Actual N/Mz/B can change which fibers are in tension; this scalar check does
    not claim to recover that general field or its combined interaction.
    """
    text(other_flexural_limit_source, "source of other applicable flexural limit", required=other_flexural_limit_Nmm is not None)
    if other_flexural_limit_Nmm is not None:
        number(other_flexural_limit_Nmm, "other applicable flexural limit", positive=True)
    if isinstance(demand, ConcurrentDemand):
        lo = hi = demand.My_Nmm; is_bound = False
        identity = asdict(demand.identity)
        additional = any(getattr(demand, name) != 0 for name in
                         ("N_N", "Mz_Nmm", "Vy_N", "Vz_N", "T_Nmm", "B_Nmm2"))
        unresolved_tension_side = any(getattr(demand, name) != 0 for name in ("N_N", "Mz_Nmm", "B_Nmm2"))
    elif isinstance(demand, SignedInterval) and demand.quantity == "My_Nmm":
        lo, hi, is_bound = demand.lower, demand.upper, True
        identity = asdict(demand); additional = True
        unresolved_tension_side = False  # A scalar-bound result is explicitly only a major-bending component.
    else:
        raise ValueError("ConcurrentDemand or signed My_Nmm interval required")
    checks = []
    for flange, magnitude, pattern in (("top", max(hi, 0), top_pattern),
                                        ("bottom", max(-lo, 0), bottom_pattern)):
        if magnitude == 0:
            continue
        if not isinstance(pattern, HolePattern):
            raise ValueError("Unknown flange geometry requires HolePattern(holes=None), not omission")
        if not pattern.x_start_mm <= identity["section_x_mm"] <= pattern.x_end_mm:
            raise ValueError("Demand section lies outside the documented hole-pattern region")
        limit = flange_hole_limit(section, steel, pattern, flange=flange)
        hole_controls = False
        if limit["gross_properties_permitted"] is None:
            assessment = _assessment(magnitude, None, is_bound=is_bound)
        elif limit["hole_limit_Nmm"] is None and other_flexural_limit_Nmm is None:
            assessment = dict(status="NO_ADDITIONAL_HOLE_LIMIT", demand=magnitude,
                              resistance=None, utilization=None,
                              reason="Gross properties allowed; other flexural limit states still required")
        else:
            finite_limits = [v for v in (limit["hole_limit_Nmm"], other_flexural_limit_Nmm) if v is not None]
            resistance = min(finite_limits)
            # Minimum net area from a DIFFERENT x, or a staggered chain spanning
            # x, combined with a single local moment is only a conservative
            # scalar comparison. An exceeded comparison is not a physical fail
            # witness. A straight net path AT THIS calculated cut may witness it.
            at_cut = [h for h in pattern.holes if h.x_mm == identity["section_x_mm"]]
            cut_width = pattern.width_mm-sum(h.deduction("y") for h in at_cut)
            path_at_cut = bool(at_cut) and isclose(cut_width, limit["net_section"]["net_width_mm"], rel_tol=1e-12)
            hole_controls = limit["hole_limit_Nmm"] is not None and resistance == limit["hole_limit_Nmm"]
            spatial_bound = hole_controls and not path_at_cut
            assessment = _assessment(magnitude, resistance, is_bound=is_bound or spatial_bound)
            assessment["governing_hole_path_at_demand_cut"] = path_at_cut
            if spatial_bound:
                assessment["spatial_pairing_note"] = "Minimum net path and actual demand cut are not paired; exceedance is inconclusive, not a failure witness"
        if unresolved_tension_side and hole_controls and assessment["status"] in ("PASS_COMPONENT", "FAIL_COMPONENT"):
            assessment["conditional_formula_status"] = assessment["status"]
            assessment["status"] = "BEAM_CHECK_NOT_QUALIFIED"
            assessment["tension_side_note"] = "Coexistent N/Mz/B can change or cancel flange tension; isolated My is not an actual rupture witness without combined normal-stress recovery"
        # A smaller but spatially unpaired hole limit must not erase a larger,
        # independently applicable limit with an actual demand witness at this
        # section. Retain this check for ALL hole outcomes, not only unknown
        # holes. Its demand provenance is independent of the net-path pairing.
        if other_flexural_limit_Nmm is not None:
            assessment["known_other_flexural_check"] = dict(
                _assessment(magnitude, other_flexural_limit_Nmm, is_bound=is_bound),
                source=other_flexural_limit_source, section_x_mm=identity["section_x_mm"],
                scope="independently applicable other flexural limit at this demand section")
        checks.append(dict(assessment, major_bending_tension_flange=flange, hole_rule=limit))
    return dict(scope="major-axis bending component only", source=SOURCE_BENDING,
                other_flexural_limit_source=other_flexural_limit_source,
                demand_identity=identity, demand_signature=fingerprint(demand), checks=checks,
                concurrent_interaction="BEAM_CHECK_NOT_QUALIFIED" if additional else "NO_OTHER_INTERNAL_ACTION_IN_THIS_STATE",
                remaining_beam_checks=["Other flexural limits and instability", "Local introduction/secondary bending and fatigue",
                                       "Actual combined stress and tension-side recovery where N, Mz or B coexist"],
                whole_beam_status="BEAM_CHECK_NOT_QUALIFIED")


@_finite_kernel
def centered_transverse_capacities(section, steel, ends, footprint):
    """Exact 5.7.2/3 scalar formulas with independently visible applicability.

    End distances refer to the physical force resultant line (patch centroid),
    not support spacing. Both end distances and both footprint-edge clearances
    are reported. ln is strictly the actual longitudinal loaded extent.
    """
    if not all(isinstance(a, b) for a, b in ((section, SupportSection), (steel, Steel),
                                            (ends, BeamEnds), (footprint, NormalFootprint))):
        raise ValueError("Physical section, steel, beam ends and actual footprint required")
    x, y, z = footprint.centroid
    left, right = x-ends.left_x_mm, ends.right_x_mm-x
    if footprint.x_start_mm < ends.left_x_mm or footprint.x_end_mm > ends.right_x_mm:
        raise ValueError("Loaded footprint lies beyond a physical beam end")
    if footprint.y_start_mm < -section.top_width_mm/2 or footprint.y_end_mm > section.top_width_mm/2:
        raise ValueError("Loaded footprint lies outside the actual top flange")
    reasons = []
    if footprint.field_model != "continuous_uniform_normal_traction":
        reasons.append("Discrete/unresolved loads need a qualified local force-distribution and introduction model")
    if y != 0:
        reasons.append("Load field is not centered relative to the web")
    if z != section.d_mm:
        reasons.append("Force is not applied on the top flange's external face (z measured from bottom)")
    near = min(left, right)
    reduction = 0.5 if near < 10*section.top_thickness_mm else 1.0
    flange = reduction*6.25*section.top_thickness_mm**2*steel.fy_mpa/steel.gamma_a1
    number(flange, "derived flange local-bending resistance", positive=True)
    root = section.top_root_extension_mm
    k = None if root is None else section.top_thickness_mm+root
    multiplier = 5.0 if near > section.d_mm else 2.5
    web = None if k is None else 1.10*(multiplier*k+footprint.longitudinal_length_mm)*steel.fy_mpa*section.web_thickness_mm/steel.gamma_a1
    if web is not None:
        number(web, "derived web yielding resistance", positive=True)
    return dict(source=SOURCE_TRANSVERSE, input_signatures=dict(section=fingerprint(section), steel=fingerprint(steel),
                ends=fingerprint(ends), footprint=fingerprint(footprint)), applicability_reasons=reasons,
                scalar_field_domain="APPLICABLE" if not reasons else "BEAM_CHECK_NOT_QUALIFIED",
                left_end_distance_mm=left, right_end_distance_mm=right, nearest_end_distance_mm=near,
                left_footprint_clearance_mm=footprint.x_start_mm-ends.left_x_mm,
                right_footprint_clearance_mm=ends.right_x_mm-footprint.x_end_mm,
                ln_mm=footprint.longitudinal_length_mm, transverse_loaded_length_mm=footprint.transverse_length_mm,
                flange_bending=dict(resistance_N=flange, end_reduction=reduction,
                                    mode_exempt=footprint.transverse_length_mm < .15*section.top_width_mm,
                                    source="5.7.2; exemption ONLY for flange local bending"),
                web_yielding=dict(resistance_N=web, k_mm=k, k_multiplier=multiplier,
                                  source="5.7.3; actual longitudinal force length; gamma_a1"))


@_finite_kernel
def check_centered_transverse(section, steel, ends, footprint, demand, *, flange_pattern):
    """Check a centered continuous normal field, not a bolt-group resultant.

    For actual demand, every attachment force/moment and its point is checked.
    A scalar reaction interval lacks that evidence, so it only supplies
    conditional comparisons. UniformPressureInterval instead integrates an
    explicitly prescribed physical uniform field for all covered states.
    """
    capacities = centered_transverse_capacities(section, steel, ends, footprint)
    reasons = list(capacities["applicability_reasons"])
    if not isinstance(flange_pattern, HolePattern):
        raise ValueError("Actual top-flange hole inventory, including unknown, is required")
    # Validate flange dimensions even when there is no bending action.
    flange_hole_limit(section, steel, flange_pattern, flange="top")
    if not (flange_pattern.x_start_mm <= footprint.x_start_mm and footprint.x_end_mm <= flange_pattern.x_end_mm):
        raise ValueError("Footprint outside the documented physical hole region")
    if flange_pattern.holes is None:
        reasons.append("Unknown perforations cannot establish a continuous normal-traction field")
    else:
        for h in flange_pattern.holes:
            if (h.x_mm+h.extent("x")/2 > footprint.x_start_mm and
                    h.x_mm-h.extent("x")/2 < footprint.x_end_mm and
                    h.y_mm+h.extent("y")/2 > footprint.y_start_mm and
                    h.y_mm-h.extent("y")/2 < footprint.y_end_mm):
                reasons.append("Loaded footprint overlaps a hole: bridging/contact and local transfer are unresolved")
                break
    if isinstance(demand, ConcurrentDemand):
        lo = hi = demand.attachment_Fz_N; is_bound = False
        identity = asdict(demand.identity)
        if demand.attachment_point_mm != footprint.centroid:
            reasons.append("Actual wrench point differs from the physical uniform-patch resultant point")
        if any(getattr(demand, name) != 0 for name in ("attachment_Fx_N", "attachment_Fy_N",
                "attachment_Mx_Nmm", "attachment_My_Nmm", "attachment_Mz_Nmm", "attachment_B_Nmm2")):
            reasons.append("Non-normal force/moment/warping transfer is not represented by this centered normal field")
    elif isinstance(demand, SignedInterval) and demand.quantity == "attachment_Fz_N":
        lo, hi, is_bound = demand.lower, demand.upper, True
        identity = asdict(demand)
        reasons.append("A scalar interval alone does not establish concurrent attachment wrench and normal-field applicability")
    elif isinstance(demand, UniformPressureInterval):
        if demand.footprint != footprint:
            raise ValueError("Pressure envelope belongs to a different actual footprint")
        lo, hi = demand.force_bounds_N; is_bound = True
        identity = asdict(demand)
    else:
        raise ValueError("ConcurrentDemand, signed attachment_Fz_N interval or UniformPressureInterval required")
    if not ends.left_x_mm <= identity["section_x_mm"] <= ends.right_x_mm:
        raise ValueError("Concurrent section lies outside the physical beam")
    comparisons = {}
    if hi <= 0:
        comparisons["flange_bending"] = dict(status="NOT_APPLICABLE_COMPRESSION_OR_ZERO", utilization=None)
    elif capacities["flange_bending"]["mode_exempt"]:
        comparisons["flange_bending"] = dict(status="MODE_EXEMPT_ONLY", utilization=None)
    else:
        comparisons["flange_bending"] = _assessment(max(hi, 0), capacities["flange_bending"]["resistance_N"], is_bound=is_bound)
    comparisons["web_yielding"] = _assessment(max(abs(lo), abs(hi)), capacities["web_yielding"]["resistance_N"], is_bound=is_bound)
    for value in comparisons.values():
        if reasons and value["status"] in ("PASS_COMPONENT", "FAIL_COMPONENT", "MODE_EXEMPT_ONLY"):
            value["conditional_formula_status"] = value["status"]
            value["status"] = "BEAM_CHECK_NOT_QUALIFIED"
    if capacities["web_yielding"]["k_mm"] is None:
        reasons.append("Actual top root radius/web-parallel weld leg is missing for 5.7.3 only; independent flange check retained")
    gaps = ["Local outstand/punching/prying/contact/overlapping-patch transfer not solved",
            "Concurrent global/local interaction and nominal secondary-bending fatigue not solved",
            "Horizontal hole bearing, tear-out, net shear and block tearing need actual force paths",
            "5.7.8 support/free-web-end stiffening requires actual longitudinal rotation restraint"]
    if section.construction == "welded":
        gaps.append("Beam-side flange-web weld force transfer under 5.4.5 remains required")
    if lo < 0:
        gaps.append("Compression/contact reversal activates applicable 5.7.4-5.7.6 checks")
    detailing = []
    if any(v["status"] == "FAIL_COMPONENT" for v in comparisons.values()):
        detailing.append("5.7.2.4/5.7.3.3 require two-sided transverse stiffeners, detailed/verified under 5.7.9; no capacity credit inferred")
    return dict(source=SOURCE_TRANSVERSE, capacities=capacities, checks=comparisons,
                applicability_reasons=reasons, demand_identity=identity, demand_signature=fingerprint(demand),
                required_beam_detailing=detailing, remaining_beam_checks=gaps,
                whole_beam_status="BEAM_CHECK_NOT_QUALIFIED")


@_finite_kernel
def summarize_beam_components(*reports):
    """Preserve actual qualified component failures, never upgrade to whole-beam PASS."""
    statuses = []
    def walk(value):
        if isinstance(value, dict):
            # Conditional formula statuses are intentionally NOT failure evidence.
            if "status" in value:
                statuses.append(value["status"])
            for key, nested in value.items():
                if key != "conditional_formula_status":
                    walk(nested)
        elif isinstance(value, (tuple, list)):
            for nested in value:
                walk(nested)
    for report in reports:
        walk(report)
    return dict(status="FAIL_BEAM_COMPONENT" if "FAIL_COMPONENT" in statuses else "BEAM_CHECK_NOT_QUALIFIED",
                component_statuses=statuses, whole_beam_complete=False,
                external_design=dict(bolts="OUTSIDE_SCOPE", receiver="OUTSIDE_SCOPE", building="OUTSIDE_SCOPE"),
                reason="Prescriptive scalar subchecks do not close local load introduction, combined stress, fatigue or boundary-condition requirements")
