"""Autonomous, read-only scalar beam-support consumer of verified family proofs.

No FE production, imported efforts, user proof switches or attachment tractions.
The current CMAA-origin -> NBR8800 composition supplies signed My bounds only.
The legacy kernel interval identity uses an explicit region-boundary anchor,
never an invented governing cut, actual case, moving position or failure event.
"""
from __future__ import annotations

from copy import deepcopy
from dataclasses import asdict
from hashlib import sha256
from pathlib import Path

from .inputs import BeamSupportPhysicalInputs, physical_from_dict
from .model import AXES, BeamEnds, HolePattern, SignedInterval, Steel, SupportSection
from .kernels import (minimum_net_section, flange_hole_limit, check_flange_hole_bending,
                      centered_transverse_capacities, summarize_beam_components)
from ..autonomous_workflow.model import signature
from ..autonomous_workflow.family_envelope import _source
from ..section_stress.recovery import geometric_properties
from ..stability.family_adapter import validate_family_receipt
from ..cmaa74.nbr_global import (generate_cmaa_nbr_global_coefficients,
                               compose_cmaa_nbr_segment_boxes, consumer_source)

AUDITED_KERNEL_SHA256 = "7fe1b7ad98d4a7ac137db588728c3f63917db53a1b032244ed54ad64c91b6e1e"
AUDITED_MODEL_SHA256 = "af837b0c602291dca642aa9cff2736230a25a54f5a3e5d57f385520068288b83"
OPEN_BEAM_CHECKS = (
    "local_elastic_transfer_model_missing",
    "fatigue_detail_stress_definition_unqualified", "concurrent_global_local_interaction_unqualified",
)


def _require(condition, message):
    if not condition:
        raise ValueError(message)


def beam_support_source_receipt():
    root = Path(__file__).resolve().parent
    files = {name: sha256((root/name).read_bytes()).hexdigest()
             for name in ("__init__.py", "model.py", "kernels.py", "inputs.py", "adapter.py")}
    _require(files["kernels.py"] == AUDITED_KERNEL_SHA256 and files["model.py"] == AUDITED_MODEL_SHA256,
             "Audited beam-support kernel/model bytes changed; this adapter has not qualified their replacement")
    data = dict(files=files, action_consumer=consumer_source())
    return dict(**data, fingerprint=signature(data))


def map_project_inputs(project, physical):
    """Bind physical geometry to the actual symmetric ISection and its properties.

    Beam ends MUST be exactly 0..project.length_mm, never support pitch. The top
    root is supplied independently; neither the bottom radius nor a weld throat
    is silently copied to it. The existing mechanical three-rectangle moduli are
    retained without root/weld stiffness credit or imported catalogue moduli.
    """
    project.validate()
    if isinstance(physical, dict):
        physical = physical_from_dict(physical)
    _require(isinstance(physical, BeamSupportPhysicalInputs), "Optional physical beam-support inputs have not been supplied")
    s = project.section
    _require(s.doubly_symmetric, "This autonomous adapter requires the existing symmetric ISection model")
    ends = physical.beam_ends
    _require(ends.left_x_mm == 0 and ends.right_x_mm == project.length_mm,
             "Physical beam ends must match the validated model 0..length_mm; support pitch is not beam length")
    _require(project.fy_mpa is not None and project.fu_mpa is not None,
             "Actual project fy and fu are required for beam-hole and transverse capacities")
    props = geometric_properties(s)
    root = physical.top_root
    if root is not None:
        expected = "rolled_radius" if s.construction == "rolled" else "web_parallel_weld_leg"
        _require(root.kind == expected, "Actual top-root type differs from the modeled section construction")
    section = SupportSection(s.d_mm, s.bf_mm, s.tf_mm, s.bottom_width, s.bottom_thickness, s.tw_mm,
        props["Iy_mm4"]/(s.d_mm-props["centroid_from_bottom_mm"]),
        props["Iy_mm4"]/props["centroid_from_bottom_mm"], s.construction,
        root.extension_mm if root is not None and root.kind == "rolled_radius" else None,
        root.extension_mm if root is not None and root.kind == "web_parallel_weld_leg" else None,
        physical.geometry_source, props["model"]+"; original section "+s.signature,
        "" if root is None else root.source)
    steel = Steel(project.fy_mpa, project.fu_mpa, physical.gamma_a1,
                  project.material_source, physical.factor_source)
    patterns, coverage = {}, {}
    for flange in ("top", "bottom"):
        inventory = getattr(physical, flange+"_holes")
        start, end = ((ends.left_x_mm, ends.right_x_mm) if inventory is None else
                      (inventory.x_start_mm, inventory.x_end_mm))
        _require(ends.left_x_mm <= start < end <= ends.right_x_mm,
                 flange+" inventory region lies outside the physical beam")
        patterns[flange] = HolePattern(start, end, getattr(section, flange+"_width_mm"),
            getattr(section, flange+"_thickness_mm"), None if inventory is None else inventory.holes,
            "" if inventory is None else inventory.inventory_source)
        unknown = []
        if inventory is None:
            unknown = [dict(start_mm=ends.left_x_mm, end_mm=ends.right_x_mm)]
        else:
            if start > ends.left_x_mm:
                unknown.append(dict(start_mm=ends.left_x_mm, end_mm=start))
            if end < ends.right_x_mm:
                unknown.append(dict(start_mm=end, end_mm=ends.right_x_mm))
        coverage[flange] = dict(inventory_known=inventory is not None,
            documented_region_mm=None if inventory is None else dict(start_mm=start, end_mm=end),
            hole_count=None if inventory is None else len(inventory.holes),
            whole_flange_inventory_known=inventory is not None and not unknown,
            unknown_regions_mm=unknown)
    support_ids = {s["id"] for s in project.supports}
    for patch in physical.footprints:
        _require(patch.support_id in support_ids, "Footprint names a support absent from the physical project: "+patch.support_id)
        # This validates actual patch bounds, not transfer from the ideal support.
        centered_transverse_capacities(section, steel, ends, patch.to_kernel())
    summary = dict(schema=physical.to_dict()["schema"], physical_input=physical.to_dict(),
        physical_input_signature=signature(physical.to_dict()), section=asdict(section), steel=asdict(steel),
        beam_ends=asdict(ends), hole_inventory_coverage=coverage,
        support_ids_without_footprints=sorted(support_ids-{p.support_id for p in physical.footprints}),
        footprint_count=len(physical.footprints), properties_model=props["model"],
        root_or_weld_stiffness_credit_used=False, external_efforts_accepted=False,
        support_pitch_used_as_physical_end=False, footprint_or_root_model_qualification_claimed=False)
    return physical, section, steel, ends, patterns, summary


def _complete_spatial_coverage(segments, ends):
    _require(bool(segments), "No verified mechanical segment coverage is available")
    cursor = ends.left_x_mm
    for row in sorted(segments, key=lambda r: r["start_mm"]):
        _require(row["start_mm"] == cursor and row["end_mm"] > cursor,
                 "Verified segment coverage has a gap/overlap; no full-beam hole bound may be claimed")
        cursor = row["end_mm"]
    _require(cursor == ends.right_x_mm,
             "Verified segment coverage omits a physical beam tail; support span is not complete beam coverage")


def _capacity_rows(section, steel, ends, patterns, physical):
    rows = []
    for patch in physical.footprints:
        capacities = centered_transverse_capacities(section, steel, ends, patch.to_kernel())
        pattern = patterns["top"]
        inventory_covers_patch = (pattern.holes is not None and pattern.x_start_mm <= patch.x_start_mm
                                 and pattern.x_end_mm >= patch.x_end_mm)
        intersecting = []
        if pattern.holes is not None:
            for hole in pattern.holes:
                if (hole.x_mm+hole.extent("x")/2 > patch.x_start_mm and
                    hole.x_mm-hole.extent("x")/2 < patch.x_end_mm and
                    hole.y_mm+hole.extent("y")/2 > patch.y_start_mm and
                    hole.y_mm-hole.extent("y")/2 < patch.y_end_mm):
                    intersecting.append(hole.id)
        rows.append(dict(id=patch.id, support_id=patch.support_id, footprint=asdict(patch),
            status="INFORMATIONAL_CAPACITY_ONLY", capacities=capacities,
            demand=None, utilization=None, support_reaction_proof_available=False,
            traction_field_qualified=False, holes_intersecting_patch=intersecting,
            top_inventory_covers_patch=inventory_covers_patch,
            reason="No validated support-reaction/traction-field proof exists in this family adapter. Each actual patch is kept separate; no bolt-group envelope or uniform pressure is inferred."))
    return rows


def _mode_applicability(section, summary, physical, project):
    """Separate established beam obligations from absent/unknown mechanisms."""
    cover = summary["hole_inventory_coverage"]
    complete = all(c["whole_flange_inventory_known"] for c in cover.values())
    has_holes = any(c["hole_count"] is not None and c["hole_count"] > 0 for c in cover.values())
    hole_status = ("APPLICABILITY_UNRESOLVED_HORIZONTAL_HOLE_TRANSFER" if has_holes else
                   "NOT_APPLICABLE_DOCUMENTED_UNPERFORATED_FLANGES" if complete else
                   "APPLICABILITY_UNRESOLVED_HOLE_INVENTORY")
    modes = [
        dict(id="flange_hole_bearing_tearout_net_shear_block_tearing", status=hole_status,
             reason="Requires an actual beam-hole force path; no horizontal bearing/friction distribution is inferred. Known absence is limited to the documented flanges."),
        dict(id="contact_prying_secondary_bending", status="APPLICABILITY_UNRESOLVED_LOCAL_INTERFACE",
             reason="Actual patch geometry alone does not establish prying/contact state or its elastic history. No connector resistance is requested or checked."),
        dict(id="beam_flange_web_weld_transfer_5_4_5",
             status="BEAM_CHECK_NOT_QUALIFIED" if section.construction == "welded" else "NOT_APPLICABLE_ROLLED_SECTION",
             reason="Beam-side flange/web weld transfer is required only for a welded member; rolled root metal is not treated as a weld."),
        dict(id="compression_modes_5_7_4_to_5_7_6", status="APPLICABILITY_UNRESOLVED_FORCE_REVERSAL",
             reason="No qualified local force/traction history is available to establish whether compression modes activate."),
        dict(id="demand_triggered_transverse_stiffeners_5_7_9", status="REQUIREMENT_NOT_ESTABLISHED",
             reason="No qualified local demand exceedance exists here; an informational resistance does not mandate a stiffener or assign it capacity."),
        dict(id="rotation_restraint_or_stiffeners_5_7_8", status="APPLICABILITY_UNRESOLVED_PHYSICAL_BOUNDARY",
             declared_support_phi_constraints={s["id"]: s["restrain"].get("phi") for s in project.supports},
             reason="Existing ideal-model rotation constraints remain declared external boundaries, not hardware verification or automatic beam-stiffener requirements."),
    ]
    return modes


def evaluate_family_beam_support(project, producer_receipt, *, physical=None,
        cmaa_physical=None, cmaa_action_project=None, cmaa_conversion_receipt=None):
    """Evaluate optional beam scalar geometry + internally generated My bounds.

    producer_receipt is an internal immutable mechanical artifact validated in
    full on EVERY call. No validation boolean, imported demand or report/status
    hook is accepted. Existing independent checks are not rewritten or replaced.
    Bound exceedance is inconclusive. This API never reports whole-beam PASS.
    """
    result = dict(kind="autonomous_beam_support_scalar_family_consumer",
        status="BEAM_CHECK_NOT_QUALIFIED", suspension_region_status="BEAM_CHECK_NOT_QUALIFIED",
        scalar_bending_status="PENDING_SIGNED_MOMENT_COVERAGE", physical_input_summary=None,
        net_sections={}, hole_limits={}, bending_checks=[], transverse_capacities=[], pending=[],
        remaining_beam_checks=list(OPEN_BEAM_CHECKS), conditional_beam_modes=[], whole_beam_complete=False,
        whole_beam_qualified=False, suspension_region_qualified=False,
        actual_failure_proven=False, governing_physical_state_invented=False,
        concurrent_tensor_claimed=False, continuum_upper_bound_claimed=False,
        external_efforts_required=False, support_reaction_proof_available=False,
        external_design=dict(bolts="OUTSIDE_SCOPE", receiver="OUTSIDE_SCOPE", floor="OUTSIDE_SCOPE", building="OUTSIDE_SCOPE"))
    try:
        own = beam_support_source_receipt()
        physical, section, steel, ends, patterns, summary = map_project_inputs(project, physical)
        result["physical_input_summary"] = summary
        result["conditional_beam_modes"] = _mode_applicability(section, summary, physical, project)
        if section.construction == "welded":
            result["remaining_beam_checks"].append("beam_flange_web_weld_transfer_5_4_5_unqualified")
        for flange in ("top", "bottom"):
            result["net_sections"][flange] = minimum_net_section(patterns[flange])
            result["hole_limits"][flange] = flange_hole_limit(section, steel, patterns[flange], flange=flange)
        result["transverse_capacities"] = _capacity_rows(section, steel, ends, patterns, physical)
        before = signature(project.to_dict())
        action_project = project if cmaa_action_project is None else cmaa_action_project
        action_before = signature(action_project.to_dict())
        _, plan = validate_family_receipt(project, producer_receipt)
        family = generate_cmaa_nbr_global_coefficients(project, plan, cmaa_physical,
            cmaa_action_project=cmaa_action_project, cmaa_conversion_receipt=cmaa_conversion_receipt)
        _require(family["all_members_contact_valid"],
                 "A factored CMAA/NBR state loses physical bridge contact; no states may be clipped or skipped")
        mechanical_segments = producer_receipt["true_fork_boundary_audit"]["segments"]
        _complete_spatial_coverage(mechanical_segments, ends)
        boxes = compose_cmaa_nbr_segment_boxes(plan, producer_receipt["basis_evidence"],
                                              family["coefficient_intervals"], mechanical_segments)
        family_signature = signature(family)
        membership = [dict(configuration_id=m["configuration_id"], case_id=m["case_id"])
                      for m in family["members"]]
        coverage = dict(producer_receipt_signature=producer_receipt["receipt_signature"],
            mechanical_generated_input_signature=producer_receipt["generated_input_signature"],
            coefficient_family_signature=family_signature, complete_membership=membership,
            total_configuration_count=family["total_configuration_count"],
            characteristic_state_count=family["characteristic_state_count"],
            partial_factor_variant_count=family["partial_factor_variant_count"],
            total_case_count=family["total_case_count"],
            covered_physical_travel_intervals_mm=deepcopy(producer_receipt["covered_physical_travel_intervals_mm"]),
            spatial_segments_mm=[dict(start_mm=b["start_mm"], end_mm=b["end_mm"]) for b in boxes],
            mechanical_spatial_coverage_complete=True,
            full_hole_inventory_coverage=all(c["whole_flange_inventory_known"] for c in summary["hole_inventory_coverage"].values()),
            signed_quantity="My_Nmm", signed_mapping="My_Nmm = family My; +x-cut; sigma_x=My*z/Iy; positive tensions top",
            axes=AXES, interval_only=True, all_active_basis_verification_allowances_scaled=True,
            coefficient_intervals_are_relaxation=True, physical_states_are_not_mixed_into_a_vector=True,
            NBR_psi=family["NBR_psi"], NBR_impact_reapplied=family["NBR_impact_reapplied"],
            origin_equation=family["origin_equation"], action_adoption=family["action_adoption"],
            dynamic_action_source=family["dynamic_action_source"], partial_factor_sources=family["partial_factor_sources"])
        coverage_signature = signature(coverage)
        for index, box in enumerate(boxes):
            for flange in ("top", "bottom"):
                pattern = patterns[flange]
                start, end = max(box["start_mm"], pattern.x_start_mm), min(box["end_mm"], pattern.x_end_mm)
                if end <= start:
                    continue
                raw = box["bounds"]["My"]
                # Selecting a tension sign is not taking absolute values or
                # changing My's physical sign. The other sign is checked in its
                # own flange/physical inventory, even when regions differ.
                lo, hi = ((max(0., raw["lower"]), max(0., raw["upper"])) if flange == "top" else
                          (min(0., raw["lower"]), min(0., raw["upper"])))
                interval = SignedInterval("My_Nmm", lo, hi, "beam_region/"+flange, start, "right",
                    family["action_adoption"]+"; "+"; ".join(family["partial_factor_sources"]),
                    "Validated mechanical receipt "+producer_receipt["receipt_signature"]+"; regenerated CMAA/NBR "+family_signature,
                    "Full moving/configuration coverage "+coverage_signature+"; verified spatial segment "+str(box["start_mm"])+".."+str(box["end_mm"])+" mm; interval anchor is not an actual governing cut")
                check = check_flange_hole_bending(section, steel, patterns["top"], patterns["bottom"], interval)
                result["bending_checks"].append(dict(segment_index=index, flange=flange,
                    checked_region_mm=dict(start_mm=start, end_mm=end),
                    signed_global_My_interval_Nmm=deepcopy(raw), signed_tension_component_interval_Nmm=dict(lower=lo, upper=hi),
                    identity_anchor_semantics="Actual inventory/segment intersection boundary, not a demand sample or governing x; support_id labels the beam region, never a support reaction",
                    demand_bound_covers_entire_checked_region=True, result=check))
        _require(before == signature(project.to_dict()) and action_before == signature(action_project.to_dict()),
                 "Physical project changed during beam-support consumption")
        _require(producer_receipt["source_at_end"] == _source(), "Numerical source changed during beam-support consumption")
        _require(own == beam_support_source_receipt(), "Beam-support/action consumer source changed during evaluation")
        result["coverage"] = coverage
        checks = [c for row in result["bending_checks"] for c in row["result"]["checks"]]
        known = coverage["full_hole_inventory_coverage"]
        if any(c["status"] == "INCONCLUSIVE_BOUND" for c in checks):
            result["scalar_bending_status"] = "INCONCLUSIVE_SUFFICIENT_BOUND"
        elif known and all(c["status"] in ("PASS_COMPONENT", "NO_ADDITIONAL_HOLE_LIMIT") for c in checks):
            result["scalar_bending_status"] = "SUFFICIENT_HOLE_BENDING_BOUND_SATISFIED"
        else:
            result["scalar_bending_status"] = "BEAM_CHECK_NOT_QUALIFIED"
        if not known:
            result["pending"].append("Complete top/bottom flange hole inventories are not available; unknown or out-of-region metal was not declared unperforated")
        result["source_receipt"] = dict(consumer_source=own, original_project_signature=before,
            action_project_signature=action_before, physical_input_signature=summary["physical_input_signature"],
            producer_receipt_signature=producer_receipt["receipt_signature"],
            producer_source_fingerprint=producer_receipt["source_at_end"]["fingerprint"],
            mass_conversion_receipt_signature=None if cmaa_conversion_receipt is None else cmaa_conversion_receipt["receipt_signature"],
            coefficient_family_signature=family_signature, coverage_signature=coverage_signature,
            all_sources_unchanged=True)
    except (ValueError, TypeError, KeyError, ArithmeticError, AttributeError) as exc:
        # Keep independently calculated geometric net areas/capacities visible.
        # Discard any incomplete/stale demand checks; never erase other reports.
        result["bending_checks"] = []
        result.pop("coverage", None)
        result.pop("source_receipt", None)
        result["scalar_bending_status"] = "PENDING_SIGNED_MOMENT_COVERAGE"
        result["pending"].append(type(exc).__name__+": "+str(exc))
    result["component_summary"] = summarize_beam_components(*[r["result"] for r in result["bending_checks"]])
    result["status"] = result["component_summary"]["status"]
    result["actual_failure_proven"] = result["status"] == "FAIL_BEAM_COMPONENT"
    result["result_signature"] = signature(result)
    return result
