"""EN13001-3-3:2014 line-contact arithmetic, non-surface-hardened steel only.
Source: public standard text, independently visual cross-check of Delft thesis
pp.21-23. NOT a qualified thin bottom-flange domain check. N, mm, MPa.
No DIN/FEM or bearing L10 substitutions. Do not expose overall PASS from this file.
"""
from dataclasses import dataclass
from math import isfinite, pi, sqrt

M = 10/3
REFERENCE_CONTACTS = 6_400_000
GAMMA_M = GAMMA_CF = 1.1
F2 = {
 'self_aligning': (1.0,1.0,.95,.9),
 'nonaligning_elastic_support': (.95,.9,.85,.8),
 'nonaligning_rigid_support': (.9,.85,.8,.7),
}
TOLERANCE_ANGLE = (.0015,.0025,.0035,.0045)


def number(x,name,positive=True):
    try:
        valid=(not isinstance(x,bool) and isinstance(x,(int,float)) and isfinite(x)
               and (x>0 if positive else x>=0))
        result=float(x) if valid else None
    except (OverflowError,ValueError,TypeError):
        valid=False;result=None
    if not valid:
        raise ValueError(f'{name}: finite {"positive" if positive else "nonnegative"} number required')
    return result

@dataclass(frozen=True)
class Steel:
    hardness_HBW: float
    hardness_source: str
    verified_depth_mm: float
    E_MPa: float
    state: str = 'non_surface_hardened'

@dataclass(frozen=True)
class Geometry:
    wheel_diameter_mm: float
    wheel_material_width_mm: float
    wheel_corner_radius_mm: float
    track_material_width_mm: float
    track_corner_radius_mm: float
    flange_thickness_mm: float
    wheel_footprint_to_free_edge_mm: float
    wheel_footprint_to_web_fillet_mm: float
    # None means an actually cylindrical tread and plane running surface.
    crown_radius_mm: float | None = None

@dataclass(frozen=True)
class Operation:
    static_design_force_N: float
    maximum_unfactored_force_N: float
    # Each tuple is (normal force, number of contacts); NOT working cycles.
    wheel_contacts: tuple[tuple[float,float],...]
    flange_contacts: tuple[tuple[float,float],...]
    tolerance_class: int
    mounting: str
    guide_slack_skew_rad: float
    wear_skew_rad: float
    driven_wheel: bool
    abrasive_environment: bool


def contact_history(bins):
    if not bins: raise ValueError('Contact history must not be empty')
    for f,n in bins:
        number(f,'force',False); number(n,'contact count')
    maximum = max(f for f,n in bins)
    if maximum == 0: raise ValueError('At least one positive contact force required')
    count = sum(n for f,n in bins)
    number(count,'total rolling contacts')
    kc = sum(n*(f/maximum)**M for f,n in bins)/count
    sc = kc*count/REFERENCE_CONTACTS
    number(kc,'contact spectrum factor');number(sc,'contact history parameter')
    return dict(maximum_force_N=maximum,contacts=count,kc=kc,sc=sc)


def evaluate(wheel: Steel, flange: Steel, g: Geometry, op: Operation):
    if not isinstance(wheel,Steel) or not isinstance(flange,Steel) or not isinstance(g,Geometry) or not isinstance(op,Operation):
        raise ValueError('Typed material, geometry and operation inputs required')
    for name,material in [('wheel',wheel),('flange',flange)]:
        for field in ('hardness_HBW','verified_depth_mm','E_MPa'):
            number(getattr(material,field),name+'.'+field)
        if material.state!='non_surface_hardened':
            raise ValueError('Surface-hardened/cast-iron material is outside this bounded kernel')
        if not isinstance(material.hardness_source,str) or not material.hardness_source.strip():
            raise ValueError('Verified hardness provenance is required; no inference from yield stress')
    for field in ('wheel_diameter_mm','wheel_material_width_mm','track_material_width_mm','flange_thickness_mm'):
        number(getattr(g,field),field)
    for field in ('wheel_corner_radius_mm','track_corner_radius_mm','wheel_footprint_to_free_edge_mm','wheel_footprint_to_web_fillet_mm'):
        number(getattr(g,field),field,False)
    bw=g.wheel_material_width_mm-2*g.wheel_corner_radius_mm
    br=g.track_material_width_mm-2*g.track_corner_radius_mm
    b=min(bw,br)
    number(b,'effective width')
    if g.crown_radius_mm is not None:
        number(g.crown_radius_mm,'crown radius')
        if g.crown_radius_mm <= 200*b:
            raise ValueError('Only cylindrical or rk > 200b line-contact branch is implemented')
    for field in ('static_design_force_N','maximum_unfactored_force_N'):
        number(getattr(op,field),field)
    if type(op.tolerance_class) is not int or op.tolerance_class not in (1,2,3,4):
        raise ValueError('Actual ISO12488-1 tolerance class 1..4 required')
    if op.mounting not in F2: raise ValueError('Unsupported mounting classification')
    for field in ('guide_slack_skew_rad','wear_skew_rad'):
        number(getattr(op,field),field,False)
    for field in ('driven_wheel','abrasive_environment'):
        if type(getattr(op,field)) is not bool: raise ValueError('Explicit boolean required: '+field)
    histories={'wheel':contact_history(op.wheel_contacts),'flange':contact_history(op.flange_contacts)}
    if op.maximum_unfactored_force_N < max(h['maximum_force_N'] for h in histories.values()):
        raise ValueError('Non-factored design maximum must cover both rolling-contact histories')
    em=2*wheel.E_MPa*flange.E_MPa/(wheel.E_MPa+flange.E_MPa)
    number(em,'equivalent modulus')
    geo=pi*g.wheel_diameter_mm*b*(1-.3**2)/em
    depth_denominator=b*em
    number(depth_denominator,'contact depth denominator')
    zml=.5*sqrt(op.maximum_unfactored_force_N*pi*g.wheel_diameter_mm*(1-.3**2)/depth_denominator)
    for label,value in [('equivalent modulus',em),('contact geometry factor',geo),('maximum shear depth',zml)]:number(value,label)
    # Lower bound across Table3 edge factors, applied to BOTH parties for RCF.
    # Avoids credit for lateral motion/being the wider party; does NOT model
    # physical flange free-edge/thickness effects.
    f1=.85
    f2=F2[op.mounting][op.tolerance_class-1]
    alpha=op.guide_slack_skew_rad+op.wear_skew_rad+TOLERANCE_ANGLE[op.tolerance_class-1]
    number(alpha,'total skew angle')
    ff3=1.0 if alpha<=.005 else (.005/alpha)**(1/3)
    ff4=.95 if op.driven_wheel and op.abrasive_environment else 1.0
    results={}
    for name,material,bins in [('wheel',wheel,op.wheel_contacts),('flange',flange,op.flange_contacts)]:
        h=histories[name]
        try:
            static=(7*material.hardness_HBW)**2*geo/GAMMA_M*f1*f2
            fu=(3*material.hardness_HBW)**2*geo
            ff=f1*ff3*(ff4 if name=='wheel' else 1.0)
            fatigue=fu/(GAMMA_CF*h['sc']**(1/M))*ff
        except (OverflowError,ZeroDivisionError) as exc:
            raise ValueError('Contact resistance arithmetic outside finite numerical domain') from exc
        for label,value in [('static contact capacity',static),('reference contact force',fu),('fatigue contact capacity',fatigue)]:number(value,label)
        static_ratio=op.static_design_force_N/static;fatigue_ratio=h['maximum_force_N']/fatigue
        number(static_ratio,'static contact ratio');number(fatigue_ratio,'fatigue contact ratio')
        results[name]={
            'static_limit_N':static,'static_ratio':static_ratio,
            'reference_contact_force_N':fu,'fatigue_limit_N':fatigue,
            'fatigue_ratio':fatigue_ratio,'history':h,
            'hardness_depth_exceeds_max_shear':material.verified_depth_mm>zml,
            'hardness_depth_at_least_twice_max_shear':material.verified_depth_mm>=2*zml,
        }
    issues=['Thin lower-flange/free-edge domain not independently qualified',
            'Contact plus nominal stress interaction not independently qualified',
            'Input action combinations must be generated consistently with EN13001-2',
            'Flat contact fit and alignment under flange deflection require geometry qualification']
    if flange.verified_depth_mm>g.flange_thickness_mm:
        issues.append('Verified material depth exceeds actual flange thickness')
    if any(not r['hardness_depth_exceeds_max_shear'] for r in results.values()):
        issues.append('Material hardness does not extend beyond maximum-shear depth')
    return dict(status='CONDITIONAL_STANDARD_ARITHMETIC',contact_cleared=False,
                equivalent_modulus_MPa=em,effective_width_mm=b,max_shear_depth_mm=zml,
                f1=f1,f2=f2,ff3=ff3,wheel_ff4=ff4,skew_angle_rad=alpha,
                wheel=results['wheel'],flange=results['flange'],unresolved=issues)
