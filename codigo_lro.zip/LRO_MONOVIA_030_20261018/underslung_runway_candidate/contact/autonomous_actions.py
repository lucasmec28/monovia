"""Internal EN13001 normal-operation/test CONTACT action and count producer.

Physical bridge masses/CG/accelerations are regenerated through the same full
8-contact transfer model. No structural efforts from Robot or external force
provenance are inputs. This named scope does NOT silently cover buffers,
emergency stops, limiters, skew guidance or environmental/assembly effects.
"""
from dataclasses import dataclass,asdict,replace,fields
from pathlib import Path
from hashlib import sha256
from math import ceil,pi
from ..autonomous_workflow.model import finite,checked_text,signature
from ..autonomous_workflow.inertia_bridge_adapter import BridgeInertiaInputs,generate_inertia_configurations
from ..bridge_inertia.statics import combine
from .en13001_kernel import Operation,F2
from .eligibility import ENContactActionReceipt,operation_signature

SOURCE='EN13001-2:2014 4.2.2.1-2 Tables2-4,4.2.4.3,4.3 Tables9/12; EN13001-3-3:2014 4.3,6.2,6.3.4-5; EN15011:2011+A1:2014 smooth-track normal domain'
UNCOVERED=(
 'Occasional skew/guidance and environmental/displacement effects outside the named indoor smooth-track normal/test domain.',
 'Exceptional emergency cut-out, buffers, force limiters, collisions, assembly and other applicable exceptional events are not generated.',
 'Vertical hoist-drive transients beyond the declared grounded-hoist/quasi-static suspended horizontal-manoeuvre domain are not generated.')

@dataclass(frozen=True)
class ContactPhysicalInputs:
    hoist_speed_max_m_s:float
    test_static_ratio:float
    test_dynamic_ratio:float
    risk_coefficient:float
    life_cycles:int
    loaded_travel_legs_per_cycle:int
    empty_travel_legs_per_cycle:int
    travel_distance_per_leg_mm:float
    stationary_load_cycles_per_cycle:int
    wheel_diameter_mm:float
    tolerance_class:int
    mounting:str
    guide_slack_skew_rad:float
    wear_skew_rad:float
    driven_wheel:bool
    abrasive_environment:bool
    operating_domain:str
    hoist_mass_scope:str
    action_model_source:str
    lifetime_operating_limit_source:str
    contact_arrangement_source:str
    def validate(self):
        for k in ('hoist_speed_max_m_s','test_static_ratio','test_dynamic_ratio','risk_coefficient','travel_distance_per_leg_mm','wheel_diameter_mm','guide_slack_skew_rad','wear_skew_rad'):
            v=finite(getattr(self,k),k)
            if v<0:raise ValueError(k+' cannot be negative')
        if self.test_static_ratio<1.25 or self.test_dynamic_ratio<1.1:raise ValueError('EN source minimum test ratios are1.25 static and1.10 dynamic; larger product-specific requirements must be entered')
        if not 1<=self.risk_coefficient<=2:raise ValueError('EN risk coefficient domain is1..2, selected as a design premise')
        if self.wheel_diameter_mm<=0:raise ValueError('Actual positive wheel diameter required')
        if type(self.tolerance_class) is not int or self.tolerance_class not in (1,2,3,4):raise ValueError('Physical tolerance class1..4 required')
        if self.mounting not in F2:raise ValueError('Physical mounting classification required')
        if type(self.driven_wheel) is not bool or type(self.abrasive_environment) is not bool:raise ValueError('Explicit driven/abrasive booleans required')
        for k in ('life_cycles','loaded_travel_legs_per_cycle','empty_travel_legs_per_cycle','stationary_load_cycles_per_cycle'):
            v=getattr(self,k)
            if type(v) is not int or not 0<=v<=10**12:raise ValueError(k+' must be a bounded nonnegative integer')
        if self.life_cycles<1 or self.loaded_travel_legs_per_cycle+self.empty_travel_legs_per_cycle+self.stationary_load_cycles_per_cycle<1:raise ValueError('Positive lifetime operating/contact domain required')
        if self.operating_domain!='indoor_smooth_track_no_release_no_impacts_normal_and_tests':raise ValueError('Only the explicitly named normal/test scope is generated')
        if self.hoist_mass_scope not in ('capacity_mass_includes_all_suspended_attachments','payload_plus_retained_common_ledger'):raise ValueError('Explicit payload and retained suspended mass accounting required')
        for k in ('action_model_source','lifetime_operating_limit_source','contact_arrangement_source'):checked_text(getattr(self,k),k)
        return self


def contact_counts(p,*,wheels_on_running_line):
    p.validate()
    if type(wheels_on_running_line) is not int or wheels_on_running_line<1:raise ValueError('Actual same-running-line wheel count required')
    legs=p.loaded_travel_legs_per_cycle+p.empty_travel_legs_per_cycle
    if legs and p.travel_distance_per_leg_mm<=0:raise ValueError('Moving legs require positive maximum distance')
    # Every monotonic leg may start at an adverse tread phase; no wheel
    # replacement credit is taken. Stationary pressure cycles count explicitly.
    rev_per_leg=ceil(p.travel_distance_per_leg_mm/(pi*p.wheel_diameter_mm))+1 if legs else 0
    wheel=p.life_cycles*(legs*rev_per_leg+p.stationary_load_cycles_per_cycle)
    # Each possible track material point is conservatively crossed by every
    # same-line wheel on every leg, and receives every stationary fluctuation.
    track=p.life_cycles*wheels_on_running_line*(legs+p.stationary_load_cycles_per_cycle)
    finite(wheel,'computed wheel contacts');finite(track,'computed track contacts')
    return dict(wheel_contacts=wheel,flange_contacts=track,monotonic_legs_per_cycle=legs,
        wheel_contacts_per_leg_upper=rev_per_leg,wheels_on_running_line=wheels_on_running_line,
        no_wheel_replacement_credit=True,stationary_cycles_counted=True,
        source='EN13001-3-3:2014 6.3.5; conservative phase/maximum-distance/contact-count envelope')


def generate_contact_actions(project,p):
    """Return internally generated per-wheel Operation + typed action receipt.

    Scope is the selected fixed hook/height configuration on its selected rail.
    All eight bridge contacts are checked in every generated force state. Other
    admissible configurations must be generated separately, never called a
    universal worst crane position from one selected record.
    """
    if not isinstance(p,ContactPhysicalInputs):raise ValueError('Typed physical contact inputs required')
    project.validate();p.validate()
    if p.hoist_mass_scope!='payload_plus_retained_common_ledger' or not project.suspended_mass_basis()['complete_suspended_mass_accounting']:
        raise ValueError('Contact action generation requires explicit common retained suspended mass and point; legacy empty-state accounting is incomplete')
    ledger=project.bridge_reaction_ledger
    if not isinstance(ledger,dict) or ledger.get('schema')!='LRO_BOUND_BRIDGE_INERTIA_LEDGER_V1':raise ValueError('Internal physical bridge inertia inputs required; no external wheel effort route')
    if project.travel_min_mm is None or project.travel_max_mm is None:raise ValueError('Physical travel/endstop range required')
    if p.loaded_travel_legs_per_cycle+p.empty_travel_legs_per_cycle and p.travel_distance_per_leg_mm<project.travel_max_mm-project.travel_min_mm:
        raise ValueError('Per-leg distance premise must cover the complete allowed physical travel interval')
    base=BridgeInertiaInputs(**ledger['inputs'])
    config_id=ledger['selected_configuration_id'];eid=ledger['selected_configuration']['endpoint_id']
    rail=ledger['selected_configuration']['rail_index']
    phi2=1.2+.68*p.hoist_speed_max_m_s;phi6=.5*(1+phi2);risk=p.risk_coefficient
    finite(phi2,'hoist dynamic bound')
    # HC4/HD1 is a bounded upper scenario across Tables2-4 at the declared max
    # hoist speed, not a claim about the equipment's actual classes.
    configurations={};states=[];audits=[];contactmax={};static={}
    # EN13001-2 4.2.2.5: Si + phi5*(Sf-Si). If both initial/final
    # rigid effects are bounded by Smax and phi5<=3, the absolute response
    # is bounded by (|1-phi5|+phi5)*Smax <=5*Smax. This includes
    # reversal/backlash. The acceleration input bounds BOTH endpoint states.
    # This is a separate EN envelope, not the project's NBR H multiplier.
    drive_reversal_factor=5.
    scenarios=(('NORMAL','A',1.,drive_reversal_factor,1.1,phi2,True),
               ('DYNAMIC_TEST','C',p.test_dynamic_ratio,drive_reversal_factor,1.1,phi6,True),
               ('STATIC_TEST','C',p.test_static_ratio,1.,1.1,1.,False),
               ('RCF','A',1.,1.,1.,1.,True))
    for name,group,mass_ratio,k,gfac,qfac,moving in scenarios:
        ip=replace(base,capacity_t=base.capacity_t*mass_ratio,horizontal_dynamic_factor=k,
                   bridge_acceleration_m_s2=base.bridge_acceleration_m_s2 if moving else 0.,
                   trolley_acceleration_m_s2=base.trolley_acceleration_m_s2 if moving else 0.)
        generated=generate_inertia_configurations(project.section,ip)
        ep=next(e for e in generated['endpoint_receipts'] if e['id']==eid)
        data=ep['generated'];configurations[name]=generated['input_signature']
        relevant=[c for c in data['contacts'] if c['rail_index']==rail]
        for loaded in ((False,True) if name in ('NORMAL','RCF') else (True,)):
            for hx in (-1,1):
                for hy in (-1,1):
                    # Common1.34 is an intentionally conservative upper of the
                    # relevant A and test-C partial factors, not an exact table row.
                    factors=(1.,) if name=='RCF' else (1.,1.34)
                    combined=[]
                    for gamma in factors:
                        r=combine(data,equipment_factor=gfac*gamma,lifted_factor=qfac*gamma,
                                  hx_multiplier=hx*gamma,hy_multiplier=hy*gamma,loaded=loaded)
                        if not r['no_hold_down_contact_valid']:raise ValueError('Adopted bounded '+name+' design state requires tensile contact; no-hold-down model is outside this design domain (not a prediction of actual equipment uplift)')
                        audits.append(dict(scenario=name,loaded=loaded,hx=hx,hy=hy,gamma_p=gamma,equilibrium=r['equilibrium'],contact_status=r['contact_status']))
                        combined.append(r)
                    for c in relevant:
                        ident=c['id'];values=[]
                        for r in combined:
                            z=next(a['force_N'][2] for a in r['loads'] if a['contact_id']==ident)
                            # Only roundoff within the kernel's explicit allowance
                            # can become zero. No physical tensile contact is clipped.
                            values.append(max(0.,-z)*risk)
                        if name=='RCF':contactmax[ident]=max(contactmax.get(ident,0.),values[0])
                        else:
                            row=dict(case_id=f'{name}/{loaded}/{hx}/{hy}',combination_group=group,
                                nonfactored_design_force_N=values[0],design_force_N=values[1])
                            static.setdefault(ident,[]).append(row)
        # Correlate removable payload gravity and inertia. Empty removes its
        # parcels only; retained suspended mass keeps gravity and inertia. Since every contact force is affine in payload
        # mass, these endpoints cover its entire allowed mass interval.
        # Source partial-factor minima/maxima are conservatively relaxed; a
        # failed sufficient guard is NOT asserted to prove actual uplift.
        if name!='RCF':
            for loaded in ((False,True) if name=='NORMAL' else (True,)):
                for hx in (-1,1):
                    for hy in (-1,1):
                        low=combine(data,equipment_factor=.95*.95,lifted_factor=1.,
                            hx_multiplier=1.34*hx,hy_multiplier=1.34*hy,loaded=loaded)
                        audits.append(dict(scenario=name+'_MINIMUM_CONTACT_BOUND',loaded=loaded,hx=hx,hy=hy,
                            gamma_p='mixed bounded coefficients',equilibrium=low['equilibrium'],contact_status=low['contact_status']))
                        if not low['no_hold_down_contact_valid']:
                            raise ValueError('Sufficient correlated-mass contact guard is inconclusive under relaxed minimum-gravity/maximum-drive factors; this is not proof of actual physical uplift. Refine the applicable source coefficients or connection/contact model.')
    input_sig=signature(dict(project=project.to_dict(),physical=asdict(p),configuration_signatures=configurations))
    source_hash=sha256(Path(__file__).read_bytes()).hexdigest();rows=[]
    # The same side/gauge identifies the physical running line. Both longitudinal
    # wheels on that line contribute to track counts; opposite-side wheels do not.
    for ident,cases in static.items():
        suffix=ident.split('/')[-1]
        same_line=[other for other in static if other.split('/')[-1]==suffix]
        line_count=len(same_line)
        # The stationary track point sees EVERY wheel on its running line.
        # Use their maximum force for its entire count, not this wheel's force.
        line_cases=[dict(c,case_id=other+'/'+c['case_id']) for other in same_line for c in static[other]]
        counts=contact_counts(p,wheels_on_running_line=line_count)
        force=contactmax[ident]
        track_force=max(contactmax[other] for other in same_line)
        if force<=0:raise ValueError('No positive contact load in the selected physical wheel domain')
        op=Operation(max(c['design_force_N'] for c in line_cases),max(c['nonfactored_design_force_N'] for c in line_cases),
            ((force,counts['wheel_contacts']),),((track_force,counts['flange_contacts']),),p.tolerance_class,p.mounting,
            p.guide_slack_skew_rad,p.wear_skew_rad,p.driven_wheel,p.abrasive_environment)
        receipt=ENContactActionReceipt(operation_signature(op),input_sig,source_hash,tuple(line_cases),(),UNCOVERED,
            'regular_A_risk_retained_all_phi_and_gamma_p_equal_1',counts['source'],counts['source'])
        rows.append(dict(wheel_id=ident,configuration_id=config_id,operation=op,action_receipt=receipt,counts=counts))
    return dict(status='INTERNAL_NORMAL_AND_TEST_CONTACT_ACTIONS',source=SOURCE,rows=rows,input_signature=input_sig,
        source_hash=source_hash,phi1_upper=1.1,phi2_upper=phi2,phi6_dynamic_test=phi6,
        common_covered_partial_factor=1.34,drive_reversal_factor=drive_reversal_factor,
        drive_basis='EN13001-2 4.2.2.5: absolute initial/final acceleration bounds and phi5<=3; reversal envelope5',risk_coefficient=risk,contact_audits=audits,
        physical_inputs=asdict(p),external_efforts_required=False,complete_A_B_C_domain=False,
        pending=list(UNCOVERED),scope='Selected fixed hook/height/rail; source-defined normal operation and tests only',
        force_history_assumption='Each computed wheel/track contact is conservatively assigned its maximum regular contact force; no cycle reduction.')
