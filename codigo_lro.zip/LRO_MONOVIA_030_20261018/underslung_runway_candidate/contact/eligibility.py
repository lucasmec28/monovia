"""Qualified CONTACT-only wrapper for a bounded flat underhung running surface.

EN13001-3-3:2014 4.1 covers wheel/rail contacts generally; 4.2/4.3 and 5/6
provide the geometry, material-depth, edge, alignment and strength conditions.
A lower flange is not rejected solely because it is a flange. This wrapper is
not local flange bending, structural fatigue, suspension or whole-beam design.

The action receipt is an INTERNAL producer contract. It is never a user-facing
'complete' checkbox and cannot be reconstructed from a provenance text alone.
A physical bridge/action generator can provide it without external demands.
"""
from dataclasses import dataclass,asdict
from hashlib import sha256
from math import isclose
import json
from .en13001_kernel import evaluate,number,Geometry,Operation,Steel
from ..section_stress.recovery import ISection

SOURCE='EN13001-3-3:2014 clauses4.1-4.4,5.2-5.3.4,6.2-6.4; explicitly adopted separate contact method'

def operation_signature(op):
    if not isinstance(op,Operation):raise ValueError('Operation required')
    return sha256(json.dumps(asdict(op),sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()

@dataclass(frozen=True)
class FlatRunningSurface:
    section: ISection
    contact_center_from_free_edge_mm: float
    # Minimum actual offsets of the tread centre over ALL permissible lateral
    # travel/misalignment states, relative to its nominal coordinate.
    lateral_min_offset_mm: float
    lateral_max_offset_mm: float
    geometry_source: str
    alignment_and_mounting_source: str

@dataclass(frozen=True)
class ENContactActionReceipt:
    operation_signature: str
    input_signature: str
    producer_source_hash: str
    # Rows: case_id, combination_group A/B/C, design_force_N,
    # nonfactored_design_force_N. Dynamics/risk retained in the latter.
    static_cases: tuple
    # Groups not applicable are decided by the internal source-based generator,
    # with the physical reason retained; not by a free user approval checkbox.
    excluded_groups: tuple
    unresolved_mechanisms: tuple
    rolling_basis: str
    wheel_contact_count_source: str
    flange_contact_count_source: str
    producer_kind: str='internal_EN13001_2_2014_cases_v1'


def _text(v,label):
    if not isinstance(v,str) or not v.strip():raise ValueError(label+' required')


def flat_surface_eligibility(g,surface):
    if not isinstance(g,Geometry) or not isinstance(surface,FlatRunningSurface):raise ValueError('Geometry and physical surface required')
    s=surface.section
    if not isinstance(s,ISection) or s.construction!='rolled' or not s.doubly_symmetric:
        raise ValueError('Bounded contact wrapper requires a parallel doubly symmetric rolled I section')
    if s.bottom_root_radius_mm<=0:raise ValueError('Actual rolled root radius required')
    for k in ('geometry_source','alignment_and_mounting_source'):_text(getattr(surface,k),k)
    n=number(surface.contact_center_from_free_edge_mm,'tread centre from free edge')
    # Signed offsets need a separate finite real validator.
    offsets=[]
    for x in (surface.lateral_min_offset_mm,surface.lateral_max_offset_mm):
        if isinstance(x,bool) or not isinstance(x,(int,float)):raise ValueError('Finite signed lateral offset required')
        number(abs(x),'lateral offset magnitude',False);offsets.append(float(x))
    if offsets[0]>offsets[1]:raise ValueError('Reversed lateral travel bounds')
    if g.track_corner_radius_mm!=0:raise ValueError('This surface adapter requires an explicit flat running strip with no additional edge-round deduction')
    clear=(s.bottom_width-s.tw_mm)/2-s.bottom_root_radius_mm
    bw=g.wheel_material_width_mm-2*g.wheel_corner_radius_mm
    number(clear,'actual flat flange width');number(bw,'actual flat tread width')
    if not isclose(g.track_material_width_mm,clear,rel_tol=1e-12,abs_tol=1e-9):raise ValueError('Track width does not match actual flat flange strip')
    if not isclose(g.flange_thickness_mm,s.bottom_thickness,rel_tol=1e-12,abs_tol=1e-9):raise ValueError('Contact/section thickness mismatch')
    free=n+offsets[0]-bw/2
    root=clear-n-offsets[1]-bw/2
    if free<0 or root<=0:raise ValueError('Complete flat tread footprint must fit outside the root and within the free edge throughout lateral travel')
    for supplied,actual,label in ((g.wheel_footprint_to_free_edge_mm,free,'free-edge clearance'),(g.wheel_footprint_to_web_fillet_mm,root,'root clearance')):
        if not isclose(supplied,actual,rel_tol=1e-12,abs_tol=1e-9):raise ValueError(label+' is inconsistent with section/contact geometry')
    return dict(eligible=True,section_signature=s.signature,flat_flange_width_mm=clear,
        flat_tread_width_mm=bw,minimum_free_edge_clearance_mm=free,minimum_root_clearance_mm=root,
        geometry_source=surface.geometry_source,alignment_and_mounting_source=surface.alignment_and_mounting_source,
        actual_contact_pressure_field_solved=False,scope='Source line-contact model; actual edge/alignment factors retained')


def _action_issues(op,r):
    if r is None:return ['Internal EN13001 action/contact-count producer receipt is required; no external structural demands are required.']
    if not isinstance(r,ENContactActionReceipt):raise ValueError('Internal typed EN contact receipt required, not a manual completion flag')
    if r.producer_kind!='internal_EN13001_2_2014_cases_v1':raise ValueError('Unrecognized contact action producer')
    for k in ('input_signature','producer_source_hash','wheel_contact_count_source','flange_contact_count_source'):_text(getattr(r,k),k)
    if r.operation_signature!=operation_signature(op):raise ValueError('Stale contact receipt: operation signature mismatch')
    if r.rolling_basis!='regular_A_risk_retained_all_phi_and_gamma_p_equal_1':raise ValueError('RCF action basis must follow EN13001-3-3 6.2')
    if not r.static_cases:raise ValueError('Generated EN static cases are required')
    seen=set();ids=set();maxd=max0=0.
    for row in r.static_cases:
        if not isinstance(row,dict):raise ValueError('Malformed internal case row')
        _text(row.get('case_id'),'generated case id')
        if row['case_id'] in ids:raise ValueError('Duplicate generated case id')
        ids.add(row['case_id']);group=row.get('combination_group')
        if group not in ('A','B','C'):raise ValueError('Unknown EN13001 combination group')
        seen.add(group)
        maxd=max(maxd,number(row.get('design_force_N'),'generated design force',False))
        max0=max(max0,number(row.get('nonfactored_design_force_N'),'generated nonfactored design force',False))
    excluded=set()
    for row in r.excluded_groups:
        if not isinstance(row,dict) or row.get('group') not in ('A','B','C'):raise ValueError('Invalid excluded action group')
        _text(row.get('physical_reason'),'physical source-based exclusion reason')
        _text(row.get('source_clause'),'exclusion source clause')
        if row['group'] in seen or row['group'] in excluded:raise ValueError('Conflicting action-group coverage')
        excluded.add(row['group'])
    issues=[]
    if seen|excluded!={'A','B','C'}:issues.append('EN13001 A/B/C design-action group coverage is incomplete.')
    if not isclose(op.static_design_force_N,maxd,rel_tol=1e-12,abs_tol=1e-9):raise ValueError('Static maximum differs from generated case maximum')
    if not isclose(op.maximum_unfactored_force_N,max0,rel_tol=1e-12,abs_tol=1e-9):raise ValueError('Hardness-depth maximum differs from nonfactored DESIGN case maximum')
    for item in r.unresolved_mechanisms:_text(item,'unresolved mechanism');issues.append(item)
    return issues


def evaluate_qualified_contact(wheel,flange,g,op,*,surface,action_receipt=None):
    raw=evaluate(wheel,flange,g,op)
    geometry=flat_surface_eligibility(g,surface)
    issues=_action_issues(op,action_receipt)
    physical_issues=[]
    if flange.verified_depth_mm>g.flange_thickness_mm:physical_issues.append('Verified material depth exceeds actual flange thickness.')
    for name in ('wheel','flange'):
        if not raw[name]['hardness_depth_exceeds_max_shear']:physical_issues.append(name+' hardness depth does not extend beyond the maximum-shear depth.')
    issues.extend(physical_issues)
    qualified=not issues
    checks=[]
    for name in ('wheel','flange'):
        for mode in ('static','fatigue'):
            ratio=raw[name][mode+'_ratio']
            checks.append(dict(id=name+'_'+mode,utilization=ratio,capacity_N=raw[name][mode+'_limit_N'],
                qualified=qualified,status=('PASS' if ratio<=1 else 'FAIL') if qualified else 'PENDING',diagnostic_exceeds_limit=ratio>1))
    passed=qualified and all(c['status']=='PASS' for c in checks)
    # A valid subset is useful without pretending omitted actions are covered.
    # Keep known subset failures visible beside the full-coverage pending state.
    covered=action_receipt is not None and not physical_issues
    subset=[dict(c,qualified=covered,status=('PASS' if c['utilization']<=1 else 'FAIL') if covered else 'PENDING',
        scope='Only internally generated action/contact-count domain in the receipt; additional applicable actions may remain pending') for c in checks]
    return dict(status=('CONTACT_PASS' if passed else 'CONTACT_FAIL') if qualified else 'CONTACT_PENDING',
        contact_method_qualified=qualified,contact_cleared=passed,checks=checks,pending=issues,
        covered_action_checks=subset,covered_action_domain_qualified=covered,
        covered_action_domain_passed=covered and all(c['status']=='PASS' for c in subset),
        surface=geometry,arithmetic={k:v for k,v in raw.items() if k not in ('status','contact_cleared','unresolved')},source=SOURCE,
        whole_beam_qualified=False,nominal_flange_qualified=False,structural_fatigue_qualified=False,
        suspension_qualified=False,physical_performance_guaranteed=False,
        limitations=['Separate adopted EN13001 contact-only method, not native NBR equivalence.',
          'Nominal global/local flange stresses, structural fatigue, bolts and suspension remain separate.',
          'No arbitrary half-space thickness/free-edge cutoff is invented; source geometry, material depth and influence factors apply.',
          'Physical wheel/material/contact count inputs are required; crane capacity alone is not a wheel reaction.'])
