"""Physical-only autonomous contact entry, separate from structural qualification.

No forces, contact histories, Operations, generated action receipts or completion
flags are accepted as physical inputs. The internal source-defined action
producer regenerates those from the bound eight-contact bridge model. Materials
and wheel geometry may differ per actual wheel; no sharing is silently assumed.
"""
from copy import deepcopy
from dataclasses import asdict, dataclass, fields
from hashlib import sha256
from math import isclose
from pathlib import Path
from ..autonomous_workflow.model import checked_text, finite, signature
from ..autonomous_workflow.source_manifest import numerical_source_receipt
from ..section_stress.recovery import bottom_contact
from .autonomous_actions import ContactPhysicalInputs, generate_contact_actions
from .eligibility import FlatRunningSurface, evaluate_qualified_contact
from .en13001_kernel import Geometry, Steel

SCHEMA = 'LRO_AUTONOMOUS_CONTACT_PHYSICAL_V1'
CONTACT_SOURCE_FILES = ('contact/autonomous_adapter.py','contact/autonomous_actions.py',
                        'contact/eligibility.py','contact/en13001_kernel.py')


def contact_source_receipt(*,root=None):
    """Separate used-contact-code receipt; never invalidate unrelated core runs.

    Includes the shared numerical dependency receipt and executable package
    initializers, but not UI, tests, research, reports or unused contact helpers.
    This records source bytes on disk before/after each NEW calculation; it
    cannot retroactively qualify or re-sign an earlier result.
    """
    root=Path(root) if root is not None else Path(__file__).resolve().parents[1]
    paths=set(CONTACT_SOURCE_FILES)
    for directory in (root,root/'contact'):
        initializer=directory/'__init__.py'
        if initializer.is_file():paths.add(str(initializer.relative_to(root)))
    files={name:sha256((root/name).read_bytes()).hexdigest() for name in sorted(paths)}
    payload=dict(manifest_version=1,files=files,shared_numerical_dependency_receipt=numerical_source_receipt(root=root))
    return dict(**payload,fingerprint=signature(payload),
        scope='Separate contact adapter/action/eligibility/resistance code plus shared numerical dependencies; excludes UI/tests/research and unused methods.')


def _attach_source_receipts(result,start):
    end=contact_source_receipt()
    if start['fingerprint']!=end['fingerprint']:
        raise ValueError('Contact calculation source changed during evaluation; result is not qualified and must be recalculated')
    result.update(calculation_source=start,calculation_source_after=end,source_unchanged_during_calculation=True)
    return result


@dataclass(frozen=True)
class ContactOperatingLimits:
    hoist_speed_max_m_s: float
    test_static_ratio: float
    test_dynamic_ratio: float
    risk_coefficient: float
    life_cycles: int
    loaded_travel_legs_per_cycle: int
    empty_travel_legs_per_cycle: int
    travel_distance_per_leg_mm: float
    stationary_load_cycles_per_cycle: int
    operating_domain: str
    hoist_mass_scope: str
    action_model_source: str
    lifetime_operating_limit_source: str
    contact_arrangement_source: str

    def __post_init__(self):
        for key in ('hoist_speed_max_m_s','test_static_ratio','test_dynamic_ratio','risk_coefficient','travel_distance_per_leg_mm'):
            value=finite(getattr(self,key),key)
            if value<0:raise ValueError(key+' cannot be negative')
            object.__setattr__(self,key,value)
        for key in ('life_cycles','loaded_travel_legs_per_cycle','empty_travel_legs_per_cycle','stationary_load_cycles_per_cycle'):
            value=getattr(self,key)
            if type(value) is not int or not 0<=value<=10**12:raise ValueError(key+' must be a bounded nonnegative integer')
        for key in ('operating_domain','hoist_mass_scope','action_model_source','lifetime_operating_limit_source','contact_arrangement_source'):
            checked_text(getattr(self,key),key)


@dataclass(frozen=True)
class FlangeContactMaterial:
    hardness_HBW: float
    hardness_source: str
    verified_depth_mm: float
    material_state: str

    def __post_init__(self):
        for key in ('hardness_HBW','verified_depth_mm'):
            value=finite(getattr(self,key),key)
            if value<=0:raise ValueError(key+' must be positive physical material data')
            object.__setattr__(self,key,value)
        checked_text(self.hardness_source,'Flange hardness/depth source')
        checked_text(self.material_state,'Flange material state')


@dataclass(frozen=True)
class WheelContactPhysical:
    wheel_id: str
    hardness_HBW: float
    hardness_source: str
    verified_depth_mm: float
    E_MPa: float
    material_state: str
    wheel_diameter_mm: float
    wheel_material_width_mm: float
    wheel_corner_radius_mm: float
    crown_radius_mm: float | None
    lateral_min_toward_web_mm: float
    lateral_max_toward_web_mm: float
    tolerance_class: int
    mounting: str
    guide_slack_skew_rad: float
    wear_skew_rad: float
    driven_wheel: bool
    abrasive_environment: bool
    geometry_source: str
    alignment_and_mounting_source: str

    def __post_init__(self):
        for key in ('hardness_HBW','verified_depth_mm','E_MPa','wheel_diameter_mm','wheel_material_width_mm'):
            value=finite(getattr(self,key),key)
            if value<=0:raise ValueError(key+' must be positive physical data')
            object.__setattr__(self,key,value)
        for key in ('wheel_corner_radius_mm','guide_slack_skew_rad','wear_skew_rad'):
            value=finite(getattr(self,key),key)
            if value<0:raise ValueError(key+' must be nonnegative')
            object.__setattr__(self,key,value)
        for key in ('lateral_min_toward_web_mm','lateral_max_toward_web_mm'):
            object.__setattr__(self,key,finite(getattr(self,key),key))
        if not self.lateral_min_toward_web_mm<=0<=self.lateral_max_toward_web_mm:
            raise ValueError('Lateral bounds must include the actual nominal project contact; positive is inward toward the web on either outstand')
        if self.crown_radius_mm is not None:
            value=finite(self.crown_radius_mm,'Explicit crown radius')
            if value<=0:raise ValueError('Positive crown radius or explicit None for cylindrical tread required')
            object.__setattr__(self,'crown_radius_mm',value)
        if type(self.tolerance_class) is not int or self.tolerance_class not in (1,2,3,4):raise ValueError('Explicit tolerance class 1..4 required')
        for key in ('driven_wheel','abrasive_environment'):
            if type(getattr(self,key)) is not bool:raise ValueError('Explicit boolean required: '+key)
        for key in ('wheel_id','hardness_source','material_state','mounting','geometry_source','alignment_and_mounting_source'):
            checked_text(getattr(self,key),key)


@dataclass(frozen=True)
class AutonomousContactPhysicalInputs:
    operating: ContactOperatingLimits
    flange: FlangeContactMaterial
    wheels: tuple[WheelContactPhysical,...]

    def __post_init__(self):
        if not isinstance(self.operating,ContactOperatingLimits) or not isinstance(self.flange,FlangeContactMaterial):
            raise ValueError('Typed physical operation/material inputs required')
        if not isinstance(self.wheels,(tuple,list)) or not self.wheels or any(not isinstance(w,WheelContactPhysical) for w in self.wheels):
            raise ValueError('Explicit typed physical data for each actual wheel required')
        object.__setattr__(self,'wheels',tuple(self.wheels))
        if len({w.wheel_id for w in self.wheels})!=len(self.wheels):raise ValueError('Repeated physical contact wheel identity')

    def to_dict(self):
        return dict(schema=SCHEMA,operating=asdict(self.operating),flange=asdict(self.flange),wheels=[asdict(w) for w in self.wheels])


def _strict_record(cls,data,label):
    if not isinstance(data,dict) or set(data)!={f.name for f in fields(cls)}:
        raise ValueError(label+' must contain exactly its physical fields; no forces, receipt, history or completion controls')
    try:return cls(**data)
    except TypeError as exc:raise ValueError('Malformed '+label) from exc


def physical_from_dict(data):
    """Strict optional project.contact_inputs serialization contract.

    Top-level keys are exactly schema, operating, flange, wheels. Every nested
    dataclass field is required, including explicit None for cylindrical crown.
    """
    if not isinstance(data,dict) or set(data)!={'schema','operating','flange','wheels'} or data['schema']!=SCHEMA:
        raise ValueError('Strict '+SCHEMA+' physical input object required')
    if not isinstance(data['wheels'],list):raise ValueError('Physical wheel records must be a list')
    return AutonomousContactPhysicalInputs(_strict_record(ContactOperatingLimits,data['operating'],'operating limits'),
        _strict_record(FlangeContactMaterial,data['flange'],'flange material'),
        tuple(_strict_record(WheelContactPhysical,w,'physical wheel') for w in data['wheels']))


def _producer_inputs(physical,wheel):
    data=asdict(physical.operating)
    for key in ('wheel_diameter_mm','tolerance_class','mounting','guide_slack_skew_rad','wear_skew_rad','driven_wheel','abrasive_environment'):
        data[key]=getattr(wheel,key)
    return ContactPhysicalInputs(**data).validate()


def _geometry(project,actual,physical):
    section=project.section
    if actual.y_mm==0:raise ValueError('Physical contact must lie on an actual bottom-flange outstand')
    n=section.bottom_width/2-abs(actual.y_mm)
    contact=bottom_contact(section,n,'left' if actual.y_mm<0 else 'right')
    if not all(isclose(getattr(actual,key),contact[key],rel_tol=1e-12,abs_tol=1e-9) for key in ('y_mm','z_mm','omega_mm2')):
        raise ValueError('Physical wheel contact/sectorial coordinates differ from the actual lower running flange')
    clear=(section.bottom_width-section.tw_mm)/2-section.bottom_root_radius_mm
    tread=physical.wheel_material_width_mm-2*physical.wheel_corner_radius_mm
    free=n+physical.lateral_min_toward_web_mm-tread/2
    root=clear-n-physical.lateral_max_toward_web_mm-tread/2
    if physical.verified_depth_mm>physical.wheel_diameter_mm/2:
        raise ValueError('Wheel verified radial material depth exceeds the physical wheel radius')
    geometry=Geometry(physical.wheel_diameter_mm,physical.wheel_material_width_mm,physical.wheel_corner_radius_mm,
        clear,0.,section.bottom_thickness,free,root,physical.crown_radius_mm)
    surface=FlatRunningSurface(section,n,physical.lateral_min_toward_web_mm,physical.lateral_max_toward_web_mm,
        physical.geometry_source,physical.alignment_and_mounting_source)
    return geometry,surface


def _base_result(status,pending):
    return dict(status=status,rows=[],contact_only=True,known_covered_domain_failure=False,covered_action_domain_passed=False,
        contact_cleared=False,complete_A_B_C_domain=False,external_efforts_required=False,
        whole_beam_qualified=False,nominal_flange_qualified=False,structural_fatigue_qualified=False,
        suspension_qualified=False,physical_performance_guaranteed=False,design_approval=False,pending=pending)


def evaluate_autonomous_contact(project,physical=None):
    """One physical-only entry. Explicit physical input takes precedence.

    Without an explicit argument, reads optional project.contact_inputs. Missing
    material data remain INPUT_REQUIRED; they are never inferred from fy or a
    catalogue crane capacity. Invalid/stale project action ledgers fail closed.
    Valid covered-domain FAIL checks survive other per-wheel pending scopes.
    """
    source_start=contact_source_receipt()
    project.validate()
    if physical is None:physical=getattr(project,'contact_inputs',None)
    if physical is None:
        return _attach_source_receipts(_base_result('CONTACT_INPUT_REQUIRED',[dict(code='physical_contact_inputs',reason='Actual per-wheel material/hardness/depth/geometry/mounting and physical lifetime operating limits are required.')]),source_start)
    if isinstance(physical,dict):physical=physical_from_dict(physical)
    if not isinstance(physical,AutonomousContactPhysicalInputs):raise ValueError('Typed physical contact inputs or their strict serialization required')
    actual={w.id:w for w in project.wheels}
    if len(actual)!=len(project.wheels):raise ValueError('Duplicate actual project wheel identity')
    if {w.wheel_id for w in physical.wheels}!=set(actual):
        raise ValueError('Physical contact inputs must match every exact current project wheel ID, without omissions, aliases or extra wheels')
    fingerprint=signature(project.to_dict())
    result=_base_result('CONTACT_PENDING',[])
    result.update(physical_inputs=physical.to_dict(),physical_input_signature=signature(physical.to_dict()),
        project_input_signature=fingerprint,source='Internal EN13001 normal/test contact action producer + qualified flat-running-surface wrapper; separate contact-only method',
        input_policy='Physical inputs only. Operations, forces, contact histories and action receipts are generated internally.',
        scope='Selected physical bridge hook/height/rail configuration; all its individual wheels; not a universal operating-domain configuration envelope.')
    flange=Steel(physical.flange.hardness_HBW,physical.flange.hardness_source,physical.flange.verified_depth_mm,
                 project.E_mpa,physical.flange.material_state)
    cache={};producer_receipts={}
    for wheel in physical.wheels:
        row=dict(wheel_id=wheel.wheel_id,status='CONTACT_PENDING',contact_only=True,checks=[],covered_action_checks=[],
                 physical_wheel=asdict(wheel),known_covered_domain_failure=False,pending=[])
        try:
            inputs=_producer_inputs(physical,wheel)
            key=signature(asdict(inputs))
            if key not in cache:
                try:cache[key]=(generate_contact_actions(project,inputs),None)
                except ValueError as exc:cache[key]=(None,str(exc))
            generated,error=cache[key]
            if error is not None:raise ValueError('Internal action/contact-count generation: '+error)
            # Retain the valid source action ledger even if this wheel's material
            # or footprint is outside the subsequent physical contact domain.
            producer_receipts[key]={k:deepcopy(v) for k,v in generated.items() if k!='rows'}
            matches=[item for item in generated['rows'] if item['configuration_id']+'/'+item['wheel_id']==wheel.wheel_id]
            if len(matches)!=1:raise ValueError('Generated contact operation does not match the exact selected physical wheel identity')
            item=matches[0];operation=item['operation'];receipt=item['action_receipt']
            row.update(configuration_id=item['configuration_id'],operation=asdict(operation),
                action_receipt=asdict(receipt),counts=deepcopy(item['counts']),
                internal_producer_input_signature=generated['input_signature'])
            geometry,surface=_geometry(project,actual[wheel.wheel_id],wheel)
            material=Steel(wheel.hardness_HBW,wheel.hardness_source,wheel.verified_depth_mm,wheel.E_MPa,wheel.material_state)
            checked=evaluate_qualified_contact(material,flange,geometry,operation,surface=surface,action_receipt=receipt)
            row.update(checked,geometry=asdict(geometry))
            row['known_covered_domain_failure']=any(c['status']=='FAIL' for c in row['covered_action_checks'])
        except ValueError as exc:
            row['pending']=[str(exc)]
            row['covered_action_domain_qualified']=False;row['covered_action_domain_passed']=False
        result['rows'].append(row)
        for reason in row['pending']:
            result['pending'].append(dict(code='wheel_contact_scope',wheel_id=wheel.wheel_id,reason=reason))
        result['known_covered_domain_failure']|=row['known_covered_domain_failure']
    if signature(project.to_dict())!=fingerprint:raise ValueError('Project changed during autonomous contact generation')
    result['producer_receipts']=list(producer_receipts.values())
    result['internal_producer_evaluations']=len(cache)
    result['covered_action_domain_passed']=all(r.get('covered_action_domain_passed',False) for r in result['rows'])
    result['contact_cleared']=all(r.get('contact_cleared',False) for r in result['rows'])
    result['complete_A_B_C_domain']=bool(producer_receipts) and all(r['complete_A_B_C_domain'] for r in producer_receipts.values())
    if result['known_covered_domain_failure']:result['status']='CONTACT_COVERED_DOMAIN_FAIL_WITH_PENDING' if result['pending'] else 'CONTACT_FAIL'
    elif result['contact_cleared']:result['status']='CONTACT_PASS'
    return _attach_source_receipts(result,source_start)
