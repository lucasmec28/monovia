"""Isolated DOUBLY SYMMETRIC prismatic 7-DOF elastic beam, N/mm/rad.
Centroid MUST equal shear centre; unequal-flange/monosymmetric I is unsupported.
The caller must verify geometry eligibility; stiffness values cannot prove it.
No strength, stability, contact, bolt allocation or implicit restraint assumptions.
"""
import math
import numpy as np
from scipy.linalg import null_space, cho_factor, cho_solve

DOFS=('u','v','w','phi','theta_y','theta_z','chi')
LOADS=('Fx','Fy','Fz','Mx','My','Mz','B')

# Exact, process-local caches. Values and keys contain only immutable scalars,
# tuples and bytes; no mutable ndarray is retained or returned by a cache.
# Both entry count and byte payload are bounded. These caches are optional
# accelerators, not model/solution state, and must not be persisted by codecs.
from collections import OrderedDict
from threading import RLock

def _array_identity(value):
    value = np.asarray(value)
    if value.dtype.hasobject:
        raise TypeError('object arrays are not cacheable')
    return (value.dtype.str, value.shape, value.tobytes(order='C'))

def _input_identity(value):
    if any(mode in ('call', 'log') for mode in np.geterr().values()):
        # External handlers need original interleaved execution, not a probe.
        raise TypeError('external FP handlers bypass caches')
    # Do not conflate ndarray subclasses/custom arithmetic or memory layouts.
    if type(value) is not np.ndarray:
        raise TypeError('custom array inputs are not cacheable')
    return (_array_identity(value), value.strides)

def _array_from_identity(value):
    dtype, shape, payload = value
    return np.frombuffer(payload, dtype=np.dtype(dtype)).reshape(shape)

def _immutable_cache(max_entries, max_bytes):
    entries = OrderedDict()
    lock = RLock()
    size = 0
    def payload_size(value):
        if isinstance(value, bytes): return len(value)
        if isinstance(value, tuple): return sum(payload_size(v) for v in value)
        return 0
    def get(key, compute):
        nonlocal size
        if key in entries:
            value, cost = entries.pop(key)
            entries[key] = (value, cost)
            return value
        value = compute()  # Exceptions never populate the cache.
        cost = payload_size(key) + payload_size(value)
        if cost <= max_bytes:
            while entries and (len(entries) >= max_entries or size + cost > max_bytes):
                _, (_, old_cost) = entries.popitem(last=False)
                size -= old_cost
            entries[key] = (value, cost)
            size += cost
        return value
    def locked_get(key, compute):
        with lock:
            return get(key, compute)
    return locked_get

_xp_cache = _immutable_cache(16, 2 * 1024 * 1024)
_udl_cache = _immutable_cache(32, 2 * 1024 * 1024)
_quadrature_cache = _immutable_cache(1, 1024)

def _event_free(compute):
    # These probes use only ordinary ndarrays and finite normalized scalars.
    # No external callback can run: all NumPy FP events raise instead. An event
    # rejects caching; the caller then executes original arithmetic/policy.
    with np.errstate(all='raise'):
        return compute()

def _gauss3():
    if any(mode in ('call', 'log') for mode in np.geterr().values()):
        return np.polynomial.legendre.leggauss(3)
    try:
        packed = _quadrature_cache(3, lambda: _event_free(lambda: tuple(
            _array_identity(a) for a in np.polynomial.legendre.leggauss(3))))
    except FloatingPointError:
        return np.polynomial.legendre.leggauss(3)
    return tuple(_array_from_identity(a) for a in packed)

def _udl_elements(nodes, q, gauss, weights):
    for i, (a, b) in enumerate(zip(nodes[:-1], nodes[1:])):
        lo = max(a, q['start']); hi = min(b, q['end'])
        if hi <= lo: continue
        f = np.zeros(14)
        for t, wt in zip(gauss, weights):
            f += interpolation(lo+(t+1)*(hi-lo)/2,a,b).T@np.array([q['qx'],q['qy'],q['qz'],q['mx'],0,0,0])*wt*(hi-lo)/2
        yield (i, _array_identity(f))


def number(x, name):
    if isinstance(x,(bool,np.bool_)) or not isinstance(x,(int,float,np.number)) or not math.isfinite(x):
        raise ValueError(name+' must be finite real')
    return float(x)

def hermite(t,h,order=0):
    co=np.array([[1,0,-3,2],[0,h,-2*h,h],[0,0,3,-2],[0,0,-h,h]],float)
    for _ in range(order): co=co[:,1:]*np.arange(1,co.shape[1])
    return co@np.array([t**i for i in range(co.shape[1])])/h**order

def interpolation(x,a,b,order=0):
    h=b-a;t=(x-a)/h; H=hermite(t,h,order); A=np.zeros((7,14))
    if order==0:A[0,[0,7]]=[1-t,t]
    if order==1:A[0,[0,7]]=[-1/h,1/h]
    A[1,[1,5,8,12]]=H
    A[2,[2,4,9,11]]=H*np.array([1,-1,1,-1])
    A[3,[3,6,10,13]]=H
    # Rotations and warping rate follow the displacement fields.
    H1=hermite(t,h,order+1) if order<3 else np.zeros(4)
    A[4,[2,4,9,11]]=-H1*np.array([1,-1,1,-1])
    A[5,[1,5,8,12]]=H1
    A[6,[3,6,10,13]]=H1
    return A

class FrameModel:
    def __init__(self,length,section,supports,max_element_length=None):
        self.length=number(length,'length')
        if self.length<=0:raise ValueError('length must be positive')
        self.section={k:number(section[k],k) for k in ('EA','EIy','EIz','GJ','ECw')}
        if min(self.section.values())<=0:raise ValueError('all stiffnesses must be positive')
        self.supports=tuple(dict(s) for s in supports)
        hmax=number(max_element_length if max_element_length is not None else length/20,'max_element_length')
        if hmax<=0:raise ValueError('max_element_length must be positive')
        breaks={0.,self.length}
        for s in self.supports:breaks.add(self.station(s['x']))
        breaks=sorted(breaks);nodes=[]
        for a,b in zip(breaks[:-1],breaks[1:]):
            count=math.ceil((b-a)/hmax)
            if count+len(nodes)>300:raise ValueError('dense candidate limited to 300 elements')
            nodes.extend(np.linspace(a,b,count+1)[:-1])
        self.nodes=np.array(nodes+[self.length]); n=7*len(self.nodes)
        if np.min(np.diff(self.nodes))<self.length*1e-12:raise ValueError('support stations too close; no merging permitted')
        self.K=np.zeros((n,n));self.element_k=[]
        g,weights=np.polynomial.legendre.leggauss(3)
        for i,(a,b) in enumerate(zip(self.nodes[:-1],self.nodes[1:])):
            k=np.zeros((14,14))
            for t,wt in zip(g,weights):
                x=a+(t+1)*(b-a)/2; D=interpolation(x,a,b,1); D2=interpolation(x,a,b,2)
                for stiff,row in [(self.section['EA'],D[0]),(self.section['EIy'],D2[2]),(self.section['EIz'],D2[1]),(self.section['GJ'],D[3]),(self.section['ECw'],D2[3])]:k+=stiff*np.outer(row,row)*wt*(b-a)/2
            ids=slice(7*i,7*i+14);self.K[ids,ids]+=k;self.element_k.append(k)
        rows=[];self.constraint_metadata=[];values=[]
        for si,s in enumerate(self.supports):
            i=int(np.where(self.nodes==s['x'])[0][0]); y=number(s.get('y',0),'support y');z=number(s.get('z',0),'support z');om=number(s.get('omega',0),'omega')
            r=s.get('restrain',[])
            if not r:raise ValueError('support must explicitly restrain one or more components')
            for key in r:
                row=np.zeros(n)
                if key=='ux':row[7*i:7*i+7]=[1,0,0,0,z,-y,-om]
                elif key=='uy':row[7*i:7*i+7]=[0,1,0,-z,0,0,0]
                elif key=='uz':row[7*i:7*i+7]=[0,0,1,y,0,0,0]
                elif key in DOFS[3:]:row[7*i+DOFS.index(key)]=1
                else:raise ValueError('unknown restraint '+str(key))
                rows.append(row);values.append(number(r[key] if isinstance(r,dict) else 0,'prescribed displacement'));self.constraint_metadata.append((si,key))
        if not rows:raise ValueError('rigid mechanism: no restraints')
        self.C=np.array(rows);self.prescribed=np.array(values)
        # Scale unknowns and constraint rows before rank/positive-energy tests.
        self.scale=1/np.sqrt(np.diag(self.K)); Cs=self.C*self.scale
        self.cscale=1/np.linalg.norm(Cs,axis=1);Cs=Cs*self.cscale[:,None]
        if np.linalg.matrix_rank(Cs,tol=1e-11)<len(rows):raise ValueError('dependent constraints: unique support reaction allocation unavailable')
        self.Cs=Cs;self.Z=null_space(Cs,rcond=1e-11)
        Ks=self.K*self.scale[:,None]*self.scale[None,:]
        A=self.Z.T@Ks@self.Z
        if len(A):
            eig=np.linalg.eigvalsh(A)
            if eig[0]<=max(eig[-1],1)*1e-12:raise ValueError('rigid mechanism or unsafe conditioning; no regularization applied')
            self.factor=cho_factor(A)
        self.Ks=Ks

    def station(self,x):
        x=number(x,'station')
        if not 0<=x<=self.length:raise ValueError('station outside beam')
        return x

    def element(self,x,side='right'):
        return max(0,min(len(self.nodes)-2,int(np.searchsorted(self.nodes,x,side=side)-1)))

    def solve(self,point_loads=(),distributed_loads=()):
        pts=[];udls=[];F=np.zeros(len(self.K));ef=[np.zeros(14) for _ in self.element_k]
        for p in point_loads:
            p=dict(p);p['x']=self.station(p['x'])
            for k in LOADS:p[k]=number(p.get(k,0),k)
            pts.append(p);i=self.element(p['x']);a,b=self.nodes[i:i+2];f=interpolation(p['x'],a,b).T@np.array([p[k] for k in LOADS]);ef[i]+=f;F[7*i:7*i+14]+=f
        gauss,weights=_gauss3()
        for q in distributed_loads:
            q=dict(q);q['start']=self.station(q.get('start',0));q['end']=self.station(q.get('end',self.length))
            if q['end']<=q['start']:raise ValueError('UDL start must precede end')
            for k in ('qx','qy','qz','mx'):q[k]=number(q.get(k,0),k)
            udls.append(q)
            # Validation and metadata collection above run even on cache hits.
            # Cache per-UDL element vectors, NOT a pre-summed global force.
            # The original point / q / element / scatter order is unchanged.
            try:
                key=(_input_identity(self.nodes),tuple(q[k].hex() for k in ('start','end','qx','qy','qz','mx')))
            except TypeError:
                contributions=_udl_elements(self.nodes,q,gauss,weights)
            else:
                try:
                    contributions=_udl_cache(key,lambda: _event_free(lambda: tuple(_udl_elements(self.nodes,q,gauss,weights))))
                except FloatingPointError:
                    # Generator fallback preserves f / scatter / next-element order,
                    # including callbacks, warnings and exceptions under caller policy.
                    contributions=_udl_elements(self.nodes,q,gauss,weights)
            for i,packed in contributions:
                f=_array_from_identity(packed)
                ef[i]+=f;F[7*i:7*i+14]+=f
        def particular():
            return _array_identity(np.linalg.lstsq(self.Cs,self.prescribed*self.cscale,rcond=None)[0])
        try:
            key=tuple(_input_identity(v) for v in (self.nodes,self.Cs,self.prescribed,self.cscale))
        except TypeError:
            xp=np.linalg.lstsq(self.Cs,self.prescribed*self.cscale,rcond=None)[0]
        else:
            try:
                xp=_array_from_identity(_xp_cache(key,lambda: _event_free(particular)))
            except FloatingPointError:
                xp=np.linalg.lstsq(self.Cs,self.prescribed*self.cscale,rcond=None)[0]
        xs=xp.copy()
        if self.Z.shape[1]:xs+=self.Z@cho_solve(self.factor,self.Z.T@(F*self.scale-self.Ks@xp))
        u=xs*self.scale;res=self.K@u-F
        lam=np.linalg.lstsq(self.Cs.T,res*self.scale,rcond=None)[0]*self.cscale
        err=res-self.C.T@lam
        relative=np.linalg.norm(err,np.inf)/max(1,np.linalg.norm(F,np.inf),np.linalg.norm(self.K,np.inf)*np.linalg.norm(u,np.inf))
        if not np.isfinite(u).all() or relative>1e-9:raise ValueError('equilibrium solve residual unacceptable')
        return Solution(self,u,pts,udls,ef,lam,relative)

class Solution:
    def __init__(self,model,u,points,udls,element_f,reaction_values,residual):
        self.model=model;self.dofs=u.reshape((-1,7));self.points=points;self.udls=udls;self.element_f=element_f
        self.reactions=[dict(support_index=si,component=key,value=float(v),x=model.supports[si]['x']) for (si,key),v in zip(model.constraint_metadata,reaction_values)]
        self.support_reactions=[]
        for si,support in enumerate(model.supports):
            wrench=np.zeros(7)
            for j,(owner,key) in enumerate(model.constraint_metadata):
                if owner==si:
                    inode=int(np.where(model.nodes==support['x'])[0][0])
                    wrench+=model.C[j,7*inode:7*inode+7]*reaction_values[j]
            self.support_reactions.append(dict(support_index=si,x=support['x'],**dict(zip(LOADS,map(float,wrench)))))
        physical=model.C.T@reaction_values; total=np.zeros(6)
        for i,x in enumerate(model.nodes):
            f=physical[7*i:7*i+7];total[:3]+=f[:3];total[3:]+=f[3:6]+np.cross([x,0,0],f[:3])
        for p in points:total[:3]+=np.array([p['Fx'],p['Fy'],p['Fz']]);total[3:]+=np.array([p['Mx'],p['My'],p['Mz']])+np.cross([p['x'],0,0],[p['Fx'],p['Fy'],p['Fz']])
        for q in udls:
            h=q['end']-q['start'];f=np.array([q['qx'],q['qy'],q['qz']])*h;total[:3]+=f;total[3:]+=np.array([q['mx']*h,0,0])+np.cross([(q['start']+q['end'])/2,0,0],f)
        force_scale=max(1.,sum(np.linalg.norm(physical[7*i:7*i+3]) for i in range(len(model.nodes))),sum(np.linalg.norm([p['Fx'],p['Fy'],p['Fz']]) for p in points)+sum(np.linalg.norm([q['qx'],q['qy'],q['qz']])*(q['end']-q['start']) for q in udls))
        moment_scale=max(1.,model.length*force_scale,sum(np.linalg.norm(physical[7*i+3:7*i+6]) for i in range(len(model.nodes))),sum(np.linalg.norm([p['Mx'],p['My'],p['Mz']]) for p in points)+sum(abs(q['mx'])*(q['end']-q['start']) for q in udls))
        balance_relative=max(np.linalg.norm(total[:3],np.inf)/force_scale,np.linalg.norm(total[3:],np.inf)/moment_scale)
        if not math.isfinite(balance_relative) or balance_relative>1e-6:raise ValueError('global physical force/moment equilibrium unacceptable')
        self.diagnostics=dict(relative_residual=residual,physical_equilibrium_relative=float(balance_relative),physical_equilibrium_N_Nmm=total.tolist(),constraint_error=float(np.max(np.abs(model.C@u-model.prescribed))),reaction_work=float(reaction_values@model.prescribed),strain_energy=float(u@model.K@u/2),torsion='cubic Hermite approximation; mesh convergence required',mesh_reusable=True,section_scope='doubly symmetric open-I; centroid equals shear centre; caller must verify geometry')

    def at(self,x,side='right'):
        m=self.model;x=m.station(x)
        if side not in ('left','right'):raise ValueError('side must be left or right')
        i=m.element(x,side);a,b=m.nodes[i:i+2];h=b-a;u=self.dofs[i:i+2].ravel();d=interpolation(x,a,b)@u
        # Exact bubble corrections: integrated loads minus their Hermite endpoint interpolant.
        deriv=[interpolation(x,a,b,k)@u for k in range(4)]
        for field,stiff,force,couple in [(1,m.section['EIz'],'Fy','Mz'),(2,m.section['EIy'],'Fz','My')]:
            def particular(xx,k):
                val=0.
                for p in self.points:
                    if not a<p['x']<b:continue
                    if xx<p['x'] or (xx==p['x'] and side=='left'):continue
                    z=xx-p['x'];c=p[couple]*(1 if field==1 else -1)
                    if k<=3:val+=p[force]*z**(3-k)/math.factorial(3-k)
                    if k<=2:val-=c*z**(2-k)/math.factorial(2-k)
                for q in self.udls:
                    lo=max(a,q['start']);hi=min(b,q['end'])
                    if hi>lo:val+=q['qy' if field==1 else 'qz']*(max(xx-lo,0)**(4-k)-max(xx-hi,0)**(4-k))/math.factorial(4-k)
                return val/stiff
            ends=np.array([0,0,particular(b,0),particular(b,1)])
            for k in range(4):deriv[k][field]+=particular(x,k)-hermite((x-a)/h,h,k)@ends
        # Axial exact bubble, including clipped segment loading.
        def axial(xx,k):
            value=0.
            for p in self.points:
                if a<p['x']<b and (xx>p['x'] or (xx==p['x'] and side=='right')):value-=p['Fx']*((xx-p['x']) if k==0 else 1)
            for q in self.udls:
                lo=max(a,q['start']);hi=min(b,q['end'])
                if hi>lo:value-=q['qx']*(max(xx-lo,0)**(2-k)-max(xx-hi,0)**(2-k))/math.factorial(2-k)
            return value/m.section['EA']
        deriv[0][0]+=axial(x,0)-(x-a)/h*axial(b,0);deriv[1][0]+=axial(x,1)-axial(b,0)/h
        d[:4]=deriv[0][:4];d[4]=-deriv[1][2];d[5]=deriv[1][1];d[6]=deriv[1][3]
        result=dict(zip(DOFS,map(float,d)));result.update(x=x,side=side,N=float(m.section['EA']*deriv[1][0]),Fy=float(-m.section['EIz']*deriv[3][1]),Fz=float(-m.section['EIy']*deriv[3][2]),My=float(-m.section['EIy']*deriv[2][2]),Mz=float(m.section['EIz']*deriv[2][1]),B=float(-m.section['ECw']*deriv[2][3]),Tsv=float(m.section['GJ']*deriv[1][3]),Tw=float(-m.section['ECw']*deriv[3][3]))
        result['T']=result['Tsv']+result['Tw']
        end_force=m.element_k[i]@u-self.element_f[i]
        dx=x-a;Te=-end_force[3];Be=end_force[6]+Te*dx-m.section['GJ']*(d[3]-u[3])
        for p in self.points:
            if m.element(p['x'])!=i:continue
            interior_side='right' if x==0 else ('left' if x==m.length else side)
            active=p['x']<x or (p['x']==x and interior_side=='right')
            if active:
                Te-=p['Mx'];Be-=p['Mx']*(x-p['x']);Be+=p['B']
        for q in self.udls:
            lo=max(a,q['start']);hi=min(b,q['end'])
            if hi>lo:
                Te-=q['mx']*(max(x-lo,0)-max(x-hi,0))
                Be-=q['mx']*(max(x-lo,0)**2-max(x-hi,0)**2)/2
        result.update(T_equilibrated=float(Te),B_equilibrated=float(Be),Tw_equilibrated=float(Te-result['Tsv']))
        return result
