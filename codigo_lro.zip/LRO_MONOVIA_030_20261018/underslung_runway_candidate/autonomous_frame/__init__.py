from .solver import FrameModel, Solution
