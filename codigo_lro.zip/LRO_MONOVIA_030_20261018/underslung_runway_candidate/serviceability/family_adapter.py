"""Native NBR 10084 all-configuration sufficient service bounds.

The force-family receipt establishes geometry and reusable physical RHS bases,
NOT displacement convergence.  This module independently verifies cubic-in-
translation *same-state contact-line end-chord increments* and refines their
spatial grid and FE mesh.  A family box has no fabricated concurrent governor;
an exceeded sufficient bound is INCONCLUSIVE, never a witnessed failure.

Only declared normal no-wind gravity/inertia mechanisms are covered.  The
source's case-II wind, other case-I mechanisms, paired-runway differential and
supporting-building service criteria remain separate.  Finite-grid engineering
convergence is not a continuum or rigorous floating-point enclosure.
"""
from copy import deepcopy
from collections import OrderedDict
from dataclasses import asdict
from fractions import Fraction
from hashlib import sha256
from pathlib import Path
import math
import time

import numpy as np
from numpy.polynomial import chebyshev as cheb

from ..autonomous_frame.solver import FrameModel
from ..autonomous_workflow.model import PhysicalWheel, physical_train_at, signature, wheel_force_components
from ..autonomous_workflow.family_envelope import interval_product, interval_sum, assess_sufficient_limit
from ..autonomous_workflow.inertia_bridge_adapter import make_ledger, physical_case_contact_audit
from ..stability.family_adapter import validate_family_receipt
from ..global_response.moving_point_bounds import _FixedModelStateCache
from ..global_response.numerical_producer import _independent_wrench
from .nbr10084_adapter import (_check_inputs, _incremental_project, _operator_receipt,
                              generate_nbr10084_service_cases, NBR10084ServicePhysicalInputs)
from .nbr10084_criteria import SOURCE, SOURCE_SHA256, ACTION_BASIS, BASELINE

VERIFIED = 'fixed_FE_NBR10084_family_chord_bounds_verified'
PENDING = 'NBR10084_family_chord_bounds_not_established'
DIRECTIONS = ('vertical', 'horizontal')
ABS_MM = 1.e-8


def _require(ok, message):
    if not ok:
        raise ValueError(message)


def _number(value, name):
    _require(type(value) in (int, float) and math.isfinite(value), name+' must be a finite real number')
    return float(value)


def _source():
    from ..autonomous_workflow.family_envelope import _source as family_source
    root = Path(__file__).resolve().parents[1]
    paths = ('serviceability/__init__.py', 'serviceability/family_adapter.py',
             'serviceability/nbr10084_adapter.py', 'serviceability/nbr10084_criteria.py',
             'serviceability/criteria.py', 'stability/family_adapter.py')
    return dict(family_source=family_source(), files={p: sha256((root/p).read_bytes()).hexdigest() for p in paths})


def _spans(project):
    xs = sorted({float(s['x']) for s in project.supports})
    _require(len(xs) >= 2 and xs[0] == 0. and xs[-1] == project.length_mm,
             'This service route requires actual support-to-support spans over the complete member; overhangs are not omitted')
    return [dict(index=i, start_mm=a, end_mm=b) for i, (a, b) in enumerate(zip(xs[:-1], xs[1:]))]


def _service_plan(project, physical, force_plan):
    """Regenerate source cases for each physical configuration, using old bases."""
    _check_inputs(project, physical)
    members, ledgers = [], {}
    bases = force_plan['bases']
    for configuration in force_plan['configurations']:
        p = deepcopy(project)
        p.bridge_reaction_ledger = make_ledger(p.section, project.bridge_reaction_ledger['inputs'], configuration['id'])
        p.wheels = [PhysicalWheel(**w) for w in p.bridge_reaction_ledger['selected_configuration']['wheels']]
        cases, vertical, horizontal = generate_nbr10084_service_cases(p, physical)
        ledgers[configuration['id']] = dict(vertical=vertical, horizontal=horizontal)
        wheels = force_plan['wheels_by_configuration'][configuration['id']]
        for case in cases:
            audit = physical_case_contact_audit(p.bridge_reaction_ledger, case)
            _require(audit['no_hold_down_contact_valid'], 'A required native service state has uplift; no physical member may be omitted')
            raw = {'selfweight': 0.}
            if project.extra_dead_N_per_mm:
                raw['accessory_dead'] = case.extra_dead
            for station in (0, 1):
                pair = [wheel_force_components(wheels[station*2+j], case) for j in (0, 1)]
                _require(pair[0] == pair[1], 'Opposed service contact actions are not equal')
                raw.update({f'station{station}/{key}': value for key, value in
                            zip(('Fx', 'Fy', 'downward_Fz'), (*pair[0][:2], -pair[0][2]))})
            coefficients = {}
            for b in bases:
                value = raw[b.id]
                _require(b.amplitude != 0. or value == 0., 'Service action cannot be represented by a zero force-family basis')
                c = value/b.amplitude if b.amplitude else 0.
                _require(math.isfinite(c) and c*b.amplitude == value,
                         'Service action coefficient must reconstruct the physical force exactly')
                coefficients[b.id] = c
            members.append(dict(configuration_id=configuration['id'], case_id=case.id,
                case=asdict(case), coefficients=coefficients, physical_contact_valid=True,
                physical_contact_receipt_signature=signature(audit)))
    lines = sorted({(w.y_mm, w.z_mm) for w in force_plan['bases'][0].wheels})
    return dict(members=members, action_ledgers=ledgers, contact_lines=[dict(y_mm=y, z_mm=z) for y, z in lines],
                active_basis_ids=[b.id for b in bases if any(m['coefficients'][b.id] != 0. for m in members)],
                configuration_ids=[c['id'] for c in force_plan['configurations']])


def _contact(state, line, direction):
    return state['w']+line['y_mm']*state['phi'] if direction == 'vertical' else state['v']-line['z_mm']*state['phi']


def chord_relative(solution, x, span, line, direction):
    """Actual same-solution contact-line displacement minus its endpoint chord."""
    a, b = span['start_mm'], span['end_mm']
    _require(a <= x <= b, 'Chord observation lies outside its actual support span')
    t = (x-a)/(b-a)
    at = lambda xx: solution.at(xx, 'left' if xx == solution.model.length else 'right')
    return _contact(at(x), line, direction)-(1-t)*_contact(at(a), line, direction)-t*_contact(at(b), line, direction)


class _ChordStates:
    """One checked model, bounded solved-state reuse; no external demand input."""
    def __init__(self, model, basis, project):
        _require(type(model) is FrameModel, 'Exact fixed linear FrameModel required')
        self.model, self.basis = model, basis
        self.cache = _FixedModelStateCache(model)
        self.cache.validate_model(model)
        qz = -(project.selfweight()*basis.case.support_dead+project.extra_dead_N_per_mm*basis.case.extra_dead)
        mx = -project.extra_dead_N_per_mm*basis.case.extra_dead*(project.extra_dead_y_mm or 0.)
        self.udls = [dict(start=0., end=model.length, qz=qz, mx=mx)] if qz or mx else []
        self.wrenches = [(Fraction(w.offset_mm), _independent_wrench(w, basis.case)) for w in basis.wheels]
        self.endpoint_cache = OrderedDict()

    def values(self, t, limit, x, span, lines):
        L = Fraction(float(self.model.length)); points = []
        for offset, wrench in self.wrenches:
            xx = t+offset
            active = 0 <= xx <= L if limit == 'exact' else (0 < xx <= L if limit == 'left' else 0 <= xx < L)
            if active:
                points.append(dict(x=float(xx), **wrench))
        def at(xx):
            key = (t, limit, xx)
            if xx in (span['start_mm'], span['end_mm']) and key in self.endpoint_cache:
                return self.endpoint_cache[key]
            state = self.cache.response_at(self.model, points, self.udls, xx,
                'left' if xx == self.model.length else 'right', exact_translation=t, translation_limit=limit)
            if xx in (span['start_mm'], span['end_mm']):
                self.endpoint_cache[key] = {k: state[k] for k in ('v', 'w', 'phi')}
                while len(self.endpoint_cache) > 2048:
                    self.endpoint_cache.popitem(last=False)
            return state
        a, b = span['start_mm'], span['end_mm']; ratio = (x-a)/(b-a)
        mid, left, right = at(x), at(a), at(b)
        return {f'{i}/{direction}': _contact(mid, line, direction)-(1-ratio)*_contact(left, line, direction)-ratio*_contact(right, line, direction)
                for i, line in enumerate(lines) for direction in DIRECTIONS}


def _point_extrema(states, x, span, lines, lo, hi, *, polynomial_rtol, max_intervals):
    """Verify all exact events and each cubic chord projection independently.

    Constant point-load nodal RHS is cubic in translation between FE nodes;
    exact bending bubbles add only cubic terms between observation crossings.
    A fixed contact/chord projection is linear, hence retains this degree.
    No component or endpoint envelope is subtracted from another envelope.
    """
    nodes = {Fraction(float(v)) for v in states.model.nodes} | {Fraction(x)}
    events = {lo, hi}
    for offset, _ in states.wrenches:
        events.update(v-offset for v in nodes if lo <= v-offset <= hi)
    events = sorted(events)
    _require(len(events)-1 <= max_intervals, 'Service polynomial interval budget exceeded; nothing was dropped')
    _require(len({float(t) for t in events}) == len(events), 'Exact service events alias in floating point')
    fields = [f'{i}/{d}' for i in range(len(lines)) for d in DIRECTIONS]
    bounds = {k: dict(lower=math.inf, upper=-math.inf) for k in fields}
    checked, peak_error, coefficient_hashes = 0, 0., []
    def evaluate(t, limit='exact'):
        # A non-event coordinate rounded onto a node/x changes the FE piece.
        for offset, _ in states.wrenches:
            xx = t+offset
            if 0 <= xx <= Fraction(float(states.model.length)):
                _require(not any(xx != b and float(xx) == float(b) for b in nodes),
                         'Non-event service wheel rounds onto a mesh/observation event')
        values = states.values(t, limit, x, span, lines)
        _require(all(math.isfinite(v) for v in values.values()), 'Nonfinite projected service displacement')
        return values
    def retain(values):
        for key, value in values.items():
            bounds[key]['lower'] = min(bounds[key]['lower'], value)
            bounds[key]['upper'] = max(bounds[key]['upper'], value)
    for t in events:
        retain(evaluate(t))
        if t > lo: retain(evaluate(t, 'left'))
        if t < hi: retain(evaluate(t, 'right'))
    zfit = np.sort(np.cos((2*np.arange(4)+1)*math.pi/8))
    for a, b in zip(events[:-1], events[1:]):
        midpoint, half = (a+b)/2, (b-a)/2
        def translation(z):
            t = midpoint+half*Fraction(float(z))
            _require(a < t < b, 'Open service polynomial interval cannot be represented')
            return t
        ts = [translation(z) for z in zfit]
        _require(len({float(t) for t in ts}) == 4, 'Service interval too narrow for independent cubic fit')
        samples = [evaluate(t) for t in ts]
        co = {k: cheb.chebfit(zfit, [row[k] for row in samples], 3) for k in fields}
        coefficient_hashes.append(signature({k: v.tolist() for k, v in co.items()}))
        scales = {k: max(abs(row[k]) for row in samples) for k in fields}
        def verify(z, values):
            nonlocal checked, peak_error
            for key in fields:
                error = abs(float(cheb.chebval(z, co[key]))-values[key])/(ABS_MM+polynomial_rtol*max(scales[key], abs(values[key])))
                _require(math.isfinite(error) and error <= 1., 'Cubic same-state chord verification failed for '+key)
                checked += 1; peak_error = max(peak_error, error)
        for z in (-.8, 0., .8): verify(z, evaluate(translation(z)))
        verify(-1., evaluate(a, 'right')); verify(1., evaluate(b, 'left'))
        for key in fields:
            for root in cheb.chebroots(cheb.chebder(co[key])):
                if abs(float(np.imag(root))) > 1e-9 or not -1 < float(np.real(root)) < 1:
                    continue
                z = float(np.real(root)); values = evaluate(translation(z)); verify(z, values); retain(values)
    return dict(bounds=bounds, interval_count=len(events)-1, event_count=len(events), verification_checks=checked,
                maximum_polynomial_verification_ratio=peak_error,
                exact_event_signature=signature([(str(t.numerator), str(t.denominator)) for t in events]),
                interval_coefficients_signature=signature(coefficient_hashes))


def _delta(current, previous, allowance=ABS_MM):
    _require(set(current) == set(previous), 'Displacement comparison field coverage changed')
    for value in (*current.values(), *previous.values()):
        _number(value, 'Signed displacement comparison')
    return max((max(0., abs(current[k]-previous[k])-allowance)/max(abs(current[k]), abs(previous[k]), 1.e-300)
                for k in current), default=0.)


def _flatten(bounds):
    return {f'{span}/{line}/{direction}/{side}': value for span, rows in enumerate(bounds)
            for line, directions in enumerate(rows) for direction, interval in directions.items()
            for side, value in interval.items()}


def _basis_grid(states, spans, lines, density, travel, polynomial_rtol, max_points, max_intervals):
    points = set(map(float, states.model.nodes))
    for a, b in zip(states.model.nodes[:-1], states.model.nodes[1:]):
        points.update(float(a+(b-a)*i/density) for i in range(1, density))
    _require(len(points) <= max_points, 'Complete service observation budget exceeded; no observations dropped')
    bounds, proofs, observations = [], [], []
    for span in spans:
        rows = [{d: dict(lower=math.inf, upper=-math.inf) for d in DIRECTIONS} for _ in lines]
        grid = sorted(x for x in points if span['start_mm'] <= x <= span['end_mm'])
        observations.append(grid)
        for x in grid:
            proof = _point_extrema(states, x, span, lines, *travel,
                polynomial_rtol=polynomial_rtol, max_intervals=max_intervals)
            for i, row in enumerate(rows):
                for direction in DIRECTIONS:
                    interval = proof['bounds'][f'{i}/{direction}']
                    row[direction]['lower'] = min(row[direction]['lower'], interval['lower'])
                    row[direction]['upper'] = max(row[direction]['upper'], interval['upper'])
            proofs.append(dict(span_index=span['index'], x_mm=x, **{k:v for k,v in proof.items() if k != 'bounds'}))
        bounds.append(rows)
    return dict(bounds=bounds, observations_by_span_mm=observations, point_proofs=proofs,
                comparison=_flatten(bounds), proof_signature=signature(proofs))


def produce_family_service_evidence(project, force_receipt, *, physical,
        relative_tolerance=.01, polynomial_relative_tolerance=1.e-8,
        max_spatial_refinements=5, max_observation_points=20000, max_polynomial_intervals=20000,
        progress=None):
    """Only reverify displacement bases, on the already established mesh sequence.

    No repeated normal case campaign and no force-family producer is invoked.
    The last force mesh is not accepted merely because forces converged.  Every
    active service basis must independently pass two chord spatial and two chord
    mesh comparisons, at <=1%, or the entire service result remains pending.
    """
    started = time.monotonic(); source = _source()
    out = dict(schema='LRO_NBR10084_FAMILY_CHORD_EVIDENCE_V1', evidence_kind=PENDING, pending=[],
               basis_evidence={}, continuum_upper_bound_claimed=False,
               rigorous_roundoff_enclosure_claimed=False, source_at_start=source)
    try:
        _check_inputs(project, physical)
        tol = _number(relative_tolerance, 'Service relative tolerance')
        ptol = _number(polynomial_relative_tolerance, 'Service polynomial tolerance')
        _require(0 < tol <= .01 and 0 < ptol <= 1.e-6, 'Service tolerance exceeds engineering verification scope')
        _require(type(max_spatial_refinements) is int and max_spatial_refinements >= 2, 'Two actual service spatial comparisons required')
        for value in (max_observation_points, max_polynomial_intervals):
            _require(type(value) is int and value > 0, 'Positive integral service coverage budgets required')
        incremental = _incremental_project(project, physical)
        _, plan = validate_family_receipt(incremental, force_receipt)
        service = _service_plan(project, physical, plan)
        spans = _spans(project); lines = service['contact_lines']
        operator = _operator_receipt(project, incremental)
        travel = (Fraction(project.travel_min_mm), Fraction(project.travel_max_mm))
        out.update(project_signature=signature(project.to_dict()), incremental_project_signature=signature(incremental.to_dict()),
            physical_inputs=asdict(physical), force_receipt_signature=force_receipt['receipt_signature'],
            service_plan=service, spans=spans, operator_signature=operator,
            covered_physical_travel_intervals_mm=deepcopy(force_receipt['covered_physical_travel_intervals_mm']),
            relative_tolerance=tol, polynomial_relative_tolerance=ptol)
        active = [b for b in plan['bases'] if b.id in service['active_basis_ids']]
        _require(active, 'No active native service physical bases')
        first = force_receipt['basis_evidence'][active[0].id]['mesh_history']
        mesh_sizes = [r['max_element_length_mm'] for r in first]
        _require(len(mesh_sizes) >= 3, 'Three actual common FE meshes required for service convergence')
        for basis in active:
            _require([r['max_element_length_mm'] for r in force_receipt['basis_evidence'][basis.id]['mesh_history']] == mesh_sizes,
                     'Service bases require one common complete mesh sequence')
        previous = {}; stable = {b.id: 0 for b in active}
        for mesh_index, mesh in enumerate(mesh_sizes):
            model = incremental.frame_model(mesh)
            for basis in active:
                states = _ChordStates(model, basis, incremental)
                spatial_history = []; prior = None; spatial_stable = 0
                for level in range(max_spatial_refinements+1):
                    row = _basis_grid(states, spans, lines, 2**level, travel, ptol, max_observation_points, max_polynomial_intervals)
                    delta = None if prior is None else _delta(row['comparison'], prior)
                    spatial_stable = spatial_stable+1 if delta is not None and delta <= tol else 0
                    spatial_history.append(dict(level=level, density=2**level,
                        relative_change=delta, stable_passes=spatial_stable,
                        signed_chord_comparison_mm=row['comparison'],
                        observations_by_span_mm=row['observations_by_span_mm'], proof_signature=row['proof_signature']))
                    prior = row['comparison']
                    if progress:
                        progress(dict(stage='family_service_displacement', basis_id=basis.id, mesh_index=mesh_index,
                                      spatial_level=level, spatial_stable_passes=spatial_stable))
                    if spatial_stable >= 2: break
                if spatial_stable < 2:
                    out.setdefault('incomplete_spatial_evidence',[]).append(dict(basis_id=basis.id,max_element_length_mm=mesh,spatial_history=spatial_history))
                _require(spatial_stable >= 2, basis.id+': independent chord spatial convergence incomplete')
                delta = None if basis.id not in previous else _delta(row['comparison'], previous[basis.id])
                stable[basis.id] = stable[basis.id]+1 if delta is not None and delta <= tol else 0
                previous[basis.id] = row['comparison']
                evidence = out['basis_evidence'].setdefault(basis.id, dict(mesh_history=[]))
                evidence['mesh_history'].append(dict(max_element_length_mm=mesh, nodes_mm=model.nodes.tolist(),
                    mesh_relative_change=delta, stable_passes=stable[basis.id], spatial_history=spatial_history,
                    signed_chord_comparison_mm=row['comparison'], solved_state_reuse=states.cache.receipt(),
                    input_signature=signature(dict(project=incremental.to_dict(), basis=asdict(basis), mesh=mesh)),
                    final_grid_proof_signature=row['proof_signature']))
                evidence.update(bounds=row['bounds'], observations_by_span_mm=row['observations_by_span_mm'],
                                point_proofs=row['point_proofs'])
        _require(all(stable[b.id] >= 2 for b in active), 'Displacement-specific FE mesh convergence incomplete; force convergence is not substituted')
        out['common_final_mesh_nodes_mm'] = model.nodes.tolist()
        _require(out['common_final_mesh_nodes_mm'] == force_receipt['common_final_mesh_nodes_mm'], 'Service final mesh differs from bound physical family mesh')
        _require(out['project_signature'] == signature(project.to_dict()), 'Project changed during service verification')
        out['evidence_kind'] = VERIFIED
    except (ValueError, TypeError, KeyError, ArithmeticError, AttributeError) as exc:
        out['pending'].append(type(exc).__name__+': '+str(exc))
    out['source_at_end'] = _source(); out['source_unchanged'] = source == out['source_at_end']
    if not out['source_unchanged']:
        out['evidence_kind'] = PENDING; out['pending'].append('Service dependency source changed during verification')
    out['seconds'] = time.monotonic()-started
    out['receipt_signature'] = signature(out)
    return out


def _validate_displacement(project, physical, force_receipt, evidence, plan):
    _require(isinstance(evidence, dict) and evidence.get('schema') == 'LRO_NBR10084_FAMILY_CHORD_EVIDENCE_V1',
             'Independent internally produced service displacement receipt required')
    _require(evidence.get('receipt_signature') == signature({k:v for k,v in evidence.items() if k != 'receipt_signature'}),
             'Service displacement receipt was altered')
    _require(evidence.get('evidence_kind') == VERIFIED and not evidence.get('pending'), 'Independent service displacement verification incomplete')
    _require(evidence.get('source_unchanged') is True and evidence.get('source_at_start') == evidence.get('source_at_end') == _source(),
             'Service displacement receipt source is stale')
    _require(evidence['project_signature'] == signature(project.to_dict()) and evidence['physical_inputs'] == asdict(physical),
             'Service project or source adoption factors differ')
    _require(evidence['force_receipt_signature'] == force_receipt['receipt_signature'], 'Service proof is not bound to this force basis receipt')
    service = _service_plan(project, physical, plan)
    _require(evidence['service_plan'] == service and evidence['spans'] == _spans(project), 'Physical service membership/span coverage differs')
    _require(evidence['common_final_mesh_nodes_mm'] == force_receipt['common_final_mesh_nodes_mm'], 'Service proof final FE mesh differs')
    _require(evidence['covered_physical_travel_intervals_mm'] == force_receipt['covered_physical_travel_intervals_mm'], 'Service travel domain differs')
    tol = _number(evidence['relative_tolerance'], 'Service convergence tolerance')
    ptol = _number(evidence['polynomial_relative_tolerance'], 'Service polynomial tolerance')
    _require(0 < tol <= .01 and 0 < ptol <= 1.e-6, 'Service convergence tolerance is invalid')
    _require(evidence.get('continuum_upper_bound_claimed') is False and evidence.get('rigorous_roundoff_enclosure_claimed') is False,
             'Unsupported mathematical service-bound claim')
    incremental = _incremental_project(project, physical)
    _require(evidence['incremental_project_signature'] == signature(incremental.to_dict()), 'Incremental support constraints differ')
    _require(evidence['operator_signature'] == _operator_receipt(project, incremental), 'Same-model baseline operator differs')
    models = {}
    bases = {b.id:b for b in plan['bases']}
    _require(set(evidence['basis_evidence']) == set(service['active_basis_ids']), 'Active displacement basis coverage incomplete')
    expected_fields = {f'{i}/{j}/{d}/{s}' for i in range(len(evidence['spans']))
                       for j in range(len(service['contact_lines'])) for d in DIRECTIONS for s in ('lower','upper')}
    for basis_id, row in evidence['basis_evidence'].items():
        history = row['mesh_history']; _require(len(history) >= 3, 'Three displacement-specific mesh levels required')
        _require(history[-1]['stable_passes'] >= 2, 'Two stable displacement-specific mesh comparisons required')
        expected_meshes = [r['max_element_length_mm'] for r in force_receipt['basis_evidence'][basis_id]['mesh_history']]
        _require([r['max_element_length_mm'] for r in history] == expected_meshes, 'Displacement mesh sequence differs from physical basis sequence')
        mesh_stable = 0
        for k, h in enumerate(history):
            mesh = h['max_element_length_mm']
            if mesh not in models: models[mesh] = incremental.frame_model(mesh)
            model = models[mesh]
            _require(h['nodes_mm'] == model.nodes.tolist(), 'Displacement mesh nodes differ from actual FE model')
            _require(h['input_signature'] == signature(dict(project=incremental.to_dict(), basis=asdict(bases[basis_id]), mesh=mesh)),
                     'Displacement basis/model input identity differs')
            _require(set(h['signed_chord_comparison_mm']) == expected_fields, 'Displacement comparison coverage incomplete')
            sh = h['spatial_history']; _require(len(sh) >= 3 and sh[-1]['stable_passes'] >= 2, 'Independent chord spatial history incomplete')
            spatial_stable = 0
            for j, spatial_row in enumerate(sh):
                _require(spatial_row['level'] == j and spatial_row['density'] == 2**j, 'Actual spatial refinement level is missing')
                grid = set(map(float, model.nodes))
                for a,b in zip(model.nodes[:-1], model.nodes[1:]):
                    grid.update(float(a+(b-a)*n/spatial_row['density']) for n in range(1,spatial_row['density']))
                expected_grid = [sorted(x for x in grid if span['start_mm'] <= x <= span['end_mm']) for span in evidence['spans']]
                _require(spatial_row['observations_by_span_mm'] == expected_grid, 'Complete computed displacement observation grid is missing')
                _require(set(spatial_row['signed_chord_comparison_mm']) == expected_fields, 'Spatial chord field coverage incomplete')
                if j:
                    change = _delta(spatial_row['signed_chord_comparison_mm'], sh[j-1]['signed_chord_comparison_mm'])
                    spatial_stable = spatial_stable+1 if change <= tol else 0
                else:
                    _require(spatial_row['relative_change'] is None, 'Initial spatial level must not claim a comparison')
                _require(spatial_row['stable_passes'] == spatial_stable, 'Spatial stable-pass count is not computed from chord comparisons')
            for prev, nxt in zip(sh[:-1], sh[1:]):
                _require(nxt['density'] == 2*prev['density'] and nxt['relative_change'] == _delta(nxt['signed_chord_comparison_mm'], prev['signed_chord_comparison_mm']),
                         'Spatial convergence is not the actual chord comparison')
            _require(all(0 <= z['relative_change'] <= tol for z in sh[-2:]), 'Last two chord spatial comparisons did not pass')
            _require(h['signed_chord_comparison_mm'] == sh[-1]['signed_chord_comparison_mm'], 'Mesh comparison is not the final chord grid')
            if k:
                _require(h['mesh_relative_change'] == _delta(h['signed_chord_comparison_mm'], history[k-1]['signed_chord_comparison_mm']),
                         'Mesh convergence is not the actual chord comparison')
                mesh_stable = mesh_stable+1 if h['mesh_relative_change'] <= tol else 0
            else:
                _require(h['mesh_relative_change'] is None, 'Initial mesh level must not claim a comparison')
            _require(h['stable_passes'] == mesh_stable, 'Mesh stable-pass count is not computed from chord comparisons')
        _require(all(0 <= h['mesh_relative_change'] <= tol for h in history[-2:]), 'Last two chord mesh comparisons did not pass')
        _require(_flatten(row['bounds']) == history[-1]['signed_chord_comparison_mm'], 'Final displacement bounds differ from mesh history')
        _require(row['observations_by_span_mm'] == history[-1]['spatial_history'][-1]['observations_by_span_mm'], 'Final observation grid differs')
        expected_points = {(i,x) for i, grid in enumerate(row['observations_by_span_mm']) for x in grid}
        actual_points = [(p['span_index'], p['x_mm']) for p in row['point_proofs']]
        _require(len(actual_points) == len(set(actual_points)) and set(actual_points) == expected_points, 'Incomplete service point/event coverage')
        _require(signature(row['point_proofs']) == history[-1]['final_grid_proof_signature'], 'Displacement point proof identity differs')
        for proof in row['point_proofs']:
            nodes = {Fraction(float(x)) for x in history[-1]['nodes_mm']} | {Fraction(proof['x_mm'])}
            lo,hi = Fraction(project.travel_min_mm),Fraction(project.travel_max_mm)
            events = {lo,hi}
            for wheel in bases[basis_id].wheels:
                offset = Fraction(wheel.offset_mm)
                events.update(x-offset for x in nodes if lo <= x-offset <= hi)
            events = sorted(events)
            _require(proof['event_count'] == len(events) and proof['interval_count'] == len(events)-1 and
                     proof['exact_event_signature'] == signature([(str(t.numerator),str(t.denominator)) for t in events]),
                     'Exact displacement event partition incomplete')
            ratio = _number(proof['maximum_polynomial_verification_ratio'], 'Polynomial verification ratio')
            _require(0 <= ratio <= 1. and type(proof['verification_checks']) is int and
                     proof['verification_checks'] >= 5*(len(events)-1)*2*len(service['contact_lines']),
                     'Displacement polynomial verification incomplete')
            _require(isinstance(proof['interval_coefficients_signature'], str) and len(proof['interval_coefficients_signature']) == 64,
                     'Verified displacement interval coefficient identity missing')
    return service


def evaluate_family_nbr10084_serviceability(project, force_receipt, *, physical,
                                            displacement_receipt=None, progress=None, **verification_controls):
    """Closed internal route: create missing displacement proof, then consume it."""
    result = dict(kind='autonomous_NBR10084_verified_family_service_consumer', status='PENDING_FAMILY_SERVICE',
        spans=[], pending=[], actual_failure_proven=False, concurrent_governor_claimed=False,
        continuum_upper_bound_claimed=False, numerical_engineering_result=True,
        sufficient_member_service_criteria_satisfied=False, whole_serviceability_complete=False,
        paired_runway_complete=False, supporting_floor_qualified=False, all_case_I_actions_complete=False,
        case_II_complete=False, selected_configuration_only=False, known_failures=[])
    try:
        _check_inputs(project, physical)
        result['suspended_mass_basis']=project.suspended_mass_basis()
        _require(result['suspended_mass_basis']['complete_suspended_mass_accounting'], 'Retained suspended mass is unspecified; legacy empty arithmetic is not a qualified physical operating envelope')
        before = signature(project.to_dict()); source_before = _source()
        incremental = _incremental_project(project, physical)
        _, plan = validate_family_receipt(incremental, force_receipt)
        if displacement_receipt is None:
            displacement_receipt = produce_family_service_evidence(project, force_receipt, physical=physical,
                progress=progress, **verification_controls)
        result['displacement_evidence'] = displacement_receipt
        service = _validate_displacement(project, physical, force_receipt, displacement_receipt, plan)
        divisor = 600. if physical.equipment_category == 'other_equipment' else 1000.
        coefficients = {b.id: dict(lower=min(m['coefficients'][b.id] for m in service['members']),
                                  upper=max(m['coefficients'][b.id] for m in service['members'])) for b in plan['bases']}
        for span in displacement_receipt['spans']:
            length = span['end_mm']-span['start_mm']; checks = []
            for direction in DIRECTIONS:
                line_bounds = []
                for line_index, line in enumerate(service['contact_lines']):
                    terms = []
                    for basis_id in service['active_basis_ids']:
                        raw = displacement_receipt['basis_evidence'][basis_id]['bounds'][span['index']][line_index][direction]
                        allowance = ABS_MM+displacement_receipt['polynomial_relative_tolerance']*max(abs(v) for v in raw.values())
                        interval = dict(lower=math.nextafter(raw['lower']-allowance, -math.inf),
                                        upper=math.nextafter(raw['upper']+allowance, math.inf))
                        terms.append(interval_product(coefficients[basis_id], interval))
                    line_bounds.append(dict(**line, signed_bound_mm=interval_sum(terms)))
                demand = max(abs(v) for row in line_bounds for v in row['signed_bound_mm'].values())
                limit = min(length/divisor, 25.) if direction == 'vertical' else length/600.
                check = assess_sufficient_limit(demand, limit)
                check.update(id='nbr10084_family_'+direction+'_incremental_chord_bound', direction=direction,
                    demand_upper_mm=demand, limit_mm=limit, line_bounds=line_bounds, qualified=True,
                    source=SOURCE, source_sha256=SOURCE_SHA256, governor=None,
                    scope='Sufficient independent-component box over all declared configurations/travel, not an actual concurrent maximum')
                checks.append(check)
            result['spans'].append(dict(**span, checks=checks))
        all_checks = [c for row in result['spans'] for c in row['checks']]
        passed = all(c['status'] == 'SUFFICIENT_BOUND_SATISFIED' for c in all_checks)
        result.update(status='SUFFICIENT_FAMILY_SERVICE_CHECKS_SATISFIED' if passed else 'INCONCLUSIVE_SUFFICIENT_BOUND',
            sufficient_member_service_criteria_satisfied=passed, total_configuration_count=len(service['configuration_ids']),
            total_service_case_count=len(service['members']), coefficient_intervals=coefficients,
            physical_inputs=asdict(physical), action_ledgers=service['action_ledgers'],
            baseline_receipt=dict(basis=BASELINE, action_basis=ACTION_BASIS, method='linear_rhs_difference',
                operator_signature=displacement_receipt['operator_signature'], same_support_constraints=True,
                same_contact_coordinates=True, same_state_chord_difference=True, incremental_selfweight_factor=0.,
                incremental_prescribed_displacements_zero=True,
                original_prescribed_support_values=[dict(id=s['id'], restrain=deepcopy(s['restrain'])) for s in project.supports],
                independently_enveloped_scalars_subtracted=False),
            source_receipt=dict(displacement_receipt_signature=displacement_receipt['receipt_signature'],
                force_receipt_signature=force_receipt['receipt_signature'], source=_source()),
            separate_scope=['Other normal horizontal mechanisms including skew/rolling are not generated.',
                'Source case II service wind and applicable temperature are not generated.',
                'Paired-runway differential, supporting-floor movement, alignment, clearances and local joint/contact compliance remain separate.'])
        _require(before == signature(project.to_dict()) and source_before == _source(), 'Project or service source changed during consumption')
    except (ValueError, TypeError, KeyError, ArithmeticError, AttributeError) as exc:
        result.update(status='PENDING_FAMILY_SERVICE', spans=[], sufficient_member_service_criteria_satisfied=False)
        result['pending'].append(type(exc).__name__+': '+str(exc))
    return result
