"""Native NBR 10084 §10/Table 4(a,d), selected bridge configuration only.

The solved field is the exact linear RHS difference from the *same* support
structure's selfweight-only state. Shared prescribed support movements cancel;
coordinates, section stiffness and constraint equations do not change. It is
not a difference of independently enveloped scalar maxima and is not the EN
total-characteristic route. Only the supplied normal no-wind gravity/inertia
mechanisms are generated, not every action in source cases I and II.
"""
from copy import deepcopy
from dataclasses import asdict, dataclass
from hashlib import sha256
from pathlib import Path

import numpy as np

from ..autonomous_workflow.model import MovingCase, checked_text, signature
from ..autonomous_workflow.pipeline import AnalysisControls, analyze_cases, source_receipt
from .criteria import PRODUCER, _governor as validate_governor
from .nbr10084_criteria import (
    ACTION_BASIS, BASELINE, CATEGORIES, SOURCE, SOURCE_SHA256,
    evaluate_span_nbr10084,
)

ACTION_SOURCE = 'ABNT NBR 10084:2020 §8.1 normal operation without wind; §10/Table 4(a,d), no impact or majoration'
ACCESSORY_POLICIES = (
    'absent', 'fixed_support_structure_selfweight', 'additional_permanent_action',
)
_SUPPORT_KEYS = {'id', 'x', 'y', 'z', 'omega', 'restrain', 'provenance', 'coordinate_basis'}


@dataclass(frozen=True)
class NBR10084ServicePhysicalInputs:
    equipment_category: str
    equipment_category_source: str
    measurement_plane: str
    measurement_plane_adoption_source: str
    operating_domain: str
    operating_source: str
    hoist_mass_scope: str
    accessory_baseline_policy: str
    accessory_baseline_source: str

    def validate(self):
        if self.equipment_category not in CATEGORIES:
            raise ValueError('Explicit NBR equipment category or conservative unclassified L/1000 policy required')
        # This physical producer is an underhung bridge, never an actual top rail.
        if self.measurement_plane != 'actual_underhung_running_plane_adopted':
            raise ValueError('Explicit adoption of the actual underhung running plane as the Table 4 analogue required')
        if self.operating_domain != 'normal_operation_without_wind':
            raise ValueError('This producer covers only the declared normal-operation no-wind mechanisms of source case I')
        if self.hoist_mass_scope not in ('capacity_mass_includes_all_suspended_attachments','payload_plus_retained_common_ledger'):
            raise ValueError('Physical hoist mass convention must be explicit')
        if self.accessory_baseline_policy not in ACCESSORY_POLICIES:
            raise ValueError('Explicit fixed-accessory selfweight baseline policy required')
        for name in ('equipment_category_source', 'measurement_plane_adoption_source',
                     'operating_source', 'accessory_baseline_source'):
            checked_text(getattr(self, name), name)
        return self


def _check_inputs(project, physical):
    if not isinstance(physical, NBR10084ServicePhysicalInputs):
        raise ValueError('Typed native NBR 10084 physical service inputs required')
    physical.validate()
    project.validate()
    mass_basis=project.suspended_mass_basis()
    if physical.hoist_mass_scope=='payload_plus_retained_common_ledger' and not mass_basis['complete_suspended_mass_accounting']:
        raise ValueError('Explicit payload and retained suspended mass ledger required for native service')
    if physical.hoist_mass_scope=='capacity_mass_includes_all_suspended_attachments' and mass_basis['complete_suspended_mass_accounting']:
        raise ValueError('Common payload/B ledger requires the matching new service mass convention')
    for support in project.supports:
        if set(support) - _SUPPORT_KEYS:
            raise ValueError('Unsupported support fields: this producer must not silently discard spring/stiffness or other support data')
    absent = physical.accessory_baseline_policy == 'absent'
    if absent != (project.extra_dead_N_per_mm == 0.):
        raise ValueError('Accessory baseline policy must match the actual declared zero/nonzero accessory UDL')


def generate_nbr10084_service_cases(project, physical):
    """Generate a bounded case-I subset, removing the entire H multiplier once.

    Both directions consume these same correlated cases. The bridge ledger
    binds individual wheels to physical masses/CGs/accelerations, including
    vertical inertia redistribution and empty-state inertia. Manual/external
    wheel effort tables cannot establish the required dynamic decomposition.
    """
    _check_inputs(project, physical)
    ledger = project.bridge_reaction_ledger
    if not ledger or ledger.get('schema') != 'LRO_BOUND_BRIDGE_INERTIA_LEDGER_V1':
        raise ValueError('Bound physical bridge inertia ledger required; external/manual forces do not identify the dynamic split')
    k = ledger['inputs']['horizontal_dynamic_factor']
    sx = (-1, 1) if any(w.longitudinal_N or w.longitudinal_empty_N or
                       w.longitudinal_vertical_N or w.longitudinal_vertical_empty_N for w in project.wheels) else (1,)
    sy = (-1, 1) if any(w.transverse_N or w.transverse_empty_N or
                       w.transverse_vertical_N or w.transverse_vertical_empty_N for w in project.wheels) else (1,)
    accessory_factor = 1. if physical.accessory_baseline_policy == 'additional_permanent_action' else 0.
    source = ACTION_SOURCE + '; ' + physical.operating_source
    cases = tuple(
        MovingCase(f'SLS10084/I/normal_no_wind/{"loaded" if loaded else "empty"}/HX{hx:+d}/HY{hy:+d}',
                   'SLS10084', 0., 1., 1. if loaded else 0., 1./k, 1./k,
                   hx, hy, loaded, source, accessory_factor, retained_lifted=1.)
        for loaded in (True, False) for hx in sx for hy in sy
    )
    ids = [c.id for c in cases]
    actions = dict(
        basis=ACTION_BASIS, case_ids=ids, case_category={i: 'I' for i in ids},
        equipment_characteristic_factor=1., lifted_characteristic_factor=1.,
        selfweight_characteristic_factor=1., incremental_selfweight_factor=0.,
        incremental_accessory_factor=accessory_factor,
        partial_factors={'support_G': 1., 'equipment_G': 1., 'Q': 1., 'HX': 1., 'HY': 1.},
        dynamic_factors={'equipment_G': 1., 'Q': 1., 'HX': 1., 'HY': 1.},
        horizontal_inertia_dynamic_removed=True,
        original_H_multiplier_removed_once=k,
        applied_correlated_H_parcel_multiplier=1./k,
        source=source, source_sha256=SOURCE_SHA256,
        covered_mechanisms=['moving equipment gravity', 'loaded/empty payload gravity',
                            'supplied bridge/trolley acceleration inertia with correlated vertical redistribution'],
        all_case_I_mechanisms_covered=False, case_II_generated=False,
        omissions=['Other normal horizontal mechanisms (including skew/rolling) are not generated.',
                   'Source case II service-limit wind and applicable temperature are not generated.',
                   'Source case III special actions are outside this service producer.'],
    )
    return cases, deepcopy(actions), deepcopy(actions)


def _incremental_project(project, physical):
    """Clone, never mutate, the physical project; cancel prescribed RHS only."""
    _check_inputs(project, physical)
    incremental = deepcopy(project)
    for support in incremental.supports:
        support['restrain'] = {key: 0. for key in support['restrain']}
    incremental.validate()
    return incremental


def _operator_receipt(original, incremental):
    """Verify actual assembled K/C/nodes at the same initial mesh.

    Every refined mesh uses the unchanged frame-model producer and the same
    coordinates/constraint keys. Only prescribed values differ. No stiffness
    is inferred for real joints; this remains the declared kinematic model.
    """
    left = original.frame_model()
    right = incremental.frame_model()
    for name in ('nodes', 'K', 'C'):
        if not np.array_equal(getattr(left, name), getattr(right, name)):
            raise ValueError('Selfweight baseline and increment must have the same linear operator and support constraints')
    if not np.array_equal(right.prescribed, np.zeros_like(right.prescribed)):
        raise ValueError('Incremental prescribed displacements must be homogeneous')
    contacts = lambda p: [(w.id, w.offset_mm, w.y_mm, w.z_mm, w.omega_mm2) for w in p.wheels]
    if contacts(original) != contacts(incremental):
        raise ValueError('Selfweight baseline and increment must use the same contact coordinates')
    return signature(dict(nodes_mm=left.nodes.tolist(), stiffness=left.K.tolist(),
                          constraints=left.C.tolist(), section=left.section,
                          mesh_mm=original.max_element_length_mm))


def _source_hash():
    # criteria.py supplies the shared governor/convergence validation and must
    # be covered too, not just the two native files.
    root = Path(__file__).parent
    names = ('__init__.py', 'criteria.py', 'nbr10084_criteria.py', 'nbr10084_adapter.py')
    return signature({name: sha256((root/name).read_bytes()).hexdigest() for name in names})


def _governor(row):
    return dict(case_id=row['case_id'], translation_mm=row['translation_mm'], x_mm=row['x_mm'],
                outstand_side='left' if row['y_mm'] < 0 else 'right',
                line_y_mm=row['y_mm'], line_z_mm=row['z_mm'],
                displacement_mm=row['absolute_contact_displacement_mm'],
                end_left_mm=row['endpoint_contact_displacements_mm'][0],
                end_right_mm=row['endpoint_contact_displacements_mm'][1], relative_mm=row['value'])


def evaluate_autonomous_nbr10084_serviceability(project, *, physical, controls=None, progress=None):
    """Evaluate every actual support span of the selected configuration.

    This entry point is deliberately separate from the existing EN adapter and
    workflow/UI. Source/input mutation, lost case/span/contact coverage, and
    missing final mesh comparisons cannot produce a qualified native check.
    """
    _check_inputs(project, physical)
    controls = AnalysisControls() if controls is None else AnalysisControls(**controls) if isinstance(controls, dict) else controls
    if not isinstance(controls, AnalysisControls):
        raise ValueError('AnalysisControls required')
    original_payload = project.to_dict()
    project_start = signature(original_payload)
    physical_start = signature(asdict(physical))
    source_start, own_start = source_receipt(), _source_hash()
    cases, vertical, horizontal = generate_nbr10084_service_cases(project, physical)
    incremental = _incremental_project(project, physical)
    incremental_start = signature(incremental.to_dict())
    operator_signature = _operator_receipt(project, incremental)
    ids = [c.id for c in cases]
    baseline_accessory = project.extra_dead_N_per_mm if physical.accessory_baseline_policy == 'fixed_support_structure_selfweight' else 0.
    baseline = dict(
        basis=BASELINE, method='linear_rhs_difference', same_linear_operator=True,
        same_contact_coordinates=True, same_support_constraints=True, same_state_chord_difference=True,
        case_ids=ids, operator_signature=operator_signature,
        baseline_case_signature=signature(dict(operator=operator_signature, supports=project.supports,
            structural_selfweight_N_per_mm=project.selfweight(), accessory_N_per_mm=baseline_accessory,
            accessory_y_mm=project.extra_dead_y_mm, accessory_policy=physical.accessory_baseline_policy)),
        incremental_load_signature=signature(dict(cases=[asdict(c) for c in cases], wheels=[asdict(w) for w in project.wheels],
            extra_dead_N_per_mm=project.extra_dead_N_per_mm, extra_dead_y_mm=project.extra_dead_y_mm,
            zero_prescribed_supports=incremental.supports)),
        incremental_selfweight_factor=0., incremental_prescribed_displacements_zero=True,
        fixed_accessory_baseline_N_per_mm=baseline_accessory,
        accessory_baseline_policy=physical.accessory_baseline_policy,
        accessory_baseline_source=physical.accessory_baseline_source,
        original_project_signature=project_start, incremental_project_signature=incremental_start,
        original_prescribed_support_values=[dict(id=s['id'], restrain=deepcopy(s['restrain'])) for s in project.supports],
        independently_enveloped_scalars_subtracted=False,
    )
    run = analyze_cases(incremental, cases, controls=controls, progress=progress)
    rows = run['cases']
    expected = {c.id: asdict(c) for c in cases}
    actual = [r['case']['id'] for r in rows]
    if len(actual) != len(set(actual)) or set(actual) != set(ids):
        raise ValueError('Native service result case coverage differs from generated cases')
    if any(signature(r['case']) != signature(expected[r['case']['id']]) for r in rows):
        raise ValueError('Native service result changed a generated action case')
    pending, spans = [], {}
    support_x = sorted({float(s['x']) for s in project.supports})
    physical_spans = list(zip(support_x[:-1], support_x[1:]))
    complete_coverage = True
    for row in rows:
        extrema = (row.get('sweep') or {}).get('extrema', {})
        expected_keys = set()
        for index, (lo, hi) in enumerate(physical_spans):
            for wheel in project.wheels:
                for direction, component in (('vertical', 'w'), ('horizontal', 'v')):
                    key = f'service_span/{index}/contact/{wheel.id}/relative_{component}'
                    expected_keys.add(key)
                    pair = extrema.get(key)
                    if not isinstance(pair, dict) or set(pair) != {'min', 'max'} or any(g is None for g in pair.values()):
                        complete_coverage = False
                        pending.append(row['case']['id'] + ': missing actual span/contact/direction envelope ' + key)
                        continue
                    for governor in pair.values():
                        if (governor.get('span_start_mm'), governor.get('span_end_mm')) != (lo, hi):
                            raise ValueError('Native service governor span differs from actual support coordinates')
                        if (governor.get('y_mm'), governor.get('z_mm')) != (wheel.y_mm, wheel.z_mm):
                            raise ValueError('Native service governor does not use the actual contact line')
                        validate_governor(_governor(governor), lo, hi, [row['case']['id']], abs(governor['value']), direction)
                        slot = spans.setdefault(index, {})
                        old = slot.get(direction)
                        if old is None or abs(governor['value']) > abs(old['value']):
                            slot[direction] = governor
        if {key for key in extrema if key.startswith('service_span/')} - expected_keys:
            raise ValueError('Native service result contains a span/contact metric absent from the physical model')
    good = bool(rows) and complete_coverage and all(r['numerical_converged'] is True and r.get('sweep') is not None for r in rows)
    if not good:
        pending.append('Moving-position/spatial/mesh convergence or required service response coverage is incomplete.')
    histories = [r['mesh_history'] for r in rows]
    # Compare each case's own final two levels, not the same list indexes.
    history = ([{}, *[dict(maximum_relative_change=(max(h[i]['mesh_relative_change'] for h in histories)
        if all(h[i].get('mesh_relative_change') is not None for h in histories) else None)) for i in (-2, -1)]]
        if histories and all(len(h) >= 3 for h in histories) else [])
    hashes = {h[-1].get('solver_source_hash', '') for h in histories if h}
    if len(hashes) != 1 or '' in hashes:
        good = False
        pending.append('Required cases do not have one consistent numerical solver source hash.')
    receipt = dict(
        producer_kind=PRODUCER, input_signature=signature(dict(project=original_payload, physical=asdict(physical),
            incremental_project_signature=incremental_start)),
        solver_source_hash=next(iter(hashes)) if len(hashes) == 1 else '', producer_source_hash=own_start,
        moving_converged=good, mesh_converged=good, event_coverage_complete=good,
        spatial_coverage_complete=good, same_state_end_chord=True, continuum_upper_bound_claimed=False,
        case_ids=ids, relative_tolerance=max(controls.moving_tolerance, controls.mesh_tolerance),
        mesh_history=history, stable_passes=min((h[-1]['stable_passes'] for h in histories if h), default=0),
    )
    missing_spans = set(range(len(physical_spans))) - set(spans)
    if missing_spans:
        pending.append('Missing service envelope for actual support spans: ' + str(sorted(missing_spans)))
    if len(support_x) < 2:
        pending.append('At least two distinct physical support stations are required for support-to-support member criteria.')
    if not support_x or support_x[0] != 0. or support_x[-1] != project.length_mm:
        pending.append('Cantilever/unsupported-end service regions are outside these support-to-support criteria.')
    results = []
    for index, slot in sorted(spans.items()):
        if set(slot) != {'vertical', 'horizontal'}:
            pending.append('Span ' + str(index) + ' lacks an actual required direction governor')
            continue
        lo, hi = physical_spans[index]
        envelope = dict(start_mm=lo, end_mm=hi, case_ids=ids, vertical_case_ids=ids, horizontal_case_ids=ids,
            vertical_abs_mm=abs(slot['vertical']['value']), horizontal_abs_mm=abs(slot['horizontal']['value']),
            vertical_governor=_governor(slot['vertical']), horizontal_governor=_governor(slot['horizontal']),
            producer_receipt=receipt, baseline_receipt=baseline,
            vertical_action_ledger=vertical, horizontal_action_ledger=horizontal)
        result = evaluate_span_nbr10084(envelope, equipment_category=physical.equipment_category,
                                       measurement_plane=physical.measurement_plane)
        result.update(span_index=index, start_mm=lo, end_mm=hi)
        results.append(result)
        pending.extend(result['pending'])
    source_after, own_after = source_receipt(), _source_hash()
    if signature(project.to_dict()) != project_start or signature(asdict(physical)) != physical_start:
        raise ValueError('Physical project or service inputs changed during native service calculation; fresh run required')
    if signature(incremental.to_dict()) != incremental_start:
        raise ValueError('Incremental physical project changed during native service calculation; fresh run required')
    if source_start['fingerprint'] != source_after['fingerprint'] or own_start != own_after:
        raise ValueError('Native service numerical source changed during calculation; fresh run required')
    coverage_gaps = deepcopy(vertical['omissions'])
    coverage_gaps += ['Only the selected hook/height/rail configuration is assessed; no whole equipment-family envelope is produced.',
        'Paired-runway differential, support/floor movement, alignment, local contact/joint compliance and clearances remain separate.']
    return dict(
        status='AUTONOMOUS_NBR10084_MEMBER_SERVICE_CHECKS' if results else 'NBR10084_SERVICE_NUMERICAL_PENDING',
        spans=results, pending=list(dict.fromkeys(pending)), case_coverage_gaps=coverage_gaps,
        physical_inputs=asdict(physical), original_project_signature=project_start,
        baseline_receipt=baseline, case_ledgers=dict(vertical=vertical, horizontal=horizontal), case_run=run,
        source=source_start, source_after=source_after, service_source_hash=own_start,
        service_source_hash_after=own_after, source_unchanged_during_calculation=True,
        normative_source=SOURCE, normative_source_sha256=SOURCE_SHA256,
        selected_configuration_only=True, all_case_I_actions_complete=False, case_II_complete=False,
        paired_runway_complete=False, supporting_floor_outside_scope=True, whole_serviceability_complete=False,
        continuum_upper_bound_claimed=False, numerical_engineering_result=True,
        known_failures=[c for r in results for c in r['checks'] if c['status'] == 'FAIL'],
    )
