"""Additional project deflection criteria; never relax or mix source criteria.

Each supplied qualified criterion keeps its own action/baseline ledger. The
manual L/divisor restriction is applied to that same response. All original
limits, including absolute caps, remain mandatory and visible.
"""
from copy import deepcopy
from math import isfinite
from ..autonomous_workflow.model import checked_text,signature
from ..autonomous_workflow.family_envelope import assess_sufficient_limit


def validate_project_limits(limits):
    if limits is None:return None
    if not isinstance(limits,dict) or set(limits)!={'vertical_divisor','lateral_divisor','source'}:
        raise ValueError('Project limits require only vertical_divisor, lateral_divisor and source')
    out=deepcopy(limits)
    for key in ('vertical_divisor','lateral_divisor'):
        v=out[key]
        if v is not None:
            try:valid=type(v) in (float,int) and isfinite(v) and v>0
            except (ArithmeticError,TypeError):valid=False
            if not valid:raise ValueError('Positive finite project L/divisor required: '+key)
    checked_text(out['source'],'Project deflection-criterion source',required=any(out[k] is not None for k in ('vertical_divisor','lateral_divisor')))
    return out


def apply_project_service_limits(result,limits):
    """Return separately identified checks; do not alter normative evidence."""
    limits=validate_project_limits(limits)
    if limits is None:return None
    output=dict(kind='additional_restrictive_project_service_criteria',physical_inputs=limits,
        original_service_signature=signature(result),checks=[],pending=[],
        source_action_bases_preserved=True,original_normative_limits_not_relaxed=True,
        different_action_bases_mixed=False,actual_failure_proven=False,
        status='PROJECT_CRITERIA_NOT_REQUESTED',sufficient_project_service_satisfied=False)
    requested=any(limits[k] is not None for k in ('vertical_divisor','lateral_divisor'))
    if not requested:return output
    directions={d for d,k in (('vertical','vertical_divisor'),('horizontal','lateral_divisor')) if limits[k] is not None}
    spans=result.get('spans',[]) if isinstance(result,dict) else []
    if not spans:output['pending'].append('No independently qualified source service span response is available')
    for span in spans:
        length=span['end_mm']-span['start_mm']
        found=set()
        for source in span.get('checks',[]):
            d=source.get('direction')
            if d not in directions:continue
            found.add(d)
            if source.get('qualified') is not True:
                output['pending'].append('Unqualified source service criterion: '+str(source.get('id',d)))
                continue
            divisor=limits['vertical_divisor' if d=='vertical' else 'lateral_divisor']
            manual=length/divisor
            limit=min(source['limit_mm'],manual)
            check=assess_sufficient_limit(source['demand_upper_mm'],limit)
            check.update(span_index=span['index'],direction=d,source_criterion_id=source['id'],
                source_reference=source.get('source'),source_response_not_replaced=True,
                demand_upper_mm=source['demand_upper_mm'],original_limit_mm=source['limit_mm'],
                project_limit_mm=manual,effective_limit_mm=limit,divisor=divisor,
                source_action_ledger=source.get('source_action_ledger',result.get('action_ledgers')),baseline_receipt=source.get('source_baseline_receipt',result.get('baseline_receipt')),
                project_source=limits['source'],governor=None)
            output['checks'].append(check)
        for d in directions-found:output['pending'].append('Missing source service direction '+d+' in span '+str(span['index']))
    passed=bool(output['checks']) and not output['pending'] and all(c['status']=='SUFFICIENT_BOUND_SATISFIED' for c in output['checks'])
    output['sufficient_project_service_satisfied']=passed
    output['status']='PROJECT_SERVICE_PENDING' if output['pending'] else 'SUFFICIENT_PROJECT_SERVICE_SATISFIED' if passed else 'INCONCLUSIVE_SUFFICIENT_BOUND'
    output['receipt_signature']=signature(output)
    return output
