"""CMAA74:2020 runway service using independently verified chord responses.

Section 1.4.1.2.3 supplies L/450 for an under-running runway, based on maximum
wheel loads without vertical impact. The text does not resolve drive-induced
vertical redistribution. This adopted check therefore contains static G+SL AND
both source-IFD directions, with the already documented SK force enclosure as
an additional conservative action. DLF/HLF are NOT applied to vertical weights.
The IFD/SK inclusion is explicitly an adoption, not a quotation of that clause.

Only mechanical response bases are reused. Native NBR action coefficients,
limits and independently enveloped scalar displacements are never relabelled.
"""
from dataclasses import asdict
from hashlib import sha256
from pathlib import Path
import math

from ..autonomous_workflow.model import signature
from ..autonomous_workflow.family_envelope import interval_product, interval_sum, assess_sufficient_limit
from ..cmaa74.actions import CMAA74PhysicalInputs, generate_case2_actions
from ..cmaa74.family_adapter import generate_cmaa_family_coefficients
from ..stability.family_adapter import validate_family_receipt
from .family_adapter import _validate_displacement, ABS_MM
from .nbr10084_adapter import NBR10084ServicePhysicalInputs

SOURCE = 'CMAA74:2020 1.4.1.2.3, printed page 10, under-running runway L/450 without VIF'
ACTION_BASIS = 'CMAA74_runway_static_weights_no_VIF_plus_adopted_IFD_SK_enclosure'


def _require(ok, message):
    if not ok:
        raise ValueError(message)


def _interval(lower, upper=None):
    upper = lower if upper is None else upper
    _require(all(type(v) in (int, float) and math.isfinite(v) for v in (lower, upper)) and lower <= upper,
             'Finite ordered service coefficient interval required')
    return dict(lower=float(lower), upper=float(upper))


def _source():
    from .family_adapter import _source as displacement_source
    root = Path(__file__).resolve().parents[1]
    paths = ('serviceability/cmaa_family.py', 'cmaa74/actions.py', 'cmaa74/family_adapter.py',
             'cmaa74/kernel.py', 'autonomous_ui/cmaa_inputs.py')
    return dict(displacement=displacement_source(), files={p:sha256((root/p).read_bytes()).hexdigest() for p in paths})


def generate_cmaa_service_coefficients(project, plan, physical, *, cmaa_action_project=None,
                                       cmaa_conversion_receipt=None):
    """Regenerate real static/IFD vectors, then enclose independent SK forces.

    Static and IFD states have physical identities. SK signs and response-box
    vertices do not, and are never exported as concurrent support reactions.
    """
    # This validator regenerates full physical membership and conversion. Its
    # Case2 force totals and normative coefficients are deliberately discarded.
    generated_domain = generate_cmaa_family_coefficients(project, plan, physical,
        cmaa_action_project=cmaa_action_project, cmaa_conversion_receipt=cmaa_conversion_receipt)
    action_project = project if cmaa_action_project is None else cmaa_action_project
    inputs = action_project.bridge_reaction_ledger['inputs']
    bases = {b.id:b for b in plan['bases']}
    members = []
    for config in plan['configurations']:
        for generated in generate_case2_actions(project.section, inputs, config['id'], physical):
            rows = {r['contact_id']:r for r in generated.full_contact_forces}
            selected = sorted(generated.wheels, key=lambda w:(w.offset_mm,w.y_mm))
            # Zero IFD is a separate included state, not inferred from a maximum.
            for inertia in (0., 1.):
                values = {}
                sx,sy = generated.case.longitudinal_sign,generated.case.transverse_sign
                for ident,row in rows.items():
                    g = row['DL_N']+row['TL_N']+row['LL_N']
                    hx,hy = row['IFD_bridge_vector_N'],row['IFD_trolley_vector_N']
                    vector = (inertia*(sx*hx[0]+sy*hy[0]), inertia*(sx*hx[1]+sy*hy[1]),
                              -g+inertia*(sx*hx[2]+sy*hy[2]))
                    _require(all(math.isfinite(v) for v in vector), 'Nonfinite source service wheel vector')
                    scale = max(1., abs(g), abs(hx[2]), abs(hy[2]))
                    _require(vector[2] <= 64*math.ulp(scale),
                             'Static/no-VIF service state leaves the no-hold-down contact model')
                    values[ident] = vector
                paired = []
                sk = []
                for wheel in selected:
                    matches = [ident for ident in rows if wheel.id.endswith('/'+ident)]
                    _require(len(matches)==1, 'Service contact identity is ambiguous')
                    ident = matches[0]
                    paired.append(values[ident]);sk.append(rows[ident]['SK_transverse_abs_upper_N'])
                raw = {b.id:_interval(0.) for b in plan['bases']}
                for station in (0,1):
                    i = 2*station
                    _require(paired[i] == paired[i+1], 'Service paired force-basis geometry requires equal physical normal/IFD forces')
                    fx,fy,fz = paired[i]
                    h = (sk[i]+sk[i+1])/2
                    raw[f'station{station}/Fx'] = _interval(fx)
                    raw[f'station{station}/Fy'] = _interval(fy-h,fy+h)
                    raw[f'station{station}/downward_Fz'] = _interval(-fz)
                coefficients = {}
                for ident,value in raw.items():
                    amplitude = bases[ident].amplitude
                    _require(amplitude != 0. or value == _interval(0.),
                             'CMAA service needs an absent mechanical force basis: '+ident)
                    coefficients[ident] = interval_product(value,_interval(1/amplitude)) if amplitude else _interval(0.)
                members.append(dict(configuration_id=config['id'], case_id=generated.case.id+('/static_no_VIF' if inertia==0 else '/IFD_no_VIF'),
                    loaded=generated.case.loaded, inertia_multiplier=inertia,
                    raw_coefficient_intervals=raw, coefficient_intervals=coefficients,
                    static_equipment_and_suspended_weight_factors=1., DLF_applied=False, HLF_applied=False,
                    correlated_IFD_vertical_components_retained=inertia==1., SK_independent_enclosure=True))
    _require(len(members)==128, 'All eight configurations/static and IFD/empty and loaded states required')
    coefficients = {ident:_interval(min(m['coefficient_intervals'][ident]['lower'] for m in members),
                                   max(m['coefficient_intervals'][ident]['upper'] for m in members)) for ident in bases}
    return dict(members=members, coefficient_intervals=coefficients, total_configuration_count=8,
        total_service_case_count=len(members), source=SOURCE, action_basis=ACTION_BASIS,
        source_case2_coefficients_reused=False, source_case2_totals_reused=False,
        static_case_included=True, vertical_impact_removed=True,
        adopted_additional_actions='Both IFD directions with full correlated vertical redistribution and conservative source SK force enclosure; additional adoption, not literal wording of 1.4.1.2.3.',
        baseline='Crane-induced incremental deformation; runway selfweight/prescribed support displacement excluded from this wheel-load criterion and assessed separately.',
        selfweight_coefficient=0., additional_fixed_accessory_coefficient=0.,
        physical_domain=generated_domain['configuration_domain'], concurrent_state_claimed=False)


def evaluate_cmaa_family_serviceability(project, force_receipt, *, physical, displacement_receipt,
                                        cmaa_action_project=None, cmaa_conversion_receipt=None):
    result = dict(kind='CMAA74_2020_underhung_family_service', status='CMAA_SERVICE_PENDING',
        spans=[],pending=[],sufficient_member_service_criteria_satisfied=False,
        actual_failure_proven=False,concurrent_governor_claimed=False,
        vertical_criterion_assessed=False,lateral_criterion_not_prescribed_by_inspected_clause=True,
        paired_runway_alignment_assessed=False,whole_beam_complete=False)
    before = signature(project.to_dict()); source = _source()
    try:
        _require(isinstance(physical,CMAA74PhysicalInputs),'Typed CMAA physical inputs required')
        _,plan = validate_family_receipt(project,force_receipt)
        _require(isinstance(displacement_receipt,dict),'Independent actual chord displacement receipt required')
        native_physical = NBR10084ServicePhysicalInputs(**displacement_receipt['physical_inputs'])
        mechanics = _validate_displacement(project,native_physical,force_receipt,displacement_receipt,plan)
        actions = generate_cmaa_service_coefficients(project,plan,physical,
            cmaa_action_project=cmaa_action_project,cmaa_conversion_receipt=cmaa_conversion_receipt)
        active = [b.id for b in plan['bases'] if actions['coefficient_intervals'][b.id] != _interval(0.)]
        _require(set(active) <= set(displacement_receipt['basis_evidence']),
                 'CMAA service requires independently verified chord bases not present in this receipt')
        for span in displacement_receipt['spans']:
            line_bounds = []
            for i,line in enumerate(mechanics['contact_lines']):
                terms = []
                for ident in active:
                    raw = displacement_receipt['basis_evidence'][ident]['bounds'][span['index']][i]['vertical']
                    allowance = ABS_MM+displacement_receipt['polynomial_relative_tolerance']*max(abs(v) for v in raw.values())
                    interval = _interval(math.nextafter(raw['lower']-allowance,-math.inf),math.nextafter(raw['upper']+allowance,math.inf))
                    terms.append(interval_product(actions['coefficient_intervals'][ident],interval))
                line_bounds.append(dict(**line,signed_bound_mm=interval_sum(terms)))
            demand = max(abs(v) for line in line_bounds for v in line['signed_bound_mm'].values())
            limit = (span['end_mm']-span['start_mm'])/450.
            check = assess_sufficient_limit(demand,limit)
            check.update(id='CMAA74_underhung_vertical_no_VIF_plus_adopted_IFD_SK', direction='vertical',
                demand_upper_mm=demand, limit_mm=limit, line_bounds=line_bounds,qualified=True,
                source=SOURCE,governor=None,action_basis=ACTION_BASIS)
            result['spans'].append(dict(**span,checks=[check]))
        passed = bool(result['spans']) and all(s['checks'][0]['status']=='SUFFICIENT_BOUND_SATISFIED' for s in result['spans'])
        result.update(status='SUFFICIENT_CMAA_FAMILY_SERVICE_SATISFIED' if passed else 'INCONCLUSIVE_SUFFICIENT_BOUND',
            sufficient_member_service_criteria_satisfied=passed,vertical_criterion_assessed=True,
            action_ledgers=actions,baseline_receipt=dict(basis=actions['baseline'],linear_rhs_difference=True,
                independent_scalar_envelopes_subtracted=False,selfweight_coefficient=0.),
            physical_inputs=asdict(physical),force_receipt_signature=force_receipt['receipt_signature'],
            displacement_receipt_signature=displacement_receipt['receipt_signature'],
            source_action_bases_preserved=True,source_receipt=source)
        _require(before==signature(project.to_dict()) and source==_source(),'Project or source changed during CMAA service consumption')
    except (ValueError,TypeError,KeyError,ArithmeticError,AttributeError) as exc:
        result.update(status='CMAA_SERVICE_PENDING',spans=[],sufficient_member_service_criteria_satisfied=False)
        result['pending'].append(type(exc).__name__+': '+str(exc))
    return result
