"""Require all applicable source checks plus restrictive project limits.

Different source action/baseline ledgers are preserved. This is not a choice of
one denominator applied to a demand calculated on another source's actions.
"""
from copy import deepcopy
from math import isfinite
from .project_limits import apply_project_service_limits,validate_project_limits


def aggregate_member_service(native,cmaa,limits=None,*,expected_spans=None):
    limits=validate_project_limits(limits)
    combined=dict(spans=[],action_ledgers={},baseline_receipt={})
    pending=[];source_results={};spans={};coverage={}
    expected=set(tuple(v) for v in expected_spans) if expected_spans is not None else None
    for key,result in (('NBR10084',native),('CMAA74',cmaa)):
        source_results[key]=bool(result and result.get('sufficient_member_service_criteria_satisfied'))
        if not result:
            pending.append(key+': independent service criterion was not assessed');continue
        pending.extend(key+': '+str(x) for x in result.get('pending',[]))
        combined['action_ledgers'][key]=deepcopy(result.get('action_ledgers'))
        combined['baseline_receipt'][key]=deepcopy(result.get('baseline_receipt'))
        rows=result.get('spans',[])
        if not rows:
            pending.append(key+': no qualified span checks');source_results[key]=False
        coverage[key]=set()
        for row in rows:
            ident=(row['index'],row['start_mm'],row['end_mm'])
            if ident in coverage[key]:
                pending.append(key+': duplicate span');source_results[key]=False
            coverage[key].add(ident)
            required={'vertical','horizontal'} if key=='NBR10084' else {'vertical'}
            checks=row.get('checks',[])
            if not checks or not required <= {c.get('direction') for c in checks}:
                pending.append(key+': missing required service direction');source_results[key]=False
            for c in checks:
                complete=(c.get('qualified') is True and c.get('status')=='SUFFICIENT_BOUND_SATISFIED'
                    and all(type(c.get(n)) in (int,float) and isfinite(c[n]) for n in ('demand_upper_mm','limit_mm'))
                    and c['demand_upper_mm']>=0 and c['limit_mm']>0 and c['demand_upper_mm']<=c['limit_mm'])
                if not complete:source_results[key]=False
                if c.get('qualified') is not True:pending.append(key+': unqualified source check')
            slot=spans.setdefault(ident,dict(index=row['index'],start_mm=row['start_mm'],end_mm=row['end_mm'],checks=[]))
            for check in row.get('checks',[]):
                c=deepcopy(check);c['source_family']=key
                c['source_action_ledger']=deepcopy(result.get('action_ledgers'))
                c['source_baseline_receipt']=deepcopy(result.get('baseline_receipt'))
                slot['checks'].append(c)
    if len(coverage)==2 and coverage['NBR10084']!=coverage['CMAA74']:
        pending.append('Original source criteria cover different physical spans')
    if expected is not None:
        for key in ('NBR10084','CMAA74'):
            if coverage.get(key,set())!=expected:
                pending.append(key+': physical support-span coverage is incomplete or substituted');source_results[key]=False
    combined['spans']=[spans[k] for k in sorted(spans)]
    manual=apply_project_service_limits(combined,limits)
    requested=bool(limits and any(limits[k] is not None for k in ('vertical_divisor','lateral_divisor')))
    manual_ok=not requested or bool(manual and manual['sufficient_project_service_satisfied'])
    if manual:pending.extend(manual.get('pending',[]))
    passed=all(source_results.values()) and manual_ok and not pending
    return dict(status='SUFFICIENT_ALL_APPLICABLE_SERVICE_CRITERIA_SATISFIED' if passed else 'SERVICE_PENDING' if pending else 'INCONCLUSIVE_SUFFICIENT_BOUND',
        sufficient_member_service_criteria_satisfied=passed,source_criteria_satisfied=source_results,
        project_criteria_required=requested,project_criteria_satisfied=manual_ok,project_service_criteria=manual,
        checks_by_original_source=combined,pending=list(dict.fromkeys(pending)),
        all_original_checks_required=True,different_action_bases_mixed=False,
        local_flange_contact_flexibility_calculated=False,
        deformation_scope='Global beam contact-line displacement relative to same-state end chord; local flange flexibility is not included in the 1D beam response',
        actual_failure_proven=False)
