"""Native NBR 10084:2020 section 10, Table 4(a,d) member criteria.

This is NOT the EN total-characteristic deformation route. The response must
be the same-model increment from the support structure's selfweight-only
configuration, excluding impact and majoration. For a linear model this may
be computed by solving the exact difference of the two right-hand sides,
with homogeneous incremental prescribed displacements. No envelope of two
independent extrema may be subtracted. Actual support/floor alignment and
paired runway differences remain separate obligations.
"""
from copy import deepcopy
from .criteria import _number, _text, _receipt_issues, _governor

SOURCE='ABNT NBR 10084:2020 section 10, Table 4(a,d), printed pages 11-12'
SOURCE_SHA256='7b15fa85b3c5533484659c81fd37c5726bed7dae481ea9ad755053d01abe4be0'
ACTION_BASIS='NBR10084_I_II_no_impact_no_majoration_increment_from_selfweight'
BASELINE='support_structure_selfweight_only_same_linear_operator'
CATEGORIES=('siderurgical_equipment','other_equipment','unclassified_adopt_stricter_L1000')
PLANES=('top_of_actual_rail','actual_underhung_running_plane_adopted')


def _action_issues(ledger,ids):
    if not isinstance(ledger,dict):return ['Internal NBR no-impact incremental action ledger required.']
    issues=[]
    if ledger.get('basis')!=ACTION_BASIS:issues.append('Wrong NBR action/baseline basis.')
    if set(ledger.get('case_ids',()))!=set(ids):issues.append('Direction action case coverage mismatch.')
    for name in ('equipment_characteristic_factor','lifted_characteristic_factor'):
        if type(ledger.get(name)) not in (int,float) or ledger[name]!=1:issues.append(name+' must equal 1.')
    for name in ('partial_factors','dynamic_factors'):
        values=ledger.get(name)
        if not isinstance(values,dict) or not values or any(type(v) not in (int,float) or v!=1 for v in values.values()):
            issues.append('All applicable '+name+' must explicitly equal 1.')
    if ledger.get('horizontal_inertia_dynamic_removed') is not True:issues.append('Complete inertia parcels must have impact/dynamic amplification removed once.')
    mapping=ledger.get('case_category')
    if not isinstance(mapping,dict) or set(mapping)!=set(ids) or any(v not in ('I','II') for v in mapping.values()):
        issues.append('Every covered source case must identify NBR action category I or II.')
    if not isinstance(ledger.get('source'),str) or not ledger['source'].strip():issues.append('Internal action source is missing.')
    return issues


def _baseline_issues(receipt,cases):
    if not isinstance(receipt,dict):return ['Internal same-operator selfweight baseline receipt required.']
    issues=[]
    if receipt.get('basis')!=BASELINE:issues.append('Baseline is not the support structure selfweight-only state.')
    if receipt.get('method') not in ('linear_rhs_difference','same_state_response_difference'):issues.append('Unsupported baseline subtraction method.')
    for flag in ('same_linear_operator','same_contact_coordinates','same_support_constraints','same_state_chord_difference'):
        if receipt.get(flag) is not True:issues.append('Missing baseline consistency: '+flag)
    if set(receipt.get('case_ids',()))!=set(cases):issues.append('Baseline receipt case coverage mismatch.')
    for key in ('operator_signature','baseline_case_signature','incremental_load_signature'):
        if not isinstance(receipt.get(key),str) or not receipt[key].strip():issues.append('Missing internal '+key)
    if receipt.get('method')=='linear_rhs_difference':
        if receipt.get('incremental_selfweight_factor')!=0 or isinstance(receipt.get('incremental_selfweight_factor'),bool):
            issues.append('Structural selfweight must cancel exactly in the incremental right-hand side.')
        if receipt.get('incremental_prescribed_displacements_zero') is not True:
            issues.append('Prescribed displacements shared by both states must cancel in the incremental solution.')
    return issues


def evaluate_span_nbr10084(envelope,*,equipment_category,measurement_plane):
    """Evaluate computed finite-grid engineering maxima, not user proof flags.

    Uses the same envelope/governor shape as criteria.py, adding baseline_receipt.
    A caller MUST derive the receipts internally from its actual solved cases.
    Selecting the stricter L/1000 criterion does not classify the equipment.
    """
    if not isinstance(envelope,dict):raise ValueError('Internal response envelope required')
    if equipment_category not in CATEGORIES:raise ValueError('Explicit equipment category or conservative unclassified policy required')
    if measurement_plane not in PLANES:raise ValueError('Actual running-plane measurement policy required')
    a=_number(envelope['start_mm'],'span start');b=_number(envelope['end_mm'],'span end')
    if not 0<=a<b:raise ValueError('Ordered physical support span required')
    ids=envelope['case_ids']
    if not isinstance(ids,(list,tuple)) or not ids or any(not isinstance(x,str) or not x.strip() for x in ids) or len(set(ids))!=len(ids):
        raise ValueError('Unique internal case IDs required')
    shared=_receipt_issues(envelope.get('producer_receipt'),ids)+_baseline_issues(envelope.get('baseline_receipt'),ids)
    L=b-a;divisor=600. if equipment_category=='other_equipment' else 1000.
    limits={'vertical':min(L/divisor,25.),'horizontal':L/600.}
    checks=[];pending=[]
    for direction in ('vertical','horizontal'):
        subset=envelope[direction+'_case_ids']
        if not isinstance(subset,(list,tuple)) or not subset or len(set(subset))!=len(subset) or not set(subset)<=set(ids):raise ValueError('Invalid direction-specific case IDs')
        value=_number(envelope[direction+'_abs_mm'],direction+' incremental maximum')
        if value<0:raise ValueError('Absolute response maximum must be nonnegative')
        limit=_number(limits[direction],'derived limit',True)
        governor=_governor(envelope[direction+'_governor'],a,b,subset,value,direction)
        issues=shared+_action_issues(envelope.get(direction+'_action_ledger'),subset)
        pending.extend(direction+': '+s for s in issues)
        ratio=_number(value/limit,'deformation utilization')
        checks.append(dict(id='nbr10084_member_'+direction+'_incremental_deformation',demand_mm=value,limit_mm=limit,
            utilization=ratio,qualified=not issues,status=('PASS' if value<=limit else 'FAIL') if not issues else 'PENDING',
            diagnostic_exceeds_limit=value>limit,governor=governor,source=SOURCE,
            baseline='Same-model increment from structural selfweight-only configuration; no impact or majoration.'))
    passed=all(c['status']=='PASS' for c in checks);failed=any(c['status']=='FAIL' for c in checks)
    return dict(status='NBR_MEMBER_DEFORMATION_FAIL' if failed else ('NBR_MEMBER_DEFORMATION_PASS' if passed else 'NBR_MEMBER_DEFORMATION_PENDING'),
        checks=checks,pending=pending,member_deformation_passed=passed,source=SOURCE,source_sha256=SOURCE_SHA256,
        equipment_category=equipment_category,equipment_classification_inferred=False,vertical_limit_divisor=divisor,
        measurement_plane=measurement_plane,underhung_running_plane_is_explicit_model_adoption=measurement_plane=='actual_underhung_running_plane_adopted',
        input_receipt=deepcopy(envelope.get('producer_receipt')),baseline_receipt=deepcopy(envelope.get('baseline_receipt')),
        vertical_action_ledger=deepcopy(envelope.get('vertical_action_ledger')),horizontal_action_ledger=deepcopy(envelope.get('horizontal_action_ledger')),
        continuum_upper_bound_claimed=False,numerical_engineering_result=True,whole_serviceability_qualified=False,
        paired_runway_qualified=False,supporting_floor_qualified=False,precamber_credit_mm=0.,torsion_angle_limit_invented=False,
        separate_scope=['Table 4(b) needs both runway responses for vertical differential.',
          'Table 4(e-h) support movement, adjacent support alignment and runway spacing remain separate.',
          'Equipment clearance, suspension/slip compliance and local contact deformation are not inferred.',
          'A site or client name does not establish siderurgical equipment classification.',
          'A covered I/II member check does not certify unprovided action mechanisms or the supporting building.'])
