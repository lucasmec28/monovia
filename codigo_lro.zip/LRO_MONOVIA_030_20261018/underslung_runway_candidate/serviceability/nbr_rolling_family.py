"""NBR service with its own static three-pair normal-rolling action domain.

Reuse independently verified SAME-STATE contact-line chord response bases,
never force convergence or independently subtracted displacement envelopes.
This consumer does not modify the original displacement proof's source closure.
Rlambda uses its NBR station projection, not CMAA SK or exceptional SHE.
"""
from copy import deepcopy
from dataclasses import asdict
from hashlib import sha256
from pathlib import Path
import math

from ..autonomous_workflow.model import signature
from ..autonomous_workflow.family_envelope import interval_product, interval_sum, assess_sufficient_limit
from ..fatigue.nbr_rolling_family import generate_nbr_rolling_family_coefficients, NBRRollingGuidance
from ..stability.family_adapter import validate_family_receipt
from .family_adapter import _validate_displacement, produce_family_service_evidence, ABS_MM, DIRECTIONS
from .nbr10084_adapter import _check_inputs, _incremental_project
from .nbr10084_criteria import SOURCE, SOURCE_SHA256, ACTION_BASIS, BASELINE


def _require(ok, message):
    if not ok:
        raise ValueError(message)


def _source():
    from .family_adapter import _source as displacement_source
    from ..fatigue.nbr_rolling_family import rolling_source_receipt
    from ..fatigue import nbr_rolling_family as actions
    return dict(displacement=displacement_source(), actions=rolling_source_receipt(),
                actions_sha256=sha256(Path(actions.__file__).read_bytes()).hexdigest(),
                consumer_sha256=sha256(Path(__file__).read_bytes()).hexdigest())


def _interval(value):
    _require(isinstance(value, dict) and set(value) == {'lower', 'upper'},
             'Complete signed interval required')
    _require(all(type(v) in (int, float) and math.isfinite(v) for v in value.values())
             and value['lower'] <= value['upper'], 'Finite ordered signed interval required')
    return value


def compose_rolling_chord_bounds(plan, evidence, coefficients, *, span_index, line_index, direction):
    """Scale the entire verified chord interval AND its allowance by actual c.

    No |c|<=1 assumption: a newly admitted Rlambda demand may exceed the old
    normalization. A zero or unverified basis with nonzero demand is pending.
    """
    _require(direction in DIRECTIONS, 'Recognized chord direction required')
    bases = {b.id: b for b in plan['bases']}
    _require(set(coefficients) == set(bases), 'Complete original mechanical basis coefficients required')
    tolerance = evidence['polynomial_relative_tolerance']
    _require(type(tolerance) in (int, float) and math.isfinite(tolerance) and 0 < tolerance <= 1.e-6,
             'Verified polynomial tolerance required')
    terms, allowances = [], {}
    for ident, coefficient in coefficients.items():
        coefficient = _interval(coefficient)
        magnitude = max(abs(v) for v in coefficient.values())
        if magnitude == 0.:
            continue
        _require(bases[ident].amplitude != 0. and ident in evidence['basis_evidence'],
                 'Nonzero NBR service action requires an independently verified nonzero chord basis: '+ident)
        raw = _interval(evidence['basis_evidence'][ident]['bounds'][span_index][line_index][direction])
        allowance = ABS_MM+tolerance*max(abs(v) for v in raw.values())
        enlarged = dict(lower=math.nextafter(raw['lower']-allowance, -math.inf),
                        upper=math.nextafter(raw['upper']+allowance, math.inf))
        terms.append(interval_product(coefficient, enlarged))
        allowances[ident] = dict(original_allowance_mm=allowance,
            maximum_absolute_coefficient=magnitude, scaled_allowance_mm=magnitude*allowance)
    return dict(signed_bound_mm=interval_sum(terms), verification_allowances=allowances)


def evaluate_family_nbr10084_rolling_serviceability(project, force_receipt, *, physical,
        displacement_receipt=None, rolling_guidance=None, progress=None, **verification_controls):
    """Generate native ELS actions and consume an original independent proof.

    If absent, only the existing audited producer may establish displacement
    evidence. An existing proof is validated unchanged, not re-signed/relabelled.
    """
    result = dict(kind='autonomous_NBR10084_verified_rolling_family_service_consumer',
        status='PENDING_FAMILY_SERVICE', spans=[], pending=[], known_failures=[],
        actual_failure_proven=False, concurrent_governor_claimed=False,
        continuum_upper_bound_claimed=False, numerical_engineering_result=True,
        sufficient_member_service_criteria_satisfied=False, whole_serviceability_complete=False,
        paired_runway_complete=False, supporting_floor_qualified=False, all_case_I_actions_complete=False,
        case_II_complete=False, selected_configuration_only=False, repeated_FE_sweeps=0)
    try:
        _check_inputs(project, physical)
        _require(isinstance(rolling_guidance, NBRRollingGuidance),
                 'Explicit NBRRollingGuidance required; missing physical guidance is not zero rolling action')
        rolling_guidance.validate()
        mass = project.suspended_mass_basis()
        _require(mass['complete_suspended_mass_accounting'], 'Explicit retained suspended B required for service')
        before, source = signature(project.to_dict()), _source()
        incremental = _incremental_project(project, physical)
        _, plan = validate_family_receipt(incremental, force_receipt)
        accessory_factor = 1. if physical.accessory_baseline_policy == 'additional_permanent_action' else 0.
        actions = generate_nbr_rolling_family_coefficients(project, plan, rolling_guidance,
            purpose='service', service_extra_dead_factor=accessory_factor)
        if displacement_receipt is None:
            displacement_receipt = produce_family_service_evidence(project, force_receipt, physical=physical,
                progress=progress, **verification_controls)
        result['displacement_evidence'] = displacement_receipt
        mechanics = _validate_displacement(project, physical, force_receipt, displacement_receipt, plan)
        divisor = 600. if physical.equipment_category == 'other_equipment' else 1000.
        _require({p['pair_id'] for p in actions['pairs']} == {'HX/HY', 'HX/Rlambda', 'HY/Rlambda'}
                 and len(actions['pairs']) == 3, 'All three distinct native horizontal pairs required')
        for span in displacement_receipt['spans']:
            length = span['end_mm']-span['start_mm']; checks = []
            for direction in DIRECTIONS:
                pair_bounds = []
                for pair in actions['pairs']:
                    lines = [dict(**line, **compose_rolling_chord_bounds(plan, displacement_receipt,
                        pair['coefficient_intervals'], span_index=span['index'], line_index=i, direction=direction))
                        for i, line in enumerate(mechanics['contact_lines'])]
                    demand = max(abs(v) for line in lines for v in line['signed_bound_mm'].values())
                    pair_bounds.append(dict(horizontal_pair=pair['horizontal_pair'], pair_id=pair['pair_id'],
                        demand_upper_mm=demand, line_bounds=lines, actual_concurrent_state_claimed=False))
                selected = max(pair_bounds, key=lambda p:p['demand_upper_mm'])
                demand = selected['demand_upper_mm']
                limit = min(length/divisor, 25.) if direction == 'vertical' else length/600.
                check = assess_sufficient_limit(demand, limit)
                check.update(id='nbr10084_rolling_family_'+direction+'_incremental_chord_bound',
                    direction=direction, demand_upper_mm=demand, limit_mm=limit,
                    ratio=divisor if direction == 'vertical' else 600.,
                    absolute_cap_mm=25. if direction == 'vertical' else None,
                    line_bounds=selected['line_bounds'], horizontal_pair_bounds=pair_bounds,
                    governing_bound_pair=selected['pair_id'], governor=None, qualified=True,
                    source=SOURCE, source_sha256=SOURCE_SHA256, action_basis=ACTION_BASIS,
                    scope='Maximum of three separate sufficient response boxes; not an actual concurrent maximum or history')
                checks.append(check)
            result['spans'].append(dict(**span, checks=checks))
        checks = [c for span in result['spans'] for c in span['checks']]
        passed = bool(checks) and all(c['status'] == 'SUFFICIENT_BOUND_SATISFIED' for c in checks)
        result.update(status='SUFFICIENT_FAMILY_SERVICE_CHECKS_SATISFIED' if passed else 'INCONCLUSIVE_SUFFICIENT_BOUND',
            sufficient_member_service_criteria_satisfied=passed, suspended_mass_basis=mass,
            total_configuration_count=actions['total_configuration_count'], total_service_case_count=actions['total_case_count'],
            physical_inputs=asdict(physical), action_ledgers=actions,
            normal_rolling_included=True, source_action_bases_preserved=True,
            baseline_receipt=dict(basis=BASELINE, action_basis=ACTION_BASIS, method='linear_rhs_difference',
                operator_signature=displacement_receipt['operator_signature'], same_linear_operator=True,
                same_support_constraints=True, same_contact_coordinates=True, same_state_chord_difference=True,
                incremental_selfweight_factor=0., incremental_extra_dead_factor=accessory_factor,
                accessory_baseline_policy=physical.accessory_baseline_policy,
                incremental_prescribed_displacements_zero=True,
                original_prescribed_support_values=[dict(id=s['id'], restrain=deepcopy(s['restrain'])) for s in project.supports],
                independently_enveloped_scalars_subtracted=False),
            source_receipt=dict(displacement_receipt_signature=displacement_receipt['receipt_signature'],
                force_receipt_signature=force_receipt['receipt_signature'], source=source),
            separate_scope=['Source case II service wind and applicable temperature are not generated.',
                'Paired-runway differential, supporting-floor movement, alignment, clearances and local joint/contact compliance remain separate.',
                'Normal Rlambda projection qualifies linear global chord displacement, not local lateral force transfer or stability load radius.'])
        _require(before == signature(project.to_dict()) and source == _source(),
                 'Project or NBR rolling service source changed during consumption')
    except (ValueError, TypeError, KeyError, ArithmeticError, AttributeError, IndexError) as exc:
        result.update(status='PENDING_FAMILY_SERVICE', spans=[], sufficient_member_service_criteria_satisfied=False)
        result['pending'].append(type(exc).__name__+': '+str(exc))
    return result
