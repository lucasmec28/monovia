"""EN1993-6:2007 member deformation criteria on INTERNAL numerical envelopes.

Table7.2(a): min(L/600,25mm), characteristic actions without dynamic factors.
Table7.1(a)'s L/600 at top rail is adapted to the actual underhung running plane
ONLY as an explicitly adopted project criterion. This does not invent a twist
limit, paired-runway response, support-settlement check or building design.
The caller supplies an internally generated numerical engineering receipt, not
an external deformation value or user completion switch.
"""
from math import isfinite,isclose
from copy import deepcopy

SOURCE='EN1993-6:2007+AC:2009 7.1-7.3, Table7.2(a); Table7.1(a) separately adopted analogous underhung horizontal criterion'
PRODUCER='moving_mesh_converged_displacement_v1'
ACTION_BASIS='EN6_characteristic_no_dynamics'


def _number(v,label,positive=False):
    try:ok=not isinstance(v,bool) and isinstance(v,(int,float)) and isfinite(v) and (not positive or v>0)
    except (TypeError,ValueError,OverflowError):ok=False
    if not ok:raise ValueError('Finite '+('positive ' if positive else '')+label+' required')
    return float(v)


def _text(v,label):
    if not isinstance(v,str) or not v.strip():raise ValueError(label+' required')
    return v


def _receipt_issues(r,case_ids):
    issues=[]
    if not isinstance(r,dict):return ['Internal numerical displacement receipt is required.']
    if r.get('producer_kind')!=PRODUCER:issues.append('Unsupported internal displacement producer.')
    for k in ('input_signature','solver_source_hash','producer_source_hash'):
        if not isinstance(r.get(k),str) or not r[k].strip():issues.append('Missing receipt '+k)
    for k in ('moving_converged','mesh_converged','event_coverage_complete','spatial_coverage_complete','same_state_end_chord'):
        if r.get(k) is not True:issues.append('Unqualified numerical coverage: '+k)
    if r.get('continuum_upper_bound_claimed') is not False:issues.append('This numerical route must not claim a rigorous continuum upper bound.')
    if set(r.get('case_ids',()))!=set(case_ids):issues.append('Case coverage differs from the displacement envelope.')
    try:
        tol=_number(r['relative_tolerance'],'relative tolerance',True)
        if tol>.01:issues.append('Numerical deformation tolerance exceeds adopted1%.')
        hist=r['mesh_history']
        if not isinstance(hist,list) or len(hist)<3:raise ValueError('At least three mesh levels required')
        for row in hist[-2:]:
            change=_number(row['maximum_relative_change'],'mesh change')
            if not 0<=change<=tol:issues.append('Two accepted consecutive mesh changes required.')
        if type(r['stable_passes']) is not int or r['stable_passes']<2:issues.append('Two stable mesh passes required.')
    except (ValueError,TypeError,KeyError) as exc:issues.append('Invalid numerical convergence receipt: '+str(exc))
    return issues


def _action_issues(ledger,case_ids,*,horizontal=False):
    if not isinstance(ledger,dict):return ['Internal characteristic no-dynamic action ledger required.']
    issues=[]
    required='EN6_characteristic_horizontal' if horizontal else ACTION_BASIS
    if ledger.get('basis')!=required:issues.append('Wrong characteristic action basis for this deformation direction.')
    if set(ledger.get('case_ids',()))!=set(case_ids):issues.append('Action ledger case coverage mismatch.')
    for key in ('equipment_characteristic_factor','lifted_characteristic_factor','selfweight_characteristic_factor'):
        if ledger.get(key)!=1 or isinstance(ledger.get(key),bool):issues.append('Full characteristic '+key+' must equal1; no quasi-permanent reduction.')
    vals=ledger.get('partial_factors')
    if not isinstance(vals,dict) or not vals or any(v!=1 or isinstance(v,bool) for v in vals.values()):
        issues.append('Every applicable partial factor must explicitly equal1.')
    vals=ledger.get('dynamic_factors')
    if not isinstance(vals,dict) or not vals:issues.append('Applicable dynamic factors are missing.')
    else:
        try:
            numbers=[_number(v,'dynamic factor',True) for v in vals.values()]
            if horizontal and any(v<1 for v in numbers):issues.append('Horizontal characteristic dynamics cannot reduce an action in this bounded preset.')
            if not horizontal and any(v!=1 for v in numbers):issues.append('Vertical criterion requires all dynamic factors equal1.')
        except ValueError as exc:issues.append(str(exc))
    if horizontal:
        if ledger.get('source_qualified_characteristic_dynamics') is not True:
            issues.append('Horizontal characteristic dynamics have not been internally qualified; the vertical no-dynamic case is insufficient.')
    elif ledger.get('horizontal_inertia_dynamic_removed') is not True:
        issues.append('Correlated horizontal/vertical drive-inertia parcels must have their dynamic multiplier removed once.')
    if not isinstance(ledger.get('source'),str) or not ledger['source'].strip():issues.append('Action source/derivation missing.')
    return issues


def _governor(g,start,end,case_ids,demand,label):
    if not isinstance(g,dict):raise ValueError(label+' actual governing state required')
    if g.get('case_id') not in case_ids:raise ValueError(label+' case is not covered')
    x=_number(g['x_mm'],label+' coordinate')
    _number(g['translation_mm'],label+' wheel translation')
    if not start<=x<=end:raise ValueError(label+' coordinate outside span')
    if g.get('outstand_side') not in ('left','right'):raise ValueError('Actual physical running line required')
    for key in ('line_y_mm','line_z_mm'):_number(g[key],key)
    displacement=_number(g['displacement_mm'],label+' displacement')
    left=_number(g['end_left_mm'],label+' left chord displacement')
    right=_number(g['end_right_mm'],label+' right chord displacement')
    relative=_number(g['relative_mm'],label+' chord-relative displacement')
    expected=displacement-left-(right-left)*(x-start)/(end-start)
    if not isclose(relative,expected,rel_tol=1e-10,abs_tol=1e-9):raise ValueError(label+' is not measured from the SAME-state end chord')
    if demand+1e-9<abs(relative):raise ValueError(label+' envelope is below its own governing state')
    return deepcopy(g)


def evaluate_span_serviceability(envelope,*,lateral_project_limit_adopted=False):
    """Evaluate one actual support interval, retaining continuous-frame demands.

    envelope keys: start_mm/end_mm, case_ids, vertical_abs_mm/horizontal_abs_mm,
    vertical_governor/horizontal_governor (signed same-state chord data),
    producer_receipt, vertical_case_ids/horizontal_case_ids,
    vertical_action_ledger/horizontal_action_ledger,
    prescribed_support_movements_nonzero.
    Maxima are separate criterion governors, never a fabricated concurrent state.
    No precamber credit is taken. Paired runway and support alignment remain
    distinct scopes even when these member deformation comparisons pass.
    """
    if not isinstance(envelope,dict):raise ValueError('Internal displacement envelope required')
    if type(lateral_project_limit_adopted) is not bool:raise ValueError('Explicit lateral criterion adoption required')
    a=_number(envelope['start_mm'],'span start');b=_number(envelope['end_mm'],'span end')
    if not 0<=a<b:raise ValueError('Ordered positive physical span required')
    cases=envelope['case_ids']
    if not isinstance(cases,(list,tuple)) or not cases or any(not isinstance(c,str) for c in cases) or len(set(cases))!=len(cases):raise ValueError('Unique source cases required')
    for c in cases:_text(c,'case identity')
    v=_number(envelope['vertical_abs_mm'],'vertical maximum');h=_number(envelope['horizontal_abs_mm'],'horizontal maximum')
    if min(v,h)<0:raise ValueError('Absolute deformation maxima cannot be negative')
    if type(envelope.get('prescribed_support_movements_nonzero')) is not bool:raise ValueError('Actual support-movement state required')
    direction_cases={}
    for direction in ('vertical','horizontal'):
        subset=envelope[direction+'_case_ids']
        if not isinstance(subset,(list,tuple)) or not subset or any(not isinstance(c,str) for c in subset) or len(set(subset))!=len(subset) or not set(subset)<=set(cases):
            raise ValueError('Valid direction-specific characteristic case IDs required')
        direction_cases[direction]=subset
    governors={key:_governor(envelope[key+'_governor'],a,b,direction_cases[key],demand,key) for key,demand in (('vertical',v),('horizontal',h))}
    shared=_receipt_issues(envelope.get('producer_receipt'),cases)
    direction_issues={key:shared+_action_issues(envelope.get(key+'_action_ledger'),direction_cases[key],horizontal=key=='horizontal') for key in ('vertical','horizontal')}
    pending=[key+': '+msg for key in direction_issues for msg in direction_issues[key]]
    L=b-a;limits={'vertical':min(L/600.,25.),'horizontal':L/600.};checks=[]
    for limit in limits.values():_number(limit,'derived deformation limit',True)
    for direction,demand in (('vertical',v),('horizontal',h)):
        qualified=not direction_issues[direction] and (direction=='vertical' or lateral_project_limit_adopted)
        ratio=_number(demand/limits[direction],'deformation utilization')
        checks.append(dict(id='member_'+direction+'_deformation',demand_mm=demand,limit_mm=limits[direction],
            utilization=ratio,qualified=qualified,
            status=('PASS' if demand<=limits[direction] else 'FAIL') if qualified else 'PENDING',
            diagnostic_exceeds_limit=demand>limits[direction],governor=governors[direction],
            basis='EN6 Table7.2(a) recommended project limit' if direction=='vertical' else 'Explicit analogous underhung project limit based on EN6 Table7.1(a), measured at actual running plane'))
    if not lateral_project_limit_adopted:pending.append('Underhung horizontal running-plane L/600 analogous project criterion not adopted.')
    scope=[dict(id='paired_runway',reason='Vertical differential and change of bridge runway spacing require both actual runway/support responses; not inferred from one rail.'),
           dict(id='supporting_structure',reason='Receiver/floor movement, adjacent support alignment and stiffness compatibility are separate from this runway-member calculation.'),
           dict(id='local_and_joint_service',reason='Local contact deformation, bolt/slip compliance, disturbed support zones and equipment clearances are not supplied by this global member deformation criterion.')]
    if envelope['prescribed_support_movements_nonzero']:
        scope.append(dict(id='prescribed_movement',reason='Nonzero known support movement is included in each same-state end chord. Chord subtraction does not qualify absolute runway alignment or differential settlement.'))
    known_failure=any(c['status']=='FAIL' for c in checks)
    return dict(status='MEMBER_DEFORMATION_FAIL' if known_failure else ('MEMBER_DEFORMATION_PASS' if all(c['status']=='PASS' for c in checks) else 'MEMBER_DEFORMATION_PENDING'),
        checks=checks,pending=pending,separate_scope=scope,source=SOURCE,span_mm=L,
        member_vertical_qualified=checks[0]['qualified'],member_horizontal_qualified=checks[1]['qualified'],
        member_deformation_passed=all(c['status']=='PASS' for c in checks),precamber_credit_mm=0.,
        numerical_engineering_result=True,continuum_upper_bound_claimed=False,
        whole_serviceability_qualified=False,paired_runway_qualified=False,supporting_floor_qualified=False,
        torsion_angle_limit_invented=False,input_receipt=deepcopy(envelope.get('producer_receipt')),
        vertical_action_ledger=deepcopy(envelope.get('vertical_action_ledger')),
        horizontal_action_ledger=deepcopy(envelope.get('horizontal_action_ledger')))
