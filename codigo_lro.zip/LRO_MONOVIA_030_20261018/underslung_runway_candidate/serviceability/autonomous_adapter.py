"""Internal physical-input service cases and same-state member deformation checks.

Separate EN vertical no-dynamic and horizontal characteristic dynamic ledgers.
Only the selected declared bridge configuration is assessed here. No external
forces, fabricated paired-runway differential, or inferred support stiffness.
"""
from dataclasses import dataclass,asdict
from pathlib import Path
from hashlib import sha256
from ..autonomous_workflow.model import finite,checked_text,MovingCase,signature
from ..autonomous_workflow.pipeline import analyze_cases,AnalysisControls,source_receipt
from .criteria import evaluate_span_serviceability,PRODUCER,ACTION_BASIS

SOURCE='EN1993-6:2007+AC:2009 7.3 Tables7.1(a)/7.2(a); EN13001-2:2014 4.2.2.1-2,4.2.2.5 source-bounded normal drive scenario'

@dataclass(frozen=True)
class ENServicePhysicalInputs:
    hoist_speed_max_m_s:float
    operating_domain:str
    hoist_mass_scope:str
    method_adoption_source:str
    drive_source:str
    lateral_project_limit_adopted:bool
    def validate(self):
        if finite(self.hoist_speed_max_m_s,'Maximum physical hoist speed')<0:raise ValueError('Nonnegative physical hoist speed required')
        if self.operating_domain!='indoor_smooth_track_no_release_no_impacts_normal_operation':raise ValueError('Named smooth-track normal-operation domain required')
        if self.hoist_mass_scope not in ('capacity_mass_includes_all_suspended_attachments','payload_plus_retained_common_ledger'):raise ValueError('Explicit physical hoist mass accounting required')
        checked_text(self.method_adoption_source,'Service project-criterion adoption source')
        checked_text(self.drive_source,'Drive/normal operating source')
        if type(self.lateral_project_limit_adopted) is not bool:raise ValueError('Explicit lateral analogous project-criterion choice required')
        return self


def generate_service_cases(project,physical):
    project.validate();physical.validate()
    mass=project.suspended_mass_basis()
    if physical.hoist_mass_scope!='payload_plus_retained_common_ledger' or not mass['complete_suspended_mass_accounting']:
        raise ValueError('EN service requires separate payload and explicit retained suspended mass/point; legacy empty-state accounting is incomplete')
    ledger=project.bridge_reaction_ledger
    if not ledger or ledger.get('schema')!='LRO_BOUND_BRIDGE_INERTIA_LEDGER_V1':raise ValueError('Physical bridge inertia ledger required to remove/rebuild horizontal dynamics once; manual wheel forces do not identify that split')
    k=ledger['inputs']['horizontal_dynamic_factor']
    phi2=1.2+.68*physical.hoist_speed_max_m_s
    finite(phi2,'Bounded EN hoist factor')
    sx=(-1,1) if any(w.longitudinal_N or w.longitudinal_empty_N or w.longitudinal_vertical_N or w.longitudinal_vertical_empty_N for w in project.wheels) else (1,)
    sy=(-1,1) if any(w.transverse_N or w.transverse_empty_N or w.transverse_vertical_N or w.transverse_vertical_empty_N for w in project.wheels) else (1,)
    result=[];ids={'vertical':[],'horizontal':[]}
    # For |Si|,|Sf| <= Smax and 1<=phi5<=3, the source expression
    # Si+phi5(Sf-Si) is bounded by5*Smax, including drive reversal.
    for direction,gd,qd,hd in (('vertical',1.,1.,1.),('horizontal',1.1,phi2,5.)):
        for loaded in (True,False):
            for hx in sx:
                for hy in sy:
                    ident=f'EN_SERVICE/{direction}/{"loaded" if loaded else "empty"}/HX{hx:+d}/HY{hy:+d}'
                    result.append(MovingCase(ident,'EN_SERVICE',1.,gd,qd if loaded else 0.,hd/k,hd/k,hx,hy,loaded,SOURCE+'; '+physical.method_adoption_source+'; '+physical.drive_source,1.,retained_lifted=qd))
                    ids[direction].append(ident)
    common=dict(equipment_characteristic_factor=1.,lifted_characteristic_factor=1.,selfweight_characteristic_factor=1.,partial_factors={'G':1.,'Q':1.,'H':1.},source=SOURCE+'; '+physical.method_adoption_source,suspended_mass_accounting=mass)
    vertical=dict(common,basis=ACTION_BASIS,case_ids=ids['vertical'],dynamic_factors={'phi1':1.,'phi2':1.,'phi5':1.},horizontal_inertia_dynamic_removed=True)
    horizontal=dict(common,basis='EN6_characteristic_horizontal',case_ids=ids['horizontal'],dynamic_factors={'phi1':1.1,'phi2':phi2,'phi5_reversal':5.},source_qualified_characteristic_dynamics=True,
        drive_basis='Source upper effect bound5Smax from Si+phi5(Sf-Si), not an actual measured dynamic factor',original_H_multiplier_removed_once=k)
    return tuple(result),vertical,horizontal


def _governor(row):
    return dict(case_id=row['case_id'],translation_mm=row['translation_mm'],x_mm=row['x_mm'],
        outstand_side='left' if row['y_mm']<0 else 'right',line_y_mm=row['y_mm'],line_z_mm=row['z_mm'],
        displacement_mm=row['absolute_contact_displacement_mm'],end_left_mm=row['endpoint_contact_displacements_mm'][0],
        end_right_mm=row['endpoint_contact_displacements_mm'][1],relative_mm=row['value'])


def evaluate_autonomous_serviceability(project,*,physical,controls=None,progress=None):
    if not isinstance(physical,ENServicePhysicalInputs):raise ValueError('Physical EN service inputs required')
    project_start=signature(project.to_dict())
    start=source_receipt();own=sha256(Path(__file__).read_bytes()+Path(__file__).with_name('criteria.py').read_bytes()).hexdigest()
    cases,vertical,horizontal=generate_service_cases(project,physical)
    run=analyze_cases(project,cases,controls=controls,progress=progress)
    controls=AnalysisControls() if controls is None else AnalysisControls(**controls) if isinstance(controls,dict) else controls
    ids=[c.id for c in cases];rows=run['cases'];pending=[];spans={}
    good=all(r['numerical_converged'] and r['sweep'] is not None for r in rows)
    if not good:pending.append('Moving-position/spatial/mesh convergence is incomplete for required service cases.')
    for row in rows:
        direction='vertical' if row['case']['id'] in vertical['case_ids'] else 'horizontal'
        suffix='/relative_w' if direction=='vertical' else '/relative_v'
        for key,pair in (row.get('sweep') or {}).get('extrema',{}).items():
            if not key.startswith('service_span/') or not key.endswith(suffix):continue
            index=int(key.split('/',2)[1]);slot=spans.setdefault(index,{})
            for governor in pair.values():
                old=slot.get(direction)
                if old is None or abs(governor['value'])>abs(old['value']):slot[direction]=governor
    histories=[r['mesh_history'] for r in rows]
    # Aggregate each case's FINAL two accepted mesh comparisons, not the
    # same index across cases that may have required different mesh budgets.
    history=([{},*[dict(maximum_relative_change=(max(h[i]['mesh_relative_change'] for h in histories) if all(h[i].get('mesh_relative_change') is not None for h in histories) else None)) for i in (-2,-1)]]
             if histories and all(len(h)>=3 for h in histories) else [])
    receipt=dict(producer_kind=PRODUCER,input_signature=signature(project.to_dict()),solver_source_hash=rows[0]['mesh_history'][-1]['solver_source_hash'] if rows and rows[0]['mesh_history'] else '',producer_source_hash=own,
        moving_converged=good,mesh_converged=good,event_coverage_complete=good,spatial_coverage_complete=good,same_state_end_chord=True,continuum_upper_bound_claimed=False,
        case_ids=ids,relative_tolerance=max(controls.moving_tolerance,controls.mesh_tolerance),mesh_history=history,stable_passes=min((h[-1]['stable_passes'] for h in histories if h),default=0))
    support_x=sorted({float(s['x']) for s in project.supports})
    expected_spans=set(range(max(0,len(support_x)-1)))
    missing_spans=expected_spans-set(spans)
    if missing_spans:pending.append('Missing service envelope for actual support spans: '+str(sorted(missing_spans)))
    if set(spans)-expected_spans:raise ValueError('Service result contains a span absent from the physical support model')
    if not support_x or support_x[0]!=0. or support_x[-1]!=project.length_mm:pending.append('Cantilever/unsupported-end service regions are outside these support-to-support criteria.')
    known_movement=any(any(v!=0 for v in s['restrain'].values()) for s in project.supports)
    results=[]
    for index,slot in sorted(spans.items()):
        if set(slot)!={'vertical','horizontal'}:
            pending.append('Span '+str(index)+' lacks an actual required direction governor');continue
        v=slot['vertical'];h=slot['horizontal']
        envelope=dict(start_mm=v['span_start_mm'],end_mm=v['span_end_mm'],case_ids=ids,vertical_case_ids=vertical['case_ids'],horizontal_case_ids=horizontal['case_ids'],
            vertical_abs_mm=abs(v['value']),horizontal_abs_mm=abs(h['value']),vertical_governor=_governor(v),horizontal_governor=_governor(h),
            prescribed_support_movements_nonzero=known_movement,producer_receipt=receipt,vertical_action_ledger=vertical,horizontal_action_ledger=horizontal)
        results.append(evaluate_span_serviceability(envelope,lateral_project_limit_adopted=physical.lateral_project_limit_adopted))
    end=source_receipt();own_after=sha256(Path(__file__).read_bytes()+Path(__file__).with_name('criteria.py').read_bytes()).hexdigest()
    if signature(project.to_dict())!=project_start:raise ValueError('Physical project changed during service calculation; fresh run required')
    if start['fingerprint']!=end['fingerprint'] or own!=own_after:raise ValueError('Service numerical source changed during calculation; fresh run required')
    return dict(status='AUTONOMOUS_MEMBER_SERVICE_CHECKS' if results else 'SERVICE_NUMERICAL_PENDING',spans=results,pending=pending,
        physical_inputs=asdict(physical),case_ledgers=dict(vertical=vertical,horizontal=horizontal),
        case_run=run,source=start,service_source_hash=own,source_unchanged_during_calculation=True,
        selected_configuration_only=True,paired_runway_complete=False,supporting_floor_outside_scope=True,whole_serviceability_complete=False,
        known_failures=[c for r in results for c in r['checks'] if c['status']=='FAIL'])
