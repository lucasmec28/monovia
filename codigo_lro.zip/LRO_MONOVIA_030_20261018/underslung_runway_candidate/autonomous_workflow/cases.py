"""Normal-operation cases from existing reviewed factor functions, not geometry.

No underhung support, wheel sharing, global response or load height is borrowed
from the top-running core. Wind/tests/emergency/endstop are separate obligations.
"""
from .model import MovingCase


def generate_normal_cases(wheels,*,psi,equipment_group,classification_source,include_8800=True,
                          extra_dead_N_per_mm=0.,extra_dead_kind='steel_or_equipment'):
    if not isinstance(classification_source,str) or not classification_source.strip():
        raise ValueError('Explicit adopted/confirmed dynamics and duty provenance required')
    from lro_beams.autonomous_actions import factors_10084,factors_8800,variants_8800
    factors=[('I',factors_10084('I',psi=psi,equipment_group=equipment_group)),
             ('SLS10084',factors_10084('service_10084',psi=psi)),
             ('FAT8400',factors_10084('fatigue_8400',psi=psi))]
    if include_8800:
        factors.append(('SLS8800',factors_8800('service_rare',psi=psi,extra_dead_kind=extra_dead_kind)))
        # Numerically 1 N/mm = 1 kN/m. An absent origin has zero coefficient
        # in the source helper; therefore its actual presence cannot be omitted.
        factors.extend(('ULS8800',a) for a in variants_8800(psi=psi,
            extra_dead_kn_per_m=extra_dead_N_per_mm,extra_dead_kind=extra_dead_kind))
    sx=(-1,1) if any(w.longitudinal_N or w.longitudinal_empty_N or w.longitudinal_vertical_N or w.longitudinal_vertical_empty_N for w in wheels) else (1,)
    sy=(-1,1) if any(w.transverse_N or w.transverse_empty_N or w.transverse_vertical_N or w.transverse_vertical_empty_N for w in wheels) else (1,)
    result=[]
    for family,a in factors:
        for loaded in (True,False):
            for hx in sx:
                for hy in sy:
                    ident=f'{family}/{a.code}/{"loaded" if loaded else "empty"}/HX{hx:+d}/HY{hy:+d}'
                    result.append(MovingCase(ident,family,a.dead_support,a.dead_equipment,a.lifted if loaded else 0.,
                        a.longitudinal,a.transverse,hx,hy,loaded,a.source+'; '+classification_source,a.extra_dead,retained_lifted=a.lifted))
    return tuple(result)
