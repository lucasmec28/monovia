"""User-facing orchestration of the internally verified all-configuration route.

This route computes physical actions, never accepts imported demands or proof
flags, and preserves separately identified sufficient component-box outcomes.
It does not silently reuse its NBR action boxes as fatigue or service inputs.
"""
from dataclasses import asdict, replace
from hashlib import sha256
from pathlib import Path
import time
from .model import signature
from .family_envelope import produce_family_envelope,VERIFIED,_source
from .family_local import evaluate_family_local
from ..stability.family_adapter import evaluate_family_member,validate_family_receipt


def _own_source(consumer_names=()):
    root=Path(__file__).resolve().parents[1]
    names=['autonomous_workflow/family_pipeline.py','autonomous_workflow/member_scope.py','autonomous_workflow/family_local.py','stability/family_adapter.py']
    optional={
        'fatigue':['fatigue/family_adapter.py'],
        'nbr_fatigue':['fatigue/nbr_member.py','fatigue/nbr_rolling_family.py','autonomous_workflow/nbr_rolling.py'],
        'service':['serviceability/family_adapter.py','serviceability/nbr10084_adapter.py',
            'serviceability/nbr10084_criteria.py','serviceability/criteria.py','serviceability/project_limits.py',
            'serviceability/cmaa_family.py','serviceability/aggregate.py','serviceability/nbr_rolling_family.py',
            'fatigue/nbr_rolling_family.py','autonomous_workflow/nbr_rolling.py'],
        'beam_support':['beam_support/__init__.py','beam_support/model.py','beam_support/kernels.py','beam_support/inputs.py','beam_support/adapter.py'],
        'cmaa':['cmaa74/family_adapter.py','cmaa74/kernel.py','cmaa74/actions.py','cmaa74/nbr_global.py','autonomous_ui/cmaa_inputs.py']}
    for key in consumer_names:names.extend(optional[key])
    out={name:sha256((root/name).read_bytes()).hexdigest() for name in names}
    if 'nbr_fatigue' in consumer_names:
        import lro_beams.autonomous_fatigue as runtime_fatigue
        out['lro_beams/autonomous_fatigue.py']=sha256(Path(runtime_fatigue.__file__).read_bytes()).hexdigest()
    if 'cmaa' in consumer_names or 'beam_support' in consumer_names:
        from ..cmaa74.nbr_global import consumer_source
        out.update({'cmaa_global_dependency/'+k:v for k,v in consumer_source()['files'].items()})
    if 'beam_support' in consumer_names:
        from ..beam_support.adapter import beam_support_source_receipt
        out['beam_support_dependency_fingerprint']=beam_support_source_receipt()['fingerprint']
    return out


def _optional_consumers(project,producer,*,native_service_physical=None,cmaa_physical=None,
                        cmaa_mass_accounting=None,service_displacement_receipt=None,progress=None,fatigue_physical=None,nbr_rolling_guidance=None):
    fatigue=service=cmaa=cmaa_service=cmaa_global=None
    if fatigue_physical is not None or project.en_fatigue_inputs is not None:
        from ..fatigue.autonomous_adapter import ENPhysicalFatigueInputs
        from ..fatigue.family_adapter import evaluate_family_fatigue
        fatigue=evaluate_family_fatigue(project,producer,physical=fatigue_physical or ENPhysicalFatigueInputs(**project.en_fatigue_inputs))
    if native_service_physical is not None:
        from ..serviceability.nbr_rolling_family import evaluate_family_nbr10084_rolling_serviceability
        service=evaluate_family_nbr10084_rolling_serviceability(project,producer,physical=native_service_physical,
            displacement_receipt=service_displacement_receipt,rolling_guidance=nbr_rolling_guidance,progress=progress)
    if cmaa_physical is not None:
        from ..cmaa74.family_adapter import evaluate_cmaa74_family
        from ..autonomous_ui.cmaa_inputs import prepare_cmaa74_action_project
        if not isinstance(cmaa_mass_accounting,dict):raise ValueError('Explicit CMAA payload/block mass accounting required')
        private,conversion=prepare_cmaa74_action_project(project,cmaa_physical,**cmaa_mass_accounting)
        cmaa=evaluate_cmaa74_family(project,producer,physical=cmaa_physical,
            cmaa_action_project=private,cmaa_conversion_receipt=conversion)
        from ..cmaa74.nbr_global import evaluate_cmaa_nbr_global
        cmaa_global=evaluate_cmaa_nbr_global(project,producer,physical=cmaa_physical,
            cmaa_action_project=private,cmaa_conversion_receipt=conversion)
        from ..serviceability.cmaa_family import evaluate_cmaa_family_serviceability
        displacement=(service or {}).get('displacement_evidence') or service_displacement_receipt
        cmaa_service=evaluate_cmaa_family_serviceability(project,producer,physical=cmaa_physical,
            displacement_receipt=displacement,cmaa_action_project=private,cmaa_conversion_receipt=conversion)
    return fatigue,service,cmaa,cmaa_service,cmaa_global


def run_family_workflow(project,*,psi,equipment_group,classification_source,include_8800=True,
                        controls=None,progress=None,native_service_physical=None,cmaa_physical=None,
                        cmaa_mass_accounting=None,verified_basis_receipt=None,service_displacement_receipt=None,
                        service_project_limits=None,fatigue_physical=None,nbr_fatigue_physical=None,nbr_rolling_guidance=None,beam_support_physical=None):
    project.validate();before=signature(project.to_dict());started=time.monotonic()
    if nbr_fatigue_physical is not None:
        declared=getattr(nbr_fatigue_physical,'rolling_guidance',None)
        if nbr_rolling_guidance is None:
            nbr_rolling_guidance=declared
        elif declared is None:
            nbr_fatigue_physical=replace(nbr_fatigue_physical,rolling_guidance=nbr_rolling_guidance)
        elif asdict(declared)!=asdict(nbr_rolling_guidance):
            raise ValueError('NBR fatigue and service must share the same declared physical guidance, not conflicting action geometry')
    if beam_support_physical is not None:
        from ..beam_support.adapter import map_project_inputs
        beam_support_physical=map_project_inputs(project,beam_support_physical)[0]
    consumer_names=tuple(key for key,enabled in (('fatigue',project.en_fatigue_inputs is not None or fatigue_physical is not None),
        ('nbr_fatigue',nbr_fatigue_physical is not None),('beam_support',beam_support_physical is not None),
        ('service',native_service_physical is not None or service_project_limits is not None or cmaa_physical is not None),('cmaa',cmaa_physical is not None)) if enabled)
    own=_own_source(consumer_names)
    if verified_basis_receipt is None:
        producer=produce_family_envelope(project,psi=psi,equipment_group=equipment_group,
            classification_source=classification_source,include_8800=include_8800,controls=controls,progress=progress)
    else:
        # Reconsume unchanged internal mechanics; never re-sign or relabel its
        # original calculation/source/elapsed-time receipt as a new FE run.
        validate_family_receipt(project,verified_basis_receipt)
        producer=verified_basis_receipt
        if controls is not None:
            from .pipeline import AnalysisControls
            c=AnalysisControls(**controls) if isinstance(controls,dict) else controls
            if c.moving_stable_passes>2 or c.mesh_stable_passes>2:
                raise ValueError('A stronger requested stability count needs a new producer run')
            for row in producer['basis_evidence'].values():
                if row['verification']['producer_receipt']['relative_tolerance']>min(c.moving_tolerance,c.mesh_tolerance):
                    raise ValueError('Saved mechanical tolerance is weaker than the requested new tolerance')
        from .family_envelope import build_family_plan
        requested=build_family_plan(project,psi=psi,equipment_group=equipment_group,
            classification_source=classification_source,include_8800=include_8800)
        if producer['generated_input_signature']!=requested['generated_input_signature'] or producer['action_generation']!=requested['action_generation']:
            raise ValueError('Saved physical bases belong to different requested action factors')
    member=evaluate_family_member(project,producer)
    local=evaluate_family_local(project,producer)
    fatigue,service,cmaa,cmaa_service,cmaa_global=_optional_consumers(project,producer,native_service_physical=native_service_physical,
        cmaa_physical=cmaa_physical,cmaa_mass_accounting=cmaa_mass_accounting,
        service_displacement_receipt=service_displacement_receipt,progress=progress,fatigue_physical=fatigue_physical,nbr_rolling_guidance=nbr_rolling_guidance)
    nbr_fatigue=None
    if nbr_fatigue_physical is not None:
        from ..fatigue.nbr_member import evaluate_nbr_family_fatigue
        nbr_fatigue=evaluate_nbr_family_fatigue(project,producer,physical=nbr_fatigue_physical)
    beam_support=None
    if beam_support_physical is not None:
        from ..beam_support.adapter import evaluate_family_beam_support
        private=conversion=None
        if cmaa_physical is not None:
            from ..autonomous_ui.cmaa_inputs import prepare_cmaa74_action_project
            private,conversion=prepare_cmaa74_action_project(project,cmaa_physical,**cmaa_mass_accounting)
        beam_support=evaluate_family_beam_support(project,producer,physical=beam_support_physical,
            cmaa_physical=cmaa_physical,cmaa_action_project=private,cmaa_conversion_receipt=conversion)
    fatigue_selected=nbr_fatigue if nbr_fatigue_physical is not None else fatigue
    from ..serviceability.project_limits import validate_project_limits,apply_project_service_limits
    service_project_limits=validate_project_limits(service_project_limits)
    from ..serviceability.aggregate import aggregate_member_service
    support_x=sorted({float(s['x']) for s in project.supports})
    expected_spans=[(i,a,b) for i,(a,b) in enumerate(zip(support_x[:-1],support_x[1:]))]
    service_summary=aggregate_member_service(service,cmaa_service,service_project_limits,expected_spans=expected_spans)
    project_service=service_summary['project_service_criteria']
    valid=producer['evidence_kind']==VERIFIED
    pending=list(producer['pending'])+member.get('pending',[])+local.get('pending',[])
    selected_global=cmaa_global if cmaa_physical is not None else member
    scope=dict(all_eight_physical_configurations_numerically_verified=valid,
        all_generated_normal_cases_included=valid,
        sufficient_global_member_criteria_satisfied=selected_global['sufficient_member_criteria_satisfied'],
        sufficient_global_nominal_section_criteria_satisfied=selected_global['sufficient_nominal_section_criteria_satisfied'],
        sufficient_NBR_lower_flange_nominal_points_satisfied=local['sufficient_prescribed_nominal_points_satisfied'],
        fatigue_all_configuration_scope_complete=False,service_all_configuration_scope_complete=False,
        sufficient_all_configuration_plain_nominal_fatigue_satisfied=bool(fatigue_selected and fatigue_selected.get('qualified_nominal_detail_modes')),
        sufficient_all_configuration_native_normal_service_satisfied=bool(service and service.get('sufficient_member_service_criteria_satisfied')),
        sufficient_all_applicable_service_satisfied=service_summary['sufficient_member_service_criteria_satisfied'],
        cmaa_nominal_family_assessed=cmaa is not None,
        beam_support_scalar_assessed=beam_support is not None,
        beam_support_scalar_bound_satisfied=bool(beam_support and beam_support.get('scalar_bending_status')=='SUFFICIENT_HOLE_BENDING_BOUND_SATISFIED'),
        suspension_beam_region_qualified=False,
        wheel_contact_complete=False,suspension_connection_strength_complete=False,
        receiving_building_outside_component_scope=True,whole_design_complete=False,
        external_efforts_required=False,component_boxes_are_coexistent_states=False)
    if before!=signature(project.to_dict()) or own!=_own_source(consumer_names) or producer['source_at_end']!=_source():
        raise ValueError('Physical inputs or calculation source changed; recalculate before using results')
    from .member_scope import summarize_nominal_member
    member_summary=summarize_nominal_member(selected_global,cmaa if cmaa_physical is not None else local,fatigue_selected,service_summary)
    result=dict(member_summary=member_summary,format='LRO_AUTONOMOUS_UNDERSLUNG_FAMILY_ANALYSIS',version=1,
        status='PARTIAL_AUTONOMOUS_FAMILY_ANALYSIS',project=project.to_dict(),project_signature=before,
        beam_support=beam_support,family_analysis=producer,family_member=member,family_local=local,selected_local_method='CMAA74_2020_case2_nominal' if cmaa_physical is not None else 'NBR10084_NBR8400_nominal',
        family_fatigue=fatigue,family_nbr_fatigue=nbr_fatigue,selected_fatigue_method='NBR8400_classified_life_nominal' if nbr_fatigue_physical is not None else 'EN2025_zero_damage_sufficient' if fatigue is not None else None,family_service=service,family_cmaa=cmaa,family_cmaa_global=cmaa_global,selected_global_method='CMAA_characteristic_NBR8800_ULS_EN2025_resistance' if cmaa_physical is not None else 'NBR_actions_EN2025_resistance',family_cmaa_service=cmaa_service,service_summary=service_summary,project_service_criteria=project_service,cases=[],known_failures=[],
        pending=list(dict.fromkeys(pending)),coverage=scope,
        source=producer['source_at_end']['shared'],source_unchanged_during_calculation=producer['source_unchanged'],
        family_consumer_source=own,consumer_source_names=list(consumer_names),physical_stiffeners='absent',
        timing=dict(seconds=time.monotonic()-started,original_basis_seconds=producer.get('seconds'),original_basis_timing=producer.get('timing'),
            original_basis_reused_without_FE_resweep=verified_basis_receipt is not None),
        consumer_inputs=dict(beam_support=beam_support_physical.to_dict() if beam_support_physical is not None else None,nbr_rolling_guidance=asdict(nbr_rolling_guidance) if nbr_rolling_guidance else None,nbr_fatigue=asdict(nbr_fatigue_physical) if nbr_fatigue_physical else None,fatigue=asdict(fatigue_physical) if fatigue_physical else project.en_fatigue_inputs,native_service=asdict(native_service_physical) if native_service_physical else None,
            cmaa=asdict(cmaa_physical) if cmaa_physical else None,cmaa_mass_accounting=cmaa_mass_accounting,
            service_project_limits=service_project_limits),
        separate_scope_obligations=[
            'Fadiga e serviço usam consumidores próprios quando solicitados; suas conclusões não decorrem dos limites de resistência. Contato e ligações conservam verificações próprias.',
            'As condições reais de vento, teste, guiamento, emergência e batentes têm bases e verificações próprias.',
            'Os vínculos especificados são requisitos físicos da suspensão. A estrutura receptora é verificada separadamente, com vetores coexistentes exportados.',
            'Excesso de um limite suficiente não comprova uma falha física: requer refinamento por estados coexistentes ou redimensionamento.'])
    for consumer in (fatigue_selected,service,cmaa,cmaa_global,cmaa_service,service_summary,project_service,beam_support):
        if consumer:result['pending'].extend(consumer.get('pending',[]))
    if beam_support and beam_support.get('actual_failure_proven'):
        result['known_failures'].append(dict(scope='beam_support',result=beam_support['component_summary']))
    result['pending']=list(dict.fromkeys(result['pending']))
    result['result_signature']=signature(result)
    return result


def assert_current_family_result(project,result):
    if not isinstance(result,dict) or result.get('format')!='LRO_AUTONOMOUS_UNDERSLUNG_FAMILY_ANALYSIS':
        raise ValueError('Internally calculated family result required')
    if result.get('result_signature')!=signature({k:v for k,v in result.items() if k!='result_signature'}):
        raise ValueError('Family result changed after calculation')
    if result.get('project_signature')!=signature(project.to_dict()):raise ValueError('Family result belongs to different physical inputs')
    if result.get('family_consumer_source')!=_own_source(result.get('consumer_source_names',[])):raise ValueError('Family consumer source changed; recalculate')
    producer=result['family_analysis']
    if producer['source_at_end']!=_source():raise ValueError('Family numerical source changed; recalculate')
    if producer['evidence_kind']==VERIFIED:validate_family_receipt(project,producer)
    return result
