"""Isolated autonomous moving-load inputs. N, mm and radians throughout.

No catalogue mass, wheel sharing, restraint or external Robot result is inferred.
The user's 3000 mm suspension grid is a position premise only.
"""
from dataclasses import dataclass,asdict
from fractions import Fraction
import hashlib,json,math


def checked_text(value,label,*,required=True):
    from lro_beams.document_metadata import validate_xml_text
    validate_xml_text(value,label,max_length=10000)
    if required and not value.strip():raise ValueError(label+' required')
    return value


def finite(value,label):
    if isinstance(value,bool) or not isinstance(value,(int,float)) or abs(value)>1e18 or not math.isfinite(value):
        raise ValueError(label+' must be a finite real in the numerical domain')
    return float(value)


def suspension_grid(count,spacing_mm=3000.):
    if type(count) is not int or not 2<=count<=101:raise ValueError('Explicit suspension count >=2 required')
    spacing=finite(spacing_mm,'spacing')
    if spacing<=0:raise ValueError('Positive suspension spacing required')
    return tuple(dict(id=f'S{i+1}',x=i*spacing,restraint_status='unselected') for i in range(count))


@dataclass(frozen=True)
class PhysicalWheel:
    id:str
    offset_mm:float
    y_mm:float
    z_mm:float
    omega_mm2:float
    dead_N:float
    lifted_N:float
    longitudinal_N:float
    transverse_N:float
    provenance:str
    point_force_transfer_adopted:bool
    longitudinal_empty_N:float|None=None
    transverse_empty_N:float|None=None
    longitudinal_vertical_N:float=0.
    transverse_vertical_N:float=0.
    longitudinal_vertical_empty_N:float|None=None
    transverse_vertical_empty_N:float|None=None
    retained_lifted_N:float=0.
    suspended_mass_accounting:str='legacy_retained_mass_unspecified'

    def __post_init__(self):
        checked_text(self.id,'Unique physical wheel ID')
        for key in ('offset_mm','y_mm','z_mm','omega_mm2','dead_N','lifted_N','longitudinal_N','transverse_N','longitudinal_vertical_N','transverse_vertical_N','retained_lifted_N'):
            object.__setattr__(self,key,finite(getattr(self,key),key))
        for key in ('longitudinal_empty_N','transverse_empty_N','longitudinal_vertical_empty_N','transverse_vertical_empty_N'):
            if getattr(self,key) is not None:object.__setattr__(self,key,finite(getattr(self,key),key))
        if min(self.dead_N,self.lifted_N,self.retained_lifted_N)<0:raise ValueError('Physical downward G/Q/B components must be nonnegative')
        if self.suspended_mass_accounting not in ('legacy_retained_mass_unspecified','explicit_payload_plus_retained'):
            raise ValueError('Explicit or legacy suspended mass accounting status required')
        if self.retained_lifted_N and self.suspended_mass_accounting!='explicit_payload_plus_retained':
            raise ValueError('Nonzero retained suspended action requires explicit mass accounting')
        checked_text(self.provenance,'Physical wheel action/geometry provenance')
        if self.point_force_transfer_adopted is not True:raise ValueError('Point-force/qualified sectorial transfer must be explicitly adopted')


@dataclass(frozen=True)
class MovingCase:
    id:str
    family:str
    support_dead:float
    equipment_dead:float
    lifted:float
    longitudinal:float
    transverse:float
    longitudinal_sign:int
    transverse_sign:int
    loaded:bool
    source:str
    extra_dead:float=1.
    retained_lifted:float|None=None

    def __post_init__(self):
        for key in ('id','family','source'):
            checked_text(getattr(self,key),key)
        for key in ('support_dead','equipment_dead','lifted','longitudinal','transverse','extra_dead'):
            object.__setattr__(self,key,finite(getattr(self,key),key))
            if getattr(self,key)<0:raise ValueError('Action multipliers must be nonnegative')
        if self.retained_lifted is not None:
            object.__setattr__(self,'retained_lifted',finite(self.retained_lifted,'retained lifted factor'))
            if self.retained_lifted<0:raise ValueError('Retained lifted factor must be nonnegative')
        if type(self.loaded) is not bool:raise ValueError('Loaded state must be explicit')
        for key in ('longitudinal_sign','transverse_sign'):
            if type(getattr(self,key)) is not int or getattr(self,key) not in (-1,1):raise ValueError('Horizontal global signs must be +/-1')


def physical_train_at(wheels,case,translation_mm,length_mm,*,exact_translation=None):
    """Signed six-wrench and work-conjugate warping load at each active contact.

    Right-hand +X twist, u_warp=-omega*chi. Each opposed wheel stays separate.
    Endpoint contacts are included exactly; wheels outside are absent, not clipped.
    """
    length=finite(length_mm,'length');a=finite(translation_mm,'translation')
    if exact_translation is not None and (not isinstance(exact_translation,Fraction) or float(exact_translation)!=a):raise ValueError('Exact translation must be a matching rational event identity')
    exact_a=Fraction(a) if exact_translation is None else exact_translation
    if length<=0 or not wheels:raise ValueError('Positive runway length and physical wheels required')
    if len({w.id for w in wheels})!=len(wheels):raise ValueError('Repeated wheel identity')
    if not isinstance(case,MovingCase):raise TypeError('MovingCase required')
    loads=[]
    for wheel in wheels:
        exact_x=exact_a+Fraction(wheel.offset_mm)
        if not 0<=exact_x<=Fraction(length):continue
        x=float(exact_x)
        fx,fy,fz=wheel_force_components(wheel,case)
        load=dict(id=wheel.id,x=x,Fx=fx,Fy=fy,Fz=fz,Mx=wheel.y_mm*fz-wheel.z_mm*fy,
                  My=wheel.z_mm*fx,Mz=-wheel.y_mm*fx,B=-wheel.omega_mm2*fx)
        if any(not math.isfinite(v) for k,v in load.items() if k!='id'):raise ValueError('Wheel load transport overflow')
        loads.append(load)
    return tuple(loads)


def selfweight_N_per_mm(area_mm2,density_kg_m3=7850.):
    area=finite(area_mm2,'area');rho=finite(density_kg_m3,'density')
    if min(area,rho)<=0:raise ValueError('Positive physical area and density required')
    return area*rho*9.80665e-9


def signature(payload):
    def default(v):return asdict(v)
    return hashlib.sha256(json.dumps(payload,default=default,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()


def wheel_force_components(wheel,case):
    """Entire correlated H parcels, signed Fz upward, scaled exactly once.

    The vertical inertia components are NOT G/Q. Empty-state parcels are chosen
    before the case factor/sign, and reverse with their corresponding H vector.
    """
    def state(loaded_name,empty_name):
        empty=getattr(wheel,empty_name)
        return getattr(wheel,loaded_name) if case.loaded or empty is None else empty
    hx=state('longitudinal_N','longitudinal_empty_N')
    hy=state('transverse_N','transverse_empty_N')
    vzx=state('longitudinal_vertical_N','longitudinal_vertical_empty_N')
    vzy=state('transverse_vertical_N','transverse_vertical_empty_N')
    cx=case.longitudinal*case.longitudinal_sign;cy=case.transverse*case.transverse_sign
    retained_factor=case.lifted if case.retained_lifted is None else case.retained_lifted
    return (hx*cx,hy*cy,-wheel.dead_N*case.equipment_dead-(wheel.lifted_N*case.lifted if case.loaded else 0.)-wheel.retained_lifted_N*retained_factor+vzx*cx+vzy*cy)
