"""Automatic moving-wheel nominal local/global stress observer.

Only existing NBR 8400 numerical allowances/status helpers are used for family I.
No external tensor, opposite-pair split, extra action factor, EN gamma transfer,
whole-flange PASS or fatigue-history qualification is introduced here.
"""
from dataclasses import asdict
from copy import deepcopy
import math
from .model import physical_train_at, finite, signature
from ..section_stress.recovery import (
    section_properties, bottom_contact, resultants_from_frame,
    recover_bottom_flange, combine_local, SOURCE,
)

METRICS=('global_sigma_x_abs_mpa','global_tau_component_bound_mpa',
         'global_vm_component_bound_mpa','local_combined_sigma_x_abs_mpa',
         'local_combined_sigma_y_abs_mpa','local_combined_tau_bound_mpa',
         'local_combined_vm_bound_mpa','local_nbr8400_utilization')


class LocalStressObserver:
    """Retains governing actual material points; per-call metrics are nonnegative.

    The accumulated result spans all calls, including refinement calls. Counts
    are evaluations, not unique states or fatigue cycles. Unavailable local
    points do not acquire zero stresses/checks: zero initial METRICS values only
    mean no demand of that metric has been observed in the current call.
    """
    def __init__(self,project,case,fy_mpa,fu_mpa,material_ratio_confirmed=False):
        project.validate()
        if type(material_ratio_confirmed) is not bool: raise ValueError('Material ratio confirmation must be explicit boolean')
        self.project=project;self.case=case;self.section=project.section
        self.wheels=tuple(project.wheels);self._wheel_by_id={w.id:w for w in self.wheels}
        self._props=section_properties(self.section,project.E_mpa,project.nu)
        self._input_fingerprint=self._fingerprint()
        self._groups={}
        for w in self.wheels:self._groups.setdefault(w.offset_mm,[]).append(w)
        self._offsets=tuple(sorted(self._groups))
        self._gauges=[];self._geometry_pending=[]
        for w in self.wheels:
            try:
                n=self.section.bottom_width/2-abs(w.y_mm)
                c=bottom_contact(self.section,n,'left' if w.y_mm<0 else 'right')
                if w.y_mm==0 or not all(math.isclose(v,getattr(w,k),rel_tol=1e-12,abs_tol=1e-9)
                    for k,v in (('y_mm',c['y_mm']),('z_mm',c['z_mm']),('omega_mm2',c['omega_mm2']))):
                    raise ValueError('Physical wheel coordinates/sectorial projection do not match the bottom running face')
                if n not in self._gauges:self._gauges.append(n)
            except (ValueError,ArithmeticError) as exc:self._geometry_pending.append((w.id,str(exc)))
        self._pending={};self._global_governing={};self._local_governing={};self._checks={};self._point_checks={}
        self._global_sigma_extrema=dict(min=None,max=None)
        self._calls=0;self._global_points=0;self._local_points=0;self._eligible_stations=0;self._unsupported_stations=0
        self._known_failure=False;self._limits=None;self._helpers=None;self._material_problem=None
        self._resistance_status='NOT_APPLICABLE_MECHANICS_ONLY'
        self._add_pending('contact_3d','Actual wheel contact pressure, tangential traction, tread and clearance are not assessed by nominal plane stresses.')
        self._add_pending('disturbed_region_scope','Prescribed nominal P0 includes the ordinary rolled root within the source model; nonstandard defects, welds, holes, support/load-transfer discontinuities and contact peaks are separate.')
        self._add_pending('full_system','This observer does not qualify whole-member strength/stability, suspension connections, receiving floor beams or fatigue.')
        for wid,why in self._geometry_pending:self._add_pending('wheel_contact_geometry',why,dict(wheel_ids=[wid]))
        if case.family=='I':
            self._resistance_status='INPUT_REQUIRED' if fy_mpa is None or fu_mpa is None else 'QUALIFICATION_REQUIRED'
            try:
                if fy_mpa is None or fu_mpa is None:
                    raise ValueError('Material fy and fu are INPUT_REQUIRED for family-I NBR comparison; automatic mechanics remain available.')
                from lro_beams.stress_8400 import elastic_allowables_8400,equivalent_plane_stress,_check
                limits=elastic_allowables_8400(fy_mpa,fu_mpa,'I')
                if limits['fy_fu_ratio']>.70 and not material_ratio_confirmed:
                    raise ValueError('Qualify NBR 8400 §5.2.1.1.2 high fy/fu reference-steel route explicitly; no hidden material branch approval.')
                self._limits=limits;self._helpers=(equivalent_plane_stress,_check);self._resistance_status='AVAILABLE_NOMINAL_ONLY'
            except (ValueError,ImportError,TypeError) as exc:
                self._material_problem=str(exc);self._add_pending('nbr_material_or_method',str(exc))
        self._provenance=dict(case_id=case.id,case_family=case.family,case_source=case.source,
            action_multipliers=asdict(case),material_source=project.material_source,
            fy_mpa=fy_mpa,fu_mpa=fu_mpa,material_ratio_confirmed=material_ratio_confirmed,
            section_signature=self.section.signature,nominal_stress_source=SOURCE,
            local_longitudinal_multiplier=0.75 if case.family=='I' else 1.0,local_transverse_multiplier=1.0,
            physical_wheels=[asdict(w) for w in self.wheels],
            distributed_actions=dict(expected_udls=self._expected_udls(),density_kg_m3=project.density_kg_m3,
                selfweight_N_per_mm=project.selfweight(),extra_dead_N_per_mm=project.extra_dead_N_per_mm,
                extra_dead_kind=project.extra_dead_kind,extra_dead_y_mm=project.extra_dead_y_mm,
                extra_dead_z_mm=project.extra_dead_z_mm,extra_dead_source=project.extra_dead_source),
            physical_travel=dict(min_mm=project.travel_min_mm,max_mm=project.travel_max_mm,source=project.travel_source),
            load_policy='Final individual actions come from the same physical_train_at output used by the frame; no factors or equal split are applied here.',
            shear_policy='Signed same-point normals and sum-of-absolute modeled same-point global shear components; not a resolved 3-D stress bound.',
            torsion_recovery='equilibrated B and Tw together, with Tsv; mesh adequacy is a separate obligation')

    def _fingerprint(self):
        # All physical/model/source inputs, including density, accessory line,
        # travel and material, belong to this observer's immutable analysis view.
        return signature(dict(project=self.project.to_dict(),case=self.case))

    def _expected_udls(self):
        q=-(self.project.selfweight()*self.case.support_dead+
            self.project.extra_dead_N_per_mm*self.case.extra_dead)
        mx=-self.project.extra_dead_N_per_mm*self.case.extra_dead*(self.project.extra_dead_y_mm or 0.)
        return (dict(start=0.,end=self.project.length_mm,qx=0.,qy=0.,qz=q,mx=mx),) if q or mx else ()

    def _add_pending(self,code,reason,example=None):
        key=(code,reason)
        if key not in self._pending:self._pending[key]=dict(code=code,reason=reason,occurrences=0,example=deepcopy(example))
        self._pending[key]['occurrences']+=1

    def _identity(self,row,translation,*,wheel_ids=(),action_state_verified=True):
        return dict(case_id=self.case.id,case_family=self.case.family,translation_mm=translation,
            translation_exact=self._translation_exact_identity,
            section_x_mm=row['state_identity']['section_x_mm'],section_cut_side=row['state_identity']['section_cut_side'],
            outstand_side=row['outstand_side'],point=row['point'],face=row['face'],point_id=row['id'],
            y_mm=row['y_mm'],z_mm=row['z_mm'],omega_mm2=row['omega_mm2'],wheel_ids=list(wheel_ids),
            section_signature=self.section.signature,action_state_verified=action_state_verified,
            action_state_verification_scope='Physical wheel IDs/wrenches plus computed full-span selfweight/accessory UDL and eccentric accessory torque')

    @staticmethod
    def _retain(container,key,value,row,identity):
        if not math.isfinite(value) or value<0:raise ValueError('Nonfinite/negative observer demand '+key)
        if key not in container or value>container[key]['value']:
            container[key]=dict(value=value,identity=deepcopy(identity),stresses=deepcopy(row))

    def _verify_actions(self,solution,translation,active_loads):
        """Use actual IDs; never infer a missing opposite wheel or pair fraction."""
        exact=getattr(solution,'translation_exact',None)
        kwargs={} if exact is None else {'exact_translation':exact}
        expected=physical_train_at(self.wheels,self.case,translation,self.project.length_mm,**kwargs)
        actual=tuple(active_loads)
        if any(not isinstance(p,dict) or 'id' not in p for p in actual):return False,'Every applied wheel load needs its actual physical ID'
        ids=[p['id'] for p in actual]
        if len(set(ids))!=len(ids):return False,'Duplicated physical wheel ID in active load list'
        if set(ids)!={p['id'] for p in expected}:return False,'Active physical wheel IDs do not match the full train at this translation'
        applied_points=tuple(getattr(solution,'points',()))
        if any(not isinstance(p,dict) or 'id' not in p for p in applied_points):return False,'Actual frame point actions need traceable physical wheel IDs'
        applied={p['id']:p for p in applied_points}
        if len(applied)!=len(applied_points):return False,'Repeated actual frame physical wheel ID'
        if set(applied)!=set(ids):return False,'Actual frame point-load IDs differ from the observer active wheel list'
        lookup={p['id']:p for p in actual}
        for want in expected:
            for observed in (lookup[want['id']],applied[want['id']]):
                for key,value in want.items():
                    if key=='id':continue
                    if key not in observed or isinstance(observed[key],bool) or not isinstance(observed[key],(int,float)) or not math.isfinite(observed[key]):
                        return False,'Missing/nonfinite actual frame action '+want['id']+'/'+key
                    if observed[key]!=value:
                        return False,'Actual frame action differs from the case factor/physical-wheel ledger: '+want['id']+'/'+key
        expected_udls=self._expected_udls();actual_udls=tuple(getattr(solution,'udls',()))
        if len(actual_udls)!=len(expected_udls):
            return False,'Actual frame distributed loads omit or add a full-span selfweight/accessory action'
        for want,observed in zip(expected_udls,actual_udls):
            if not isinstance(observed,dict):return False,'Invalid actual frame distributed-load record'
            for key,value in want.items():
                if key not in observed or isinstance(observed[key],bool) or not isinstance(observed[key],(int,float)) or not math.isfinite(observed[key]) or observed[key]!=value:
                    return False,'Actual frame UDL differs from the computed selfweight/accessory factor and load-line ledger: '+key
        return True,''

    def _pair(self,offset,active_by_id):
        group=self._groups[offset]
        if len(group)!=2:return None,'unsupported_wheel_arrangement','Local Table5.2 requires exactly two physical opposed wheels at each longitudinal station'
        if any(w.id not in active_by_id for w in group):return None,'incomplete_opposed_pair','The actual active load set does not contain both physical wheels of the station'
        a,b=group;pa,pb=active_by_id[a.id],active_by_id[b.id]
        if a.y_mm*b.y_mm>=0 or a.y_mm!=-b.y_mm:
            return None,'asymmetric_contacts','Physical pair does not have opposed equal-offset contact lines; no symmetry or equal split is invented'
        n=self.section.bottom_width/2-abs(a.y_mm)
        if any(wid in {a.id,b.id} for wid,_ in self._geometry_pending):
            return None,'wheel_contact_geometry','A physical wheel does not match the actual bottom-flange running face/sectorial projection'
        if pa['x']!=pb['x']:return None,'asymmetric_station','Opposed wheel actions are not at the same physical longitudinal station'
        P=-pa['Fz']
        if P<0 or P!=-pb['Fz']:
            return None,'unequal_opposed_actions','Opposed individual vertical actions are not equal and nonnegative; pair total is not split or averaged'
        neighbours=[abs(other-offset) for other in self._offsets if other!=offset]
        spacing=min(neighbours) if neighbours else None
        # Whole train, including currently inactive stations: never re-label a
        # close train as isolated merely because another station is off the beam.
        if spacing is not None and spacing<1.5*self.section.bottom_width:
            return None,'close_wheel_cluster','Nearest longitudinal station in the full physical train is closer than 1.5 bottom-flange widths; cluster local envelope is pending'
        return dict(wheel_ids=[a.id,b.id],x=pa['x'],n=n,P=P,spacing=spacing),None,None

    def _compare(self,row,identity):
        if self._limits is None:return None
        eq,check=self._helpers;lim=self._limits
        sx=row['sigma_x_mpa'];sy=row['sigma_y_mpa'];tau=row['tau_xy_component_bound_mpa']
        vm=eq(sx,sy,tau)
        checks=[check('sigma_x','Tensão normal x nominal',abs(sx),lim['sigma_a_mpa'],lim['formula'],lim['clause']),
                check('sigma_y','Tensão normal y nominal',abs(sy),lim['sigma_a_mpa'],lim['formula'],lim['clause']),
                check('tau_xy','Limite nominal de cisalhamento xy',tau,lim['tau_a_mpa'],'tau_a = sigma_a / sqrt(3)','5.2.1.2'),
                check('equivalent','Tensão equivalente nominal limitada por componentes',vm,lim['sigma_a_mpa'],
                      'sqrt(sigma_x^2 + sigma_y^2 - sigma_x*sigma_y + 3*tau_component_bound^2)','5.2.1.3')]
        for c in checks:
            self._known_failure|=c['status']=='NÃO ATENDE'
            key='/'.join((row['outstand_side'],'P'+str(row['point']),row['face'],c['id']))
            update_global=c['id'] not in self._checks or c['utilization']>self._checks[c['id']]['utilization']
            update_point=key not in self._point_checks or c['utilization']>self._point_checks[key]['utilization']
            if update_global or update_point:
                record=dict(c,identity=deepcopy(identity),stresses=deepcopy(row),comparison_scope='Nominal local/global material-point comparison only',
                            conservative_shear_components=True,full_compliance=False)
                if update_global:self._checks[c['id']]=record
                if update_point:self._point_checks[key]=record
        return max(c['utilization'] for c in checks)

    def __call__(self,solution,translation,active_loads,spatial_stations):
        translation=finite(translation,'wheel translation')
        if self._fingerprint()!=self._input_fingerprint:raise ValueError('Project/wheel/case changed after observer construction; build a fresh observer')
        if solution.model.length!=self.project.length_mm:raise ValueError('Frame/observer physical member length mismatch')
        if tuple(solution.model.supports)!=tuple(self.project.supports):raise ValueError('Frame/observer physical suspension constraints mismatch')
        for key,value in self._props['frame_section'].items():
            if key not in solution.model.section or not math.isclose(solution.model.section[key],value,rel_tol=1e-10):
                raise ValueError('Frame/observer stiffness mismatch: '+key)
        self._calls+=1;metrics={key:0. for key in METRICS};active_loads=tuple(active_loads)
        exact=getattr(solution,'translation_exact',None)
        self._translation_exact_identity=None if exact is None else dict(numerator=exact.numerator,denominator=exact.denominator)
        valid,reason=self._verify_actions(solution,translation,active_loads)
        if not valid:self._add_pending('action_source_mismatch',reason,dict(translation_mm=translation,case_id=self.case.id))
        by_id={p['id']:p for p in active_loads if isinstance(p,dict) and p.get('id') in self._wheel_by_id}
        stations={finite(x,'spatial station') for x in spatial_stations}
        if valid:stations.update(p['x'] for p in by_id.values())
        if any(not 0<=x<=self.project.length_mm for x in stations):raise ValueError('Spatial observation station outside physical member')
        cache={}
        def state(x,side):
            key=(x,side)
            if key not in cache:cache[key]=resultants_from_frame(self.section,solution.at(x,side),
                combination_id=self.case.id,wheel_translation_mm=translation,torsion_recovery='equilibrated')
            return cache[key]
        # Global stresses are still evaluated when end/spacing/pair mechanics is
        # unsupported locally. No missing local contribution is assigned zero.
        for x in sorted(stations):
            for side in ('left','right'):
                seen=set()
                for n in self._gauges:
                    for row in recover_bottom_flange(self.section,state(x,side),n):
                        physical_ids=[w.id for w in self.wheels if w.y_mm==row['y_mm']]
                        if row['point']==1 and not physical_ids:continue
                        point_key=(row['point'],row['face'],row['y_mm'],row['z_mm'])
                        if point_key in seen:continue
                        seen.add(point_key);self._global_points+=1
                        identity=self._identity(row,translation,wheel_ids=physical_ids,action_state_verified=valid)
                        sx=row['global_sigma_x_mpa'];tau=row['tau_xy_component_bound_mpa'];vm=math.hypot(sx,math.sqrt(3)*tau)
                        for key,value in (('global_sigma_x_abs_mpa',abs(sx)),('global_tau_component_bound_mpa',tau),('global_vm_component_bound_mpa',vm)):
                            metrics[key]=max(metrics[key],value);self._retain(self._global_governing,key,value,row,identity)
                        for bound,better in (('min',lambda v:sx<v),('max',lambda v:sx>v)):
                            old=self._global_sigma_extrema[bound]
                            if old is None or better(old['value']):self._global_sigma_extrema[bound]=dict(value=sx,identity=deepcopy(identity),stresses=deepcopy(row))
        active_offsets=sorted({self._wheel_by_id[wid].offset_mm for wid in by_id})
        for offset in active_offsets:
            basic=dict(case_id=self.case.id,translation_mm=translation,translation_exact=self._translation_exact_identity,station_offset_mm=offset,
                       wheel_ids=[w.id for w in self._groups[offset]])
            if not valid:
                self._unsupported_stations+=1;continue
            pair,code,reason=self._pair(offset,by_id)
            if pair is None:
                self._unsupported_stations+=1;self._add_pending(code,reason,basic);continue
            x=pair['x'];distance=min(x,self.project.length_mm-x)
            try:
                rows_by_cut=[]
                for side in ('left','right'):
                    rows=combine_local(self.section,state(x,side),pair['n'],individual_wheel_N=pair['P'],wheel_station_mm=x,
                        distance_to_nearest_end_mm=distance,symmetric_opposite_wheels_confirmed=True,
                        nearest_longitudinal_spacing_mm=pair['spacing'],isolated_longitudinal_station_confirmed=pair['spacing'] is None,
                        local_longitudinal_multiplier=0.75 if self.case.family=='I' else 1.0)
                    rows_by_cut.extend(rows)
            except (ValueError,ArithmeticError) as exc:
                self._unsupported_stations+=1
                code='physical_end_zone' if distance<=self.section.bottom_width else 'local_method_domain'
                self._add_pending(code,str(exc),dict(basic,section_x_mm=x,physical_end_distance_mm=distance));continue
            self._eligible_stations+=1
            for row in rows_by_cut:
                self._local_points+=1;identity=self._identity(row,translation,wheel_ids=pair['wheel_ids'])
                row['load_provenance']=dict(wheel_ids=pair['wheel_ids'],individual_wheel_N=pair['P'],case_source=self.case.source,
                    wheel_sources=[self._wheel_by_id[wid].provenance for wid in pair['wheel_ids']],nearest_full_train_spacing_mm=pair['spacing'])
                quantities=(('local_combined_sigma_x_abs_mpa',abs(row['sigma_x_mpa'])),
                    ('local_combined_sigma_y_abs_mpa',abs(row['sigma_y_mpa'])),
                    ('local_combined_tau_bound_mpa',row['tau_xy_component_bound_mpa']),
                    ('local_combined_vm_bound_mpa',row['von_mises_component_bound_mpa']))
                for key,value in quantities:
                    metrics[key]=max(metrics[key],value);self._retain(self._local_governing,key,value,row,identity)
                if self.case.family=='I' and self._limits is not None:
                    try:util=self._compare(row,identity)
                    except (ValueError,ArithmeticError) as exc:
                        self._add_pending('nominal_comparison_domain',str(exc),identity);continue
                    metrics['local_nbr8400_utilization']=max(metrics['local_nbr8400_utilization'],util)
        return metrics

    def result(self):
        """Deep snapshot; a later pending state never erases an observed failure."""
        comparison=bool(self._checks)
        status=('NOMINAL_FAILURE_WITH_PENDING' if self._known_failure else
                'NOMINAL_COMPARISONS_WITH_PENDING' if comparison else 'MECHANICS_ONLY_WITH_PENDING')
        return deepcopy(dict(status=status,case_id=self.case.id,case_family=self.case.family,
            mechanical_results_available=bool(self._global_points or self._local_points),
            local_nominal_comparison_available=comparison,known_nominal_failure=self._known_failure,
            observed_local_states_supported=self._eligible_stations>0 and self._unsupported_stations==0,
            whole_beam_complete=False,local_flange_complete=False,global_strength_complete=False,
            fatigue_complete=False,contact_complete=False,connection_complete=False,
            actual_3d_tensor_complete=False,mathematically_certified_envelope=False,
            torsion_mesh_qualified=False,external_tensor_required=False,
            evaluated_calls=self._calls,global_point_evaluations=self._global_points,
            local_point_evaluations=self._local_points,eligible_station_evaluations=self._eligible_stations,
            unsupported_station_evaluations=self._unsupported_stations,counts_are_not_unique_states_or_cycles=True,
            governing_global_mechanics=self._global_governing,global_sigma_x_extrema=self._global_sigma_extrema,
            governing_local_mechanics=self._local_governing,governing_checks=self._checks,
            governing_point_checks=self._point_checks,pending=list(self._pending.values()),
            resistance_status=self._resistance_status,material_input_required=self._resistance_status=='INPUT_REQUIRED',
            limits=self._limits,source_provenance=self._provenance,
            qualification='Automatic source-prescribed nominal points including ordinary rolled P0; family-I uses NBR10084 local-X 0.75 and NBR8400 allowances. Numerical coverage is assigned by the enclosing producer, not this observer; contact/disturbed zones and full system remain separate'))
