"""Explicit numerical dependency receipt, distinct from a distribution manifest.

The selected analysis imports only these candidate modules and the listed LRO
helpers. UI, report formatting, tests, source audits and unused experimental
solvers are deliberately excluded. Adding a numerical import requires updating
this manifest; import-closure regression checks guard omissions. Every NEW run
hashes this receipt before and after execution. No earlier run is re-signed.
"""
from pathlib import Path
import hashlib
import importlib
import json
import platform

NUMERICAL_FILES = (
    'autonomous_frame/solver.py',
    'autonomous_workflow/bridge_reactions.py',
    'autonomous_workflow/cases.py',
    'autonomous_workflow/inertia_bridge_adapter.py',
    'autonomous_workflow/local_observer.py',
    'autonomous_workflow/model.py',
    'autonomous_workflow/moving.py',
    'autonomous_workflow/pipeline.py',
    'autonomous_workflow/project.py',
    'autonomous_workflow/source_manifest.py',
    'bridge_inertia/statics.py',
    'fatigue/autonomous_adapter.py',
    'fatigue/en2025.py',
    'fatigue/nominal_local.py',
    'fatigue/tensor_bounds.py',
    'global_response/moving_point_bounds.py',
    'global_response/numerical_producer.py',
    'global_response/translation_events.py',
    'local_flange/kernel.py',
    'section_stress/recovery.py',
    'section_stress/whole_section_bounds.py',
    'stability/c2_adapter.py',
    'stability/reference.py',
)
OPTIONAL_SEPARATELY_RECEIPTED_IMPORTS = {'autonomous_workflow/project.py': ('contact/autonomous_adapter.py','serviceability/autonomous_adapter.py'), 'autonomous_workflow/pipeline.py': ('contact/autonomous_adapter.py','serviceability/autonomous_adapter.py')}
# Contact physical-schema validation does not change frame actions, response or
# fatigue arithmetic. When selected, its separate before/after contact receipt
# hashes the complete contact route and this shared numerical manifest.

LRO_DEPENDENCIES = ('lro_beams.autonomous_actions','lro_beams.stress_8400','lro_beams.document_metadata')


def numerical_source_receipt(*, root=None):
    root=Path(root) if root is not None else Path(__file__).resolve().parents[1]
    paths=set(NUMERICAL_FILES)
    # Package initializers can execute code and therefore belong to lineage.
    for name in NUMERICAL_FILES:
        for directory in (root/Path(name).parent,root):
            initializer=directory/'__init__.py'
            if initializer.is_file():paths.add(str(initializer.relative_to(root)))
    files={name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in sorted(paths)}
    dependencies={}
    for name in LRO_DEPENDENCIES:
        module=importlib.import_module(name)
        dependencies[name]=hashlib.sha256(Path(module.__file__).read_bytes()).hexdigest()
    package=importlib.import_module('lro_beams')
    if package.__file__:dependencies['lro_beams']=hashlib.sha256(Path(package.__file__).read_bytes()).hexdigest()
    import numpy,scipy
    libraries=dict(python=platform.python_version(),numpy=numpy.__version__,scipy=scipy.__version__)
    payload=dict(manifest_version=1,files=files,dependency_files=dependencies,libraries=libraries)
    fingerprint=hashlib.sha256(json.dumps(payload,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
    return dict(**payload,fingerprint=fingerprint,
        scope='Explicit physical-action, linear-response, numerical-envelope, local/member and nominal-fatigue dependency closure. Excludes UI/reports/tests/research and separately receipted optional contact/service and unused suspension methods; separate package receipt covers shipped artifacts.')
