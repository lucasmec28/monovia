"""Source-prescribed NBR nominal bottom-flange checks of verified family boxes.

All eight physical configurations and their actual NBR-I cases remain in the
internal receipt. Component boxes are mathematical bounds, not fictitious
simultaneous stress states. An exceeded sufficient box is inconclusive; it is
not evidence that a physical configuration fails. Contact/defects/support
regions and stability/fatigue are independent assessed scopes.
"""
from pathlib import Path
from hashlib import sha256
from itertools import product
import math
from .family_envelope import interval_product,interval_sum,_source
from .model import signature
from ..stability.family_adapter import validate_family_receipt
from ..section_stress.recovery import geometric_properties,bottom_flange_points
from ..section_stress.whole_section_bounds import whole_section_shear_bound
from ..local_flange.kernel import Geometry,coefficients

SOURCE='ABNT NBR 10084:2020 §9.1.4, Tabela 2 (mesas paralelas), superposição nominal e sigma_cx=sigma_x+0.75sigma_0x; NBR8400-2:2019 versão corrigida2022 §5.2.1.1–3'


def _require(ok,message):
    if not ok:raise ValueError(message)


def _scaled(interval,value):
    return interval_product(interval,dict(lower=value,upper=value))


def nominal_vertex_checks(total_box,limits):
    """Exact existing NBR verdict/tolerance at all eight mathematical corners."""
    from lro_beams.stress_8400 import equivalent_plane_stress,_check
    for key in ('sx','sy','tau'):
        lo,hi=total_box[key]
        _require(all(type(v) in (int,float) and math.isfinite(v) for v in (lo,hi)) and lo<=hi,'Ordered finite stress bounds required')
    retained={}
    for sx,sy,tau in product(*(total_box[k] for k in ('sx','sy','tau'))):
        vm=equivalent_plane_stress(sx,sy,tau)
        for c in (_check('sigma_x','Tensão normal x nominal',abs(sx),limits['sigma_a_mpa'],limits['formula'],limits['clause']),
                  _check('sigma_y','Tensão normal y nominal',abs(sy),limits['sigma_a_mpa'],limits['formula'],limits['clause']),
                  _check('tau_xy','Cisalhamento nominal limitado por componentes',abs(tau),limits['tau_a_mpa'],'tau_a=sigma_a/sqrt(3)','5.2.1.2'),
                  _check('equivalent','Tensão equivalente nominal limitada por componentes',vm,limits['sigma_a_mpa'],'sqrt(sx²+sy²-sx sy+3tau²)','5.2.1.3')):
            if c['id'] not in retained or c['utilization']>retained[c['id']]['utilization']:
                failed=c['status']=='NÃO ATENDE'
                retained[c['id']]=dict(c,source_comparison_status=c['status'],status='INCONCLUSIVE_SUFFICIENT_BOUND' if failed else 'SUFFICIENT_BOUND_SATISFIED',
                    mathematical_vertex=dict(sx=sx,sy=sy,tau=tau),criterion_is_sufficient_upper_bound=True,actual_failure_proven=False)
    return list(retained.values())


def evaluate_family_local(project,receipt):
    result=dict(kind='NBR10084_prescribed_nominal_family_points',status='PENDING_NOMINAL_FAMILY',points=[],pending=[],
        sufficient_prescribed_nominal_points_satisfied=False,whole_bottom_flange_qualified=False,whole_member_qualified=False,
        actual_failure_proven=False,contact_qualified=False,fatigue_qualified=False,concurrent_tensor_claimed=False,source=SOURCE)
    own=sha256(Path(__file__).read_bytes()).hexdigest()
    try:
        before=signature(project.to_dict());_,plan=validate_family_receipt(project,receipt)
        _require(project.section.construction=='rolled','First qualified ordinary nominal domain is rolled parallel I only')
        _require(project.fy_mpa is not None and project.fu_mpa is not None,'Physical/adopted steel fy and fu required')
        from lro_beams.stress_8400 import elastic_allowables_8400
        limits=elastic_allowables_8400(project.fy_mpa,project.fu_mpa,'I')
        _require(limits['fy_fu_ratio']<=.70 or project.material_ratio_confirmed,'High fy/fu branch requires its specified reference-steel qualification')
        s=project.section;props=geometric_properties(s)
        first=next(iter(plan['wheels_by_configuration'].values()))
        n=s.bottom_width/2-abs(first[0].y_mm)
        _require(all(abs(w.y_mm)==abs(first[0].y_mm) for w in first),'Common physical contact line required')
        geometry=Geometry(s.bottom_width,s.tw_mm,s.bottom_thickness,n,s.construction,s.bottom_root_radius_mm,s.bottom_weld_throat_mm)
        end_distance=min(project.travel_min_mm+min(w.offset_mm for w in first),project.length_mm-project.travel_max_mm-max(w.offset_mm for w in first))
        _require(end_distance>geometry.bottom_b_mm,'Whole physical passage must remain beyond the source end-transition distance b')
        chosen=[f for f in receipt['families'] if f['family']=='I']
        _require(len(chosen)==1,'Exactly one internally generated NBR family-I domain required')
        f=chosen[0];b=f['bounds'];coef=coefficients(geometry.mu)
        # All actual same-side wheels included, without favorable cancellation,
        # spacing attenuation or omitted neighboring stations. Opposed wheels
        # are not double-counted. This is a prescribed nominal design box.
        selected=[r for r in f['wheel_vertical_actions'] if r['y_mm']<0]
        _require(len(selected)==2,'Complete two-station same-side train required')
        peak_sum=math.fsum(r['downward_N']['upper'] for r in selected)
        _require(peak_sum>=0 and all(r['downward_N']['lower']>=0 for r in selected),'Compression-only contact domain required')
        denominator=s.bottom_thickness**2
        _require(math.isfinite(denominator) and denominator>0,'Finite positive local thickness square required')
        raw_x=max(abs(c[0]) for c in coef)*peak_sum/denominator
        raw_y=max(abs(c[1]) for c in coef)*peak_sum/denominator
        _require(all(math.isfinite(v) for v in (raw_x,raw_y)),'Local arithmetic outside finite numerical domain')
        mag=lambda k:max(abs(b[k]['lower']),abs(b[k]['upper']))
        shear=whole_section_shear_bound(s,abs_Fy_N=mag('Fy'),abs_Fz_N=mag('Fz'),abs_Tsv_Nmm=mag('Tsv'),abs_Tw_Nmm=mag('Tw_equilibrated'))
        tau=shear['tau_bound_mpa']
        for point in bottom_flange_points(s,n):
            sx=interval_sum((_scaled(b['N'],1/props['A_mm2']),_scaled(b['My'],point.z_mm/props['Iy_mm4']),
                             _scaled(b['Mz'],-point.y_mm/props['Iz_mm4']),_scaled(b['B_equilibrated'],point.omega_mm2/props['Cw_mm6'])))
            combined=interval_sum((sx,dict(lower=-.75*raw_x,upper=.75*raw_x)))
            box=dict(sx=(combined['lower'],combined['upper']),sy=(-raw_y,raw_y),tau=(-tau,tau))
            result['points'].append(dict(point_id=point.id,point=point.point,face=point.face,outstand_side=point.outstand_side,
                global_sigma_x_interval_mpa=(sx['lower'],sx['upper']),raw_local_x_interval_mpa=(-raw_x,raw_x),raw_local_y_interval_mpa=(-raw_y,raw_y),
                local_longitudinal_multiplier=.75,local_transverse_multiplier=1.,total_box_mpa=box,checks=nominal_vertex_checks(box,limits)))
        checks=[c for p in result['points'] for c in p['checks']]
        passed=bool(checks) and all(c['status']=='SUFFICIENT_BOUND_SATISFIED' for c in checks)
        result.update(status='SUFFICIENT_NOMINAL_FAMILY_BOUND_SATISFIED' if passed else 'INCONCLUSIVE_SUFFICIENT_BOUND',
            sufficient_prescribed_nominal_points_satisfied=passed,limits=limits,physical_case_count=len(f['members']),minimum_end_distance_mm=end_distance,
            nominal_local_box=dict(producer_kind='SOURCE_PRESCRIBED_NOMINAL_DESIGN_BOX',all_same_side_wheels_included=True,maximum_same_side_wheel_sum_N=peak_sum,
                local_x_raw_bound_mpa=raw_x,local_y_raw_bound_mpa=raw_y,coefficient_policy='Maximum absolute coefficient across prescribed0/1/2points and both faces; full separate-wheel superposition, no attenuation.',
                physical_continuum_enclosure_claimed=False),nominal_global_shear=shear,
            scope='Selected source-prescribed ordinary rolled lower-flange nominal points, both outstands/faces, all generated NBR-I configurations/cases and physical passage; no contact tensor, defective root, holes, support/connection disturbed zones, stability or fatigue approval.')
        _require(before==signature(project.to_dict()) and receipt['source_at_end']==_source(),'Physical project or numerical source changed during local family consumption')
        _require(own==sha256(Path(__file__).read_bytes()).hexdigest(),'Local family consumer source changed')
        result['source_receipt']=dict(consumer_sha256=own,producer_receipt_signature=receipt['receipt_signature'],project_signature=before,
            source_fingerprint=receipt['source_at_end']['fingerprint'])
    except (ValueError,TypeError,KeyError,ArithmeticError,AttributeError) as exc:
        result.update(status='PENDING_NOMINAL_FAMILY',points=[],sufficient_prescribed_nominal_points_satisfied=False)
        result['pending'].append(type(exc).__name__+': '+str(exc))
    return result
