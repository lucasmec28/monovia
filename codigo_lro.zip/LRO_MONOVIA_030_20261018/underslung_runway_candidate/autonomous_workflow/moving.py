"""Isolated moving-train response sampling with identity and strict refinement.

Numerical convergence is not a mathematical enclosure or whole-design approval.
Both spatial observation density and train-translation density are refined.
The frame torsion mesh has its own independent convergence requirement.
"""
from dataclasses import asdict
from fractions import Fraction
import math,time,json,hashlib
from pathlib import Path
from .model import finite,physical_train_at,signature
from ..global_response.translation_events import build_event_catalogue,event_translation_map,select_event_probes

METRICS=('u','v','w','phi','theta_y','theta_z','chi','N','Fy','Fz','My','Mz','B_equilibrated','T_equilibrated','Tsv','Tw_equilibrated')


def event_translations(length,wheels,stations=()):
    L=finite(length,'length')
    if L<=0 or not wheels:raise ValueError('Positive length and physical train required')
    positions={0.,L,*(finite(x,'station') for x in stations)}
    if any(not 0<=x<=L for x in positions):raise ValueError('Event station outside runway')
    return tuple(sorted({x-w.offset_mm for x in positions for w in wheels}))


def partition_samples(events,divisions):
    if type(divisions) is not int or divisions<1:raise ValueError('Positive integer sample subdivisions required')
    values=set(events)
    for lo,hi in zip(events[:-1],events[1:]):
        for j in range(1,divisions):values.add(lo+(hi-lo)*j/divisions)
    return tuple(sorted(values))


def scan_moving_case(model,wheels,case,*,selfweight=0.,extra_dead=0.,fixed_stations=(),
                     divisions=2,max_refinements=4,tolerance=.01,consecutive_stable=2,progress=None,observer=None,
                     travel_min_mm=None,travel_max_mm=None,segments=(),extra_dead_y_mm=0.):
    """Model is already built/factored; point loads never alter its topology.

    observer(solution, translation, active_loads, spatial_stations) may return
    explicitly named nonnegative scalar demand maxima for convergence monitoring.
    It must retain any local point/case identity in its own result accumulator.
    """
    L=model.length;selfweight=finite(selfweight,'selfweight');extra_dead=finite(extra_dead,'extra_dead')
    import underslung_runway_candidate.autonomous_frame.solver as solver_source
    solver_hash=hashlib.sha256(Path(solver_source.__file__).read_bytes()).hexdigest()
    if min(selfweight,extra_dead)<0:raise ValueError('Selfweight/additional downward dead UDL must be nonnegative')
    extra_dead_y_mm=finite(extra_dead_y_mm,'accessory load-line y')
    if type(max_refinements) is not int or max_refinements<1:raise ValueError('At least one refinement comparison required')
    if not 0<tolerance<1 or type(consecutive_stable) is not int or consecutive_stable<1:raise ValueError('Invalid explicit convergence controls')
    for seg in segments:
        if not 0<=seg['start_mm']<seg['end_mm']<=L:raise ValueError('Segment outside runway')
    fixed=tuple(sorted({0.,L,*map(float,model.nodes),*map(float,fixed_stations),*(float(s[k]) for s in segments for k in ('start_mm','end_mm'))}))
    if any(not 0<=x<=L for x in fixed):raise ValueError('Observation station outside beam')
    catalogue=build_event_catalogue(L,wheels,fixed,travel_min_mm=travel_min_mm,travel_max_mm=travel_max_mm)
    exact_map=event_translation_map(catalogue);events=tuple(e.translation_mm for e in catalogue)
    probes=select_event_probes(catalogue)
    for seg in segments:
        if not 0<=seg['start_mm']<seg['end_mm']<=L:raise ValueError('Segment outside runway')
    support_x=tuple(sorted({float(s['x']) for s in model.supports}))
    service_spans=tuple(zip(support_x[:-1],support_x[1:])) if case.family in ('SLS10084','SLS8800','EN_SERVICE') else ()
    history=[];stable=0;previous=None;start=time.monotonic();total_solves=0
    for level in range(max_refinements+1):
        density=divisions*2**level
        # Exact event positions plus verified representable nearby probes.
        # Probes approximate, but are not claimed to equal, one-sided limits.
        translations=tuple(sorted(set(partition_samples(events,density))|{r['translation_mm'] for r in probes}))
        base_stations=partition_samples(fixed,density)
        extrema={};reaction_extrema={};observed={};equilibrium_max=0.;constraint_max=0.
        segment_extrema=[dict(start_mm=s['start_mm'],end_mm=s['end_mm'],extrema={}) for s in segments]
        def retain(container,key,value,a,x,side,extra=None):
            if not math.isfinite(value):raise ValueError('Nonfinite response in '+key)
            row=container.setdefault(key,dict(min=None,max=None))
            for bound,condition in (('min',lambda old:value<old),('max',lambda old:value>old)):
                if row[bound] is None or condition(row[bound]['value']):
                    row[bound]=dict(value=float(value),case_id=case.id,translation_mm=a,
                        translation_exact_mm=dict(numerator=str(exact_a.numerator),denominator=str(exact_a.denominator)),
                        x_mm=x,side=side,**(extra or {}))
        for number,a in enumerate(translations):
            exact_a=exact_map.get(a,Fraction(a))
            loads=physical_train_at(wheels,case,a,L,exact_translation=exact_a)
            q=-(selfweight*case.support_dead+extra_dead*case.extra_dead)
            mx=-extra_dead*case.extra_dead*extra_dead_y_mm
            solution=model.solve(loads,[dict(start=0.,end=L,qz=q,mx=mx)] if q or mx else [])
            solution.translation_exact=exact_a
            total_solves+=1
            eq=max(map(abs,solution.diagnostics['physical_equilibrium_N_Nmm']))
            equilibrium_max=max(equilibrium_max,eq);constraint_max=max(constraint_max,solution.diagnostics['constraint_error'])
            stations=tuple(sorted({*base_stations,*(p['x'] for p in loads)}))
            service_ends={x:solution.at(x,'right' if x<L else 'left') for x in support_x} if service_spans else {}
            for x in stations:
                for side in ('left','right'):
                    state=solution.at(x,side)
                    for key in METRICS:retain(extrema,key,state[key],a,x,side)
                    for wheel in wheels:
                        # Displacements at the actual contact, not the centroid
                        # or old top-running rail height. Small-rotation model.
                        contact=dict(u=state['u']+wheel.z_mm*state['theta_y']-wheel.y_mm*state['theta_z']-wheel.omega_mm2*state['chi'],
                            v=state['v']-wheel.z_mm*state['phi'],w=state['w']+wheel.y_mm*state['phi'])
                        for key,value in contact.items():retain(extrema,f'contact/{wheel.id}/{key}',value,a,x,side,
                            dict(y_mm=wheel.y_mm,z_mm=wheel.z_mm,omega_mm2=wheel.omega_mm2))
                        for span_index,(lo,hi) in enumerate(service_spans):
                            if lo<=x<=hi:
                                t=(x-lo)/(hi-lo);sl=service_ends[lo];sr=service_ends[hi]
                                for component in ('v','w'):
                                    left=sl['v']-wheel.z_mm*sl['phi'] if component=='v' else sl['w']+wheel.y_mm*sl['phi']
                                    right=sr['v']-wheel.z_mm*sr['phi'] if component=='v' else sr['w']+wheel.y_mm*sr['phi']
                                    chord=(1-t)*left+t*right
                                    retain(extrema,f'service_span/{span_index}/contact/{wheel.id}/relative_{component}',contact[component]-chord,a,x,side,
                                        dict(span_start_mm=lo,span_end_mm=hi,y_mm=wheel.y_mm,z_mm=wheel.z_mm,
                                             endpoint_contact_displacements_mm=[left,right],chord_displacement_mm=chord,
                                             absolute_contact_displacement_mm=contact[component],
                                             displacement_basis='Same-state actual contact line relative to end chord; endpoint motion retained separately'))
                    for segment in segment_extrema:
                        lo,hi=segment['start_mm'],segment['end_mm']
                        if lo<=x<=hi and not (x==lo and side=='left' or x==hi and side=='right'):
                            for key in METRICS:retain(segment['extrema'],key,state[key],a,x,side)
            attachment_vectors=[]
            for r in solution.support_reactions:
                sp=model.supports[r['support_index']];y=sp.get('y',0.);z=sp.get('z',0.);om=sp.get('omega',0.)
                attachment_vectors.append(dict(support_index=r['support_index'],support_id=sp.get('id',str(r['support_index'])),
                    point_mm=dict(x=r['x'],y=y,z=z),Fx=r['Fx'],Fy=r['Fy'],Fz=r['Fz'],
                    Mx=r['Mx']-y*r['Fz']+z*r['Fy'],My=r['My']-z*r['Fx'],Mz=r['Mz']+y*r['Fx'],
                    generalized_B=r['B']+om*r['Fx'],
                    axes='x longitudinal, y transverse, z upward; N and Nmm; B Nmm2 is generalized warping action, not an ordinary nodal moment'))
            for reaction in solution.support_reactions:
                for key in ('Fx','Fy','Fz','Mx','My','Mz','B'):
                    retain(reaction_extrema,f'S{reaction["support_index"]}/{key}',reaction[key],a,reaction['x'],'support',
                        dict(coexistent_reaction_vector=dict(reaction),
                             coexistent_all_support_vectors=[dict(r) for r in solution.support_reactions],
                             coexistent_attachment_vectors=attachment_vectors,
                             coexistent_constraint_reactions=[dict(r) for r in solution.reactions],
                             reaction_reference='Centroid-referred physical Fx/Fy/Fz/Mx/My/Mz and generalized B; same case and translation, not independent maxima combined'))
            if observer:
                values=observer(solution,a,loads,stations)
                for key,value in (values or {}).items():
                    value=finite(value,'observer metric '+key)
                    if value<0:raise ValueError('Observer convergence metric must be nonnegative')
                    observed[key]=max(observed.get(key,0.),value)
            if progress:progress(case.id,level,number+1,len(translations))
        peaks={**{k:max(abs(v['min']['value']),abs(v['max']['value'])) for k,v in extrema.items()},
               **{'reaction/'+k:max(abs(v['min']['value']),abs(v['max']['value'])) for k,v in reaction_extrema.items()},
               **{f'segment/{i}/'+k:max(abs(v['min']['value']),abs(v['max']['value'])) for i,s in enumerate(segment_extrema) for k,v in s['extrema'].items()},
               **{'observer/'+k:v for k,v in observed.items()}}
        comparison={**{k+'/'+b:v[b]['value'] for k,v in extrema.items() for b in ('min','max')},
               **{'reaction/'+k+'/'+b:v[b]['value'] for k,v in reaction_extrema.items() for b in ('min','max')},
               **{f'segment/{i}/'+k+'/'+b:v[b]['value'] for i,s in enumerate(segment_extrema) for k,v in s['extrema'].items() for b in ('min','max')},
               **{'observer/'+k:v for k,v in observed.items()}}
        # Do not demand relative convergence of nominal zeros contaminated by
        # floating-point equilibrium residuals. Dimensional roundoff allowances
        # are 1000 machine eps times the current force/length scales, not an
        # engineering load tolerance; all raw extrema remain unchanged.
        eps=1000*math.ulp(1.)
        force_scale=max(1.,*(v for k,v in peaks.items() if k in ('N','Fy','Fz') or k.rsplit('/',1)[-1] in ('Fx','Fy','Fz')))
        moment_scale=max(force_scale*L,*(peaks[k] for k in ('My','Mz','T_equilibrated','Tsv','Tw_equilibrated')))
        bimoment_scale=max(moment_scale*L,peaks['B_equilibrated'])
        roundoff={}
        for key in comparison:
            base=key.rsplit('/',1)[0] if key.endswith(('/min','/max')) else key
            name=base.rsplit('/',1)[-1]
            if key.startswith('observer/'):scale=0.
            elif name in ('N','Fx','Fy','Fz'):scale=force_scale
            elif name in ('My','Mz','Mx','T_equilibrated','Tsv','Tw_equilibrated'):scale=moment_scale
            elif name in ('B','B_equilibrated'):scale=bimoment_scale
            elif name in ('u','v','w'):scale=L
            elif name=='chi':scale=1/L
            else:scale=1.
            roundoff[key]=eps*scale
        delta=None if previous is None else max(max(0.,abs(comparison.get(k,0.)-previous.get(k,0.))-roundoff.get(k,0.))/max(abs(comparison.get(k,0.)),abs(previous.get(k,0.)),1e-300) for k in set(comparison)|set(previous))
        stable=stable+1 if delta is not None and delta<=tolerance else 0
        history.append(dict(level=level,density=density,translations=len(translations),spatial_base_points=len(base_stations),relative_change=delta,stable_passes=stable,
                            peak_metrics=peaks,signed_comparison_metrics=comparison,roundoff_allowances=roundoff,equilibrium_absolute_max_N_Nmm=equilibrium_max,constraint_absolute_max=constraint_max))
        previous=comparison
        if stable>=consecutive_stable:break
    manifest=json.loads(json.dumps(dict(length=L,section=model.section,supports=model.supports,wheels=wheels,case=case,
            selfweight=selfweight,extra_dead=extra_dead,extra_dead_y_mm=extra_dead_y_mm,fixed_stations=fixed,divisions=divisions,max_refinements=max_refinements,tolerance=tolerance,consecutive_stable=consecutive_stable,
            travel_min_mm=travel_min_mm,travel_max_mm=travel_max_mm,segments=segments),default=asdict,allow_nan=False))
    return dict(case=asdict(case),converged=stable>=consecutive_stable,mathematically_certified_envelope=False,
        torsion_mesh_qualified=False,extrema=extrema,segment_extrema=segment_extrema,support_reaction_extrema=reaction_extrema,observer_peaks=observed,
        history=history,solve_count=total_solves,seconds=time.monotonic()-start,
        translation_events_mm=list(events),exact_translation_events=[e.as_record() for e in catalogue],approximate_event_side_probes=list(probes),
        spatial_base_stations_mm=list(base_stations),input_manifest=manifest,input_signature=signature(manifest),
        solver_source_hash=solver_hash,solver_source_unchanged=solver_hash==hashlib.sha256(Path(solver_source.__file__).read_bytes()).hexdigest())
