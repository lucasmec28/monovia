"""Physical capacity/mass inputs to characteristic underhung wheel actions.

Gravity reactions follow rigid-body force/moment equilibrium across TWO rails.
Capacity is metric tonnes of lifted mass, not a force in tonne-force. The bridge
mass includes its carriages but excludes the separately supplied trolley mass.
Two longitudinal carriage stations, each with two opposed bottom-flange wheels,
are an explicitly adopted equalized arrangement: four individual wheels/rail.

Horizontal loads are transparent characteristic inertial mechanics, not a full
code action envelope: Fx=-(mb+mt+mq)*ax*k and Fy=-(mt+mq)*ay*k, with mq=0 when
empty. Explicit left-rail fractions and equal wheel sharing are retained, never
silently inferred from vertical reactions. No hoisting psi or case multiplier is
applied here. The later case generator alone applies its own action factors.

Primary source: ABNT NBR 8400-1:2019, 6.2.3 and 6.2.3.1.1, printed pp23-24:
mass/acceleration calculation, driven/braked-wheel tread placement, and the
1/30 to 1/4 driven/braked wheel-load range. Those last mechanism checks are NOT
performed here. No arbitrary force cap, minimum or rolling lambda is invented.

Gravity G/Q are not reactions including horizontal overturning. CG heights,
wheel-drive layout, crane torsional transfer, and vertical redistribution from
horizontal inertia are not known. Required yaw transfer is reported where
specified rail fractions cannot balance the applied inertial yaw moment.
These limitations accompany every configuration; this module never approves a
crane, supplies missing physical inputs, or chooses a universal worst state.
"""
from dataclasses import asdict, dataclass, fields
from math import isclose, isfinite
from .model import checked_text, finite, signature
from .project import physical_wheel
from ..section_stress.recovery import ISection


SOURCE = 'ABNT NBR 8400-1:2019, 6.2.3 and 6.2.3.1.1, pp23-24; Newtonian inertia and independent two-rail gravity force/moment equilibrium'


@dataclass(frozen=True)
class BridgeReactionInputs:
    capacity_t: float
    bridge_span_mm: float
    bridge_mass_kg: float
    bridge_cg_from_left_mm: float
    trolley_mass_kg: float
    hook_min_from_left_mm: float
    hook_max_from_left_mm: float
    trolley_cg_minus_hook_mm: float
    carriage_station_spacing_mm: float
    contact_n_mm: float
    bridge_acceleration_m_s2: float
    trolley_acceleration_m_s2: float
    horizontal_dynamic_factor: float
    longitudinal_left_rail_fraction: float
    transverse_left_rail_fraction: float
    equalized_four_wheels_per_rail_adopted: bool
    point_force_transfer_adopted: bool
    geometry_mass_source: str
    equalization_source: str
    acceleration_source: str
    horizontal_factor_source: str
    horizontal_transfer_source: str
    gravity_m_s2: float = 9.80665

    def __post_init__(self):
        for item in fields(self):
            name = item.name
            if name.endswith('_source'):
                checked_text(getattr(self, name), name)
            elif name.endswith('_adopted'):
                if getattr(self, name) is not True:
                    raise ValueError(name + ' must be explicitly adopted')
            else:
                object.__setattr__(self, name, finite(getattr(self, name), name))
        for name in ('capacity_t', 'bridge_span_mm', 'carriage_station_spacing_mm', 'contact_n_mm', 'gravity_m_s2'):
            if getattr(self, name) <= 0:
                raise ValueError(name + ' must be positive')
        if min(self.bridge_mass_kg, self.trolley_mass_kg) < 0:
            raise ValueError('Bridge-only and trolley masses must be nonnegative explicit physical inputs')
        if self.horizontal_dynamic_factor < 1:
            raise ValueError('An adopted additional horizontal factor cannot reduce characteristic inertia below m*a')
        for name in ('longitudinal_left_rail_fraction', 'transverse_left_rail_fraction'):
            if not 0 <= getattr(self, name) <= 1:
                raise ValueError(name + ' must be between zero and one; right rail is the complement')
        L = self.bridge_span_mm
        if not 0 <= self.bridge_cg_from_left_mm <= L:
            raise ValueError('Bridge CG must lie between the two rail reference lines')
        if not 0 <= self.hook_min_from_left_mm <= self.hook_max_from_left_mm <= L:
            raise ValueError('Ordered hook travel limits must lie between the two rail reference lines')
        for hook in (self.hook_min_from_left_mm, self.hook_max_from_left_mm):
            if not 0 <= hook + self.trolley_cg_minus_hook_mm <= L:
                raise ValueError('Trolley CG must remain between rails throughout hook travel; uplift is outside this model')


def bridge_reaction_inputs_from_dict(data):
    """Strict physical-input route, with no top-running catalogue/preset mapping."""
    if not isinstance(data, dict):
        raise ValueError('Bridge reaction input must be an object')
    if set(data) - {f.name for f in fields(BridgeReactionInputs)}:
        raise ValueError('Unknown bridge reaction input field')
    try:
        return BridgeReactionInputs(**data)
    except TypeError as exc:
        raise ValueError('All physical masses, geometry, sharing and source inputs are required: ' + str(exc)) from exc


def _reactions(force, coordinate, span):
    right = force * (coordinate / span)
    return force - right, right


def _equilibrium(left, right, force, moment, span):
    residual_force = left + right - force
    residual_moment = right * span - moment
    # Receipts never turn floating-point roundoff into an external action.
    return dict(force_sum_N=left + right, applied_force_N=force,
                moment_about_left_Nmm=right * span, applied_moment_about_left_Nmm=moment,
                force_residual_N=residual_force, moment_residual_Nmm=residual_moment,
                force_balanced=isclose(left + right, force, rel_tol=1e-12, abs_tol=1e-9),
                moment_balanced=isclose(right * span, moment, rel_tol=1e-12, abs_tol=1e-6))


def generate_bridge_reactions(section, inputs):
    """Return JSON-safe endpoint × rail records with complete PhysicalWheel dicts.

    Four configurations are retained even if the hook limits happen to coincide.
    To use a record in the existing autonomous project route, pass its ``wheels``
    list to project_from_dict or instantiate PhysicalWheel(**row). These are
    alternate crane positions/selected rail responses, not four simultaneous
    cranes and not four trains to add together.
    """
    if not isinstance(section, ISection):
        raise ValueError('Explicit computed ISection geometry is required')
    if not section.doubly_symmetric or section.construction != 'rolled':
        raise ValueError('Autonomous bridge route currently supports doubly symmetric parallel rolled I only')
    if isinstance(inputs, dict):
        inputs = bridge_reaction_inputs_from_dict(inputs)
    if not isinstance(inputs, BridgeReactionInputs):
        raise ValueError('BridgeReactionInputs or its strict input dictionary is required')
    p = inputs
    payload = asdict(p)
    input_signature = signature(dict(section_signature=section.signature, inputs=payload))
    L = p.bridge_span_mm
    lifted_mass = p.capacity_t * 1000.
    Wb, Wt, Wq = (mass * p.gravity_m_s2 for mass in (p.bridge_mass_kg, p.trolley_mass_kg, lifted_mass))
    gb = _reactions(Wb, p.bridge_cg_from_left_mm, L)
    states = {}
    for loaded in (True, False):
        mq = lifted_mass if loaded else 0.
        states['loaded' if loaded else 'empty'] = dict(
            longitudinal_moving_mass_kg=p.bridge_mass_kg + p.trolley_mass_kg + mq,
            transverse_moving_mass_kg=p.trolley_mass_kg + mq,
            Fx_N=-(p.bridge_mass_kg + p.trolley_mass_kg + mq) * p.bridge_acceleration_m_s2 * p.horizontal_dynamic_factor,
            Fy_N=-(p.trolley_mass_kg + mq) * p.trolley_acceleration_m_s2 * p.horizontal_dynamic_factor)
    pending = [
        dict(code='horizontal_overturning_transfer', reason='G/Q are gravity-only reactions. Crane/trolley/hook CG heights and the actual mechanism are absent; vertical rail/carriage redistribution from horizontal actions is not calculated.'),
        dict(code='driven_braked_wheel_actions', reason='Driven/braked wheel location, traction distribution and the source 1/30 to 1/4 wheel-load requirement have not been qualified; all-wheel horizontal sharing is an explicitly adopted nominal model.'),
        dict(code='horizontal_dynamic_mechanism', reason='The additional H factor is explicitly supplied, not a calculated drive/swing transient. No rolling/skewing, buffers, wind or test/emergency mechanism is inferred.'),
        dict(code='full_system', reason='Capacity-to-gravity-reaction and nominal inertia mechanics do not qualify the bridge, runway, support connections, stability, contact or fatigue.')]
    configurations = []
    endpoint_receipts = []
    for endpoint, hook in (('endpoint_min', p.hook_min_from_left_mm), ('endpoint_max', p.hook_max_from_left_mm)):
        trolley = hook + p.trolley_cg_minus_hook_mm
        gt = _reactions(Wt, trolley, L)
        q = _reactions(Wq, hook, L)
        g = tuple(gb[i] + gt[i] for i in range(2))
        eq = dict(bridge_G=_equilibrium(*gb, Wb, Wb * p.bridge_cg_from_left_mm, L),
                  trolley_G=_equilibrium(*gt, Wt, Wt * trolley, L),
                  total_G=_equilibrium(*g, Wb + Wt, Wb * p.bridge_cg_from_left_mm + Wt * trolley, L),
                  lifted_Q=_equilibrium(*q, Wq, Wq * hook, L))
        horizontal = {}
        for state, totals in states.items():
            mq = lifted_mass if state == 'loaded' else 0.
            axk = p.bridge_acceleration_m_s2 * p.horizontal_dynamic_factor
            # Mz=-y*Fx for the runway-coordinate origin at the left rail.
            required_Mz = axk * (p.bridge_mass_kg * p.bridge_cg_from_left_mm + p.trolley_mass_kg * trolley + mq * hook)
            actual_Mz = -L * totals['Fx_N'] * (1 - p.longitudinal_left_rail_fraction)
            horizontal[state] = dict(**totals,
                left_Fx_N=totals['Fx_N'] * p.longitudinal_left_rail_fraction,
                right_Fx_N=totals['Fx_N'] * (1 - p.longitudinal_left_rail_fraction),
                left_Fy_N=totals['Fy_N'] * p.transverse_left_rail_fraction,
                right_Fy_N=totals['Fy_N'] * (1 - p.transverse_left_rail_fraction),
                required_inertial_yaw_Mz_Nmm=required_Mz,
                modeled_wheel_yaw_Mz_Nmm=actual_Mz,
                required_additional_yaw_transfer_Nmm=required_Mz - actual_Mz,
                yaw_balance_without_additional_transfer=isclose(required_Mz, actual_Mz, rel_tol=1e-12, abs_tol=1e-6))
        endpoint_receipts.append(dict(id=endpoint, hook_from_left_mm=hook, trolley_cg_from_left_mm=trolley,
                                     gravity_equilibrium=eq, horizontal=horizontal))
        for index, rail in enumerate(('left', 'right')):
            ident = endpoint + '/rail_' + rail
            rail_x_fraction = p.longitudinal_left_rail_fraction if index == 0 else 1 - p.longitudinal_left_rail_fraction
            rail_y_fraction = p.transverse_left_rail_fraction if index == 0 else 1 - p.transverse_left_rail_fraction
            wheels = []
            # Provenance travels with each individual wheel into the normal-case
            # observer's action ledger; the full assumptions remain in this receipt.
            provenance = ('Generated gravity-only bridge reactions and adopted nominal inertia; '
                          + ident + '; input ' + input_signature + '; ' + p.geometry_mass_source
                          + '; equalization: ' + p.equalization_source + '; H transfer: ' + p.horizontal_transfer_source)
            for station, offset in (('rear', -p.carriage_station_spacing_mm / 2), ('front', p.carriage_station_spacing_mm / 2)):
                for side in ('left', 'right'):
                    wheels.append(asdict(physical_wheel(section, id=ident + '/' + station + '/' + side,
                        offset_mm=offset, outstand_side=side, edge_to_contact_n_mm=p.contact_n_mm,
                        dead_N=g[index] / 4, lifted_N=q[index] / 4,
                        longitudinal_N=states['loaded']['Fx_N'] * rail_x_fraction / 4,
                        transverse_N=states['loaded']['Fy_N'] * rail_y_fraction / 4,
                        longitudinal_empty_N=states['empty']['Fx_N'] * rail_x_fraction / 4,
                        transverse_empty_N=states['empty']['Fy_N'] * rail_y_fraction / 4,
                        provenance=provenance, point_force_transfer_adopted=p.point_force_transfer_adopted)))
            reference = (lambda coordinate: coordinate if index == 0 else L - coordinate)
            configuration_pending = [dict(item) for item in pending]
            if any(not item['yaw_balance_without_additional_transfer'] for item in horizontal.values()):
                configuration_pending.append(dict(code='horizontal_yaw_transfer', reason='The adopted constant rail fractions do not balance inertial yaw for at least one load state. The endpoint receipt reports the additional required couple; it is not silently inserted into the wheel forces.'))
            configurations.append(dict(id=ident, endpoint_id=endpoint, selected_rail=rail,
                selected_rail_from_left_mm=0. if index == 0 else L,
                hook_from_left_mm=hook, trolley_cg_from_left_mm=trolley,
                hook_from_selected_rail_mm=reference(hook), trolley_cg_from_selected_rail_mm=reference(trolley),
                bridge_cg_from_selected_rail_mm=reference(p.bridge_cg_from_left_mm),
                gravity_rail_reactions=dict(bridge_G_N=gb[index], trolley_G_N=gt[index], dead_G_N=g[index], lifted_Q_N=q[index]),
                horizontal_rail_actions={state: dict(Fx_N=data['Fx_N'] * rail_x_fraction, Fy_N=data['Fy_N'] * rail_y_fraction)
                                         for state, data in states.items()},
                longitudinal_rail_fraction=rail_x_fraction, transverse_rail_fraction=rail_y_fraction,
                wheels=wheels, input_signature=input_signature, gravity_only_vertical_reactions=True,
                complete_dynamic_action_envelope=False, horizontal_vertical_redistribution_complete=False,
                design_approval=False, pending=configuration_pending, source=SOURCE))
    result = dict(schema='underslung_bridge_characteristic_reactions_v1', inputs=payload,
        input_signature=input_signature, section_signature=section.signature,
        capacity_lifted_mass_kg=lifted_mass, characteristic_lifted_weight_N=Wq,
        bridge_span_is_not_runway_suspension_spacing=True,
        hook_approaches_mm=dict(left=p.hook_min_from_left_mm, right=L - p.hook_max_from_left_mm),
        endpoint_receipts=endpoint_receipts, configurations=configurations,
        source=SOURCE, design_approval=False, external_reactions_required=False,
        endpoint_envelope_only=True, universal_worst_configuration_selected=False,
        gravity_only_vertical_reactions=True, complete_dynamic_action_envelope=False,
        pending=pending, assumptions=[
            'capacity_t is metric tonnes of lifted mass; kilograms × supplied gravity gives N. No tonne-force substitution.',
            'Bridge-only mass includes its end carriages and excludes trolley; hook block/rigging inclusion must be stated in physical mass/capacity provenance.',
            'Bridge span is distance between runway rail reference lines, unrelated to the runway suspension grid.',
            'Two longitudinal stations centered about the train origin; two opposed contacts per station; four equal vertical and adopted horizontal shares per rail.',
            'x is longitudinal and y increases from physical left rail to right rail for BOTH selected rails; changing rail reference does not reverse acceleration signs.',
            'Positive acceleration transmits negative characteristic inertial force to the runway; later case sign variants and multipliers are not applied here.',
            'Horizontal dynamic factor is additional adopted H amplification, not the vertical hoisting psi; the case generator applies psi only to Q as its source prescribes.',
            'Four records are alternate configurations, never simultaneous trains. Endpoints are preserved separately; no unproved full-system worst position is selected.',
            'Gravity equilibrium does not supply missing inertia-height overturning redistribution, traction/drive qualification, or rolling/skewing actions.'])
    def check_finite(value):
        if isinstance(value, float) and not isfinite(value):
            raise ValueError('Bridge reaction arithmetic overflow')
        if isinstance(value, dict):
            for item in value.values(): check_finite(item)
        elif isinstance(value, (tuple, list)):
            for item in value: check_finite(item)
    check_finite(result)
    return result
