"""Physical autonomous project, separate from the external-stress local format.

The 3000 mm suspension grid is a user-adopted spacing, not beam length/fixity.
Helpers derive load/support height and sectorial coordinates from section data.
"""
from dataclasses import dataclass,field,asdict,fields
from math import isclose,pi
from ..section_stress.recovery import ISection,section_properties,geometric_properties,bottom_contact
from ..autonomous_frame.solver import FrameModel
from .model import PhysicalWheel,finite,selfweight_N_per_mm,checked_text


def physical_wheel(section,*,id,offset_mm,outstand_side,edge_to_contact_n_mm,dead_N,lifted_N,
                   longitudinal_N,transverse_N,provenance,point_force_transfer_adopted,
                   longitudinal_empty_N=None,transverse_empty_N=None,longitudinal_vertical_N=0.,transverse_vertical_N=0.,
                   longitudinal_vertical_empty_N=None,transverse_vertical_empty_N=None,
                   retained_lifted_N=0.,suspended_mass_accounting='legacy_retained_mass_unspecified'):
    try:c=bottom_contact(section,edge_to_contact_n_mm,outstand_side)
    except ArithmeticError as exc:raise ValueError('Contact/section arithmetic outside numerical domain') from exc
    return PhysicalWheel(id,offset_mm,c['y_mm'],c['z_mm'],c['omega_mm2'],dead_N,lifted_N,
        longitudinal_N,transverse_N,provenance,point_force_transfer_adopted,longitudinal_empty_N,transverse_empty_N,
        longitudinal_vertical_N,transverse_vertical_N,longitudinal_vertical_empty_N,transverse_vertical_empty_N,
        retained_lifted_N,suspended_mass_accounting)


def top_suspension_point(section,*,id,x_mm,y_mm,restrain,provenance):
    try:p=geometric_properties(section)
    except ArithmeticError as exc:raise ValueError('Suspension/section arithmetic outside numerical domain') from exc
    x=finite(x_mm,'x');y=finite(y_mm,'support transverse coordinate')
    checked_text(id,'Suspension identity');checked_text(provenance,'Support-model provenance')
    if abs(y)>section.bf_mm/2:raise ValueError('Suspension coordinate outside physical top flange')
    if not isinstance(restrain,dict) or not restrain:raise ValueError('Explicit components/prescribed values required, no inferred fixity')
    if set(restrain)-{'ux','uy','uz','phi','theta_y','theta_z','chi'}:raise ValueError('Unknown support DOF')
    for key,value in restrain.items():finite(value,'support '+key)
    return dict(id=id,x=x,y=y,z=section.d_mm-p['centroid_from_bottom_mm'],
        omega=-y*(p['top_z_mid_mm']-p['z_sc_mm']),restrain=dict(restrain),provenance=provenance,
        coordinate_basis='Top flange physical surface; normalized flange-midline sectorial mode; no automatic restraint')


@dataclass
class AutonomousUnderslungProject:
    section:ISection
    length_mm:float
    supports:list
    wheels:list[PhysicalWheel]
    E_mpa:float
    nu:float
    material_source:str
    density_kg_m3:float=7850.
    extra_dead_N_per_mm:float=0.
    extra_dead_source:str=''
    support_grid_spacing_mm:float=3000.
    support_grid_source:str='User-adopted 3 m suspension spacing; restraints and total length specified separately.'
    max_element_length_mm:float=500.
    capacity_tf:float|None=None
    actual_project:bool=False
    source_notes:str=''
    travel_min_mm:float|None=None
    travel_max_mm:float|None=None
    travel_source:str=''
    fy_mpa:float|None=None
    fu_mpa:float|None=None
    material_ratio_confirmed:bool=False
    extra_dead_kind:str='steel_or_equipment'
    extra_dead_y_mm:float|None=None
    extra_dead_z_mm:float|None=None
    supplementary_en_resistance_gamma:float|None=None
    supplementary_en_source:str=''
    section_mass_kg_per_m:float|None=None
    section_mass_source:str=''
    bridge_reaction_ledger:dict|None=None
    en_fatigue_inputs:dict|None=None
    contact_inputs:dict|None=None
    service_inputs:dict|None=None

    def validate(self):
        if not isinstance(self.section,ISection):raise ValueError('Physical I section required')
        if not self.section.doubly_symmetric:raise ValueError('Current decoupled sectional stiffness needs a doubly-symmetric I; unequal flange global coupling is not inferred')
        if self.section.construction=='rolled' and 2*self.section.bottom_root_radius_mm>self.section.d_mm-2*self.section.tf_mm:raise ValueError('Symmetric circular root fillets overlap inside the web height')
        for key in ('length_mm','E_mpa','density_kg_m3','support_grid_spacing_mm','max_element_length_mm'):
            if finite(getattr(self,key),key)<=0:raise ValueError(key+' must be positive')
        if finite(self.extra_dead_N_per_mm,'extra dead')<0:raise ValueError('Additional permanent UDL cannot be negative')
        if self.extra_dead_N_per_mm>0:
            if self.extra_dead_y_mm is None or self.extra_dead_z_mm is None:raise ValueError('Nonzero accessory weight requires explicit load-line y and z, not an assumed centroid')
            finite(self.extra_dead_y_mm,'accessory y');finite(self.extra_dead_z_mm,'accessory z')
        if self.capacity_tf is not None and finite(self.capacity_tf,'capacity')<=0:raise ValueError('Nominal capacity must be positive')
        if type(self.actual_project) is not bool:raise ValueError('Project/example identity must be explicit')
        if type(self.material_ratio_confirmed) is not bool:raise ValueError('Material ratio confirmation must be boolean')
        if self.supplementary_en_resistance_gamma is not None:
            if finite(self.supplementary_en_resistance_gamma,'supplementary EN resistance gamma')<1:raise ValueError('Supplementary EN resistance gamma must be >=1')
            if not isinstance(self.supplementary_en_source,str) or not self.supplementary_en_source.strip():raise ValueError('Identify the explicitly adopted supplementary EN resistance basis/factor')
        for key in ('fy_mpa','fu_mpa'):
            if getattr(self,key) is not None and finite(getattr(self,key),key)<=0:raise ValueError(key+' must be positive')
        if self.fy_mpa is not None and self.fu_mpa is not None and self.fy_mpa>self.fu_mpa:raise ValueError('Yield strength cannot exceed tensile strength')
        if (self.travel_min_mm is None)!=(self.travel_max_mm is None):raise ValueError('Both physical travel limits are required together')
        if self.travel_min_mm is not None:
            lo=finite(self.travel_min_mm,'travel minimum');hi=finite(self.travel_max_mm,'travel maximum')
            if not lo<hi:raise ValueError('Positive physical travel interval required')
            if not isinstance(self.travel_source,str) or not self.travel_source.strip():raise ValueError('Physical travel/endstop location provenance required')
        for key in ('material_source','extra_dead_source','support_grid_source','source_notes'):
            checked_text(getattr(self,key),key,required=False)
        checked_text(self.travel_source,'Travel source',required=False)
        checked_text(self.supplementary_en_source,'Supplementary EN source',required=False)
        checked_text(self.section_mass_source,'Profile mass source',required=False)
        if self.section_mass_kg_per_m is not None:
            if finite(self.section_mass_kg_per_m,'profile mass per length')<=0 or not self.section_mass_source.strip():raise ValueError('Explicit positive profile mass needs its manufacturer/project source')
        elif self.section.construction!='rolled':raise ValueError('Welded profile selfweight needs explicit complete mass including weld metal; first automatic mass domain is symmetric rolled I')
        if not self.material_source.strip() or not self.extra_dead_source.strip():raise ValueError('Material and additional permanent-load adoption source required, including declared zero')
        if not self.wheels or any(not isinstance(w,PhysicalWheel) for w in self.wheels):raise ValueError('Individual physical wheel train required')
        if self.travel_min_mm is not None and any(self.travel_min_mm+w.offset_mm<0 or self.travel_max_mm+w.offset_mm>self.length_mm for w in self.wheels):raise ValueError('Declared physical travel puts a wheel outside this runway; separate entry/exit model required')
        if len({w.id for w in self.wheels})!=len(self.wheels):raise ValueError('Repeated wheel ID')
        for wheel in self.wheels:
            side='left' if wheel.y_mm<0 else 'right'
            contact=bottom_contact(self.section,self.section.bottom_width/2-abs(wheel.y_mm),side)
            for key in ('y_mm','z_mm','omega_mm2'):
                if not isclose(getattr(wheel,key),contact[key],rel_tol=1e-12,abs_tol=1e-12):raise ValueError('Wheel '+wheel.id+' geometry does not match the actual bottom contact/section: '+key)
        if not self.supports or any(not s.get('id') or not s.get('provenance') for s in self.supports):raise ValueError('Each actual/adopted suspension point needs identity and provenance')
        if len({s['id'] for s in self.supports})!=len(self.supports):raise ValueError('Repeated support ID')
        if any(not 0<=s['x']<=self.length_mm for s in self.supports):raise ValueError('Suspension outside runway')
        for support in self.supports:
            expected=top_suspension_point(self.section,id=support['id'],x_mm=support['x'],y_mm=support['y'],
                restrain=support['restrain'],provenance=support['provenance'])
            for key in ('z','omega'):
                if not isclose(finite(support[key],'support '+key),expected[key],rel_tol=1e-12,abs_tol=1e-12):raise ValueError('Suspension '+support['id']+' does not match the physical top-flange attachment: '+key)
        if self.bridge_reaction_ledger is not None:
            ledger=self.bridge_reaction_ledger
            if not isinstance(ledger,dict):raise ValueError('Bridge reaction ledger must be an object')
            if set(ledger)!={'schema','inputs','selected_configuration_id','input_signature','section_signature','selected_configuration','endpoint_receipt','pending'}:raise ValueError('Malformed bridge reaction ledger')
            if ledger.get('schema')=='LRO_BOUND_BRIDGE_INERTIA_LEDGER_V1':
                from .inertia_bridge_adapter import make_ledger
                regenerated=make_ledger(self.section,ledger['inputs'],ledger['selected_configuration_id'])
            else:regenerated=make_bridge_reaction_ledger(self.section,ledger['inputs'],ledger['selected_configuration_id'])
            from .model import signature
            if signature(ledger)!=signature(regenerated):raise ValueError('Bridge reaction ledger is stale or altered; regenerate from physical inputs')
            if signature([asdict(w) for w in self.wheels])!=signature([asdict(PhysicalWheel(**w)) for w in regenerated['selected_configuration']['wheels']]):raise ValueError('Selected physical wheels differ from the bound bridge configuration')
            if self.capacity_tf is None or self.capacity_tf!=regenerated['inputs']['capacity_t']:raise ValueError('Nominal bridge capacity differs from the selected physical reaction scenario')
        if self.service_inputs is not None:
            if not isinstance(self.service_inputs,dict):raise ValueError('Physical service inputs must be an object')
            from ..serviceability.autonomous_adapter import ENServicePhysicalInputs
            try:ENServicePhysicalInputs(**self.service_inputs).validate()
            except TypeError as exc:raise ValueError('Invalid or truncated physical service inputs') from exc
        if self.contact_inputs is not None:
            from ..contact.autonomous_adapter import physical_from_dict
            physical_from_dict(self.contact_inputs)
        if self.en_fatigue_inputs is not None:
            from ..fatigue.autonomous_adapter import ENPhysicalFatigueInputs
            if not isinstance(self.en_fatigue_inputs,dict):raise ValueError('EN fatigue physical inputs must be an object')
            try:ENPhysicalFatigueInputs(**self.en_fatigue_inputs).validate()
            except TypeError as exc:raise ValueError('Missing or unknown EN fatigue physical input: '+str(exc)) from exc
        from lro_beams.autonomous_actions import factors_8800
        factors_8800('service_rare',psi=1.,extra_dead_kind=self.extra_dead_kind)
        return self

    def frame_model(self,mesh_mm=None):
        self.validate();properties=section_properties(self.section,self.E_mpa,self.nu)
        return FrameModel(self.length_mm,properties['frame_section'],self.supports,
            max_element_length=self.max_element_length_mm if mesh_mm is None else mesh_mm)

    def selfweight(self):
        if self.section_mass_kg_per_m is not None:return self.section_mass_kg_per_m*9.80665/1000
        if self.section.construction!='rolled':raise ValueError('Complete section mass required, including weld metal')
        # Four symmetric circular root fills: 4(r²−pi*r²/4). Do not reuse
        # the reduced stiffness area for mass or omit physical fillet metal.
        area=geometric_properties(self.section)['A_mm2']+(4-pi)*self.section.bottom_root_radius_mm**2
        return selfweight_N_per_mm(area,self.density_kg_m3)

    def mass_basis(self):
        return dict(selfweight_N_per_mm=self.selfweight(),manufacturer_mass_kg_per_m=self.section_mass_kg_per_m,
            source=self.section_mass_source if self.section_mass_kg_per_m is not None else 'Derived nominal symmetric rolled I: three rectangles plus four circular root fills, using supplied density/radius.',
            fillet_stiffness_credit=False,root_radius_applied_symmetrically=self.section_mass_kg_per_m is None)

    def suspended_mass_basis(self):
        from .inertia_bridge_adapter import from_dict
        from ..bridge_inertia.statics import suspended_mass_accounting
        ledger=self.bridge_reaction_ledger
        if ledger and ledger.get('schema')=='LRO_BOUND_BRIDGE_INERTIA_LEDGER_V1':
            return suspended_mass_accounting(from_dict(ledger['inputs']))
        return dict(complete_suspended_mass_accounting=False,retained_mass_explicit=False,
                    legacy_scope='No bound four-mass physical ledger; retained mass is unspecified')

    def to_dict(self):return asdict(self)

    def support_grid_audit(self):
        xs=sorted({s['x'] for s in self.supports})
        gaps=[b-a for a,b in zip(xs[:-1],xs[1:])]
        return dict(adopted_spacing_mm=self.support_grid_spacing_mm,source=self.support_grid_source,
            actual_station_coordinates_mm=xs,actual_spacing_mm=gaps,
            matches_adopted_grid=bool(gaps) and all(isclose(d,self.support_grid_spacing_mm,rel_tol=1e-12) for d in gaps),
            spacing_implies_no_restraint=True)


def project_from_dict(data):
    """Strict separate candidate format. No conversion of top-running projects."""
    if not isinstance(data,dict):raise ValueError('Autonomous physical project must be an object')
    if set(data)-{f.name for f in fields(AutonomousUnderslungProject)}:raise ValueError('Unknown autonomous project field')
    raw=dict(data)
    try:
        if not isinstance(raw['section'],dict) or set(raw['section'])-{f.name for f in fields(ISection)}:raise ValueError('Invalid/unknown section field')
        raw['section']=ISection(**raw['section'])
        if not isinstance(raw['wheels'],list):raise ValueError('Individual physical wheel list required')
        raw['wheels']=[PhysicalWheel(**w) if isinstance(w,dict) else None for w in raw['wheels']]
        if not isinstance(raw['supports'],list):raise ValueError('Explicit physical suspension list required')
        return AutonomousUnderslungProject(**raw).validate()
    except (KeyError,TypeError,AttributeError) as exc:raise ValueError('Missing or malformed autonomous physical input: '+str(exc)) from exc


def make_bridge_reaction_ledger(section,inputs,configuration_id):
    """Bind source physical inputs and one correlated rail/trolley configuration."""
    from .bridge_reactions import generate_bridge_reactions
    checked_text(configuration_id,'Bridge configuration identity')
    result=generate_bridge_reactions(section,inputs)
    matches=[c for c in result['configurations'] if c['id']==configuration_id]
    if len(matches)!=1:raise ValueError('Unknown generated bridge configuration')
    configuration=matches[0]
    endpoint=next(e for e in result['endpoint_receipts'] if e['id']==configuration['endpoint_id'])
    return dict(schema='LRO_BOUND_BRIDGE_REACTION_LEDGER_V1',inputs=result['inputs'],
        selected_configuration_id=configuration_id,input_signature=result['input_signature'],
        section_signature=result['section_signature'],selected_configuration=configuration,
        endpoint_receipt=endpoint,pending=result['pending'])
