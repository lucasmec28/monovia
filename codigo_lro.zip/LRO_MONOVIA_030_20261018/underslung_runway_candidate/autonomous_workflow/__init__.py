"""Isolated autonomous underhung integration; not part of the released app."""
