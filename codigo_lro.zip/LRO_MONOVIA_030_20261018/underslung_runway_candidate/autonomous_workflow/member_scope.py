"""Separate completed nominal member assessments from unexecuted obligations.

The selected procedures are alternatives where stated; EN zero-damage is not a
cumulative veto when NBR classified-life fatigue is selected. This summary does
not extend ordinary-region coverage to holes or connection-disturbed sections.
"""
from math import isfinite

def _nominal_pending(result, criterion):
    """Separate only explicitly identified, retained disturbed-region duties.

    This does not filter human text or forgive arbitrary pending items. The
    exact consumer, completed ordinary coverage, obligation identifier and
    index/message binding are required; every other pending item still blocks.
    Full-member and disturbed-region approval remain false in the summary.
    """
    pending=list((result or {}).get('pending',[]))
    if (criterion!='local_lower_flange' or not isinstance(result,dict)
        or result.get('kind')!='CMAA74_2020_verified_mechanical_family_consumer'
        or result.get('ordinary_nominal_points_qualified') is not True
        or result.get('operating_configuration_envelope_complete') is not True
        or not result.get('transfer_sections_excluded')):
        return pending,[]
    excluded=set();obligations=[]
    for row in result.get('pending_obligations',[]):
        if not isinstance(row,dict):continue
        index=row.get('pending_index')
        if (row.get('id')=='SUSPENSION_LOAD_TRANSFER_REGIONS'
            and row.get('scope')=='disturbed_suspension_regions'
            and row.get('status')=='BEAM_CHECK_NOT_QUALIFIED'
            and type(index) is int and 0<=index<len(pending) and index not in excluded
            and row.get('message')==pending[index]
            and row.get('regions')==result['transfer_sections_excluded']):
            excluded.add(index);obligations.append(dict(row))
    return [reason for i,reason in enumerate(pending) if i not in excluded],obligations


def _nested_assessment_pending(result):
    """Pending point/check evidence cannot be hidden by a sufficient parent.

    Traverse assessment containers only, not arbitrary provenance/source data.
    The sole recognized region exception is handled at consumer root above;
    nested numerical/material/method pending remains an ordinary-scope blocker.
    """
    issues=[]
    def visit(node,path,root=False):
        if not isinstance(node,dict):return
        if not root:
            reasons=node.get('pending',[])
            if reasons:
                issues.extend(path+': '+str(reason) for reason in
                              (reasons if isinstance(reasons,(list,tuple)) else [reasons]))
            status=str(node.get('status',''))
            if 'PENDING' in status or 'SOURCE_CHANGED' in status:
                issues.append(path+': '+status)
        for key in ('checks','segments','families','points','point_results','spans'):
            for index,child in enumerate(node.get(key,[])):
                visit(child,path+'/'+key+'/'+str(index))
        for key in ('plain_global_result','lower_local_result','checks_by_original_source'):
            if node.get(key):visit(node[key],path+'/'+key)
    visit(result,'assessment',root=True)
    return issues

def summarize_nominal_member(global_result,local_result,fatigue_result,service_result):
    def checks(result):
        if not isinstance(result,dict):return []
        rows=list(result.get('checks',[]))
        if result.get('kind')=='NBR8400_2_source_qualified_planar_nominal_member_fatigue':
            bound=result.get('bound',{});ratios=bound.get('component_utilizations',{})
            values=list(ratios.values())+[bound.get('combined_utilization_upper_bound')]
            if result.get('input_valid') is True and len(ratios)==3 and all(type(v) in (int,float) and isfinite(v) and v>=0 for v in values):
                rows.extend(dict(utilization=v,actual_failure_proven=False) for v in values)
        for key in ('segments','families','points','point_results'):
            for row in result.get(key,[]):rows.extend(checks(row))
        for key in ('plain_global_result','lower_local_result','checks_by_original_source'):
            if result.get(key) and not (key in ('plain_global_result','lower_local_result') and result.get('point_results')):rows.extend(checks(result[key]))
        for row in result.get('spans',[]):rows.extend(row.get('checks',[]))
        return rows
    outcomes=[];unqualified_regions=[]
    for key,result,pass_field in (
        ('global_member',global_result,'sufficient_member_criteria_satisfied'),
        ('local_lower_flange',local_result,'ordinary_nominal_ASD_sufficient' if (local_result or {}).get('kind','').startswith('CMAA') or 'ordinary_nominal_ASD_sufficient' in (local_result or {}) else 'sufficient_prescribed_nominal_points_satisfied'),
        ('nominal_fatigue',fatigue_result,'qualified_nominal_detail_modes'),
        ('service',service_result,'sufficient_member_service_criteria_satisfied')):
        rows=checks(result)
        status=str((result or {}).get('status','PENDING'))
        nominal_pending,region_obligations=_nominal_pending(result,key)
        nominal_pending.extend(_nested_assessment_pending(result))
        unqualified_regions.extend(region_obligations)
        complete=bool(rows) and not nominal_pending and 'PENDING' not in status and 'SOURCE_CHANGED' not in status
        actual_failure=bool((result or {}).get('actual_failure_proven')) or any(c.get('actual_failure_proven') for c in rows)
        passed=complete and not actual_failure and (result or {}).get(pass_field) is True
        if key=='global_member':passed=passed and result.get('sufficient_nominal_section_criteria_satisfied') is True
        outcomes.append(dict(id=key,assessment_complete=complete,criterion_satisfied=passed,
            status='FAIL' if actual_failure else 'NOT_ASSESSED' if not complete else 'SATISFIED' if passed else 'INCONCLUSIVE_SUFFICIENT_BOUND',
            checks_count=len(rows),actual_failure_proven=actual_failure,
            nominal_pending=nominal_pending,separately_unqualified_region_ids=[r['id'] for r in region_obligations]))
    complete=all(x['assessment_complete'] for x in outcomes);passed=complete and all(x['criterion_satisfied'] for x in outcomes)
    return dict(status='FAIL' if any(x['actual_failure_proven'] for x in outcomes) else 'NOT_ASSESSED' if not complete else 'SATISFIED' if passed else 'INCONCLUSIVE_SUFFICIENT_BOUND',
        assessment_complete=complete,criteria_satisfied=passed,nominal_member_scope_qualified=passed,criteria=outcomes,
        scope='Declared normal-action domain, ordinary rolled nominal member regions and independently verified global contact-line service response',
        whole_member_approval=False,holes_or_connection_disturbed_regions_qualified=False,
        unqualified_region_obligations=unqualified_regions,
        external_efforts_required=False,wheels_mechanisms_building_required_for_this_summary=False)
