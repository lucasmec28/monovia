"""Autonomous physical-input orchestration, isolated candidate, not approval.

No external demand, imported Robot tensor, or catalogue admissible capacity is
used. All beam actions and point stresses are computed inside this workflow.
Numerical sampling, FE convergence and strength-method coverage are distinct.
"""
from dataclasses import dataclass,asdict
from pathlib import Path
import hashlib,time,math
from .model import signature
from .cases import generate_normal_cases
from .moving import scan_moving_case
from ..stability.reference import model_fork_segments


@dataclass(frozen=True)
class AnalysisControls:
    divisions:int=2
    max_refinements:int=4
    moving_tolerance:float=.01
    moving_stable_passes:int=2
    max_mesh_refinements:int=2
    mesh_tolerance:float=.01
    mesh_stable_passes:int=2

    def __post_init__(self):
        for k in ('divisions','max_refinements','moving_stable_passes','mesh_stable_passes'):
            if type(getattr(self,k)) is not int or getattr(self,k)<1:raise ValueError(k+' must be a positive integer')
        if type(self.max_mesh_refinements) is not int or not 0<=self.max_mesh_refinements<=6:raise ValueError('Mesh refinement budget must be integer 0..6')
        for k in ('moving_tolerance','mesh_tolerance'):
            v=getattr(self,k)
            if isinstance(v,bool) or not isinstance(v,(int,float)) or not math.isfinite(v) or not 0<v<1:raise ValueError('Invalid '+k)


def source_receipt():
    from .source_manifest import numerical_source_receipt
    return numerical_source_receipt()


def _mesh_delta(current,previous):
    a=current['history'][-1]['signed_comparison_metrics'];b=previous['history'][-1]['signed_comparison_metrics']
    # Mesh station topology may change, but the named global/segment/support
    # quantities and observer criteria must stay identical for this comparison.
    if set(a)!=set(b):return None
    ra=current['history'][-1]['roundoff_allowances'];rb=previous['history'][-1]['roundoff_allowances']
    return max((max(0.,abs(a[k]-b[k])-max(ra.get(k,0.),rb.get(k,0.)))/max(abs(a[k]),abs(b[k]),1e-300) for k in a),default=0.)


def _supplementary_member(project,case,model,scan,mesh_history,converged):
    """Real internal evidence production, never a user-set proof flag."""
    from ..global_response.numerical_producer import verify_moving_response
    from ..stability.c2_adapter import Qualification,evaluate_segment
    from ..stability.reference import transverse_dead_load_radius_guard
    from ..section_stress.whole_section_bounds import whole_section_shear_bound
    if case.family!='ULS8800':return dict(status='NOT_APPLIED_TO_THIS_ACTION_BASIS',checks=[],pending=[])
    if project.supplementary_en_resistance_gamma is None or project.fy_mpa is None:
        return dict(status='INPUT_REQUIRED',checks=[],pending=['Supplementary EN resistance basis/factor and steel fy are required; no silent NBR/EN factor transfer.'])
    if scan is None:return dict(status='NUMERICAL_RESPONSE_UNAVAILABLE',checks=[],pending=['No internally computed response.'])
    fields=('N','My','Mz','B_equilibrated','Fy','Fz','Tsv','Tw_equilibrated')
    evidence=verify_moving_response(model,project.wheels,case,scan,selfweight=project.selfweight(),
        extra_dead=project.extra_dead_N_per_mm,extra_dead_y_mm=project.extra_dead_y_mm or 0.,
        observation_points=scan['spatial_base_stations_mm'],mesh_converged=converged,mesh_history=mesh_history,fields=fields)
    parcels=[dict(qy=0.,qz=-project.selfweight()*case.support_dead,y=0.,z=0.)]
    if project.extra_dead_N_per_mm:
        parcels.append(dict(qy=0.,qz=-project.extra_dead_N_per_mm*case.extra_dead,y=project.extra_dead_y_mm,z=project.extra_dead_z_mm))
    radius=transverse_dead_load_radius_guard(project.wheels,case,distributed_parcels=parcels)
    valid=evidence['evidence_kind']=='fixed_FE_extrema_mesh_converged'
    qualification=Qualification(case_id=case.id,action_basis_source=case.source,
        method_adoption_source=project.supplementary_en_source,bounds_are_upper=False,
        bounds_source='Internal all-translation fixed-FE polynomial extrema plus computed spatial/moving/mesh convergence; not a continuum enclosure.' if valid else 'Unqualified sampled response; numerical evidence not established.',
        torsion_mesh_qualified=valid,no_destabilizing_transverse_load_radius=radius['no_destabilizing_transverse_load_radius'],
        uniform_undistorted_thin_wall_i_adopted=True,structural_steel_ambient=True,
        producer_kind='fixed_FE_extrema_mesh_converged' if valid else 'analytical_upper',
        producer_receipt=evidence.get('producer_receipt'))
    results=[]
    for segment in evidence['segment_extrema'] if valid else scan['segment_extrema']:
        shear=None;shear_error=None
        try:
            def upper(key):return max(abs(segment['extrema'][key][b]['value']) for b in ('min','max'))
            shear=whole_section_shear_bound(project.section,abs_Fy_N=upper('Fy'),abs_Fz_N=upper('Fz'),abs_Tsv_Nmm=upper('Tsv'),abs_Tw_Nmm=upper('Tw_equilibrated'))
        except (ValueError,KeyError,ArithmeticError) as exc:shear_error=str(exc)
        result=evaluate_segment(model,project.section,segment,qualification,E_mpa=project.E_mpa,nu=project.nu,
            fy_mpa=project.fy_mpa,resistance_gamma=project.supplementary_en_resistance_gamma,
            shear_upper_mpa=None if shear is None else shear['tau_bound_mpa'],shear_bound_source=None if shear is None else shear['source'])
        for check in result['checks']:
            check.update(case_id=case.id,segment_start_mm=segment['start_mm'],segment_end_mm=segment['end_mm'])
        result['whole_nominal_shear']=shear
        if shear_error:result['pending'].append(shear_error)
        results.append(result)
    return dict(status='INTERNAL_NUMERICAL_MEMBER_CHECKS' if valid else 'NUMERICAL_EVIDENCE_PENDING',segments=results,
        response_evidence=evidence,load_radius_audit=radius,checks=[c for r in results for c in r['checks']],
        adopted_model_scope='Uniform prismatic undistorted thin-wall structural steel I at ambient temperature; explicitly adopted hybrid NBR action basis plus supplementary EN resistance, not a complete EN design.',
        pending=evidence['pending']+[issue for r in results for issue in r.get('pending',[])]+[r['section_pending'] for r in results if r.get('section_pending')]+([] if results else ['No eligible fork-to-fork segment in the declared suspension model.']))


def analyze_cases(project,cases,*,controls=None,progress=None):
    """Run explicitly identified cases; caller retains all omitted obligations."""
    from .local_observer import LocalStressObserver
    project.validate()
    controls=AnalysisControls() if controls is None else AnalysisControls(**controls) if isinstance(controls,dict) else controls
    if not isinstance(controls,AnalysisControls):raise ValueError('AnalysisControls required')
    cases=tuple(cases)
    if not cases or len({c.id for c in cases})!=len(cases):raise ValueError('Nonempty uniquely identified case set required')
    start=time.monotonic();source_start=source_receipt();rows=[];models={};pending=[];failures=[]
    grid=project.support_grid_audit()
    if not grid['matches_adopted_grid']:pending.append('Entered suspension stations do not match the declared adopted spacing. The calculation uses the entered coordinates; reconcile the project premise.')
    if project.travel_min_mm is None:
        pending.append('Physical travel/endstop limits are not supplied. The computed domain includes full train entry/exit and is not a design of the endstop or actual travel.')
    if project.section.construction!='rolled':
        pending.append('The first integrated autonomous qualification domain is a straight doubly symmetric rolled section. Welded geometry mechanics may be computed, but its detail qualification is not completed here.')
    if project.bridge_reaction_ledger:
        pending.extend('Equipment model: '+item.get('reason',str(item)) for item in project.bridge_reaction_ledger['pending'])
    for index,case in enumerate(cases):
        contact_audit=_physical_contact_domain(project,case)
        if not contact_audit['contact_domain_valid']:
            message='Unilateral wheel contact model invalid: upward wheel action occurs in the generated physical case; no tensile contact, clipping or silent hold-down is assumed.'
            rows.append(dict(case=asdict(case),sweep=None,local=None,mesh_history=[],numerical_converged=False,stability=None,
                true_fork_boundary_audit=None,error=message,physical_contact_audit=contact_audit,mathematical_enclosure_certified=False))
            pending.append(case.id+': '+message)
            if progress:progress(dict(stage='case_complete',case_index=index,case_count=len(cases),case_id=case.id,numerical_converged=False))
            continue
        previous=None;stable=0;mesh_history=[];last=None;local=None;error=None;boundaries=None
        for refinement in range(controls.max_mesh_refinements+1):
            mesh=project.max_element_length_mm/2**refinement
            try:
                if refinement not in models:models[refinement]=project.frame_model(mesh)
                model=models[refinement];boundaries=model_fork_segments(model)
                observer=LocalStressObserver(project,case,project.fy_mpa,project.fu_mpa,
                    material_ratio_confirmed=project.material_ratio_confirmed)
                def tick(case_id,level,n,total):
                    if progress:progress(dict(stage='moving',case_index=index,case_count=len(cases),case_id=case_id,
                        mesh_refinement=refinement,moving_refinement=level,sample_index=n,sample_count=total))
                current=scan_moving_case(model,project.wheels,case,selfweight=project.selfweight(),extra_dead=project.extra_dead_N_per_mm,
                    divisions=controls.divisions,max_refinements=controls.max_refinements,tolerance=controls.moving_tolerance,
                    consecutive_stable=controls.moving_stable_passes,progress=tick,observer=observer,
                    travel_min_mm=project.travel_min_mm,travel_max_mm=project.travel_max_mm,segments=boundaries['segments'],
                    extra_dead_y_mm=project.extra_dead_y_mm or 0.)
                local=observer.result();last=current
                delta=None if previous is None else _mesh_delta(current,previous)
                stable=stable+1 if current['converged'] and previous is not None and previous['converged'] and delta is not None and delta<=controls.mesh_tolerance else 0
                mesh_history.append(dict(refinement=refinement,max_element_length_mm=mesh,elements=len(model.nodes)-1,
                    case_id=case.id,scan_input_signature=current['input_signature'],source_fingerprint_at_start=source_start['fingerprint'],
                    solver_source_hash=current['solver_source_hash'],
                    moving_converged=current['converged'],mesh_relative_change=delta,stable_passes=stable,solve_count=current['solve_count'],seconds=current['seconds']))
                previous=current
                if stable>=controls.mesh_stable_passes:break
            except (ValueError,TypeError,ArithmeticError) as exc:
                error=f'{type(exc).__name__}: {exc}'
                break
        converged=error is None and last is not None and last['converged'] and stable>=controls.mesh_stable_passes
        try:stability=_supplementary_member(project,case,model,last,mesh_history,converged) if last is not None else None
        except (ValueError,TypeError,KeyError,ArithmeticError) as exc:
            stability=dict(status='METHOD_OR_NUMERICAL_DOMAIN_PENDING',checks=[],pending=[type(exc).__name__+': '+str(exc)])
        if local is not None:
            local['prescribed_nominal_point_checks_qualified'] = (case.family=='I' and converged and
                project.section.construction=='rolled' and local.get('local_nominal_comparison_available') is True and
                local.get('observed_local_states_supported') is True and
                not any(v['code'] in {'action_source_mismatch','wheel_contact_geometry','nbr_material_or_method','nominal_comparison_domain'} for v in local.get('pending',[])))
            local['prescribed_nominal_scope'] = 'NBR10084 §9.1.4 prescribed isolated-wheel points on ordinary rolled parallel bottom flange, both outstands/faces/cuts, selected family-I actions and converged numerical domain. Contact, defects, holes, support/disturbed zones and other action families are separate.'
        equipment_identity=_equipment_identity(project)
        if last is not None:
            last['equipment_configuration']=equipment_identity
            for pair in last.get('support_reaction_extrema',{}).values():
                for governor in pair.values():governor['equipment_configuration']=equipment_identity
        rows.append(dict(case=asdict(case),sweep=last,local=local,mesh_history=mesh_history,numerical_converged=converged,stability=stability,
            true_fork_boundary_audit=boundaries,error=error,physical_contact_audit=contact_audit,mathematical_enclosure_certified=False))
        if error:pending.append(case.id+': '+error)
        elif not converged:pending.append(case.id+': moving-position/spatial/FE mesh convergence not established within the declared budget.')
        if local:
            failures.extend(c for c in local.get('governing_point_checks',{}).values() if c.get('status')=='NÃO ATENDE')
        if stability:
            failures.extend(c for c in stability.get('checks',[]) if c.get('qualified') and c.get('status')=='NÃO ATENDE')
            pending.extend(case.id+': '+issue for issue in stability.get('pending',[]))
        if progress:progress(dict(stage='case_complete',case_index=index,case_count=len(cases),case_id=case.id,numerical_converged=converged))
    uls_rows=[r for r in rows if r['case']['family']=='ULS8800']
    member_complete=bool(uls_rows) and all(r.get('true_fork_boundary_audit',{}).get('reference_boundary_coverage',False) and
        bool((r.get('stability') or {}).get('segments')) and all(s.get('member_stability_qualified') and s.get('global_section_qualified')
        for s in (r.get('stability') or {}).get('segments',[])) for r in uls_rows if r.get('true_fork_boundary_audit') is not None) and all(r.get('true_fork_boundary_audit') is not None for r in uls_rows)
    local_rows=[r for r in rows if r['case']['family']=='I']
    local_nominal_qualified=bool(local_rows) and all((r.get('local') or {}).get('prescribed_nominal_point_checks_qualified') is True for r in local_rows)
    suspended_mass_basis=project.suspended_mass_basis()
    coverage=dict(complete_suspended_mass_accounting=suspended_mass_basis['complete_suspended_mass_accounting'],autonomous_physical_input_to_response=True,external_efforts_required=False,
        cases_evaluated=len(rows),cases_numerically_converged=sum(r['numerical_converged'] for r in rows),
        selfweight_computed=True,individual_wheel_transport_computed=True,eccentric_support_constraints_computed=True,
        selected_uls_c2_and_whole_nominal_section_checks_complete=member_complete,
        selected_family_I_prescribed_rolled_local_points_qualified=local_nominal_qualified,
        supplementary_member_checks_available=any((r.get('stability') or {}).get('checks') for r in rows),
        source_qualified_global_strength_complete=False,local_bottom_flange_complete=False,whole_section_stress_complete=False,
        fatigue_complete=False,wheel_contact_complete=False,suspension_connection_strength_complete=False,
        receiving_building_outside_component_scope=True,coexistent_suspension_reactions_available=any(r['sweep'] is not None for r in rows),
        endstop_test_emergency_complete=False,whole_design_complete=False)
    if not suspended_mass_basis['complete_suspended_mass_accounting']:
        pending.append('Legacy suspended mass accounting: retained block/accessory mass is unspecified, not known zero; no complete physical operating envelope is established.')
    pending.extend([
        'Global member resistance/stability, local load-introduction/root/contact, fatigue and physical suspension connections have separate qualification gates; an elastic solve does not clear them.',
        'Support constraints are declared ideal kinematics. Suspension joint stiffness/strength must realize them. Same-state reaction vectors are supplied for receiving-building design, which lies outside this runway-component scope.',
        'Normal-operation cases do not by themselves cover tests, endstops, emergency actions or every real equipment arrangement.',
    ])
    source_end=source_receipt();source_unchanged=source_start['fingerprint']==source_end['fingerprint']
    if not source_unchanged:
        coverage['selected_uls_c2_and_whole_nominal_section_checks_complete']=False
        coverage['selected_family_I_prescribed_rolled_local_points_qualified']=False
        for row in rows:
            if row.get('local'):row['local']['prescribed_nominal_point_checks_qualified']=False
        pending.append('Source files changed during calculation; freeze/recalculate before relying on this development run.')
    return dict(format='LRO_AUTONOMOUS_UNDERSLUNG_ANALYSIS',version=1,status='PARTIAL_AUTONOMOUS_ANALYSIS_NOT_WHOLE_DESIGN_APPROVAL',
        project=project.to_dict(),project_signature=signature(project.to_dict()),controls=asdict(controls),
        cases=rows,pending=list(dict.fromkeys(pending)),known_failures=failures,coverage=coverage,support_grid_audit=grid,mass_basis=project.mass_basis(),suspended_mass_accounting=suspended_mass_basis,
        timing=dict(seconds=time.monotonic()-start),source=source_start,source_unchanged_during_calculation=source_unchanged,
        source_after=source_end if not source_unchanged else None)


def run_autonomous_workflow(project,*,psi,equipment_group,classification_source,include_8800=True,
                            selected_case_ids=None,controls=None,progress=None):
    """Generate factors internally, then compute requested normal-operation cases."""
    generated=generate_normal_cases(project.wheels,psi=psi,equipment_group=equipment_group,
        classification_source=classification_source,include_8800=include_8800,
        extra_dead_N_per_mm=project.extra_dead_N_per_mm,extra_dead_kind=project.extra_dead_kind)
    if selected_case_ids is not None:
        ids=tuple(selected_case_ids)
        if not ids or len(ids)!=len(set(ids)) or set(ids)-{c.id for c in generated}:raise ValueError('Select known unique generated case IDs')
        selected=tuple(c for c in generated if c.id in ids)
    else:selected=generated
    result=analyze_cases(project,selected,controls=controls,progress=progress)
    result['case_generation']=dict(psi=psi,equipment_group=equipment_group,classification_source=classification_source,
        include_8800=include_8800,generated_ids=[c.id for c in generated],selected_ids=[c.id for c in selected],
        all_generated_cases_evaluated=len(selected)==len(generated))
    if len(selected)!=len(generated):result['pending'].insert(0,'Only the explicitly selected generated cases were evaluated; other normal-operation cases remain unevaluated.')
    if project.en_fatigue_inputs is not None:
        from ..fatigue.autonomous_adapter import ENPhysicalFatigueInputs,evaluate_autonomous_fatigue
        try:
            fatigue=evaluate_autonomous_fatigue(project,physical=ENPhysicalFatigueInputs(**project.en_fatigue_inputs),controls=controls,progress=progress)
        except (ValueError,TypeError,ArithmeticError) as exc:
            fatigue=dict(status='PHYSICAL_OR_METHOD_DOMAIN_PENDING',qualified_nominal_detail_modes=False,pending=[type(exc).__name__+': '+str(exc)])
        result['fatigue']=fatigue
        result['coverage']['ordinary_bottom_flange_nominal_fatigue_modes_sufficient']=(fatigue.get('lower_local_result') or {}).get('qualified_nominal_detail_modes') is True
        result['coverage']['ordinary_plain_section_global_fatigue_modes_sufficient']=(fatigue.get('plain_global_result') or {}).get('qualified_nominal_detail_modes') is True
        result['pending'].extend('EN nominal fatigue: '+v for v in fatigue.get('pending',[]))
        if fatigue.get('status')=='SUFFICIENT_CHECK_NOT_SATISFIED':
            result['pending'].append('The sufficient all-range no-count EN fatigue check is not satisfied; this is not proof of fatigue failure. A fuller spectrum/detail assessment or redesign is required.')
        result['source_unchanged_during_calculation']=result['source_unchanged_during_calculation'] and result['source']['fingerprint']==source_receipt()['fingerprint']
        if not result['source_unchanged_during_calculation']:
            result['coverage']['ordinary_bottom_flange_nominal_fatigue_modes_sufficient']=False
            result['coverage']['ordinary_plain_section_global_fatigue_modes_sufficient']=False
            result['pending'].append('Source changed during the combined normal/fatigue calculation; freeze and recalculate before relying on this development result.')
    if project.contact_inputs is not None:
        from ..contact.autonomous_adapter import evaluate_autonomous_contact
        try:
            contact=evaluate_autonomous_contact(project)
        except (ValueError,TypeError,ArithmeticError) as exc:
            contact=dict(status='CONTACT_PHYSICAL_OR_METHOD_DOMAIN_PENDING',contact_complete=False,pending=[type(exc).__name__+': '+str(exc)],known_failures=[])
        result['contact']=contact
        result['coverage']['wheel_contact_complete']=contact.get('complete_A_B_C_domain') is True and bool(contact.get('rows')) and all(r.get('contact_method_qualified') is True for r in contact['rows'])
        result['coverage']['wheel_contact_covered_action_domain_qualified']=bool(contact.get('rows')) and all(r.get('covered_action_domain_qualified') is True for r in contact['rows'])
        result['pending'].extend('Wheel/flange contact: '+str(v) for v in contact.get('pending',[]))
        result['known_failures'].extend(dict(c,wheel_id=row['wheel_id'],scope='Internally generated covered contact action domain') for row in contact.get('rows',[]) for c in row.get('covered_action_checks',[]) if c.get('qualified') and c.get('status')=='FAIL')
    if project.service_inputs is not None:
        from ..serviceability.autonomous_adapter import ENServicePhysicalInputs,evaluate_autonomous_serviceability
        try:
            service=evaluate_autonomous_serviceability(project,physical=ENServicePhysicalInputs(**project.service_inputs),controls=controls,progress=progress)
        except (ValueError,TypeError,ArithmeticError) as exc:
            service=dict(status='SERVICE_PHYSICAL_OR_METHOD_DOMAIN_PENDING',spans=[],pending=[type(exc).__name__+': '+str(exc)],known_failures=[])
        result['serviceability']=service
        result['coverage']['selected_configuration_member_vertical_service_qualified']=bool(service.get('spans')) and all(s.get('member_vertical_qualified') for s in service['spans']) and not service.get('pending')
        result['coverage']['selected_configuration_member_horizontal_service_qualified']=bool(service.get('spans')) and all(s.get('member_horizontal_qualified') for s in service['spans']) and not service.get('pending')
        result['pending'].extend('Member serviceability: '+str(v) for v in service.get('pending',[]))
        result['known_failures'].extend(service.get('known_failures',[]))
    return result


def _equipment_identity(project):
    if not project.bridge_reaction_ledger:return dict(source='Directly adopted individual physical wheel inputs',configuration_id=None)
    ledger=project.bridge_reaction_ledger;c=ledger['selected_configuration']
    return dict(configuration_id=ledger['selected_configuration_id'],input_signature=ledger['input_signature'],
        selected_rail=c.get('selected_rail'),hook_from_left_mm=c.get('hook_from_left_mm'),
        trolley_cg_from_left_mm=c.get('trolley_cg_from_left_mm'),lifted_cg_z_mm=c.get('lifted_cg_z_mm'),lifted_force_application_z_mm=c.get('lifted_force_application_z_mm'),transfer_model=c.get('transfer_model'),
        schema=ledger['schema'],source='Internally generated correlated bridge configuration; do not combine governing vectors across configurations')


def _physical_contact_domain(project,case):
    from .model import wheel_force_components
    if case.family=='EN_LINEAR_BASIS':return dict(contact_domain_valid=True,scope='Mathematical linear contribution, not a physical contact state; no contact approval',physical_case=False)
    ledger=project.bridge_reaction_ledger
    if ledger and ledger['schema']=='LRO_BOUND_BRIDGE_INERTIA_LEDGER_V1':
        from .inertia_bridge_adapter import physical_case_contact_audit
        audit=physical_case_contact_audit(ledger,case)
        return dict(contact_domain_valid=audit['no_hold_down_contact_valid'],scope='All eight common-bridge contacts, before selecting the analyzed rail',physical_case=True,receipt=audit)
    uplift=[];forces=[]
    for w in project.wheels:
        fx,fy,fz=wheel_force_components(w,case)
        vzx=w.longitudinal_vertical_N if case.loaded or w.longitudinal_vertical_empty_N is None else w.longitudinal_vertical_empty_N
        vzy=w.transverse_vertical_N if case.loaded or w.transverse_vertical_empty_N is None else w.transverse_vertical_empty_N
        scale=sum(map(abs,(w.dead_N*case.equipment_dead,w.lifted_N*case.lifted if case.loaded else 0.,w.retained_lifted_N*(case.lifted if case.retained_lifted is None else case.retained_lifted),vzx*case.longitudinal,vzy*case.transverse)))
        allowance=64*math.ulp(max(1.,scale))
        if fz>allowance:uplift.append(w.id)
        forces.append(dict(id=w.id,Fx=fx,Fy=fy,Fz=fz,vertical_roundoff_allowance_N=allowance))
    return dict(contact_domain_valid=not uplift,physical_case=True,scope='Supplied individual wheel train only; unspecified opposite rail not inferred',uplift_contacts=uplift,forces=forces)
