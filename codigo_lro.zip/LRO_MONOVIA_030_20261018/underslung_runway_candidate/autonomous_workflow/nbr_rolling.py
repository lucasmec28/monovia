"""Normal NBR rolling reaction, isolated four-contact runway bounding contract.

This is neither CMAA SK nor exceptional Annex-C SHE. Figure 6 is translated
from its GRAPH, not an equation printed in the standard. Only four physical
wheel-flange contacts (two rails, two longitudinal stations) are qualified.
Unequal vertical reactions produce a relaxed sufficient box, not an invented
physical couple, equilibrium certificate, operating history or wheel design.
N, mm; +z up. No externally entered wheel force is a user-facing input.
"""
from dataclasses import asdict, dataclass
from itertools import combinations
from math import fsum, isfinite
from pathlib import Path
import hashlib

from .model import signature, checked_text

SOURCE = 'ABNT NBR 8400-1:2019 6.2.3.3, Figures 6/7, printed pp25-26; 6.3.1(c), printed p36; NBR10084:2020 6.3/8.1.1'
PRIMARY_PDF_SHA256 = '18bee2ce461b29c70c2fd0f9eeae5de50629f66ed1f9ac6aea05d25c5b3af666'
GUIDANCE_MODEL = 'four_wheel_flange_contacts_no_bogies_or_separate_guides'
PAIRS = tuple(combinations(('HX', 'HY', 'Rlambda'), 2))
QUALIFICATION_CONTRACT_SHA256 = 'c9ff3c6003758ca8795595f5e10a91ac0722f1ea4b1d0c63c7e9c194dab4b27b'


def _real(value, label, *, positive=False):
    if (isinstance(value, bool) or not isinstance(value, (int, float)) or
            not isfinite(value) or abs(value) > 1e15 or positive and value <= 0):
        raise ValueError(label+' must be finite'+(' and positive' if positive else ''))
    return float(value)


def _text(value, label):
    return checked_text(value, label+' physical/source provenance')


@dataclass(frozen=True)
class NBRRollingGuidance:
    model: str
    geometry_source: str
    reference_adoption_source: str

    def __post_init__(self):
        if self.model != GUIDANCE_MODEL:
            raise ValueError('Only four actual wheel-flange contacts, no hardware bogies/equalizers or separate guides (mathematical bilinear mass allocation is distinct), are qualified')
        _text(self.geometry_source, 'Actual guidance geometry')
        _text(self.reference_adoption_source, 'Conservative static/service vertical-reference adoption')


def rolling_source_receipt():
    payload = dict(source=SOURCE, primary_pdf_sha256=PRIMARY_PDF_SHA256,
        module_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        qualification_contract_sha256=QUALIFICATION_CONTRACT_SHA256)
    return dict(**payload, fingerprint=signature(payload))


def lambda_from_geometry(p_mm, a_mm):
    """Graph transcription only; p is crane span, a actual station wheelbase."""
    p = _real(p_mm, 'Equipment rail span p', positive=True)
    a = _real(a_mm, 'Actual longitudinal guidance wheelbase a', positive=True)
    ratio = p/a
    if not isfinite(ratio) or ratio <= 0 or ratio > 12:
        raise ValueError('p/a outside the qualified Figure-6 graphic domain 0 < p/a <= 12; no extrapolation/clamp')
    coefficient = .05 if ratio <= 2 else .025*ratio if ratio < 8 else .20
    return dict(p_mm=p, a_mm=a, ratio=ratio, coefficient=coefficient,
        basis='Algebraic transcription of Figure-6 straight segments, NOT a printed normative equation',
        domain='0 < p/a <= 12; terminal 12 is inferred from the graphic grid, not printed text',
        source=SOURCE, runway_support_span_used=False, CMAA_factor_used=False)


def horizontal_pairs():
    """Keep all three candidates; downstream response, not force rank, governs."""
    return PAIRS


def _contacts(raw):
    rows = raw.get('contacts', ())
    if len(rows) != 4 or len({r.get('id') for r in rows}) != 4:
        raise ValueError('Exactly four distinct actual contacts required; opposed under-running pairs/bogies are not covered')
    result = []
    for row in rows:
        _text(row.get('id'), 'Contact identity')
        if type(row.get('rail_index')) is not int or row['rail_index'] not in (0, 1):
            raise ValueError('Two explicit rail identities required')
        xyz = tuple(_real(v, 'Contact coordinate') for v in row['position_mm'])
        if len(xyz) != 3:
            raise ValueError('Physical contact xyz required')
        result.append(dict(id=row['id'], rail_index=row['rail_index'], position_mm=xyz))
    xs = sorted({r['position_mm'][0] for r in result})
    if len(xs) != 2 or xs[0] == xs[1]:
        raise ValueError('Exactly two distinct longitudinal wheel stations required')
    rail_y = []
    for rail in (0, 1):
        side = [r for r in result if r['rail_index'] == rail]
        if len(side) != 2 or sorted(r['position_mm'][0] for r in side) != xs:
            raise ValueError('Exactly one actual wheel per station per rail required')
        ys = {r['position_mm'][1] for r in side}
        if len(ys) != 1:
            raise ValueError('Straight parallel rail contact geometry required')
        rail_y.append(ys.pop())
    if rail_y[1] <= rail_y[0] or len({r['position_mm'][2] for r in result}) != 1:
        raise ValueError('Two ordered rails in a common physical contact plane required')
    p, a = rail_y[1]-rail_y[0], xs[1]-xs[0]
    if raw.get('inputs', {}).get('rail_span_mm') != p or raw.get('inputs', {}).get('station_spacing_mm') != a:
        raise ValueError('Contact geometry must match common equipment rail span and wheelbase, not a beam span')
    return tuple(sorted(result, key=lambda r: (r['rail_index'], r['position_mm'][0]))), p, a


def four_contact_rolling_bound(raw_generated, *, psi, horizontal_dynamic_factor,
                               loaded, inertia_actions, guidance):
    """Derive each lambda reference from common G/B/Q and whole H parcels.

    Pbound_i = max(G+B+Q, G+psi*(B+Q)) + sum(abs(hd*HZ_event_i)).
    Q is absent while empty, B remains. HZ is first summed by physical event;
    cancellation inside a complete event vector is not destroyed. Only the
    inertia events selected in that two-effect pair enter this reference.
    This is an explicit conservative reference adoption, not literal psi text.
    Raw input authentication belongs to the common internally generated ledger.
    """
    if not isinstance(guidance, NBRRollingGuidance):
        raise ValueError('Explicit NBRRollingGuidance required; missing guidance is not zero rolling reaction')
    psi = _real(psi, 'Hoisting psi'); hd = _real(horizontal_dynamic_factor, 'H dynamics')
    if psi < 1 or hd < 1:
        raise ValueError('psi and sourced inertia dynamics cannot be reducing multipliers')
    if type(loaded) is not bool:
        raise ValueError('Loaded/empty state must be explicit')
    actions = tuple(inertia_actions)
    if len(set(actions)) != len(actions) or any(a not in ('HX', 'HY') for a in actions):
        raise ValueError('Distinct physical inertia events HX/HY required')
    contacts, p, a = _contacts(raw_generated)
    coefficient = lambda_from_geometry(p, a)
    ids = {r['id'] for r in contacts}
    origins = {ident: {'equipment': [], 'lifted': [], 'retained_lifted': [], 'HX': [], 'HY': []} for ident in ids}
    parcels = raw_generated.get('parcels', ())
    kinds, mass_actions = set(), set()
    for parcel in parcels:
        kind, action = parcel['kind'], parcel['action']
        if kind not in ('equipment', 'lifted', 'retained_lifted') or action not in ('gravity', 'HX', 'HY'):
            raise ValueError('Only separate common G/Q/B and raw HX/HY origins are accepted')
        key = (parcel['mass_id'], action)
        if key in mass_actions:
            raise ValueError('Duplicated common mass/action parcel')
        mass_actions.add(key); kinds.add(kind)
        loads = parcel['loads']
        if len(loads) != 4 or {r['contact_id'] for r in loads} != ids:
            raise ValueError('Each complete physical vector must retain every contact')
        for row in loads:
            ident = row['contact_id']; c = next(c for c in contacts if c['id'] == ident)
            if tuple(row['position_mm']) != c['position_mm']:
                raise ValueError('Parcel contact coordinates differ from common geometry')
            force = tuple(_real(v, 'Common raw vector') for v in row['force_N'])
            if len(force) != 3:
                raise ValueError('Complete Fx/Fy/Fz required')
            if action == 'gravity' and (force[0] or force[1] or force[2] > 0):
                raise ValueError('Nonnegative compressive gravity origins required; no clipping')
            if kind == 'lifted' and not loaded:
                continue
            origins[ident][kind if action == 'gravity' else action].append(-force[2])
    if kinds != {'equipment', 'lifted', 'retained_lifted'}:
        raise ValueError('Explicit common G, removable Q and retained B origins required, including sourced zero B')
    masses = {m for m, _ in mass_actions}
    if mass_actions != {(m, a) for m in masses for a in ('gravity', 'HX', 'HY')}:
        raise ValueError('Incomplete mass event vectors; missing H origin is not zero')
    bounds = []
    for contact in contacts:
        o = {key: fsum(values) for key, values in origins[contact['id']].items()}
        static = o['equipment']+o['retained_lifted']+o['lifted']
        dynamic = o['equipment']+psi*(o['retained_lifted']+o['lifted'])
        inertia = {event: hd*o[event] for event in actions}
        vertical_amplitude = fsum(abs(v) for v in inertia.values())
        lower = min(static, dynamic)-vertical_amplitude
        upper = max(static, dynamic)+vertical_amplitude
        if not isfinite(upper) or lower < 0:
            raise ValueError('Reference set includes loss of compressive contact; four-contact bound not qualified')
        H = coefficient['coefficient']*upper
        bounds.append(dict(**contact, gravity_origins_N={k:o[k] for k in ('equipment', 'retained_lifted', 'lifted')},
            static_reference_N=static, service_reference_N=dynamic, signed_vertical_inertia_N=inertia,
            vertical_reference_interval_N=(lower, upper), Pbound_N=upper,
            Fy_interval_N=(-H, H), vector_intervals_N=((0., 0.), (-H, H), (0., 0.))))
    payload = dict(schema='NBR8400_NORMAL_ROLLING_FOUR_CONTACT_BOUND_V1', contacts=bounds,
        lambda_receipt=coefficient, guidance=asdict(guidance), psi=psi, horizontal_dynamic_factor=hd,
        loaded=loaded, inertia_actions=actions, source=SOURCE, source_receipt=rolling_source_receipt(),
        raw_ledger_signature=signature(raw_generated), independent_sign_relaxation=True,
        whole_bridge_equilibrium_qualified=False, actual_wheel_distribution_claimed=False,
        cyclic_histories_created=0, Mx_applied=False, additional_psi_or_H_factor_on_Rlambda=False,
        reference_policy='Conservative max static/service wheel compression plus selected full-event vertical inertia; not a literal resolution of psi inside clause 6.2.3.3',
        scope='Sufficient per-runway reaction box at actual contacts; no physical four-wheel state/equilibrium or fatigue history assertion')
    return dict(**payload, receipt_signature=signature(payload))


def symmetric_physical_couples(rolling_bound, rail_index):
    """Only an explicitly equal-reference pair can be represented as a couple.

    This helper illustrates the source pair; the autonomous consumer uses the
    containing box. It does not prove that reference maxima coexist in time.
    """
    rows = [r for r in rolling_bound['contacts'] if r['rail_index'] == rail_index]
    if len(rows) != 2 or rows[0]['Pbound_N'] != rows[1]['Pbound_N']:
        raise ValueError('Equal wheel reference required for simplified symmetric couple')
    h = rows[0]['Fy_interval_N'][1]
    return dict(Fy_pairs_N=((h, -h), (-h, h)), reference_only=True,
        coexistent_operational_state_proven=False, source=SOURCE)
