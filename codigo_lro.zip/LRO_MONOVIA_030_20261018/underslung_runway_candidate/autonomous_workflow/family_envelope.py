"""Finite-FE numerical component boxes for ALL generated normal configurations.

Six physical station-pair force bases plus the permanent origins replace repeated
linear solves, never the actual signed wheel ledger.  Interval addition discards
correlation only in the unfavorable direction.  A box is NOT a coexistent stress
or reaction vector; its exceedance proves no actual case failure.  Translation
polynomials and computed mesh/spatial convergence are engineering evidence, not
a continuum/roundoff enclosure.  Normative and contact/detail gates stay separate.

This isolated module is not imported by the UI/pipeline.  Its own receipt includes
its hash as well as the shared numerical source manifest.  No caller-set proof
flag or externally supplied basis receipt can qualify a result.
"""
from dataclasses import asdict, dataclass, replace
from fractions import Fraction
from pathlib import Path
import hashlib
import math
import time

from .model import PhysicalWheel, MovingCase, physical_train_at, wheel_force_components, signature
from .cases import generate_normal_cases
from .inertia_bridge_adapter import generate_inertia_configurations, physical_case_contact_audit
from .moving import scan_moving_case
from .pipeline import AnalysisControls, _mesh_delta, source_receipt
from ..global_response.numerical_producer import verify_moving_response, EvidenceKind
from ..global_response.moving_point_bounds import ABS_TOL
from ..stability.reference import model_fork_segments, transverse_dead_load_radius_guard

FIELDS = ('N', 'My', 'Mz', 'B_equilibrated', 'Fy', 'Fz', 'Tsv', 'Tw_equilibrated')
VERIFIED = 'fixed_FE_component_family_bounds_verified'
PENDING = 'component_family_bounds_not_established'
FORCE_FIELDS = ('dead_N', 'lifted_N', 'retained_lifted_N', 'longitudinal_N', 'transverse_N',
                'longitudinal_empty_N', 'transverse_empty_N', 'longitudinal_vertical_N',
                'transverse_vertical_N', 'longitudinal_vertical_empty_N', 'transverse_vertical_empty_N')
GEOMETRY_FIELDS = ('offset_mm', 'y_mm', 'z_mm', 'omega_mm2')


def _require(condition, message):
    if not condition:
        raise ValueError(message)


def _finite(value):
    _require(not isinstance(value, bool) and isinstance(value, (float, int)) and math.isfinite(value),
             'Finite real interval endpoint required')
    return float(value)


def _interval(lower, upper):
    lower, upper = _finite(lower), _finite(upper)
    _require(lower <= upper, 'Ordered signed interval required')
    return dict(lower=lower, upper=upper)


def interval_product(a, b):
    """Outward rounded scalar interval product; exact zero remains zero."""
    a, b = _interval(a['lower'], a['upper']), _interval(b['lower'], b['upper'])
    if a['lower'] == a['upper'] == 0. or b['lower'] == b['upper'] == 0.:
        return _interval(0., 0.)
    values = [x*y for x in a.values() for y in b.values()]
    _require(all(math.isfinite(x) for x in values), 'Interval product overflow')
    lo, hi = min(values), max(values)
    return _interval(math.nextafter(lo, -math.inf), math.nextafter(hi, math.inf))


def interval_sum(items):
    items = tuple(_interval(x['lower'], x['upper']) for x in items)
    if not items or all(x['lower'] == x['upper'] == 0. for x in items):
        return _interval(0., 0.)
    lo, hi = math.fsum(x['lower'] for x in items), math.fsum(x['upper'] for x in items)
    return _interval(math.nextafter(lo, -math.inf), math.nextafter(hi, math.inf))


def assess_sufficient_limit(upper_demand, resistance):
    """A failed sufficient box test is inconclusive, never a witnessed FAIL."""
    demand, resistance = _finite(upper_demand), _finite(resistance)
    _require(demand >= 0 and resistance > 0, 'Nonnegative demand and positive resistance required')
    return dict(status='SUFFICIENT_BOUND_SATISFIED' if demand <= resistance else 'INCONCLUSIVE_SUFFICIENT_BOUND',
                upper_demand=demand, resistance=resistance, utilization=demand/resistance,
                actual_failure_proven=False,
                scope='Arithmetic comparison only; normative applicability and response evidence are separate required gates.')


def validate_paired_geometry(configurations):
    """Reject rather than average unequal physical opposed loads or geometry."""
    _require(len(configurations) == 8 and len({c['id'] for c in configurations}) == 8,
             'All eight distinct generated hook/height/rail configuration identities are required')
    reference, ordered = None, {}
    for configuration in configurations:
        wheels = sorted((PhysicalWheel(**w) if isinstance(w, dict) else w for w in configuration['wheels']),
                        key=lambda w: (w.offset_mm, w.y_mm))
        _require(len(wheels) == 4, 'Exactly two stations with two opposed physical contacts each required')
        offsets = sorted({w.offset_mm for w in wheels})
        _require(len(offsets) == 2, 'Exactly two longitudinal stations required')
        for offset in offsets:
            pair = [w for w in wheels if w.offset_mm == offset]
            _require(len(pair) == 2 and pair[0].y_mm < 0 < pair[1].y_mm and
                     pair[0].y_mm == -pair[1].y_mm and pair[0].z_mm == pair[1].z_mm and
                     pair[0].omega_mm2 == -pair[1].omega_mm2,
                     'Opposed physical coordinates/sectorial modes must match exactly')
            _require(all(getattr(pair[0], key) == getattr(pair[1], key) for key in FORCE_FIELDS),
                     'Opposed contact forces/parcels are unequal; no equal-wheel split is inferred')
        geometry = tuple(tuple(getattr(w, key) for key in GEOMETRY_FIELDS) for w in wheels)
        _require(reference is None or geometry == reference,
                 'All configurations must share identical local contact geometry and fixed event topology')
        reference, ordered[configuration['id']] = geometry, tuple(wheels)
    return ordered


def _power_two_scale(values):
    peak = max((abs(x) for x in values), default=0.)
    if peak == 0.:
        return 0.
    mantissa, exponent = math.frexp(peak)
    return math.ldexp(1., exponent-1 if mantissa == .5 else exponent)


@dataclass(frozen=True)
class _Basis:
    id: str
    wheels: tuple
    case: MovingCase
    amplitude: float
    origin: str
    station_index: int | None = None
    component: str | None = None


def _basis_case(ident, **factors):
    return MovingCase(ident, 'LINEAR_RESPONSE_BASIS', factors.get('support_dead', 0.),
                      factors.get('equipment_dead', 0.), 0., factors.get('longitudinal', 0.),
                      factors.get('transverse', 0.), 1, 1, True,
                      'Internal linear physical-force basis, not a normative design case', factors.get('extra_dead', 0.))


def build_family_plan(project, *, psi, equipment_group, classification_source, include_8800=True):
    """Regenerate complete physical membership and binary-normalized bases.

    This planning result contains no qualified response.  Zero prescribed support
    motion is required: otherwise the affine settlement solution is another basis
    and must not be accidentally multiplied by every action coefficient.
    """
    project.validate()
    _require(project.travel_min_mm is not None, 'Explicit physical travel limits required for a family domain')
    _require(all(value == 0. for s in project.supports for value in s['restrain'].values()),
             'Nonzero prescribed support motions need a separately derived affine basis; unsupported here')
    ledger = project.bridge_reaction_ledger
    _require(isinstance(ledger, dict) and ledger.get('schema') == 'LRO_BOUND_BRIDGE_INERTIA_LEDGER_V1',
             'Bound internally generated full-inertia bridge ledger required')
    generated = generate_inertia_configurations(project.section, ledger['inputs'])
    ordered = validate_paired_geometry(generated['configurations'])
    members, invalid = [], []
    endpoint_receipts = {row['id']: row for row in generated['endpoint_receipts']}
    for configuration in generated['configurations']:
        wheels = ordered[configuration['id']]
        cases = generate_normal_cases(wheels, psi=psi, equipment_group=equipment_group,
            classification_source=classification_source, include_8800=include_8800,
            extra_dead_N_per_mm=project.extra_dead_N_per_mm, extra_dead_kind=project.extra_dead_kind)
        bound = dict(schema='LRO_BOUND_BRIDGE_INERTIA_LEDGER_V1',
                     endpoint_receipt=endpoint_receipts[configuration['endpoint_id']])
        for case in cases:
            audit = physical_case_contact_audit(bound, case)
            if not audit['no_hold_down_contact_valid']:
                invalid.append(dict(configuration_id=configuration['id'], case_id=case.id,
                                    uplift_contacts=audit['uplift_contacts'], contact_status=audit['contact_status']))
            # Axis coefficients are actual per-contact forces, not station totals.
            values = {}
            for station in (0, 1):
                forces = [wheel_force_components(wheels[2*station+j], case) for j in (0, 1)]
                _require(forces[0] == forces[1], 'Factored opposed wheel vectors differ')
                for axis, value in zip(('Fx', 'Fy', 'downward_Fz'), (*forces[0][:2], -forces[0][2])):
                    values[f'station{station}/{axis}'] = value
            values['selfweight'] = case.support_dead
            if project.extra_dead_N_per_mm:
                values['accessory_dead'] = case.extra_dead
            parcels = [dict(qy=0., qz=-project.selfweight()*case.support_dead, y=0., z=0.)]
            if project.extra_dead_N_per_mm:
                parcels.append(dict(qy=0., qz=-project.extra_dead_N_per_mm*case.extra_dead,
                                    y=project.extra_dead_y_mm, z=project.extra_dead_z_mm))
            radius = transverse_dead_load_radius_guard(wheels, case, distributed_parcels=parcels)
            contact_receipt = dict(contact_count=len(audit['loads']),
                no_hold_down_contact_valid=audit['no_hold_down_contact_valid'],
                input_signature=audit['input_signature'], audit_signature=signature(audit),
                upward_Fz_N_by_contact={r['contact_id']: r['force_N'][2] for r in audit['loads']},
                vertical_roundoff_allowance_N=audit['vertical_roundoff_allowance_N'],
                case_factors=audit['case_factors'], loaded=audit['loaded'],
                full_3d_equilibrium=audit['equilibrium'], physical_drive_or_equalizer_qualified=False)
            members.append(dict(configuration_id=configuration['id'], case_id=case.id, family=case.family,
                                case=case, raw_coefficients=values, physical_contact_valid=audit['no_hold_down_contact_valid'],
                                physical_contact_receipt=contact_receipt, load_radius_receipt=radius))
    templates = tuple(replace(w, id=f'basis/contact/{i}', provenance='Internally regenerated paired-contact geometry',
                        **{key: (None if key.endswith('_empty_N') else 0.) for key in FORCE_FIELDS})
                      for i, w in enumerate(next(iter(ordered.values()))))
    bases = []
    for key in members[0]['raw_coefficients']:
        scale = _power_two_scale(m['raw_coefficients'][key] for m in members)
        if key.startswith('station'):
            station = int(key[7]); component = key.split('/')[1]
            field, factor = {'Fx': ('longitudinal_N', 'longitudinal'),
                             'Fy': ('transverse_N', 'transverse'),
                             'downward_Fz': ('dead_N', 'equipment_dead')}[component]
            wheels = tuple(replace(w, **{field: scale}) if i//2 == station else w for i, w in enumerate(templates))
            basis = _Basis(key, wheels, _basis_case('basis/'+key, **{factor: 1.}), scale, 'physical_station_pair', station, component)
        else:
            factor = 'support_dead' if key == 'selfweight' else 'extra_dead'
            basis = _Basis(key, templates, _basis_case('basis/'+key, **{factor: scale}), scale, key)
        bases.append(basis)
        for member in members:
            raw = member['raw_coefficients'][key]
            coefficient = raw/scale if scale else 0.
            _require(abs(coefficient) <= 1. and coefficient*scale == raw,
                     'Power-of-two basis did not preserve exact scalar reconstruction')
            member.setdefault('coefficients', {})[key] = coefficient
    return dict(project_signature=signature(project.to_dict()), generated_input_signature=generated['input_signature'],
                configurations=generated['configurations'], wheels_by_configuration=ordered,
                suspended_mass_accounting=generated['suspended_mass_accounting'],
                action_generation=dict(psi=psi, equipment_group=equipment_group, classification_source=classification_source,
                                       include_8800=include_8800),
                covered_physical_travel_intervals_mm=[dict(start_mm=project.travel_min_mm, end_mm=project.travel_max_mm,
                                                          source=project.travel_source)],
                members=members, bases=tuple(bases), invalid_contacts=invalid,
                scope='All internally generated normal NBR families; no emergency, bumper, test, skew or supplementary EN service cases added.')


def _member_identity(member):
    return dict(configuration_id=member['configuration_id'], case_id=member['case_id'])


def _coefficient_intervals(members, bases):
    result = {}
    for basis in bases:
        low = min(members, key=lambda m: m['coefficients'][basis.id])
        high = max(members, key=lambda m: m['coefficients'][basis.id])
        result[basis.id] = dict(lower=low['coefficients'][basis.id], upper=high['coefficients'][basis.id],
                               lower_member=_member_identity(low), upper_member=_member_identity(high))
    return result


def _response_interval(row, field, evidence):
    lo, hi = row[field]['min']['value'], row[field]['max']['value']
    receipt = evidence['producer_receipt']
    # These are explicit engineering verification allowances, NOT proven FE or
    # continuum errors.  Normalized |coefficients|<=1 prevent magnification.
    allowance = max(ABS_TOL[field]+receipt['polynomial_relative_tolerance']*max(abs(lo), abs(hi)),
                    *(r['roundoff_allowances'].get(field+'/'+bound, 0.)
                      for r in receipt['moving_spatial_history'][-2:] for bound in ('min', 'max')))
    return dict(lower=math.nextafter(lo-allowance, -math.inf),
                upper=math.nextafter(hi+allowance, math.inf), verification_allowance=allowance)


def _boxes(plan, evidence, segments):
    families = []
    for family in sorted({m['family'] for m in plan['members']}):
        members = [m for m in plan['members'] if m['family'] == family]
        coefficients = _coefficient_intervals(members, plan['bases'])
        def bounds(segment_index=None):
            result = {}
            for field in FIELDS:
                terms = []
                for basis in plan['bases']:
                    if basis.amplitude == 0.:
                        continue
                    e = evidence[basis.id]['verification']
                    row = e['refined_extrema'] if segment_index is None else e['segment_extrema'][segment_index]['extrema']
                    response = _response_interval(row, field, e)
                    product = interval_product(coefficients[basis.id], response)
                    terms.append(product)
                result[field] = interval_sum(terms)
            return result
        wheel_actions = []
        for index, template in enumerate(plan['bases'][0].wheels):
            actions = [(wheel_force_components(plan['wheels_by_configuration'][m['configuration_id']][index], m['case'])[2], m)
                       for m in members]
            lo, hi = min(actions, key=lambda pair: pair[0]), max(actions, key=lambda pair: pair[0])
            wheel_actions.append(dict(contact_index=index, **{k: getattr(template, k) for k in GEOMETRY_FIELDS},
                                     Fz_N=dict(lower=lo[0], upper=hi[0], lower_member=_member_identity(lo[1]),
                                               upper_member=_member_identity(hi[1])),
                                     downward_N=dict(lower=-hi[0], upper=-lo[0])))
        families.append(dict(family=family,
            members=[dict(**_member_identity(m), case=asdict(m['case']), coefficients=m['coefficients'],
                          physical_contact_valid=m['physical_contact_valid'], physical_contact_receipt=m['physical_contact_receipt'],
                          load_radius_receipt=m['load_radius_receipt']) for m in members],
            action_basis_sources=sorted({m['case'].source for m in members}),
            covered_physical_travel_intervals_mm=plan['covered_physical_travel_intervals_mm'],
            all_members_contact_valid=all(m['physical_contact_valid'] for m in members),
            all_members_non_destabilizing_radius=all(m['load_radius_receipt']['no_destabilizing_transverse_load_radius'] for m in members),
            coefficient_intervals_are_relaxation=True,
            coefficient_intervals=coefficients, bounds=bounds(),
            segments=[dict(start_mm=s['start_mm'], end_mm=s['end_mm'], bounds=bounds(i)) for i, s in enumerate(segments)],
            wheel_vertical_actions=wheel_actions, concurrent_tensor_claimed=False,
            scope='Signed component Minkowski box, not a realizable case or a reaction vector. Exceedance is inconclusive.'))
    return families


def _source():
    shared = source_receipt()
    own = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    return dict(shared=shared, family_source_hash=own,
                fingerprint=signature(dict(shared=shared['fingerprint'], family_source_hash=own)))


def _candidate_reactions(plan, evidence, model, project, budget):
    """Re-solve real cases at basis-extremum translations, never mix peaks."""
    _require(type(budget) is int and budget >= 0, 'Nonnegative explicit candidate reaction budget required')
    selected, requests = {}, {}
    for family in sorted({m['family'] for m in plan['members']}):
        members = [m for m in plan['members'] if m['family'] == family]
        coefficient_rows = _coefficient_intervals(members, plan['bases'])
        for basis in plan['bases']:
            if basis.amplitude == 0.:
                continue
            for component_side in ('lower_member', 'upper_member'):
                identity = coefficient_rows[basis.id][component_side]
                member = next(m for m in members if _member_identity(m) == identity)
                for segment in evidence[basis.id]['verification']['segment_extrema']:
                    for field, bounds in segment['extrema'].items():
                        for bound, governor in bounds.items():
                            exact = governor['translation_exact_mm']
                            t = Fraction(int(exact['numerator']), int(exact['denominator']))
                            key = (member['configuration_id'], member['case_id'], t)
                            requests.setdefault(key, []).append(dict(basis_id=basis.id, field=field, bound=bound,
                                segment_start_mm=segment['start_mm'], segment_end_mm=segment['end_mm'],
                                coefficient_endpoint=component_side))
                            selected[key] = member
    rows = []
    for key in sorted(requests, key=lambda k: (k[0], k[1], k[2]))[:budget]:
        member, t = selected[key], key[2]
        case = member['case']; wheels = plan['wheels_by_configuration'][member['configuration_id']]
        loads = physical_train_at(wheels, case, float(t), model.length, exact_translation=t)
        qz = -(project.selfweight()*case.support_dead+project.extra_dead_N_per_mm*case.extra_dead)
        mx = -project.extra_dead_N_per_mm*case.extra_dead*(project.extra_dead_y_mm or 0.)
        solution = model.solve(loads, [dict(start=0., end=model.length, qz=qz, mx=mx)] if qz or mx else [])
        attachments = []
        for reaction in solution.support_reactions:
            s = model.supports[reaction['support_index']]
            y, z, om = s.get('y', 0.), s.get('z', 0.), s.get('omega', 0.)
            attachments.append(dict(support_index=reaction['support_index'], support_id=s.get('id'),
                point_mm=dict(x=s['x'], y=y, z=z), Fx=reaction['Fx'], Fy=reaction['Fy'], Fz=reaction['Fz'],
                Mx=reaction['Mx']-y*reaction['Fz']+z*reaction['Fy'], My=reaction['My']-z*reaction['Fx'],
                Mz=reaction['Mz']+y*reaction['Fx'], generalized_B=reaction['B']+om*reaction['Fx']))
        rows.append(dict(**_member_identity(member), case=asdict(case), translation_mm=float(t),
            translation_exact_mm=dict(numerator=str(t.numerator), denominator=str(t.denominator)),
            originating_basis_candidates=requests[key], physical_point_loads=list(loads),
            distributed_loads=[dict(start=0., end=model.length, qz=qz, mx=mx)] if qz or mx else [],
            coexistent_all_support_vectors=solution.support_reactions,
            coexistent_attachment_vectors=attachments, coexistent_constraint_reactions=solution.reactions,
            physical_equilibrium_relative=solution.diagnostics['physical_equilibrium_relative'],
            scope='One actual configuration/case/translation; not a family reaction envelope.'))
    return dict(rows=rows, requested_candidate_count=len(requests), evaluated_candidate_count=len(rows),
                candidate_budget=budget, candidate_selection_truncated=len(rows) < len(requests),
                exhaustive_reaction_envelope=False, synthetic_peak_vector_created=False)


def produce_family_envelope(project, *, psi, equipment_group, classification_source,
                            include_8800=True, controls=None, progress=None, reaction_candidate_budget=32,
                            max_observation_faces=20000, max_polynomial_intervals=20000):
    """Compute complete internally verified bases and form component family boxes.

    Every active basis is recomputed at each common mesh level.  A cheaper basis
    is never stopped on a different mesh.  Zero coefficient bases remain in the
    ledger with an exact zero-coefficient proof, not invented response evidence.
    No normative strength/service check or whole-beam approval is issued here.
    """
    started = time.monotonic(); source_start = _source()
    result = dict(schema='LRO_VERIFIED_COMPONENT_FAMILY_BOX_V1', evidence_kind=PENDING,
                  continuum_upper_bound_claimed=False, rigorous_roundoff_enclosure_claimed=False,
                  component_box_not_concurrent=True, normative_qualification_granted=False,
                  families=[], basis_evidence={}, pending=[], real_coexistence_candidates=None,
                  source_at_start=source_start)
    try:
        controls = AnalysisControls() if controls is None else AnalysisControls(**controls) if isinstance(controls, dict) else controls
        _require(isinstance(controls, AnalysisControls), 'AnalysisControls required')
        _require(controls.moving_stable_passes >= 2 and controls.mesh_stable_passes >= 2 and
                 controls.moving_tolerance <= .01 and controls.mesh_tolerance <= .01,
                 'Two stable moving/mesh passes at <=1% tolerance required; budget may remain insufficient')
        plan = build_family_plan(project, psi=psi, equipment_group=equipment_group,
                                 classification_source=classification_source, include_8800=include_8800)
        result.update(project_signature=plan['project_signature'], generated_input_signature=plan['generated_input_signature'],
            configurations=plan['configurations'], total_configuration_count=len(plan['configurations']),
            action_generation=plan['action_generation'],
            suspended_mass_accounting=plan['suspended_mass_accounting'],
            covered_physical_travel_intervals_mm=plan['covered_physical_travel_intervals_mm'],
            supplementary_method_adoption=dict(source=project.supplementary_en_source,
                                              resistance_gamma=project.supplementary_en_resistance_gamma),
            total_case_count=len(plan['members']), scope=plan['scope'], physical_contact_invalid_members=plan['invalid_contacts'],
            complete_membership=[dict(**_member_identity(m), case=asdict(m['case']), coefficients=m['coefficients']) for m in plan['members']],
            basis_definitions=[dict(id=b.id, amplitude=b.amplitude, origin=b.origin, station_index=b.station_index,
                component=b.component, case=asdict(b.case), wheels=[asdict(w) for w in b.wheels],
                all_coefficients_zero=b.amplitude == 0.) for b in plan['bases']])
        _require(not plan['invalid_contacts'], 'At least one required actual case has uplift outside the unilateral-contact model; no cases omitted')
        active = [b for b in plan['bases'] if b.amplitude]
        previous, stable, histories, scans = {}, {b.id: 0 for b in active}, {b.id: [] for b in active}, {}
        all_converged = False
        for refinement in range(controls.max_mesh_refinements+1):
            mesh = project.max_element_length_mm/2**refinement
            model = project.frame_model(mesh)
            boundaries = model_fork_segments(model)
            segments = boundaries['segments']
            _require(bool(segments), 'No eligible segment domain; family member consumer requires actual qualified fork spans')
            for basis in active:
                def tick(case_id, level, number, total):
                    if progress:
                        progress(dict(stage='basis_scan', basis_id=basis.id, mesh_refinement=refinement,
                                      moving_refinement=level, sample_index=number, sample_count=total))
                scan = scan_moving_case(model, basis.wheels, basis.case, selfweight=project.selfweight(),
                    extra_dead=project.extra_dead_N_per_mm, extra_dead_y_mm=project.extra_dead_y_mm or 0.,
                    divisions=controls.divisions, max_refinements=controls.max_refinements,
                    tolerance=controls.moving_tolerance, consecutive_stable=controls.moving_stable_passes,
                    segments=segments, travel_min_mm=project.travel_min_mm, travel_max_mm=project.travel_max_mm, progress=tick)
                old = previous.get(basis.id)
                delta = None if old is None else _mesh_delta(scan, old)
                stable[basis.id] = stable[basis.id]+1 if old is not None and old['converged'] and scan['converged'] and delta is not None and delta <= controls.mesh_tolerance else 0
                histories[basis.id].append(dict(refinement=refinement, max_element_length_mm=mesh, elements=len(model.nodes)-1,
                    case_id=basis.case.id, scan_input_signature=scan['input_signature'], solver_source_hash=scan['solver_source_hash'],
                    moving_converged=scan['converged'], mesh_relative_change=delta, stable_passes=stable[basis.id],
                    solve_count=scan['solve_count'], seconds=scan['seconds']))
                previous[basis.id] = scans[basis.id] = scan
                result['basis_evidence'][basis.id] = dict(mesh_history=histories[basis.id], verification=None)
            all_converged = all(scans[b.id]['converged'] and stable[b.id] >= controls.mesh_stable_passes for b in active)
            if all_converged:
                break
        result.update(common_final_mesh_nodes_mm=list(map(float, model.nodes)), true_fork_boundary_audit=boundaries,
                      all_basis_mesh_converged=all_converged)
        _require(all_converged, 'Not every active basis reached independent moving/spatial and common-mesh convergence within budget')
        common_grid = sorted({x for scan in scans.values() for x in scan['spatial_base_stations_mm']})
        result['common_spatial_base_stations_mm'] = common_grid
        for basis in active:
            if progress:
                progress(dict(stage='basis_polynomial_verification', basis_id=basis.id, observation_points=len(common_grid)))
            verification = verify_moving_response(model, basis.wheels, basis.case, scans[basis.id],
                selfweight=project.selfweight(), extra_dead=project.extra_dead_N_per_mm,
                extra_dead_y_mm=project.extra_dead_y_mm or 0., observation_points=common_grid,
                mesh_converged=stable[basis.id] >= controls.mesh_stable_passes, mesh_history=histories[basis.id],
                relative_tolerance=max(controls.moving_tolerance, controls.mesh_tolerance), fields=FIELDS,
                max_observation_faces=max_observation_faces, max_polynomial_intervals=max_polynomial_intervals)
            result['basis_evidence'][basis.id]['verification'] = verification
            _require(verification['evidence_kind'] == EvidenceKind.FIXED_FE_EXTREMA_MESH_CONVERGED.value,
                     basis.id+': '+('; '.join(verification['pending']) or 'Fixed-FE verification incomplete'))
        result['families'] = _boxes(plan, result['basis_evidence'], segments)
        result['real_coexistence_candidates'] = _candidate_reactions(plan, result['basis_evidence'], model, project, reaction_candidate_budget)
        _require(signature(project.to_dict()) == plan['project_signature'], 'Project inputs changed while producing family evidence')
        result['evidence_kind'] = VERIFIED
    except (ValueError, TypeError, KeyError, ArithmeticError) as exc:
        result['pending'].append(type(exc).__name__+': '+str(exc))
    result['source_at_end'] = _source()
    result['source_unchanged'] = result['source_at_end']['fingerprint'] == source_start['fingerprint']
    if not result['source_unchanged']:
        result['evidence_kind'] = PENDING
        result['pending'].append('Numerical source dependency changed during computation')
    result['seconds'] = time.monotonic()-started
    result['receipt_signature'] = signature(result)
    return result
