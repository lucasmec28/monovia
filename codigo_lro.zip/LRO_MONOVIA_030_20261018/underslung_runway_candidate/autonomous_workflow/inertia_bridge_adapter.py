"""Capacity/CG inputs to the fully equilibrated, declared eight-contact model.

No actual mass, CG, equalization or drive fact is inferred. Gravity and complete
inertia vectors remain separate, including signed vertical redistribution.
"""
from dataclasses import dataclass,asdict,fields
from .model import finite,checked_text,signature
from .project import physical_wheel
from ..section_stress.recovery import ISection
from ..bridge_inertia.statics import (PointMass,generate,combine,LEGACY_MASS_CONVENTION,
    SEPARATE_MASS_CONVENTION,MASS_ACCOUNTING_FIELDS,validate_suspended_mass_accounting,
    suspended_mass_accounting,serialize_mass_inputs,retained_point_mass)


@dataclass(frozen=True)
class BridgeInertiaInputs:
    capacity_t:float
    bridge_span_mm:float
    bridge_mass_kg:float
    bridge_cg_x_mm:float
    bridge_cg_y_mm:float
    bridge_cg_z_mm:float
    trolley_mass_kg:float
    trolley_cg_x_mm:float
    trolley_cg_z_mm:float
    trolley_cg_minus_hook_mm:float
    hook_min_from_left_mm:float
    hook_max_from_left_mm:float
    lifted_cg_x_mm:float
    lifted_cg_z_min_mm:float
    lifted_cg_z_max_mm:float
    carriage_station_spacing_mm:float
    contact_n_mm:float
    bridge_acceleration_m_s2:float
    trolley_acceleration_m_s2:float
    horizontal_dynamic_factor:float
    geometry_mass_cg_source:str
    acceleration_dynamic_source:str
    equalization_source:str
    equalized_bilinear_model_adopted:bool
    point_force_transfer_adopted:bool
    gravity_m_s2:float=9.80665
    transfer_model:str='guided_rigid_payload_cg'
    suspension_point_x_mm:float|None=None
    suspension_point_z_mm:float|None=None
    force_transfer_source:str=''
    mass_accounting_convention:str=LEGACY_MASS_CONVENTION
    retained_suspended_mass_kg:float|None=None
    retained_suspended_cg_x_mm:float|None=None
    retained_suspended_cg_z_mm:float|None=None
    retained_mass_excluded_from_equipment:bool|None=None
    suspended_mass_source:str=''

    def __post_init__(self):
        for f in fields(self):
            v=getattr(self,f.name)
            if f.name in MASS_ACCOUNTING_FIELDS:continue
            if f.name=='transfer_model':
                if v not in ('guided_rigid_payload_cg','free_suspended_at_crab'):raise ValueError('Select an explicit hoist-load force-transfer model')
            elif f.name=='force_transfer_source':checked_text(v,f.name,required=False)
            elif f.name in ('suspension_point_x_mm','suspension_point_z_mm'):
                if v is not None:object.__setattr__(self,f.name,finite(v,f.name))
            elif f.name in ('lifted_cg_x_mm','lifted_cg_z_min_mm','lifted_cg_z_max_mm') and v is None:
                if self.transfer_model!='free_suspended_at_crab':raise ValueError('Guided/rigid load transfer requires physical CG coordinates')
            elif f.name.endswith('_source'):checked_text(v,f.name)
            elif f.name.endswith('_adopted'):
                if v is not True:raise ValueError('Explicit model adoption required: '+f.name)
            else:object.__setattr__(self,f.name,finite(v,f.name))
        for name in ('capacity_t','bridge_span_mm','carriage_station_spacing_mm','contact_n_mm','gravity_m_s2'):
            if getattr(self,name)<=0:raise ValueError(name+' must be positive')
        if min(self.bridge_mass_kg,self.trolley_mass_kg)<0:raise ValueError('Masses cannot be negative')
        if self.horizontal_dynamic_factor<1:raise ValueError('Horizontal dynamic multiplier cannot reduce inertia')
        if not 0<=self.hook_min_from_left_mm<=self.hook_max_from_left_mm<=self.bridge_span_mm:raise ValueError('Hook travel must stay between rails')
        if self.transfer_model=='free_suspended_at_crab':
            if self.suspension_point_x_mm is None or self.suspension_point_z_mm is None or not self.force_transfer_source.strip():
                raise ValueError('Free-rope equivalent transfer requires explicit suspension point x/z and source; no trolley height is inferred')
            if any(v is not None for v in (self.lifted_cg_x_mm,self.lifted_cg_z_min_mm,self.lifted_cg_z_max_mm)):
                raise ValueError('Free-rope model uses the source-defined point immediately below the crab, not payload CG fields')
        else:
            if self.lifted_cg_z_min_mm>self.lifted_cg_z_max_mm:raise ValueError('Ordered signed payload CG height range required')
            if self.suspension_point_x_mm is not None or self.suspension_point_z_mm is not None:
                raise ValueError('Guided/rigid CG model must not mix free-rope equivalent point fields')
        validate_suspended_mass_accounting(self)
        for y in (self.hook_min_from_left_mm+self.trolley_cg_minus_hook_mm,self.hook_max_from_left_mm+self.trolley_cg_minus_hook_mm,self.bridge_cg_y_mm):
            if not 0<=y<=self.bridge_span_mm:raise ValueError('Equipment CG outside rail span')


def from_dict(data):
    if not isinstance(data,dict) or set(data)-{f.name for f in fields(BridgeInertiaInputs)}:raise ValueError('Invalid bridge inertia physical input object')
    try:return BridgeInertiaInputs(**data)
    except TypeError as exc:raise ValueError('Missing bridge inertia physical input: '+str(exc)) from exc


def generate_inertia_configurations(section,inputs):
    if not isinstance(section,ISection) or not section.doubly_symmetric or section.construction!='rolled':raise ValueError('Current autonomous domain is a doubly symmetric rolled I')
    p=from_dict(inputs) if isinstance(inputs,dict) else inputs
    if not isinstance(p,BridgeInertiaInputs):raise ValueError('BridgeInertiaInputs required')
    payload=serialize_mass_inputs(p);sig=signature(dict(section_signature=section.signature,inputs=payload))
    b=section.bottom_width/2-p.contact_n_mm
    configurations=[];receipts=[]
    free=p.transfer_model=='free_suspended_at_crab'
    height_min=height_max=p.suspension_point_z_mm if free else None
    if not free:height_min,height_max=p.lifted_cg_z_min_mm,p.lifted_cg_z_max_mm
    load_x=p.suspension_point_x_mm if free else p.lifted_cg_x_mm
    transfer_source=(p.force_transfer_source+'; EN13001-2:2014 4.2.2.5 equivalent hoist load immediately below crab') if free else (p.force_transfer_source or p.geometry_mass_cg_source)+'; explicitly guided/rigid point-mass CG transfer, not arbitrary freely hanging load'

    for endpoint,hook in (('hook_min',p.hook_min_from_left_mm),('hook_max',p.hook_max_from_left_mm)):
        for height,z in (('lift_z_min',height_min),('lift_z_max',height_max)):
            eid=endpoint+'/'+height
            masses=[PointMass('bridge','equipment',p.bridge_mass_kg,p.bridge_cg_x_mm,p.bridge_cg_y_mm,p.bridge_cg_z_mm,p.bridge_acceleration_m_s2,0.,p.geometry_mass_cg_source),
                PointMass('trolley','equipment',p.trolley_mass_kg,p.trolley_cg_x_mm,hook+p.trolley_cg_minus_hook_mm,p.trolley_cg_z_mm,p.bridge_acceleration_m_s2,p.trolley_acceleration_m_s2,p.geometry_mass_cg_source),
                PointMass('lifted' if p.mass_accounting_convention==LEGACY_MASS_CONVENTION else 'payload','lifted',1000*p.capacity_t,load_x,hook,z,p.bridge_acceleration_m_s2,p.trolley_acceleration_m_s2,transfer_source)]
            retained=retained_point_mass(p,hook)
            if retained is not None:masses.append(retained)
            generated=generate(masses,rail_span_mm=p.bridge_span_mm,station_spacing_mm=p.carriage_station_spacing_mm,
                contact_half_gauge_mm=b,model_source=p.equalization_source,equalized_model_adopted=True,
                horizontal_dynamic_factor=p.horizontal_dynamic_factor,gravity_m_s2=p.gravity_m_s2)
            # Both rail contact systems remain in this receipt. Do not validate
            # only the selected rail: lift-off elsewhere invalidates this model.
            receipts.append(dict(id=eid,generated=generated,hook_from_left_mm=hook,lifted_cg_z_mm=None if free else z,lifted_force_application_x_mm=load_x,lifted_force_application_z_mm=z,transfer_model=p.transfer_model,force_transfer_source=transfer_source))
            for rail in (0,1):
                ident=eid+'/rail'+str(rail);wheels=[]
                for contact in generated['contacts']:
                    if contact['rail_index']!=rail:continue
                    values=dict(G=0.,Q=0.,B=0.,HX=0.,HY=0.,HXz=0.,HYz=0.,HXempty=0.,HYempty=0.,HXzempty=0.,HYzempty=0.)
                    for parcel in generated['parcels']:
                        vec=next(row['force_N'] for row in parcel['loads'] if row['contact_id']==contact['id'])
                        action=parcel['action'];kind=parcel['kind']
                        if action=='gravity':values[{'equipment':'G','lifted':'Q','retained_lifted':'B'}[kind]]-=vec[2]
                        else:
                            values[action]+=vec[0 if action=='HX' else 1];values[action+'z']+=vec[2]
                            if kind!='lifted':
                                values[action+'empty']+=vec[0 if action=='HX' else 1];values[action+'zempty']+=vec[2]
                    wheel=asdict(physical_wheel(section,id=ident+'/'+contact['id'],offset_mm=contact['position_mm'][0],
                        outstand_side='left' if contact['outstand_sign']<0 else 'right',edge_to_contact_n_mm=p.contact_n_mm,
                        dead_N=values['G'],lifted_N=values['Q'],retained_lifted_N=values['B'],
                        suspended_mass_accounting='explicit_payload_plus_retained' if retained is not None else 'legacy_retained_mass_unspecified',longitudinal_N=values['HX'],transverse_N=values['HY'],
                        longitudinal_empty_N=values['HXempty'],transverse_empty_N=values['HYempty'],
                        longitudinal_vertical_N=values['HXz'],transverse_vertical_N=values['HYz'],
                        longitudinal_vertical_empty_N=values['HXzempty'],transverse_vertical_empty_N=values['HYzempty'],
                        provenance=p.geometry_mass_cg_source+'; '+p.acceleration_dynamic_source+'; '+p.equalization_source+'; '+ident,
                        point_force_transfer_adopted=True))
                    if retained is None:
                        wheel.pop('retained_lifted_N');wheel.pop('suspended_mass_accounting')
                    wheels.append(wheel)
                configurations.append(dict(id=ident,endpoint_id=eid,rail_index=rail,selected_rail='left' if rail==0 else 'right',
                    hook_from_left_mm=hook,lifted_cg_z_mm=None if free else z,lifted_force_application_x_mm=load_x,lifted_force_application_z_mm=z,transfer_model=p.transfer_model,force_transfer_source=transfer_source,trolley_cg_from_left_mm=hook+p.trolley_cg_minus_hook_mm,
                    wheels=wheels,input_signature=sig,full_3d_resultant_equilibrium=True,actual_drive_or_equalizer_qualified=False))
    return dict(schema='LRO_EQUILIBRATED_BRIDGE_INERTIA_V1',inputs=payload,input_signature=sig,section_signature=section.signature,
        configurations=configurations,endpoint_receipts=receipts,design_approval=False,
        suspended_mass_accounting=suspended_mass_accounting(p),
        pending=[dict(id='drive_equalizer',reason='The bilinear/equalized transfer and supplied accelerations/dynamics are adopted physical model requirements; actual drive, equalizer and guide compatibility remains to be specified.'),
                 dict(id='selected_configuration',reason='Each hook/height/rail record is a separate correlated hypothesis. All admissible records must be included for an operating-domain envelope.'),
                 dict(id='other_actions',reason='Rolling/skew, bumper, emergency and test actions are not generated by the normal inertia transfer model.')])


def make_ledger(section,inputs,configuration_id):
    r=generate_inertia_configurations(section,inputs)
    records=[c for c in r['configurations'] if c['id']==configuration_id]
    if len(records)!=1:raise ValueError('Unknown inertia bridge configuration')
    c=records[0]
    return dict(schema='LRO_BOUND_BRIDGE_INERTIA_LEDGER_V1',inputs=r['inputs'],selected_configuration_id=c['id'],
        input_signature=r['input_signature'],section_signature=r['section_signature'],selected_configuration=c,
        endpoint_receipt=next(e for e in r['endpoint_receipts'] if e['id']==c['endpoint_id']),pending=r['pending'])


def physical_case_contact_audit(ledger,case):
    """All eight bridge contacts checked before accepting one selected runway."""
    if ledger.get('schema')!='LRO_BOUND_BRIDGE_INERTIA_LEDGER_V1':return None
    return combine(ledger['endpoint_receipt']['generated'],equipment_factor=case.equipment_dead,lifted_factor=case.lifted,
        hx_multiplier=case.longitudinal*case.longitudinal_sign,hy_multiplier=case.transverse*case.transverse_sign,loaded=case.loaded,retained_lifted_factor=case.retained_lifted)
