"""All-translation fixed-point extrema in a specified, fixed linear FE model.

This is NOT a spatial envelope or a physical FE-error bound. It uses the
proved piecewise-cubic dependence of constant point loads in FrameModel,
then verifies floating-point coefficient recovery independently. No rigorous
roundoff enclosure is claimed; `certified_numerical_bound` is always False.
"""
from fractions import Fraction
import math
import numpy as np
from numpy.polynomial import chebyshev as cheb

from underslung_runway_candidate.autonomous_frame.solver import FrameModel, LOADS

FIELDS = ("u", "v", "w", "phi", "theta_y", "theta_z", "chi", "N", "Fy", "Fz", "My", "Mz",
          "B", "Tsv", "Tw", "T", "T_equilibrated", "B_equilibrated", "Tw_equilibrated")
ABS_TOL = dict(u=1e-8, v=1e-8, w=1e-8, phi=1e-11, theta_y=1e-11, theta_z=1e-11, chi=1e-14,
               N=1e-4, Fy=1e-4, Fz=1e-4, My=.1, Mz=.1, B=100., Tsv=.1, Tw=.1, T=.1,
               T_equilibrated=.1, B_equilibrated=100., Tw_equilibrated=.1)
JUMPS = dict(N=("Fx", -1), Fy=("Fy", -1), Fz=("Fz", -1), My=("My", -1), Mz=("Mz", -1),
             T_equilibrated=("Mx", -1), B_equilibrated=("B", 1), Tw_equilibrated=("Mx", -1))


class PolynomialDomainError(ValueError):
    """The declared polynomial domain or numerical verification failed."""


def _number(value, name):
    if isinstance(value, (bool, np.bool_)) or not isinstance(value, (int, float, np.number)) or not math.isfinite(value):
        raise ValueError(name+" must be a finite real number")
    return float(value)

class _FixedModelStateCache:
    """Bounded internal solved-state reuse, never a cache of result identities.

    Only fresh response dictionaries leave this object.  Cached Solution objects
    and their arrays are private; no translation/provenance attributes are set.
    An exact typed physical load tuple and rational translation/limit are keys.
    A different model object, operator, material, support or mesh is rejected.
    """
    def __init__(self, model, *, max_entries=512, max_bytes=32*1024*1024):
        from collections import OrderedDict
        if type(model) is not FrameModel:
            raise TypeError('State cache requires exactly FrameModel')
        for value in (max_entries, max_bytes):
            if type(value) is not int or value <= 0:
                raise ValueError('Positive integral cache memory/entry limits required')
        self._model = model
        self._fingerprint = self._model_key(model)
        self._entries = OrderedDict()
        self._max_entries, self._max_bytes = max_entries, max_bytes
        self._bytes = 0
        self._stats = dict(requests=0, hits=0, misses=0, evictions=0,
                           oversize_not_retained=0, peak_entries=0, peak_estimated_bytes=0)

    @staticmethod
    def _typed(value):
        if isinstance(value, (float, np.floating)):
            return (type(value).__name__, float(value).hex())
        if type(value) in (int, str, bool, type(None)):
            return (type(value).__name__, value)
        if isinstance(value, Fraction):
            return ('Fraction', value.numerator, value.denominator)
        if isinstance(value, dict):
            return ('dict', tuple((k, _FixedModelStateCache._typed(v)) for k, v in sorted(value.items())))
        if isinstance(value, (tuple, list)):
            return (type(value).__name__, tuple(_FixedModelStateCache._typed(v) for v in value))
        raise TypeError('Unsupported value in exact solved-state key')

    @classmethod
    def _model_key(cls, model):
        import hashlib
        # Include assembled operators as well as the physical input metadata.
        # This check runs at each fixed-point call, not every sample evaluation.
        digest = hashlib.sha256()
        digest.update(repr(cls._typed(dict(length=model.length, section=model.section,
                                         supports=model.supports))).encode())
        arrays = [model.nodes, model.K, model.C, model.prescribed, model.scale,
                  model.cscale, model.Cs, model.Z, model.Ks, *model.element_k]
        if hasattr(model, 'factor'):
            arrays.append(model.factor[0]); digest.update(repr(model.factor[1]).encode())
        for array in arrays:
            digest.update(str(array.dtype).encode()); digest.update(repr(array.shape).encode())
            digest.update(array.tobytes())
        return digest.hexdigest()

    def validate_model(self, model):
        if model is not self._model or self._model_key(model) != self._fingerprint:
            raise ValueError('Solved-state cache cannot cross a changed model/mesh/material/support/operator')
        if getattr(model.solve, '__func__', None) is not FrameModel.solve:
            raise ValueError('Solved-state cache requires the unchanged FrameModel solver method')

    @staticmethod
    def _estimated_size(value, seen=None):
        import sys
        seen = set() if seen is None else seen
        if id(value) in seen:
            return 0
        seen.add(id(value)); size = sys.getsizeof(value)
        if isinstance(value, np.ndarray):
            # A view's sys.getsizeof omits its backing array; count its data.
            return size+(0 if value.flags.owndata else value.nbytes)
        if isinstance(value, dict):
            return size+sum(_FixedModelStateCache._estimated_size(k, seen)+
                            _FixedModelStateCache._estimated_size(v, seen) for k, v in value.items())
        if isinstance(value, (tuple, list)):
            return size+sum(_FixedModelStateCache._estimated_size(v, seen) for v in value)
        return size

    def response_at(self, model, points, udls, x, side, *, exact_translation, translation_limit):
        if model is not self._model:
            raise ValueError('Solved-state cache belongs to a different model object')
        if not isinstance(exact_translation, Fraction) or translation_limit not in ('exact', 'left', 'right'):
            raise ValueError('Exact rational translation and identified limit required')
        key = (exact_translation.numerator, exact_translation.denominator, translation_limit,
               self._typed(points), self._typed(udls))
        self._stats['requests'] += 1
        if key in self._entries:
            self._stats['hits'] += 1
            solution, size = self._entries.pop(key)
            self._entries[key] = (solution, size)
        else:
            self._stats['misses'] += 1
            solution = model.solve(points, udls)
            # Defensive read-only numerical arrays. Inputs are already copied
            # by FrameModel.solve; model storage is never altered here.
            solution.dofs.setflags(write=False)
            for force in solution.element_f:
                force.setflags(write=False)
            state = {k: v for k, v in vars(solution).items() if k != 'model'}
            # Include LRU node/container overhead conservatively per entry.
            size = 512+self._estimated_size(key)+self._estimated_size(state)
            if size <= self._max_bytes:
                while self._entries and (len(self._entries) >= self._max_entries or self._bytes+size > self._max_bytes):
                    _, (_, removed) = self._entries.popitem(last=False)
                    self._bytes -= removed; self._stats['evictions'] += 1
                self._entries[key] = (solution, size); self._bytes += size
                self._stats['peak_entries'] = max(self._stats['peak_entries'], len(self._entries))
                self._stats['peak_estimated_bytes'] = max(self._stats['peak_estimated_bytes'], self._bytes)
            else:
                self._stats['oversize_not_retained'] += 1
        # Solution.at creates a fresh scalar-only dict. Do not expose Solution,
        # reactions, arrays, or mutable translation/provenance to consumers.
        return solution.at(x, side)

    def receipt(self):
        return dict(**self._stats, max_entries=self._max_entries, max_estimated_bytes=self._max_bytes,
                    retained_entries=len(self._entries), retained_estimated_bytes=self._bytes,
                    key_scope='Exact rational translation and exact/left/right limit; complete typed physical wheel and UDL tuples; one checked model/operator',
                    numerical_state_exposed=False, identity_or_provenance_cached=False)



def fixed_point_extrema(model, wheels, observation_x, translation_min, translation_max, *,
                        fields=FIELDS, distributed_loads=(), spatial_side="right",
                        relative_tolerance=1e-8, absolute_tolerances=None, max_intervals=20000, _state_cache=None):
    """Numerically verify and extremize every piecewise cubic response field.

    `wheels` are mappings with constant `offset` in mm and optional constant
    Fx/Fy/Fz/Mx/My/Mz/B in N/mm-based units; x = translation + offset. Wheel
    loads are active on the CLOSED member [0,L]; train entry/exit limit states
    use their corresponding one-sided active set. No wheel redistribution,
    moving UDL, nonlinear support, changing stiffness, or changing load factor
    is supported. Distributed loads are fixed as supplied to FrameModel.

    The fixed material observation face stays `spatial_side` even at a mesh
    node. Both physical endpoint side labels mean the sole interior face.
    Exact event states and translation-left/right limits are retained. A
    translation limit is not obtained by shifting a point by an arbitrary
    epsilon: its exact active set and analytical traction jumps are used.
    """
    if type(model) is not FrameModel:
        raise TypeError("The proved degree contract requires exactly FrameModel, not a custom/nonlinear solver")
    if _state_cache is not None:
        if type(_state_cache) is not _FixedModelStateCache:
            raise TypeError('Only the bounded internal fixed-model state cache is allowed')
        _state_cache.validate_model(model)
    if spatial_side not in ("left", "right"):
        raise ValueError("spatial_side must be left or right")
    obs = _number(observation_x, "observation_x")
    model.station(obs)
    flo = translation_min if isinstance(translation_min, Fraction) else Fraction(_number(translation_min, "translation_min"))
    fhi = translation_max if isinstance(translation_max, Fraction) else Fraction(_number(translation_max, "translation_max"))
    lo, hi = float(flo), float(fhi)
    if not math.isfinite(lo) or not math.isfinite(hi):
        raise ValueError("Translation endpoints must be finite")
    if fhi < flo:
        raise ValueError("translation_min must not exceed translation_max")
    rtol = _number(relative_tolerance, "relative_tolerance")
    if rtol <= 0:
        raise ValueError("relative_tolerance must be positive")
    fields = tuple(fields)
    if not fields or len(fields) != len(set(fields)) or any(k not in FIELDS for k in fields):
        raise ValueError("Unique supported response fields required")
    if isinstance(max_intervals, bool) or not isinstance(max_intervals, int) or max_intervals < 1:
        raise ValueError("max_intervals must be a positive integer")
    atol = dict(ABS_TOL)
    for k, v in (absolute_tolerances or {}).items():
        if k not in FIELDS:
            raise ValueError("Unknown absolute-tolerance field")
        atol[k] = _number(v, "absolute_tolerance")
        if atol[k] <= 0:
            raise ValueError("Absolute tolerances must be positive")
    ws = []
    for i, wheel in enumerate(wheels):
        if any(k not in (*LOADS, "offset", "wheel_id") for k in wheel):
            raise ValueError("Wheel contains unknown or position-varying load inputs")
        offset = _number(wheel["offset"], "wheel offset")
        forces = {k: _number(wheel.get(k, 0.), "wheel "+k) for k in LOADS}
        ws.append((Fraction(offset), forces, wheel.get("wheel_id", str(i))))
    if not ws:
        raise ValueError("At least one constant moving wheel required")
    udls = tuple(dict(q) for q in distributed_loads)
    fL, fobs = Fraction(float(model.length)), Fraction(obs)
    breakpoints = {Fraction(float(x)) for x in model.nodes} | {fobs}
    events = {flo, fhi}
    for offset, _, _ in ws:
        events.update(x-offset for x in breakpoints if flo <= x-offset <= fhi)
    events = sorted(events)
    if len(events)-1 > max_intervals:
        raise PolynomialDomainError("Event partition exceeds max_intervals; no intervals were discarded")
    if len({float(t) for t in events}) != len(events):
        raise PolynomialDomainError("Distinct exact translation events alias in floating point; no merging permitted")
    cache, counts = {}, dict(solves=0, verification_checks=0)
    largest_ratio, largest_abs = 0., {k: 0. for k in fields}
    envelopes = {k: {"minimum": None, "maximum": None} for k in fields}

    def evaluate(t, limit="exact"):
        key = (t, limit)
        if key in cache:
            return cache[key]
        points, coincident = [], []
        for offset, forces, wheel_id in ws:
            x = t+offset
            active = (0 <= x <= fL)
            if limit == "left":
                active = (0 < x <= fL)
            elif limit == "right":
                active = (0 <= x < fL)
            if not active:
                continue
            rounded = float(x)
            if any(x != b and rounded == float(b) for b in breakpoints):
                raise PolynomialDomainError("A non-event wheel coordinate rounds onto a response/mesh event")
            points.append(dict(x=rounded, **forces))
            if x == fobs:
                coincident.append(forces)
        response = (model.solve(points, udls).at(obs, spatial_side) if _state_cache is None else
                    _state_cache.response_at(model, points, udls, obs, spatial_side,
                                             exact_translation=t, translation_limit=limit))
        counts["solves"] += 1
        if limit != "exact" and coincident:
            # Exact at() activation is right at x=0 and left at x=L. For an
            # interior observation it follows the requested spatial face.
            exact_active = obs == 0 or (obs != model.length and spatial_side == "right")
            desired_active = limit == "left"  # moving wheel is to the left
            delta = int(desired_active)-int(exact_active)
            for field, (load, jump_sign) in JUMPS.items():
                response[field] += delta*jump_sign*math.fsum(p[load] for p in coincident)
        selected = {k: float(response[k]) for k in fields}
        if not all(math.isfinite(v) for v in selected.values()):
            raise PolynomialDomainError("Nonfinite fixed-point response")
        cache[key] = selected
        return selected

    def retain(t, kind, values, interval=None):
        for k, value in values.items():
            record = dict(value=value, translation_mm=float(t), kind=kind,
                          translation_exact_mm={"numerator": str(t.numerator), "denominator": str(t.denominator)},
                          observation_x_mm=obs, spatial_side=spatial_side, interval=interval)
            if envelopes[k]["minimum"] is None or value < envelopes[k]["minimum"]["value"]:
                envelopes[k]["minimum"] = record
            if envelopes[k]["maximum"] is None or value > envelopes[k]["maximum"]["value"]:
                envelopes[k]["maximum"] = record

    event_states = []
    for t in events:
        state = dict(translation_mm=float(t),
                     translation_exact_mm={"numerator": str(t.numerator), "denominator": str(t.denominator)},
                     exact=evaluate(t), translation_left_limit=None, translation_right_limit=None)
        retain(t, "exact_event", state["exact"])
        if t > flo:
            state["translation_left_limit"] = evaluate(t, "left")
            retain(t, "translation_left_limit", state["translation_left_limit"])
        if t < fhi:
            state["translation_right_limit"] = evaluate(t, "right")
            retain(t, "translation_right_limit", state["translation_right_limit"])
        event_states.append(state)

    intervals = []
    zfit = np.sort(np.cos((2*np.arange(4)+1)*math.pi/8))
    for index, (a, b) in enumerate(zip(events[:-1], events[1:])):
        midpoint, half = (a+b)/2, (b-a)/2

        def translation(z):
            t = midpoint+half*Fraction(float(z))
            if not a < t < b:
                raise PolynomialDomainError("Open-interval sample could not be represented")
            return t

        ts = [translation(z) for z in zfit]
        if len({float(t) for t in ts}) != 4:
            raise PolynomialDomainError("Interval too narrow for four distinct fitting stations")
        samples = [evaluate(t) for t in ts]
        coefficients = {k: cheb.chebfit(zfit, [row[k] for row in samples], 3) for k in fields}
        scales = {k: max(abs(row[k]) for row in samples) for k in fields}
        interval_ratio = 0.

        def verify(z, actual):
            nonlocal largest_ratio, interval_ratio
            for k in fields:
                predicted = float(cheb.chebval(z, coefficients[k]))
                err = abs(predicted-actual[k])
                tol = atol[k]+rtol*max(scales[k], abs(actual[k]))
                ratio = err/tol
                largest_abs[k] = max(largest_abs[k], err)
                largest_ratio = max(largest_ratio, ratio)
                interval_ratio = max(interval_ratio, ratio)
                counts["verification_checks"] += 1
                if not math.isfinite(ratio) or ratio > 1:
                    raise PolynomialDomainError("Cubic verification failed for %s in interval %d: error %.6g > %.6g" %
                                                (k, index, err, tol))

        for z in (-.8, 0., .8):
            verify(z, evaluate(translation(z)))
        verify(-1., evaluate(a, "right"))
        verify(1., evaluate(b, "left"))
        stationary = []
        for k in fields:
            for root in cheb.chebroots(cheb.chebder(coefficients[k])):
                if abs(float(np.imag(root))) > 1e-9 or not -1 < float(np.real(root)) < 1:
                    continue
                z = float(np.real(root))
                t = translation(z)
                actual = evaluate(t)
                verify(z, actual)
                retain(t, "stationary_point", actual, index)
                stationary.append(dict(field=k, translation_mm=float(t), value=actual[k]))
        intervals.append(dict(start_mm=float(a), end_mm=float(b),
                              chebyshev_coefficients={k: c.tolist() for k, c in coefficients.items()},
                              normalized_verification_error=interval_ratio, stationary_points=stationary))
    return dict(status="numerically_verified_piecewise_cubic_extrema", certified_numerical_bound=False,
                scope="All translations at one fixed material face in this fixed linear FE model only",
                excluded="Physical FE discretization error, spatial envelope, strength and rigorous roundoff enclosure",
                observation_x_mm=obs, spatial_side=spatial_side, translation_range_mm=[lo, hi],
                exact_translation_range_mm=[{"numerator": str(t.numerator), "denominator": str(t.denominator)} for t in (flo, fhi)],
                fields=envelopes, events_mm=[float(t) for t in events], event_states=event_states, intervals=intervals,
                model_nodes_mm=model.nodes.tolist(),
                exact_events_mm=[{"numerator": str(t.numerator), "denominator": str(t.denominator)} for t in events],
                maximum_normalized_verification_error=largest_ratio, maximum_absolute_verification_error=largest_abs,
                relative_tolerance=rtol, absolute_tolerances={k: atol[k] for k in fields}, **counts)
