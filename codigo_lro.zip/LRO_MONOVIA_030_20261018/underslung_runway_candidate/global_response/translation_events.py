"""Exact event bookkeeping and resolvable, honestly approximate side probes.

No wheel or support is snapped. An event is the exact rational difference of
the input IEEE floating coordinates. Probes are ordinary representable float
translations with correctly rounded wheel positions strictly inside their
adjacent event interval. These probes are NOT exact one-sided response limits.
"""
from dataclasses import dataclass
from fractions import Fraction
import math


class EventResolutionError(ValueError):
    """Relevant distinct events or their side probes cannot be resolved."""


def _real(value, name):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        raise ValueError(name+" must be finite real")
    return float(value)


def _fraction(value, name):
    return value if isinstance(value, Fraction) else Fraction(_real(value, name))


@dataclass(frozen=True)
class Crossing:
    wheel_index: int
    wheel_id: str
    target_mm: float
    offset_mm: float


@dataclass(frozen=True)
class TranslationEvent:
    translation_mm: float
    exact_translation_mm: Fraction
    crossings: tuple[Crossing, ...]

    def as_record(self):
        return dict(translation_mm=self.translation_mm,
                    exact_numerator=str(self.exact_translation_mm.numerator),
                    exact_denominator=str(self.exact_translation_mm.denominator),
                    crossings=[dict(wheel_index=c.wheel_index, wheel_id=c.wheel_id,
                                    target_mm=c.target_mm, offset_mm=c.offset_mm) for c in self.crossings])


def build_event_catalogue(length, wheels, stations=(), *, travel_min_mm=None, travel_max_mm=None):
    """Include beam endpoints, requested stations and optional travel endpoints.

    Wheels may be PhysicalWheel objects (`offset_mm`, `id`) or dictionaries
    with `offset_mm`/`offset` and optional `id`/`wheel_id`. Distinct exact events
    mapping to one float are rejected, never merged. Limits are computational
    crossing limits unless physical travel limits were explicitly supplied.
    """
    L = _real(length, "length")
    if L <= 0:
        raise ValueError("Positive member length required")
    wheels = tuple(wheels)
    if not wheels:
        raise ValueError("Physical wheel train required")
    targets = {0., L, *(_real(x, "event station") for x in stations)}
    if any(not 0 <= x <= L for x in targets):
        raise ValueError("Event station outside member")
    catalogue = {}
    for index, wheel in enumerate(wheels):
        if isinstance(wheel, dict):
            offset = wheel.get("offset_mm", wheel.get("offset"))
            ident = wheel.get("id", wheel.get("wheel_id", str(index)))
        else:
            offset, ident = wheel.offset_mm, wheel.id
        offset = _real(offset, "wheel offset")
        for target in targets:
            exact = Fraction(target)-Fraction(offset)
            catalogue.setdefault(exact, []).append(Crossing(index, str(ident), target, offset))
    lo, hi = min(catalogue), max(catalogue)
    if (travel_min_mm is None) != (travel_max_mm is None):
        raise ValueError("Both physical/computational travel endpoints required")
    if travel_min_mm is not None:
        requested_lo, requested_hi = _fraction(travel_min_mm, "travel minimum"), _fraction(travel_max_mm, "travel maximum")
        if not lo <= requested_lo < requested_hi <= hi:
            raise ValueError("Travel interval must be positive and inside the full train crossing domain")
        lo, hi = requested_lo, requested_hi
    catalogue = {a: crossings for a, crossings in catalogue.items() if lo <= a <= hi}
    catalogue.setdefault(lo, [])
    catalogue.setdefault(hi, [])
    ordered = sorted(catalogue)
    if len({float(a) for a in ordered}) != len(ordered):
        raise EventResolutionError("Distinct relevant exact events alias as float translations; no merging permitted")
    return tuple(TranslationEvent(float(a), a, tuple(sorted(catalogue[a], key=lambda c: (c.wheel_index, c.target_mm))))
                 for a in ordered)


def event_translation_map(catalogue):
    """Map ordinary event labels to exact translations, for event evaluation."""
    result = {event.translation_mm: event.exact_translation_mm for event in catalogue}
    if len(result) != len(catalogue):
        raise EventResolutionError("Duplicate event float labels")
    return result


def exact_wheel_coordinate(translation, offset, exact_events=None):
    """Round only AFTER exact translation-plus-offset addition.

    Pass the event map for an exact-event float label. For ordinary interval
    samples/probes, Fraction(translation) is used. All output remains physical
    mm; no member clipping, wheel redistribution, or support snapping occurs.
    """
    if isinstance(translation, Fraction):
        a = translation
    else:
        value = _real(translation, "translation")
        a = (exact_events or {}).get(value, Fraction(value))
    x = float(a+_fraction(offset, "wheel offset"))
    if not math.isfinite(x):
        raise EventResolutionError("Nonfinite translated wheel position")
    return x


def _rounding_threshold(crossing, side):
    """Strict coordinate threshold guaranteeing rounding to the chosen side."""
    target = crossing.target_mm
    neighbor = math.nextafter(target, math.inf if side == "right" else -math.inf)
    if not math.isfinite(neighbor):
        raise EventResolutionError("No finite coordinate neighbor")
    # Strictly beyond the midpoint avoids all tie-to-even ambiguity.
    return (Fraction(target)+Fraction(neighbor))/2-Fraction(crossing.offset_mm)


def select_event_probes(catalogue):
    """Return closest resolvable floating probes at each available event side.

    Every probe is strictly on the required side of ALL crossings at BOTH
    adjacent event boundaries, after wheel-coordinate floating rounding.
    If there is no such representable probe, fail rather than claim a limit.
    Metadata includes the finite gap; no exact-limit language is used.
    """
    events = tuple(catalogue)
    if len(events) < 2:
        return ()
    exact_map = event_translation_map(events)
    if any(a.exact_translation_mm >= b.exact_translation_mm for a, b in zip(events[:-1], events[1:])):
        raise ValueError("Strictly increasing exact event catalogue required")
    records = []
    for left, right in zip(events[:-1], events[1:]):
        lower = max([left.exact_translation_mm]+[_rounding_threshold(c, "right") for c in left.crossings])
        upper = min([right.exact_translation_mm]+[_rounding_threshold(c, "left") for c in right.crossings])
        if lower >= upper:
            raise EventResolutionError("Adjacent event interval has no strictly sided rounded physical coordinates")
        for side, boundary, event in (("right", lower, left), ("left", upper, right)):
            direction = math.inf if side == "right" else -math.inf
            probe = float(boundary)
            for _ in range(16):
                fraction = Fraction(probe)
                strictly_inside = lower < fraction < upper
                left_ok = all(exact_wheel_coordinate(probe, c.offset_mm) > c.target_mm for c in left.crossings)
                right_ok = all(exact_wheel_coordinate(probe, c.offset_mm) < c.target_mm for c in right.crossings)
                if strictly_inside and probe not in exact_map and left_ok and right_ok:
                    break
                if (side == "right" and fraction >= upper) or (side == "left" and fraction <= lower):
                    raise EventResolutionError("No floating translation resolves the adjacent event sides")
                probe = math.nextafter(probe, direction)
                if not math.isfinite(probe):
                    raise EventResolutionError("Nonfinite side probe")
            else:
                raise EventResolutionError("Rounding-threshold verification failed; no probe accepted")
            records.append(dict(translation_mm=probe, event_translation_mm=event.translation_mm,
                                side=side, approximate_limit=True,
                                distance_to_event_mm=float(abs(Fraction(probe)-event.exact_translation_mm)),
                                interval_start_mm=left.translation_mm, interval_end_mm=right.translation_mm,
                                strict_rounded_wheel_sides_verified=True))
    return tuple(records)
