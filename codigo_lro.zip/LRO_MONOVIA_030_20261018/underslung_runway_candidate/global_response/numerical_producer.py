"""Internal production of scoped engineering-numerical evidence, not a toggle.

All-translation polynomial extrema are verified at every required fixed face.
Spatial coverage means the COMPLETE computed finite observation grid, with
its separate sampled refinement evidence, never a continuum upper bound.
"""
from dataclasses import asdict
from enum import Enum
from fractions import Fraction
import hashlib
import json
import math
from pathlib import Path

from underslung_runway_candidate.autonomous_frame.solver import FrameModel
from underslung_runway_candidate.autonomous_workflow.model import PhysicalWheel, MovingCase, physical_train_at
from .moving_point_bounds import fixed_point_extrema, PolynomialDomainError, ABS_TOL, _FixedModelStateCache
from .translation_events import build_event_catalogue


class EvidenceKind(str, Enum):
    NOT_ESTABLISHED = "not_established"
    FIXED_FE_EXTREMA_MESH_CONVERGED = "fixed_FE_extrema_mesh_converged"


REQUIRED_FIELDS = ("N", "My", "Mz", "B_equilibrated")


def _canonical(value):
    return json.loads(json.dumps(value, default=asdict, sort_keys=True, separators=(",", ":"), allow_nan=False))


def _signature(value):
    return hashlib.sha256(json.dumps(_canonical(value), sort_keys=True, separators=(",", ":"), allow_nan=False).encode()).hexdigest()


def _hash(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def _real(value, name):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        raise ValueError(name+" must be a finite real")
    return float(value)


def _require(condition, message):
    if not condition:
        raise ValueError(message)


def _gather_governing_coordinates(scan):
    result = set()
    containers = [scan["extrema"], scan.get("support_reaction_extrema", {})]
    containers.extend(row["extrema"] for row in scan.get("segment_extrema", ()))
    for container in containers:
        for bounds in container.values():
            for bound in ("min", "max"):
                if bounds.get(bound) is not None:
                    result.add(_real(bounds[bound]["x_mm"], "governing material coordinate"))
    return result


def _governing_records_at(scan, x):
    containers = [scan["extrema"]]
    containers.extend(row["extrema"] for row in scan.get("segment_extrema", ()))
    return [(field, bound, record) for container in containers for field, bounds in container.items()
            for bound, record in bounds.items() if record is not None and record["x_mm"] == x]


def _independent_wrench(wheel, case):
    """Constant physical contact action, independently of the scan transport.

    Explicit empty-crane horizontal values (including zero) override the
    loaded values only in an empty case. None retains the adopted common-H
    model. Origin factors and case signs are each applied exactly once.
    """
    hx = wheel.longitudinal_N
    hy = wheel.transverse_N
    hx_vertical = wheel.longitudinal_vertical_N
    hy_vertical = wheel.transverse_vertical_N
    if not case.loaded:
        if wheel.longitudinal_empty_N is not None:
            hx = wheel.longitudinal_empty_N
        if wheel.transverse_empty_N is not None:
            hy = wheel.transverse_empty_N
        if wheel.longitudinal_vertical_empty_N is not None:
            hx_vertical = wheel.longitudinal_vertical_empty_N
        if wheel.transverse_vertical_empty_N is not None:
            hy_vertical = wheel.transverse_vertical_empty_N
    fx = hx*case.longitudinal*case.longitudinal_sign
    fy = hy*case.transverse*case.transverse_sign
    retained_factor=case.lifted if case.retained_lifted is None else case.retained_lifted
    fz = -(wheel.dead_N*case.equipment_dead+(wheel.lifted_N*case.lifted if case.loaded else 0.)
           +wheel.retained_lifted_N*retained_factor)
    # H-induced redistribution is signed upward-positive, NOT additional G/Q.
    # Its complete vector reverses and scales with that H origin exactly once.
    fz += hx_vertical*case.longitudinal*case.longitudinal_sign
    fz += hy_vertical*case.transverse*case.transverse_sign
    return dict(Fx=fx, Fy=fy, Fz=fz, Mx=wheel.y_mm*fz-wheel.z_mm*fy,
                My=wheel.z_mm*fx, Mz=-wheel.y_mm*fx, B=-wheel.omega_mm2*fx)


def _sampled_metric_value(field, state, solution, wheels):
    """Reproduce one identified raw/contact/chord-relative scan governor."""
    service = field.startswith("service_span/")
    if not service and not field.startswith("contact/"):
        return state[field], ABS_TOL.get(field, 1e-7)
    span = None
    contact_key = field
    if service:
        _, index, contact_key = field.split("/", 2)
        support_x = sorted({float(s["x"]) for s in solution.model.supports})
        index = int(index)
        _require(0 <= index < len(support_x)-1, "Governor service span is not a physical suspension interval")
        span = support_x[index:index+2]
        _require(span[0] <= state["x"] <= span[1], "Governor lies outside its service span")
    _require(contact_key.startswith("contact/"), "Malformed physical-contact governor")
    wid, component = contact_key[len("contact/"):].rsplit("/", 1)
    wheel = next((w for w in wheels if w.id == wid), None)
    _require(wheel is not None, "Governor contact identity does not belong to the physical train")
    if service:
        _require(component in ("relative_v", "relative_w"), "Unknown service contact component")
        component = component[len("relative_"):]

    def project(row):
        return dict(u=row["u"]+wheel.z_mm*row["theta_y"]-wheel.y_mm*row["theta_z"]-wheel.omega_mm2*row["chi"],
                    v=row["v"]-wheel.z_mm*row["phi"], w=row["w"]+wheel.y_mm*row["phi"])[component]

    value = project(state)
    if service:
        a, b = span
        left = project(solution.at(a, "right" if a < solution.model.length else "left"))
        right = project(solution.at(b, "right" if b < solution.model.length else "left"))
        ratio = (state["x"]-a)/(b-a)
        value -= (1-ratio)*left+ratio*right
    return value, ABS_TOL[component]


def verify_moving_response(model, physical_wheels, case, scan_result, *, selfweight, extra_dead,
                           observation_points, mesh_converged, mesh_history,
                           extra_dead_y_mm=0., relative_tolerance=.01,
                           fields=REQUIRED_FIELDS, polynomial_relative_tolerance=1e-8,
                           max_observation_faces=20000, max_polynomial_intervals=20000):
    """Return evidence only after all computed prerequisites and faces verify.

    `mesh_converged=True` is insufficient: >=3 source/case/signature-bound
    computed mesh-history rows and two final successful refinement comparisons
    are required. The same is required for moving/spatial sampling. The caller
    supplies the complete final computed base grid; segment boundaries and ALL
    scan-governing coordinates are added automatically. A missing input,
    unresolved event, incomplete point, or failed verification returns
    NOT_ESTABLISHED with the precise reason and diagnostic partial work.

    Normative applicability, actual fork eligibility, section assumptions and
    destabilizing load radius are independent downstream gates. This producer
    never converts those gates to true and never claims continuum upper bounds.
    """
    result = dict(evidence_kind=EvidenceKind.NOT_ESTABLISHED.value,
                  producer_kind=EvidenceKind.NOT_ESTABLISHED.value,
                  continuum_upper_bound_claimed=False, bounds_are_upper=False,
                  all_point_completion=False, producer_receipt=None, segment_extrema=[],
                  refined_extrema={}, polynomial_receipts=[], pending=[],
                  boundary_governor_witnesses=[],
                  spatial_scope="Complete computed finite grid and segment boundaries. Auxiliary machine-adjacent governing states may use explicitly reproduced boundary-envelope witnesses, not an alltranslation proof at the auxiliary point. No continuum coverage.")
    try:
        _require(type(model) is FrameModel, "Exactly the fixed linear FrameModel is required")
        _require(isinstance(case, MovingCase), "Identified MovingCase required")
        wheels = tuple(physical_wheels)
        _require(bool(wheels) and all(isinstance(w, PhysicalWheel) for w in wheels), "Individual identified PhysicalWheel inputs required")
        _require(len({w.id for w in wheels}) == len(wheels), "Physical wheel identities are not unique")
        tol = _real(relative_tolerance, "engineering numerical relative tolerance")
        _require(0 < tol <= .01, "Engineering evidence requires relative tolerance <= 0.01")
        polynomial_relative_tolerance = _real(polynomial_relative_tolerance, "polynomial relative tolerance")
        _require(0 < polynomial_relative_tolerance <= 1e-6, "Polynomial verification tolerance must not exceed 1e-6")
        _require(type(mesh_converged) is bool and mesh_converged, "Computed torsion/response mesh convergence is not established")
        _require(scan_result.get("converged") is True, "Moving-position and spatial sampling convergence is not established")
        manifest = scan_result.get("input_manifest")
        _require(isinstance(manifest, dict), "Scan input manifest missing")
        _require(_signature(manifest) == scan_result.get("input_signature"), "Scan input signature does not match its manifest")
        _require(_canonical(scan_result["case"]) == _canonical(asdict(case)) == manifest["case"], "Case identity or factor ledger mismatch")
        current = dict(length=model.length, section=model.section, supports=model.supports,
                       wheels=wheels, case=case, selfweight=_real(selfweight, "selfweight"),
                       extra_dead=_real(extra_dead, "extra dead"), extra_dead_y_mm=_real(extra_dead_y_mm, "extra dead load-line y"))
        for key, value in _canonical(current).items():
            _require(key in manifest and manifest[key] == value, "Current model/action input differs from signed scan manifest: "+key)
        _require(current["selfweight"] >= 0 and current["extra_dead"] >= 0, "Negative permanent-load magnitude unsupported")
        solver_path = Path(__file__).resolve().parents[1]/"autonomous_frame"/"solver.py"
        solver_hash = _hash(solver_path)
        _require(scan_result.get("solver_source_hash") == solver_hash, "Scan solver source hash is missing or stale")
        _require(scan_result.get("solver_source_unchanged") is True, "Solver source changed during the scan")

        history = scan_result.get("history", ())
        _require(len(history) >= 3, "Two independent final moving/spatial comparisons are required")
        _require(history[-1].get("stable_passes", 0) >= 2, "Moving/spatial stable-pass count below two")
        for row in history[-2:]:
            change = _real(row["relative_change"], "computed moving/spatial change")
            _require(row.get("stable_passes", 0) >= 1 and 0 <= change <= tol, "Final moving/spatial refinement comparison is not adequate")
        mesh_rows = tuple(mesh_history)
        _require(len(mesh_rows) >= 3, "At least three computed mesh levels are required")
        _require(mesh_rows[-1].get("stable_passes", 0) >= 2, "Computed mesh stable-pass count below two")
        for row in mesh_rows:
            _require(row.get("case_id") == case.id, "Mesh history belongs to a different or unidentified case")
            _require(isinstance(row.get("scan_input_signature"), str) and len(row["scan_input_signature"]) == 64,
                     "Mesh history lacks its computed scan signature")
            _require(row.get("solver_source_hash") == solver_hash, "Mesh history source hash is missing or stale")
        for before, after in zip(mesh_rows[:-1], mesh_rows[1:]):
            _require(after["max_element_length_mm"] < before["max_element_length_mm"], "Mesh history is not a strictly refined sequence")
        for row in mesh_rows[-2:]:
            change = _real(row["mesh_relative_change"], "computed mesh relative change")
            _require(row.get("moving_converged") is True and 0 <= change <= tol, "Final mesh comparison or its moving scan is not converged")
        _require(mesh_rows[-1]["scan_input_signature"] == scan_result["input_signature"], "Final mesh history is not bound to this scan")
        _require(mesh_rows[-1]["elements"] == len(model.nodes)-1, "Final mesh element count does not match the model")
        _require(max(float(b-a) for a, b in zip(model.nodes[:-1], model.nodes[1:])) <= mesh_rows[-1]["max_element_length_mm"]*(1+1e-12),
                 "Final model mesh is coarser than its mesh history")

        fixed = tuple(manifest["fixed_stations"])
        _require(set(map(float, model.nodes)).issubset(set(fixed)), "Signed scan manifest omits a current stiffness node")
        density = history[-1]["density"]
        _require(type(density) is int and density > 0, "Computed final spatial density missing")
        expected_base = set(fixed)
        for a, b in zip(fixed[:-1], fixed[1:]):
            expected_base.update(a+(b-a)*j/density for j in range(1, density))
        base = {_real(x, "computed base observation") for x in scan_result["spatial_base_stations_mm"]}
        _require(base == expected_base, "Final observation grid does not match computed spatial refinement")
        supplied = {_real(x, "supplied observation") for x in observation_points}
        _require(base.issubset(supplied), "Supplied observation grid omits computed final base points")
        segments = manifest.get("segments", ())
        _require(bool(segments), "No segment domains supplied for numerical member evidence")
        mandatory = set(supplied)
        for segment in segments:
            a, b = _real(segment["start_mm"], "segment start"), _real(segment["end_mm"], "segment end")
            _require(0 <= a < b <= model.length, "Invalid physical segment domain")
            mandatory.update((a, b))
            result["segment_extrema"].append(dict(start_mm=a, end_mm=b, extrema={}))
        catalogue = build_event_catalogue(model.length, wheels, fixed,
                          travel_min_mm=manifest.get("travel_min_mm"), travel_max_mm=manifest.get("travel_max_mm"))
        _require([e.as_record() for e in catalogue] == scan_result["exact_translation_events"], "Exact scan event catalogue does not match current geometry/train")
        lo, hi = catalogue[0].exact_translation_mm, catalogue[-1].exact_translation_mm
        # A sampled wheel governor can sit one ulp inside its physical travel
        # endpoint even when that endpoint is not on the base spatial grid.
        # Verify those real endpoint material sections themselves first; only
        # then may the existing strict sampled-state boundary witness apply.
        endpoint_points = {}
        for translation in (lo, hi):
            for wheel in wheels:
                exact_x = translation+Fraction(wheel.offset_mm)
                if 0 <= exact_x <= Fraction(model.length):
                    x = float(exact_x)
                    _require(x not in endpoint_points or endpoint_points[x] == exact_x,
                             "Distinct physical travel-end wheel coordinates alias in floating point")
                    endpoint_points[x] = exact_x
                    mandatory.add(x)
        result["physical_travel_endpoint_observations_mm"] = sorted(endpoint_points)
        observations = mandatory | _gather_governing_coordinates(scan_result)
        _require(all(0 <= x <= model.length for x in observations), "Observation outside member")
        ordered_observations = sorted(mandatory)+sorted(observations-mandatory)
        faces = [(x, side) for x in ordered_observations for side in ("left", "right")
                 if not (x == 0 and side == "left") and not (x == model.length and side == "right")]
        _require(type(max_observation_faces) is int and len(faces) <= max_observation_faces, "Complete observation face budget exceeded; no points were dropped")
        result.update(required_observation_points_mm=sorted(observations), required_observation_faces=len(faces),
                      completed_observation_faces=0)
        fields = tuple(fields)
        _require(set(REQUIRED_FIELDS).issubset(fields), "Numerical member evidence requires N, My, Mz and equilibrated B together")

        moving = []
        for wheel in wheels:
            wrench = _independent_wrench(wheel, case)
            transported = physical_train_at((wheel,), case, -wheel.offset_mm, model.length)[0]
            _require(all(transported[k] == value for k, value in wrench.items()), "Independent physical action ledger disagrees with transport")
            moving.append(dict(offset=wheel.offset_mm, wheel_id=wheel.id, **wrench))
        qz = -(selfweight*case.support_dead+extra_dead*case.extra_dead)
        mx = -extra_dead*case.extra_dead*extra_dead_y_mm
        udls = [dict(start=0., end=model.length, qz=qz, mx=mx)] if qz or mx else []

        def aggregate(container, field, bounds, x, side):
            row = container.setdefault(field, dict(min=None, max=None))
            for target, source in (("min", "minimum"), ("max", "maximum")):
                candidate = bounds[source]
                old = row[target]
                if old is None or (candidate["value"] < old["value"] if target == "min" else candidate["value"] > old["value"]):
                    row[target] = dict(value=candidate["value"], case_id=case.id,
                        translation_mm=candidate["translation_mm"], translation_exact_mm=candidate["translation_exact_mm"],
                        x_mm=x, side=side, numerical_candidate_kind=candidate["kind"])

        total_solves, maximum_polynomial_ratio = 0, 0.
        state_cache = _FixedModelStateCache(model)
        verified_faces = {}

        def boundary_witness(x, side, failure):
            # This is NOT a substitute for a missing base-grid polynomial.
            # Only machine-adjacent auxiliary governors may use a re-solved
            # sampled-state witness in an already verified boundary envelope.
            _require(x not in mandatory, "Mandatory base/segment observation cannot be replaced by a witness")
            resolution_errors = ("too narrow", "rounds onto", "alias in floating", "could not be represented")
            _require(any(word in str(failure) for word in resolution_errors), "A failed polynomial residual cannot be waived by a boundary witness")
            coordinate_allowance = 8*max(math.ulp(x), math.ulp(model.length), *(math.ulp(w.offset_mm) for w in wheels))
            candidates = [b for b in mandatory if 0 < abs(x-b) <= coordinate_allowance]
            _require(bool(candidates), "Unresolved governor is not machine-adjacent to a verified required point")
            boundary = min(candidates, key=lambda b: abs(x-b))
            boundary_side = "left" if x < boundary else "right"
            _require((boundary, boundary_side) in verified_faces, "Required boundary-face polynomial is unavailable")
            truth = verified_faces[boundary, boundary_side]
            records = _governing_records_at(scan_result, x)
            _require(bool(records), "Auxiliary point has no traceable sampled governing state")
            checks = []
            for field, bound, original in records:
                _require(original["case_id"] == case.id, "Governor witness case mismatch")
                exact = original.get("translation_exact_mm")
                _require(isinstance(exact, dict), "Governor witness lacks exact translation identity")
                t = Fraction(int(exact["numerator"]), int(exact["denominator"]))
                _require(float(t) == original["translation_mm"], "Governor translation identity mismatch")
                loads = physical_train_at(wheels, case, float(t), model.length, exact_translation=t)
                original_solution = model.solve(loads, udls)
                original_state = original_solution.at(x, original["side"])
                actual_original, original_atol = _sampled_metric_value(field, original_state, original_solution, wheels)
                _require(math.isclose(actual_original, original["value"], rel_tol=1e-8, abs_tol=original_atol),
                         "Original sampled governor could not be reproduced")
                field_checks = {}
                for metric in fields:
                    lower = truth["fields"][metric]["minimum"]["value"]
                    upper = truth["fields"][metric]["maximum"]["value"]
                    allowance = max(ABS_TOL[metric]+polynomial_relative_tolerance*max(abs(lower), abs(upper)),
                                    history[-1]["roundoff_allowances"].get(metric+"/min", 0.),
                                    history[-1]["roundoff_allowances"].get(metric+"/max", 0.))
                    value = original_state[metric]
                    _require(lower-allowance <= value <= upper+allowance, "Boundary envelope does not witness the original sampled "+metric)
                    field_checks[metric] = dict(original_sample=value, boundary_minimum=lower,
                                               boundary_maximum=upper, numerical_allowance=allowance)
                checks.append(dict(original_field=field, original_bound=bound, original_identity=original,
                                   field_coverage=field_checks))
            result["boundary_governor_witnesses"].append(dict(original_x_mm=x, original_auxiliary_face=side,
                boundary_x_mm=boundary, boundary_side=boundary_side,
                coordinate_distance_mm=abs(x-boundary), coordinate_roundoff_allowance_mm=coordinate_allowance,
                sampled_state_witness_only=True, full_polynomial_at_original_point_claimed=False,
                reason=str(failure), reproduced_governing_states=checks))

        for x, side in faces:
            try:
                verified = fixed_point_extrema(model, moving, x, lo, hi, fields=fields,
                             distributed_loads=udls, spatial_side=side,
                             relative_tolerance=polynomial_relative_tolerance, max_intervals=max_polynomial_intervals,
                             _state_cache=state_cache)
            except PolynomialDomainError as failure:
                boundary_witness(x, side, failure)
                result["completed_observation_faces"] += 1
                continue
            _require(verified["status"] == "numerically_verified_piecewise_cubic_extrema", "Polynomial verification did not finish")
            verified_faces[x, side] = verified
            for field, bounds in verified["fields"].items():
                aggregate(result["refined_extrema"], field, bounds, x, side)
                for segment in result["segment_extrema"]:
                    a, b = segment["start_mm"], segment["end_mm"]
                    if a <= x <= b and not (x == a and side == "left") and not (x == b and side == "right"):
                        aggregate(segment["extrema"], field, bounds, x, side)
            total_solves += verified["solves"]
            maximum_polynomial_ratio = max(maximum_polynomial_ratio, verified["maximum_normalized_verification_error"])
            result["polynomial_receipts"].append(dict(x_mm=x, side=side,
                intervals=len(verified["intervals"]), event_count=len(verified["events_mm"]),
                solve_count=verified["solves"], verification_checks=verified["verification_checks"],
                maximum_normalized_verification_error=verified["maximum_normalized_verification_error"],
                maximum_absolute_verification_error=verified["maximum_absolute_verification_error"],
                interval_coefficients_receipt_hash=_signature(verified["intervals"])))
            result["completed_observation_faces"] += 1
        for segment in result["segment_extrema"]:
            _require(all(k in segment["extrema"] and all(segment["extrema"][k][b] is not None for b in ("min", "max"))
                         for k in fields), "A segment has an incomplete signed field envelope")
        # Independent integration guard: every sampled governing response must
        # be covered by the verified translation extrema at its fixed point.
        for field in fields:
            for bound in ("min", "max"):
                sampled = scan_result["extrema"][field][bound]["value"]
                refined = result["refined_extrema"][field][bound]["value"]
                allowance = max(1e-7, abs(sampled)*1e-7,
                                history[-1]["roundoff_allowances"].get(field+"/"+bound, 0.))
                _require(refined <= sampled+allowance if bound == "min" else refined >= sampled-allowance,
                         "Verified extrema do not cover the scan governing state: "+field+"/"+bound)
        for sampled_segment in scan_result.get("segment_extrema", ()):
            matching = [s for s in result["segment_extrema"] if s["start_mm"] == sampled_segment["start_mm"] and s["end_mm"] == sampled_segment["end_mm"]]
            _require(len(matching) == 1, "Sampled segment has no unique verified numerical domain")
            for field in fields:
                for bound in ("min", "max"):
                    sampled = sampled_segment["extrema"][field][bound]["value"]
                    refined = matching[0]["extrema"][field][bound]["value"]
                    allowance = max(ABS_TOL[field], abs(sampled)*1e-7,
                                    history[-1]["roundoff_allowances"].get(field+"/"+bound, 0.))
                    _require(refined <= sampled+allowance if bound == "min" else refined >= sampled-allowance,
                             "Verified segment extrema do not cover its sampled governor: "+field+"/"+bound)
        normalized_mesh = [dict(row, maximum_relative_change=row.get("mesh_relative_change")) for row in mesh_rows]
        receipt = dict(fixed_FE_extrema_verified=True, event_coverage_complete=True,
            spatial_coverage_complete=True, torsion_mesh_converged=True,
            continuum_upper_bound_claimed=False,
            spatial_coverage_definition=result["spatial_scope"],
            input_signature=scan_result["input_signature"], solver_source_hash=solver_hash,
            extrema_source_hash=_hash(Path(__file__).with_name("moving_point_bounds.py")),
            producer_source_hash=_hash(__file__), relative_tolerance=tol,
            stable_passes=min(history[-1]["stable_passes"], mesh_rows[-1]["stable_passes"]),
            mesh_history=normalized_mesh, moving_spatial_history=history,
            completed_observation_faces=len(faces), required_observation_faces=len(faces),
            full_polynomial_verified_faces=len(verified_faces),
            auxiliary_governor_faces_accounted_by_boundary_witness=len(result["boundary_governor_witnesses"]),
            observation_grid_signature=_signature(faces), maximum_polynomial_verification_ratio=maximum_polynomial_ratio,
            physical_travel_endpoint_observations_mm=sorted(endpoint_points),
            polynomial_relative_tolerance=polynomial_relative_tolerance,
            polynomial_response_solves=total_solves,
            solved_state_reuse=state_cache.receipt(),
            point_action_signature=_signature(moving), distributed_action_signature=_signature(udls),
            normative_domain_qualification="Separate downstream gate; not granted by numerical evidence")
        result.update(evidence_kind=EvidenceKind.FIXED_FE_EXTREMA_MESH_CONVERGED.value,
                      producer_kind=EvidenceKind.FIXED_FE_EXTREMA_MESH_CONVERGED.value,
                      all_point_completion=True, producer_receipt=receipt)
    except (ValueError, TypeError, KeyError, ArithmeticError) as exc:
        result["pending"].append(type(exc).__name__+": "+str(exc))
    return result
