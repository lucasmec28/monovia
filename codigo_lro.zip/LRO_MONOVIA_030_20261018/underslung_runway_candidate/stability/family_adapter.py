"""Dedicated C.2 consumer of INTERNAL verified component-family boxes.

No fictitious concurrent event or x-coordinate is manufactured. All response
components are monotone upper inputs to a sufficient criterion. A satisfied
bound qualifies that bounded criterion; an exceeded bound is INCONCLUSIVE,
not an observed failure. Actual-state failures require a separate witness.
"""
from copy import deepcopy
from dataclasses import asdict
from pathlib import Path
import hashlib

from .c2_adapter import Qualification,evaluate_component_box
from .reference import model_fork_segments
from ..section_stress.whole_section_bounds import whole_section_shear_bound
from ..autonomous_workflow.model import signature
from ..autonomous_workflow.family_envelope import (VERIFIED,FIELDS,build_family_plan,_boxes,_source)


def _require(ok,message):
    if not ok:raise ValueError(message)


def validate_family_receipt(project,receipt):
    """Rebind all physical membership, source, boxes and boundary geometry.

    This validates an internally generated receipt. It is not a public imported
    effort format, nor a user proof checkbox. Numerical errors remain governed
    by the producer's validated engineering tolerances, not a continuum theorem.
    """
    project.validate()
    _require(isinstance(receipt,dict),'Internal family receipt required')
    _require(receipt.get('schema')=='LRO_VERIFIED_COMPONENT_FAMILY_BOX_V1','Unsupported family schema')
    _require(receipt.get('receipt_signature')==signature({k:v for k,v in receipt.items() if k!='receipt_signature'}),'Family receipt was altered')
    _require(receipt.get('evidence_kind')==VERIFIED and not receipt.get('pending'),'All active numerical bases must be verified')
    _require(receipt.get('source_unchanged') is True and receipt.get('source_at_start')==receipt.get('source_at_end'),'Family computation source changed')
    _require(receipt['source_at_end']==_source(),'Family receipt is stale relative to current numerical source')
    _require(receipt.get('project_signature')==signature(project.to_dict()),'Family receipt belongs to another project')
    _require(receipt.get('continuum_upper_bound_claimed') is False and receipt.get('component_box_not_concurrent') is True,'Invalid bound/concurrency scope')
    _require(receipt.get('all_basis_mesh_converged') is True,'Common mesh convergence missing')
    plan=build_family_plan(project,**receipt['action_generation'])
    _require(receipt['generated_input_signature']==plan['generated_input_signature'],'Physical bridge ledger differs')
    _require(receipt.get('suspended_mass_accounting')==plan['suspended_mass_accounting'],'Suspended mass accounting is missing or differs from the regenerated physical convention')
    _require(receipt['configurations']==plan['configurations'],'Generated physical configurations differ')
    _require(receipt['total_configuration_count']==8 and receipt['total_case_count']==len(plan['members']),'Incomplete physical membership')
    membership=[dict(configuration_id=m['configuration_id'],case_id=m['case_id'],case=asdict(m['case']),coefficients=m['coefficients']) for m in plan['members']]
    _require(receipt['complete_membership']==membership,'Original action factors/configuration membership differ')
    _require(not plan['invalid_contacts'],'Actual physical contact prerequisite not met')
    _require(receipt['covered_physical_travel_intervals_mm']==plan['covered_physical_travel_intervals_mm'],'Physical travel coverage differs')
    _require(receipt['supplementary_method_adoption']==dict(source=project.supplementary_en_source,resistance_gamma=project.supplementary_en_resistance_gamma),'Resistance basis changed')
    definitions=[dict(id=b.id,amplitude=b.amplitude,origin=b.origin,station_index=b.station_index,component=b.component,
        case=asdict(b.case),wheels=[asdict(w) for w in b.wheels],all_coefficients_zero=b.amplitude==0.) for b in plan['bases']]
    _require(receipt['basis_definitions']==definitions,'Physical linear basis definitions differ')
    active={b.id for b in plan['bases'] if b.amplitude!=0.}
    evidence=receipt['basis_evidence']
    _require(set(evidence)==active,'Missing or substituted active basis evidence')
    meshes=set()
    for name,row in evidence.items():
        history=row['mesh_history'];_require(len(history)>=3,'Three actual mesh levels required')
        _require(history[-1]['stable_passes']>=2,'Two stable actual mesh comparisons required')
        meshes.add(history[-1]['max_element_length_mm'])
        v=row['verification'];r=v['producer_receipt']
        _require(v['evidence_kind']=='fixed_FE_extrema_mesh_converged' and v['all_point_completion'] is True,'Incomplete actual polynomial verification')
        _require(set(v['refined_extrema'])==set(FIELDS),'Missing whole response field')
        _require(r['fixed_FE_extrema_verified'] is True and r['event_coverage_complete'] is True and r['spatial_coverage_complete'] is True and r['torsion_mesh_converged'] is True,'Incomplete basis numerical coverage')
        _require(r['relative_tolerance']<=.01,'Basis tolerance exceeds the adopted scope')
    _require(len(meshes)==1,'Bases do not share the same final physical mesh')
    model=project.frame_model(meshes.pop())
    _require(list(map(float,model.nodes))==receipt['common_final_mesh_nodes_mm'],'Final model mesh differs')
    boundaries=model_fork_segments(model)
    _require(boundaries==receipt['true_fork_boundary_audit'],'Actual fork/segment constraints differ')
    recomputed=_boxes(plan,evidence,boundaries['segments'])
    _require(receipt['families']==recomputed,'Family box/guard membership is not the exact internal interval composition')
    return model,plan


def evaluate_family_member(project,receipt):
    """Selected ULS8800 action domain + explicitly adopted EN2025 resistance.

    Other action families remain in the source receipt but are not silently fed
    to this resistance method. No connection, contact, fatigue or building scope
    is promoted by this member result.
    """
    result=dict(kind='autonomous_c2_verified_family_consumer',status='PENDING_FAMILY_MEMBER',families=[],pending=[],
        whole_beam_qualified=False,actual_failure_proven=False,concurrent_tensor_claimed=False,
        continuum_upper_bound_claimed=False,numerical_engineering_result=True,
        sufficient_member_criteria_satisfied=False,sufficient_nominal_section_criteria_satisfied=False)
    own=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    try:
        before=signature(project.to_dict());model,plan=validate_family_receipt(project,receipt)
        _require(project.fy_mpa is not None and project.supplementary_en_resistance_gamma is not None and project.supplementary_en_source.strip(),'Explicit material and supplementary resistance basis required')
        chosen=[f for f in receipt['families'] if f['family']=='ULS8800']
        _require(bool(chosen),'No ULS8800 source family was generated; other families are not substituted')
        for family in chosen:
            q=Qualification(case_id=family['family'],action_basis_source='; '.join(family['action_basis_sources']),
                method_adoption_source=project.supplementary_en_source,bounds_are_upper=False,
                bounds_source='Internal verified fixed-FE component-family interval receipt '+receipt['receipt_signature'],
                torsion_mesh_qualified=True,no_destabilizing_transverse_load_radius=family['all_members_non_destabilizing_radius'],
                uniform_undistorted_thin_wall_i_adopted=True,structural_steel_ambient=True,
                producer_kind=VERIFIED,producer_receipt=receipt)
            entries=[]
            for segment in family['segments']:
                mag=lambda k:max(abs(segment['bounds'][k]['lower']),abs(segment['bounds'][k]['upper']))
                shear=whole_section_shear_bound(project.section,abs_Fy_N=mag('Fy'),abs_Fz_N=mag('Fz'),abs_Tsv_Nmm=mag('Tsv'),abs_Tw_Nmm=mag('Tw_equilibrated'))
                r=evaluate_component_box(model,project.section,segment,q,E_mpa=project.E_mpa,nu=project.nu,fy_mpa=project.fy_mpa,
                    resistance_gamma=project.supplementary_en_resistance_gamma,shear_upper_mpa=shear['tau_bound_mpa'],shear_bound_source=shear['source'])
                # Avoid copying a large receipt per segment. Preserve its exact identity.
                if 'response_producer' in r:r['response_producer']['receipt']=dict(receipt_signature=receipt['receipt_signature'],evidence_kind=VERIFIED)
                r['nominal_shear_bound']=shear;entries.append(r)
            result['families'].append(dict(family=family['family'],physical_member_count=len(family['members']),segments=entries,
                all_members_contact_valid=family['all_members_contact_valid'],load_radius_domain=family['all_members_non_destabilizing_radius']))
        checks=[c for f in result['families'] for s in f['segments'] for c in s['checks']]
        result['pending']=[p for f in result['families'] for s in f['segments'] for p in s.get('pending',[])]
        _require(bool(checks),'No member criteria were produced')
        member=[c for c in checks if c['id']!='global_elastic_section'];section=[c for c in checks if c['id']=='global_elastic_section']
        result['sufficient_member_criteria_satisfied']=bool(member) and all(c['qualified'] and c['status']=='ATENDE' for c in member)
        result['sufficient_nominal_section_criteria_satisfied']=bool(section) and all(c['qualified'] and c['status']=='ATENDE' for c in section)
        if all(c['qualified'] for c in checks):
            result['status']='SUFFICIENT_FAMILY_MEMBER_CHECKS_SATISFIED' if all(c['status']=='ATENDE' for c in checks) else 'INCONCLUSIVE_SUFFICIENT_BOUND'
        _require(before==signature(project.to_dict()),'Project changed during family consumption')
        _require(receipt['source_at_end']==_source(),'Numerical source changed during family consumption')
        _require(own==hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'Family consumer source changed')
        result['source_receipt']=dict(consumer_sha256=own,producer_receipt_signature=receipt['receipt_signature'],project_signature=before,
            source_fingerprint=receipt['source_at_end']['fingerprint'])
    except (ValueError,TypeError,KeyError,ArithmeticError,AttributeError) as exc:
        result.update(status='PENDING_FAMILY_MEMBER',families=[],sufficient_member_criteria_satisfied=False,sufficient_nominal_section_criteria_satisfied=False)
        result['pending'].append(type(exc).__name__+': '+str(exc))
    return result
