"""Isolated elastic reference helpers. Not a strength or connection approval.

The conservative Mcr input is for a straight doubly symmetric prismatic
Vlasov member with centroid lateral displacement and twist zero at endpoints.
Actual axial/biaxial/torsion/warping resistance needs a separately sourced
member method. Ideal model constraints never prove real connection strength.
"""
import math
import numpy as np


def _positive(x, name):
    if isinstance(x,(bool,np.bool_)) or not isinstance(x,(int,float,np.number)):
        raise ValueError(name+' must be finite positive')
    try:ok=math.isfinite(x) and x>0
    except (OverflowError,ValueError):ok=False
    if not ok:raise ValueError(name+' must be finite positive')
    return float(x)


def warping_only_mcr(*,E_mpa,Iweak_mm4,Cw_mm6,length_mm):
    """Sufficient reference lower bound for ANY signed major moment diagram.

    Normalize the diagram by M*=sup|M|. Cauchy and the two-end Dirichlet
    Poincare inequality bound its geometric bilinear work by
    2 M* L²/pi² ||v''|| ||phi''||. Keeping only EIweak and ECw energy gives
    Mcr >= pi² E sqrt(Iweak*Cw)/L². Positive GJ and stabilizing wheel height
    are discarded. Destabilizing height terms MUST be absent/separately bounded.
    This is not the actual pretwisted N/M/T/B critical load.
    """
    E,I,C,L=(_positive(v,k) for v,k in ((E_mpa,'E'),(Iweak_mm4,'Iweak'),(Cw_mm6,'Cw'),(length_mm,'L')))
    # Log evaluation avoids otherwise avoidable intermediate product overflow.
    logm=2*math.log(math.pi)+math.log(E)+.5*(math.log(I)+math.log(C))-2*math.log(L)
    try:m=math.exp(logm)
    except OverflowError as exc:raise ValueError('Mcr outside finite numeric domain') from exc
    if not math.isfinite(m) or m<=0:raise ValueError('Mcr outside finite numeric domain')
    m*=1.-1e-12  # explicit engineering floating-point guard, not interval libm proof
    return dict(Mcr_lower_nmm=m,numerical_relative_guard=1e-12,source='Elastic Vlasov energy comparison; JRC NCCI SN003a Eq.(3) with C1=1 and positive GJ discarded',
        is_reference_only=True,combined_member_qualified=False,connection_strength_qualified=False,
        ignores_beneficial_GJ=True,ignores_beneficial_bottom_load_height=True)


def model_station_constraints(model,x_mm,*,residual_limit=1e-11):
    """Certify only the algebraic support conditions declared in FrameModel.C.

    Local rows at this station are used, not rigid-member assumptions or
    support pitch. A top-flange uy restraint alone does not imply v=phi=0.
    Translational and rotational units are normalized by the model length.
    Failure/ill-conditioning gives no fork credit. No connection adequacy.
    """
    x=float(x_mm)
    hits=np.flatnonzero(model.nodes==x)
    if len(hits)!=1:raise ValueError('Exact model support station required')
    node=int(hits[0]);n=7*node
    rows=[];ids=[]
    for j,(support_index,component) in enumerate(model.constraint_metadata):
        if float(model.supports[support_index]['x'])==x:
            row=np.asarray(model.C[j],dtype=float)
            outside=np.r_[row[:n],row[n+7:]]
            if np.any(outside!=0):raise ValueError('Nonlocal constraint cannot be treated as a station fork')
            rows.append(row[n:n+7]);ids.append(dict(row=j,support_index=support_index,component=component))
    if not rows:return dict(x_mm=x,model_fork=False,vertical_supported=False,reason='No explicit constraints at station',connection_strength_qualified=False)
    L=_positive(model.length,'model length')
    Q=np.array([1.,1.,1.,1./L,1./L,1./L,1./(L*L)])
    A=np.asarray(rows)*Q
    norms=np.linalg.norm(A,axis=1)
    if not np.isfinite(A).all() or np.any(norms==0):raise ValueError('Invalid constraint row')
    A=A/norms[:,None]
    U,s,Vh=np.linalg.svd(A,full_matrices=True)
    rank=int(np.count_nonzero(s>1e-10))
    independent=rank==len(rows)
    Z=Vh[rank:,:].T
    residuals={key:float(np.linalg.norm(Z[j,:])) for j,key in enumerate(('u','v','w','phi','theta_y','theta_z','chi'))}
    finite=np.isfinite(s).all() and np.isfinite(Z).all()
    good=independent and finite
    locked={k:good and v<=residual_limit for k,v in residuals.items()}
    return dict(x_mm=x,model_fork=bool(locked['v'] and locked['phi']),vertical_supported=bool(locked['w']),
        locked=locked,residuals=residuals,rank=rank,rows=len(rows),minimum_retained_singular=float(s[rank-1]) if rank else 0.,
        constraints=ids,reason='Algebraic ideal-model constraint only; physical strength/stiffness remains separate',
        connection_strength_qualified=False)


def model_fork_segments(model):
    """Return bounded reference segments and exact uncovered physical tails.

    This does not claim standard C.2 applicability to every segmented system;
    the resistance adapter must state its source/domain adoption separately.
    """
    stations=sorted({float(s['x']) for s in model.supports})
    audits=[model_station_constraints(model,x) for x in stations]
    xs=[a['x_mm'] for a in audits if a['model_fork'] and a['vertical_supported']]
    segments=[dict(start_mm=a,end_mm=b,length_mm=b-a) for a,b in zip(xs,xs[1:])]
    uncovered=[]
    if not xs:uncovered=[(0.,model.length)]
    else:
        if xs[0]>0:uncovered.append((0.,xs[0]))
        if xs[-1]<model.length:uncovered.append((xs[-1],model.length))
    return dict(stations=audits,segments=segments,uncovered_tails_mm=uncovered,
        reference_boundary_coverage=bool(segments) and not uncovered,
        physical_support_qualified=False,whole_member_qualified=False)


def first_order_axial_gate(*,E_mpa,Imajor_mm4,Iminor_mm4,length_mm,compression_upper_n):
    """Sufficient non-sway flexural gate for EN2025 M1, NOT an LTB exemption.

    For each actual fork/vertical segment, releasing end slopes gives the
    pinned Euler reference. N(x) <= Nupper pointwise implies alpha_cr,ns >=
    min(Ncr_major,Ncr_minor)/Nupper. Use EN's default k0=25, not NA relief.
    Real support stiffness, second-order LTB/torsion and member strength remain
    separate. The caller must establish the endpoint and action-envelope gates.
    """
    E,Iy,Iz,L=(_positive(v,k) for v,k in ((E_mpa,'E'),(Imajor_mm4,'Imajor'),
        (Iminor_mm4,'Iminor'),(length_mm,'L')))
    if isinstance(compression_upper_n,(bool,np.bool_)):
        raise ValueError('Compression upper bound must be finite nonnegative')
    try:N=float(compression_upper_n)
    except (ValueError,TypeError,OverflowError) as exc:
        raise ValueError('Compression upper bound must be finite nonnegative') from exc
    if not math.isfinite(N) or N<0:raise ValueError('Compression upper bound must be finite nonnegative')
    def euler(I):
        try:value=math.exp(2*math.log(math.pi)+math.log(E)+math.log(I)-2*math.log(L))*(1-1e-12)
        except OverflowError as exc:raise ValueError('Euler load outside finite numeric domain') from exc
        if not math.isfinite(value) or value<=0:raise ValueError('Euler load outside finite numeric domain')
        return value
    Ny,Nz=euler(Iy),euler(Iz);limit=min(Ny,Nz)/25
    if not math.isfinite(limit) or limit<=0:raise ValueError('First-order limit outside finite numeric domain')
    return dict(non_sway_flexural_first_order_sufficient=N<=limit,
        compression_upper_n=N,compression_limit_n=limit,Ncr_major_lower_n=Ny,Ncr_minor_lower_n=Nz,
        k0=25,ltb_exempted=False,torsional_buckling_exempted=False,physical_support_qualified=False,
        source='DIN EN1993-1-1:2025 sections7.2.1(4)-(5),7.2.2(5): M1; conservative pinned-reference comparison',
        scope='Requires separately established no-sway fork/vertical boundaries and pointwise compression upper bound')


def transverse_dead_load_radius_guard(wheels,case,*,distributed_parcels=()):
    """Automatic sufficient dead-force radial-work guard for a physical case.

    Coincident wheels are grouped by exact longitudinal offset: their signed
    correlations are preserved. The case factors are applied exactly once as
    in physical_train_at. A distributed parcel is already-final qy/qz at y/z.
    The second variation of a fixed-direction force under right-hand section
    twist is +(Fy*y+Fz*z)*phi². Nonnegative coefficients are not destabilizing.
    This is an adopted rigid-section reference statement, not a follower-load
    or 3-D attachment theorem; all actual torque actions remain in resistance.
    """
    from ..autonomous_workflow.model import PhysicalWheel,MovingCase,wheel_force_components
    if not isinstance(case,MovingCase) or not wheels or any(not isinstance(w,PhysicalWheel) for w in wheels):
        raise ValueError('Physical wheel train and MovingCase required')
    grouped={}
    for w in wheels:
        # Includes signed, correlated vertical inertia in BOTH H parcels. These
        # are not equipment G/Q and must reverse with the corresponding action.
        _,fy,fz=wheel_force_components(w,case)
        pieces=(fy*w.y_mm,fz*w.z_mm)
        if not all(math.isfinite(v) for v in pieces):raise ValueError('Nonfinite dead-load radius work')
        grouped.setdefault(w.offset_mm,[]).extend(pieces)
    rows=[dict(offset_mm=x,radial_work_coefficient_nmm=math.fsum(values)) for x,values in sorted(grouped.items())]
    distributed=[]
    for p in distributed_parcels:
        values=[]
        for key in ('qy','qz','y','z'):
            value=float(p[key])
            if not math.isfinite(value):raise ValueError('Nonfinite distributed dead-load parcel')
            values.append(value)
        qy,qz,y,z=values;value=math.fsum((qy*y,qz*z))
        if not math.isfinite(value):raise ValueError('Nonfinite distributed dead-load radius work')
        distributed.append(value)
    safe=all(r['radial_work_coefficient_nmm']>=0 for r in rows) and all(v>=0 for v in distributed)
    return dict(no_destabilizing_transverse_load_radius=safe,wheel_station_coefficients=rows,
        distributed_coefficients_n=distributed,case_id=case.id,source='Rigid-section dead-force second-variation derivation',
        factors_applied_once=True,beneficial_radius_credit_used=False,ordinary_torque_actions_not_removed=True,
        follower_or_unqualified_attachment_loads_covered=False)
