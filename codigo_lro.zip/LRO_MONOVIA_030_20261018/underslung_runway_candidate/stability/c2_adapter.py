"""Bounded supplementary EN2025 C.2 member checks for the autonomous model.

Not native NBR resistance; no whole-beam, support-connection, fatigue or contact
approval. Published interaction is used on extracted ideal fork segments. Actual
system actions are retained; no maxima are described as a concurrent tensor.
The action producer, not a string field, must substantiate its upper bounds.
"""
from dataclasses import dataclass,replace
import math
from copy import deepcopy
from .reference import model_station_constraints,first_order_axial_gate,warping_only_mcr
from ..section_stress.recovery import ISection,section_properties

SOURCE='DIN EN1993-1-1:2025 sections7.2.1(4)-(5),7.2.2(5),8.3.3(4),Tables7.3/7.4,8.7/8.8,AnnexC.2; explicitly adopted conservative extracted-member route'


def number(x,name,positive=False):
    if isinstance(x,bool) or not isinstance(x,(int,float)):
        raise ValueError(name+' must be finite real')
    try:valid=math.isfinite(x) and (not positive or x>0)
    except (OverflowError,ValueError):valid=False
    if not valid:raise ValueError(name+' outside numerical domain')
    return float(x)


def text(x,name):
    if not isinstance(x,str) or not x.strip():raise ValueError(name+' required')
    return x


@dataclass(frozen=True)
class Qualification:
    """Producer obligations. These declarations are NOT evidence by themselves."""
    case_id:str
    action_basis_source:str
    method_adoption_source:str
    bounds_are_upper:bool
    bounds_source:str
    torsion_mesh_qualified:bool
    no_destabilizing_transverse_load_radius:bool
    uniform_undistorted_thin_wall_i_adopted:bool
    structural_steel_ambient:bool
    producer_kind:str='analytical_upper'
    producer_receipt:dict|None=None

    def __post_init__(self):
        for key in ('case_id','action_basis_source','method_adoption_source','bounds_source'):
            text(getattr(self,key),key)
        for key in ('bounds_are_upper','torsion_mesh_qualified','no_destabilizing_transverse_load_radius',
                    'uniform_undistorted_thin_wall_i_adopted','structural_steel_ambient'):
            if type(getattr(self,key)) is not bool:raise ValueError(key+' must be explicit boolean')
        if self.producer_kind not in ('analytical_upper','fixed_FE_extrema_mesh_converged','fixed_FE_component_family_bounds_verified'):
            raise ValueError('Unrecognized internal response producer')
        if self.producer_receipt is not None and not isinstance(self.producer_receipt,dict):
            raise ValueError('Producer receipt must be a mapping')


def _producer_issues(q):
    if q.producer_kind=='fixed_FE_component_family_bounds_verified':
        r=q.producer_receipt or {};issues=[]
        if r.get('schema')!='LRO_VERIFIED_COMPONENT_FAMILY_BOX_V1' or r.get('evidence_kind')!=q.producer_kind:
            issues.append('Unverified component-family response producer.')
        if r.get('continuum_upper_bound_claimed') is not False or r.get('component_box_not_concurrent') is not True:
            issues.append('Family box scope is inconsistent.')
        if r.get('source_unchanged') is not True or r.get('all_basis_mesh_converged') is not True:
            issues.append('Family source/mesh receipt is incomplete.')
        evidence=r.get('basis_evidence',{})
        if not isinstance(evidence,dict) or not evidence:issues.append('No actual active-basis evidence.')
        else:
            for name,basis in evidence.items():
                v=basis.get('verification') or {}
                issues.extend(name+': '+x for x in _producer_issues(replace(q,producer_kind='fixed_FE_extrema_mesh_converged',producer_receipt=v.get('producer_receipt'))))
        return issues
    if q.producer_kind=='analytical_upper':
        return [] if q.bounds_are_upper else ['Analytical upper-bound producer is not qualified.']
    r=q.producer_receipt or {};issues=[]
    for flag in ('fixed_FE_extrema_verified','event_coverage_complete','spatial_coverage_complete','torsion_mesh_converged'):
        if r.get(flag) is not True:issues.append('Numerical producer receipt lacks '+flag)
    for key in ('input_signature','solver_source_hash','extrema_source_hash'):
        if not isinstance(r.get(key),str) or not r[key].strip():issues.append('Numerical producer receipt lacks '+key)
    try:
        tol=number(r['relative_tolerance'],'producer tolerance',True)
        if tol>.01:issues.append('Numerical producer tolerance exceeds this adopted 1% maximum.')
        history=r['mesh_history']
        if not isinstance(history,list) or len(history)<3:raise ValueError('Three or more mesh levels required')
        for row in history[-2:]:
            change=number(row['maximum_relative_change'],'mesh change')
            if change<0 or change>tol:issues.append('Numerical producer lacks two accepted consecutive mesh changes.')
        if type(r.get('stable_passes')) is not int or r['stable_passes']<2:issues.append('Two stable mesh passes required.')
    except (ValueError,KeyError,TypeError) as exc:issues.append('Numerical producer convergence receipt invalid: '+str(exc))
    return issues


def _extrema(segment,key,case_id):
    pair=segment['extrema'][key];rows=[]
    for edge in ('min','max'):
        row=pair[edge];value=number(row['value'],key+' '+edge)
        if row['case_id']!=case_id:raise ValueError('Mixed case identity in '+key)
        x=number(row['x_mm'],'extremum coordinate')
        if not segment['start_mm']<=x<=segment['end_mm']:raise ValueError('Extremum outside segment')
        if row['side'] not in ('left','right'):raise ValueError('Internal cut side required')
        if x==segment['start_mm'] and row['side']!='right':raise ValueError('Segment start must use interior right cut')
        if x==segment['end_mm'] and row['side']!='left':raise ValueError('Segment end must use interior left cut')
        number(row['translation_mm'],'wheel translation');rows.append(value)
    if rows[0]>rows[1]:raise ValueError('Reversed extrema in '+key)
    return tuple(rows)


def _chi_d(lam):
    # Algebraically stable curve d. Every lambda supplied is nonnegative.
    phi=.5*(1+.76*(lam-.2)+lam*lam)
    return min(1.,1/(phi+math.sqrt(max(0.,phi*phi-lam*lam))))


def _evaluate_segment(model,section,segment,qualification,*,E_mpa,nu,fy_mpa,resistance_gamma,
                     shear_upper_mpa=None,shear_bound_source=None,component_box=False):
    """Independent source check from one case's automatic segment extrema.

    Required extrema: N,My,Mz,B_equilibrated; signed physical +x convention.
    Optional shear bound must cover the WHOLE nominal cross-section, not only
    bottom-flange sample points. No missing shear is replaced by zero.
    """
    result=dict(kind='autonomous_supplementary_en2025_c2_family_box' if component_box else 'autonomous_supplementary_en2025_c2',source=SOURCE,checks=[],pending=[],
        member_stability_qualified=False,global_section_qualified=False,whole_beam_qualified=False,
        suspension_strength_qualified=False,fatigue_qualified=False,contact_qualified=False,
        limitations=['Supplementary explicitly adopted EN method, not native NBR resistance.',
          'All component maxima form a sufficient family bound, not one concurrent physical state.',
          'Actual frame N/M/B/end actions retained; slope/warping continuity released only in the elastic reference.',
          'Physical restraint stiffness/strength, local wheel effects, contact, web shear buckling, fatigue and service remain separate.'])
    try:
        if not isinstance(section,ISection) or not section.doubly_symmetric:raise ValueError('Doubly symmetric ISection required')
        if not isinstance(qualification,Qualification):raise ValueError('Qualification required')
        q=qualification
        E=number(E_mpa,'E',True);nu=number(nu,'nu');fy=number(fy_mpa,'fy',True);gamma=number(resistance_gamma,'resistance gamma',True)
        if gamma<1:raise ValueError('Adopted resistance margin must be >=1')
        props=section_properties(section,E,nu)
        for k,v in props['frame_section'].items():
            if k not in model.section or not math.isclose(model.section[k],v,rel_tol=1e-10):raise ValueError('Frame/section mismatch: '+k)
        a=number(segment['start_mm'],'segment start');b=number(segment['end_mm'],'segment end')
        if not 0<=a<b<=model.length:raise ValueError('Invalid physical segment')
        for x in (a,b):
            audit=model_station_constraints(model,x)
            if not (audit['model_fork'] and audit['vertical_supported']):result['pending'].append('No true ideal fork/vertical boundary at x='+str(x))
        if any(a<float(s['x'])<b for s in model.supports):
            result['pending'].append('Intermediate suspension within extracted segment: its reaction-height/support interaction is not qualified by this two-end route.')
        if any(v!=0 for v in model.prescribed):
            result['pending'].append('Prescribed nonzero support movement is outside this no-sway first-order route.')
        signed={key:(_signed_box(segment,key) if component_box else _extrema(segment,key,q.case_id)) for key in ('N','My','Mz','B_equilibrated')}
        Nabs=max(map(abs,signed['N']));Ncomp=max(0.,-signed['N'][0]);My=max(map(abs,signed['My']));Mz=max(map(abs,signed['Mz']));B=max(map(abs,signed['B_equilibrated']))
        A,Iy,Iz,J,Cw=(props[k] for k in ('A_mm2','Iy_mm4','Iz_mm4','J_mm4','Cw_mm6'))
        if Iy<Iz:raise ValueError('Current major-axis route requires Iy >= Iz')
        L=b-a;Wy=2*Iy/section.d_mm;Wz=2*Iz/section.bf_mm
        omega=section.bf_mm*(section.d_mm-section.tf_mm)/4
        gate=first_order_axial_gate(E_mpa=E,Imajor_mm4=Iy,Iminor_mm4=Iz,length_mm=L,compression_upper_n=Ncomp)
        if not gate['non_sway_flexural_first_order_sufficient']:
            result['pending'].append('Ncr/25 first-order flexural gate not met: qualified second-order/EM analysis required, not a declaration of collapse.')
        mcr=warping_only_mcr(E_mpa=E,Iweak_mm4=Iz,Cw_mm6=Cw,length_mm=L)['Mcr_lower_nmm']
        result['pending'].extend(_producer_issues(q))
        flags={'torsion_mesh_qualified':'Torsion mesh/recovery has no accepted convergence/enclosure.',
               'no_destabilizing_transverse_load_radius':'Destabilizing transverse dead-load radius terms Fy*y+Fz*z have not been excluded/bounded.',
               'uniform_undistorted_thin_wall_i_adopted':'Uniform undistorted thin-wall I model not adopted.',
               'structural_steel_ambient':'Ambient structural steel scope not qualified.'}
        for key,msg in flags.items():
            if not getattr(q,key):result['pending'].append(msg)
        if not 200<=fy<=700:result['pending'].append('Structural steel fy outside adopted 200–700 MPa scope.')
        eps=math.sqrt(235/fy);cf=(section.bf_mm-section.tw_mm)/(2*section.tf_mm);cw=(section.d_mm-2*section.tf_mm)/section.tw_mm
        # Uniform compression sufficient class gate; no guessed favorable N/M gradient.
        if cf>14*eps:result['pending'].append('Sufficient class1–3 flange gate not satisfied.')
        if cw>38*eps:result['pending'].append('Sufficient class1–3 web gate not satisfied; actual-gradient/effective-section route needed.')
        NR=A*fy;MRy=Wy*fy;MRz=Wz*fy;BR=Cw*fy/omega
        Ny=gate['Ncr_major_lower_n'];Nz=gate['Ncr_minor_lower_n'];NT=(props['G_mpa']*J+E*Cw*math.pi**2/L**2)/((Iy+Iz)/A)
        chiy=_chi_d(math.sqrt(NR/Ny));chiz=min(_chi_d(math.sqrt(NR/Nz)),_chi_d(math.sqrt(NR/NT)));chiLT=_chi_d(math.sqrt(MRy/mcr))
        if B/BR>.3:result['pending'].append('C.2 BEd/BRk <=0.30 domain exceeded.')
        ny=Ncomp/(chiy*NR/gamma);nz=Ncomp/(chiz*NR/gamma);my=My/(chiLT*MRy/gamma);mz=Mz/(MRz/gamma)
        kyy=1+.8*ny;kzz=1+1.4*nz;kyz=kzz;kzy=max(1.,.8*kyy);tor=1.4*B/(BR/gamma)
        u1=ny+kyy*my+kyz*mz+tor;u2=nz+kzy*my+kzz*mz+tor
        normal=Nabs/A+My/Wy+Mz/Wz+B*omega/Cw
        result['intermediates']=dict(first_order_gate=gate,section_signature=section.signature,case_id=q.case_id,
            start_mm=a,end_mm=b,N_abs_n=Nabs,N_compression_n=Ncomp,My_abs_nmm=My,Mz_abs_nmm=Mz,B_abs_nmm2=B,
            Mcr_lower_nmm=mcr,chi_major=chiy,chi_minor_torsional=chiz,chi_LT=chiLT,
            NRk_n=NR,MRy_nmm=MRy,MRz_nmm=MRz,BRk_nmm2=BR,bimoment_ratio=B/BR,
            ny=ny,nz=nz,my=my,mz=mz,kyy=kyy,kyz=kyz,kzy=kzy,kzz=kzz,torsion_term=tor,
            C1_upper=u1,C2_upper=u2,normal_stress_upper_mpa=normal,
            flange_c_over_t=cf,web_c_over_t=cw,flange_class3_limit=14*eps,web_class3_limit=38*eps,
            method_adoption=q.method_adoption_source,action_basis=q.action_basis_source,bounds_source=q.bounds_source)
        if component_box:
            result['intermediates']['family_id']=result['intermediates'].pop('case_id')
            result['concurrent_tensor_claimed']=False
            result['governing_physical_state_invented']=False
        result['response_producer']=dict(kind=q.producer_kind,continuum_upper_bound_claimed=q.producer_kind=='analytical_upper' and q.bounds_are_upper,
            numerical_engineering_not_continuum_enclosure=q.producer_kind in ('fixed_FE_extrema_mesh_converged','fixed_FE_component_family_bounds_verified'),
            receipt=deepcopy(q.producer_receipt))
        # Criteria are conditional diagnostics until every applicability gate is met.
        qualified=not result['pending']
        for id_,value in (('C1_major_interaction',u1),('C2_minor_interaction',u2)):
            result['checks'].append(dict(id=id_,demand=value,capacity=1.,utilization=value,
                qualified=qualified,status=('ATENDE' if value<=1 else 'INCONCLUSIVE_SUFFICIENT_BOUND') if qualified else 'PENDENTE',
                diagnostic_exceeds_limit=value>1,actual_failure_proven=False,criterion_is_sufficient_upper_bound=True,source=SOURCE))
        result['member_stability_qualified']=qualified
        if shear_upper_mpa is None:
            result['section_pending']='Whole-section nominal shear bound not supplied; no zero shear assumed.'
        else:
            tau=number(shear_upper_mpa,'whole-section shear upper',False)
            if tau<0:raise ValueError('Shear upper must be nonnegative')
            text(shear_bound_source,'shear bound source')
            equivalent=math.hypot(normal,math.sqrt(3)*tau);capacity=fy/gamma
            result['checks'].append(dict(id='global_elastic_section',demand=equivalent,capacity=capacity,utilization=equivalent/capacity,
                title='Whole nominal rectangular/thin-wall section: sufficient elastic equivalent-stress bound',
                actual_rolled_root_peak_qualified=False,contact_peak_qualified=False,
                stress_scope='Three-rectangle longitudinal/bending/warping normal stress and whole nominal shear-vector bound; not a resolved fillet/contact tensor.',
                qualified=qualified,status=('ATENDE' if equivalent<=capacity else 'INCONCLUSIVE_SUFFICIENT_BOUND') if qualified else 'PENDENTE',
                diagnostic_exceeds_limit=equivalent>capacity,actual_failure_proven=False,criterion_is_sufficient_upper_bound=True,source='EN2025 8.2.1(4)-(5); independent global nominal section bound',shear_bound_source=shear_bound_source))
            result['global_section_qualified']=qualified
        def finite(v):
            if isinstance(v,float):return math.isfinite(v)
            if isinstance(v,dict):return all(finite(x) for x in v.values())
            if isinstance(v,(list,tuple)):return all(finite(x) for x in v)
            return True
        if not finite(result):raise ValueError('Nonfinite derived C.2 result')
        result['input_valid']=True
        result['status']='CALCULATED_SUPPLEMENTARY_MEMBER' if qualified else 'PENDING_MEMBER_QUALIFICATION'
    except (ValueError,TypeError,OverflowError,ZeroDivisionError,KeyError,AttributeError) as exc:
        result.update(input_valid=False,status='INVALID_OR_UNSUPPORTED_INPUT',checks=[],member_stability_qualified=False,global_section_qualified=False,errors=[str(exc)])
    return result


def _signed_box(segment,key):
    row=segment['bounds'][key]
    if set(row)!={'lower','upper'}:raise ValueError('Plain signed family component interval required')
    lo=number(row['lower'],key+' lower');hi=number(row['upper'],key+' upper')
    if lo>hi:raise ValueError('Reversed family interval')
    return lo,hi


def evaluate_segment(model,section,segment,qualification,**kwargs):
    """Actual-case component extrema; exceeding a sufficient bound is inconclusive."""
    return _evaluate_segment(model,section,segment,qualification,**kwargs)


def evaluate_component_box(model,section,segment,qualification,**kwargs):
    """Dedicated nonconcurrent box arithmetic; no fictional event/governor rows.

    The high-level family_adapter must validate the full internally produced
    receipt, source/input binding and regenerated physical membership first.
    """
    return _evaluate_segment(model,section,segment,qualification,component_box=True,**kwargs)
