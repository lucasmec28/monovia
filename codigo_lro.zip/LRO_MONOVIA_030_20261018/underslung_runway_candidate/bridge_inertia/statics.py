"""Full force/moment transfer for an explicitly adopted equalized bridge model.

N, mm, kg, m/s2. Global x is runway travel, y goes between the rails,
z is upward from their common wheel-contact plane. Four carriage station
centres are (x=+/-a/2,y=0 or L,z=0), each split into two equal opposed
physical contacts (y=rail_y +/- contact_half_gauge). Every physical contact
has its own force vector. Contact sharing and absence of a diagonal corner
self-stress are MODEL ASSUMPTIONS, not consequences of rigid-body statics.

Gravity and HX/HY inertia remain separate parcels. A later action generator
must multiply each entire vector by the same factor/sign; it must never
reverse horizontal force without reversing its vertical redistribution.
There is no hardware traction, drive, skew, impact, fatigue or resistance
approval in this kernel. Negative/downward wheel force is normal loading;
positive/upward wheel force indicates that the adopted no-hold-down contact
model lifts off and is rejected for that case, not silently clipped.
"""
from dataclasses import dataclass,asdict
import math,hashlib,json


def real(x,name,positive=False):
    if isinstance(x,bool) or not isinstance(x,(int,float)) or abs(x)>1e15:
        raise ValueError(name+' must be finite real in the numerical domain')
    if not math.isfinite(x):raise ValueError(name+' must be finite real in the numerical domain')
    if positive and x<=0:raise ValueError(name+' must be positive')
    return float(x)


def text(x,name):
    if not isinstance(x,str) or not x.strip():raise ValueError(name+' provenance required')
    return x


@dataclass(frozen=True)
class PointMass:
    id:str
    kind:str  # equipment, removable lifted, or retained_lifted (SL/Q even when empty)
    mass_kg:float
    x_mm:float
    y_mm:float
    z_mm:float
    ax_m_s2:float
    ay_m_s2:float
    source:str
    def __post_init__(self):
        text(self.id,'Mass identity');text(self.source,'Mass/CG/acceleration')
        if self.kind not in ('equipment','lifted','retained_lifted'):raise ValueError('Unknown mass kind')
        for key in ('mass_kg','x_mm','y_mm','z_mm','ax_m_s2','ay_m_s2'):
            object.__setattr__(self,key,real(getattr(self,key),key))
        if self.mass_kg<0:raise ValueError('Mass cannot be negative')



LEGACY_MASS_CONVENTION = 'legacy_all_lifted_removed_when_empty'
SEPARATE_MASS_CONVENTION = 'payload_plus_retained_suspended_mass'
MASS_ACCOUNTING_FIELDS = ('mass_accounting_convention','retained_suspended_mass_kg',
    'retained_suspended_cg_x_mm','retained_suspended_cg_z_mm',
    'retained_mass_excluded_from_equipment','suspended_mass_source')


def validate_suspended_mass_accounting(p):
    """Shared four-origin contract. Missing legacy B is UNKNOWN, not sourced zero."""
    convention=p.mass_accounting_convention
    if convention not in (LEGACY_MASS_CONVENTION,SEPARATE_MASS_CONVENTION):
        raise ValueError('Unknown suspended mass accounting convention')
    if convention==LEGACY_MASS_CONVENTION:
        if any(getattr(p,k) is not None for k in MASS_ACCOUNTING_FIELDS[1:-1]) or p.suspended_mass_source:
            raise ValueError('Legacy accounting cannot silently consume retained-mass inputs; choose payload_plus_retained_suspended_mass')
        return p
    mass=real(p.retained_suspended_mass_kg,'Explicit retained suspended mass')
    if mass<0:raise ValueError('Retained suspended mass must be nonnegative, including an explicit sourced zero')
    if p.retained_mass_excluded_from_equipment is not True:
        raise ValueError('Retained suspended mass must be identified separately from bridge/trolley equipment; no double counting')
    text(p.suspended_mass_source,'Retained suspended mass/CG accounting')
    coordinates=(p.retained_suspended_cg_x_mm,p.retained_suspended_cg_z_mm)
    if p.transfer_model=='free_suspended_at_crab':
        if any(v is not None for v in coordinates):raise ValueError('Free-rope retained mass uses the declared crab point, not a separate CG')
    elif mass>0:
        for value,name in zip(coordinates,('retained suspended CG x','retained suspended CG z')):real(value,name)
    else:
        for value in coordinates:
            if value is not None:real(value,'zero-mass retained CG')
    return p


def suspended_mass_accounting(p):
    validate_suspended_mass_accounting(p)
    explicit=p.mass_accounting_convention==SEPARATE_MASS_CONVENTION
    retained=p.retained_suspended_mass_kg if explicit else None
    return dict(convention=p.mass_accounting_convention,retained_mass_explicit=explicit,
        complete_suspended_mass_accounting=explicit,retained_suspended_mass_kg=retained,
        removable_loaded_mass_kg=1000*p.capacity_t,
        loaded_suspended_mass_kg=1000*p.capacity_t+retained if explicit else None,
        empty_suspended_mass_kg=retained,
        retained_gravity_action_kind='SL/Q, never permanent equipment G',
        legacy_scope=None if explicit else 'Historical arithmetic removes the whole declared lifted parcel at empty operation; retained block/accessory mass remains unspecified, not established zero.',
        source=p.suspended_mass_source if explicit else None)


def serialize_mass_inputs(p):
    """Keep legacy persisted physical ledgers byte-compatible, not re-signed."""
    payload=asdict(p)
    if p.mass_accounting_convention==LEGACY_MASS_CONVENTION:
        for key in MASS_ACCOUNTING_FIELDS:payload.pop(key,None)
    return payload


def retained_point_mass(p,hook_mm):
    validate_suspended_mass_accounting(p)
    if p.mass_accounting_convention==LEGACY_MASS_CONVENTION:return None
    free=p.transfer_model=='free_suspended_at_crab';mass=p.retained_suspended_mass_kg
    x=p.suspension_point_x_mm if free else p.retained_suspended_cg_x_mm
    z=p.suspension_point_z_mm if free else p.retained_suspended_cg_z_mm
    if mass==0 and not free:x=0. if x is None else x;z=0. if z is None else z
    return PointMass('retained_suspended','retained_lifted',mass,x,hook_mm,z,
                     p.bridge_acceleration_m_s2,p.trolley_acceleration_m_s2,p.suspended_mass_source)

def _cross(r,F):
    x,y,z=r;fx,fy,fz=F
    return [y*fz-z*fy,z*fx-x*fz,x*fy-y*fx]


def _resultant(loads):
    force=[math.fsum(p['force_N'][j] for p in loads) for j in range(3)]
    moment=[math.fsum(_cross(p['position_mm'],p['force_N'])[j] for p in loads) for j in range(3)]
    return dict(force_N=force,moment_Nmm=moment)


def _compare(actual,expected):
    residual={key:[a-b for a,b in zip(actual[key],expected[key])] for key in actual}
    # A vector norm scale also covers roundoff in nominally zero components.
    for key,values in residual.items():
        scale=max(1.,*(abs(v) for v in actual[key]),*(abs(v) for v in expected[key]))
        if max(map(abs,values))>2e-11*scale:raise ArithmeticError('Force/moment equilibrium failed: '+key)
    return dict(expected=expected,actual=actual,residual=residual,balanced=True)


def generate(masses,*,rail_span_mm,station_spacing_mm,contact_half_gauge_mm,
             model_source,equalized_model_adopted,horizontal_dynamic_factor=1.,gravity_m_s2=9.80665):
    """Generate physical eight-wheel actions and full 3-D equilibrium receipts.

    Positive interpolation weights require every CG to lie within the four
    carriage-centre support rectangle. z may be negative (suspended) or positive.
    The stated diagonal load-sharing choice is bilinear for gravity/in-plane
    inertia and zero extra diagonal self-stress for overturning parcels.
    """
    L=real(rail_span_mm,'Rail span',True);a=real(station_spacing_mm,'Station spacing',True)
    b=real(contact_half_gauge_mm,'Opposed contact half-gauge',True)
    k=real(horizontal_dynamic_factor,'Horizontal dynamic factor',True);g=real(gravity_m_s2,'Gravity',True)
    if k<1:raise ValueError('Horizontal dynamic factor cannot reduce inertia')
    if 2*b>=L:raise ValueError('Opposed contact envelopes overlap across rails')
    text(model_source,'Equalized transfer model')
    if equalized_model_adopted is not True:raise ValueError('Explicit equalized model adoption required')
    masses=tuple(masses)
    if not masses or any(not isinstance(m,PointMass) for m in masses):raise ValueError('Explicit physical point masses required')
    if len({m.id for m in masses})!=len(masses):raise ValueError('Duplicated mass identity')
    for m in masses:
        if not -a/2<=m.x_mm<=a/2 or not 0<=m.y_mm<=L:raise ValueError('CG outside equalized support rectangle')
    contacts=[]
    for sx in (-1,1):
        for iy in (0,1):
            for sy in (-1,1):
                contacts.append(dict(id=f'{"rear" if sx<0 else "front"}/rail{iy}/{"left" if sy<0 else "right"}',
                    position_mm=[sx*a/2,iy*L+sy*b,0.],station_sign=sx,rail_index=iy,outstand_sign=sy))
    parcels=[];receipts=[]
    for m in masses:
        source_position=[m.x_mm,m.y_mm,m.z_mm]
        source_vectors={'gravity':[0.,0.,-m.mass_kg*g],
                        'HX':[-m.mass_kg*m.ax_m_s2*k,0.,0.],
                        'HY':[0.,-m.mass_kg*m.ay_m_s2*k,0.]}
        for action,F in source_vectors.items():
            M=_cross(source_position,F);loads=[]
            for c in contacts:
                sx=c['station_sign'];iy=c['rail_index'];sy=2*iy-1
                wx=.5+sx*m.x_mm/a;wy=(m.y_mm/L if iy else 1-m.y_mm/L)
                share=wx*wy/2
                f=[F[j]*share for j in range(3)]
                if action!='gravity':
                    # Only z-height induced overturning, not the full M from
                    # horizontal positions (yaw is carried by in-plane shares).
                    mx_height=-m.z_mm*F[1];my_height=m.z_mm*F[0]
                    f[2]+=(sy*mx_height/(2*L)-sx*my_height/(2*a))/2
                if not all(math.isfinite(v) for v in f):raise ValueError('Nonfinite transferred force')
                loads.append(dict(contact_id=c['id'],position_mm=c['position_mm'],force_N=f))
            expected=dict(force_N=F,moment_Nmm=M)
            receipts.append(dict(mass_id=m.id,action=action,**_compare(_resultant(loads),expected)))
            parcels.append(dict(mass_id=m.id,kind=m.kind,action=action,source=m.source,source_position_mm=source_position,
                                source_force_N=F,loads=loads))
    inputs=dict(masses=[asdict(m) for m in masses],rail_span_mm=L,station_spacing_mm=a,contact_half_gauge_mm=b,
                model_source=model_source,equalized_model_adopted=True,horizontal_dynamic_factor=k,gravity_m_s2=g)
    digest=hashlib.sha256(json.dumps(inputs,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
    return dict(schema='equalized_bridge_correlated_inertia_v2' if any(m.kind=='retained_lifted' for m in masses) else 'equalized_bridge_correlated_inertia_v1',inputs=inputs,input_signature=digest,
        contacts=contacts,parcels=parcels,equilibrium=receipts,statics_balanced=True,
        physical_drive_or_equalizer_qualified=False,external_efforts_required=False,
        scope='Declared bilinear/equalized force-transfer model only; zero added diagonal overturning self-stress.',
        coordinate_system='x longitudinal; y from rail0 to rail1; z up relative to common contact plane')


def combine(generated,*,equipment_factor,lifted_factor,hx_multiplier,hy_multiplier,loaded,retained_lifted_factor=None):
    """Apply correlated parcels, check complete-case equilibrium and contact.

    H multipliers already include their chosen code factor and sign; they scale
    corresponding vertical inertia parcels as well. No positive-force clipping.
    """
    if type(loaded) is not bool:raise ValueError('Loaded state must be boolean')
    factors={name:real(value,name) for name,value in [('equipment',equipment_factor),('lifted',lifted_factor),('HX',hx_multiplier),('HY',hy_multiplier)]}
    factors['retained_lifted']=factors['lifted'] if retained_lifted_factor is None else real(retained_lifted_factor,'retained lifted factor')
    if min(factors['equipment'],factors['lifted'],factors['retained_lifted'])<0:raise ValueError('Gravity factors must be nonnegative')
    by_id={p['id']:dict(contact_id=p['id'],position_mm=p['position_mm'],force_N=[0.,0.,0.]) for p in generated['contacts']}
    terms={ident:[[],[],[]] for ident in by_id}
    source=[]
    for parcel in generated['parcels']:
        if parcel['kind']=='lifted' and not loaded:continue
        factor=factors[parcel['kind']] if parcel['action']=='gravity' else factors[parcel['action']]
        source.append(dict(position_mm=parcel['source_position_mm'],force_N=[factor*v for v in parcel['source_force_N']]))
        for p in parcel['loads']:
            target=terms[p['contact_id']]
            for j in range(3):target[j].append(factor*p['force_N'][j])
    for ident,parts in terms.items():by_id[ident]['force_N']=[math.fsum(v) for v in parts]
    loads=list(by_id.values());receipt=_compare(_resultant(loads),_resultant(source))
    allowances={ident:64*math.ulp(max(1.,math.fsum(abs(v) for v in parts[2]))) for ident,parts in terms.items()}
    uplift=[p['contact_id'] for p in loads if p['force_N'][2]>allowances[p['contact_id']]]
    return dict(loads=loads,equilibrium=receipt,uplift_contacts=uplift,
        no_hold_down_contact_valid=not uplift,contact_status='UPLIFT_OUTSIDE_DOMAIN' if uplift else 'COMPRESSIVE_CONTACT_MODEL',
        vertical_roundoff_allowance_N=allowances,case_factors=factors,loaded=loaded,input_signature=generated['input_signature'],
        physical_drive_or_equalizer_qualified=False)
