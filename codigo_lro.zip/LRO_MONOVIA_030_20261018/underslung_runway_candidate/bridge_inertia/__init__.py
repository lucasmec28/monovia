"""Declared equalized rigid-bridge statics, separate from drive qualification."""
