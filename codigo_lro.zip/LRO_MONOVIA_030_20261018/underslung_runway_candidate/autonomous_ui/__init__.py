"""Isolated physical-input UI and report adapters; no production route changes."""
