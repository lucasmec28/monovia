"""Bounded, physical-only persistence for the autonomous underslung form.

A document is a draft of declarations, never a calculation receipt or approval.
Loading does not call a solver, certify declarations, or trust saved results.
"""
from __future__ import annotations

from copy import deepcopy
import json
import math
import re

from ..autonomous_workflow.model import checked_text

FORMAT = 'LRO_AUTONOMOUS_UNDERSLUNG_PHYSICAL_PROJECT'
VERSION = 1
ROUTE = 'underslung_runway_autonomous'
MAX_BYTES = 8 * 1024 * 1024
MAX_DEPTH = 48
MAX_NODES = 250_000
STATE_KEY = 'underslung_autonomous_physical_inputs'
REVISION_KEY = 'underslung_autonomous_form_revision'
RESULT_KEYS = ('underslung_autonomous_result', 'underslung_autonomous_family')
SOURCE_MODES = ('Informado pelo usuário', 'Catálogo de referência', 'Premissa adotada')


class ProjectDocumentError(ValueError):
    """An unsafe, unrecognized or malformed physical document."""


def _fail(path, detail):
    raise ProjectDocumentError(f'{path}: {detail}')


def _safe_tree(value):
    """Also inspect ignored legacy receipts: unsafe text must never enter UI/XML."""
    stack = [(value, 0)]
    nodes = 0
    while stack:
        item, depth = stack.pop()
        nodes += 1
        if nodes > MAX_NODES or depth > MAX_DEPTH:
            _fail('JSON', 'estrutura excede o limite seguro de tamanho/profundidade.')
        if isinstance(item, dict):
            for key, child in item.items():
                if not isinstance(key, str):
                    _fail('JSON', 'nomes de campos devem ser texto.')
                checked_text(key, 'Nome de campo JSON', required=False)
                stack.append((child, depth + 1))
        elif isinstance(item, list):
            stack.extend((child, depth + 1) for child in item)
        elif isinstance(item, str):
            checked_text(item, 'Texto JSON', required=False)
        elif type(item) in (int, float):
            try:
                finite = math.isfinite(item)
            except OverflowError:
                finite = False
            if not finite:
                _fail('JSON', 'números devem ser finitos.')
        elif item is not None and type(item) is not bool:
            _fail('JSON', 'tipo não permitido.')


def _unique_object(pairs):
    value = {}
    for key, child in pairs:
        if key in value:
            _fail('JSON', 'campos duplicados não são permitidos.')
        value[key] = child
    return value


def _reject_constant(value):
    _fail('JSON', 'NaN e infinito não são permitidos.')


def _decode(data):
    if not isinstance(data, (str, bytes, bytearray)):
        _fail('Arquivo', 'forneça texto ou bytes JSON UTF-8.')
    try:
        size = len(data.encode('utf-8')) if isinstance(data, str) else len(data)
        if size > MAX_BYTES:
            _fail('Arquivo', 'JSON excede o limite de 8 MiB.')
        text = data if isinstance(data, str) else bytes(data).decode('utf-8')
    except UnicodeError:
        _fail('Arquivo', 'texto UTF-8/Unicode inválido.')
    # Bound nesting before json.loads, including malicious deeply nested arrays.
    depth = 0
    quoted = escaped = False
    for char in text:
        if quoted:
            if escaped:
                escaped = False
            elif char == '\\':
                escaped = True
            elif char == '"':
                quoted = False
        elif char == '"':
            quoted = True
        elif char in '[{':
            depth += 1
            if depth > MAX_DEPTH:
                _fail('JSON', 'profundidade excede o limite seguro.')
        elif char in ']}':
            depth -= 1
    try:
        value = json.loads(text, object_pairs_hook=_unique_object, parse_constant=_reject_constant)
        _safe_tree(value)
    except ProjectDocumentError:
        raise
    except (ValueError, TypeError, RecursionError, OverflowError) as exc:
        raise ProjectDocumentError('JSON inválido ou texto Unicode/XML não permitido: ' + str(exc)) from None
    return value


def _schema():
    # Local form contracts only. In particular this module does not import TOP.
    from . import ui
    from . import family_inputs as family
    template = ui.blank_inputs()
    template['contact_common_wheel'] = ui.blank_contact_wheel()
    template['document_metadata'] = {}
    enums = {
        'identity': ('actual_project', 'synthetic_fixture'),
        'action_input_route': (ui.INERTIA_ROUTE, ui.BRIDGE_ROUTE, ui.MANUAL_ROUTE),
        'extra_dead_kind': ('steel_or_equipment', 'precast_or_timber', 'cast_in_place_or_permanent_thrust', 'industrial_with_in_situ_additions', 'general_construction'),
        'actions.equipment_group': tuple(f'A{i}' for i in range(1, 9)),
        'inertia_inputs.transfer_model': tuple(ui.INERTIA_TRANSFER_MODELS),
        'inertia_inputs.mass_accounting_convention': tuple(ui.COMMON_MASS_CONVENTIONS),
        'en_fatigue_inputs.vertical_operating_model': tuple(ui.FATIGUE_VERTICAL_MODELS),
        'cmaa_mass_accounting.capacity_basis': tuple(family.CMAA_CAPACITY_LABELS),
        'inertia_inputs.retained_mass_excluded_from_equipment': (True,),
        'cmaa_mass_accounting.retained_mass_excluded_from_equipment': (True,),
        'contact_inputs.schema': (ui.blank_contact_inputs()['schema'],),
        'contact_inputs.operating.operating_domain': (ui.CONTACT_OPERATING_DOMAIN,),
        'contact_inputs.operating.hoist_mass_scope': (ui.CONTACT_MASS_SCOPE,),
        'contact_inputs.flange.material_state': ('non_surface_hardened',),
        'service_inputs.operating_domain': (ui.SERVICE_DOMAIN,),
        'service_inputs.hoist_mass_scope': (ui.CONTACT_MASS_SCOPE,),
    }
    for name in ('bridge', 'fatigue', 'contact', 'service'):
        enums[name + '_source_mode'] = SOURCE_MODES
    for name, (token, _) in ui.FATIGUE_ENUMS.items():
        enums['en_fatigue_inputs.' + name] = (token,)
    for group, fields in (('native_service_inputs', family.NATIVE_ENUMS), ('cmaa_physical_inputs', family.CMAA_ENUMS), ('nbr_rolling_guidance', family.ROLLING_GUIDANCE_LABELS)):
        for name, (_, choices) in fields.items():
            enums[group + '.' + name] = tuple(choices)
    # String-only declaration vocabulary from the existing shared NBR form.
    # No TOP implementation or numerical consumer is imported for persistence.
    nbr = dict(material_grade=('S235', 'S275', 'ASTM A36', 'S355', 'ASTM A572 GR50'),
        component_group=tuple(f'E{i}' for i in range(1, 9)),
        classification_kind=('documented_component_classification', 'adopted_conservative_E8', 'manual_code_selection'),
        construction_detail=('W0_plain_rolled_unnotched',),
        fabrication_requirement=('specified_h6', 'specified_h6_qc'),
        evaluation_location=('base_material',),
        kappa_policy=('explicit_kappa_minus_one_resistance_reduction',))
    enums.update({'nbr_fatigue_inputs.' + key: values for key, values in nbr.items()})
    support = dict(id='', x_mm=None, y_mm=None, **{d: ui.UNSELECTED for d in ui.DOFS}, provenance='')
    wheel = dict(id='', offset_mm=None, outstand_side=ui.UNSELECTED, edge_to_contact_n_mm=None,
        dead_N=None, lifted_N=None, longitudinal_N=None, transverse_N=None,
        provenance='', point_force_transfer_adopted=False)
    enums.update({'supports[].' + dof: (ui.UNSELECTED, ui.FREE, ui.FIXED) for dof in ui.DOFS})
    enums['wheels[].outstand_side'] = (ui.UNSELECTED, 'left', 'right')
    for group in ('contact_common_wheel', 'contact_inputs.wheels[]'):
        enums[group + '.material_state'] = ('non_surface_hardened',)
        enums[group + '.mounting'] = tuple(ui.CONTACT_MOUNTINGS)
        enums[group + '.tolerance_class'] = (1, 2, 3, 4)
    optional_bools = {
        'service_inputs.lateral_project_limit_adopted',
        *(group + '.' + key for group in ('contact_common_wheel', 'contact_inputs.wheels[]') for key in ('driven_wheel', 'abrasive_environment')),
    }
    lists = {'supports': (support, 101), 'wheels': (wheel, 128), 'contact_inputs.wheels': (ui.blank_contact_wheel(), 128)}
    return template, enums, optional_bools, lists


def validate_physical_inputs(payload):
    """Validate storage types without filling physical unknowns or running FE.

    Numeric strings are kept verbatim so an unfinished form roundtrips. Physical
    applicability/completeness remains the responsibility of existing validators.
    """
    from .ui import number
    from lro_beams.document_metadata import validate_document_metadata
    try:
        _safe_tree(payload)
    except (ValueError, TypeError, ArithmeticError) as exc:
        raise ProjectDocumentError(str(exc)) from None
    template, enums, optional_bools, lists = _schema()
    if not isinstance(payload, dict):
        _fail('Entradas', 'objeto de dados físicos obrigatório.')
    required = {'identity', 'action_input_route', 'section', 'material', 'supports', 'wheels'}
    if not required <= set(payload):
        _fail('Entradas', 'identidade, rota e grupos físicos da viga suspensa obrigatórios.')

    def walk(value, model, path):
        if path == 'beam_support_physical_inputs':
            from .support_inputs import validate_beam_support_draft
            return validate_beam_support_draft(value)
        if path == 'document_metadata':
            validate_document_metadata(value)
            return deepcopy(value)
        if path == 'bridge_application':
            if value is None:
                return None
            if not isinstance(value, dict) or set(value) != {'configuration_id', 'input_signature'}:
                _fail(path, 'somente seleção e assinatura das entradas físicas são aceitas.')
            if not isinstance(value['configuration_id'], str) or not value['configuration_id']:
                _fail(path, 'identidade de configuração deve ser texto.')
            if not isinstance(value['input_signature'], str) or not re.fullmatch(r'[a-f0-9]{64}', value['input_signature']):
                _fail(path, 'assinatura física inválida.')
            return deepcopy(value)
        if path in enums:
            choices = enums[path]
            if value is None or (type(value) is str and value == ''):
                if (value is None and model is None) or (value == '' and model == ''):
                    return value
                _fail(path, 'opção não informada deve usar o marcador previsto no formulário.')
            if not any(type(value) is type(choice) and value == choice for choice in choices):
                _fail(path, 'opção não reconhecida.')
            return value
        if path in optional_bools:
            if value is not None and type(value) is not bool:
                _fail(path, 'deve ser booleano ou não informado.')
            return value
        if isinstance(model, dict):
            if not isinstance(value, dict) or set(value) - set(model):
                _fail(path or 'Entradas', 'somente os campos físicos reconhecidos são aceitos; nenhum esforço ou comprovante externo.')
            result = {}
            for key, child in model.items():
                child_path = (path + '.' if path else '') + key
                if key not in value:
                    if not path and key in ('document_metadata', 'contact_common_wheel'):
                        continue
                    # Absent legacy fields remain unknown, not their form defaults.
                    result[key] = missing(child, child_path)
                else:
                    result[key] = walk(value[key], child, child_path)
            return result
        if isinstance(model, list):
            row, limit = lists[path]
            if not isinstance(value, list) or len(value) > limit:
                _fail(path, 'lista inválida ou quantidade acima do limite.')
            return [walk(child, row, path + '[]') for child in value]
        if type(model) is bool:
            if type(value) is not bool:
                _fail(path, 'deve ser booleano explícito.')
        elif isinstance(model, str):
            if not isinstance(value, str):
                _fail(path, 'deve ser texto.')
        elif path.startswith(('supports[].', 'wheels[].')) and value is not None and type(value) not in (int, float):
            _fail(path, 'a célula numérica deve conter número JSON ou null.')
        elif value is not None and value != '':
            if type(value) not in (str, int, float):
                _fail(path, 'deve ser número, texto numérico ou não informado.')
            # This explicit incomplete contact-form marker cannot become a number.
            if path in ('contact_common_wheel.crown_radius_mm', 'contact_inputs.wheels[].crown_radius_mm') and value == 'FORMA_NAO_DECLARADA':
                return value
            number(value, path)
        return deepcopy(value)

    def missing(model, path):
        if path == 'beam_support_physical_inputs':
            from .support_inputs import blank_beam_support_inputs
            return blank_beam_support_inputs()
        if isinstance(model, dict):
            return {key: missing(child, path + '.' + key) for key, child in model.items()}
        if isinstance(model, list):
            return []
        if path == 'contact_inputs.schema':
            return model  # Format tag only, no physical assumption.
        if type(model) is bool:
            return False
        if isinstance(model, str):
            return model if path.startswith(('supports[].', 'wheels[].')) and path in enums else ''
        return None

    try:
        return walk(payload, template, '')
    except ProjectDocumentError:
        raise
    except (ValueError, TypeError, ArithmeticError) as exc:
        raise ProjectDocumentError(str(exc)) from None


def project_document(payload):
    return dict(format=FORMAT, version=VERSION, route=ROUTE, inputs=validate_physical_inputs(payload))


def dumps_project_document(payload):
    data = json.dumps(project_document(payload), ensure_ascii=False, indent=2, allow_nan=False)
    if len(data.encode('utf-8')) > MAX_BYTES:
        _fail('Arquivo', 'JSON excede o limite de 8 MiB.')
    return data


def loads_project_document(data):
    """Recognize only this physical format or the two actual UI export envelopes."""
    raw = _decode(data)
    if not isinstance(raw, dict):
        _fail('Arquivo', 'o documento deve ser um objeto JSON identificado.')
    if set(raw) == {'format', 'version', 'route', 'inputs'}:
        if raw['format'] != FORMAT or type(raw['version']) is not int or raw['version'] != VERSION or raw['route'] != ROUTE:
            _fail('Arquivo', 'formato, versão ou rota não reconhecido para a viga suspensa.')
        payload = raw['inputs']
    elif set(raw) in ({'payload', 'result', 'controls'}, {'payload', 'result', 'request_signature'}):
        family = 'controls' in raw
        expected = 'LRO_AUTONOMOUS_UNDERSLUNG_' + ('FAMILY_ANALYSIS' if family else 'ANALYSIS')
        result = raw['result']
        if not isinstance(result, dict) or result.get('format') != expected or type(result.get('version')) is not int or result['version'] != 1:
            _fail('Arquivo', 'exportação legada não reconhecida desta rota.')
        if family:
            controls = raw['controls']
            if not isinstance(controls, dict) or set(controls) != {'max_refinements', 'max_mesh_refinements'} or any(type(v) is not int for v in controls.values()):
                _fail('Arquivo', 'controles do envelope legado não reconhecidos.')
        elif not isinstance(raw['request_signature'], str) or not re.fullmatch(r'[a-f0-9]{64}', raw['request_signature']):
            _fail('Arquivo', 'assinatura do envelope legado inválida.')
        payload = raw['payload']
    else:
        _fail('Arquivo', 'envelope não reconhecido; use um projeto físico suspenso ou exportação legada identificada.')
    return validate_physical_inputs(payload)


def apply_project_import(state, data):
    """All parsing finishes before any mutation; never restore a result cache."""
    payload = loads_project_document(data)
    revision = state.get(REVISION_KEY, 0) + 1
    state[STATE_KEY] = payload
    state[REVISION_KEY] = revision
    for key in RESULT_KEYS:
        state.pop(key, None)
    return deepcopy(payload)
