"""Explicit payload/retained-block accounting for a private CMAA action project.

The user's nominal payload is never silently relabelled as CMAA LL. A private,
regenerated project is produced only after the mass convention is declared.
This module contains no resistance criteria or automatic equipment dimensions.
"""
from copy import deepcopy
from dataclasses import asdict, replace
from math import fsum
from ..autonomous_workflow.model import PhysicalWheel, checked_text, signature
from ..autonomous_workflow.project import project_from_dict
from ..autonomous_workflow.inertia_bridge_adapter import from_dict, make_ledger
from ..cmaa74.actions import CMAA74PhysicalInputs
from ..bridge_inertia.statics import SEPARATE_MASS_CONVENTION, LEGACY_MASS_CONVENTION

PAYLOAD = 'rated_payload_excludes_retained_suspended_mass'
TOTAL_LL = 'loaded_LL_total_includes_retained_suspended_mass'


def prepare_cmaa74_action_project(project, physical, *, capacity_basis,
        mass_accounting_source, retained_mass_excluded_from_equipment):
    """Return a four-origin physical project without changing the original.

    New convention: capacity is payload, B is a separate suspended working-load
    parcel retained when empty. A legacy declared total-LL input can be split
    only by the explicitly supplied B mass/point and exact first-moment balance.
    B never becomes equipment G and is never added twice.
    """
    project.validate()
    if not isinstance(physical, CMAA74PhysicalInputs):
        raise ValueError('Typed CMAA physical operating inputs required')
    physical.validate()
    if capacity_basis not in (PAYLOAD, TOTAL_LL):
        raise ValueError('Declare whether nominal capacity is payload or total loaded CMAA LL')
    checked_text(mass_accounting_source, 'Payload and retained suspended mass accounting source')
    if retained_mass_excluded_from_equipment is not True:
        raise ValueError('Identify retained suspended mass separately from bridge and trolley masses; double counting is not permitted')
    ledger = project.bridge_reaction_ledger
    if not isinstance(ledger, dict) or ledger.get('schema') != 'LRO_BOUND_BRIDGE_INERTIA_LEDGER_V1':
        raise ValueError('A bound physical inertia bridge ledger is required; external wheel efforts cannot establish mass accounting')
    original = signature(project.to_dict())
    p = from_dict(ledger['inputs'])
    retained = physical.empty_suspended_mass_kg
    nominal_mass = p.capacity_t * 1000.
    if p.transfer_model == 'free_suspended_at_crab' and (
            physical.empty_suspended_cg_x_mm is not None or physical.empty_suspended_cg_z_mm is not None):
        raise ValueError('Free-suspended retained mass uses the declared crab point, not a separate payload CG')
    updates = dict(mass_accounting_convention=SEPARATE_MASS_CONVENTION,
        retained_suspended_mass_kg=retained,
        retained_suspended_cg_x_mm=physical.empty_suspended_cg_x_mm,
        retained_suspended_cg_z_mm=physical.empty_suspended_cg_z_mm,
        retained_mass_excluded_from_equipment=True,suspended_mass_source=mass_accounting_source)
    if p.mass_accounting_convention == SEPARATE_MASS_CONVENTION:
        if capacity_basis != PAYLOAD:
            raise ValueError('The common four-origin convention defines capacity as payload, not loaded total LL')
        expected = (p.retained_suspended_mass_kg,p.retained_suspended_cg_x_mm,p.retained_suspended_cg_z_mm)
        supplied = (retained,physical.empty_suspended_cg_x_mm,physical.empty_suspended_cg_z_mm)
        if expected != supplied:
            raise ValueError('CMAA retained mass/CG differs from the shared physical equipment inputs')
        private_inputs = p
        payload_mass = nominal_mass
    elif capacity_basis == PAYLOAD:
        payload_mass = nominal_mass
        private_inputs = replace(p, **updates)
    else:
        payload_mass = nominal_mass-retained
        if payload_mass <= 0.:
            raise ValueError('Legacy total LL conversion requires a positive separately identified payload')
        updates['capacity_t'] = payload_mass/1000.
        if p.transfer_model == 'guided_rigid_payload_cg' and retained:
            if physical.empty_suspended_cg_x_mm is None or physical.empty_suspended_cg_z_mm is None:
                raise ValueError('Guided retained suspended mass requires its own physical x/z CG')
            a,b = nominal_mass/payload_mass,retained/payload_mass
            updates.update(lifted_cg_x_mm=fsum((a*p.lifted_cg_x_mm,-b*physical.empty_suspended_cg_x_mm)),
                lifted_cg_z_min_mm=fsum((a*p.lifted_cg_z_min_mm,-b*physical.empty_suspended_cg_z_mm)),
                lifted_cg_z_max_mm=fsum((a*p.lifted_cg_z_max_mm,-b*physical.empty_suspended_cg_z_mm)))
        private_inputs = replace(p, **updates)
    total = fsum((payload_mass,retained))
    new_ledger = make_ledger(project.section, asdict(private_inputs), ledger['selected_configuration_id'])
    raw = deepcopy(project.to_dict())
    raw['capacity_tf'] = private_inputs.capacity_t
    raw['bridge_reaction_ledger'] = new_ledger
    raw['wheels'] = deepcopy(new_ledger['selected_configuration']['wheels'])
    private = project_from_dict(raw)
    if original != signature(project.to_dict()):
        raise ValueError('Original physical project changed during conversion')
    changes = {key:dict(original=asdict(p)[key],cmaa=asdict(private_inputs)[key])
               for key in asdict(p) if asdict(p)[key] != asdict(private_inputs)[key]}
    receipt = dict(schema='LRO_EXPLICIT_CMAA_LL_MASS_ACCOUNTING_V2',
        original_project_signature=original, cmaa_project_signature=signature(private.to_dict()),
        physical_inputs_signature=signature(asdict(physical)), capacity_basis=capacity_basis,
        original_nominal_mass_kg=nominal_mass, loaded_CMAA_LL_mass_kg=total,
        retained_empty_suspended_mass_kg=retained,
        variable_payload_mass_kg=payload_mass,
        retained_mass_excluded_from_equipment=True, mass_accounting_source=mass_accounting_source,
        input_changes=changes, same_mechanical_geometry=True,
        loaded_mass_transfer='Four independent source parcels; retained B remains suspended working load. Legacy total LL is split by exact first-moment balance; free rope uses its declared crab point.',
        original_project_unchanged=True, actual_equipment_confirmation=False)
    receipt['receipt_signature'] = signature(receipt)
    return private, receipt


def validate_cmaa74_action_conversion(project, physical, private, receipt):
    if not isinstance(receipt,dict) or receipt.get('receipt_signature') != signature({k:v for k,v in receipt.items() if k!='receipt_signature'}):
        raise ValueError('Changed or missing CMAA mass-accounting receipt')
    regenerated, expected = prepare_cmaa74_action_project(project,physical,
        capacity_basis=receipt.get('capacity_basis'), mass_accounting_source=receipt.get('mass_accounting_source'),
        retained_mass_excluded_from_equipment=receipt.get('retained_mass_excluded_from_equipment'))
    if signature(regenerated.to_dict()) != signature(private.to_dict()) or signature(receipt) != signature(expected):
        raise ValueError('CMAA action project is not the exact declared mass conversion')
    return private
