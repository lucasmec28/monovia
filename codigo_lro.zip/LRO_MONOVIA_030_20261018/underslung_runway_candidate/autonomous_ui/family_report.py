"""Readable family criteria; never invent a governing physical force vector."""
from ..autonomous_workflow.family_pipeline import assert_current_family_result
from .family_inputs import (
    physical_family_options, consumer_input_snapshot, service_project_limits,
    NATIVE_CATEGORY_LABELS, NATIVE_BASELINE_LABELS, CMAA_CAPACITY_LABELS,
)

CRITERIA = {
    'C1_major_interaction': 'Interação de estabilidade no eixo principal forte',
    'C2_minor_interaction': 'Interação de estabilidade no eixo fraco e torção',
    'global_elastic_section': 'Tensão equivalente nominal da seção inteira',
    'sigma_x': 'Tensão normal longitudinal', 'sigma_y': 'Tensão normal transversal',
    'tau_xy': 'Cisalhamento nominal', 'equivalent': 'Tensão equivalente nominal',
    'sigma_transverse': 'Tensão normal transversal', 'sigma_longitudinal': 'Tensão normal longitudinal',
    'combined_von_mises': 'Tensão equivalente de von Mises',
}
DOFS = {'ux': 'translação longitudinal', 'uy': 'translação transversal', 'uz': 'translação vertical',
        'phi': 'rotação de torção', 'theta_y': 'rotação de flexão principal',
        'theta_z': 'rotação de flexão lateral', 'chi': 'empenamento'}


def _status(row):
    value = str(row.get('status', 'PENDING'))
    if row.get('actual_failure_proven') or row.get('known_nominal_failure') or value in ('FAIL','NÃO ATENDE','NAO_ATENDE'):
        return 'Falha identificada no critério avaliado'
    if 'INCONCLUSIVE' in value or 'NOT_SATISFIED' in value: return 'Seção não comprovada pelo critério conservador adotado; refinar ou aumentar seção'
    if row.get('qualified') is False or 'PENDING' in value or value == 'PENDENTE': return 'Verificação pendente / não executada'
    if value in ('ATENDE', 'PASS', 'SUFFICIENT_BOUND_SATISFIED', 'NOMINAL_METHOD_ZERO_CALCULATED_DAMAGE_SUFFICIENT') or 'SATISFIED' in value or value in ('SUFFICIENT_CMAA_FAMILY_NOMINAL_BOUND','SUFFICIENT_CMAA_NBR_GLOBAL_BOUND'):
        return 'Critério atendido'
    return 'Verificação pendente / não executada'


def _measure(value, digits=2):
    from .report import fmt
    if isinstance(value,(int,float)) and not isinstance(value,bool):
        return fmt(value,digits).rstrip('0').rstrip(',')
    return fmt(value)


def _timing_text(result):
    timing=result.get('timing') or {}
    if timing.get('original_basis_reused_without_FE_resweep'):
        original=timing.get('original_basis_seconds')
        return ('Análise mecânica FE original: '+(_measure(original,1)+' s' if original is not None else 'tempo não registrado')+
            '. Pós-processamento desta execução: '+_measure(timing.get('seconds'),1)+' s. As bases verificadas foram reutilizadas sem nova varredura FE; o tempo de pós-processamento não é o tempo total de análise.')
    return 'Tempo observado da execução de análise e critérios: '+_measure(timing.get('seconds'),1)+' s.'


def _pct(value):
    from .report import fmt
    return fmt(100*value, 1)+' %' if value is not None else 'Não disponível'


def _label(check):
    return CRITERIA.get(check.get('id'), 'Critério nominal complementar')


def _point(row):
    side = {'left': 'esquerdo', 'right': 'direito'}.get(row.get('outstand_side'), 'não identificado')
    face = {'top': 'superior', 'bottom': 'inferior'}.get(row.get('face'), 'não identificada')
    return f"P{row.get('point', '?')} · balanço {side} · face {face}"


def _basis_label(key):
    if key == 'selfweight': return 'Peso próprio da viga'
    if key in ('extra_dead', 'accessory_dead'): return 'Carga permanente adicional'
    if key.startswith('station') and '/' in key:
        station, component = key.split('/', 1)
        number = int(station.replace('station', ''))+1
        component = {'Fx': 'força longitudinal', 'Fy': 'força transversal', 'downward_Fz': 'força vertical descendente'}.get(component, 'ação mecânica')
        return f'Estação {number}: {component}'
    return 'Base mecânica interna'


def _rolling_action_text(component, *, service=False):
    """Describe computed pair coverage, never infer it from a user checkbox."""
    family = (component or {}).get('action_ledgers' if service else 'normal_rolling_family') or {}
    pairs = {row.get('pair_id') for row in family.get('pairs', [])}
    coefficient = (family.get('lambda_receipt') or {}).get('coefficient')
    # TOP and UNDER retain different producer schemas. Read the actual TOP
    # pair ledger, not its boolean alone, and do not fabricate a coefficient.
    if not service and not family and (component or {}).get('normal_rolling_included') is True:
        pairs = {'/'.join(pair) for pair in component.get('horizontal_pairs', [])
                 if isinstance(pair, (list, tuple)) and len(pair) == 2}
        values = {(row.get('receipt', {}).get('lambda_receipt') or {}).get('coefficient')
                  for row in component.get('rolling_receipts', [])}
        coefficient = next(iter(values)) if len(values) == 1 else None
    if pairs != {'HX/HY', 'HX/Rlambda', 'HY/Rlambda'}:
        return 'A cobertura dos três pares de ações horizontais NBR não foi demonstrada nesta avaliação.'
    coefficient_text = _measure(coefficient, 5) if coefficient is not None else 'não registrado nesta síntese'
    text = ('Ações horizontais: são avaliados separadamente os pares HX/HY, HX/Rλ e HY/Rλ. '
            'HX e HY são as inércias longitudinal e transversal; Rλ é a reação transversal normal '
            'da NBR 8400-1, §6.2.3.3, com λ = '+coefficient_text+'. '
            'Rλ não é o desalinhamento CMAA nem o enviesamento excepcional SHE. ')
    text += ('Nesta verificação de flecha, a referência vertical e as inércias são estáticas, sem impacto ou majoração.'
             if service else 'Na fadiga, preservam-se os fatores próprios do caso I, sem Mx; os limites não representam uma história artificial.')
    return text


def _normal_domain_text(result):
    data=result.get('consumer_inputs') or {}
    cmaa=data.get('cmaa') or {}; service=data.get('native_service') or {}
    declared = cmaa.get('operating_environment') == 'indoor_no_operating_wind' or service.get('operating_domain') == 'normal_operation_without_wind'
    return ('Domínio operacional declarado: operação normal em ambiente sem vento operacional. '
            if declared else 'O domínio ambiental não foi declarado nos consumidores selecionados. ')+(
        'A conclusão é restrita às ações e combinações identificadas nesta memória. '
        'Variações térmicas impostas, ensaios, choque em batentes, emergência e montagem exigem '
        'casos próprios quando aplicáveis ao projeto; não são presumidos necessários em toda operação '
        'nem dispensados por esta avaliação nominal.')


SELECTED_METHODS = (
    ('selected_global_method', {'CMAA_characteristic_NBR8800_ULS_EN2025_resistance': 'family_cmaa_global',
                                'NBR_actions_EN2025_resistance': 'family_member'}),
    ('selected_local_method', {'CMAA74_2020_case2_nominal': 'family_cmaa',
                               'NBR10084_NBR8400_nominal': 'family_local'}),
    ('selected_fatigue_method', {'NBR8400_classified_life_nominal': 'family_nbr_fatigue',
                                 'EN2025_zero_damage_sufficient': 'family_fatigue'}),
)


def _selected_criteria(result):
    """Use explicit producer method IDs, with no default for missing selection."""
    return tuple(methods.get(result.get(field)) for field, methods in SELECTED_METHODS)


def _assessment_nodes(component, path='assessment'):
    """Assessment evidence only, not provenance or nonselected diagnostics."""
    if not isinstance(component, dict):
        return
    yield path, component
    for key in ('checks', 'segments', 'families', 'points', 'point_results', 'spans'):
        children = component.get(key, [])
        for index, child in enumerate(children if isinstance(children, (list, tuple)) else []):
            if isinstance(child, dict):
                yield from _assessment_nodes(child, path+'/'+key+'/'+str(index))
    for key in ('plain_global_result', 'lower_local_result', 'checks_by_original_source', 'project_service_criteria'):
        if isinstance(component.get(key), dict):
            yield from _assessment_nodes(component[key], path+'/'+key)


def _known_failure(component):
    return bool(component.get('actual_failure_proven') or component.get('known_nominal_failure')
                or component.get('known_failures') or component.get('status') in
                ('FAIL', 'FAIL_COMPONENT', 'NÃO ATENDE', 'NAO_ATENDE'))


def declared_beam_scope_summary(result):
    """Read-only presentation conclusion, never a new signed calculation gate.

    Recompute the existing nominal summary from explicitly selected consumers.
    The existing exact, indexed suspension-region exception is the only nominal
    pending exclusion. Numerical contradictions and unknown summary/root duties
    cannot be promoted to a pass by a sufficient parent flag.
    """
    from math import isfinite
    from ..autonomous_workflow.member_scope import summarize_nominal_member
    selected = _selected_criteria(result)
    components = [result.get(key) if key else None for key in selected]+[result.get('service_summary')]
    blockers = []
    try:
        summary = summarize_nominal_member(*components)
    except (AttributeError, KeyError, TypeError, ValueError):
        # Incomplete presentation-only/legacy fixtures can still be displayed,
        # but incompatible assessment evidence cannot become a qualified pass.
        summary = summarize_nominal_member(None, None, None, None)
        blockers.append('Estrutura de evidência dos critérios incompatível ou incompleta.')
    if any(key is None for key in selected):
        blockers.append('Método obrigatório ausente ou não reconhecido na seleção registrada.')
    stored = result.get('member_summary')
    if not isinstance(stored, dict) or stored != summary:
        blockers.append('A síntese original não corresponde integralmente aos critérios selecionados recomputados.')
    # Retain unexplained root duties, while identified alternative consumers
    # remain diagnostic and the optional suspension scalar check remains separate.
    producer = result.get('family_analysis') or {}
    blockers.extend(str(reason) for reason in producer.get('pending', []))
    component_keys = ('family_member', 'family_cmaa_global', 'family_local', 'family_cmaa',
                      'family_nbr_fatigue', 'family_fatigue', 'family_service', 'family_cmaa_service',
                      'service_summary', 'project_service_criteria', 'beam_support')
    explained = [reason for key in component_keys for reason in (result.get(key) or {}).get('pending', [])]
    blockers.extend(str(reason) for reason in result.get('pending', []) if reason not in explained)
    project = result.get('project') or {}
    supports = {row.get('id'): row.get('x') for row in project.get('supports', []) if isinstance(row, dict)}
    for obligation in summary['unqualified_region_obligations']:
        for region in obligation['regions']:
            if (not isinstance(region, dict) or region.get('support_id') not in supports
                or region.get('section_x_mm') != supports.get(region.get('support_id'))
                or type(region.get('wheel_contact_index')) is not int
                or not 0 <= region['wheel_contact_index'] < len(project.get('wheels', []))):
                blockers.append('Região de suspensão sem vínculo físico válido ao projeto registrado.')
    required_checks = {
        'family_member': {'C1_major_interaction', 'C2_minor_interaction', 'global_elastic_section'},
        'family_cmaa_global': {'C1_major_interaction', 'C2_minor_interaction', 'global_elastic_section'},
        'family_local': {'sigma_x', 'sigma_y', 'tau_xy', 'equivalent'},
        'family_cmaa': {'sigma_transverse', 'sigma_longitudinal', 'tau_xy', 'combined_von_mises'},
    }
    finite_nonnegative = lambda value: type(value) in (int, float) and isfinite(value) and value >= 0
    for key, component, criterion in zip((*selected, 'service_summary'), components, summary['criteria']):
        issues, exceeded = [], False
        for path, node in _assessment_nodes(component):
            criterion['actual_failure_proven'] |= _known_failure(node)
            status = str(node.get('status', ''))
            bound_status = 'INCONCLUSIVE' in status or 'NOT_SATISFIED' in status
            if node.get('qualified') is False and not bound_status:
                issues.append(path+': evidência não qualificada.')
            exceeded |= bound_status
            checks = node.get('checks')
            if checks is not None:
                if not isinstance(checks, list) or not checks or any(not isinstance(c, dict) for c in checks):
                    issues.append(path+': verificações ausentes ou incompatíveis.')
                elif key in required_checks and not required_checks[key] <= {c.get('id') for c in checks}:
                    issues.append(path+': conjunto obrigatório de verificações incompleto.')
            values = [node['utilization']] if 'utilization' in node else []
            for demand, limit in (('demand', 'capacity'), ('demand_bound_MPa', 'allowable_MPa'),
                                  ('demand_upper_mm', 'limit_mm'), ('demand_upper_mm', 'effective_limit_mm')):
                if demand in node and limit in node:
                    if finite_nonnegative(node[demand]) and finite_nonnegative(node[limit]) and node[limit] > 0:
                        values.append(node[demand]/node[limit])
                    else:
                        issues.append(path+': demanda ou resistência numérica inválida.')
            if node.get('kind') == 'NBR8400_2_source_qualified_planar_nominal_member_fatigue':
                bound = node.get('bound') or {}
                ratios = bound.get('component_utilizations') or {}
                if node.get('input_valid') is not True or set(ratios) != {'sigma_x', 'sigma_y', 'tau_xy'}:
                    issues.append(path+': evidência obrigatória de fadiga incompleta.')
                values.extend([*ratios.values(), bound.get('combined_utilization_upper_bound')])
            if any(not finite_nonnegative(value) for value in values):
                issues.append(path+': utilização numérica inválida.')
            exceeded |= any(finite_nonnegative(value) and value > 1 for value in values)
        criterion['nominal_pending'].extend(issues)
        criterion['assessment_complete'] &= not issues
        criterion['criterion_satisfied'] &= not issues and not exceeded and not criterion['actual_failure_proven']
        criterion['status'] = ('FAIL' if criterion['actual_failure_proven'] else
            'NOT_ASSESSED' if not criterion['assessment_complete'] else
            'SATISFIED' if criterion['criterion_satisfied'] else 'INCONCLUSIVE_SUFFICIENT_BOUND')
    # Stored unknown criteria/failures remain visible blockers, never discarded.
    stored_failure = isinstance(stored, dict) and (_known_failure(stored) or any(
        _known_failure(row) for row in stored.get('criteria', []) if isinstance(row, dict)))
    root_failure = any(not isinstance(row, dict) or row.get('scope') != 'beam_support'
                       for row in result.get('known_failures', []))
    failed = stored_failure or root_failure or any(row['actual_failure_proven'] for row in summary['criteria'])
    complete = not blockers and all(row['assessment_complete'] for row in summary['criteria'])
    passed = complete and not failed and all(row['criterion_satisfied'] for row in summary['criteria'])
    summary.update(status='FAIL' if failed else 'NOT_ASSESSED' if not complete else
                   'SATISFIED' if passed else 'INCONCLUSIVE_SUFFICIENT_BOUND',
                   assessment_complete=complete, criteria_satisfied=passed,
                   nominal_member_scope_qualified=passed, presentation_blockers=blockers,
                   title='Escopo de viga avaliado', whole_member_approval=False,
                   holes_or_connection_disturbed_regions_qualified=False)
    return summary

def _pending_text(result, *, selected_only=False):
    """Report actionable domains in Portuguese; exact internal causes stay JSON."""
    out = []
    for title, key in (('Resistência global e estabilidade', 'family_member'), ('Global com origens CMAA e majoração NBR', 'family_cmaa_global'),
                       ('Tensão nominal local NBR', 'family_local'), ('Fadiga NBR de vida classificada', 'family_nbr_fatigue'), ('Fadiga nominal EN', 'family_fatigue'),
                       ('Serviço NBR', 'family_service'), ('Tensão nominal local CMAA', 'family_cmaa'),
                       ('Limites de serviço do projeto', 'project_service_criteria')):
        component = result.get(key)
        if selected_only and key not in (*_selected_criteria(result),'family_service','family_cmaa_service','project_service_criteria'):
            continue
        if selected_only and component is None and key not in _selected_criteria(result):
            continue
        if key=='family_local' and result.get('selected_local_method')=='CMAA74_2020_case2_nominal': title+=' (diagnóstico alternativo)'
        if key=='family_member' and result.get('selected_global_method')=='CMAA_characteristic_NBR8800_ULS_EN2025_resistance': title+=' (diagnóstico alternativo)'
        if component is None:
            out.append(title+(': verificação pendente / não executada.' if key=='family_nbr_fatigue' and result.get('consumer_inputs',{}).get('nbr_fatigue') is not None else ': não solicitado nesta execução.'))
        elif component.get('pending'):
            pending = component['pending']
            if selected_only and key == 'family_cmaa':
                from ..autonomous_workflow.member_scope import _nominal_pending
                pending, _ = _nominal_pending(component, 'local_lower_flange')
                if not pending:
                    continue
            if any('material' in str(p).lower() or 'steel fy' in str(p).lower() for p in pending):
                out.append(title+': informar as resistências do aço e, quando aplicável, o fator e a fonte da resistência suplementar EN; nenhum valor é presumido.')
            elif any('class' in str(p).lower() or 'C.2' in str(p) for p in pending):
                out.append(title+': domínio geométrico ou de aplicação não qualificado; revisar os limites do método e adotar avaliação compatível.')
            elif key == 'project_service_criteria':
                out.append(title+': requer resposta de serviço qualificada na mesma base de ações e deslocamentos.')
            else:
                out.append(title+': evidência numérica ou domínio físico ainda não qualificado. A causa exata e sua rastreabilidade estão registradas no JSON.')
        elif 'INCONCLUSIVE' in str(component.get('status', '')):
            out.append(title+': o limite suficiente não permite concluir; avaliar estados coexistentes ou redimensionar, sem tratar este resultado como falha física demonstrada.')
    if result['family_analysis'].get('pending'):
        out.insert(0, 'Bases mecânicas: verificação numérica incompleta. Aumentar ou revisar o orçamento e os dados conforme o registro do cálculo antes de usar as conclusões.')
    return out


def _fatigue_rows(component):
    from .report import fmt
    rows = []
    for title, entries in (
        ('Mesa superior e alma, regiões ordinárias', [component.get('plain_global_result')]),
        ('Mesa inferior, global + local nominal', component.get('point_results', [])),
    ):
        entries = [e for e in entries if e]
        if not entries: continue
        criteria = (
            ('Amplitude principal / limite VAFL', 'principal_range_mpa', 'normal_vafl_design_mpa', 1.),
            ('Amplitude direta / limite VAFL', 'direct_range_mpa', 'normal_vafl_design_mpa', 1.),
            ('Amplitude de cisalhamento / limite VAFL', 'shear_range_mpa', 'shear_vafl_design_mpa', 1.),
            ('Tensão normal característica / limite elástico', 'characteristic_absolute_normal_bound_mpa', 'characteristic_normal_limit_mpa', 1.),
            ('Cisalhamento característico / limite elástico', 'characteristic_absolute_shear_bound_mpa', 'characteristic_shear_limit_mpa', 1.),
            ('Amplitude normal frequente / limite', 'frequent_normal_range_bound_mpa', 'characteristic_normal_limit_mpa', 1.5),
            ('Amplitude de cisalhamento frequente / limite', 'frequent_shear_range_bound_mpa', 'characteristic_shear_limit_mpa', 1.5),
        )
        for label, demand, limit, factor in criteria:
            applicable = [e for e in entries if e.get(demand) is not None and e.get(limit)]
            if not applicable: continue
            worst = max(applicable, key=lambda e: e[demand]/(factor*e[limit]))
            ratio = worst[demand]/(factor*worst[limit])
            # VAFL criteria are strict '<', unlike the characteristic/frequent checks.
            passed = ratio < 1. if 'VAFL' in label else ratio <= 1.
            rows.append({'Região': title, 'Critério': label, 'Demanda / limite [MPa]': fmt(worst[demand])+' / '+fmt(factor*worst[limit]),
                         'Utilização': _pct(ratio), 'Situação': 'Critério atendido' if passed else 'Seção não comprovada pelo critério conservador adotado; refinar ou aumentar seção'})
    return rows


def sections(project, result, payload=None, *, include_diagnostics=False):
    assert_current_family_result(project, result)
    from .report import fmt
    if payload is not None:
        from .ui import build_project
        from ..autonomous_workflow.model import signature
        current=build_project(payload,max_element_length_mm=project.max_element_length_mm)
        if signature(current.to_dict())!=signature(project.to_dict()):
            raise ValueError('As entradas físicas da viga ou da composição comum de massas mudaram; recalcular antes de exportar.')
        snapshot = consumer_input_snapshot(physical_family_options(payload))
        snapshot['service_project_limits'] = service_project_limits(payload)
        from .support_inputs import physical_beam_support_inputs
        support=physical_beam_support_inputs(payload,project=project)
        snapshot['beam_support']=support.to_dict() if support is not None else None
        actual = result.get('consumer_inputs', {})
        if any(actual.get(k) != v for k, v in snapshot.items()):
            raise ValueError('As opções físicas complementares mudaram; recalcular antes de exportar a memória da família.')
    payload = payload or {}
    r, s = result['family_analysis'], project.section
    summary = []
    selected_keys=_selected_criteria(result)
    declared_scope=declared_beam_scope_summary(result)
    for label, key in (('Resistência global e estabilidade complementar EN', 'family_member'), ('Global: origens CMAA, majoração NBR e resistência suplementar EN', 'family_cmaa_global'),
                       ('Tensão nominal local NBR', 'family_local'), ('Fadiga NBR de vida classificada', 'family_nbr_fatigue'), ('Fadiga nominal suficiente EN 2025, diagnóstico independente', 'family_fatigue'),
                       ('Deformação incremental NBR 10084', 'family_service'), ('Serviço CMAA independente', 'family_cmaa_service'), ('Conjunto de critérios de serviço solicitados', 'service_summary'), ('Tensão nominal local CMAA 74:2020', 'family_cmaa'),
                       ('Limites mais restritivos de serviço do projeto', 'project_service_criteria')):
        part = result.get(key)
        if key not in (*selected_keys,'family_service','family_cmaa_service','service_summary','project_service_criteria'):
            continue
        if part is None and key not in selected_keys:
            continue
        if key=='family_member' and result.get('selected_global_method')=='CMAA_characteristic_NBR8800_ULS_EN2025_resistance': label+=' — diagnóstico alternativo'
        if key=='family_cmaa_global' and result.get('selected_global_method')=='CMAA_characteristic_NBR8800_ULS_EN2025_resistance': label+=' — método selecionado'
        if key=='family_local' and result.get('selected_local_method')=='CMAA74_2020_case2_nominal': label+=' — diagnóstico alternativo'
        if key=='family_cmaa' and result.get('selected_local_method')=='CMAA74_2020_case2_nominal': label+=' — método selecionado'
        requested = key=='family_nbr_fatigue' and result.get('consumer_inputs',{}).get('nbr_fatigue') is not None
        summary.append({'Critério independente': label, 'Situação': ('Verificação pendente / não executada' if requested or key in selected_keys else 'Não solicitado') if part is None else _status(part), '_criterion':key})
    order={key:index for index,key in enumerate((*selected_keys,'family_service','family_cmaa_service','service_summary','project_service_criteria'))}
    summary.sort(key=lambda row:order[row.pop('_criterion')])
    if result.get('beam_support') is not None:
        support=result['beam_support']
        summary.append({'Critério independente':'Informação fora do escopo: furos, parcela escalar de flexão maior',
                        'Situação':_status(dict(status=support['scalar_bending_status'],actual_failure_proven=support.get('actual_failure_proven',False)))})
    for index, (key, label) in enumerate(zip(selected_keys, ('Resistência global e estabilidade', 'Tensão nominal local', 'Fadiga do membro'))):
        if key is None:
            summary.insert(index, {'Critério independente':label, 'Situação':'Método não declarado ou não reconhecido; avaliação necessária'})
    summary.extend([
        {'Critério independente':'Ligação viga-piso, componentes da ligação e estrutura receptora', 'Situação':'FORA DO ESCOPO · NÃO VERIFICADA'},
        {'Critério independente':'Região local de introdução da reação, interação e fadiga locais', 'Situação':'FORA DO ESCOPO · NÃO VERIFICADA'}])
    out = [dict(title='1. Identificação, alcance e conclusão', paragraphs=[
        'PROJETO COM PREMISSAS INFORMADAS' if project.actual_project else 'TESTE SINTÉTICO, NÃO É PROJETO REAL',
        str(payload.get('project_label') or 'Estudo sem identificação comercial.'),
        'ESCOPO DESTA MEMÓRIA: SOMENTE A VIGA DE ROLAMENTO, nos domínios nominais de resistência global, estabilidade global, tensão local, fadiga e flecha efetivamente avaliados. A validade das condições de apoio e os vínculos físicos declarados são premissas obrigatórias do modelo. Contato roda/pista, mecanismos, ligação viga-piso, regiões perturbadas de introdução da reação e estrutura receptora são escopos separados: sua não avaliação não impede, por si só, o atendimento dos critérios nominais declarados. Os limites de componentes não são estados simultâneos; seu excesso não comprova falha física. Dados e requisitos adotados não são confirmação do fabricante nem projeto da ponte inteira.',
        'Escopo de viga avaliado: '+_status(declared_scope)+'. '+('Todos os critérios nominais obrigatórios selecionados atendem no domínio declarado.' if declared_scope['criteria_satisfied'] else 'Avaliação nominal concluída, mas o limite suficiente não comprova atendimento; refinar ou redimensionar sem presumir falha física.' if declared_scope['assessment_complete'] and declared_scope['status']!='FAIL' else 'Há falha identificada ou verificação ausente, inconsistente ou ainda não qualificada; consultar os critérios e a rastreabilidade.'),
        'FORA DO ESCOPO, NÃO VERIFICADAS: a ligação viga-piso e a região local de introdução da reação, incluindo efeitos elásticos, interação e fadiga locais. Essas exclusões não bloqueiam o atendimento do escopo nominal declarado, mas não aprovam a ligação, a região perturbada nem integralmente a viga.',
        'Ações e respostas são calculadas internamente, sem esforços de programa externo. Todas as oito configurações extremas declaradas de gancho, altura de transferência e via são regeneradas a partir de massas, geometria e acelerações. Registros coincidentes podem ocorrer na carga livre por cabos.',
        'Os métodos selecionados são apresentados no corpo principal. Diagnósticos alternativos e seus valores permanecem no JSON e podem ser incluídos no apêndice opcional.'], rows=summary),
      dict(title='2. Geometria, material e massas', paragraphs=[project.source_notes, project.material_source], rows=[
        {'Grandeza': 'Comprimento físico', 'Valor': _measure(project.length_mm), 'Unidade': 'mm'},
        {'Grandeza': 'Altura / largura / espessura da mesa / espessura da alma', 'Valor': ' / '.join(_measure(v) for v in (s.d_mm,s.bf_mm,s.tf_mm,s.tw_mm)), 'Unidade': 'mm'},
        {'Grandeza': 'Resistência ao escoamento / resistência à ruptura', 'Valor': _measure(project.fy_mpa)+' / '+_measure(project.fu_mpa), 'Unidade': 'MPa'},
        {'Grandeza': 'Curso físico de translação do trem', 'Valor': _measure(project.travel_min_mm)+' a '+_measure(project.travel_max_mm), 'Unidade': 'mm'},
        {'Grandeza': 'Peso próprio distribuído', 'Valor': fmt(project.selfweight(),5), 'Unidade': 'N/mm'},
        {'Grandeza': 'Capacidade nominal de carga útil' if project.suspended_mass_basis().get('complete_suspended_mass_accounting') else 'Parcela içada removível declarada, convenção legada', 'Valor': _measure(project.capacity_tf), 'Unidade': 't métricas'}]),
      dict(title='3. Suspensões e vínculos', paragraphs=[
        'Coordenadas longitudinais: x é a posição física na viga, medida desde a extremidade esquerda. ξ é a posição relativa da roda no trem. Em cada translação a, vale x = a + ξ; uma estação relativa não é uma seção fixa da viga.',
        'O espaçamento não impõe restrição lateral, rotação ou empenamento. Os vínculos a seguir são premissas físicas adotadas; sua realização deve ser garantida pelo projeto separado da ligação viga-piso. A ligação e a estrutura receptora estão fora do escopo desta avaliação.'], rows=[
        {'Apoio': row['id'], 'x / y / z [mm]': ' / '.join(_measure(row[k]) for k in ('x','y','z')),
         'Graus restringidos': ', '.join(DOFS.get(k,'vínculo adicional')+' = '+_measure(v) for k,v in row['restrain'].items()), 'Origem': row['provenance']} for row in project.supports]),
      dict(title='4. Modelo de análise e cobertura', paragraphs=[
        'A análise linear da viga considera as posições das rodas, os dois lados dos cortes e as passagens pelos apoios, com verificação da convergência de malha. Os limites de esforços e as deformações de serviço são verificados separadamente; não se afirma um limite matemático exato do contínuo.',
        'As ações de resistência, as ações do método de fadiga selecionado, o serviço incremental NBR e o caso 2 nominal CMAA têm fatores e composições próprios. Compartilham apenas a mecânica linear verificada; não se transferem aprovações entre normas.'], rows=[])]
    bridge = (project.bridge_reaction_ledger or {}).get('inputs', {})
    physical_fields = (
        ('bridge_span_mm', 'Vão da ponte entre vias', 'mm'),
        ('bridge_mass_kg', 'Massa da ponte e cabeceiras, sem carro', 'kg'),
        ('trolley_mass_kg', 'Massa do carro', 'kg'),
        ('hook_min_from_left_mm', 'Gancho mínimo desde a via esquerda', 'mm'),
        ('hook_max_from_left_mm', 'Gancho máximo desde a via esquerda', 'mm'),
        ('carriage_station_spacing_mm', 'Distância longitudinal entre estações de rodas', 'mm'),
        ('contact_n_mm', 'Centro de contato até a borda livre', 'mm'),
        ('bridge_acceleration_m_s2', 'Aceleração longitudinal assinada da ponte', 'm/s²'),
        ('trolley_acceleration_m_s2', 'Aceleração transversal assinada do carro', 'm/s²'),
        ('horizontal_dynamic_factor', 'Amplificação horizontal adicional NBR adotada', '—'),
    )
    out[1]['rows'].extend({'Grandeza': label, 'Valor': _measure(bridge[key],3 if unit=='m/s²' else 2), 'Unidade': unit}
        for key, label, unit in physical_fields if key in bridge)
    if bridge:
        mass_basis=project.suspended_mass_basis()
        if mass_basis.get('complete_suspended_mass_accounting'):
            out[1]['rows'].extend([
                {'Grandeza':'Massa suspensa retida no vazio e no carregado','Valor':_measure(mass_basis['retained_suspended_mass_kg']),'Unidade':'kg'},
                {'Grandeza':'Massa suspensa total carregada, carga útil + retida','Valor':_measure(mass_basis['loaded_suspended_mass_kg']),'Unidade':'kg'}])
            out[1]['paragraphs'].extend([
                'Composição comum: a capacidade nominal é somente carga útil. Moitão e acessórios retidos são uma parcela suspensa separada, presente no vazio e no carregado e excluída das massas da ponte e do carro. Não se adota um CG médio entre a carga útil e a massa retida.',
                'Fonte da massa suspensa e ausência de dupla contagem: '+str(bridge['suspended_mass_source'])])
            if bridge.get('transfer_model')=='guided_rigid_payload_cg' and mass_basis['retained_suspended_mass_kg']>0:
                out[1]['rows'].append({'Grandeza':'CG próprio da massa retida, ξ / z','Valor':_measure(bridge.get('retained_suspended_cg_x_mm'))+' / '+_measure(bridge.get('retained_suspended_cg_z_mm')),'Unidade':'mm'})
        else:
            out[1]['paragraphs'].append('Convenção legada preservada: toda a parcela içada declarada é removida no vazio. A massa real do moitão e acessórios retidos permanece desconhecida; isso NÃO demonstra massa retida igual a zero nem composição completa das massas suspensas.')
        out[1]['paragraphs'].append('Origem das massas e geometria da ponte: '+str(bridge.get('geometry_mass_cg_source') or 'Não identificada.'))
        out[1]['paragraphs'].append('Transferência da carga: '+('livre por cabos, com força aplicada no ponto declarado abaixo do carro.' if bridge.get('transfer_model')=='free_suspended_at_crab' else 'guiada ou rígida, pelos centros de massa explicitamente declarados.'))
    global_rows = []
    for family in result['family_member'].get('families', []):
        for index, segment in enumerate(family['segments']):
            for c in segment['checks']:
                global_rows.append({'Trecho': str(index+1), 'Critério': _label(c), 'Utilização': _pct(c.get('utilization')), 'Situação': _status(c)})
    out.append(dict(criterion='family_member', title='5. Resistência global e estabilidade', paragraphs=[
        _status(result['family_member'])+'.',
        ('Diagnóstico alternativo: o método global selecionado nesta execução usa origens CMAA, majoração NBR 8800 e resistência suplementar EN C.2, apresentado no corpo principal.' if result.get('selected_global_method')=='CMAA_characteristic_NBR8800_ULS_EN2025_resistance' else 'Família original de ações NBR avaliada nesta seção.'),
        'Critérios globais nominais e método C.2 suplementar EN, expressamente adotado, nos trechos cujos vínculos e geometria satisfazem seu domínio. Não constitui resistência global CMAA nem equivalência integral entre normas.'], rows=global_rows))
    cmaa_global=result.get('family_cmaa_global')
    if cmaa_global is not None:
        cg=[]
        for index,segment in enumerate(cmaa_global.get('segments',[])):
            for check in segment.get('checks',[]):
                cg.append({'Trecho':str(index+1),'Critério':_label(check),'Utilização':_pct(check.get('utilization')),'Situação':_status(check)})
        out.append(dict(criterion='family_cmaa_global', title='5b. Global com origens CMAA e majoração NBR',paragraphs=[_status(cmaa_global)+'.',
            'As parcelas físicas características CMAA de ponte, carro, carga útil, massa retida, inércia e desalinhamento recebem a majoração NBR 8800 por origem. Os fatores dinâmicos CMAA são aplicados uma vez; não se majora um tensor combinado do caso 2 nem se reaplica a dinâmica vertical NBR.',
            'Resistência e estabilidade: método suplementar EN 2025 C.2 e tensão nominal da seção, expressamente adotados. Esta sequência não é resistência nativa CMAA nem resistência integral NBR.',
            'Domínio adotado: geometria, vínculos, raio de aplicação, contato sem retenção e evidência numérica do modelo.'],rows=cg))
    local_rows = []
    for point in result['family_local'].get('points', []):
        if not point.get('checks'): continue
        worst = max(point['checks'], key=lambda c:c['utilization'])
        local_rows.append({'Ponto nominal': _point(point), 'Critério limitante': _label(worst), 'Utilização': _pct(worst['utilization']), 'Situação': _status(worst)})
    out.append(dict(criterion='family_local', title='6. Mesa inferior, tensão nominal local NBR', paragraphs=[
        _status(result['family_local'])+'.',
        *(['Diagnóstico alternativo preservado. O método local selecionado nesta execução é o caso 2 nominal CMAA 74, apresentado no corpo principal. O resultado NBR não é ocultado nem reclassificado.'] if result.get('selected_local_method')=='CMAA74_2020_case2_nominal' else []),
        'ABNT NBR 10084:2020, §9.1.4: parcela longitudinal local 75 % e transversal 100 %, com comparação nominal NBR 8400. Ambos os balanços e faces são avaliados nos pontos prescritos da região laminada ordinária.'], rows=local_rows))
    fatigue = result.get('family_fatigue')
    fatigue_inputs = (fatigue or {}).get('physical_inputs') or result.get('consumer_inputs', {}).get('fatigue') or project.en_fatigue_inputs or {}
    out.append(dict(criterion='family_fatigue', title='7. Fadiga nominal EN 1993-1-9:2025', paragraphs=[
        'Não solicitada nesta execução.' if fatigue is None else _status(fatigue)+'.',
        'Fatores físicos EN declarados: dinâmica do equipamento '+fmt(fatigue_inputs.get('dynamic_equipment'))+'; dinâmica da massa içada '+fmt(fatigue_inputs.get('dynamic_lifted'))+'; ação de fadiga '+fmt(fatigue_inputs.get('gamma_ff'))+'; resistência à fadiga '+fmt(fatigue_inputs.get('gamma_mf'))+'; resistência em serviço '+fmt(fatigue_inputs.get('gamma_mser'))+'.',
        ('Diagnóstico independente: a conclusão de fadiga selecionada nesta execução é NBR de vida classificada; a condição EN não a substitui nem a invalida.' if result.get('selected_fatigue_method')=='NBR8400_classified_life_nominal' else 'Método EN selecionado para o escopo de fadiga nesta execução.' if result.get('selected_fatigue_method')=='EN2025_zero_damage_sufficient' else 'A seleção do método de fadiga não foi registrada nesta execução.'),
        'Método suficiente de dano calculado nulo, sob limites de amplitude variável (VAFL), com fatores EN declarados separadamente. Não é cálculo completo de vida finita, contagem de ciclos, equivalência NBR ou promessa de vida física ilimitada.',
        'Mesa superior/alma: efeitos globais nas regiões ordinárias. Mesa inferior: efeitos globais e locais nominais nos pontos prescritos.'], rows=_fatigue_rows(fatigue) if fatigue else []))
    if fatigue is None:
        out[-1]['paragraphs']=['Não solicitada nesta execução.']
    nbr=result.get('family_nbr_fatigue')
    nbr_physical=(nbr or {}).get('physical_inputs') or result.get('consumer_inputs',{}).get('nbr_fatigue')
    if nbr_physical is not None:
        out.append(nbr_fatigue_section(nbr,nbr_physical))
    service = result.get('family_service')
    inputs = result.get('consumer_inputs', {}).get('native_service') or {}
    service_rows = []
    for span in (service or {}).get('spans', []):
        for check in span['checks']:
            service_rows.append({'Vão [mm]': _measure(span['start_mm'])+' a '+_measure(span['end_mm']),
                'Direção': 'Vertical' if check['direction']=='vertical' else 'Lateral',
                'Limite superior da flecha [mm]': fmt(check['demand_upper_mm']), 'Limite admissível [mm]': fmt(check['limit_mm']),
                'Utilização': _pct(check.get('utilization',check['demand_upper_mm']/check['limit_mm'])), 'Situação': _status(check)})
    out.append(dict(criterion='family_service', title='8. Serviço NBR 10084:2020', paragraphs=[
        'Não solicitado nesta execução.' if service is None else _status(service)+'.',
        'Tabela 4(a,d): deslocamento na linha real de rolamento suspenso, adotada explicitamente, relativo à corda entre suspensões. Incremento desde o estado de peso próprio do MESMO modelo, sem impacto nem majoração; não é deslocamento total EN nem subtração de máximos independentes.',
        NATIVE_CATEGORY_LABELS.get(inputs.get('equipment_category'),'Categoria não declarada nesta execução.')+'. Limite lateral: L/600.',
        NATIVE_BASELINE_LABELS.get(inputs.get('accessory_baseline_policy'),'Composição do peso próprio de referência não declarada nesta execução.')+'.',
        'Fontes físicas NBR: '+ '; '.join(str(inputs[k]) for k in ('equipment_category_source','measurement_plane_adoption_source','operating_source','accessory_baseline_source') if inputs.get(k))+'.' if inputs else 'Sem fontes complementares NBR nesta execução.',
        _rolling_action_text(service,service=True)], rows=service_rows))
    cmaa_service=result.get('family_cmaa_service')
    if cmaa_service is not None:
        cr=[]
        for span in cmaa_service.get('spans',[]):
            for check in span.get('checks',[]):
                cr.append({'Vão [mm]':_measure(span['start_mm'])+' a '+_measure(span['end_mm']),
                    'Direção':'Vertical' if check.get('direction')=='vertical' else 'Lateral',
                    'Limite superior [mm]':fmt(check.get('demand_upper_mm')),'Limite admissível [mm]':fmt(check.get('limit_mm')),
                    'Situação':_status(check)})
        out.append(dict(criterion='family_cmaa_service', title='8b. Serviço CMAA 74, base independente',paragraphs=[_status(cmaa_service)+'.',
            'Critério vertical L/450 para a viga de rolamento suspensa, com ações próprias CMAA, sem impacto vertical e com as parcelas de inércia e desalinhamento explicitamente adotadas no consumidor. A resposta e seu estado de referência são mantidos separados do incremento NBR; não se reutiliza a flecha de outra base nem se escolhe apenas o denominador menos restritivo.',
            'Deformação global da linha de contato relativamente à corda entre apoios do mesmo estado.'],rows=cr))
    service_summary=result.get('service_summary')
    if service_summary is not None:
        out.append(dict(criterion='service_summary', title='8c. Conjunto de critérios de serviço',paragraphs=[_status(service_summary)+'.',
            'A conclusão mantém os critérios originais de cada norma e todos os vãos físicos, além dos limites mais restritivos de projeto quando solicitados. Cada resposta conserva sua base de ações e seu estado de referência; uma aprovação isolada não substitui critério original ausente ou não demonstrado.'],rows=[]))
    manual = result.get('project_service_criteria')
    manual_rows = []
    for check in (manual or {}).get('checks', []):
        manual_rows.append({'Base / vão':('CMAA' if 'CMAA' in str(check.get('source_criterion_id','')) else 'NBR')+' / '+str(check['span_index']+1), 'Direção': 'Vertical' if check['direction']=='vertical' else 'Lateral',
            'Flecha limitada [mm]': fmt(check['demand_upper_mm']), 'Norma / projeto / efetivo [mm]': ' / '.join(fmt(check[k]) for k in ('original_limit_mm','project_limit_mm','effective_limit_mm')),
            'Utilização': _pct(check['demand_upper_mm']/check['effective_limit_mm']), 'Situação': _status(check)})
    manual_inputs = (manual or {}).get('physical_inputs') or {}
    out.append(dict(criterion='project_service_criteria', title='9. Limites adicionais mais restritivos de serviço', paragraphs=[
        'Não solicitados nesta execução.' if manual is None else _status(manual)+'.',
        'Para cada resposta qualificada, mantém-se o menor limite entre a norma aplicável (inclusive teto absoluto) e L/divisor de projeto. Uma entrada menos restritiva nunca relaxa a norma. Respostas CMAA sem impacto vertical, NBR incrementais e EN totais não são misturadas nem rebatizadas.',
        *(['Divisores de projeto declarados: vertical '+('L/'+_measure(manual_inputs['vertical_divisor']) if manual_inputs.get('vertical_divisor') is not None else 'não solicitado')+'; lateral '+('L/'+_measure(manual_inputs['lateral_divisor']) if manual_inputs.get('lateral_divisor') is not None else 'não solicitado')+'.', 'Origem do requisito: '+str(manual_inputs['source'])] if manual_inputs.get('source') else [])], rows=manual_rows))
    cmaa = result.get('family_cmaa')
    ci = result.get('consumer_inputs', {}).get('cmaa') or {}
    accounting = result.get('consumer_inputs', {}).get('cmaa_mass_accounting') or {}
    cmaa_rows = []
    for point in (cmaa or {}).get('points', []):
        if not point.get('checks'): continue
        worst = max(point['checks'], key=lambda c:c['utilization'])
        cmaa_rows.append({'Ponto nominal': _point(point), 'Estação relativa ξ [mm]': _measure(point.get('station_offset_mm')),
            'Critério limitante': _label(worst), 'Demanda / admissível [MPa]': fmt(worst['demand_bound_MPa'])+' / '+fmt(worst['allowable_MPa']),
            'Utilização': _pct(worst['utilization']), 'Situação': _status(worst)})
    out.append(dict(criterion='family_cmaa', title='10. CMAA 74:2020, caso 2 ASD, tensão nominal local', paragraphs=[
        'Não solicitada nesta execução.' if cmaa is None else _status(cmaa)+'.',
        *(['Método local selecionado para a conclusão do membro nesta execução; o diagnóstico local NBR é preservado separadamente.'] if result.get('selected_local_method')=='CMAA74_2020_case2_nominal' else []),
        'Fonte: CMAA Specification No. 74, edição 2020, §§3.3.2.6.1–2 e 3.4.4.1, Tabela 3.4-1, caso 2. Tensões admissíveis: normais/equivalente 66 % de fy; cisalhamento 40 % de fy. Parcelas locais transversal e longitudinal: 75 %; parcela global longitudinal: 100 %.',
        'P0 na face da alma e P1 sob a roda, na face inferior da mesa, nos dois balanços. Ações CMAA próprias incluem fatores de peso próprio, içamento e inércia, mais limite suficiente de desalinhamento. A origem normativa não é NBR/EN e a comparação não constitui verificação global CMAA.',
        CMAA_CAPACITY_LABELS.get(accounting.get('capacity_basis'),'Convenção de capacidade não declarada nesta execução.')+'. Massa suspensa retida no vazio: '+_measure(ci.get('empty_suspended_mass_kg'))+' kg.',
        'Composição comum de massas e sua fonte conforme seção 2, com fatores CMAA próprios e sem dupla contagem.',
        'Velocidades físicas CMAA: ponte '+_measure(ci.get('bridge_travel_speed_m_s'),3)+' m/s; carro '+_measure(ci.get('trolley_travel_speed_m_s'),3)+' m/s; içamento '+_measure(ci.get('hoist_speed_m_s'),3)+' m/s. Fonte: '+str(ci.get('source') or 'Não informada.'),
        *(['CG físico da massa suspensa retida: x = '+_measure(ci.get('empty_suspended_cg_x_mm'))+' mm; z = '+_measure(ci.get('empty_suspended_cg_z_mm'))+' mm, no referencial declarado dos contatos.'] if ci.get('empty_suspended_mass_kg') and bridge.get('transfer_model')=='guided_rigid_payload_cg' else []),
        'O estado sem carga útil conserva a parcela suspensa retida.'], rows=cmaa_rows))
    out.append(dict(criterion='reactions', title='11. Reações coexistentes para a estrutura receptora', paragraphs=[
        'O JSON conserva vetores reais de reação de casos e posições identificados. Não são a reunião de máximos independentes nem a combinação das duas pontes do prédio.',
        'Os vetores testemunhos não constituem envelope exaustivo de ligações. Demanda das ligações e capacidade da estrutura receptora mantêm escopos próprios.'], rows=[]))
    if result.get('beam_support') is not None:
        out.append(beam_support_section(result['beam_support']))
    out.append(dict(criterion='traceability', title='12. Cobertura restante e rastreabilidade', paragraphs=_pending_text(result,selected_only=True)+[
        _normal_domain_text(result),
        *declared_scope['presentation_blockers'],
        ('Informação fora do escopo: os caminhos líquidos e o limite escalar de flexão por furos informados permanecem discriminados na seção própria, inclusive eventual falha conhecida. Não qualificam a região local de introdução da reação.' if result.get('beam_support') is not None else 'Furos, seção líquida e região local de introdução da reação não são verificados por esta conclusão nominal. A região perturbada e a ligação viga-piso permanecem fora do escopo, sem presumir uma mesa parafusada íntegra.'),
        'Identidade das entradas: '+result['project_signature'][:16]+'. O JSON conserva integralmente fontes, fatores, configurações, campos originais, resultados principais e diagnósticos alternativos. Alterações de entradas, opções ou código de cálculo exigem nova validação.'], rows=[]))
    main=_principal_sections(out,result,include_diagnostics=include_diagnostics)
    if include_diagnostics:
        main.append(dict(title='Apêndice B. Registro técnico da análise numérica',paragraphs=[
            f"Foram incluídas {r.get('total_configuration_count',0)} configurações e {r.get('total_case_count',0)} combinações do produtor mecânico.",
            _timing_text(result),
            'A verificação das bases lineares inclui as posições polinomiais, os lados dos cortes e os eventos. Os recibos completos, controles e históricos de convergência permanecem no JSON técnico.'],rows=[
            {'Base interna':_basis_label(k),'Malhas':str(len(v['mesh_history'])),'Verificação':'Concluída' if (v.get('verification') or {}).get('all_point_completion') else 'Pendente'}
            for k,v in r.get('basis_evidence',{}).items()]))
    return main


def _principal_sections(all_sections,result,*,include_diagnostics):
    """Order selected methods first, without editing any raw result or gate."""
    import re
    selected=_selected_criteria(result)
    indexed={part.get('criterion'):part for part in all_sections if part.get('criterion')}
    main=all_sections[:4]
    for key, label in zip(selected, ('Resistência global e estabilidade', 'Tensão nominal local', 'Fadiga do membro')):
        if key is None:
            main.append(dict(title=label,paragraphs=[
                ('Método de fadiga não declarado; avaliação necessária.' if label=='Fadiga do membro' and result.get('selected_fatigue_method') is None else 'Método não declarado ou não reconhecido; avaliação necessária.')+' Verificação pendente / não executada.'],rows=[]))
        elif key in indexed:
            main.append(indexed[key])
        else:
            main.append(dict(title='Fadiga do membro' if key in ('family_nbr_fatigue','family_fatigue') else 'Critério selecionado',
                paragraphs=['Verificação pendente / não executada. O método selecionado ainda não possui resultado qualificado.'],rows=[]))
    for key in ('family_service','family_cmaa_service','service_summary','project_service_criteria'):
        if key in indexed and (result.get(key) is not None or key=='family_service'):
            main.append(indexed[key])
    if 'beam_support' in indexed:
        main.append(indexed['beam_support'])
    main.append(indexed['traceability'])
    diagnostics=[part for part in all_sections[4:] if part.get('criterion') not in selected
        and part.get('criterion') not in ('family_service','family_cmaa_service','service_summary','project_service_criteria','beam_support','traceability')
        and (result.get(part.get('criterion')) is not None or part.get('criterion')=='reactions')]
    for index,part in enumerate(main,1):
        part['title']=str(index)+'. '+re.sub(r'^\d+[a-z]?\.\s*','',part['title'])
    if include_diagnostics and diagnostics:
        main.append(dict(title='Apêndice A. Diagnósticos alternativos',paragraphs=[
            'Resultados preservados para comparação; não substituem os métodos selecionados do corpo principal. A seleção dos métodos não altera nem reclassifica os valores abaixo.'],rows=[]))
        for index,part in enumerate(diagnostics,1):
            diagnostic_title={'family_local':'Tensão nominal local NBR','family_member':'Resistência global e estabilidade'}.get(part.get('criterion'),re.sub(r'^\d+[a-z]?\.\s*','',part['title']))
            part['title']='A'+str(index)+'. '+diagnostic_title+' — diagnóstico alternativo'
            main.append(part)
    # Full outcome wording occurs once at the conclusion of each criterion,
    # while tables remain readable without repeating a paragraph in every row.
    for part in main:
        for row in part.get('rows',[]):
            if str(row.get('Situação','')).startswith('Seção não comprovada pelo critério conservador adotado;'):
                row['Situação']='Seção não comprovada'
    return main



def physical_elevation_data(project):
    """Exact physical coordinates and an explicitly illustrative train position."""
    project.validate()
    if project.travel_min_mm is None or project.travel_max_mm is None:
        raise ValueError('A elevação da família exige o curso físico declarado do trem.')
    translation=(project.travel_min_mm+project.travel_max_mm)/2
    stations={}
    for wheel in project.wheels:
        stations.setdefault(wheel.offset_mm,[]).append(wheel.id)
    return dict(length_mm=project.length_mm, translation_mm=translation,
        supports=[dict(id=s['id'],x_mm=s['x']) for s in project.supports],
        stations=[dict(relative_xi_mm=offset,physical_x_mm=translation+offset,wheel_ids=ids)
                  for offset,ids in sorted(stations.items())],
        travel_min_mm=project.travel_min_mm,travel_max_mm=project.travel_max_mm)


def physical_elevation_png(project):
    """Dimensioned member/support/train drawing, never a governing force state."""
    from io import BytesIO
    from PIL import Image,ImageDraw,ImageFont
    data=physical_elevation_data(project)
    im=Image.new('RGB',(1600,650),'white');draw=ImageDraw.Draw(im)
    face='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
    try:
        title=ImageFont.truetype(face,30);font=ImageFont.truetype(face,23);small=ImageFont.truetype(face,21)
    except OSError:title=font=small=ImageFont.load_default()
    blue,gray,red='#173858','#64748b','#be123c'
    left,right,top,bottom=100.,1500.,195,250
    xpix=lambda x:left+(right-left)*x/data['length_mm']
    draw.text((32,16),'Elevação dimensionada da viga e do trem de rodas',font=title,fill=blue)
    draw.text((32,62),'Posição ilustrativa, não governante. x = a + ξ; x físico na viga e ξ relativo ao trem.',font=font,fill=gray)
    draw.rectangle((left,top,right,bottom),fill='#e2e8f0',outline=blue,width=3)
    draw.line((left,top+8,right,top+8),fill=blue,width=2)
    draw.line((left,bottom-8,right,bottom-8),fill=blue,width=2)
    supports={}
    for s in data['supports']:supports.setdefault(s['x_mm'],[]).append(str(s['id']))
    for i,(x,ids) in enumerate(sorted(supports.items())):
        xp=xpix(x);draw.line((xp,top-45,xp,top),fill='#0284c7',width=4)
        draw.line((xp-22,top-45,xp+22,top-45),fill='#0284c7',width=4)
        label='/'.join(ids)+'  x='+_measure(x)+' mm'
        box=draw.textbbox((0,0),label,font=small);w=box[2]-box[0]
        draw.text((max(24,min(1576-w,xp-w/2)),100+(i%2)*24),label,font=small,fill='#075985')
    def dimension(xa,xb,y,label,color=gray):
        pa,pb=xpix(xa),xpix(xb)
        draw.line((pa,y,pb,y),fill=color,width=2)
        for xp in (pa,pb):draw.line((xp,y-8,xp,y+8),fill=color,width=2)
        box=draw.textbbox((0,0),label,font=small);w=box[2]-box[0]
        draw.rectangle(((pa+pb-w)/2-5,y-16,(pa+pb+w)/2+5,y+15),fill='white')
        draw.text(((pa+pb-w)/2,y-14),label,font=small,fill=color)
    xs=sorted({0.,data['length_mm'],*supports})
    for a,b in zip(xs,xs[1:]):
        if b>a:dimension(a,b,350,_measure(b-a)+' mm')
    dimension(0,data['length_mm'],408,'Comprimento físico '+_measure(data['length_mm'])+' mm',blue)
    for i,station in enumerate(data['stations']):
        x=station['physical_x_mm'];xp=xpix(x)
        if 0<=x<=data['length_mm']:
            draw.ellipse((xp-12,bottom-10,xp+12,bottom+14),fill=red,outline=red)
            draw.line((xp,bottom+14,xp,286),fill=red,width=2)
        label='Estação '+str(i+1)+': ξ='+_measure(station['relative_xi_mm'])+'; x='+_measure(x)+' mm'
        box=draw.textbbox((0,0),label,font=small);w=box[2]-box[0]
        draw.text((max(24,min(1576-w,xp-w/2)),286+(i%2)*28),label,font=small,fill=red)
    draw.text((32,460),'Translação ilustrativa a = '+_measure(data['translation_mm'])+' mm; curso declarado: '+_measure(data['travel_min_mm'])+' a '+_measure(data['travel_max_mm'])+' mm.',font=font,fill=blue)
    if len(data['stations'])>1:
        pitch=data['stations'][-1]['relative_xi_mm']-data['stations'][0]['relative_xi_mm']
        draw.text((32,502),'Distância entre estações extremas do trem: '+_measure(pitch)+' mm. Rodas de lados opostos coincidem nesta projeção.',font=small,fill=gray)
    draw.text((32,544),'A figura usa as coordenadas reais/adotadas dos apoios; não presume uma malha regular.',font=small,fill=gray)
    draw.text((32,584),'Vínculos e coordenadas transversais estão na tabela. Esquema de análise, não detalhamento de fabricação.',font=small,fill=gray)
    output=BytesIO();im.save(output,format='PNG');return output.getvalue()


def nbr_fatigue_section(component,physical,title='7b. Fadiga NBR 8400-2, vida classificada finita'):
    """Independent nominal classified-life result; never an invented cycle count."""
    from dataclasses import asdict,is_dataclass
    from .report import fmt
    data=asdict(physical) if is_dataclass(physical) else physical
    duty=data['duty'];detail=data['detail'];method=data['method'];fm=data['flange_material'];wm=data['web_material']
    rows=[]
    for row in (component or {}).get('point_results',[]):
        plane=row.get('input',{}).get('plane',{})
        bound=row.get('bound') or {}
        point=str(plane.get('point_id',''));parts=point.split('/')
        region_label={'top_flange_uniform_nominal_wall_face_bound':'Mesa superior, global nominal','bottom_flange_uniform_nominal_wall_face_bound':'Mesa inferior, global nominal','web_uniform_nominal_wall_face_bound':'Alma, global nominal',
            'top_uniform_fixed_material_point_bound':'Mesa superior, modelo nominal adotado',
            'bottom_uniform_fixed_material_point_bound':'Mesa inferior, modelo nominal adotado',
            'web_uniform_fixed_material_point_bound':'Alma, modelo nominal adotado'}.get(point)
        if region_label is None:
            location=next((v for v in parts if v.startswith('P') and v[1:].isdigit()),'ponto nominal')
            side='esquerdo' if 'left' in parts else 'direito' if 'right' in parts else ''
            region_label=('Mesa inferior, global + local' if 'bottom_flange' in point else 'Mesa superior, nominal' if 'top_flange' in point else 'Alma, nominal')+' · '+location+(' · '+side if side else '')
        face={'top':'superior','bottom':'inferior','both_nominal_wall_faces':'ambas as faces nominais','left':'esquerda','right':'direita'}.get(plane.get('face'),'face nominal declarada')
        rows.append({'Região / ponto':region_label,
            'Plano / face':str(plane.get('plane',''))+' / '+face,
            'Interação D.5: Q ≤ 1':fmt(bound.get('Q_upper_bound')),
            'Utilização equivalente':_pct(bound.get('combined_utilization_upper_bound')),
            'Situação':_status(row)})
    return dict(criterion='family_nbr_fatigue',title=title,paragraphs=[
        'Verificação pendente / não executada.' if component is None else _status(component)+'.',
        ('Grupo NBR do componente: '+duty['component_group']+'.' if duty['classification_kind']=='manual_code_selection' else
         ('E8 adotado conservadoramente como requisito de projeto, não classificação derivada de ciclos.' if duty['classification_kind']=='adopted_conservative_E8' else 'Grupo do componente documentado: '+duty['component_group']+'.')+' Fonte: '+duty['classification_source']),
        'Fonte: ABNT NBR 8400-2:2019, versão corrigida de 20.10.2022: ações de fadiga do caso I (§5.6), tabelas de resistência do Anexo D e interação planar da equação D.5 (§D.2.3). A composição nominal global/local da viga é identificada na fonte do modelo abaixo. Não é previsão de ciclos até ruptura.',
        _rolling_action_text(component),
        *(['Guiamento adotado: duas estações simples, com contatos opostos no mesmo nível de transferência, sem truques longitudinais, guias laterais separadas ou pré-cargas laterais internas. Origem: '+str(data['rolling_guidance']['guidance_source'])] if data.get('rolling_guidance') else []),
        *(['Guiamento adotado: quatro rodas flangeadas, duas estações longitudinais e duas vias, sem truques ou guias laterais separadas. Origem: '+str(component['rolling_guidance']['geometry_source'])] if (component or {}).get('rolling_guidance', {}).get('model')=='four_wheel_flange_contacts_no_bogies_or_separate_guides' else []),
        'Detalhe W0 de material-base laminado ordinário, sem entalhes: '+detail['construction_detail_source']+'. Requisito de fabricação/inspeção '+('h6 com controle de qualidade' if detail['fabrication_requirement']=='specified_h6_qc' else 'h6')+': '+detail['fabrication_source']+'. Esta declaração não afirma inspeção executada.',
        'Material '+fm['material_grade']+'; fy / fu = '+_measure(fm['fy_mpa'])+' / '+_measure(fm['fu_mpa'])+' MPa; espessuras mesa / alma = '+_measure(fm['thickness_mm'])+' / '+_measure(wm['thickness_mm'])+' mm, derivadas do perfil e material validados. Fonte: '+fm['material_source'],
        'Redução conservadora explícita da resistência com κ = −1: '+method['adoption_source']+'. Os limites de tensões não são apresentados como história real concomitante.',
        'Modelo nominal: '+data['nominal_model_source']+'. As regiões ordinárias cobertas são identificadas na tabela.'],rows=rows)


def beam_support_section(component):
    """Scalar beam-region checks, never a suspension-connection approval."""
    labels={'top':'Mesa superior','bottom':'Mesa inferior'}
    verdict={'CALCULATED':'Geometria calculada','NO_ADDITIONAL_HOLE_LIMIT':'Sem redução adicional por este critério',
        'PASS_COMPONENT':'Critério escalar atendido','FAIL_COMPONENT':'Falha identificada',
        'INCONCLUSIVE_BOUND':'Seção não comprovada pelo limite suficiente',
        'BEAM_CHECK_NOT_QUALIFIED':'Verificação não qualificada'}
    rows=[]
    coverage=(component.get('physical_input_summary') or {}).get('hole_inventory_coverage',{})
    for flange,net in component.get('net_sections',{}).items():
        rows.append({'Região / critério':labels.get(flange,flange)+' · área bruta / líquida',
            'Demanda':'—','Limite / geometria':_measure(net.get('gross_area_mm2'))+' / '+_measure(net.get('net_area_mm2')),
            'Unidade':'mm²','Situação':verdict.get(net.get('status'),'Geometria não estabelecida')})
    for item in component.get('bending_checks',[]):
        region=item['checked_region_mm']
        for check in item['result'].get('checks',[]):
            rows.append({'Região / critério':labels.get(check.get('major_bending_tension_flange'),'Mesa')+' · x '+_measure(region['start_mm'])+' a '+_measure(region['end_mm'])+' mm',
                'Demanda':_measure(check.get('demand')/1e6) if check.get('demand') is not None else '—',
                'Limite / geometria':_measure(check.get('resistance')/1e6) if check.get('resistance') is not None else '—',
                'Unidade':'kN·m','Situação':verdict.get(check.get('status'),'Verificação não qualificada')})
    for item in component.get('transverse_capacities',[]):
        for key,label in (('flange_bending','Flexão local da mesa'),('web_yielding','Escoamento local da alma')):
            value=item.get('capacities',{}).get(key,{}).get('resistance_N')
            rows.append({'Região / critério':str(item['id'])+' · '+label,'Demanda':'Não recuperada',
                'Limite / geometria':_measure(value/1000) if value is not None else '—','Unidade':'kN',
                'Situação':'Capacidade informativa, sem comparação'})
    physical=(component.get('physical_input_summary') or {}).get('physical_input') or {}
    geometry=[]
    fabrication={'drilled':'broqueado','punched':'puncionado','thermal_cut':'cortado termicamente','unknown':'fabricação não informada'}
    for flange in ('top','bottom'):
        inventory=physical.get(flange+'_holes')
        if inventory is None:
            geometry.append(labels[flange]+': inventário de furos desconhecido.')
            continue
        geometry.append(labels[flange]+': inventário declarado de x = '+_measure(inventory['x_start_mm'])+' a '+_measure(inventory['x_end_mm'])+' mm; '+str(len(inventory['holes']))+' furo(s). Fonte: '+inventory['inventory_source'])
        for h in inventory['holes']:
            dimensions=('diâmetro '+_measure(h['major_mm']) if h['shape']=='round' else 'oblongo '+_measure(h['major_mm'])+' × '+_measure(h['minor_mm']))
            geometry.append(str(h['id'])+': x = '+_measure(h['x_mm'])+' mm, y = '+_measure(h['y_mm'])+' mm; '+dimensions+' mm; '+fabrication[h['manufacturing']]+'.')
    if physical:
        geometry.append('Coeficiente de resistência γa1 = '+_measure(physical['gamma_a1'])+'. Fonte: '+physical['factor_source'])
    known=all(row.get('whole_flange_inventory_known') for row in coverage.values()) if coverage else False
    return dict(criterion='beam_support',title='Informação fora do escopo: região de suspensão',paragraphs=[
        'Seção informativa opcional, FORA DO ESCOPO da conclusão nominal de viga. A ligação viga-piso e a região local de introdução da reação permanecem NÃO VERIFICADAS; resultados escalares e falhas conhecidas abaixo são preservados, sem aprovação desses detalhes.',
        'Resultado escalar informado: '+_status(dict(status=component.get('scalar_bending_status', 'PENDING'), actual_failure_proven=component.get('actual_failure_proven', False)))+'.',
        'ABNT NBR 8800:2024 + Errata 1:2025: caminhos líquidos (§5.2.4), limite escalar de flexão da mesa tracionada com furos (§5.4.2.6) e capacidades centradas (§§5.7.2–3). Os dados são físicos; as demandas de flexão vêm das mesmas bases mecânicas verificadas, sem esforços externos.',
        'Inventário de furos completo nos dois trechos de mesa declarados.' if known else 'Inventário parcial ou desconhecido: nenhum trecho sem informação foi presumido íntegro.',
        *geometry,
        'O sinal do momento identifica a mesa tracionada na parcela de flexão maior. A comparação usa um limite suficiente no trecho documentado, não um corte crítico físico inventado; os demais esforços e interações não são dispensados.',
        'Região local de suspensão: FORA DO ESCOPO, NÃO VERIFICADA. O campo elástico local da reação, sua interação e a fadiga da região perturbada pertencem à avaliação separada. As verificações escalares não supõem pressão uniforme da reação do grupo nem aprovam a região completa.',
        'Parafusos, contato/prying da ligação, receptor e piso não são dimensionados nesta memória.'],rows=rows)
