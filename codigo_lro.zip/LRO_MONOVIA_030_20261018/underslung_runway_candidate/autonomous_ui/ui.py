"""Isolated autonomous underslung Streamlit adapter, N/mm/MPa.

Importing this module never starts Streamlit or calculations. The physical form
is empty by default, apart from the user-adopted 3000 mm position spacing.
There are no external resultants/stresses or Robot-result inputs in this route.
"""
from __future__ import annotations

from copy import deepcopy
from dataclasses import asdict
import gzip
import json
import math
from pathlib import Path
from typing import Mapping

# Streamlit executes file entrypoints outside their package; keep imports local.
if not __package__:
    import sys
    sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
    __package__ = 'underslung_runway_candidate.autonomous_ui'

from ..autonomous_workflow.project import (
    AutonomousUnderslungProject, physical_wheel, top_suspension_point, make_bridge_reaction_ledger,
)
from ..autonomous_workflow.model import suspension_grid, signature, checked_text, PhysicalWheel
from ..autonomous_workflow.bridge_reactions import BridgeReactionInputs, generate_bridge_reactions
from ..autonomous_workflow.inertia_bridge_adapter import BridgeInertiaInputs, generate_inertia_configurations, make_ledger as make_inertia_ledger
from ..section_stress.recovery import ISection
from .family_inputs import blank_family_inputs, physical_family_options, service_project_limits, render_family_inputs
from .support_inputs import blank_beam_support_inputs, physical_beam_support_inputs, render_beam_support_inputs


def calculation_payload(payload):
    """Document identity is not a physical or numerical calculation input."""
    return {key: value for key, value in payload.items()
            if key not in ('document_metadata', 'project_label')}

DOFS = ('ux', 'uy', 'uz', 'phi', 'theta_y', 'theta_z', 'chi')
UNSELECTED = 'Não informado'
FREE = 'Livre'
FIXED = 'Restrito a zero'
IDEAL_FORK_NAME = 'Forquilha ideal adotada; ancoragem axial somente na primeira suspensão'
IDEAL_FORK_REQUIREMENT = (
    'A suspensão a detalhar e fornecer deve efetivamente impedir uy, uz e phi, '
    'com ux impedido apenas na primeira suspensão. theta_y, theta_z e chi '
    'permanecem livres. Verificar caminho de carga, rigidez, resistência, '
    'parafusos, efeito alavanca e viga receptora antes de aceitar a ligação. '
    'A adoção deste modelo não comprova a ligação nem a estabilidade real.'
)
HORIZONTAL_ACTION_BASIS = (
    'Hx/Hy são ações características individuais já com os efeitos e a dinâmica horizontal aplicáveis ao cenário normal adotado. '
    'Os mesmos valores são adotados nos estados carregado e vazio. O gerador aplica seus fatores próprios e reverte direções globais; '
    'não deriva H da capacidade e não multiplica silenciosamente o psi vertical em H. Esta adoção não reconstrói o histórico real de cargas.'
)
GEOMETRY_FIELDS = {
    'd_mm': 'Altura total d [mm]', 'bf_mm': 'Largura das mesas b [mm]',
    'tf_mm': 'Espessura das mesas t [mm]', 'tw_mm': 'Espessura da alma tw [mm]',
    'bottom_root_radius_mm': 'Raio de concordância inferior r [mm]',
}
BRIDGE_NUMERIC_FIELDS = {
    'capacity_t': 'Capacidade nominal de carga útil [t métricas], sem massa retida',
    'bridge_span_mm': 'Vão da ponte entre as duas vias [mm], não espaçamento de suspensão',
    'bridge_mass_kg': 'Massa da ponte e cabeceiras, sem carro [kg]',
    'bridge_cg_from_left_mm': 'CG da ponte desde a via esquerda [mm]',
    'trolley_mass_kg': 'Massa do carro [kg]',
    'hook_min_from_left_mm': 'Gancho: posição mínima desde a via esquerda [mm]',
    'hook_max_from_left_mm': 'Gancho: posição máxima desde a via esquerda [mm]',
    'trolley_cg_minus_hook_mm': 'CG do carro menos posição do gancho [mm]',
    'carriage_station_spacing_mm': 'Distância longitudinal entre estações de rodas [mm]',
    'contact_n_mm': 'Centro de contato à borda livre n [mm]',
    'bridge_acceleration_m_s2': 'Aceleração longitudinal assinada da ponte [m/s²]',
    'trolley_acceleration_m_s2': 'Aceleração transversal assinada do carro [m/s²]',
    'horizontal_dynamic_factor': 'Amplificação horizontal adicional adotada [-], não psi vertical',
    'longitudinal_left_rail_fraction': 'Fração de Hx transmitida à via esquerda [0 a 1]',
    'transverse_left_rail_fraction': 'Fração de Hy transmitida à via esquerda [0 a 1]',
    'gravity_m_s2': 'Gravidade para conversão massa → peso [m/s²]',
}
BRIDGE_SOURCE_FIELDS = {
    'geometry_mass_source': 'Base das massas, geometria e inclusão de moitão/acessórios na capacidade',
    'equalization_source': 'Base da equalização das quatro rodas por via',
    'acceleration_source': 'Base das acelerações e sinais',
    'horizontal_factor_source': 'Base da amplificação horizontal',
    'horizontal_transfer_source': 'Base da transferência horizontal entre vias e rodas',
}
INERTIA_NUMERIC_FIELDS = {
    **{k: label for k,label in BRIDGE_NUMERIC_FIELDS.items() if k not in ('bridge_cg_from_left_mm', 'longitudinal_left_rail_fraction', 'transverse_left_rail_fraction')},
    'bridge_cg_x_mm': 'CG ponte: ξ longitudinal desde o centro do trem [mm]',
    'bridge_cg_y_mm': 'CG ponte: y desde a via esquerda [mm]',
    'bridge_cg_z_mm': 'CG ponte: z desde o plano de contatos [mm], assinado',
    'trolley_cg_x_mm': 'CG carro: ξ longitudinal desde o centro do trem [mm]',
    'trolley_cg_z_mm': 'CG carro: z desde o plano de contatos [mm], assinado',
    'lifted_cg_x_mm': 'CG carga: ξ longitudinal desde o centro do trem [mm]',
    'lifted_cg_z_min_mm': 'CG carga: z mínimo desde o plano de contatos [mm], assinado',
    'lifted_cg_z_max_mm': 'CG carga: z máximo desde o plano de contatos [mm], assinado',
    'suspension_point_x_mm': 'Ponto de transferência abaixo do carro: ξ desde o centro do trem [mm]',
    'suspension_point_z_mm': 'Ponto de transferência abaixo do carro: z desde o plano de contatos [mm]',
}
COMMON_MASS_NUMERIC_FIELDS = {
    'retained_suspended_mass_kg': 'Massa suspensa retida no vazio [kg], inclusive zero',
    'retained_suspended_cg_x_mm': 'CG da massa retida guiada: ξ desde o centro do trem [mm]',
    'retained_suspended_cg_z_mm': 'CG da massa retida guiada: z desde o plano de contatos [mm]',
}
COMMON_MASS_CONVENTIONS = {
    'payload_plus_retained_suspended_mass': 'Carga útil nominal + massa suspensa retida separada',
    'legacy_all_lifted_removed_when_empty': 'Legado: toda parcela içada removida no vazio; massa retida desconhecida',
}
COMMON_RETAINED_CG_FIELDS = ('retained_suspended_cg_x_mm','retained_suspended_cg_z_mm')
INERTIA_TRANSFER_MODELS = {
    'free_suspended_at_crab': 'Carga livre por cabos: força equivalente imediatamente abaixo do carro',
    'guided_rigid_payload_cg': 'Carga guiada ou rígida: transferência pelo CG físico da carga',
}
GUIDED_CG_FIELDS = ('lifted_cg_x_mm', 'lifted_cg_z_min_mm', 'lifted_cg_z_max_mm')
FREE_TRANSFER_FIELDS = ('suspension_point_x_mm', 'suspension_point_z_mm')

def active_inertia_numeric_fields(raw):
    transfer=raw.get('transfer_model')
    excluded = GUIDED_CG_FIELDS if transfer == 'free_suspended_at_crab' else FREE_TRANSFER_FIELDS
    if transfer not in INERTIA_TRANSFER_MODELS: excluded = GUIDED_CG_FIELDS + FREE_TRANSFER_FIELDS
    return {key:label for key,label in INERTIA_NUMERIC_FIELDS.items() if key not in excluded}

INERTIA_SOURCE_FIELDS = {
    'geometry_mass_cg_source': 'Origem das massas, geometria e centros de massa',
    'acceleration_dynamic_source': 'Origem das acelerações e amplificação horizontal',
    'equalization_source': 'Origem do modelo de transferência equalizado/bilinear',
    'force_transfer_source': 'Origem e adoção da transferência da força içada',
}
FATIGUE_NUMERIC_FIELDS = {
    'dynamic_equipment': 'Dinâmica EN da parcela G do equipamento [-], >= 1',
    'dynamic_lifted': 'Dinâmica EN da parcela Q içada [-], >= 1',
    'gamma_ff': 'Fator EN de ação de fadiga gamma_Ff [-], >= 1',
    'gamma_mf': 'Fator EN de resistência à fadiga gamma_Mf [-], >= 1,35',
    'gamma_mser': 'Fator EN de serviço gamma_Mser [-], >= 1',
}
FATIGUE_VERTICAL_MODELS = {
    'quasistatic_suspended_gravity_plus_horizontal': 'Carga suspensa quase estática mais manobras horizontais',
    'source_bounded_vertical_dynamics': 'Dinâmica vertical com limites mínimos declarados e fonte',
}
FATIGUE_MINIMUM_FIELDS = {
    'minimum_equipment_gravity': 'Fator mínimo da gravidade do equipamento [-]',
    'minimum_lifted_gravity': 'Fator mínimo da gravidade da carga içada [-]',
}
FATIGUE_ENUMS = {
    'detail_delivery': ('EN10163-3_C3_no_weld_repair', 'Região laminada EN 10163-3 classe C3, sem reparo por solda'),
    'assessed_plain_region_condition': ('ordinary_unmodified_undamaged_rolled_plain_regions_excluding_discontinuities', 'Regiões laminadas ordinárias avaliadas íntegras e não modificadas, excluídas descontinuidades'),
    'environment': ('normal_atmosphere_maintained_no_galvanizing_no_weathering', 'Atmosfera normal, manutenção prevista, sem galvanização nem aço patinável'),
}
FATIGUE_SOURCE_FIELDS = ('action_source', 'fixed_train_operating_limit_source', 'detail_condition_source',
                         'environment_source', 'execution_source', 'nominal_method_adoption_source')
INERTIA_ROUTE = 'bridge_inertia'
BRIDGE_ROUTE = 'bridge_capacity'
MANUAL_ROUTE = 'manual_wheels'
BRIDGE_LIMITS = (
    'As quatro configurações são alternativas correlacionadas: dois extremos do gancho × duas vias. '
    'Não são quatro pontes simultâneas e nenhuma é escolhida como pior universal. G/Q são reações somente gravitacionais. '
    'Hx/Hy vêm das massas, acelerações, amplificação e partilhas explicitamente adotadas, com valores diferentes em carregado e vazio. '
    'Alturas dos centros de massa, redistribuição vertical por inércia, mecanismo de tração/frenagem, efeitos de rolamento e transientes não são determinados aqui.'
)
MATERIAL_FIELDS = {
    'E_mpa': 'Módulo E [MPa]', 'nu': 'Coeficiente de Poisson nu [-]',
    'density_kg_m3': 'Massa específica [kg/m³]',
}


class InputValidationError(ValueError):
    def __init__(self, errors):
        self.errors = tuple(dict.fromkeys(errors))
        super().__init__('; '.join(self.errors))


def blank_inputs():
    """Unknown is None/blank, never a physical default or a hidden zero."""
    return {
        **blank_family_inputs(),
        'identity': 'actual_project', 'project_label': '', 'length_mm': None,
        'section': {k: None for k in GEOMETRY_FIELDS}, 'section_source': '',
        'material': {**{k: None for k in MATERIAL_FIELDS}, 'source': '', 'fy_mpa': None, 'fu_mpa': None, 'material_ratio_confirmed': False},
        'extra_dead_N_per_mm': None, 'extra_dead_source': '', 'extra_dead_kind': None,
        'extra_dead_y_mm': None, 'extra_dead_z_mm': None,
        'travel_min_mm': None, 'travel_max_mm': None, 'travel_source': '',
        'support_grid_spacing_mm': 3000.0,
        'support_grid_source': 'Espaçamento de suspensão de 3 m adotado pelo usuário; não define comprimento nem vínculos.',
        'supports': [], 'wheels': [], 'action_input_route': INERTIA_ROUTE,
        'bridge_inputs': blank_bridge_inputs(), 'inertia_inputs': blank_inertia_inputs(), 'bridge_application': None,
        'bridge_source_mode': None, 'bridge_source_detail': '',
        'horizontal_action_basis_adopted': False, 'ideal_fork_adopted': False,
        'ideal_fork_requirement_acknowledged': False,
        'actions': {'psi': None, 'equipment_group': None, 'classification_source': ''},
        'source_notes': '', 'supplementary_en_resistance_gamma': None, 'supplementary_en_source': '',
        'en_fatigue_enabled': False, 'en_fatigue_inputs': blank_fatigue_inputs(),
        'fatigue_source_mode': None, 'fatigue_source_detail': '', 'fatigue_fixed_train_adopted': False,
        'contact_enabled':False, 'contact_inputs':blank_contact_inputs(), 'contact_source_mode':None, 'contact_source_detail':'',
        'service_enabled':False, 'service_inputs':blank_service_inputs(), 'service_source_mode':None, 'service_source_detail':'',
        'beam_support_enabled': False, 'beam_support_physical_inputs': blank_beam_support_inputs(),
    }


def blank_bridge_inputs():
    """Only standard gravity is supplied; all crane-specific values stay unknown."""
    return {**{k: None for k in BRIDGE_NUMERIC_FIELDS},
            **{k: '' for k in BRIDGE_SOURCE_FIELDS}, 'gravity_m_s2': 9.80665,
            'equalized_four_wheels_per_rail_adopted': False,
            'point_force_transfer_adopted': False}


def blank_fatigue_inputs():
    return {**{key: None for key in FATIGUE_NUMERIC_FIELDS}, **{key: None for key in FATIGUE_ENUMS},
            **{key: '' for key in FATIGUE_SOURCE_FIELDS}, 'vertical_operating_model': None,
            **{key: None for key in FATIGUE_MINIMUM_FIELDS}, 'minimum_gravity_source': ''}


def physical_fatigue_inputs(payload):
    if payload.get('en_fatigue_enabled') is not True: return None
    from ..fatigue.autonomous_adapter import ENPhysicalFatigueInputs
    raw=payload.get('en_fatigue_inputs',{})
    allowed=set(FATIGUE_NUMERIC_FIELDS)|set(FATIGUE_ENUMS)|set(FATIGUE_SOURCE_FIELDS)|set(FATIGUE_MINIMUM_FIELDS)|{'vertical_operating_model','minimum_gravity_source'}
    if isinstance(raw,dict) and 'physical_detail_condition' in raw:
        raise ValueError('Declaração anterior limitada à mesa inferior: revisar explicitamente as regiões ordinárias avaliadas; não há migração automática para uma região mais ampla.')
    if not isinstance(raw,dict) or set(raw)-allowed:
        raise ValueError('Fadiga EN aceita somente dados físicos; campos de prova numérica externos não são aceitos.')
    if payload.get('fatigue_fixed_train_adopted') is not True:
        raise ValueError('Declarar o limite operacional ao trem/configuração informados para a rota nominal de fadiga.')
    data={key:number(raw.get(key),label,positive=True) for key,label in FATIGUE_NUMERIC_FIELDS.items()}
    for key,(token,label) in FATIGUE_ENUMS.items():
        if raw.get(key)!=token:raise ValueError('Fadiga EN: declarar condição física aplicável: '+label)
        data[key]=token
    model=raw.get('vertical_operating_model')
    if model not in FATIGUE_VERTICAL_MODELS:raise ValueError('Fadiga EN: selecionar explicitamente o domínio físico de operação vertical.')
    data['vertical_operating_model']=model
    for key,label in FATIGUE_MINIMUM_FIELDS.items():
        if model=='source_bounded_vertical_dynamics':data[key]=number(raw.get(key),label)
        elif raw.get(key) is not None:raise ValueError('O preset quase estático não admite sobreposição de fatores mínimos.')
        else:data[key]=None
    data['minimum_gravity_source']=checked_text(raw.get('minimum_gravity_source',''),'Base dos mínimos de gravidade',required=model=='source_bounded_vertical_dynamics')
    data.update({key:text_required(raw.get(key),'Fadiga EN / '+key) for key in FATIGUE_SOURCE_FIELDS})
    return asdict(ENPhysicalFatigueInputs(**data).validate())


def blank_inertia_inputs():
    return {**{k: None for k in INERTIA_NUMERIC_FIELDS},
            **{k: '' for k in INERTIA_SOURCE_FIELDS}, 'gravity_m_s2': 9.80665,
            'equalized_bilinear_model_adopted': False, 'point_force_transfer_adopted': False, 'transfer_model': None,
            'mass_accounting_convention':None, **{k:None for k in COMMON_MASS_NUMERIC_FIELDS},
            'retained_mass_excluded_from_equipment':None, 'suspended_mass_source':''}


def bridge_source_ledger(mode, detail=''):
    """Source selection records what was declared, not a verified catalog fact."""
    if mode not in ('Informado pelo usuário', 'Catálogo de referência', 'Premissa adotada'):
        raise ValueError('Selecionar a origem dos dados; não é necessário escrever uma justificativa para cada campo.')
    detail = checked_text(detail, 'Referência dos dados da ponte', required=False).strip()
    if mode == 'Catálogo de referência' and not detail:
        raise ValueError('Identificar o catálogo/documento de referência da ponte.')
    origin = 'Premissa adotada como requisito de projeto/fornecimento' if mode == 'Premissa adotada' else mode
    base = origin + ': valores físicos declarados no formulário, sem certificação independente' + ('; ' + detail if detail else '')
    return dict(geometry_mass_source=base + '; composição da massa/capacidade conforme declaração do usuário',
                equalization_source=base + '; arranjo de quatro rodas por via e equalização adotados explicitamente',
                acceleration_source=base + '; acelerações assinadas para inércia nominal m*a',
                horizontal_factor_source=base + '; amplificação horizontal adicional declarada, independente do psi vertical',
                horizontal_transfer_source=base + '; frações entre vias e partilha igual entre as quatro rodas adotadas; mecanismo real pendente')


def bridge_preview(payload):
    """Recompute all correlated states from physical input, never edited reactions."""
    geom = payload.get('section', {})
    if not isinstance(geom, dict) or set(geom) - set(GEOMETRY_FIELDS):
        raise ValueError('Geometria explícita e somente os campos de perfil aceitos são necessários.')
    section = ISection(**{k: number(geom.get(k), label, positive=True) for k, label in GEOMETRY_FIELDS.items()}, construction='rolled')
    inertia = payload.get('action_input_route') == INERTIA_ROUTE
    numeric = INERTIA_NUMERIC_FIELDS if inertia else BRIDGE_NUMERIC_FIELDS
    sources = INERTIA_SOURCE_FIELDS if inertia else BRIDGE_SOURCE_FIELDS
    adopted = ('equalized_bilinear_model_adopted' if inertia else 'equalized_four_wheels_per_rail_adopted', 'point_force_transfer_adopted')
    raw = payload.get('inertia_inputs' if inertia else 'bridge_inputs', {})
    allowed = set(numeric) | set(sources) | set(adopted) | ({'transfer_model','mass_accounting_convention','retained_mass_excluded_from_equipment','suspended_mass_source',*COMMON_MASS_NUMERIC_FIELDS} if inertia else set())
    if not isinstance(raw, dict) or set(raw) - allowed:
        raise ValueError('Campo desconhecido nas entradas físicas da ponte.')
    errors, data = [], {}
    if inertia:
        convention=raw.get('mass_accounting_convention')
        if convention not in COMMON_MASS_CONVENTIONS:
            raise ValueError('Revisar e declarar a composição comum das massas suspensas; entradas antigas não são convertidas e massa retida desconhecida não é zero.')
        data['mass_accounting_convention']=convention
        data['retained_mass_excluded_from_equipment']=raw.get('retained_mass_excluded_from_equipment')
        data['suspended_mass_source']=raw.get('suspended_mass_source','')
        for key,label in COMMON_MASS_NUMERIC_FIELDS.items():
            value=raw.get(key)
            try:data[key]=None if value is None or value=='' else number(value,label)
            except (ValueError,TypeError,ArithmeticError) as exc:errors.append(str(exc))
        transfer=raw.get('transfer_model')
        if transfer not in INERTIA_TRANSFER_MODELS:
            raise ValueError('Revisar e selecionar explicitamente a transferência da carga içada; entradas anteriores não são migradas automaticamente para um modelo guiado.')
        data['transfer_model']=transfer
        inactive=GUIDED_CG_FIELDS if transfer=='free_suspended_at_crab' else FREE_TRANSFER_FIELDS
        for key in inactive:
            if raw.get(key) is not None:errors.append('Campo não aplicável ao modelo selecionado deve ser None: '+key)
            data[key]=None
        numeric=active_inertia_numeric_fields(raw)
    for k, label in numeric.items():
        try: data[k] = number(raw.get(k), label)
        except (ValueError, TypeError, ArithmeticError) as exc: errors.append(str(exc))
    for k, label in sources.items():
        try: data[k] = text_required(raw.get(k), label)
        except (ValueError, TypeError, ArithmeticError) as exc: errors.append(str(exc))
    for k in adopted:
        data[k] = raw.get(k)
        if data[k] is not True: errors.append('Adotar explicitamente: ' + k)
    if errors: raise InputValidationError(errors)
    return generate_inertia_configurations(section, BridgeInertiaInputs(**data)) if inertia else generate_bridge_reactions(section, BridgeReactionInputs(**data))


def apply_bridge_configuration(payload, configuration_id):
    """Explicitly bind selection to the currently previewed physical inputs."""
    result = bridge_preview(payload)
    if configuration_id not in {c['id'] for c in result['configurations']}:
        raise ValueError('Selecionar uma configuração correlacionada válida; nenhuma é presumida governante.')
    p = deepcopy(payload)
    p['action_input_route'] = INERTIA_ROUTE if payload.get('action_input_route') == INERTIA_ROUTE else BRIDGE_ROUTE
    p['bridge_application'] = dict(configuration_id=configuration_id, input_signature=result['input_signature'])
    return p


def selected_bridge_configuration(payload):
    result = bridge_preview(payload)
    applied = payload.get('bridge_application')
    if not isinstance(applied, dict) or set(applied) != {'configuration_id', 'input_signature'}:
        raise ValueError('Conferir a prévia e aplicar deliberadamente uma configuração da ponte.')
    if applied['input_signature'] != result['input_signature']:
        raise ValueError('Entradas da ponte ou seção alteradas: conferir novamente a prévia e reaplicar a configuração.')
    selected = next((c for c in result['configurations'] if c['id'] == applied['configuration_id']), None)
    if selected is None: raise ValueError('Configuração da ponte não corresponde às entradas atuais.')
    return result, selected


def number(value, label, *, positive=False, nonnegative=False):
    if value is None or isinstance(value, bool) or (isinstance(value, str) and not value.strip()):
        raise ValueError(f'{label}: informar valor explícito, inclusive quando zero.')
    try:
        result = float(value.replace(',', '.')) if isinstance(value, str) else float(value)
    except (TypeError, ValueError, ArithmeticError):
        raise ValueError(f'{label}: número inválido.') from None
    if not math.isfinite(result) or abs(result) > 1e18:
        raise ValueError(f'{label}: informar número finito no domínio numérico.')
    if positive and result <= 0 or nonnegative and result < 0:
        raise ValueError(f'{label}: valor fora do domínio permitido.')
    return result


def text_required(value, label):
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f'{label}: informar fonte ou adoção identificada.')
    return checked_text(value.strip(), label)


def position_grid_rows(count, *, start_mm=0.0):
    """Generate adopted 3 m positions only; no physical length or DOF inference."""
    start = number(start_mm, 'Coordenada inicial')
    return [dict(id=s['id'], x_mm=s['x'] + start, y_mm=None,
                 **{d: UNSELECTED for d in DOFS}, provenance='')
            for s in suspension_grid(count, spacing_mm=3000.0)]


def apply_ideal_fork(rows):
    """An explicit user action, not an automatic consequence of the 3 m grid."""
    result = deepcopy(rows)
    for i, row in enumerate(result):
        row.update({d: FREE for d in DOFS})
        row.update(uy=FIXED, uz=FIXED, phi=FIXED, ux=FIXED if i == 0 else FREE)
        row['provenance'] = 'Modelo ideal adotado explicitamente: ' + IDEAL_FORK_NAME
    return result


def _support(section, row, index):
    label = f'Suspensão {index + 1}'
    restrain = {}
    for d in DOFS:
        state = row.get(d)
        if state not in (FREE, FIXED):
            raise ValueError(f'{label}: selecionar explicitamente {d} como livre ou restrito a zero.')
        if state == FIXED:
            restrain[d] = 0.0
    if not restrain:
        raise ValueError(f'{label}: nenhum vínculo selecionado; não é ponto de suspensão ativo.')
    return top_suspension_point(
        section, id=text_required(row.get('id'), label + ' / identificação'),
        x_mm=number(row.get('x_mm'), label + ' / x', nonnegative=True),
        y_mm=number(row.get('y_mm'), label + ' / y na mesa superior'),
        restrain=restrain, provenance=text_required(row.get('provenance'), label + ' / modelo de apoio'),
    )


def _wheel(section, row, index):
    label = f'Roda {index + 1}'
    return physical_wheel(
        section, id=text_required(row.get('id'), label + ' / identificação'),
        offset_mm=number(row.get('offset_mm'), label + ' / posição longitudinal'),
        outstand_side=row.get('outstand_side'),
        edge_to_contact_n_mm=number(row.get('edge_to_contact_n_mm'), label + ' / n', positive=True),
        dead_N=number(row.get('dead_N'), label + ' / G', nonnegative=True),
        lifted_N=number(row.get('lifted_N'), label + ' / Q', nonnegative=True),
        longitudinal_N=number(row.get('longitudinal_N'), label + ' / Hx'),
        transverse_N=number(row.get('transverse_N'), label + ' / Hy'),
        provenance=text_required(row.get('provenance'), label + ' / ações e geometria'),
        point_force_transfer_adopted=row.get('point_force_transfer_adopted') is True,
    )


def build_project(payload, *, max_element_length_mm=500.0):
    """Validate physical input before creating the internal model.

    Catalogue names and 3 m spacing never infer dimensions, span or restraints.
    The alternative capacity route requires all masses, geometry and sharing
    premises, then regenerates the selected configuration internally.
    """
    errors = []
    try:
        checked_text(payload.get('project_label', ''), 'Identificação', required=False)
    except (ValueError, ArithmeticError) as exc:
        errors.append(str(exc))
    identity = payload.get('identity')
    if identity not in ('actual_project', 'synthetic_fixture'):
        errors.append('Identidade explícita de projeto real ou teste sintético obrigatória.')
    try:
        spacing = number(payload.get('support_grid_spacing_mm'), 'Espaçamento adotado', positive=True)
        if spacing != 3000.0:
            raise ValueError('Esta rota adota somente espaçamento nominal de suspensão de 3000 mm.')
    except (ValueError, ArithmeticError) as exc:
        errors.append(str(exc))
    route = payload.get('action_input_route', MANUAL_ROUTE)
    if route not in (MANUAL_ROUTE, BRIDGE_ROUTE, INERTIA_ROUTE):
        errors.append('Selecionar rota explícita de ações individuais ou capacidade da ponte.')
    if route == MANUAL_ROUTE and payload.get('horizontal_action_basis_adopted') is not True:
        errors.append('Adotar explicitamente a base de Hx/Hy individuais, inclusive seu uso nos estados carregado e vazio.')
    if payload.get('ideal_fork_adopted') and not payload.get('ideal_fork_requirement_acknowledged'):
        errors.append('Modelo de forquilha ideal exige aceitação explícita do requisito de detalhamento e fornecimento.')
    geom = payload.get('section', {})
    if set(geom) - set(GEOMETRY_FIELDS):
        errors.append('Esta interface aceita somente a geometria laminada simétrica declarada; campos adicionais ou mesas desiguais não são descartados silenciosamente.')
    section = None
    parsed = {}
    for k, label in GEOMETRY_FIELDS.items():
        try:
            parsed[k] = number(geom.get(k), label, positive=True)
        except (ValueError, ArithmeticError) as exc:
            errors.append(str(exc))
    if len(parsed) == len(GEOMETRY_FIELDS):
        try:
            section = ISection(**parsed, construction='rolled')
        except (ValueError, ArithmeticError) as exc:
            errors.append(str(exc))
    scalars = {}
    for key, value, label, positive, nonnegative in (
        ('length_mm', payload.get('length_mm'), 'Comprimento físico total', True, False),
        ('extra_dead_N_per_mm', payload.get('extra_dead_N_per_mm'), 'Carga permanente adicional', False, True),
        *[(k, payload.get('material', {}).get(k), label, k != 'nu', False) for k, label in MATERIAL_FIELDS.items()],
    ):
        try:
            scalars[key] = number(value, label, positive=positive, nonnegative=nonnegative)
        except (ValueError, ArithmeticError) as exc:
            errors.append(str(exc))
    if 'nu' in scalars and not -1 < scalars['nu'] < .5:
        errors.append('Coeficiente de Poisson deve estar entre -1 e 0,5.')
    sources = {}
    for key, value, label in (
        ('section_source', payload.get('section_source'), 'Geometria do perfil'),
        ('material_source', payload.get('material', {}).get('source'), 'Material'),
        ('extra_dead_source', payload.get('extra_dead_source'), 'Carga permanente adicional, inclusive zero'),
        ('support_grid_source', payload.get('support_grid_source'), 'Espaçamento de suspensões'),
    ):
        try:
            sources[key] = text_required(value, label)
        except (ValueError, ArithmeticError) as exc:
            errors.append(str(exc))
    supports, wheels, bridge_ledger = [], [], None
    if not payload.get('supports'):
        errors.append('Informar os pontos reais/adotados de suspensão na mesa superior e seus vínculos.')
    if route == MANUAL_ROUTE and not payload.get('wheels'):
        errors.append('Informar cada roda física, sua geometria e suas ações individuais G, Q, Hx e Hy.')
    if section:
        collections = [(supports, _support, 'supports')]
        if route == MANUAL_ROUTE: collections.append((wheels, _wheel, 'wheels'))
        for collection, make, key in collections:
            for i, row in enumerate(payload.get(key, [])):
                try:
                    collection.append(make(section, row, i))
                except (ValueError, TypeError, ArithmeticError) as exc:
                    errors.append(str(exc))
    if section and route in (BRIDGE_ROUTE, INERTIA_ROUTE):
        try:
            receipt, selected = selected_bridge_configuration(payload)
            wheels = [PhysicalWheel(**row) for row in selected['wheels']]
            ledger_builder = make_inertia_ledger if route == INERTIA_ROUTE else make_bridge_reaction_ledger
            bridge_ledger = ledger_builder(section, receipt['inputs'], selected['id'])
        except (ValueError, TypeError, ArithmeticError) as exc:
            errors.append(str(exc))
    try: en_fatigue = physical_fatigue_inputs(payload)
    except (ValueError,TypeError,ArithmeticError) as exc:
        en_fatigue=None;errors.append(str(exc))
    try: contact_inputs=physical_contact_inputs(payload,wheels)
    except (ValueError,TypeError,ArithmeticError) as exc:
        contact_inputs=None;errors.append(str(exc))
    try: service_inputs=physical_service_inputs(payload)
    except (ValueError,TypeError,ArithmeticError) as exc:
        service_inputs=None;errors.append(str(exc))
    optional = {}
    for key in ('fy_mpa', 'fu_mpa'):
        value = payload.get('material', {}).get(key)
        try:
            optional[key] = None if value is None or value == '' else number(value, key, positive=True)
        except (ValueError, ArithmeticError) as exc:
            errors.append(str(exc))
    for key in ('travel_min_mm', 'travel_max_mm', 'extra_dead_y_mm', 'extra_dead_z_mm', 'supplementary_en_resistance_gamma'):
        value = payload.get(key)
        try:
            optional[key] = None if value is None or value == '' else number(value, key)
        except (ValueError, ArithmeticError) as exc:
            errors.append(str(exc))
    extra_kind = payload.get('extra_dead_kind')
    if scalars.get('extra_dead_N_per_mm', 0) > 0 and not extra_kind:
        errors.append('Classificar a origem da permanente adicional antes de gerar seus fatores.')
    if errors:
        raise InputValidationError(errors)
    project = AutonomousUnderslungProject(
        section=section, supports=supports, wheels=wheels, bridge_reaction_ledger=bridge_ledger,
        capacity_tf=bridge_ledger['inputs']['capacity_t'] if bridge_ledger else None,
        en_fatigue_inputs=en_fatigue, contact_inputs=contact_inputs, service_inputs=service_inputs, **scalars, **optional,
        travel_source=payload.get('travel_source', ''),
        supplementary_en_source=payload.get('supplementary_en_source', ''),
        material_ratio_confirmed=payload.get('material', {}).get('material_ratio_confirmed', False),
        extra_dead_kind=extra_kind or 'steel_or_equipment',
        material_source=sources['material_source'], extra_dead_source=sources['extra_dead_source'],
        support_grid_spacing_mm=3000.0, support_grid_source=sources['support_grid_source'],
        max_element_length_mm=number(max_element_length_mm, 'Malha máxima', positive=True),
        actual_project=identity == 'actual_project',
        source_notes='Geometria: ' + sources['section_source'] + '; ' + str(payload.get('source_notes', ''))
        + ('; ' + IDEAL_FORK_REQUIREMENT if payload.get('ideal_fork_adopted') else ''),
    )
    try:
        return project.validate()
    except (ValueError, ArithmeticError) as exc:
        raise InputValidationError([str(exc)]) from exc


def action_options(payload):
    actions = payload.get('actions', {})
    psi = number(actions.get('psi'), 'Fator dinâmico psi', positive=True)
    group = actions.get('equipment_group')
    if group not in tuple(f'A{i}' for i in range(1, 9)):
        raise InputValidationError(['Selecionar grupo de equipamento A1 a A8 com base identificada.'])
    source = text_required(actions.get('classification_source'), 'Classificação e dinâmica')
    return dict(psi=psi, equipment_group=group, classification_source=source)


def synthetic_fixture():
    """Small, conspicuously synthetic fixture, never a named real project."""
    p = blank_inputs()
    p.update(identity='synthetic_fixture', action_input_route=MANUAL_ROUTE, project_label='TESTE SINTÉTICO: viga 3 m / par oposto',
             length_mm=3000.0,
             section=dict(d_mm=300., bf_mm=150., tf_mm=12., tw_mm=8., bottom_root_radius_mm=8.),
             section_source='SYNTHETIC geometric test, no manufacturer or real-project identity',
             material=dict(E_mpa=200000., nu=.3, density_kg_m3=7850., fy_mpa=250., fu_mpa=400., material_ratio_confirmed=False, source='SYNTHETIC elastic steel constants and strengths'),
             extra_dead_N_per_mm=0., extra_dead_source='SYNTHETIC explicit zero accessories', extra_dead_kind='steel_or_equipment',
             travel_min_mm=300., travel_max_mm=2700., travel_source='SYNTHETIC test limits, every wheel remains on runway',
             ideal_fork_adopted=True, ideal_fork_requirement_acknowledged=True, horizontal_action_basis_adopted=True,
             source_notes='SYNTHETIC fixture only. No actual project dimensions, wheel actions or restraints asserted.',
             actions=dict(psi=1.3, equipment_group='A5', classification_source='SYNTHETIC adopted normal-operation factors'))
    p['supports'] = apply_ideal_fork(position_grid_rows(2))
    for s in p['supports']:
        s['y_mm'] = 0.
        s['provenance'] = 'SYNTHETIC explicitly adopted ideal fork, top flange centreline'
    p['wheels'] = [dict(id=side.upper(), offset_mm=0., outstand_side=side,
                        edge_to_contact_n_mm=15., dead_N=500., lifted_N=4500.,
                        longitudinal_N=0., transverse_N=0.,
                        provenance='SYNTHETIC individual wheel, explicit equal opposed pair',
                        point_force_transfer_adopted=True) for side in ('left', 'right')]
    return p


def _editor_records(frame, template):
    """Empty editor cells are unknown, not JSON NaN or invented physical data."""
    rows = frame.astype(object).where(frame.notna(), None).to_dict('records')
    for row in rows:
        for key, default in template.items():
            if row.get(key) is None and isinstance(default, (str, bool)):
                row[key] = default
    return [row for row in rows if row != template]


def _text_number(st, label, value, *, key):
    return st.text_input(label, value='' if value is None else str(value), key=key)


def _render_bridge_inputs(st, p, form_key, state_key, revision_key, revision):
    st.caption(BRIDGE_LIMITS)
    st.caption('Capacidade em toneladas de massa, não tf. Informar onde entram moitão e acessórios. O vão entre vias não é o vão longitudinal da viga nem a malha de suspensões de 3 m. Valores zero também precisam ser declarados.')
    raw = p.setdefault('bridge_inputs', blank_bridge_inputs())
    core = ('capacity_t', 'bridge_span_mm', 'bridge_mass_kg', 'trolley_mass_kg',
            'hook_min_from_left_mm', 'hook_max_from_left_mm', 'carriage_station_spacing_mm', 'contact_n_mm')
    cols = st.columns(2)
    for i, key in enumerate(core):
        raw[key] = _text_number(cols[i % 2], BRIDGE_NUMERIC_FIELDS[key], raw.get(key), key='ua_bridge_' + key + '_' + form_key)
    with st.expander('Detalhes físicos: centros de massa, acelerações e transferência horizontal', expanded=False):
        st.caption('Campos necessários para gerar H sem inventar o mecanismo. Fração à direita = 1 menos a fração à esquerda. A gravidade padrão é declarada; não é dado medido do equipamento.')
        cols = st.columns(2)
        for i, key in enumerate(k for k in BRIDGE_NUMERIC_FIELDS if k not in core):
            raw[key] = _text_number(cols[i % 2], BRIDGE_NUMERIC_FIELDS[key], raw.get(key), key='ua_bridge_' + key + '_' + form_key)
    modes = [None, 'Informado pelo usuário', 'Catálogo de referência', 'Premissa adotada']
    p['bridge_source_mode'] = st.selectbox('Origem dos dados e premissas da ponte', modes,
        index=modes.index(p.get('bridge_source_mode')), format_func=lambda mode: 'Selecionar origem' if mode is None else mode,
        key='ua_bridge_source_mode_' + form_key)
    p['bridge_source_detail'] = st.text_input('Referência do catálogo (obrigatória nessa opção) ou observação opcional',
        value=p.get('bridge_source_detail', ''), key='ua_bridge_source_detail_' + form_key)
    try:
        raw.update(bridge_source_ledger(p['bridge_source_mode'], p['bridge_source_detail']))
    except (ValueError, TypeError, ArithmeticError) as exc:
        raw.update({k: '' for k in BRIDGE_SOURCE_FIELDS})
        st.info(str(exc))
    raw['equalized_four_wheels_per_rail_adopted'] = st.checkbox(
        'Adoto duas estações longitudinais, cada uma com duas rodas opostas: quatro rodas equalizadas por via, com partilha horizontal nominal igual.',
        value=raw.get('equalized_four_wheels_per_rail_adopted', False), key='ua_bridge_equalized_' + form_key)
    raw['point_force_transfer_adopted'] = st.checkbox(
        'Adoto forças pontuais nos contatos inferiores e projeção setorial nominal, sem comprovação de contato finito.',
        value=raw.get('point_force_transfer_adopted', False), key='ua_bridge_transfer_' + form_key)
    try:
        receipt = bridge_preview(p)
    except (ValueError, TypeError, ArithmeticError) as exc:
        st.info('Prévia da ponte ainda indisponível: ' + str(exc))
        return
    st.write('Prévia: estados correlacionados do gancho e da via selecionada')
    st.dataframe([{
        'Configuração': c['id'], 'Gancho desde esquerda [mm]': c['hook_from_left_mm'],
        'CG carro desde esquerda [mm]': c['trolley_cg_from_left_mm'],
        'Gancho desde via selecionada [mm]': c['hook_from_selected_rail_mm'],
        'G na via [N]': c['gravity_rail_reactions']['dead_G_N'],
        'Q na via [N]': c['gravity_rail_reactions']['lifted_Q_N'],
        'Hx carregado [N]': c['horizontal_rail_actions']['loaded']['Fx_N'],
        'Hy carregado [N]': c['horizontal_rail_actions']['loaded']['Fy_N'],
        'Hx vazio [N]': c['horizontal_rail_actions']['empty']['Fx_N'],
        'Hy vazio [N]': c['horizontal_rail_actions']['empty']['Fy_N'],
    } for c in receipt['configurations']], hide_index=True)
    st.caption('A soma das duas vias e seus momentos fecham o equilíbrio gravitacional de cada extremo. O balanço horizontal é independente: a tabela abaixo informa o momento adicional que o mecanismo precisaria transmitir.')
    st.dataframe([{
        'Extremo': e['id'], 'Estado': state, 'Transferência adicional de Mz [N.mm]': h['required_additional_yaw_transfer_Nmm'],
        'Mz fechado sem transferência adicional': h['yaw_balance_without_additional_transfer'],
    } for e in receipt['endpoint_receipts'] for state, h in e['horizontal'].items()], hide_index=True)
    if any(not h['yaw_balance_without_additional_transfer'] for e in receipt['endpoint_receipts'] for h in e['horizontal'].values()):
        st.warning('Há resíduo de momento horizontal: as frações adotadas não demonstram equilíbrio completo da ponte. A transferência adicional indicada permanece fora deste modelo nominal.')
    options = [None] + [c['id'] for c in receipt['configurations']]
    applied = p.get('bridge_application') or {}
    current = applied.get('configuration_id')
    selection = st.selectbox('Configuração a aplicar à viga desta via', options,
        index=options.index(current) if current in options else 0,
        format_func=lambda value: 'Selecionar deliberadamente' if value is None else value,
        key='ua_bridge_configuration_' + form_key)
    if st.button('Aplicar configuração correlacionada da ponte', disabled=selection is None, key='ua_apply_bridge'):
        p.update(apply_bridge_configuration(p, selection))
        st.session_state[state_key] = p
        st.session_state[revision_key] = revision + 1
        st.rerun()
    if applied.get('input_signature') == receipt['input_signature'] and current in options[1:]:
        selected = next(c for c in receipt['configurations'] if c['id'] == current)
        st.success('Configuração aplicada: ' + current + '. Somente este trem entra no cálculo; demais configurações não são cobertas por esta execução.')
        st.dataframe([{'Roda': w['id'], 'Offset [mm]': w['offset_mm'], 'G [N]': w['dead_N'], 'Q [N]': w['lifted_N'],
                       'Hx carregado [N]': w['longitudinal_N'], 'Hy carregado [N]': w['transverse_N'],
                       'Hx vazio [N]': w['longitudinal_empty_N'], 'Hy vazio [N]': w['transverse_empty_N']}
                      for w in selected['wheels']], hide_index=True)
    else:
        st.warning('Nenhuma configuração aplicada às entradas atuais. Conferir e aplicar a prévia antes de calcular.')


def _render_common_suspended_mass(st, raw, form_key):
    st.write('Composição comum das massas suspensas')
    values=[None]+list(COMMON_MASS_CONVENTIONS)
    value=raw.get('mass_accounting_convention')
    raw['mass_accounting_convention']=st.selectbox('Convenção da capacidade e da massa retida',values,
        index=values.index(value) if value in values else 0,
        format_func=lambda v:'Selecionar explicitamente, sem presumir massa retida nula' if v is None else COMMON_MASS_CONVENTIONS[v],
        key='ua_common_mass_convention_'+form_key)
    if raw['mass_accounting_convention']=='legacy_all_lifted_removed_when_empty':
        st.warning('Entrada legada preservada: a parcela içada inteira sai no vazio. A massa real retida é desconhecida, não igual a zero; essa entrada não documenta a composição completa da carga suspensa.')
        return
    st.caption('Capacidade nominal é somente carga útil. Moitão e acessórios que permanecem suspensos compõem uma parcela separada, presente no carregado e no vazio. Não incluir essa parcela na massa da ponte nem do carro.')
    raw['retained_suspended_mass_kg']=_text_number(st,COMMON_MASS_NUMERIC_FIELDS['retained_suspended_mass_kg'],raw.get('retained_suspended_mass_kg'),key='ua_common_retained_mass_'+form_key)
    if raw.get('transfer_model')=='guided_rigid_payload_cg':
        for key in COMMON_RETAINED_CG_FIELDS:
            raw[key]=_text_number(st,COMMON_MASS_NUMERIC_FIELDS[key],raw.get(key),key='ua_common_'+key+'_'+form_key)
    elif any(raw.get(key) is not None for key in COMMON_RETAINED_CG_FIELDS):
        st.warning('O modelo por cabos livres não usa CG separado da massa retida. Remova explicitamente os valores anteriores para usar o ponto de suspensão declarado.')
        if st.button('Remover CG retido do modelo guiado anterior',key='ua_common_clear_retained_cg_'+form_key):
            for key in COMMON_RETAINED_CG_FIELDS:raw[key]=None
    else:
        st.caption('Cabos livres: a parcela retida usa o mesmo ponto de suspensão declarado abaixo do carro, nunca um CG arbitrário da carga.')
    options=[None,True]
    current=raw.get('retained_mass_excluded_from_equipment')
    raw['retained_mass_excluded_from_equipment']=st.selectbox('Separação da massa retida da ponte e do carro',options,
        index=options.index(current) if current in options else 0,
        format_func=lambda v:'Não declarado' if v is None else 'Massa retida separada, sem dupla contagem',key='ua_common_mass_excluded_'+form_key)
    raw['suspended_mass_source']=st.text_input('Fonte da massa suspensa retida, acessórios, CG e exclusão das massas do equipamento',value=raw.get('suspended_mass_source',''),key='ua_common_mass_source_'+form_key)


def _render_inertia_inputs(st, p, form_key, state_key, revision_key, revision):
    st.caption('Modelo de oito contatos físicos: forças e momentos de gravidade e inércia são equilibrados internamente, incluindo redistribuição vertical assinada. A hipótese bilinear/equalizada não certifica o equipamento real.')
    st.caption('Coordenadas da ponte: ξ longitudinal desde o centro entre as estações; y desde a via esquerda; z positivo para cima desde o plano comum de contato. A posição física na viga é x = a + ξ, com a sendo a translação do trem. Nenhuma altura ou centro de massa é presumido.')
    raw = p.setdefault('inertia_inputs', blank_inertia_inputs())
    transfer_options=[None]+list(INERTIA_TRANSFER_MODELS)
    raw['transfer_model']=st.selectbox('Transferência física da carga içada',transfer_options,
        index=transfer_options.index(raw.get('transfer_model')) if raw.get('transfer_model') in transfer_options else 0,
        format_func=lambda value:'Selecionar o mecanismo, sem inferência automática' if value is None else INERTIA_TRANSFER_MODELS[value],
        key='ua_inertia_transfer_model_'+form_key)
    free=raw['transfer_model']=='free_suspended_at_crab'
    if raw['transfer_model'] in INERTIA_TRANSFER_MODELS:
        for key in (GUIDED_CG_FIELDS if free else FREE_TRANSFER_FIELDS):raw[key]=None
    if free:
        st.caption('EN 13001-2, 4.2.2.5: a carga livre por cabos é representada imediatamente abaixo do carro. Informar o ponto equivalente x/z; não usar o CG profundo da carga nem inferir a altura do carro. A elevação real da carga não varia esse ponto neste modelo.')
    elif raw['transfer_model']=='guided_rigid_payload_cg':
        st.caption('Alternativa limitada a carga guiada ou rigidamente transferida. O CG físico e sua faixa de altura precisam representar o caminho de força adotado; não aplicar a uma carga livre por cabos.')
    else:
        st.info('Escolher o mecanismo antes de informar coordenadas de transferência. Entradas antigas exigem revisão explícita.')
    _render_common_suspended_mass(st,raw,form_key)
    core = ('capacity_t', 'bridge_span_mm', 'bridge_mass_kg', 'trolley_mass_kg',
            'hook_min_from_left_mm', 'hook_max_from_left_mm', 'carriage_station_spacing_mm', 'contact_n_mm')
    cols = st.columns(2)
    for i,key in enumerate(core):
        raw[key] = _text_number(cols[i % 2], INERTIA_NUMERIC_FIELDS[key], raw.get(key), key='ua_inertia_' + key + '_' + form_key)
    with st.expander('Centros de massa, alturas e dinâmica: dados físicos necessários', expanded=False):
        st.caption('Os centros de massa precisam ficar dentro do retângulo entre as estações e as vias. Informar zero deliberadamente quando aplicável. Os extremos de altura são alternativas, não cargas simultâneas.')
        cols = st.columns(2)
        for i,key in enumerate(k for k in active_inertia_numeric_fields(raw) if k not in core):
            raw[key] = _text_number(cols[i % 2], INERTIA_NUMERIC_FIELDS[key], raw.get(key), key='ua_inertia_' + key + '_' + form_key)
    modes = [None, 'Informado pelo usuário', 'Catálogo de referência', 'Premissa adotada']
    p['bridge_source_mode'] = st.selectbox('Origem dos dados e premissas da ponte', modes,
        index=modes.index(p.get('bridge_source_mode')), format_func=lambda mode: 'Selecionar origem' if mode is None else mode,
        key='ua_inertia_source_mode_' + form_key)
    p['bridge_source_detail'] = st.text_input('Referência do catálogo (obrigatória nessa opção) ou observação opcional',
        value=p.get('bridge_source_detail', ''), key='ua_inertia_source_detail_' + form_key)
    try:
        sources = bridge_source_ledger(p['bridge_source_mode'],p['bridge_source_detail'])
        raw.update(geometry_mass_cg_source=sources['geometry_mass_source'] + '; centros de massa e alturas assinados explicitamente',
                   acceleration_dynamic_source=sources['acceleration_source'] + '; ' + sources['horizontal_factor_source'],
                   equalization_source=(sources['geometry_mass_source'] + '; modelo bilinear/equalizado explicitamente adotado, sem autoesforço diagonal adicional de tombamento; compatibilidade física a demonstrar'),
                   force_transfer_source=sources['geometry_mass_source']+'; '+INERTIA_TRANSFER_MODELS.get(raw.get('transfer_model'),'transferência ainda não selecionada')+'; coordenadas declaradas no referencial comum')
    except (ValueError, TypeError, ArithmeticError) as exc:
        raw.update({k: '' for k in INERTIA_SOURCE_FIELDS});st.info(str(exc))
    raw['equalized_bilinear_model_adopted'] = st.checkbox(
        'Adoto o modelo bilinear/equalizado de oito contatos e zero autoesforço diagonal adicional de tombamento; a compatibilidade do mecanismo real precisa ser demonstrada.',
        value=raw.get('equalized_bilinear_model_adopted',False),key='ua_inertia_equalized_' + form_key)
    raw['point_force_transfer_adopted'] = st.checkbox('Adoto forças pontuais nos contatos inferiores e projeção setorial nominal, sem comprovação de contato finito.',
        value=raw.get('point_force_transfer_adopted',False),key='ua_inertia_transfer_' + form_key)
    try:receipt = bridge_preview(p)
    except (ValueError, TypeError, ArithmeticError) as exc:
        st.info('Prévia 3D ainda indisponível: ' + str(exc));return
    st.write('Prévia: registros correlacionados de gancho, transferência e via')
    if free:st.caption('Os dois registros de altura coincidem: não representam variação do CG da carga livre. São mantidos para identidade e rastreabilidade das configurações.')
    st.dataframe([{'Configuração':c['id'],'Gancho [mm]':c['hook_from_left_mm'],'z de aplicação da força [mm]':c['lifted_force_application_z_mm'],
                   'G do equipamento na via [N]':sum(w['dead_N'] for w in c['wheels']),'Q removível na via [N]':sum(w['lifted_N'] for w in c['wheels']),
                   'B retida na via [N]':sum(w.get('retained_lifted_N',0.) for w in c['wheels']) if raw.get('mass_accounting_convention')=='payload_plus_retained_suspended_mass' else None,
                   'Hx carregado [N]':sum(w['longitudinal_N'] for w in c['wheels']),
                   'Hy carregado [N]':sum(w['transverse_N'] for w in c['wheels'])} for c in receipt['configurations']],hide_index=True)
    st.caption('Cada parcela conserva força e momento nos oito contatos. A análise de cada caso precisa verificar perda de contato em ambas as vias; equilíbrio não significa resistência, tração ou equalização reais comprovadas.')
    st.dataframe([{'Estado geométrico':e['id'],'Equilíbrio das parcelas':all(v['balanced'] for v in e['generated']['equilibrium']),
                   'Maior resíduo de força [N]':max(abs(x) for v in e['generated']['equilibrium'] for x in v['residual']['force_N']),
                   'Maior resíduo de momento [N.mm]':max(abs(x) for v in e['generated']['equilibrium'] for x in v['residual']['moment_Nmm'])}
                  for e in receipt['endpoint_receipts']],hide_index=True)
    st.caption('Para o cálculo principal, confirme os dados de toda a família. A primeira identidade serve apenas de referência interna, nunca de pior configuração; todas as oito são regeneradas e verificadas.')
    if st.button('Confirmar dados de todas as configurações', key='ua_apply_inertia_family'):
        p.update(apply_bridge_configuration(p, receipt['configurations'][0]['id']))
        st.session_state[state_key] = p
        st.session_state[revision_key] = revision+1
        st.rerun()
    with st.expander('Diagnóstico avançado · escolher uma configuração de referência', expanded=False):
        applied=p.get('bridge_application') or {};current=applied.get('configuration_id')
        options=[None]+[c['id'] for c in receipt['configurations']]
        selection=st.selectbox('Configuração a aplicar à viga desta via',options,index=options.index(current) if current in options else 0,
            format_func=lambda value:'Selecionar deliberadamente' if value is None else value,key='ua_inertia_configuration_' + form_key)
        if st.button('Aplicar configuração correlacionada da ponte',disabled=selection is None,key='ua_apply_inertia'):
            p.update(apply_bridge_configuration(p,selection));st.session_state[state_key]=p
            st.session_state[revision_key]=revision+1;st.rerun()
        if applied.get('input_signature')==receipt['input_signature'] and current in options[1:]:
            c=next(c for c in receipt['configurations'] if c['id']==current)
            st.success('Configuração de referência aplicada: '+current+'. O cálculo principal regenera toda a família; apenas o diagnóstico avançado usa esta configuração isolada.')
            st.dataframe([{'Roda':w['id'],'Offset [mm]':w['offset_mm'],'G / Q [N]':f"{w['dead_N']:.3f} / {w['lifted_N']:.3f}",
                           'Hx / Hy [N]':f"{w['longitudinal_N']:.3f} / {w['transverse_N']:.3f}",
                           'Fz de Hx / Hy [N]':f"{w['longitudinal_vertical_N']:.3f} / {w['transverse_vertical_N']:.3f}"} for w in c['wheels']],hide_index=True)
            st.caption('As parcelas verticais de H permanecem separadas de G/Q e acompanham o mesmo fator e sinal da ação horizontal, inclusive no vazio. A tabela mostra o estado carregado; o registro completo retém ambos.')
        else:st.warning('Nenhuma referência física aplicada às entradas atuais. Conferir e aplicar antes de calcular a família.')


def _render_fatigue_inputs(st,p,form_key):
    p['en_fatigue_enabled']=st.checkbox('Calcular também o método suficiente nominal EN 1993-1-9:2025',
        value=p.get('en_fatigue_enabled',False),key='ua_fatigue_enabled_'+form_key)
    if not p['en_fatigue_enabled']:return
    st.caption('Avalia separadamente regiões ordinárias da mesa superior/alma por efeitos globais e da mesa inferior por efeitos globais e locais. Furos, regiões perturbadas, introdução local de carga, ligações, emendas e fadiga de contato permanecem excluídos. Não exige tensões externas nem caixas de confirmação de prova numérica.')
    st.caption('As dinâmicas EN de G/Q devem ser declaradas, sem copiar psi NBR silenciosamente. O programa calcula internamente as bases e sua convergência. Critério suficiente não satisfeito não significa ruptura por fadiga nem determina vida útil.')
    raw=p.setdefault('en_fatigue_inputs',blank_fatigue_inputs())
    if 'physical_detail_condition' in raw:
        st.warning('Declaração antiga cobria apenas a região inferior. A nova avaliação inclui também regiões ordinárias da mesa superior/alma e exige revisão explícita, sem migrar a declaração anterior.')
        if st.button('Descartar declaração antiga e revisar as regiões avaliadas',key='ua_fatigue_region_review_'+form_key):
            raw.pop('physical_detail_condition');raw['assessed_plain_region_condition']=None
    vertical_options=[None]+list(FATIGUE_VERTICAL_MODELS)
    raw['vertical_operating_model']=st.selectbox('Domínio físico de operação vertical para fadiga',vertical_options,
        index=vertical_options.index(raw.get('vertical_operating_model')) if raw.get('vertical_operating_model') in vertical_options else 0,
        format_func=lambda value:'Selecionar o domínio físico' if value is None else FATIGUE_VERTICAL_MODELS[value],key='ua_fatigue_vertical_'+form_key)
    bounded=raw['vertical_operating_model']=='source_bounded_vertical_dynamics'
    if raw['vertical_operating_model']=='quasistatic_suspended_gravity_plus_horizontal':
        for key in FATIGUE_MINIMUM_FIELDS:raw[key]=None
        st.caption('Adoção quase estática explícita: mínimo G = 0,95, pela vibração do equipamento EN 13001-2; mínimo Q = 1 para gravidade suspensa mais H. Exclui aceleração vertical descendente arbitrária, alívio/liberação e reversão de içamento.')
    elif bounded:
        st.caption('Declarar mínimos de G/Q entre zero e seus máximos dinâmicos. Os mínimos não são deduzidos dos máximos. A origem escolhida abaixo registra a base dos limites físicos.')
    cols=st.columns(2)
    numeric=dict(FATIGUE_NUMERIC_FIELDS,**(FATIGUE_MINIMUM_FIELDS if bounded else {}))
    for i,(key,label) in enumerate(numeric.items()):
        raw[key]=_text_number(cols[i%2],label,raw.get(key),key='ua_fatigue_'+key+'_'+form_key)
    for key,(token,label) in FATIGUE_ENUMS.items():
        raw[key]=st.selectbox(label,[None,token],index=1 if raw.get(key)==token else 0,
            format_func=lambda value:'Não informado / fora deste domínio' if value is None else 'Condição física declarada ou requisito explicitamente adotado',key='ua_fatigue_'+key+'_'+form_key)
    p['fatigue_fixed_train_adopted']=st.checkbox('Limito esta avaliação à família física declarada (ou à configuração, no diagnóstico), massas, acelerações e curso informados; outros equipamentos não estão implicitamente cobertos.',
        value=p.get('fatigue_fixed_train_adopted',False),key='ua_fatigue_train_'+form_key)
    modes=[None,'Informado pelo usuário','Catálogo de referência','Premissa adotada']
    p['fatigue_source_mode']=st.selectbox('Origem dos dados/requisitos físicos para fadiga',modes,index=modes.index(p.get('fatigue_source_mode')),
        format_func=lambda mode:'Selecionar origem' if mode is None else mode,key='ua_fatigue_source_mode_'+form_key)
    p['fatigue_source_detail']=st.text_input('Referência do catálogo (se aplicável) ou observação dos requisitos de fadiga',value=p.get('fatigue_source_detail',''),key='ua_fatigue_source_detail_'+form_key)
    raw['execution_source']=st.text_input('Base de execução/inspeção da região avaliada: documento ou requisito aplicável',value=raw.get('execution_source',''),key='ua_fatigue_execution_'+form_key)
    try:
        base=bridge_source_ledger(p['fatigue_source_mode'],p['fatigue_source_detail'])['geometry_mass_source']
        raw.update(action_source=base+'; fatores dinâmicos EN de G/Q declarados separadamente e H físico já inclui sua dinâmica',
                   fixed_train_operating_limit_source=base+'; adoção expressa de operação limitada à família física declarada ou à configuração do diagnóstico e ao curso físico deste projeto',
                   detail_condition_source=base+'; condição expressamente declarada das regiões laminadas ordinárias avaliadas, excluídos furos, introduções locais de carga, regiões perturbadas e ligações',
                   environment_source=base+'; condição ambiental e manutenção declaradas para esta região',
                   nominal_method_adoption_source='EN 1993-1-9:2025, método nominal suficiente independente; '+base,
                   minimum_gravity_source=(base+'; limites mínimos de gravidade G/Q explicitamente declarados para o domínio de operação vertical' if bounded else ''))
    except (ValueError,TypeError,ArithmeticError) as exc:
        for key in FATIGUE_SOURCE_FIELDS:
            if key!='execution_source':raw[key]=''
        st.info(str(exc))


CONTACT_OPERATING_NUMBERS = {
    'hoist_speed_max_m_s':'Velocidade máxima de içamento [m/s]',
    'test_static_ratio':'Razão de massa no ensaio estático [-]',
    'test_dynamic_ratio':'Razão de massa no ensaio dinâmico [-]',
    'risk_coefficient':'Coeficiente de risco EN adotado [-]',
    'life_cycles':'Ciclos de operação na vida de projeto [inteiro]',
    'loaded_travel_legs_per_cycle':'Percursos monotônicos carregados por ciclo [inteiro]',
    'empty_travel_legs_per_cycle':'Percursos monotônicos vazios por ciclo [inteiro]',
    'travel_distance_per_leg_mm':'Distância máxima por percurso [mm]',
    'stationary_load_cycles_per_cycle':'Flutuações de carga estacionárias por ciclo [inteiro]',
}
CONTACT_INTEGER_FIELDS = {'life_cycles','loaded_travel_legs_per_cycle','empty_travel_legs_per_cycle','stationary_load_cycles_per_cycle','tolerance_class'}
CONTACT_WHEEL_NUMBERS = {
    'hardness_HBW':'Dureza HBW da roda', 'verified_depth_mm':'Profundidade com dureza declarada na roda [mm]',
    'E_MPa':'Módulo elástico da roda [MPa]', 'wheel_diameter_mm':'Diâmetro da roda [mm]',
    'wheel_material_width_mm':'Largura material da roda [mm]', 'wheel_corner_radius_mm':'Raio de canto da roda [mm]',
    'crown_radius_mm':'Raio de coroamento da roda [mm]',
    'lateral_min_toward_web_mm':'Deslocamento lateral mínimo para a alma [mm]',
    'lateral_max_toward_web_mm':'Deslocamento lateral máximo para a alma [mm]',
    'guide_slack_skew_rad':'Desalinhamento por folga de guia [rad]', 'wear_skew_rad':'Desalinhamento por desgaste [rad]',
}
CONTACT_MOUNTINGS = {'self_aligning':'Autoalinhante', 'nonaligning_elastic_support':'Não autoalinhante com apoio elástico', 'nonaligning_rigid_support':'Não autoalinhante com apoio rígido'}
CONTACT_OPERATING_DOMAIN='indoor_smooth_track_no_release_no_impacts_normal_and_tests'
CONTACT_MASS_SCOPE='payload_plus_retained_common_ledger'


def blank_contact_inputs():
    from dataclasses import fields
    from ..contact.autonomous_adapter import SCHEMA, ContactOperatingLimits, FlangeContactMaterial
    def blank(cls):return {f.name:('' if f.name.endswith('_source') else None) for f in fields(cls)}
    return dict(schema=SCHEMA,operating=blank(ContactOperatingLimits),flange=blank(FlangeContactMaterial),wheels=[])


def blank_contact_wheel():
    from dataclasses import fields
    from ..contact.autonomous_adapter import WheelContactPhysical
    return {f.name:('' if f.name.endswith('_source') or f.name=='wheel_id' else None) for f in fields(WheelContactPhysical)}


def _contact_number(value,label,key):
    value=number(value,label)
    if key in CONTACT_INTEGER_FIELDS:
        if value!=int(value):raise ValueError(label+': informar inteiro, sem arredondamento automático.')
        return int(value)
    return value


def physical_contact_inputs(payload,wheels):
    if payload.get('contact_enabled') is not True:return None
    from ..contact.autonomous_adapter import physical_from_dict, SCHEMA, ContactOperatingLimits, FlangeContactMaterial, WheelContactPhysical
    from dataclasses import fields
    raw=deepcopy(payload.get('contact_inputs'))
    if not isinstance(raw,dict) or set(raw)!={'schema','operating','flange','wheels'} or raw.get('schema')!=SCHEMA:
        raise ValueError('Contrato físico estrito de contato não informado ou com campos externos.')
    for key,cls in [('operating',ContactOperatingLimits),('flange',FlangeContactMaterial)]:
        if not isinstance(raw[key],dict) or set(raw[key])!={f.name for f in fields(cls)}:
            raise ValueError(key+' must contain exactly its physical fields; no external proof or forces')
    if not isinstance(raw['wheels'],list) or any(not isinstance(row,dict) or set(row)!={f.name for f in fields(WheelContactPhysical)} for row in raw['wheels']):
        raise ValueError('Wheel records must contain exactly their physical fields; no external proof or forces')
    # Field sets are preserved; only form numeric strings are normalized.
    for key,label in CONTACT_OPERATING_NUMBERS.items():
        raw.setdefault('operating',{})[key]=_contact_number(raw.get('operating',{}).get(key),label,key)
    for key in ('hardness_HBW','verified_depth_mm'):
        raw.setdefault('flange',{})[key]=number(raw.get('flange',{}).get(key),'Mesa inferior / '+key,positive=True)
    for row in raw.get('wheels',[]):
        for key,label in CONTACT_WHEEL_NUMBERS.items():
            if key=='crown_radius_mm' and row.get(key) is None:continue
            row[key]=_contact_number(row.get(key),label,key)
        row['tolerance_class']=_contact_number(row.get('tolerance_class'),'Classe de tolerância','tolerance_class')
    physical=physical_from_dict(raw)
    if {w.wheel_id for w in physical.wheels}!={w.id for w in wheels}:
        raise ValueError('O cadastro de contato deve corresponder a cada identidade atual de roda; reaplicar ou revisar após mudar a configuração.')
    return physical.to_dict()


def _contact_current_ids(p):
    if p.get('action_input_route') in (BRIDGE_ROUTE,INERTIA_ROUTE):
        _,selected=selected_bridge_configuration(p)
        return [w['id'] for w in selected['wheels']]
    return [row['id'] for row in p.get('wheels',[]) if row.get('id')]


def _render_contact_hardware(st,raw,key,base):
    tread_options=[None,'cylindrical','crowned']
    current='crowned' if raw.get('crown_radius_mm') is not None else None
    tread=st.selectbox('Forma física da banda de rolamento',tread_options,index=tread_options.index(current),
        format_func=lambda value:{None:'Não informada','cylindrical':'Cilíndrica, sem coroamento','crowned':'Coroada, raio explicitamente informado'}[value],key=key+'_tread')
    if tread=='cylindrical':raw['crown_radius_mm']=None
    columns=st.columns(2)
    shown=[(k,label) for k,label in CONTACT_WHEEL_NUMBERS.items() if k!='crown_radius_mm' or tread=='crowned']
    for i,(k,label) in enumerate(shown):raw[k]=_text_number(columns[i%2],label,raw.get(k),key=key+'_'+k)
    raw['tolerance_class']=st.selectbox('Classe de tolerância física da roda',[None,1,2,3,4],index=[None,1,2,3,4].index(raw.get('tolerance_class')),key=key+'_tol')
    options=[None]+list(CONTACT_MOUNTINGS)
    raw['mounting']=st.selectbox('Montagem física da roda',options,index=options.index(raw.get('mounting')) if raw.get('mounting') in options else 0,
        format_func=lambda v:'Não informada' if v is None else CONTACT_MOUNTINGS[v],key=key+'_mount')
    for k,label in [('driven_wheel','Roda motriz'),('abrasive_environment','Ambiente abrasivo')]:
        raw[k]=st.selectbox(label,[None,False,True],index=[None,False,True].index(raw.get(k)),format_func=lambda v:'Não informado' if v is None else ('Sim' if v else 'Não'),key=key+'_'+k)
    raw['material_state']=st.selectbox('Estado metalúrgico da roda',[None,'non_surface_hardened'],index=1 if raw.get('material_state')=='non_surface_hardened' else 0,
        format_func=lambda v:'Não informado ou fora do método' if v is None else 'Aço não endurecido superficialmente',key=key+'_material')
    for k,scope in [('hardness_source','dureza e profundidade material declaradas'),('geometry_source','dimensões e banda de rolamento declaradas'),('alignment_and_mounting_source','montagem, tolerância e deslocamentos declarados')]:
        raw[k]=(base+'; '+scope) if base else ''
    return tread is not None


def _render_contact_inputs(st,p,form_key):
    p['contact_enabled']=st.checkbox('Calcular contato roda e mesa inferior com dados físicos próprios',value=p.get('contact_enabled',False),key='ua_contact_enabled_'+form_key)
    if not p['contact_enabled']:return
    st.caption('Método EN 13001 independente. O programa gera forças e contagens a partir da ponte de oito contatos e dos limites físicos declarados; não recebe forças, espectros de pressão ou comprovantes externos. Exige a rota de ponte por inércia e o curso físico. A cobertura normal/ensaios não encerra todos os eventos A/B/C.')
    raw=p.setdefault('contact_inputs',blank_contact_inputs());op=raw['operating'];flange=raw['flange']
    modes=[None,'Informado pelo usuário','Catálogo de referência','Premissa adotada']
    mode=st.selectbox('Origem dos dados físicos de contato',modes,index=modes.index(p.get('contact_source_mode')),format_func=lambda v:'Selecionar origem' if v is None else v,key='ua_contact_source_'+form_key)
    p['contact_source_mode']=mode
    p['contact_source_detail']=st.text_input('Documento de contato ou identificação do catálogo',value=p.get('contact_source_detail',''),key='ua_contact_source_detail_'+form_key)
    try:base=bridge_source_ledger(mode,p['contact_source_detail'])['geometry_mass_source']
    except (ValueError,TypeError,ArithmeticError) as exc:base='';st.info(str(exc))
    columns=st.columns(2)
    for i,(key,label) in enumerate(CONTACT_OPERATING_NUMBERS.items()):op[key]=_text_number(columns[i%2],label,op.get(key),key='ua_contact_op_'+key+'_'+form_key)
    st.caption('Ensaios: mínimos de fonte 1,25 estático e 1,10 dinâmico, sujeitos a requisitos específicos maiores. Estes são critérios informativos; nenhum valor é preenchido automaticamente.')
    for key,token,label in [('operating_domain',CONTACT_OPERATING_DOMAIN,'Operação interna em pista lisa, sem liberação/impactos, domínio normal e ensaios'),('hoist_mass_scope',CONTACT_MASS_SCOPE,'Carga útil e massa retida do contato seguem a composição física comum')]:
        op[key]=st.selectbox(label,[None,token],index=1 if op.get(key)==token else 0,format_func=lambda v:'Não declarado' if v is None else 'Adoção física explícita',key='ua_contact_op_'+key+'_'+form_key)
    for key,scope in [('action_model_source','domínio físico normal e ensaios declarado'),('lifetime_operating_limit_source','vida de projeto, percursos máximos e ciclos estacionários declarados'),('contact_arrangement_source','arranjo das rodas conforme identidades e posições atuais do projeto')]:op[key]=(base+'; '+scope) if base else ''
    st.write('Material da mesa inferior')
    for key,label in [('hardness_HBW','Dureza HBW da mesa inferior'),('verified_depth_mm','Profundidade com dureza declarada na mesa [mm]')]:flange[key]=_text_number(st,label,flange.get(key),key='ua_contact_flange_'+key+'_'+form_key)
    flange['material_state']=st.selectbox('Estado metalúrgico da mesa inferior',[None,'non_surface_hardened'],index=1 if flange.get('material_state')=='non_surface_hardened' else 0,format_func=lambda v:'Não informado ou fora do método' if v is None else 'Aço não endurecido superficialmente',key='ua_contact_flange_state_'+form_key)
    flange['hardness_source']=(base+'; dureza e profundidade da mesa inferior declaradas, não inferidas de fy') if base else ''
    try:ids=_contact_current_ids(p)
    except (ValueError,TypeError,ArithmeticError) as exc:ids=[];st.info('Identidades das rodas ainda pendentes: '+str(exc))
    if not ids:st.info('Definir/aplicar as rodas físicas antes de cadastrar seu contato.');return
    mode=st.radio('Cadastro físico das rodas',['Aplicar hardware comum explicitamente','Editar cada roda individualmente'],key='ua_contact_hardware_mode_'+form_key)
    if mode.startswith('Aplicar'):
        common=p.setdefault('contact_common_wheel',blank_contact_wheel())
        ready=_render_contact_hardware(st,common,'ua_contact_common_'+form_key,base)
        same=st.checkbox('Adoto explicitamente os mesmos materiais, dimensões e montagem para todas as rodas atuais.',key='ua_contact_same_'+form_key)
        if st.button('Copiar cadastro comum para as rodas atuais',disabled=not (same and ready),key='ua_contact_apply_'+form_key):
            raw['wheels']=[dict(deepcopy(common),wheel_id=ident) for ident in ids]
            st.success('Cadastro copiado para '+str(len(ids))+' identidades atuais. Os campos físicos ainda são validados antes do cálculo.')
    else:
        ident=st.selectbox('Roda cujo cadastro será editado',ids,key='ua_contact_wheel_selected_'+form_key)
        row=next((w for w in raw['wheels'] if w['wheel_id']==ident),None)
        if row is None:row=dict(blank_contact_wheel(),wheel_id=ident);raw['wheels'].append(row)
        ready=_render_contact_hardware(st,row,'ua_contact_one_'+signature(ident)[:12]+'_'+form_key,base)
        # None means cylindrical only after the explicit UI shape declaration.
        if not ready:row['crown_radius_mm']='FORMA_NAO_DECLARADA'
    st.dataframe([{'Roda':w.get('wheel_id'),'HBW':w.get('hardness_HBW'),'Diâmetro [mm]':w.get('wheel_diameter_mm'),'Profundidade [mm]':w.get('verified_depth_mm'),'Montagem':w.get('mounting')} for w in raw['wheels']],hide_index=True)
    if {w.get('wheel_id') for w in raw['wheels']}!=set(ids):st.warning('Cadastro incompleto ou de outra configuração. Revisar cada identidade ou reaplicar o cadastro comum; nenhum alias é aceito.')


SERVICE_DOMAIN='indoor_smooth_track_no_release_no_impacts_normal_operation'


def blank_service_inputs():
    return dict(hoist_speed_max_m_s=None,operating_domain=None,hoist_mass_scope=None,
                method_adoption_source='',drive_source='',lateral_project_limit_adopted=None)


def physical_service_inputs(payload):
    if payload.get('service_enabled') is not True:return None
    from ..serviceability.autonomous_adapter import ENServicePhysicalInputs
    from dataclasses import fields
    raw=deepcopy(payload.get('service_inputs'))
    if not isinstance(raw,dict) or set(raw)!={f.name for f in fields(ENServicePhysicalInputs)}:
        raise ValueError('Serviço aceita somente o contrato de dados físicos, sem esforços, deslocamentos ou comprovantes externos.')
    raw['hoist_speed_max_m_s']=number(raw['hoist_speed_max_m_s'],'Velocidade física máxima de içamento para serviço')
    return asdict(ENServicePhysicalInputs(**raw).validate())


def _render_service_inputs(st,p,form_key):
    p['service_enabled']=st.checkbox('Calcular critérios de deformação do membro com casos EN internos',value=p.get('service_enabled',False),key='ua_service_enabled_'+form_key)
    if not p['service_enabled']:return
    raw=p.setdefault('service_inputs',blank_service_inputs())
    st.caption('Gera casos adicionais da configuração aplicada. Mede deslocamentos na linha real de contato em relação à corda entre suspensões no mesmo estado. Vertical: limite recomendado min(L/600, 25 mm), sem dinâmica; lateral: L/600 somente como critério análogo de projeto explicitamente adotado, com dinâmica horizontal própria. Não inferir PASS a partir dos diagramas normais.')
    st.caption('Diferença entre as duas vias, alinhamento real dos apoios, deformação local de contato, folga/deslizamento de ligações e resposta da estrutura receptora permanecem escopos separados. Exige a ponte por inércia; pode ampliar o tempo de cálculo.')
    raw['hoist_speed_max_m_s']=_text_number(st,'Velocidade máxima física de içamento para serviço [m/s]',raw.get('hoist_speed_max_m_s'),key='ua_service_speed_'+form_key)
    for key,token,label in [('operating_domain',SERVICE_DOMAIN,'Domínio normal interno em pista lisa, sem liberação nem impactos'),('hoist_mass_scope',CONTACT_MASS_SCOPE,'Carga útil e massa retida do serviço seguem a composição física comum')]:
        raw[key]=st.selectbox(label,[None,token],index=1 if raw.get(key)==token else 0,format_func=lambda v:'Não declarado' if v is None else 'Adoção física explícita',key='ua_service_'+key+'_'+form_key)
    raw['lateral_project_limit_adopted']=st.selectbox('Adotar L/600 como limite lateral análogo do projeto suspenso',[None,False,True],index=[None,False,True].index(raw.get('lateral_project_limit_adopted')),
        format_func=lambda v:'Não decidido' if v is None else ('Adotado para esta avaliação' if v else 'Não adotado; lateral permanece pendente'),key='ua_service_lateral_'+form_key)
    modes=[None,'Informado pelo usuário','Catálogo de referência','Premissa adotada']
    p['service_source_mode']=st.selectbox('Origem dos dados e critérios de serviço',modes,index=modes.index(p.get('service_source_mode')),format_func=lambda v:'Selecionar origem' if v is None else v,key='ua_service_source_'+form_key)
    p['service_source_detail']=st.text_input('Documento de serviço ou referência do catálogo',value=p.get('service_source_detail',''),key='ua_service_detail_'+form_key)
    try:
        base=bridge_source_ledger(p['service_source_mode'],p['service_source_detail'])['geometry_mass_source']
        raw['method_adoption_source']='EN 1993-6:2007 + AC:2009, 7.3, critérios de deformação do membro; '+base
        raw['drive_source']=base+'; velocidades e limites de aceleração devem cobrir os estados inicial/final da manobra normal; resposta dinâmica EN gerada internamente'
    except (ValueError,TypeError,ArithmeticError) as exc:
        raw['method_adoption_source']=raw['drive_source']='';st.info(str(exc))


def run_pipeline(project, payload, **numerical_options):
    """Late import keeps form/tests available while pipeline is evolving."""
    from ..autonomous_workflow.pipeline import run_autonomous_workflow
    return run_autonomous_workflow(project, **action_options(payload), **numerical_options)


def run_family_pipeline(project, payload, **numerical_options):
    """One workflow entrypoint; optional standards consume independent inputs."""
    from ..autonomous_workflow.family_pipeline import run_family_workflow
    from .support_inputs import physical_beam_support_inputs
    support=physical_beam_support_inputs(payload,project=project)
    return run_family_workflow(project, **action_options(payload), **physical_family_options(payload),
        beam_support_physical=support,service_project_limits=service_project_limits(payload), **numerical_options)


def build_technical_export_gzip(saved, payload):
    """Serialize the complete in-session record only after an explicit request.

    This is a documentary export, not an import route or a numerical producer.
    The caller must retain its current-input/result/source guards. Only the
    current documentary payload replaces the recorded one; no result is edited.
    """
    document = dict(saved, payload=deepcopy(payload))
    return gzip.compress(json.dumps(document, ensure_ascii=False, indent=2,
                                    allow_nan=False).encode('utf-8'), compresslevel=6, mtime=0)


def _technical_export_key(saved, payload, request_signature):
    """Cheap identity: never hash/serialize the large result to build a UI key."""
    if not saved:
        return None
    result = saved['result']
    return (result.get('result_signature'), result.get('project_signature'),
            saved.get('request_signature'), request_signature, signature(payload),
            signature(saved.get('controls')), 'technical-json-gzip-v1')


def _sync_technical_export_cache(st, cache_key, saved, payload, request_signature, *, cache_across_reruns):
    key = _technical_export_key(saved, payload, request_signature)
    cached = st.session_state.get(cache_key)
    # Only the signed family route may retain bytes between reruns, behind its
    # existing full integrity/source checks. A single diagnostic result is
    # mutable and unsigned: never treat object identity as content proof.
    if cached and (not cache_across_reruns or cached['key'] != key or not saved
                   or cached['result'] is not saved['result']):
        st.session_state.pop(cache_key, None)
    return key


def _render_technical_export(st, saved, payload, *, cache_key, export_key, file_name, widget_prefix):
    with st.expander('Avançado · evidência técnica completa', expanded=False):
        st.caption('Para guardar ou reabrir o estudo, use o JSON leve de entradas físicas. '
                   'A evidência técnica completa inclui vetores e recibos e pode ser grande; '
                   'só será gerada quando solicitada, em JSON comprimido. Não é necessária para a memória Word.')
        if st.button('Preparar evidência técnica comprimida', key=widget_prefix + '_prepare_technical_export'):
            st.session_state.pop(cache_key, None)
            try:
                with st.spinner('Preparando evidência técnica completa...'):
                    data = build_technical_export_gzip(saved, payload)
                st.session_state[cache_key] = dict(key=export_key, result=saved['result'], data=data)
            except (ValueError, TypeError, ArithmeticError, OSError) as exc:
                st.error('Evidência técnica não gerada: ' + str(exc))
        cached = st.session_state.get(cache_key)
        if cached and cached['key'] == export_key and cached['result'] is saved['result']:
            st.download_button('Baixar evidência técnica JSON comprimida', cached['data'],
                file_name=file_name, mime='application/gzip', key=widget_prefix + '_technical_download',
                on_click='ignore')


def render(st=None, *, runner=None):
    """Render as an isolated page or call from a future explicitly selected route."""
    if st is None:
        import streamlit as st
    from .report import report_sections, build_report_docx, section_schematic_svg, result_mapping, BASE_GAPS, governing_state_diagram
    from .project_io import apply_project_import, dumps_project_document
    runner = runner or run_pipeline
    state_key = 'underslung_autonomous_physical_inputs'
    if state_key not in st.session_state:
        st.session_state[state_key] = blank_inputs()
    p = deepcopy(st.session_state[state_key])
    revision_key = 'underslung_autonomous_form_revision'
    revision = st.session_state.get(revision_key, 0)
    form_key = p['identity'] + '_' + str(revision)
    st.title('Viga de rolamento suspensa | cálculo interno')
    st.caption('Rota candidata isolada · perfil I/W laminado, duplamente simétrico · N, mm e MPa')
    st.caption('Dados podem ser informados, referenciados a catálogo ou adotados como requisitos de projeto/fornecimento. '
               'Uma premissa adotada não é confirmação do fabricante; valores físicos ainda desconhecidos permanecem em branco.')
    st.info('As rodas atuam sobre a face superior da mesa inferior. As suspensões são pontos da mesa superior. '
            'O espaçamento adotado de 3 m não define o comprimento físico, os vínculos nem a resistência das ligações.')
    with st.expander('Reabrir entradas físicas de um projeto', expanded=False):
        st.caption('JSON da rota suspensa, até 8 MiB. Abrir não calcula nem aprova: somente as entradas são recuperadas; resultados e comprovantes anteriores são descartados. Entradas incompletas continuam pendentes.')
        uploaded = st.file_uploader('Selecionar projeto físico ou exportação legada suspensa JSON',
            type=['json'], key='ua_project_upload_' + str(revision))
        if st.button('Aplicar entradas do arquivo', key='ua_project_apply', disabled=uploaded is None):
            try:
                apply_project_import(st.session_state, uploaded.getvalue())
            except (ValueError, TypeError, ArithmeticError) as exc:
                st.error('Arquivo não aplicado; entradas atuais preservadas. ' + str(exc))
            else:
                st.session_state['underslung_autonomous_import_notice'] = True
                st.rerun()
    if st.session_state.pop('underslung_autonomous_import_notice', False):
        st.success('Entradas físicas reabertas. Nenhum resultado ou aprovação foi importado; revise as pendências e recalcule quando os dados estiverem completos.')
    left, right = st.columns(2)
    if left.button('Iniciar projeto vazio', key='ua_blank'):
        st.session_state[state_key] = blank_inputs()
        st.session_state[revision_key] = revision + 1
        st.session_state.pop('underslung_autonomous_result', None)
        st.session_state.pop('underslung_autonomous_family', None)
        st.rerun()
    if right.button('Carregar TESTE SINTÉTICO (não é projeto real)', key='ua_fixture'):
        st.session_state[state_key] = synthetic_fixture()
        st.session_state[revision_key] = revision + 1
        st.session_state.pop('underslung_autonomous_result', None)
        st.session_state.pop('underslung_autonomous_family', None)
        st.rerun()
    if p['identity'] == 'synthetic_fixture':
        st.warning('TESTE SINTÉTICO. Números destinados a verificação do programa, não à aprovação de uma obra.')
    p['project_label'] = st.text_input('Identificação opcional', value=p['project_label'], key='ua_project_label_' + form_key)
    with st.expander('Identificação da memória de cálculo', expanded=False):
        from lro_beams.document_metadata import DOCUMENT_FIELDS, validate_document_metadata
        metadata = dict(p.get('document_metadata') or {})
        for key, label in DOCUMENT_FIELDS.items():
            metadata[key] = st.text_input(label, value=metadata.get(key, ''), key='ua_document_'+key+'_'+form_key)
        try:
            p['document_metadata'] = validate_document_metadata(metadata)
        except ValueError as exc:
            p['document_metadata'] = metadata
            st.error(str(exc))
        st.caption('Identificação documental não altera ações ou resultados. Editá-la não exige repetir a análise; a memória exportada usa os valores atuais.')
    with st.expander('1 · Comprimento, perfil e material', expanded=True):
        p['length_mm'] = _text_number(st, 'Comprimento físico total [mm]', p['length_mm'], key='ua_length_' + form_key)
        st.caption('Perfil reto, mesas paralelas iguais. Dimensões e raio vêm do perfil efetivamente selecionado; '
                   'a rigidez é aproximada por três retângulos, sem metal de concordância.')
        cols = st.columns(3)
        for i, (k, label) in enumerate(GEOMETRY_FIELDS.items()):
            p['section'][k] = _text_number(cols[i % 3], label, p['section'].get(k), key='ua_' + k + '_' + form_key)
        p['section_source'] = st.text_input('Fonte da geometria / identificação do perfil', value=p['section_source'], key='ua_section_source_' + form_key)
        cols = st.columns(3)
        for i, (k, label) in enumerate(MATERIAL_FIELDS.items()):
            p['material'][k] = _text_number(cols[i], label, p['material'].get(k), key='ua_' + k + '_' + form_key)
        p['material']['source'] = st.text_input('Fonte do material', value=p['material']['source'], key='ua_material_source_' + form_key)
        p['extra_dead_N_per_mm'] = _text_number(st, 'Permanente adicional distribuída [N/mm], informar inclusive zero', p['extra_dead_N_per_mm'], key='ua_dead_' + form_key)
        p['extra_dead_source'] = st.text_input('Base da permanente adicional', value=p['extra_dead_source'], key='ua_extra_dead_source_' + form_key)
        st.caption('Quando a permanente adicional não é zero, informar y e z de sua linha de ação em relação ao centroide; nenhuma aplicação centrada é presumida.')
        a, b = st.columns(2)
        p['extra_dead_y_mm'] = _text_number(a, 'y da permanente adicional [mm]', p.get('extra_dead_y_mm'), key='ua_dead_y_' + form_key)
        p['extra_dead_z_mm'] = _text_number(b, 'z da permanente adicional [mm]', p.get('extra_dead_z_mm'), key='ua_dead_z_' + form_key)
        kinds = [None, 'steel_or_equipment', 'precast_or_timber', 'cast_in_place_or_permanent_thrust', 'industrial_with_in_situ_additions', 'general_construction']
        p['extra_dead_kind'] = st.selectbox('Origem da permanente adicional (necessária quando não nula)', kinds,
            index=kinds.index(p.get('extra_dead_kind')), format_func=lambda x: 'Não informado / carga zero' if x is None else x, key='ua_extra_dead_kind_' + form_key)
        st.caption('Resistências opcionais para comparação nominal: sem fy/fu, apenas a resposta mecânica é calculada; nenhum valor é presumido.')
        a, b = st.columns(2)
        for col, key in ((a, 'fy_mpa'), (b, 'fu_mpa')):
            p['material'][key] = _text_number(col, key.split('_')[0] + ' [MPa]', p['material'].get(key), key='ua_' + key + '_' + form_key)
        p['material']['material_ratio_confirmed'] = st.checkbox('Rota de aço de referência NBR 8400 §5.2.1.1.2 qualificada quando fy/fu > 0,70.', value=p['material'].get('material_ratio_confirmed', False), key='ua_material_ratio_confirmed_' + form_key)
        st.caption('Curso físico opcional do trem: informar os dois limites e sua origem. Sem limites, a análise usa o domínio computacional de entrada/saída, não o curso real nem o projeto de batentes.')
        a, b = st.columns(2)
        p['travel_min_mm'] = _text_number(a, 'Translação mínima física [mm]', p.get('travel_min_mm'), key='ua_tmin_' + form_key)
        p['travel_max_mm'] = _text_number(b, 'Translação máxima física [mm]', p.get('travel_max_mm'), key='ua_tmax_' + form_key)
        p['travel_source'] = st.text_input('Fonte dos limites de curso / batentes', value=p.get('travel_source', ''), key='ua_travel_source_' + form_key)
    with st.expander('2 · Suspensões na superfície da mesa superior', expanded=True):
        st.caption('Eixos: x longitudinal, y transversal, z para cima; rotações em radianos. '
                   'z físico e coordenada setorial são calculados da seção. Todos os sete vínculos devem ser deliberados.')
        a, b = st.columns(2)
        count = a.text_input('Número de suspensões para gerar apenas posições', value='', key='ua_count_' + form_key)
        start = b.text_input('Primeira posição x [mm]', value='', key='ua_start_' + form_key)
        if st.button('Gerar posições a cada 3000 mm, sem vínculos'):
            try:
                n = number(count, 'Número de suspensões', positive=True)
                if n != int(n):
                    raise ValueError('Número de suspensões deve ser inteiro.')
                p['supports'] = position_grid_rows(int(n), start_mm=number(start, 'Primeira posição'))
                p['ideal_fork_adopted'] = False
                st.session_state[state_key] = p
                st.session_state[revision_key] = revision + 1
                st.rerun()
            except (ValueError, ArithmeticError) as exc:
                st.error(str(exc))
        st.write('Alternativa de projeto idealizado: ' + IDEAL_FORK_NAME)
        st.caption(IDEAL_FORK_REQUIREMENT)
        acknowledge = st.checkbox('Adoto deliberadamente esta forquilha ideal e o requisito de detalhamento/fornecimento acima.', value=p['ideal_fork_requirement_acknowledged'], key='ua_ideal_fork_requirement_' + form_key)
        if st.button('Aplicar modelo ideal às posições informadas', disabled=not acknowledge or not p['supports']):
            p['supports'] = apply_ideal_fork(p['supports'])
            p['ideal_fork_adopted'] = True
            p['ideal_fork_requirement_acknowledged'] = True
            st.session_state[state_key] = p
            st.session_state[revision_key] = revision + 1
            st.rerun()
        p['ideal_fork_requirement_acknowledged'] = acknowledge
        support_template = dict(id='', x_mm=None, y_mm=None, **{d: UNSELECTED for d in DOFS}, provenance='')
        import pandas as pd
        config = {d: st.column_config.SelectboxColumn(d, options=[UNSELECTED, FREE, FIXED], required=True) for d in DOFS}
        config.update(id=st.column_config.TextColumn('Ponto'), x_mm=st.column_config.NumberColumn('x [mm]'),
                      y_mm=st.column_config.NumberColumn('y superior [mm]'), provenance=st.column_config.TextColumn('Base do vínculo'))
        p['supports'] = _editor_records(st.data_editor(pd.DataFrame(p['supports'] or [support_template]), num_rows='dynamic',
                                      column_config=config, hide_index=True, key='ua_support_editor_' + form_key), support_template)
    render_beam_support_inputs(st, p, form_key)
    with st.expander('3 · Trem de rodas físicas e ações características individuais', expanded=True):
        routes = [INERTIA_ROUTE, MANUAL_ROUTE, BRIDGE_ROUTE]
        p['action_input_route'] = st.radio('Origem das ações características', routes,
            index=routes.index(p.get('action_input_route', MANUAL_ROUTE)),
            format_func=lambda r: {MANUAL_ROUTE: 'Forças individuais informadas', INERTIA_ROUTE: 'Capacidade → reações e inércia 3D equilibradas (modelo adotado)', BRIDGE_ROUTE: 'Capacidade → gravidade + partilhas H adotadas (limitado)'}[r],
            key='ua_action_route_' + form_key)
        if p['action_input_route'] == INERTIA_ROUTE:
            _render_inertia_inputs(st, p, form_key, state_key, revision_key, revision)
        elif p['action_input_route'] == BRIDGE_ROUTE:
            _render_bridge_inputs(st, p, form_key, state_key, revision_key, revision)
        else:
            st.caption('G = peso do equipamento por roda; Q = parcela da carga içada por roda; Hx/Hy = forças horizontais '
                       'características assinadas, antes dos fatores gerados. Não informar capacidade em tf como reação. '
                       'n é a distância do centro de contato à borda livre da mesa inferior. Rodas opostas ficam em linhas separadas.')
            st.caption(HORIZONTAL_ACTION_BASIS)
            p['horizontal_action_basis_adopted'] = st.checkbox('Adoto explicitamente a base de Hx/Hy descrita acima.', value=p.get('horizontal_action_basis_adopted', False), key='ua_horizontal_action_basis_' + form_key)
            wheel_template = dict(id='', offset_mm=None, outstand_side=UNSELECTED, edge_to_contact_n_mm=None,
                                  dead_N=None, lifted_N=None, longitudinal_N=None, transverse_N=None,
                                  provenance='', point_force_transfer_adopted=False)
            config = {'outstand_side': st.column_config.SelectboxColumn('Lado: left=esquerdo / right=direito', options=[UNSELECTED, 'left', 'right'], required=True),
                      'point_force_transfer_adopted': st.column_config.CheckboxColumn('Adota força pontual e projeção setorial nominal?', required=True)}
            config.update(id=st.column_config.TextColumn('Roda'), offset_mm=st.column_config.NumberColumn('Offset x [mm]'),
                          edge_to_contact_n_mm=st.column_config.NumberColumn('n à borda [mm]'),
                          dead_N=st.column_config.NumberColumn('G individual [N]'), lifted_N=st.column_config.NumberColumn('Q individual [N]'),
                          longitudinal_N=st.column_config.NumberColumn('Hx individual [N]'), transverse_N=st.column_config.NumberColumn('Hy individual [N]'),
                          provenance=st.column_config.TextColumn('Base das ações e geometria'))
            p['wheels'] = _editor_records(st.data_editor(pd.DataFrame(p['wheels'] or [wheel_template]), num_rows='dynamic', column_config=config,
                                        hide_index=True, key='ua_wheel_editor_' + form_key), wheel_template)
    with st.expander('4 · Casos e resolução numérica', expanded=True):
        p['actions']['psi'] = _text_number(st, 'Fator dinâmico psi adotado [-]', p['actions']['psi'], key='ua_psi_' + form_key)
        groups = [None] + [f'A{i}' for i in range(1, 9)]
        p['actions']['equipment_group'] = st.selectbox('Grupo de equipamento', groups,
            index=groups.index(p['actions']['equipment_group']), format_func=lambda x: 'Não informado' if x is None else x, key='ua_equipment_group_' + form_key)
        p['actions']['classification_source'] = st.text_input('Base da classificação e do fator dinâmico', value=p['actions']['classification_source'], key='ua_classification_source_' + form_key)
        st.caption('A rota gera internamente casos normais carregados/vazios e sinais horizontais; nenhum esforço externo é solicitado. '
                   'Eventos excepcionais, vento, ensaios e batentes não são inventados. Casos FAT amostrados não constituem vida à fadiga.')
        st.caption('Base EN suplementar opcional, separada da comparação NBR: informar fator e referência adotados somente para o método interno correspondente. '
                   'Sem fator não há valor presumido. A entrada não comprova a estabilidade; o produtor numérico deve demonstrar o domínio de C.2.')
        p['supplementary_en_resistance_gamma'] = _text_number(st, 'Fator de resistência EN suplementar, gamma >= 1',
            p.get('supplementary_en_resistance_gamma'), key='ua_en_gamma_' + form_key)
        p['supplementary_en_source'] = st.text_input('Método, edição e base do fator EN suplementar', value=p.get('supplementary_en_source', ''), key='ua_supplementary_en_source_' + form_key)
        mesh_mm = st.number_input('Comprimento máximo de elemento [mm] (controle numérico)', min_value=50., max_value=3000., value=500., step=50., key='ua_mesh_length_' + form_key)
    with st.expander('5 · Método nominal EN 2025 de fadiga (opcional e separado)', expanded=False):
        _render_fatigue_inputs(st,p,form_key)
    with st.expander('Diagnóstico avançado · contato de uma configuração, não da família', expanded=False):
        st.caption('Este cadastro alimenta somente o diagnóstico da configuração selecionada. O cálculo principal da família não inclui aprovação de contato.')
        _render_contact_inputs(st,p,form_key)
    render_family_inputs(st,p,form_key)
    with st.expander('Diagnóstico avançado · serviço EN total da configuração selecionada', expanded=False):
        _render_service_inputs(st,p,form_key)
    st.session_state[state_key] = deepcopy(p)
    try:
        physical_document = dumps_project_document(p)
    except (ValueError, TypeError, ArithmeticError) as exc:
        st.warning('Corrija o campo indicado para salvar um JSON físico seguro: ' + str(exc))
        physical_document = None
    st.download_button('Baixar entradas físicas do projeto JSON (sem resultados)', physical_document or '',
        file_name='projeto_fisico_suspenso.json', mime='application/json', key='ua_project_download',
        disabled=physical_document is None)
    try:
        project = build_project(p, max_element_length_mm=mesh_mm)
        action_options(p)
        ready = True
    except (ValueError, TypeError, ArithmeticError) as exc:
        project, ready = None, False
        errors = getattr(exc, 'errors', [str(exc)])
        st.warning('Entradas ainda necessárias: ' + ' | '.join(errors))
    selected_case_ids, numerical_controls = None, None
    if project and ready:
        from ..autonomous_workflow.cases import generate_normal_cases
        generated = generate_normal_cases(project.wheels, **action_options(p),
            extra_dead_N_per_mm=project.extra_dead_N_per_mm, extra_dead_kind=project.extra_dead_kind)
        ids = [case.id for case in generated]
        with st.expander('Conferir casos gerados e orçamento numérico', expanded=False):
            st.caption('Todos os casos gerados estão selecionados por padrão. Remover um caso é uma análise parcial explícita, nunca aprovação de toda a operação.')
            selected_case_ids = st.multiselect('Casos a calcular', ids, default=ids, key='ua_selected_cases_' + form_key)
            st.dataframe([dict(Caso=c.id, Família=c.family, G_viga=c.support_dead, G_equipamento=c.equipment_dead,
                               Q_içada=c.lifted, Hx=c.longitudinal*c.longitudinal_sign, Hy=c.transverse*c.transverse_sign,
                               G_adicional=c.extra_dead) for c in generated], hide_index=True)
            a, b = st.columns(2)
            moving_levels = a.number_input('Refinamentos máximos da varredura', min_value=1, max_value=6, value=4, key='ua_moving_levels_' + form_key)
            mesh_levels = b.number_input('Refinamentos máximos da malha', min_value=0, max_value=6, value=2, key='ua_mesh_levels_' + form_key)
            numerical_controls = dict(max_refinements=int(moving_levels), max_mesh_refinements=int(mesh_levels))
            st.caption('Dois passos estáveis são exigidos por padrão. Limitar o orçamento pode produzir resultado não convergido, que permanece explicitamente pendente.')
        if not selected_case_ids:
            st.warning('Selecionar pelo menos um caso. Nenhum caso será escolhido silenciosamente.')
            ready = False
    request_signature = signature(dict(project=project.to_dict(), payload=calculation_payload(p), selected_case_ids=selected_case_ids,
                                       controls=numerical_controls)) if project else None
    if project:
        st.image(section_schematic_svg(project), caption='Esquema de coordenadas, não detalhamento de fabricação.')
    family_route = p.get('action_input_route') == INERTIA_ROUTE
    family_options, family_error = None, None
    try:
        family_options = physical_family_options(p)
        project_limits = service_project_limits(p)
        physical_beam_support_inputs(p, project=project)
    except (ValueError, TypeError, ArithmeticError) as exc:
        family_error = str(exc)
    if family_route:
        st.subheader('Cálculo principal · todas as configurações físicas')
        st.caption('Uma execução inclui as oito configurações declaradas, todos os casos normais gerados e os critérios opcionais de família solicitados. A lista de casos do diagnóstico não reduz este domínio. O escopo é a viga: resistência, estabilidade, fadiga, flechas e validade dos apoios adotados. Critérios NBR, EN e CMAA permanecem separados; rodas, mecanismos, ligações e edifício são opcionais externos e não bloqueiam por si só os critérios do membro.')
        if family_error: st.warning('Dados complementares ainda necessários: '+family_error)
        family_ready = bool(project and family_options is not None and family_error is None and project.bridge_reaction_ledger and project.bridge_reaction_ledger.get('schema') == 'LRO_BOUND_BRIDGE_INERTIA_LEDGER_V1')
        if st.button('Calcular todas as configurações e critérios solicitados', disabled=not family_ready, type='primary', key='ua_family_calculate'):
            try:
                with st.spinner('Calculando a família física e seus critérios independentes...'):
                    label = st.empty()
                    def family_progress(event):
                        if event.get('stage') == 'basis_polynomial_verification': label.caption('Verificando posições e cortes das bases internas.')
                        elif event.get('sample_index') == event.get('sample_count'): label.caption('Refinando a malha e verificando a convergência interna.')
                    value = run_family_pipeline(project, p, controls=numerical_controls, progress=family_progress)
                st.session_state['underslung_autonomous_family'] = dict(payload=deepcopy(p), result=value, controls=numerical_controls)
            except (ValueError, TypeError, ArithmeticError) as exc: st.error('Família não qualificada: '+str(exc))
        family_saved = st.session_state.get('underslung_autonomous_family')
        family_cache_key = 'underslung_autonomous_family_technical_export'
        family_export_key = _sync_technical_export_cache(st, family_cache_key, family_saved, p, request_signature,
                                                       cache_across_reruns=True)
        if family_saved:
            if not project or calculation_payload(family_saved['payload']) != calculation_payload(p) or family_saved['controls'] != numerical_controls:
                st.session_state.pop(family_cache_key, None)
                st.warning('O resultado de família está desatualizado. Recalcule após alterar entradas, opções ou controles.')
            else:
                try:
                    from ..autonomous_workflow.family_pipeline import assert_current_family_result
                    value = assert_current_family_result(project, family_saved['result'])
                    for part in report_sections(project, value, payload=p):
                        st.subheader(part['title'])
                        for line in part['paragraphs']: st.write(line)
                        if part['rows']: st.dataframe(part['rows'], hide_index=True)
                    if physical_document is not None:
                        st.download_button('Baixar memória da família Word', build_report_docx(project,value,payload=p), file_name='suspensa_familia_interna.docx', mime='application/vnd.openxmlformats-officedocument.wordprocessingml.document')
                        _render_technical_export(st, family_saved, p, cache_key=family_cache_key,
                            export_key=family_export_key, file_name='suspensa_familia_interna.json.gz', widget_prefix='ua_family')
                    else:
                        st.session_state.pop(family_cache_key, None)
                except (ValueError, TypeError, ArithmeticError) as exc:
                    st.session_state.pop(family_cache_key, None)
                    st.warning('Resultado de família indisponível para uso atual: '+str(exc))
    else:
        st.session_state.pop('underslung_autonomous_family_technical_export', None)
    with st.expander('Diagnóstico avançado · configuração e casos selecionados', expanded=not family_route):
        st.caption('Análise detalhada abaixo: somente a configuração física selecionada e os casos marcados. É complementar à análise de família, não substitui as demais configurações.')
        if st.button('Calcular internamente os casos e o trem móvel', disabled=not ready,type='secondary' if family_route else 'primary'):
            try:
                with st.spinner('Gerando casos e resolvendo a viga com as rodas físicas...'):
                    progress_label = st.empty()
                    last_case = [None]
                    def report_progress(event):
                        if event.get('case_id') != last_case[0] or event.get('stage') == 'case_complete':
                            last_case[0] = event.get('case_id')
                            progress_label.caption('Caso ' + str(event.get('case_index', 0) + 1) + ' de '
                                                   + str(event.get('case_count', '?')) + ': ' + str(event.get('case_id', '')))
                    result = runner(project, p, selected_case_ids=selected_case_ids, controls=numerical_controls,
                                    progress=report_progress)
                st.session_state['underslung_autonomous_result'] = dict(payload=deepcopy(p), request_signature=request_signature, result=result_mapping(result))
            except Exception as exc:
                st.error('Cálculo interrompido sem aprovação: ' + str(exc))
        saved = st.session_state.get('underslung_autonomous_result')
        result_cache_key = 'underslung_autonomous_result_technical_export'
        result_export_key = _sync_technical_export_cache(st, result_cache_key, saved, p, request_signature,
                                                       cache_across_reruns=False)
        if not saved or calculation_payload(saved['payload']) != calculation_payload(p) or saved.get('request_signature') != request_signature:
            with st.expander('Limites da rota candidata e domínios ainda não qualificados', expanded=False):
                for gap in BASE_GAPS:
                    st.write(gap)
        if saved:
            if calculation_payload(saved['payload']) != calculation_payload(p) or saved.get('request_signature') != request_signature:
                st.session_state.pop(result_cache_key, None)
                st.warning('As entradas foram alteradas. O resultado anterior não corresponde à edição atual; recalcule antes de exportar.')
            else:
                for section in report_sections(project, saved['result'], payload=p):
                    st.subheader(section['title'])
                    for line in section['paragraphs']:
                        st.write(line)
                    if section.get('rows'):
                        st.dataframe(section['rows'], hide_index=True)
                diagram = governing_state_diagram(project, saved['result'])
                if diagram:
                    st.image(diagram['png'], caption='Elevação e diagramas assinados de um único estado governante. Não é envelope simultâneo.')
                if physical_document is not None:
                    st.download_button('Baixar memória de cálculo Word', build_report_docx(project, saved['result'], payload=p),
                                       file_name='memoria_suspensa_autonoma.docx', mime='application/vnd.openxmlformats-officedocument.wordprocessingml.document')
                    _render_technical_export(st, saved, p, cache_key=result_cache_key,
                        export_key=result_export_key, file_name='suspensa_autonoma_trilha.json.gz', widget_prefix='ua_result')
                else:
                    st.session_state.pop(result_cache_key, None)


if __name__ == '__main__':
    render()
