"""Physical declarations for the one all-configuration workflow.

No imported forces, numerical receipts, convergence switches or guessed crane
properties are accepted here. Optional consumers keep independent source bases.
"""
from copy import deepcopy
from dataclasses import asdict, fields, replace

NATIVE_CATEGORY_LABELS = {
    'siderurgical_equipment': 'Equipamento siderúrgico: vertical L/1000, limitado a 25 mm',
    'other_equipment': 'Demais equipamentos: vertical L/600, limitado a 25 mm',
    'unclassified_adopt_stricter_L1000': 'Sem categoria estabelecida: adotar vertical L/1000, limitado a 25 mm',
}
NATIVE_BASELINE_LABELS = {
    'absent': 'Sem acessórios permanentes distribuídos: carga adicional declarada igual a zero',
    'fixed_support_structure_selfweight': 'Acessórios fixos integram o peso próprio de referência',
    'additional_permanent_action': 'Acessórios são ação permanente adicional, fora da referência de peso próprio',
}
NATIVE_ENUMS = {
    'equipment_category': ('Categoria física ou requisito adotado', NATIVE_CATEGORY_LABELS),
    'measurement_plane': ('Plano físico de medição', {
        'actual_underhung_running_plane_adopted': 'Plano real de rolamento suspenso, adotado como aplicação análoga da Tabela 4'}),
    'operating_domain': ('Domínio operacional NBR', {
        'normal_operation_without_wind': 'Operação normal sem vento'}),
    'hoist_mass_scope': ('Composição da massa içada NBR', {
        'payload_plus_retained_common_ledger': 'Carga útil e massa retida seguem a composição física comum, sem dupla contagem'}),
    'accessory_baseline_policy': ('Acessórios e estado de referência', NATIVE_BASELINE_LABELS),
}
NATIVE_SOURCE_LABELS = {
    'equipment_category_source': 'Fonte da categoria ou requisito NBR',
    'measurement_plane_adoption_source': 'Fonte da adoção do plano real suspenso',
    'operating_source': 'Fonte do domínio normal sem vento',
    'accessory_baseline_source': 'Fonte da composição do peso próprio de referência',
}
CMAA_NUMERIC_LABELS = {
    'bridge_travel_speed_m_s': 'Velocidade física de translação da ponte [m/s]',
    'trolley_travel_speed_m_s': 'Velocidade física de translação do carro [m/s]',
    'hoist_speed_m_s': 'Velocidade física de içamento CMAA [m/s]',
    'empty_suspended_mass_kg': 'Massa suspensa retida no vazio, inclusive moitão e acessórios [kg]; informar zero se aplicável',
}
CMAA_CG_LABELS = {
    'empty_suspended_cg_x_mm': 'CG da massa retida: x longitudinal desde o centro do trem [mm]',
    'empty_suspended_cg_z_mm': 'CG da massa retida: z desde o plano de contatos [mm], assinado',
}
CMAA_ENUMS = {
    'operating_environment': ('Ambiente CMAA', {'indoor_no_operating_wind': 'Ambiente interno sem vento operacional'}),
    'load_engagement': ('Engate e içamento da carga', {'normal_non_abrupt': 'Operação normal, sem engate brusco'}),
    'lifted_mass_scope': ('Composição física comum da carga suspensa CMAA', {
        'payload_plus_retained_common_ledger': 'Carga útil e massa retida seguem a composição física comum, sem dupla contagem'}),
    'crane_configuration': ('Aplicabilidade do método CMAA 74', {
        'single_girder_under_running_trolley': 'Ponte de viga única com carro suspenso',
        'not_established_adopted_nominal_method': 'Configuração não estabelecida: método nominal adotado explicitamente, sem alegar conformidade integral'}),
}
CMAA_CAPACITY_LABELS = {
    'rated_payload_excludes_retained_suspended_mass': 'Capacidade nominal é carga útil, sem a massa suspensa retida',
}


def blank_native_service_inputs():
    return {**{k: None for k in NATIVE_ENUMS}, **{k: '' for k in NATIVE_SOURCE_LABELS}}


def blank_cmaa_physical_inputs():
    return {**{k: None for k in (*CMAA_NUMERIC_LABELS, *CMAA_CG_LABELS, *CMAA_ENUMS)}, 'source': ''}


ROLLING_GUIDANCE_LABELS = {
    'guidance_model': ('Modelo físico de guiamento', {'two_station_opposed_contacts': 'Duas estações, dois contatos opostos por estação no mesmo nível de transferência'}),
    'longitudinal_bogies_present': ('Existem truques ou equalizadores longitudinais físicos?', {False: 'Não, duas estações simples', True: 'Sim: fora do domínio atual'}),
    'separate_lateral_guides_present': ('Existem guias laterais separadas dos contatos adotados?', {False: 'Não', True: 'Sim: fora do domínio atual'}),
    'internal_lateral_preload_present': ('Existem pré-cargas laterais internas adicionais?', {False: 'Não', True: 'Sim: fora do domínio atual'}),
}


def blank_rolling_guidance():
    return dict(guidance_model=None, guidance_source='', lateral_transfer_source='',
        longitudinal_bogies_present=None, separate_lateral_guides_present=None,
        internal_lateral_preload_present=None)


def under_rolling_guidance(raw):
    """No supplied action/proof accepted: physical topology and transfer only."""
    if raw is None:
        return None
    if not isinstance(raw, dict) or set(raw) != set(blank_rolling_guidance()):
        raise ValueError('Guiamento NBR: somente os campos físicos previstos são aceitos.')
    from ..autonomous_workflow.model import checked_text
    for name in ('guidance_source','lateral_transfer_source'):
        checked_text(raw[name],name,required=raw['guidance_model'] is not None)
    if raw['guidance_model'] is None:
        return None
    from ..fatigue.nbr_rolling_family import NBRRollingGuidance
    for name in ('longitudinal_bogies_present', 'separate_lateral_guides_present', 'internal_lateral_preload_present'):
        if type(raw[name]) is not bool:
            raise ValueError('Guiamento NBR: declarar as condições de truques, guias e pré-cargas.')
    value=NBRRollingGuidance(**raw)
    value.validate()
    return value


def blank_family_inputs():
    from top_unstiffened_candidate.fatigue_ui import blank_premises
    from top_unstiffened_candidate.fatigue_inputs import NBRFatiguePremises
    return dict(nbr_fatigue_enabled=False,nbr_fatigue_inputs=blank_premises(NBRFatiguePremises),nbr_rolling_guidance=blank_rolling_guidance(),native_service_enabled=False, native_service_inputs=blank_native_service_inputs(),
        cmaa_enabled=False, cmaa_physical_inputs=blank_cmaa_physical_inputs(),
        cmaa_mass_accounting=dict(capacity_basis=None, mass_accounting_source='', retained_mass_excluded_from_equipment=None),
        family_service_project_limits=dict(vertical_divisor=None, lateral_divisor=None, source=''))


def _exact_contract(raw, contract, label):
    if not isinstance(raw, dict) or set(raw) != {f.name for f in fields(contract)}:
        raise ValueError(label + ': somente os dados físicos do formulário são aceitos; sem esforços, deslocamentos ou comprovantes numéricos externos.')
    return deepcopy(raw)


def physical_family_options(payload):
    """Typed API options; JSON keeps only the original declared physical fields."""
    from .ui import number, text_required
    from ..serviceability.nbr10084_adapter import NBR10084ServicePhysicalInputs
    from ..cmaa74.actions import CMAA74PhysicalInputs
    options = dict(native_service_physical=None, cmaa_physical=None, cmaa_mass_accounting=None,nbr_fatigue_physical=None,nbr_rolling_guidance=None)
    if payload.get('nbr_fatigue_enabled') is True or payload.get('native_service_enabled') is True:
        options['nbr_rolling_guidance']=under_rolling_guidance(payload.get('nbr_rolling_guidance'))
    if type(payload.get("nbr_fatigue_enabled",False)) is not bool:
        raise ValueError("Fadiga NBR: ativação deve ser explícita e booleana.")
    if payload.get("nbr_fatigue_enabled") is True:
        from top_unstiffened_candidate.fatigue_inputs import NBRFatiguePremises,exact_premises
        from .ui import build_project
        project=build_project(payload)
        if not project.suspended_mass_basis().get("complete_suspended_mass_accounting"):
            raise ValueError("Fadiga NBR exige a composição comum explícita de carga útil e massa retida.")
        declaration=exact_premises(NBRFatiguePremises,payload.get("nbr_fatigue_inputs"))
        options["nbr_fatigue_physical"]=declaration.physical(fy_mpa=project.fy_mpa,fu_mpa=project.fu_mpa,
            flange_thickness_mm=project.section.tf_mm,web_thickness_mm=project.section.tw_mm,material_source=project.material_source)
        options['nbr_fatigue_physical']=replace(options['nbr_fatigue_physical'], rolling_guidance=options['nbr_rolling_guidance'])
    if payload.get('native_service_enabled') is True:
        if payload.get('inertia_inputs',{}).get('mass_accounting_convention')!='payload_plus_retained_suspended_mass':
            raise ValueError('Serviço NBR da família exige composição comum explícita de carga útil e massa retida; o legado não demonstra massa retida nula.')
        data = _exact_contract(payload.get('native_service_inputs'), NBR10084ServicePhysicalInputs, 'Serviço NBR')
        for key, (label, labels) in NATIVE_ENUMS.items():
            if not isinstance(data[key], str) or data[key] not in labels: raise ValueError('Serviço NBR: declarar '+label.lower()+'.')
        for key, label in NATIVE_SOURCE_LABELS.items(): data[key] = text_required(data[key], label)
        options['native_service_physical'] = NBR10084ServicePhysicalInputs(**data).validate()
    if payload.get('cmaa_enabled') is True:
        data = _exact_contract(payload.get('cmaa_physical_inputs'), CMAA74PhysicalInputs, 'CMAA 74:2020')
        for key, (label, labels) in CMAA_ENUMS.items():
            if not isinstance(data[key], str) or data[key] not in labels: raise ValueError('CMAA 74:2020: declarar '+label.lower()+'.')
        for key, label in CMAA_NUMERIC_LABELS.items(): data[key] = number(data[key], label, nonnegative=True)
        for key, label in CMAA_CG_LABELS.items():
            data[key] = None if data[key] is None or data[key] == '' else number(data[key], label)
        transfer = payload.get('inertia_inputs', {}).get('transfer_model')
        if transfer == 'free_suspended_at_crab' and any(data[key] is not None for key in CMAA_CG_LABELS):
            raise ValueError('Carga livre por cabos usa o ponto declarado abaixo do carro; não informar CG separado da massa retida.')
        if transfer == 'guided_rigid_payload_cg' and data['empty_suspended_mass_kg'] > 0 and any(data[key] is None for key in CMAA_CG_LABELS):
            raise ValueError('Carga guiada com massa retida não nula exige seu próprio CG físico x/z, sem inferir o CG da carga útil.')
        data['source'] = text_required(data['source'], 'Fonte dos dados físicos CMAA 74:2020')
        options['cmaa_physical'] = CMAA74PhysicalInputs(**data).validate()
        raw = payload.get('cmaa_mass_accounting')
        if not isinstance(raw, dict) or set(raw) != {'capacity_basis', 'mass_accounting_source', 'retained_mass_excluded_from_equipment'}:
            raise ValueError('Declarar separadamente a convenção de capacidade e a origem da contabilidade de massas CMAA.')
        if raw['capacity_basis'] not in CMAA_CAPACITY_LABELS:
            raise ValueError('A capacidade nominal comum é carga útil, sem a massa retida. Declarações antigas de massa total exigem revisão explícita.')
        if raw['retained_mass_excluded_from_equipment'] is not True:
            raise ValueError('Declarar a massa suspensa retida separada das massas da ponte e do carro; não é permitida dupla contagem.')
        options['cmaa_mass_accounting'] = dict(raw, mass_accounting_source=text_required(raw['mass_accounting_source'], 'Fonte da contabilidade de massas'))
        common = payload.get('inertia_inputs', {})
        if common.get('mass_accounting_convention') != 'payload_plus_retained_suspended_mass':
            raise ValueError('CMAA exige a composição comum explícita de carga útil e massa retida; o legado não demonstra massa retida nula.')
        if common.get('retained_mass_excluded_from_equipment') is not True:
            raise ValueError('A composição comum deve separar a massa retida das massas da ponte e do carro, sem dupla contagem.')
        text_required(common.get('suspended_mass_source'), 'Fonte comum da massa suspensa retida')
        retained = number(common.get('retained_suspended_mass_kg'), 'Massa suspensa retida comum', nonnegative=True)
        if data['empty_suspended_mass_kg'] != retained:
            raise ValueError('Declarações de massa incompatíveis: a massa retida CMAA deve coincidir com a composição comum, sem uma segunda contabilidade.')
        for common_key, cmaa_key in (('retained_suspended_cg_x_mm','empty_suspended_cg_x_mm'), ('retained_suspended_cg_z_mm','empty_suspended_cg_z_mm')):
            value=common.get(common_key)
            value=None if value is None or value=='' else number(value,'CG físico comum da massa retida')
            if data[cmaa_key] != value:
                raise ValueError('CG físico da massa retida CMAA incompatível com o CG da composição comum; revisar as duas declarações.')
    return options


def service_project_limits(payload):
    """Optional project restrictions, never a substitute for a source limit."""
    from .ui import number, text_required
    raw = payload.get('family_service_project_limits', dict(vertical_divisor=None, lateral_divisor=None, source=''))
    if not isinstance(raw, dict) or set(raw) != {'vertical_divisor', 'lateral_divisor', 'source'}:
        raise ValueError('Limites de projeto: informar somente divisores L/? vertical/lateral e sua fonte.')
    data = {key: None if raw[key] is None or raw[key] == '' else number(raw[key], 'Divisor L/? de projeto', positive=True)
            for key in ('vertical_divisor', 'lateral_divisor')}
    active = any(v is not None for v in data.values())
    data['source'] = text_required(raw['source'], 'Fonte dos limites mais restritivos de projeto') if active else ''
    return data if active else None


def consumer_input_snapshot(options):
    return dict(nbr_rolling_guidance=asdict(options['nbr_rolling_guidance']) if options.get('nbr_rolling_guidance') else None,
        nbr_fatigue=asdict(options['nbr_fatigue_physical']) if options.get('nbr_fatigue_physical') else None,
        native_service=asdict(options['native_service_physical']) if options['native_service_physical'] else None,
        cmaa=asdict(options['cmaa_physical']) if options['cmaa_physical'] else None,
        cmaa_mass_accounting=deepcopy(options['cmaa_mass_accounting']))


def render_family_inputs(st, payload, form_key):
    """No default source, speed, mass, category, CG or numerical-proof adoption."""
    from .ui import _text_number
    from top_unstiffened_candidate.detail_gallery import render_detail_gallery
    render_detail_gallery(st)
    for key, value in blank_family_inputs().items(): payload.setdefault(key, value)
    def choice(raw, key, label, labels, prefix):
        values = [None] + list(labels)
        raw[key] = st.selectbox(label, values, index=values.index(raw.get(key)) if raw.get(key) in values else 0,
            format_func=lambda v: 'Não informado / não adotado' if v is None else labels[v], key=prefix+key+'_'+form_key)
    with st.expander('Fadiga NBR 8400-2 · vida classificada finita',expanded=False):
        from top_unstiffened_candidate.fatigue_ui import render_nbr_premises
        payload['nbr_fatigue_enabled']=st.checkbox('Calcular fadiga NBR de vida classificada finita da família',value=payload['nbr_fatigue_enabled'],key='ua_nbr_fatigue_enabled_'+form_key)
        if payload['nbr_fatigue_enabled']:
            payload['nbr_fatigue_inputs']=render_nbr_premises(st,payload['nbr_fatigue_inputs'],'ua_nbr_fatigue_'+form_key+'_')
        st.caption('A verificação EN por limite de amplitude variável permanece separada. Selecionar NBR não converte nem aprova automaticamente a condição EN.')
    with st.expander('Guiamento físico para as ações NBR', expanded=False):
        st.caption('A reação transversal normal de rolamento é incluída separadamente das inércias. Declare a geometria e o nível de transferência como informação do equipamento ou requisito de projeto, sem atribuir esforços externos.')
        raw=payload['nbr_rolling_guidance']
        for name,(label,labels) in ROLLING_GUIDANCE_LABELS.items():
            choice(raw,name,label,labels,'ua_nbr_rolling_')
        raw['guidance_source']=st.text_input('Fonte ou requisito de projeto do guiamento',value=raw.get('guidance_source',''),key='ua_nbr_rolling_source_'+form_key)
        raw['lateral_transfer_source']=st.text_input('Fonte ou requisito do ponto de transferência lateral adotado',value=raw.get('lateral_transfer_source',''),key='ua_nbr_rolling_transfer_'+form_key)
    with st.expander('7 · Serviço NBR 10084 da família e limites de projeto', expanded=False):
        payload['native_service_enabled'] = st.checkbox('Calcular serviço NBR 10084:2020 de todas as configurações',
            value=payload['native_service_enabled'], key='ua_native_service_enabled_'+form_key)
        if payload['native_service_enabled']:
            st.caption('Flecha incremental na linha real de contato, relativa à corda entre suspensões e ao estado de peso próprio do MESMO modelo. Sem impacto nem majoração. Não é o deslocamento total EN e não é diferença entre máximos independentes.')
            st.caption('Vertical: L/1000 ou L/600 conforme categoria, com teto de 25 mm. Lateral: L/600. Apenas os mecanismos normais sem vento gerados; vento, temperatura, diferença entre vias, apoios e ligações permanecem separados.')
            raw = payload['native_service_inputs']
            for key, (label, labels) in NATIVE_ENUMS.items(): choice(raw, key, label, labels, 'ua_native_service_')
            for key, label in NATIVE_SOURCE_LABELS.items(): raw[key] = st.text_input(label, value=raw.get(key, ''), key='ua_native_service_'+key+'_'+form_key)
        st.caption('Limite manual L/? é uma restrição adicional: nunca relaxa a norma nem seu teto absoluto. Só será indicado como verificado se o resultado o incluir expressamente; bases de deslocamento incompatíveis não são misturadas.')
        raw = payload['family_service_project_limits']
        a, b = st.columns(2)
        raw['vertical_divisor'] = _text_number(a, 'Divisor vertical de projeto: L / ? [opcional]', raw.get('vertical_divisor'), key='ua_project_vertical_'+form_key)
        raw['lateral_divisor'] = _text_number(b, 'Divisor lateral de projeto: L / ? [opcional]', raw.get('lateral_divisor'), key='ua_project_lateral_'+form_key)
        raw['source'] = st.text_input('Fonte ou requisito dos limites de flecha de projeto', value=raw.get('source', ''), key='ua_project_service_source_'+form_key)
    with st.expander('8 · Comparação nominal local CMAA 74:2020, caso 2 ASD', expanded=False):
        payload['cmaa_enabled'] = st.checkbox('Calcular também a comparação local CMAA 74:2020 da família', value=payload['cmaa_enabled'], key='ua_cmaa_enabled_'+form_key)
        if not payload['cmaa_enabled']: return
        st.caption('Base independente NBR/EN: ações próprias CMAA, caso 2 de tensões admissíveis, com fatores de peso próprio, içamento, inércia e limite de desalinhamento. Não é verificação global CMAA nem aprovação completa da ponte.')
        raw = payload['cmaa_physical_inputs']
        for key, label in CMAA_NUMERIC_LABELS.items(): raw[key] = _text_number(st, label, raw.get(key), key='ua_cmaa_'+key+'_'+form_key)
        if payload.get('inertia_inputs', {}).get('transfer_model') == 'guided_rigid_payload_cg':
            st.caption('Massa retida não nula na carga guiada exige seu CG próprio. O programa não copia o CG da carga útil.')
            for key, label in CMAA_CG_LABELS.items(): raw[key] = _text_number(st, label, raw.get(key), key='ua_cmaa_'+key+'_'+form_key)
        elif any(raw.get(key) is not None for key in CMAA_CG_LABELS):
            st.warning('Há CG retido de um modelo guiado anterior. Apague deliberadamente estes valores para usar o ponto de transferência da carga livre.')
            if st.button('Remover CG retido incompatível com carga livre', key='ua_cmaa_clear_cg_'+form_key):
                for key in CMAA_CG_LABELS: raw[key] = None
        for key, (label, labels) in CMAA_ENUMS.items(): choice(raw, key, label, labels, 'ua_cmaa_')
        raw['source'] = st.text_input('Fonte das velocidades, ambiente, engate e massa retida CMAA', value=raw.get('source', ''), key='ua_cmaa_source_'+form_key)
        accounting = payload['cmaa_mass_accounting']
        choice(accounting, 'capacity_basis', 'O que significa a capacidade nominal informada?', CMAA_CAPACITY_LABELS, 'ua_cmaa_accounting_')
        choice(accounting, 'retained_mass_excluded_from_equipment', 'Separação da massa suspensa retida', {
            True: 'Massa retida NÃO está incluída nas massas da ponte nem do carro'}, 'ua_cmaa_accounting_')
        accounting['mass_accounting_source'] = st.text_input('Fonte da convenção de capacidade e ausência de dupla contagem', value=accounting.get('mass_accounting_source', ''), key='ua_cmaa_accounting_source_'+form_key)
        st.caption('A capacidade nominal é sempre carga útil. Os valores da massa retida e de seu CG precisam coincidir com a composição comum acima. Todos os critérios usam as mesmas parcelas físicas, mas conservam seus próprios fatores e combinações; não se recompõe um CG médio nem se soma a massa retida à capacidade.')
