"""Optional beam-side physical declarations, never imported forces or proof.

Storage validates a safe editable draft. Only ``physical_beam_support_inputs``
requires complete physical input and creates the strict numerical API object.
Unknown hole inventory is None; [] is a documented absence within one stated
rectangular flange region, not a claim about the rest of the beam.
"""
from __future__ import annotations

from copy import deepcopy

from ..autonomous_workflow.model import checked_text
from ..beam_support.inputs import SCHEMA

HOLE_SHAPES = {'round': 'Circular', 'obround': 'Rasgo oblongo'}
HOLE_MANUFACTURING = {
    'drilled': 'Broqueado (com fonte)', 'punched': 'Puncionado',
    'thermal_cut': 'Corte térmico', 'unknown': 'Processo desconhecido',
}
ROOT_KINDS = {
    'rolled_radius': 'Raio real de concordância laminada',
    'web_parallel_weld_leg': 'Perna real da solda paralela à alma',
}
CONTACT_MODELS = {
    'discrete_bearing_patch': 'Área discreta real de apoio',
    'unresolved': 'Contato ainda não resolvido',
}
MAX_HOLES = 512
MAX_FOOTPRINTS = 512
HOLE_NUMBERS = ('x_mm', 'y_mm', 'major_mm', 'minor_mm', 'angle_rad')
FOOTPRINT_NUMBERS = ('x_start_mm', 'x_end_mm', 'y_start_mm', 'y_end_mm', 'application_z_mm')


def blank_beam_support_inputs():
    """No assumed gamma, ends, holes, source, radius or physical contact field."""
    return dict(schema=SCHEMA,
        beam_ends=dict(left_x_mm=None, right_x_mm=None, physical_end_source=''),
        geometry_source='', gamma_a1=None, factor_source='',
        top_holes=None, bottom_holes=None, top_root=None, footprints=[])


def blank_hole_inventory():
    return dict(x_start_mm=None, x_end_mm=None, inventory_source='', holes=[])


def blank_hole_row():
    return dict(id='', **{key: None for key in HOLE_NUMBERS}, shape=None,
        manufacturing=None, geometry_source='', manufacturing_source='')


def blank_footprint_row():
    return dict(id='', support_id='', **{key: None for key in FOOTPRINT_NUMBERS},
        contact_model=None, footprint_source='', contact_source='')


def validate_beam_support_draft(raw):
    """Bounded physical-only storage validation, not a calculation approval.

    Valid numeric text and blanks survive unchanged in text widgets. Numeric
    table cells use only finite JSON numbers or null. Missing inventories remain
    unknown, including imports predating this optional form.
    """
    from .ui import number

    def object_fields(value, template, label):
        if not isinstance(value, dict) or set(value) - set(template):
            raise ValueError(label + ': somente campos físicos reconhecidos são aceitos; sem esforços, pressões ou comprovantes externos.')
        return {key: deepcopy(value.get(key, default)) for key, default in template.items()}

    def text(value, label):
        return checked_text(value, label, required=False)

    def numeric(value, label, *, table=False):
        if value is None:
            return value
        if table and type(value) not in (int, float):
            raise ValueError(label + ': célula numérica deve conter número JSON ou null.')
        if not table and value == '':
            return value
        if type(value) not in (int, float, str):
            raise ValueError(label + ': informar número ou deixar em branco.')
        number(value, label)
        return value

    def choice(value, choices, label):
        if value is not None and (not isinstance(value, str) or value not in choices):
            raise ValueError(label + ': opção física não reconhecida.')
        return value

    def rows(value, template, numeric_keys, enums, label, limit):
        if not isinstance(value, list) or len(value) > limit:
            raise ValueError(label + ': lista inválida ou acima do limite de linhas.')
        result = []
        for i, item in enumerate(value):
            row = object_fields(item, template, f'{label} [{i+1}]')
            for key in row:
                path = f'{label} [{i+1}] / {key}'
                if key in numeric_keys:
                    numeric(row[key], path, table=True)
                elif key in enums:
                    choice(row[key], enums[key], path)
                else:
                    text(row[key], path)
            result.append(row)
        return result

    result = object_fields(raw, blank_beam_support_inputs(), 'Região da viga na suspensão')
    if result['schema'] != SCHEMA:
        raise ValueError('Esquema físico da região da suspensão não reconhecido.')
    ends = object_fields(result['beam_ends'], blank_beam_support_inputs()['beam_ends'], 'Extremos físicos')
    for key in ('left_x_mm', 'right_x_mm'):
        numeric(ends[key], 'Extremos físicos / '+key)
    text(ends['physical_end_source'], 'Fonte dos extremos físicos')
    result['beam_ends'] = ends
    text(result['geometry_source'], 'Fonte da geometria da região')
    text(result['factor_source'], 'Fonte de gamma_a1')
    numeric(result['gamma_a1'], 'gamma_a1')
    for key in ('top_holes', 'bottom_holes'):
        if result[key] is None:
            continue
        inventory = object_fields(result[key], blank_hole_inventory(), key)
        if 'holes' not in result[key]:
            raise ValueError(key + ': inventário conhecido exige a lista explícita de furos; omissão não significa ausência de furos.')
        for bound in ('x_start_mm', 'x_end_mm'):
            numeric(inventory[bound], key+' / '+bound)
        text(inventory['inventory_source'], key+' / fonte do inventário')
        inventory['holes'] = rows(inventory['holes'], blank_hole_row(), HOLE_NUMBERS,
            dict(shape=HOLE_SHAPES, manufacturing=HOLE_MANUFACTURING), key+' / furos', MAX_HOLES)
        result[key] = inventory
    if result['top_root'] is not None:
        root = object_fields(result['top_root'], dict(kind=None, extension_mm=None, source=''), 'Raiz superior')
        choice(root['kind'], ROOT_KINDS, 'Tipo da raiz superior')
        numeric(root['extension_mm'], 'Dimensão da raiz superior')
        text(root['source'], 'Fonte da raiz superior')
        result['top_root'] = root
    result['footprints'] = rows(result['footprints'], blank_footprint_row(), FOOTPRINT_NUMBERS,
        dict(contact_model=CONTACT_MODELS), 'Áreas reais de contato', MAX_FOOTPRINTS)
    return result


def physical_beam_support_inputs(payload, *, project=None):
    """Return the strict typed optional adapter input; never mutate the draft."""
    from .ui import number
    from ..beam_support.inputs import physical_from_dict
    enabled = payload.get('beam_support_enabled', False)
    if type(enabled) is not bool:
        raise ValueError('Região da suspensão: a ativação deve ser booleana explícita.')
    if not enabled:
        return None
    raw = validate_beam_support_draft(payload.get('beam_support_physical_inputs', blank_beam_support_inputs()))
    for key in ('left_x_mm', 'right_x_mm'):
        raw['beam_ends'][key] = number(raw['beam_ends'][key], 'Extremos físicos / '+key)
    raw['gamma_a1'] = number(raw['gamma_a1'], 'Fator gamma_a1 da região da suspensão', positive=True)
    for key in ('top_holes', 'bottom_holes'):
        if raw[key] is not None:
            for bound in ('x_start_mm', 'x_end_mm'):
                raw[key][bound] = number(raw[key][bound], 'Região do inventário / '+bound)
    if raw['top_root'] is not None:
        raw['top_root']['extension_mm'] = number(raw['top_root']['extension_mm'], 'Raiz superior [mm]', nonnegative=True)
    physical = physical_from_dict(raw)
    if project is not None:
        from ..beam_support.adapter import map_project_inputs
        map_project_inputs(project, physical)
    return physical


def _physical_table(st, rows, template, numeric_labels, text_labels, enum_labels, *, key):
    """Human labels in the grid; persisted rows retain the audited API tokens."""
    import pandas as pd
    from .ui import _editor_records
    # Streamlit editor deltas are relative to its original table. Feeding the
    # last output back as a new baseline changes widget identity and can drop
    # the next edit/add/delete event. Imports/reset change form_key; hiding the
    # editor clears its widget key, so reopening starts from the saved draft.
    base_key = '_'+key+'_physical_table_base'
    if key not in st.session_state or base_key not in st.session_state:
        st.session_state[base_key] = deepcopy(rows or [template])
    displayed = deepcopy(st.session_state[base_key])
    for row in displayed:
        for field, (_, choices) in enum_labels.items():
            row[field] = choices.get(row.get(field))
    config = {field: st.column_config.NumberColumn(label) for field, label in numeric_labels.items()}
    config.update({field: st.column_config.TextColumn(label) for field, label in text_labels.items()})
    config.update({field: st.column_config.SelectboxColumn(label, options=list(choices.values()))
        for field, (label, choices) in enum_labels.items()})
    edited = st.data_editor(pd.DataFrame(displayed, columns=template), num_rows='dynamic',
        column_config=config, hide_index=True, key=key)
    output = _editor_records(edited, template)
    for row in output:
        for field, (_, choices) in enum_labels.items():
            reverse = {label: token for token, label in choices.items()}
            row[field] = reverse.get(row.get(field))
    return [row for row in output if row != template]


def _render_inventory(st, raw, flange, label, form_key):
    from .ui import _text_number
    key = flange + '_holes'
    status = st.selectbox('Inventário de furos da '+label,
        [None, 'documented_region'], index=0 if raw.get(key) is None else 1,
        format_func=lambda v: 'Desconhecido / não cadastrado' if v is None else 'Inventário documentado de uma região',
        key='ua_bs_inventory_'+flange+'_'+form_key)
    if status is None:
        raw[key] = None
        return
    inventory = raw.get(key) or blank_hole_inventory()
    st.caption('Declare todos os furos nesta região retangular, por toda a largura da '+label+'. '
        'Tabela vazia significa ausência documentada de furos somente entre os limites x informados. '
        'Sem documento, mantenha o inventário desconhecido. Não são dados de resistência de parafusos.')
    left, right = st.columns(2)
    inventory['x_start_mm'] = _text_number(left, 'Início da região na '+label+' · x [mm]', inventory['x_start_mm'], key='ua_bs_'+key+'_start_'+form_key)
    inventory['x_end_mm'] = _text_number(right, 'Fim da região na '+label+' · x [mm]', inventory['x_end_mm'], key='ua_bs_'+key+'_end_'+form_key)
    inventory['inventory_source'] = st.text_input('Fonte do inventário completo da '+label,
        value=inventory['inventory_source'], key='ua_bs_'+key+'_source_'+form_key)
    st.caption('Centros: x ao longo da viga, y transversal a partir da alma. '
        'Circular: dimensões maior e menor iguais; rasgo: ângulo em radianos a partir de +x. '
        'Broqueamento só dispensa a margem de fabricação quando documentado.')
    inventory['holes'] = _physical_table(st, inventory['holes'], blank_hole_row(),
        dict(x_mm='Centro x [mm]', y_mm='Centro y [mm]', major_mm='Dimensão maior [mm]',
            minor_mm='Dimensão menor [mm]', angle_rad='Ângulo desde +x [rad]'),
        dict(id='Furo', geometry_source='Fonte da geometria do furo', manufacturing_source='Fonte do processo'),
        dict(shape=('Forma física', HOLE_SHAPES), manufacturing=('Processo de fabricação', HOLE_MANUFACTURING)),
        key='ua_bs_'+key+'_editor_'+form_key)
    raw[key] = inventory


def render_beam_support_inputs(st, payload, form_key):
    """One optional expander in UNDER, with physical grids rather than raw JSON."""
    from .ui import _text_number, number
    with st.expander('Região da viga nas suspensões · furos e contato físico (opcional)', expanded=False):
        payload['beam_support_enabled'] = st.checkbox('Incluir verificações disponíveis da viga na região das suspensões',
            value=payload.get('beam_support_enabled', False), key='ua_bs_enabled_'+form_key)
        st.caption('Escopo: a própria viga, suas mesas e alma. Parafusos, viga receptora e edifício não são dimensionados aqui. '
            'O cadastro não comprova vínculos, rigidez, distribuição de pressão nem aprovação da viga.')
        raw = payload.setdefault('beam_support_physical_inputs', blank_beam_support_inputs())
        if not payload['beam_support_enabled']:
            st.caption('Cadastro desativado. Dados já preenchidos são preservados; sem inventário, não se presume viga sem furos.')
            return
        st.warning('As verificações escalares disponíveis não resolvem a introdução local completa, o efeito alavanca (prying), '
            'a interação com os esforços globais nem a recuperação de tensões/fadiga na suspensão parafusada. '
            'Elas não produzem aprovação global da viga.')
        ends = raw['beam_ends']
        if st.button('Copiar extremos 0 e comprimento físico da viga', key='ua_bs_copy_ends_'+form_key):
            try:
                length = number(payload.get('length_mm'), 'Comprimento físico da viga', positive=True)
            except ValueError as exc:
                st.info(str(exc))
            else:
                ends.update(left_x_mm=0., right_x_mm=length)
                for field in ('left_x_mm', 'right_x_mm'):
                    st.session_state['ua_bs_'+field+'_'+form_key] = str(ends[field])
        left, right = st.columns(2)
        ends['left_x_mm'] = _text_number(left, 'Extremo físico esquerdo · x [mm]', ends['left_x_mm'], key='ua_bs_left_x_mm_'+form_key)
        ends['right_x_mm'] = _text_number(right, 'Extremo físico direito · x [mm]', ends['right_x_mm'], key='ua_bs_right_x_mm_'+form_key)
        ends['physical_end_source'] = st.text_input('Fonte dos extremos físicos da viga', value=ends['physical_end_source'], key='ua_bs_end_source_'+form_key)
        st.caption('Extremos reais do membro, não espaçamento entre suspensões. Copiar o comprimento não preenche sua fonte.')
        raw['geometry_source'] = st.text_input('Fonte da geometria da região da suspensão', value=raw['geometry_source'], key='ua_bs_geometry_source_'+form_key)
        raw['gamma_a1'] = _text_number(st, 'Fator de resistência gamma_a1 da região da suspensão [-]', raw['gamma_a1'], key='ua_bs_gamma_'+form_key)
        raw['factor_source'] = st.text_input('Norma, edição e fonte de gamma_a1', value=raw['factor_source'], key='ua_bs_factor_source_'+form_key)
        st.caption('As dimensões das mesas e da alma e as resistências fy/fu vêm da viga informada acima; nenhum fator é presumido.')
        for flange, label in (('top', 'mesa superior'), ('bottom', 'mesa inferior')):
            st.write(label.capitalize())
            _render_inventory(st, raw, flange, label, form_key)
        current = raw.get('top_root') or {}
        root_kind = st.selectbox('Geometria real da raiz superior', [None, *ROOT_KINDS],
            index=[None, *ROOT_KINDS].index(current.get('kind')),
            format_func=lambda v: 'Não informada' if v is None else ROOT_KINDS[v], key='ua_bs_root_kind_'+form_key)
        if root_kind is None:
            raw['top_root'] = None
        else:
            raw['top_root'] = dict(kind=root_kind,
                extension_mm=_text_number(st, 'Raio ou perna paralela à alma na raiz superior [mm]', current.get('extension_mm'), key='ua_bs_root_extension_'+form_key),
                source=st.text_input('Fonte da geometria da raiz superior', value=current.get('source', ''), key='ua_bs_root_source_'+form_key))
        st.write('Áreas físicas reais de contato na suspensão (opcional)')
        st.caption('Uma linha por área real, não o envelope do grupo de parafusos nem uma largura de distribuição presumida. '
            'Associe ao identificador da suspensão da tabela anterior. z=0 na face inferior da viga; face superior em z=d. '
            'A geometria de contato não define pressão uniforme nem esforços locais. Tabela vazia não comprova ausência de contato.')
        raw['footprints'] = _physical_table(st, raw['footprints'], blank_footprint_row(),
            dict(x_start_mm='Início x [mm]', x_end_mm='Fim x [mm]', y_start_mm='Início y [mm]',
                y_end_mm='Fim y [mm]', application_z_mm='Face de aplicação z [mm]'),
            dict(id='Área', support_id='Suspensão', footprint_source='Fonte da área física', contact_source='Fonte do contato'),
            dict(contact_model=('Modelo físico do contato', CONTACT_MODELS)), key='ua_bs_footprints_editor_'+form_key)
        st.caption('Rascunhos incompletos podem ser salvos e reabertos. Os dados físicos são validados novamente antes da verificação do componente.')
