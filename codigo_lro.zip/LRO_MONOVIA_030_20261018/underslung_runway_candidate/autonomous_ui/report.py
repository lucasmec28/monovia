"""Human-readable report for internal underslung calculations.

This presentation adapter never upgrades a numerical result to system approval.
The authoritative signed data and identities remain in the accompanying JSON.
"""
from __future__ import annotations
from dataclasses import asdict, is_dataclass
from html import escape
from io import BytesIO
import math
from collections.abc import Mapping

from ..section_stress.recovery import geometric_properties
from ..autonomous_workflow.model import signature

SOURCE_REFERENCES = (
    ('ABNT NBR 10084:2020', '§9.1.4, Tabela 2: base brasileira primária das tensões locais nominais para mesa de faces paralelas. A composição e os fatores usados em cada critério são preservados no resultado interno.', ''),
    ('EN 1993-6:2007 + AC:2009', '§5.8, Fig. 5.6 / Tabela 5.2: tensões locais nominais da mesa inferior; §7.5(3): coexistência local/global. Referência complementar de mecânica local; a verificação brasileira direta usa sua própria base NBR, sem equivalência automática de fatores.', 'https://www.phd.eng.br/wp-content/uploads/2015/12/en.1993.6.2007.pdf'),
    ('SCI P385 (2011)', '§§2.1–2.2 e 5.4; Apêndice B: modelo nominal de torção e empenamento de seção aberta.', ''),
    ('EN 13001-3-3:2014', '§§5–6: resistência estática e fadiga de contato de roda e pista, dentro das condições de geometria, material e histórico do método qualificado. A cobertura efetiva consta do resultado de cada verificação.', 'https://www.scribd.com/document/729764936/BS-EN-13001-3-3-2014'),
)
BASE_GAPS = (
    'O resultado informa separadamente a cobertura de resistência, estabilidade, fadiga estrutural, contato e suspensões; não presume os dados físicos ainda ausentes.',
    'Os métodos normativos são usados somente nos detalhes e domínios aos quais se aplicam. Um detalhe laminado íntegro não é tratado automaticamente como entalhe ou solda.',
    'Convergência é um critério numérico separado dos limites de resistência e serviço; os estados governantes conservam caso, posição, ponto e sinais.',
)



def result_mapping(value):
    if is_dataclass(value):
        return asdict(value)
    if hasattr(value, 'to_dict'):
        return value.to_dict()
    if isinstance(value, Mapping):
        return dict(value)
    raise TypeError('Resultado deve ser um mapeamento identificável do cálculo interno.')


def fmt(value, digits=3):
    if value is None:
        return 'Não informado'
    if isinstance(value, bool):
        return 'Sim' if value else 'Não'
    if isinstance(value, (int, float)):
        if not math.isfinite(value):
            return 'Não finito / verificar domínio'
        return f'{value:,.{digits}f}'.replace(',', '_').replace('.', ',').replace('_', '.')
    return str(value)


def _human(value):
    if isinstance(value, Mapping):
        label = value.get('title') or value.get('name') or value.get('id') or value.get('check') or value.get('domain')
        detail = value.get('reason') or value.get('message') or value.get('description') or value.get('status')
        if label and detail:
            return str(label) + ': ' + str(detail)
        if detail or label:
            return str(detail or label)
        return '; '.join(f'{k}: {_human(v)}' for k, v in value.items() if v is not None)
    if isinstance(value, (list, tuple)):
        return '; '.join(_human(v) for v in value)
    return fmt(value)


def _peak(extrema, metric):
    entry = extrema.get(metric, {})
    values = [entry.get(bound) for bound in ('min', 'max')]
    valid = [v for v in values if isinstance(v, Mapping) and isinstance(v.get('value'), (int, float))]
    return max(valid, key=lambda x: abs(x['value'])) if valid else None


def _contact_peak(extrema, component):
    candidates = [(key, _peak(extrema, key)) for key in extrema
                  if key.startswith('contact/') and key.endswith('/' + component)]
    candidates = [(key, record) for key, record in candidates if record is not None]
    return max(candidates, key=lambda item: abs(item[1]['value'])) if candidates else (None, None)


def _case_rows(result):
    rows = []
    cases = result.get('cases', [])
    if isinstance(cases, Mapping):
        cases = list(cases.values())
    for item in cases:
        case = item.get('case', {})
        sweep = item.get('sweep') or {}
        extrema = sweep.get('extrema', {})
        _, w = _contact_peak(extrema, 'w')
        _, v = _contact_peak(extrema, 'v')
        my, mz, torque = (_peak(extrema, metric) for metric in ('My', 'Mz', 'T_equilibrated'))
        rows.append({
            'Caso': case.get('id', item.get('id', 'Sem identificação')),
            'Numérico': 'Convergido' if item.get('numerical_converged', False) else 'Pendente',
            '|w contato| [mm]': fmt(abs(w['value']) if w else None),
            '|v contato| [mm]': fmt(abs(v['value']) if v else None),
            '|My| máx [kN.m]': fmt(abs(my['value']) / 1e6 if my else None),
            '|Mz| máx [kN.m]': fmt(abs(mz['value']) / 1e6 if mz else None),
            '|T| máx [kN.m]': fmt(abs(torque['value']) / 1e6 if torque else None),
        })
    return rows


def _critical_identity_rows(result):
    rows = []
    cases = result.get('cases', [])
    if isinstance(cases, Mapping):
        cases = list(cases.values())
    for item in cases:
        case = item.get('case', {})
        extrema = (item.get('sweep') or {}).get('extrema', {})
        for component in ('w', 'v'):
            metric, peak = _contact_peak(extrema, component)
            if peak:
                rows.append({'Caso': case.get('id', peak.get('case_id', 'Sem identificação')),
                             'Grandeza': component + ' contato ' + metric[len('contact/'):-(len(component)+1)],
                             'Valor assinado': fmt(peak['value']) + ' mm',
                             'Translação [mm]': fmt(peak.get('translation_mm')),
                             'Seção x [mm]': fmt(peak.get('x_mm')), 'Lado do corte': peak.get('side', 'Não informado')})
        for metric, unit, scale in (('My', 'kN.m', 1e6), ('B_equilibrated', 'kN.m²', 1e9)):
            peak = _peak(extrema, metric)
            if peak:
                rows.append({'Caso': case.get('id', peak.get('case_id', 'Sem identificação')), 'Grandeza': metric,
                             'Valor assinado': fmt(peak['value'] / scale) + ' ' + unit,
                             'Translação [mm]': fmt(peak.get('translation_mm')),
                             'Seção x [mm]': fmt(peak.get('x_mm')), 'Lado do corte': peak.get('side', 'Não informado')})
    return rows


def _nominal_rows(result):
    rows = []
    for item in result.get('cases', []):
        local = item.get('local') or {}
        case_id = item.get('case', {}).get('id', 'Sem identificação')
        checks = local.get('governing_checks', {})
        if checks:
            for key, check in checks.items():
                ident = check.get('identity', {})
                rows.append({'Caso': case_id, 'Grandeza / critério': check.get('label', check.get('name', key)),
                             'Demanda [MPa]': fmt(check.get('demand')), 'Limite [MPa]': fmt(check.get('capacity', check.get('limit'))),
                             'Utilização': fmt(check.get('utilization')), 'Situação nominal': check.get('status', 'Não informada'),
                             'Ponto / face': str(ident.get('point_id', 'Não identificado'))})
        else:
            for key, record in local.get('governing_local_mechanics', {}).items():
                ident = record.get('identity', {})
                rows.append({'Caso': case_id, 'Grandeza / critério': key,
                             'Demanda [MPa]': fmt(record.get('value')), 'Limite [MPa]': 'Não comparado',
                             'Utilização': 'Não comparada', 'Situação nominal': local.get('resistance_status', 'Mecânica somente'),
                             'Ponto / face': str(ident.get('point_id', 'Não identificado'))})
        if not checks and not local.get('governing_local_mechanics'):
            rows.append({'Caso': case_id, 'Grandeza / critério': 'Local indisponível neste domínio',
                         'Demanda [MPa]': 'Não calculada', 'Limite [MPa]': 'Não comparado',
                         'Utilização': 'Não comparada', 'Situação nominal': local.get('status', 'Sem resultado local'),
                         'Ponto / face': 'Ver pendências'})
    return rows


def _translate_pending(value):
    text = _human(value)
    translations = {
        'EN13001 A/B/C design-action group coverage is incomplete.':'Cobertura integral dos grupos de ações A/B/C não demonstrada.',
        'Occasional skew/guidance and environmental/displacement effects outside the named indoor smooth-track normal/test domain.':'Desalinhamento/guiamento ocasional e efeitos ambientais ou de deslocamento estão fora do domínio normal/ensaios em pista lisa interna.',
        'Exceptional emergency cut-out, buffers, force limiters, collisions, assembly and other applicable exceptional events are not generated.':'Eventos excepcionais, emergência, batentes, limitadores, colisões e montagem não são gerados por esta rota normal.',
        'Vertical hoist-drive transients beyond the declared grounded-hoist/quasi-static suspended horizontal-manoeuvre domain are not generated.':'Transientes verticais fora do içamento declarado e da carga suspensa quase estática com manobras horizontais não são gerados.',
        'EN nominal fatigue: ValueError: Physical wheel path enters local end-transition domain':'Fadiga nominal: o curso físico da roda entra na região de transição junto à extremidade, fora do domínio local interior adotado.',
        'Member serviceability: Moving-position/spatial/mesh convergence is incomplete for required service cases.':'Serviço do membro: convergência da varredura, amostragem espacial e malha pendente para os casos exigidos.',
        'Only the explicitly selected generated cases were evaluated; other normal-operation cases remain unevaluated.':
            'Somente os casos explicitamente selecionados foram avaliados; os demais casos normais gerados permanecem sem avaliação.',
        'Physical travel/endstop limits are not supplied. The computed domain includes full train entry/exit and is not a design of the endstop or actual travel.':
            'Curso físico e posições de batentes não informados. O domínio computacional inclui entrada/saída do trem e não dimensiona o batente nem define o curso real.',
        'Entered suspension stations do not match the declared adopted spacing. The calculation uses the entered coordinates; reconcile the project premise.':
            'As estações de suspensão não correspondem ao espaçamento declarado neste projeto. O cálculo usa as coordenadas informadas; reconciliar a premissa do projeto.',
    }
    text = translations.get(text, text)
    return text.replace('moving-position/spatial/FE mesh convergence not established within the declared budget.',
                        'convergência da posição móvel, amostragem espacial e malha não demonstrada no orçamento numérico declarado.')


def pending_items(result):
    coverage = result.get('coverage', {})
    pending = []
    groups = (
        (('source_qualified_global_strength_complete', 'global_strength_complete'), 'Resistência e estabilidade global: cobertura ainda não demonstrada neste resultado.'),
        (('local_bottom_flange_complete', 'local_flange_complete'), 'Mesa inferior: cobertura completa do domínio nominal ainda não demonstrada neste resultado.'),
        (('fatigue_complete',), 'Fadiga estrutural: verificação do detalhe e histórico aplicáveis ainda não demonstrada neste resultado.'),
        (('wheel_contact_complete', 'contact_complete'), 'Contato roda/pista: resistência estática e fadiga de contato ainda não demonstradas neste resultado para os dados físicos informados.'),
        (('suspension_connection_strength_complete', 'connection_complete'), 'Suspensões e ligações: resistência e rigidez ainda não demonstradas neste resultado.'),
        (('endstop_test_emergency_complete',), 'Batentes, ensaios e ações excepcionais aplicáveis: cobertura ainda não demonstrada neste resultado.'),
    )
    for keys, text in groups:
        if keys == ('wheel_contact_complete', 'contact_complete') and result.get('contact'):
            continue
        if keys == ('fatigue_complete',) and result.get('fatigue'):
            continue  # Actual method result/scope is reported, not a blanket negative.
        if not any(coverage.get(key) is True for key in keys):
            pending.append(text)
    extra = result.get('pending', [])
    if isinstance(extra, Mapping):
        extra = [dict(id=k, reason=v) for k, v in extra.items()]
    elif isinstance(extra, str):
        extra = [extra]
    # The three fixed pipeline scope statements are already expressed above.
    redundant = ('Global member resistance/stability,', 'Support constraints are declared ideal', 'Normal-operation cases do not by themselves', 'Equipment model:', 'Wheel/flange contact:')
    pending.extend(_translate_pending(v) for v in extra if not isinstance(v, str) or not v.startswith(redundant))
    contact_gaps={}
    for gap in (result.get('contact') or {}).get('pending',[]):
        reason=gap.get('reason',str(gap)) if isinstance(gap,dict) else str(gap)
        ident=gap.get('wheel_id','') if isinstance(gap,dict) else ''
        contact_gaps.setdefault(reason,set()).add(ident)
    pending += ['Contato: '+_translate_pending(reason)+(' [Rodas afetadas: '+str(len([v for v in ids if v]))+'; identidades no JSON]' if any(ids) else '') for reason,ids in contact_gaps.items()]
    grouped = {}
    for item in result.get('cases', []):
        local = item.get('local') or {}
        for gap in local.get('pending', []):
            if gap.get('code') in ('contact_3d', 'root_junction', 'full_system'):
                continue
            key = (gap.get('code', ''), gap.get('reason', ''))
            grouped.setdefault(key, set()).add(item.get('case', {}).get('family', ''))
    for (code, reason), families in grouped.items():
        pending.append(reason + ' [Famílias: ' + ', '.join(sorted(families)) + ']')
    return list(dict.fromkeys(pending))


def numerical_source_matches(result):
    recorded=(result.get('source') or {}).get('fingerprint')
    if not recorded:return True
    from ..autonomous_workflow.pipeline import source_receipt
    return recorded==source_receipt()['fingerprint']


def report_sections(project, result, *, payload=None, include_diagnostics=False):
    """Render one consolidated gap register, never repeated per green check."""
    r = result_mapping(result)
    if r.get('format')=='LRO_AUTONOMOUS_UNDERSLUNG_FAMILY_ANALYSIS':
        from .family_report import sections
        return sections(project,r,payload,include_diagnostics=include_diagnostics)
    payload = payload or {}
    p = geometric_properties(project.section)
    identity = 'PROJETO REAL COM DADOS INFORMADOS' if project.actual_project else 'TESTE SINTÉTICO, NÃO É PROJETO REAL'
    sections = [{
        'title': '1. Identificação, resultado e alcance',
        'paragraphs': [identity,
            'Situação global: INCOMPLETA PARA APROVAÇÃO. O cálculo fornece respostas internas e verificações apenas nos domínios explicitamente cobertos.',
            str(payload.get('project_label') or 'Sem identificação comercial ou de obra atribuída.'),
            'Origem dos dados: valores informados, referências de catálogo e premissas/requisitos adotados são distintos. Requisitos de projeto/fornecimento, incluindo materiais, geometria, montagem e transferência de forças, devem constar da especificação e ter compatibilidade comprovada pelo fornecedor; não constituem confirmação de equipamento existente. Valores físicos ausentes não são completados automaticamente.',
            'Fluxo: entradas físicas → casos gerados → análise de barras → trem móvel → recuperação nominal no mesmo ponto/estado. Não depende de esforços ou tensões de um modelo externo.',
            'Espaçamento nominal de suspensão adotado neste modelo: ' + fmt(project.support_grid_spacing_mm) + ' mm. A interface parte da premissa do usuário de 3 m; comprimento físico informado separadamente: ' + fmt(project.length_mm) + ' mm.',
        ],
        'rows': [],
    }]
    if not numerical_source_matches(r):
        sections[0]['paragraphs'].append('Código numérico alterado desde esta execução. Valores preservados como registro histórico; não requalificados com a fonte atual. O gráfico reconstruído é omitido; executar novamente para uso atual.')
    sections.append({
        'title': '2. Perfil, material e peso próprio',
        'paragraphs': [project.material_source, project.source_notes, 'Base da permanente adicional: ' + project.extra_dead_source,
                       ('Linha de ação da permanente adicional y / z: ' + fmt(project.extra_dead_y_mm) + ' / ' + fmt(project.extra_dead_z_mm) + ' mm em relação ao centroide.')
                       if project.extra_dead_N_per_mm else 'Permanente adicional declarada zero; linha de ação não necessária.',
                       'Seção I/W laminada de mesas paralelas e duplamente simétrica. Área e inércias por três retângulos; J e Cw pelo modelo de parede fina. Metal dos raios não acrescentado à rigidez.',
                       ('Massa para peso próprio: ' + fmt(project.section_mass_kg_per_m) + ' kg/m; fonte: ' + project.section_mass_source) if project.section_mass_kg_per_m is not None
                       else 'Massa para peso próprio calculada com três retângulos e quatro concordâncias circulares simétricas, usando raio e densidade informados; sem crédito adicional de rigidez.'],
        'rows': [
            {'Parâmetro': 'd / b / tf / tw / r', 'Valor': ' / '.join(fmt(getattr(project.section, k)) for k in ('d_mm','bf_mm','tf_mm','tw_mm','bottom_root_radius_mm')), 'Unidade': 'mm'},
            {'Parâmetro': 'E / nu / massa específica', 'Valor': f'{fmt(project.E_mpa)} / {fmt(project.nu)} / {fmt(project.density_kg_m3)}', 'Unidade': 'MPa / - / kg/m³'},
            {'Parâmetro': 'Resistência fy / fu', 'Valor': f'{fmt(project.fy_mpa)} / {fmt(project.fu_mpa)}', 'Unidade': 'MPa'},
            {'Parâmetro': 'Área A', 'Valor': fmt(p['A_mm2']), 'Unidade': 'mm²'},
            {'Parâmetro': 'Inércia forte Iy / fraca Iz', 'Valor': f'{fmt(p["Iy_mm4"])} / {fmt(p["Iz_mm4"])}', 'Unidade': 'mm⁴'},
            {'Parâmetro': 'Constante torsional J / empenamento Cw', 'Valor': f'{fmt(p["J_mm4"])} / {fmt(p["Cw_mm6"])}', 'Unidade': 'mm⁴ / mm⁶'},
            {'Parâmetro': 'Peso próprio calculado', 'Valor': fmt(project.selfweight(), 6), 'Unidade': 'N/mm'},
            {'Parâmetro': 'Permanente adicional declarada', 'Valor': fmt(project.extra_dead_N_per_mm, 6), 'Unidade': 'N/mm'},
        ],
    })
    grid = project.support_grid_audit()
    sections.append({
        'title': '3. Suspensões e hipóteses de vínculo',
        'paragraphs': ['Os vínculos atuam nos pontos físicos da face superior da mesa superior, não sobre a linha de contato inferior. '
                       'Graus não listados como restritos estão livres no modelo. Nenhum vínculo decorre automaticamente do espaçamento.',
                       'O vínculo ideal é requisito a demonstrar no detalhamento e no fornecimento; não é resultado de resistência da ligação.',
                       'Conferência das posições: ' + ('espaçamento adotado de ' + fmt(project.support_grid_spacing_mm) + ' mm confirmado nas coordenadas informadas.' if grid['matches_adopted_grid']
                       else 'ATENÇÃO: coordenadas não coincidem com o espaçamento adotado de ' + fmt(project.support_grid_spacing_mm) + ' mm; o cálculo usa as posições informadas.')],
        'rows': [{'Ponto': s['id'], 'x / y / z [mm]': ' / '.join(fmt(s[k]) for k in ('x','y','z')),
                  'Restritos (valor)': '; '.join(f'{k}={fmt(v)}' for k,v in s['restrain'].items()), 'Base': s['provenance']}
                 for s in project.supports],
    })
    bridge = getattr(project, 'bridge_reaction_ledger', None)
    aliases = {w.id: ('R' + str(i+1) if bridge else w.id) for i,w in enumerate(project.wheels)}
    n_by_id = {w.id: project.section.bottom_width/2-abs(w.y_mm) for w in project.wheels}
    sections.append({
        'title': '4. Rodas, geometria e ações individuais',
        'paragraphs': ['Cada linha representa uma roda física. G e Q são cargas verticais características descendentes antes dos fatores; '
                       'Hx/Hy são as ações horizontais individuais assinadas. Pares opostos não são somados nem divididos automaticamente.',
                       ('Ações geradas da capacidade, massas e acelerações adotadas: G/Q são somente gravitacionais; H distingue carregado e vazio. '
                        'A amplificação horizontal é independente de psi. A identidade de via e posição do carro acompanha todas as rodas.' if bridge else
                        'Base horizontal adotada: Hx/Hy característicos por roda já incluem os efeitos e a dinâmica horizontal aplicáveis ao cenário normal. '
                        'Os mesmos valores são adotados em carregado e vazio. O gerador aplica seus fatores próprios e inverte direções globais; não deriva H da capacidade '
                        'nem aplica automaticamente o psi vertical a H. Não é reconstrução do histórico real de cargas.'),
                       'Contato na face superior da mesa inferior. n mede da borda livre ao centro do contato; não é o braço à alma. '
                       'Força pontual e projeção setorial nominal são hipóteses adotadas, não solução do contato finito.',
                       ('Curso físico declarado: ' + fmt(project.travel_min_mm) + ' a ' + fmt(project.travel_max_mm) + ' mm de translação. Base: ' + project.travel_source)
                       if project.travel_min_mm is not None else 'Curso físico não informado: varredura computacional de entrada/saída, sem qualificação dos batentes.'],
        'rows': [{'Roda': aliases[w.id], 'Offset [mm]': fmt(w.offset_mm), 'y / z [mm]': f'{fmt(w.y_mm)} / {fmt(w.z_mm)}',
                  'n [mm]': fmt(n_by_id.get(w.id)), 'G / Q [kN]': f'{fmt(w.dead_N/1000)} / {fmt(w.lifted_N/1000)}',
                  'Hx / Hy [kN]': f'{fmt(w.longitudinal_N/1000)} / {fmt(w.transverse_N/1000)}'} for w in project.wheels],
    })
    if bridge:
        sections.extend(bridge_report_sections(project, aliases))
    cases = r.get('cases', [])
    sections.append({
        'title': '5. Casos internos e resposta móvel',
        'paragraphs': ['Quantidade de casos calculados: ' + str(len(cases)) + '. Os valores abaixo são máximos absolutos apenas para apresentação; '
                       'as identidades e os sinais do estado correspondente permanecem no registro detalhado.',
                       'Os máximos de grandezas distintas podem ocorrer em posições diferentes e não constituem um único estado coexistente.',
                       'w e v são deslocamentos nas linhas físicas inferiores de contato definidas por cada roda, não apenas no centroide. A seção governante não precisa coincidir com a posição instantânea da roda. Numérico indica somente convergência; não há comparação com limite de serviço nesta tabela.',
                       'Casos FAT amostrados fornecem respostas de ações identificadas, não resultado de vida à fadiga nem histórico completo de ciclos.'],
        'rows': _case_rows(r),
    })
    contact_rows = physical_contact_rows(r)
    if contact_rows:
        sections.append({'title': '5a. Contato unilateral dos casos físicos',
                         'paragraphs': ['Verificação de domínio, não resistência de contato. Força vertical positiva para cima indica perda de contato no modelo sem retenção. Nenhuma força ascendente é truncada ou convertida silenciosamente em tirante.'],
                         'rows': contact_rows})
    sections.append({'title': '6. Identidades de estados governantes selecionados',
                     'paragraphs': ['Translação do trem, seção e lado do corte são inseparáveis do valor. '
                                    'Ambos os lados das descontinuidades são examinados pelo cálculo.'],
                     'rows': _critical_identity_rows(r)})
    coverage = r.get('coverage', {})
    gen = r.get('case_generation', {})
    if gen:
        selected = len(gen.get('selected_ids', [])); total = len(gen.get('generated_ids', []))
        next(s for s in sections if s['title'].startswith('5.'))['paragraphs'].append(f'Seleção explícita: {selected} de {total} casos gerados. ' +
            ('Todos os casos desta geração foram calculados.' if gen.get('all_generated_cases_evaluated') else 'ANÁLISE PARCIAL: casos não selecionados permanecem sem avaliação.'))
    next(s for s in sections if s['title'].startswith('5.'))['paragraphs'].extend(['Base das ações: ' + item['case'].get('source', 'Não informada') for item in r.get('cases', [])][:1])
    failures = r.get('known_failures', []) or [check for item in r.get('cases', [])
        for check in (item.get('stability') or {}).get('checks', [])
        if check.get('qualified') is True and check.get('status') == 'NÃO ATENDE']
    nominal_failures = [item['case']['id'] for item in r.get('cases', []) if (item.get('local') or {}).get('known_nominal_failure')]
    failure_lines = (['Falhas registradas: ' + str(len(failures)) +
                      ' verificações identificadas na trilha detalhada; os critérios governantes constam acima.'] if failures else [])
    if nominal_failures:
        failure_lines.append('Falha nominal observada em ' + ', '.join(nominal_failures))
    comparison_sources = sorted({check.get('source', '') for item in r.get('cases', [])
                                 for check in (item.get('local') or {}).get('governing_checks', {}).values()
                                 if check.get('source')})
    sections.append({'title': '7. Tensões nominais coexistentes e comparação local',
                     'paragraphs': ['Os componentes locais e globais pertencem ao mesmo ponto material e ao mesmo estado do trem. '
                                    'A comparação nominal disponível não é resistência integral da mesa ou do contato.']
                     + (['Base dos critérios: ' + '; '.join(comparison_sources)] if comparison_sources else []),
                     'rows': _nominal_rows(r)})
    local_section=sections[-1]
    for item in r.get('cases',[]):
        local=item.get('local') or {};source=local.get('source_provenance') or {}
        if 'local_longitudinal_multiplier' in source:
            local_section['paragraphs'].append(str(item.get('case',{}).get('id','Caso'))+': composição nominal sigma_x = global_x + '+fmt(source['local_longitudinal_multiplier'])+' local_x; sigma_y = '+fmt(source.get('local_transverse_multiplier',1.))+' local_y. Valores locais brutos preservados na trilha.')
        if 'prescribed_nominal_point_checks_qualified' in local:
            local_section['paragraphs'].append('Pontos nominais prescritos da família I no domínio laminado ordinário, inclusive P0: '+('qualificados neste caso.' if local['prescribed_nominal_point_checks_qualified'] else 'qualificação ainda não demonstrada neste caso.')+' Contato, defeitos, furos e zonas de introdução de carga/suspensão são escopos separados.')
    stability_rows = member_check_rows(r)
    if stability_rows:
        sections.append({'title': '7a. Estabilidade e seção global no domínio suplementar',
                         'paragraphs': ['Resultados do produtor interno por caso e trecho. Qualificado significa que os critérios de aplicação deste método foram atendidos, não aprovação integral da viga. C1/C2 são adimensionais; seção elástica global é comparada em MPa.',
                                        'Base EN suplementar separada das ações NBR adotadas; a resposta numérica convergida não é um limite matemático garantido do contínuo.'],
                         'rows': stability_rows})
    if r.get('fatigue') or getattr(project,'en_fatigue_inputs',None):
        sections.extend(fatigue_report_sections(project,r))
    reaction_rows = support_receiving_rows(r)
    if reaction_rows:
        sections.append({'title':'7c. Demandas coexistentes nas suspensões',
                         'paragraphs':['Cada linha conserva um estado completo de reação no ponto físico da suspensão superior, escolhido pela maior reação vertical absoluta dessa suspensão. Componentes não são combinados por máximos independentes.',
                                        'São reações sobre a viga de rolamento, nos eixos locais. A demanda aplicada à estrutura receptora tem sinal oposto e deve ser transformada para seus eixos. B é ação generalizada de empenamento, não momento nodal comum. Outros extremos e vetores coexistentes estão no JSON.'],
                         'rows':reaction_rows})
    if r.get('contact') or getattr(project,'contact_inputs',None):
        sections.extend(contact_report_sections(project,r))
        if (r.get('contact') or {}).get('known_covered_domain_failure') and not failures:
            failure_lines.append('Falha qualificada de contato no domínio coberto, preservada apesar de outras pendências.')
    if r.get('serviceability') or getattr(project,'service_inputs',None):
        sections.extend(service_report_sections(project,r))
    sections.append({'title': '8. Cobertura e ocorrências',
                     'paragraphs': (['Casos com convergência numérica demonstrada: ' + str(coverage.get('cases_numerically_converged', 0)) +
                                    ' de ' + str(coverage.get('cases_evaluated', len(r.get('cases', [])))) + '.',
                                    'Peso próprio, transporte das ações individuais e restrições excêntricas são calculados no modelo interno. '
                                    'A validade depende das entradas físicas e das hipóteses declaradas. As reações são demandas para o projeto das vigas receptoras, não aprovação do edifício.'] if coverage else ['Cobertura detalhada não fornecida pelo cálculo.'])
                     + (failure_lines or ['Nenhuma ocorrência de falha foi listada; isso não elimina os domínios pendentes.']),
                     'rows': []})
    sections.append({'title': '9. Pendências e limites de qualificação', 'paragraphs': list(dict.fromkeys(pending_items(r) + bridge_pending_items(project))), 'rows': []})
    sections.append({'title': '10. Bases e rastreabilidade',
                     'paragraphs': [title + '. ' + scope + (' Fonte: ' + url if url else '') for title, scope, url in SOURCE_REFERENCES]
                     + ['Assinatura dos dados do projeto: ' + str(r.get('project_signature', 'Não fornecida pelo cálculo.')),
                        'Versão/formato do cálculo: ' + str(r.get('version', r.get('format', 'Não fornecido.'))),
                        'A trilha JSON conserva a estrutura completa dos casos, ações, identidades, convergência e avisos.'], 'rows': []})
    if project.supplementary_en_resistance_gamma is not None:
        sections[-1]['paragraphs'].append('Base EN suplementar separada: gamma = ' + fmt(project.supplementary_en_resistance_gamma) +
            '; ' + project.supplementary_en_source + '. O fator não é prova de estabilidade: depende do produtor numérico e do domínio de C.2. Não há equivalência automática EN/NBR.')
    return sections


def support_receiving_rows(result):
    rows=[]
    for item in result.get('cases',[]):
        for key,bounds in (item.get('sweep') or {}).get('support_reaction_extrema',{}).items():
            if not key.endswith('/Fz'):continue
            candidates=[bounds.get(k) for k in ('min','max') if isinstance(bounds.get(k),Mapping)]
            if not candidates:continue
            peak=max(candidates,key=lambda p:abs(p['value']))
            support_index=(peak.get('coexistent_reaction_vector') or {}).get('support_index')
            vector=next((v for v in peak.get('coexistent_attachment_vectors',[]) if v.get('support_index')==support_index),None)
            if not vector:continue
            rows.append({'Caso / suspensão':str(peak.get('case_id',''))+' / '+str(vector.get('support_id',key)),
                         'Translação [mm]':fmt(peak.get('translation_mm')),
                         'Fx / Fy / Fz [kN]':' / '.join(fmt(vector[v]/1000) for v in ('Fx','Fy','Fz')),
                         'Mx / My / Mz [kN.m]':' / '.join(fmt(vector[v]/1e6) for v in ('Mx','My','Mz')),
                         'B [kN.m²]':fmt(vector.get('generalized_B',0)/1e9)})
    return rows


def fatigue_report_sections(project,result):
    f=result.get('fatigue') or {};inputs=f.get('physical_inputs') or getattr(project,'en_fatigue_inputs',None) or {}
    status=f.get('status','NOT_EVALUATED')
    status_text={
        'NOMINAL_METHOD_ZERO_CALCULATED_DAMAGE_SUFFICIENT':'Critério suficiente de dano nominal calculado nulo atendido para os modos e a região avaliados.',
        'SUFFICIENT_CHECK_NOT_SATISFIED':'Critério suficiente não satisfeito. Isso não demonstra falha por fadiga; requer avaliação mais completa do espectro/detalhe ou revisão de projeto.',
        'NUMERICAL_EVIDENCE_PENDING':'Evidência numérica ainda pendente; nenhum resultado suficiente de fadiga é afirmado.',
        'CONTACT_DOMAIN_SUFFICIENT_GUARD_INCONCLUSIVE':'Verificação suficiente do domínio de contato inconclusiva; não demonstra perda real de contato nem falha por fadiga.',
        'PHYSICAL_OR_METHOD_DOMAIN_PENDING':'Dados físicos ou domínio do método pendentes; nenhum resultado suficiente de fadiga é afirmado.',
        'NOT_EVALUATED':'Método nominal solicitado, mas resultado ainda não fornecido pelo cálculo.',
    }.get(status,status)
    if result.get('source_unchanged_during_calculation') is False:
        status_text+=' A fonte mudou durante o cálculo: resultado de desenvolvimento não utilizável sem nova execução com código estável.'
    paragraphs=[status_text,
        'Método EN 1993-1-9:2025 adotado separadamente. Escopo declarado: regiões ordinárias laminadas, com verificação global da mesa superior/alma separada da verificação global + local da mesa inferior. Não inclui furos da suspensão superior, seções líquidas/introdução local de carga, regiões perturbadas, ligações, emendas ou fadiga de contato.',
        'O dano nominal calculado nulo deste critério suficiente não é promessa de vida física ilimitada. Os casos FAT normais não substituem esta avaliação interna de todas as bases e intervalos.',
        'Dinâmica EN G / Q: '+fmt(inputs.get('dynamic_equipment'))+' / '+fmt(inputs.get('dynamic_lifted'))+
        '; gamma_Ff / gamma_Mf / gamma_Mser: '+' / '.join(fmt(inputs.get(k)) for k in ('gamma_ff','gamma_mf','gamma_mser'))]
    from .ui import FATIGUE_ENUMS,FATIGUE_SOURCE_FIELDS,FATIGUE_VERTICAL_MODELS
    model=inputs.get('vertical_operating_model')
    paragraphs.append('Operação vertical: '+FATIGUE_VERTICAL_MODELS.get(model,'Não declarada'))
    if model=='quasistatic_suspended_gravity_plus_horizontal':
        paragraphs.append('Mínimos G / Q = 0,95 / 1,00: vibração EN 13001-2 do equipamento e carga quase estática. Exclui aceleração descendente arbitrária, alívio/liberação e reversão de içamento.')
    elif model=='source_bounded_vertical_dynamics':
        paragraphs.append('Mínimos declarados G / Q: '+fmt(inputs.get('minimum_equipment_gravity'))+' / '+fmt(inputs.get('minimum_lifted_gravity'))+'. Base: '+inputs.get('minimum_gravity_source','Não informada'))
    paragraphs += [label+': '+('Declarado' if inputs.get(key)==token else 'Não informado') for key,(token,label) in FATIGUE_ENUMS.items()]
    source_labels={'action_source':'Ações e dinâmica','fixed_train_operating_limit_source':'Limite operacional','detail_condition_source':'Condição das regiões avaliadas','environment_source':'Ambiente','execution_source':'Execução/inspeção','nominal_method_adoption_source':'Adoção do método'}
    paragraphs += [source_labels[key]+': '+inputs[key] for key in FATIGUE_SOURCE_FIELDS if inputs.get(key)]
    if f.get('assessed_regions'):paragraphs.append('Regiões modeladas: '+'; '.join(f['assessed_regions']))
    if f.get('excluded_regions'):paragraphs.append('Regiões excluídas: '+'; '.join(f['excluded_regions']))
    points=list((f.get('lower_local_result') or {}).get('point_results',f.get('point_results',[])))
    if f.get('plain_global_result'):
        points.insert(0,dict(f['plain_global_result'],point={'id':'Regiões ordinárias da mesa superior/alma: global'}))
    rows=[{'Ponto':v.get('point',{}).get('id',v.get('physical_point','Não informado')),
           'Faixa principal / limite [MPa]':fmt(v.get('principal_range_mpa'))+' / '+fmt(v.get('normal_vafl_design_mpa')),
           'Faixa direta / limite [MPa]':fmt(v.get('direct_range_mpa'))+' / '+fmt(v.get('normal_vafl_design_mpa')),
           'Faixa cisalhante / limite [MPa]':fmt(v.get('shear_range_mpa'))+' / '+fmt(v.get('shear_vafl_design_mpa')),
           'Critérios satisfeitos':str(sum(value is True for value in v.get('checks',{}).values()))+' / '+str(len(v.get('checks',{}))),
           'Resultado suficiente':'Atendido no domínio' if v.get('qualified_nominal_detail_modes') else 'Não satisfeito, não é falha demonstrada'} for v in points]
    sections=[{'title':'7b. Fadiga nominal EN 2025 calculada internamente','paragraphs':paragraphs,'rows':rows}]
    if f.get('basis_run_summary'):
        sections.append({'title':'7b.1 Bases numéricas da avaliação nominal',
            'paragraphs':['Bases matemáticas lineares, não estados físicos isolados de contato. A qualificação numérica é produzida pelo programa, nunca por confirmação do usuário.'],
            'rows':[{'Base':v['case'],'Convergência numérica':fmt(v.get('numerical_converged',False)),'Ocorrência':v.get('error') or 'Nenhuma ocorrência registrada'} for v in f['basis_run_summary']]})
    return sections


def service_report_sections(project,result):
    service=result.get('serviceability') or {};physical=service.get('physical_inputs') or getattr(project,'service_inputs',None) or {}
    rows=[];identities=[]
    for i,span in enumerate(service.get('spans',[])):
        for check in span.get('checks',[]):
            direction='Vertical' if check.get('id')=='member_vertical_deformation' else 'Lateral'
            rows.append({'Trecho / vão [mm]':str(i+1)+' / '+fmt(span.get('span_mm')),'Direção':direction,
                         'Demanda / limite [mm]':fmt(check.get('demand_mm'))+' / '+fmt(check.get('limit_mm')),
                         'Utilização':fmt(check.get('utilization')),'Qualificado':fmt(check.get('qualified',False)),'Situação':check.get('status','PENDING')})
            g=check.get('governor') or {}
            identities.append({'Trecho / direção':str(i+1)+' / '+direction,'Caso':g.get('case_id','Não informado'),
                               'Translação / x [mm]':fmt(g.get('translation_mm'))+' / '+fmt(g.get('x_mm')),
                               'y / z da linha [mm]':fmt(g.get('line_y_mm'))+' / '+fmt(g.get('line_z_mm')),
                               'Resposta relativa assinada [mm]':fmt(g.get('relative_mm'))})
    failed=any(row['Situação']=='FAIL' and row['Qualificado']=='Sim' for row in rows)
    paragraphs=[('FALHA qualificada em deformação do membro.' if failed else 'Critérios de deformação do membro exibidos por trecho; pendência numérica não é PASS.'),
        'Base EN independente: resposta vertical sem dinâmica e resposta lateral com dinâmica característica própria, ambas na linha real de contato e relativas à corda entre apoios no mesmo estado. Não misturar com a referência NBR de peso próprio isolado.',
        'Critério vertical recomendado: min(L/600, 25 mm). Critério lateral análogo L/600: '+('adotado explicitamente.' if physical.get('lateral_project_limit_adopted') is True else 'não adotado ou não informado; não há aprovação lateral.'),
        'Velocidade máxima de içamento declarada: '+fmt(physical.get('hoist_speed_max_m_s'))+' m/s. '+str(physical.get('method_adoption_source','')),
        str(physical.get('drive_source','')),
        'Somente a configuração aplicada. As duas vias, seu diferencial/alinhamento real, a deformação local de contato e a flexibilidade/deslizamento das ligações são verificações separadas. As demandas à estrutura receptora são saídas, não aprovação do edifício.']
    sections=[dict(title='7e. Deformação em serviço do membro',paragraphs=paragraphs,rows=rows)]
    if identities:sections.append(dict(title='7e.1 Estados governantes de deformação relativa',paragraphs=['Sinais, posição, caso e linha de contato são inseparáveis. Nenhum valor combina extremos de estados diferentes.'],rows=identities))
    return sections


def contact_report_sections(project,result):
    aliases={w.id:('R'+str(i+1) if '/' in w.id else w.id) for i,w in enumerate(project.wheels)}
    contact=result.get('contact') or {};physical=contact.get('physical_inputs') or getattr(project,'contact_inputs',None) or {}
    statuses={'CONTACT_INPUT_REQUIRED':'Dados físicos de contato ainda necessários.',
              'CONTACT_PENDING':'Contato completo pendente; os critérios do domínio de ações coberto são apresentados separadamente.',
              'CONTACT_COVERED_DOMAIN_FAIL_WITH_PENDING':'FALHA no domínio de contato coberto, com outras ações ou condições ainda pendentes.',
              'CONTACT_FAIL':'FALHA nos critérios de contato avaliados.',
              'CONTACT_PASS':'Critérios de contato atendidos no domínio qualificado informado.',
              'CONTACT_PHYSICAL_OR_METHOD_DOMAIN_PENDING':'Dados físicos ou domínio de contato pendentes.'}
    status=statuses.get(contact.get('status'),'Resultado de contato não fornecido pelo cálculo.')
    if contact.get('known_covered_domain_failure') and 'FALHA' not in status:
        status='FALHA conhecida no domínio de ações coberto. '+status
    paragraphs=[status,
        'Método de contato EN 13001 separado da resistência nominal da mesa, fadiga estrutural e ligações. As ações e contagens são geradas internamente para a configuração aplicada; não há forças ou histórico de pressão externos.',
        'PASS/FAIL na tabela vale somente para as ações e contagens cobertas. Pendência de outras ações não apaga uma falha qualificada já calculada. Não é aprovação integral A/B/C, da viga, da suspensão ou da estrutura receptora.']
    rows=[]
    labels={'wheel_static':'Roda estática','wheel_fatigue':'Roda fadiga de contato','flange_static':'Mesa estática','flange_fatigue':'Mesa fadiga de contato'}
    for wheel in contact.get('rows',[]):
        for check in wheel.get('covered_action_checks',[]):
            rows.append({'Roda':aliases.get(wheel['wheel_id'],wheel['wheel_id']),'Critério':labels.get(check.get('id'),check.get('id')),
                         'Limite [N]':fmt(check.get('capacity_N')),'Utilização':fmt(check.get('utilization')),
                         'Domínio qualificado':fmt(check.get('qualified',False)),'Situação coberta':check.get('status','PENDING')})
    sections=[dict(title='7d. Contato roda e mesa inferior calculado internamente',paragraphs=paragraphs,rows=rows)]
    if physical:
        from .ui import CONTACT_OPERATING_NUMBERS,CONTACT_MOUNTINGS
        operating=physical['operating'];flange=physical['flange']
        sections.append(dict(title='7d.1 Limites físicos de operação e material da mesa',
            paragraphs=['Domínio declarado: '+('pista lisa interna, sem liberação nem impactos, operação normal e ensaios' if operating['operating_domain']=='indoor_smooth_track_no_release_no_impacts_normal_and_tests' else str(operating['operating_domain']))+'. Escopo de massa: '+('inclui carga, moitão, lingas e todos os acessórios suspensos' if operating['hoist_mass_scope']=='capacity_mass_includes_all_suspended_attachments' else str(operating['hoist_mass_scope']))+'.',
                        'Mesa inferior: HBW '+fmt(flange['hardness_HBW'])+', profundidade material '+fmt(flange['verified_depth_mm'])+' mm; estado '+str(flange['material_state'])+'. '+flange['hardness_source']]+[operating[key] for key in ('action_model_source','lifetime_operating_limit_source','contact_arrangement_source')],
            rows=[{'Limite físico':label,'Valor':fmt(operating[key])} for key,label in CONTACT_OPERATING_NUMBERS.items()]))
        sections.append(dict(title='7d.2 Material e geometria por identidade de roda',
            paragraphs=['Deslocamentos laterais positivos apontam para a alma em ambos os balanços. Raio de coroamento None significa banda cilíndrica explicitamente declarada, não dado desconhecido. Não se infere dureza a partir de fy.'],
            rows=[{'Roda':aliases.get(w['wheel_id'],w['wheel_id']),'HBW / profundidade [mm]':fmt(w['hardness_HBW'])+' / '+fmt(w['verified_depth_mm']),
                   'E [MPa]':fmt(w['E_MPa']),'Diâmetro / largura / canto [mm]':' / '.join(fmt(w[key]) for key in ('wheel_diameter_mm','wheel_material_width_mm','wheel_corner_radius_mm')),
                   'Coroamento [mm]':'Cilíndrica' if w['crown_radius_mm'] is None else fmt(w['crown_radius_mm']),
                   'Curso lateral min / max [mm]':fmt(w['lateral_min_toward_web_mm'])+' / '+fmt(w['lateral_max_toward_web_mm'])} for w in physical['wheels']]))
        sections.append(dict(title='7d.3 Montagem e contagens de contato',
            paragraphs=['Contagens de contato de roda/pista, esforços, fontes e estados coexistentes completos são preservados no JSON; não equivalem à contagem de ciclos de fadiga estrutural.'],
            rows=[{'Roda':aliases.get(w['wheel_id'],w['wheel_id']),'Classe / montagem':str(w['tolerance_class'])+' / '+CONTACT_MOUNTINGS.get(w['mounting'],w['mounting']),
                   'Folga / desgaste [rad]':fmt(w['guide_slack_skew_rad'],5)+' / '+fmt(w['wear_skew_rad'],5),
                   'Motriz / abrasivo':fmt(w['driven_wheel'])+' / '+fmt(w['abrasive_environment']),
                   'Contagens roda / pista':str(next((v.get('counts',{}).get('wheel_contacts','Não gerado') for v in contact.get('rows',[]) if v['wheel_id']==w['wheel_id']),'Não gerado'))+' / '+str(next((v.get('counts',{}).get('flange_contacts','Não gerado') for v in contact.get('rows',[]) if v['wheel_id']==w['wheel_id']),'Não gerado'))} for w in physical['wheels']]))
        sources=list(dict.fromkeys(w[key] for w in physical['wheels'] for key in ('hardness_source','geometry_source','alignment_and_mounting_source')))
        sections[-1]['paragraphs'] += sources
    return sections


def physical_contact_rows(result):
    rows=[]
    for item in result.get('cases',[]):
        audit=item.get('physical_contact_audit') or {}
        if not audit: continue
        receipt=audit.get('receipt') or {}
        forces=receipt.get('loads',audit.get('forces',[]))
        upward=receipt.get('uplift_contacts',audit.get('uplift_contacts',[]))
        rows.append({'Caso':item.get('case',{}).get('id','Não identificado'),
                     'Contatos examinados':len(forces),
                     'Escopo':'Oito contatos da ponte' if receipt else ('Trem informado' if audit.get('physical_case') else 'Base matemática, não física'),
                     'Domínio unilateral':'Válido no modelo' if audit.get('contact_domain_valid') else 'INVÁLIDO: perda de contato',
                     'Contatos ascendentes':'; '.join(upward) or 'Nenhum'})
    return rows


def member_check_rows(result):
    rows=[]
    for item in result.get('cases',[]):
        stability=item.get('stability') or {}
        for check in stability.get('checks',[]):
            rows.append({'Caso / trecho [mm]':str(check.get('case_id',item.get('case',{}).get('id',''))) + ' / ' + fmt(check.get('segment_start_mm')) + '–' + fmt(check.get('segment_end_mm')),
                         'Critério':check.get('title',check.get('id','Não identificado')),
                         'Demanda / limite':fmt(check.get('demand'))+' / '+fmt(check.get('capacity')),
                         'Utilização':fmt(check.get('utilization')),
                         'Qualificado':fmt(check.get('qualified',False)),
                         'Situação':check.get('status','Não informada')})
    return rows


def bridge_pending_items(project):
    ledger = getattr(project, 'bridge_reaction_ledger', None)
    if not ledger: return []
    if ledger.get('schema') == 'LRO_BOUND_BRIDGE_INERTIA_LEDGER_V1':
        return [
            'Ponte, transferência física: o modelo bilinear/equalizado e zero autoesforço diagonal adicional são requisitos adotados; compatibilidade do acionamento, equalizador e guias reais ainda precisa ser demonstrada.',
            'Ponte, domínio operacional: esta execução utiliza somente a configuração de gancho, ponto de aplicação da força e via selecionada; as demais hipóteses admissíveis não compõem este resultado.',
            'Ponte, ações adicionais: rolamento/desalinhamento, batentes, emergência e ensaio não são derivados do modelo normal de inércia.',
        ]
    pending = [
        'Ponte, redistribuição vertical por inércia: faltam alturas dos centros de massa e mecanismo real; as reações G/Q geradas são somente gravitacionais.',
        'Ponte, tração/frenagem e rolamento: localização de rodas motrizes/freadas, partilha real, exigência de ação mínima/máxima e efeitos de desalinhamento não foram qualificados.',
        'Ponte, dinâmica horizontal: fator adicional explicitamente adotado, sem solução de transientes ou balanço da carga suspensa.',
        'Outras configurações de gancho/via: esta execução corresponde somente à configuração selecionada; não é envelope integral da ponte.',
    ]
    if any(not h['yaw_balance_without_additional_transfer'] for h in ledger['endpoint_receipt']['horizontal'].values()):
        pending.append('Ponte, momento horizontal: há transferência adicional de Mz não modelada, quantificada no balanço selecionado. O equilíbrio completo da ponte não está demonstrado.')
    return pending


def bridge_report_sections(project, aliases):
    """Capacity/input ledger and correlated reactions, never componentwise maxima."""
    from .ui import BRIDGE_NUMERIC_FIELDS, BRIDGE_SOURCE_FIELDS
    from ..autonomous_workflow.bridge_reactions import generate_bridge_reactions
    ledger = project.bridge_reaction_ledger
    if ledger.get('schema') == 'LRO_BOUND_BRIDGE_INERTIA_LEDGER_V1':
        return inertia_report_sections(project, aliases)
    inputs, selected, endpoint = ledger['inputs'], ledger['selected_configuration'], ledger['endpoint_receipt']
    receipt = generate_bridge_reactions(project.section, inputs)
    rows = [{'Entrada física': label, 'Valor declarado': fmt(inputs[key])} for key, label in BRIDGE_NUMERIC_FIELDS.items()]
    sections = [{
        'title': '4a. Capacidade e dados físicos da ponte',
        'paragraphs': ['Capacidade é massa em toneladas métricas, convertida por 1000 × g para N; não é força em tf. '
                       'A massa da ponte inclui cabeceiras e exclui o carro. A composição de moitão/acessórios deve corresponder à declaração física.',
                       'O vão transversal entre vias é independente do comprimento longitudinal da viga e do espaçamento de suspensões. '
                       'Arranjo explicitamente adotado: duas estações longitudinais com duas rodas opostas cada, equalizadas por via.',
                       'Configuração aplicada: ' + selected['id'] + '. As quatro configurações abaixo são alternativas, nunca somadas nem tomadas como máximos coexistentes.',
                       'Identidades das rodas: ' + '; '.join(alias + ' = ' + ident for ident, alias in aliases.items())],
        'rows': rows,
    }, {
        'title': '4b. Configurações correlacionadas de gancho e via',
        'paragraphs': ['Coordenadas de gancho e CG do carro são medidas desde a via esquerda. G e Q de cada linha pertencem à mesma configuração. '
                       'Somente a configuração aplicada foi encaminhada à análise desta viga.'],
        'rows': [{'Configuração': c['id'], 'Gancho / CG carro [mm]': fmt(c['hook_from_left_mm']) + ' / ' + fmt(c['trolley_cg_from_left_mm']),
                  'G / Q na via [kN]': fmt(c['gravity_rail_reactions']['dead_G_N']/1000) + ' / ' + fmt(c['gravity_rail_reactions']['lifted_Q_N']/1000),
                  'Aplicada': 'Sim' if c['id'] == selected['id'] else 'Não'} for c in receipt['configurations']],
    }, {
        'title': '4c. Ações horizontais coexistentes por roda',
        'paragraphs': ['Forças características assinadas antes dos fatores de caso. Hx = −massa longitudinal × ax × kH; '
                       'Hy = −massa carro/carga × ay × kH, com frações de via explícitas. No vazio, a massa içada é zero. '
                       'O gerador de casos aplica seus fatores e reversões depois; não reaplica psi vertical a H.'],
        'rows': [{'Roda': aliases[w.id], 'Hx / Hy carregado [kN]': fmt(w.longitudinal_N/1000) + ' / ' + fmt(w.transverse_N/1000),
                  'Hx / Hy vazio [kN]': fmt(w.longitudinal_empty_N/1000) + ' / ' + fmt(w.transverse_empty_N/1000)} for w in project.wheels],
    }, {
        'title': '4d. Balanço gravitacional do extremo selecionado',
        'paragraphs': ['As duas vias participam deste balanço gravitacional. O fechamento de G/Q não demonstra equilíbrio dinâmico completo.'],
        'rows': [{'Componente': key, 'Força aplicada [N]': fmt(value['applied_force_N']),
                  'Resíduo força [N]': fmt(value['force_residual_N'],6),
                  'Resíduo momento [N.mm]': fmt(value['moment_residual_Nmm'],6)} for key, value in endpoint['gravity_equilibrium'].items()],
    }, {
        'title': '4e. Balanço horizontal do extremo selecionado',
        'paragraphs': ['Momento Mz referido à via esquerda; resíduo assinado = momento inercial exigido menos momento transmitido pelas forças nas rodas modeladas. '
                       'Valor diferente de zero é transferência adicional exigida do mecanismo, não uma reação automaticamente distribuída às rodas.'],
        'rows': [{'Estado': state, 'Mz exigido [kN.m]': fmt(h['required_inertial_yaw_Mz_Nmm']/1e6),
                  'Mz das rodas [kN.m]': fmt(h['modeled_wheel_yaw_Mz_Nmm']/1e6),
                  'Transferência adicional [kN.m]': fmt(h['required_additional_yaw_transfer_Nmm']/1e6)} for state,h in endpoint['horizontal'].items()],
    }, {
        'title': '4f. Origem das ações geradas',
        'paragraphs': [label + ': ' + inputs[key] for key,label in BRIDGE_SOURCE_FIELDS.items()] +
                      ['Base mecânica: ' + receipt['source'], 'Assinatura dos dados da ponte: ' + ledger['input_signature']],
        'rows': [],
    }]
    return sections


def inertia_report_sections(project, aliases):
    from .ui import INERTIA_NUMERIC_FIELDS, INERTIA_SOURCE_FIELDS, INERTIA_TRANSFER_MODELS, active_inertia_numeric_fields
    from ..autonomous_workflow.inertia_bridge_adapter import generate_inertia_configurations
    ledger=project.bridge_reaction_ledger;inputs=ledger['inputs'];selected=ledger['selected_configuration'];endpoint=ledger['endpoint_receipt']
    receipt=generate_inertia_configurations(project.section,inputs)
    free=inputs.get('transfer_model')=='free_suspended_at_crab'
    transfer_text=('Carga livre por cabos: força equivalente aplicada imediatamente abaixo do carro, conforme EN 13001-2, 4.2.2.5, nas coordenadas x/z declaradas. O CG profundo da carga e sua elevação não são usados neste modelo.' if free else 'Carga guiada ou rígida: transferência adotada no CG físico da carga e em sua faixa de altura. Esta alternativa não representa automaticamente uma carga livre por cabos.')
    vector=lambda values,scale=1.: ' / '.join(fmt(v/scale) for v in values)
    rows=[]
    for w in project.wheels:
        for state,empty in (('carregado',False),('vazio',True)):
            rows.append({'Roda / estado': aliases[w.id]+' / '+state,
                         'Hx / Hy [kN]': vector([w.longitudinal_empty_N if empty else w.longitudinal_N,w.transverse_empty_N if empty else w.transverse_N],1000),
                         'Fz de Hx / Fz de Hy [kN]':vector([w.longitudinal_vertical_empty_N if empty else w.longitudinal_vertical_N,w.transverse_vertical_empty_N if empty else w.transverse_vertical_N],1000)})
    return [{
        'title':'4a. Capacidade, centros de massa e inércia 3D',
        'paragraphs':['Configuração aplicada: '+selected['id']+'. Capacidade em toneladas métricas de massa. Ponte com cabeceiras e sem carro, conforme composição física declarada.',
                      'Referencial da ponte: ξ longitudinal desde o centro do trem, y desde a via esquerda, z positivo para cima desde o plano comum de contato. A posição física de cada roda na viga é x = a + ξ. Valores negativos de z representam centros abaixo desse plano.',
                      transfer_text,
                      'Na viga selecionada, a excentricidade y das rodas é local à seção: ±(b/2 − n). A distância global entre vias não é aplicada como excentricidade da viga.',
                      'Modelo bilinear/equalizado explicitamente adotado, com zero autoesforço diagonal adicional de tombamento. Forças e momentos são equilibrados nos oito contatos para cada parcela; isso não comprova o mecanismo real.',
                      'Identidades das rodas: '+'; '.join(alias+' = '+ident for ident,alias in aliases.items())],
        'rows':[{'Entrada física':label,'Valor declarado':fmt(inputs[key])} for key,label in active_inertia_numeric_fields(inputs).items()],
    },{
        'title':'4b. Hipóteses correlacionadas de gancho, altura e via',
        'paragraphs':['Registros correlacionados, nunca somados nem combinados por máximos independentes. Somente a hipótese aplicada entra nesta execução.',
                      'Os dois registros de altura coincidem no ponto equivalente imediatamente abaixo do carro; não são duas elevações físicas da carga livre.' if free else 'Os extremos de CG da carga guiada e gancho são preservados mesmo quando numericamente iguais.'],
        'rows':[{'Configuração':c['id'],'Gancho / z de aplicação [mm]':vector([c['hook_from_left_mm'],c['lifted_force_application_z_mm']]),
                 'G / Q útil / B retida na via [kN]':vector([sum(w['dead_N'] for w in c['wheels']),sum(w['lifted_N'] for w in c['wheels'])],1000)+' / '+(fmt(sum(w.get('retained_lifted_N',0.) for w in c['wheels'])/1000) if project.suspended_mass_basis().get('complete_suspended_mass_accounting') else 'Não declarada'),
                 'Aplicada':'Sim' if c['id']==selected['id'] else 'Não'} for c in receipt['configurations']],
    },{
        'title':'4c. Parcelas de inércia coexistentes por roda',
        'paragraphs':['Fz de Hx e Fz de Hy são redistribuições verticais assinadas, positivas para cima; não são peso G nem carga içada Q. Cada parcela acompanha o mesmo fator e sinal da ação horizontal correspondente. Na composição comum, o estado vazio exclui somente a carga útil e conserva a massa suspensa retida.',
                      'A verificação de cada caso deve examinar os oito contatos da ponte, incluindo a via não selecionada. Contato com força resultante ascendente fica fora do modelo sem retenção, sem truncamento artificial a zero.'],
        'rows':rows,
    },{
        'title':'4d. Equilíbrio vetorial nos oito contatos',
        'paragraphs':['Balanço por massa e parcela no estado geométrico selecionado. Vetores na ordem x / y / z. Resíduos são transmitido menos aplicado; os valores completos aplicados/transmitidos e cada contato estão preservados no registro JSON.'],
        'rows':[{'Massa / parcela':v['mass_id']+' / '+v['action'],
                 'Força aplicada [kN]':vector(v['expected']['force_N'],1000),
                 'Momento aplicado [kN.m]':vector(v['expected']['moment_Nmm'],1e6),
                 'Máx |resíduo F| [N]':fmt(max(abs(x) for x in v['residual']['force_N']),9),
                 'Máx |resíduo M| [N.mm]':fmt(max(abs(x) for x in v['residual']['moment_Nmm']),9)} for v in endpoint['generated']['equilibrium']],
    },{
        'title':'4e. Origem e modelo das ações geradas',
        'paragraphs':[label+': '+inputs[key] for key,label in INERTIA_SOURCE_FIELDS.items()]+[
            'Assinatura dos dados da ponte: '+ledger['input_signature'],
            'A gravidade e as parcelas completas HX/HY são multiplicadas separadamente na geração de casos; a dinâmica vertical não é reaplicada à inércia horizontal.'],
        'rows':[],
    }]


def section_schematic_svg(project):
    """Physical top suspension vs bottom contact; schematic, not fabrication."""
    s = project.section
    props = geometric_properties(s)
    # Uniform scale retains physical aspect ratio, labels outside flange bounds.
    scale = min(300 / s.d_mm, 250 / s.bf_mm)
    cx, top = 270., 80.
    d, b, tf, tw = s.d_mm * scale, s.bf_mm * scale, s.tf_mm * scale, s.tw_mm * scale
    bottom = top + d
    def line(x1,y1,x2,y2,color='#334155',width=2):
        return f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" stroke="{color}" stroke-width="{width}"/>'
    elements = ['<svg xmlns="http://www.w3.org/2000/svg" width="680" height="460" viewBox="0 0 680 460">',
                '<rect width="680" height="460" fill="#ffffff"/>',
                '<g font-family="DejaVu Sans,Arial,sans-serif" font-size="14" fill="#172b4d">',
                '<text x="24" y="28" font-size="18" font-weight="bold">Suspensão superior / contato inferior</text>']
    for x,y,w,h in ((cx-b/2,top,b,tf),(cx-tw/2,top+tf,tw,d-2*tf),(cx-b/2,bottom-tf,b,tf)):
        elements.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" fill="#dce5ef" stroke="#334155"/>')
    elements += [line(cx,top-24,cx,bottom+24,'#94a3b8',1),
                 '<text x="440" y="72" fill="#075985">Mesa superior</text>', line(cx+b/2,top,430,67,'#075985')]
    for support in project.supports:
        sx = cx + support['y'] * scale
        elements += [f'<circle cx="{sx}" cy="{top}" r="5" fill="#0284c7"/>',line(sx,top-30,sx,top,'#0284c7',3)]
    elements.append('<text x="440" y="94" fill="#075985">Pontos de suspensão</text>')
    wheel_y = []
    for wheel in project.wheels:
        if wheel.y_mm not in wheel_y:
            wheel_y.append(wheel.y_mm)
            wx = cx + wheel.y_mm * scale
            wy = bottom - tf
            elements += [f'<circle cx="{wx}" cy="{wy}" r="5" fill="#be123c"/>',
                         line(wx,wy-25,wx,wy,'#be123c',2)]
    elements += [line(cx+b/2,bottom-tf,430,bottom-tf-10,'#be123c'),
                 f'<text x="440" y="{bottom-tf-12}" fill="#be123c">Contato da roda</text>',
                 f'<text x="440" y="{bottom-tf+10}" fill="#be123c">na face superior</text>',
                 f'<text x="440" y="{bottom-tf+30}" fill="#be123c">da mesa inferior</text>',
                 '<text x="24" y="420">z positivo para cima; y transversal; x longitudinal.</text>',
                 '<text x="24" y="444" font-size="12">Esquema de coordenadas, sem detalhamento de ligações ou contato finito.</text>', '</g></svg>']
    return ''.join(elements)


def section_schematic_png(project):
    """Pillow fallback: legible static drawing for Word, no browser dependency."""
    from PIL import Image, ImageDraw, ImageFont
    im = Image.new('RGB', (1360, 740), 'white')
    draw = ImageDraw.Draw(im)
    font_path = '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
    try:
        font = ImageFont.truetype(font_path, 26)
        small = ImageFont.truetype(font_path, 23)
    except OSError:
        font = small = ImageFont.load_default()
    s = project.section
    scale = min(480 / s.d_mm, 400 / s.bf_mm)
    cx, top = 510., 100.
    d, b, tf, tw = s.d_mm*scale, s.bf_mm*scale, s.tf_mm*scale, s.tw_mm*scale
    bottom = top + d
    draw.text((30, 20), 'Suspensão superior / contato inferior', font=font, fill='#172b4d')
    for x,y,w,h in ((cx-b/2,top,b,tf),(cx-tw/2,top+tf,tw,d-2*tf),(cx-b/2,bottom-tf,b,tf)):
        draw.rectangle((x,y,x+w,y+h), fill='#dce5ef', outline='#334155', width=2)
    for supp in project.supports:
        x = cx + supp['y']*scale
        draw.line((x, top-40,x,top), fill='#0284c7', width=4)
        draw.ellipse((x-7,top-7,x+7,top+7),fill='#0284c7')
    draw.line((cx+b/2,top,800,top-15),fill='#0284c7',width=2)
    draw.text((820, top-35), 'Pontos de suspensão',font=font,fill='#075985')
    draw.text((820, top), 'na mesa superior',font=small,fill='#075985')
    for y in set(w.y_mm for w in project.wheels):
        x, z = cx+y*scale, bottom-tf
        draw.line((x,z-35,x,z),fill='#be123c',width=3)
        draw.ellipse((x-7,z-7,x+7,z+7),fill='#be123c')
    draw.line((cx+b/2,bottom-tf,800,bottom-tf-20),fill='#be123c',width=2)
    draw.text((820,bottom-tf-45),'Contato da roda',font=font,fill='#be123c')
    draw.text((820,bottom-tf-5),'na face superior',font=small,fill='#be123c')
    draw.text((820,bottom-tf+30),'da mesa inferior',font=small,fill='#be123c')
    draw.text((30, 655),'z positivo para cima; y transversal; x longitudinal.',font=small,fill='#334155')
    draw.text((30, 695),'Esquema de coordenadas, não detalhamento de fabricação.',font=small,fill='#334155')
    output = BytesIO(); im.save(output,format='PNG')
    return output.getvalue()


def build_report_docx(project, result, *, payload=None, include_diagnostics=False, document_metadata=None):
    """Return editable Word bytes with readable scope, inputs and response."""
    result = result_mapping(result)
    if result.get('project_signature') != signature(project.to_dict()):
        raise ValueError('O resultado não pertence às entradas físicas atuais; recalcular antes de exportar a memória.')
    from docx import Document
    from docx.shared import Inches, Pt, RGBColor
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn
    from lro_beams.document_metadata import DOCUMENT_FIELDS, validate_document_metadata
    payload_metadata = validate_document_metadata((payload or {}).get('document_metadata', {}))
    metadata = payload_metadata if document_metadata is None else validate_document_metadata(document_metadata)
    if document_metadata is not None and payload_metadata and metadata != payload_metadata:
        raise ValueError('Identificações documentais divergentes; fornecer uma única identificação atual.')
    document = Document()
    section = document.sections[0]
    section.page_width, section.page_height = Inches(8.27), Inches(11.69)
    section.top_margin = section.bottom_margin = Inches(.65)
    section.left_margin = section.right_margin = Inches(.65)
    normal = document.styles['Normal']
    normal.font.name = 'DejaVu Sans'; normal.font.size = Pt(9); normal.font.color.rgb = RGBColor(0,0,0)
    normal.paragraph_format.space_after = Pt(5)
    for name in ('Title','Heading 1','Heading 2'):
        document.styles[name].font.name = 'DejaVu Sans'
        document.styles[name].font.color.rgb = RGBColor(0,0,0)
    # Some bundled Word templates give Title a bottom border; remove it.
    for style in document.styles:
        ppr = style.element.find(qn('w:pPr'))
        if ppr is not None:
            for border in list(ppr.findall(qn('w:pBdr'))):
                ppr.remove(border)
    document.core_properties.title = 'Memória de cálculo da viga de rolamento'
    document.core_properties.subject = 'Modelo autônomo candidato, entradas físicas e qualificação parcial'
    document.core_properties.author = ''
    footer=section.footer.paragraphs[0]
    footer.alignment=2
    footer.add_run('Memória de cálculo | página ')
    field=OxmlElement('w:fldSimple');field.set(qn('w:instr'),'PAGE');footer._p.append(field)
    for run in footer.runs:run.font.name='DejaVu Sans';run.font.size=Pt(8);run.font.color.rgb=RGBColor(0,0,0)
    document.add_paragraph('Memória de cálculo da viga de rolamento',style='Title')
    document.add_paragraph('Perfil I/W laminado • dados físicos, casos internos e rastreabilidade')
    if metadata:
        identity = document.add_table(rows=0, cols=2)
        identity.style = 'Table Grid'
        borders = OxmlElement('w:tblBorders')
        for edge in ('top','left','bottom','right','insideH','insideV'):
            border=OxmlElement('w:'+edge);border.set(qn('w:val'),'single');border.set(qn('w:sz'),'4');border.set(qn('w:color'),'D9D9D9');borders.append(border)
        identity._tbl.tblPr.append(borders)
        for key in DOCUMENT_FIELDS:
            if key not in metadata:
                continue
            value = metadata[key]
            cells = identity.add_row().cells
            cells[0].text = DOCUMENT_FIELDS[key]
            cells[1].text = value
            identity.rows[-1]._tr.get_or_add_trPr().append(OxmlElement('w:cantSplit'))
            for cell in cells:
                for paragraph in cell.paragraphs:
                    paragraph.paragraph_format.space_after=Pt(2)
                    for run in paragraph.runs:
                        run.font.name='DejaVu Sans';run.font.size=Pt(8)
    diagram = governing_state_diagram(project, result)
    for i, data in enumerate(report_sections(project,result,payload=payload,include_diagnostics=include_diagnostics)):
        import re
        document.add_heading(re.sub(r'[.,:;()/]', ' ', data['title']), 1)
        for paragraph_index,text in enumerate(data['paragraphs']):
            paragraph=document.add_paragraph(text)
            if paragraph_index==0 and len(data['paragraphs'])>1:
                paragraph.paragraph_format.keep_with_next=True
            if not data.get('criterion') and data['title'].startswith('10.'):
                paragraph.paragraph_format.space_after=Pt(3)
                for run in paragraph.runs:run.font.size=Pt(8)
        if i == 2:
            if result.get('format')=='LRO_AUTONOMOUS_UNDERSLUNG_FAMILY_ANALYSIS':
                from .family_report import physical_elevation_png
                document.add_picture(BytesIO(physical_elevation_png(project)),width=Inches(6.8))
            document.add_picture(BytesIO(section_schematic_png(project)),width=Inches(6.8))
        if data.get('rows'):
            keys = list(data['rows'][0])
            table = document.add_table(rows=1, cols=len(keys))
            table.style = 'Table Grid'
            for cell, key in zip(table.rows[0].cells, keys):
                cell.text = key
            trpr = table.rows[0]._tr.get_or_add_trPr()
            repeat = OxmlElement('w:tblHeader'); repeat.set(qn('w:val'),'true'); trpr.append(repeat)
            trpr.append(OxmlElement('w:cantSplit'))
            for row in data['rows']:
                cells = table.add_row().cells
                for cell, key in zip(cells, keys):
                    cell.text = str(row.get(key, ''))
                    for paragraph in cell.paragraphs:
                        for run in paragraph.runs:
                            run.font.size = Pt(8)
                props = table.rows[-1]._tr.get_or_add_trPr()
                props.append(OxmlElement('w:cantSplit'))
            # Explicit, template-independent professional table formatting.
            borders=OxmlElement('w:tblBorders')
            for edge in ('top','left','bottom','right','insideH','insideV'):
                border=OxmlElement('w:'+edge);border.set(qn('w:val'),'single');border.set(qn('w:sz'),'4');border.set(qn('w:color'),'D9D9D9');borders.append(border)
            table._tbl.tblPr.append(borders)
            for ri,row in enumerate(table.rows):
                for ci,cell in enumerate(row.cells):
                    from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT
                    cell.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
                    shading=OxmlElement('w:shd');shading.set(qn('w:fill'),'173858' if ri==0 else ('F1F4F7' if ri%2 else 'FFFFFF'));cell._tc.get_or_add_tcPr().append(shading)
                    margins=OxmlElement('w:tcMar')
                    for edge,val in (('top','55'),('bottom','55'),('left','70'),('right','70')):
                        node=OxmlElement('w:'+edge);node.set(qn('w:w'),val);node.set(qn('w:type'),'dxa');margins.append(node)
                    cell._tc.get_or_add_tcPr().append(margins)
                    for paragraph in cell.paragraphs:
                        paragraph.paragraph_format.space_after=Pt(1)
                        paragraph.paragraph_format.space_before=Pt(1)
                        if ri==0:paragraph.paragraph_format.keep_with_next=True
                        for run in paragraph.runs:
                            run.font.name='DejaVu Sans';run.font.size=Pt(8);run.font.bold=ri==0
                            run.font.color.rgb=RGBColor(255,255,255) if ri==0 else RGBColor(0,0,0)
            document.add_paragraph('')
        if data['title'].startswith('5.') and diagram:
            document.add_heading('Elevação e diagramas do estado governante de w', 1)
            document.add_picture(BytesIO(diagram['png']), width=Inches(6.8))
            # Case, numerical status and sign legend are embedded in the figure,
            # so its caption cannot be orphaned on the following page.
            # Full bridge wheel identities are already mapped in section 4a.
    output = BytesIO(); document.save(output)
    return output.getvalue()


def governing_state_diagram(project, result):
    """Reconstruct one computed signed state, not an invented envelope diagram.

    Uses the result's exact rational train event, case, final mesh and current
    project signature. Returns None if no qualified input state is available.
    """
    from fractions import Fraction
    from ..autonomous_workflow.model import MovingCase, physical_train_at
    from PIL import Image, ImageDraw, ImageFont
    result = result_mapping(result)
    if result.get('project_signature') != signature(project.to_dict()):
        raise ValueError('Estado gráfico não corresponde ao projeto atual.')
    if not numerical_source_matches(result):return None
    candidates = []
    for row in result.get('cases', []):
        metric, peak = _contact_peak((row.get('sweep') or {}).get('extrema', {}), 'w')
        if peak and row.get('mesh_history'):
            candidates.append((row, metric, peak))
    if not candidates:
        return None
    row, metric, peak = max(candidates, key=lambda item: abs(item[2]['value']))
    case = MovingCase(**row['case'])
    a = peak['translation_mm']
    raw_exact = peak.get('translation_exact_mm')
    exact = Fraction(int(raw_exact['numerator']), int(raw_exact['denominator'])) if raw_exact else Fraction(a)
    wheel_id = metric[len('contact/'):-len('/w')]
    wheel = next(w for w in project.wheels if w.id == wheel_id)
    aliases = {w.id: ('R' + str(i+1) if '/' in w.id else w.id) for i,w in enumerate(project.wheels)}
    mesh = row['mesh_history'][-1]['max_element_length_mm']
    model = project.frame_model(mesh)
    loads = physical_train_at(project.wheels, case, a, project.length_mm, exact_translation=exact)
    q = -(project.selfweight()*case.support_dead + project.extra_dead_N_per_mm*case.extra_dead)
    mx = -project.extra_dead_N_per_mm*case.extra_dead*(project.extra_dead_y_mm or 0.)
    solution = model.solve(loads, [dict(start=0., end=project.length_mm, qz=q, mx=mx)] if q or mx else [])
    solution.translation_exact = exact
    xs = sorted({project.length_mm*i/120 for i in range(121)} | set(model.nodes) | {v['x'] for v in loads})
    points = [(x, side, solution.at(x, side)) for x in xs for side in ('left', 'right')]
    W, H = 1600, 1390
    im = Image.new('RGB', (W, H), 'white'); draw = ImageDraw.Draw(im)
    face = '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
    try:
        title = ImageFont.truetype(face, 34); font = ImageFont.truetype(face, 27); small = ImageFont.truetype(face, 23)
    except OSError:
        title = font = small = ImageFont.load_default()
    blue, gray, red = '#173858', '#64748b', '#be123c'
    left, right = 120., 1480.
    xpix = lambda x: left + (right-left)*x/project.length_mm
    draw.text((40, 20), 'Viga suspensa | elevação e resposta assinada', font=title, fill=blue)
    draw.text((40, 74), 'Estado: ' + case.id + ' | translação = ' + fmt(a) + ' mm', font=font, fill=blue)
    draw.text((40, 115), 'Mesmo estado e malha final; não é envelope. Convergência: ' + ('demonstrada.' if row.get('numerical_converged') else 'pendente no orçamento numérico.'), font=small, fill=gray)
    top, bottom = 230, 295
    draw.rectangle((left, top, right, bottom), fill='#e2e8f0', outline=blue, width=3)
    draw.line((left, top+9, right, top+9), fill=blue, width=2)
    draw.line((left, bottom-9, right, bottom-9), fill=blue, width=2)
    supports = sorted(project.supports, key=lambda v:v['x'])
    for i, support in enumerate(supports):
        px = xpix(support['x'])
        draw.line((px,top-38,px,top),fill='#0284c7',width=4)
        draw.line((px-15,top-38,px+15,top-38),fill='#0284c7',width=4)
        # Alternate levels maintain readability for nearby entered stations.
        label = str(support['id']) + ' | x=' + fmt(support['x'],0)
        box = draw.textbbox((0,0),label,font=small); tw=box[2]-box[0]
        draw.text((max(15,min(W-tw-15,px-tw/2)),155),label,font=small,fill=blue)
    groups = {}
    for load in loads:
        groups.setdefault(load['x'],[]).append(load['id'])
    for i,(x,ids) in enumerate(sorted(groups.items())):
        px=xpix(x)
        draw.ellipse((px-12,bottom-33,px+12,bottom-9),outline=red,width=4)
        draw.line((px,bottom+5,px,bottom+40),fill=red,width=3)
        draw.polygon(((px-6,bottom+30),(px+6,bottom+30),(px,bottom+42)),fill=red)
        label='/'.join(aliases.get(ident,ident) for ident in ids)+' | x='+fmt(x,0)
        box=draw.textbbox((0,0),label,font=small);tw=box[2]-box[0]
        draw.text((max(15,min(W-tw-15,px-tw/2)),bottom+48+(i%2)*30),label,font=small,fill=red)
    station_xs=sorted({s['x'] for s in supports})
    wheel_station_xs=sorted(groups)
    for xa,xb in zip(wheel_station_xs[:-1],wheel_station_xs[1:]):
        x1,x2=xpix(xa),xpix(xb);ypitch=bottom+118
        draw.line((x1,ypitch,x2,ypitch),fill=red,width=2)
        for xx in (x1,x2):draw.line((xx,ypitch-6,xx,ypitch+6),fill=red,width=2)
        label='Passo '+fmt(xb-xa,0)+' mm';box=draw.textbbox((0,0),label,font=small)
        draw.text(((x1+x2-(box[2]-box[0]))/2,ypitch+7),label,font=small,fill=red)
    ydim=bottom+165
    for xa,xb in zip(station_xs[:-1],station_xs[1:]):
        x1,x2=xpix(xa),xpix(xb)
        draw.line((x1,ydim,x2,ydim),fill=gray,width=2)
        for xx in (x1,x2):draw.line((xx,ydim-9,xx,ydim+9),fill=gray,width=2)
        label=fmt(xb-xa,0)+' mm';box=draw.textbbox((0,0),label,font=small)
        draw.text(((x1+x2-(box[2]-box[0]))/2,ydim+9),label,font=small,fill=blue)
    travel=('Curso físico do trem: '+fmt(project.travel_min_mm,0)+' a '+fmt(project.travel_max_mm,0)+' mm') if project.travel_min_mm is not None else 'Curso físico não informado; somente domínio computacional identificado no resultado.'
    draw.text((40,505),'Comprimento físico: '+fmt(project.length_mm,0)+' mm | '+travel,font=small,fill=blue)
    def graph(y0,label,values,color):
        plot_top, plot_bottom = y0+40,y0+182
        peakval=max(abs(v) for v in values)
        amp=peakval*1.15 if peakval>1e-14 else 1.
        base=(plot_top+plot_bottom)/2
        ypix=lambda v:base-v/amp*(plot_bottom-plot_top)/2
        draw.text((40,y0),label+' | mín '+fmt(min(values),4)+' / máx '+fmt(max(values),4),font=font,fill=color)
        draw.line((left,base,right,base),fill='#94a3b8',width=2)
        for support in supports:
            px=xpix(support['x']);draw.line((px,plot_top,px,plot_bottom),fill='#e2e8f0',width=1)
        coordinates=[(xpix(x),ypix(v)) for (x,_,_),v in zip(points,values)]
        draw.line(coordinates,fill=color,width=3)
        draw.text((left,plot_bottom+6),'0',font=small,fill=gray)
        text=fmt(project.length_mm,0)+' mm';box=draw.textbbox((0,0),text,font=small)
        draw.text((right-(box[2]-box[0]),plot_bottom+6),text,font=small,fill=gray)
    graph(565,'Momento My [kN.m]',[state['My']/1e6 for _,_,state in points],blue)
    graph(810,'Cortante Fz [kN]',[state['Fz']/1000 for _,_,state in points],'#9f1239')
    graph(1055,'Deslocamento w na linha '+aliases[wheel_id]+' [mm]',[state['w']+wheel.y_mm*state['phi'] for _,_,state in points],'#047857')
    draw.text((40,1305),'x →; z ↑; y entra no plano: eixos locais de mão direita. w < 0 é deslocamento para baixo.',font=small,fill=gray)
    draw.text((40,1335),'Convenção local do solver: My < 0 na flexão sagente deste plano; sinais não invertidos para apresentação.',font=small,fill=gray)
    draw.text((40,1365),'x em mm; dimensão vertical esquemática. Esta vista não verifica limite de serviço.',font=small,fill=gray)
    buf=BytesIO();im.save(buf,format='PNG')
    return dict(png=buf.getvalue(),case_id=case.id,translation_mm=a,translation_exact_mm=raw_exact,
                wheel_line=wheel_id,wheel_aliases=aliases,max_element_length_mm=mesh,project_signature=result['project_signature'],
                numerical_converged=row.get('numerical_converged',False),plot_is_envelope=False,
                active_wheel_station_pitch_mm=[b-a for a,b in zip(wheel_station_xs[:-1],wheel_station_xs[1:])],
                signed_response=[dict(x=x,side=side,My_Nmm=state['My'],Fz_N=state['Fz'],w_contact_mm=state['w']+wheel.y_mm*state['phi']) for x,side,state in points])
