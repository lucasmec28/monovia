"""Isolated underslung engineering candidates; not a released package."""
