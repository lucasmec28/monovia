"""Automatic signed SAME-POINT nominal underslung flange recovery, N/mm/MPa.

Axes are x longitudinal, y lateral, z up; twist is right-hand about +x.
This is an explicit beam/plate nominal model, never a complete contact/root tensor.
See README.md for the derivation, source domains, and unresolved 3-D effects.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
from functools import cached_property, lru_cache
from math import isfinite, isclose, sqrt, copysign
from hashlib import sha256
import json

MODEL = 'three_rectangle_elastic_section_and_Vlasov_thin_wall_nominal_recovery'
SOURCE = 'ABNT NBR 10084:2020 §9.1.4, Tabela 2 (mesas paralelas); EN 1993-6:2007+AC:2009 §5.8 Fig.5.6/Table5.2 (modelo nominal correspondente); SCI P385:2011 §§2.1–2.2,5.4,Appendix B'
NBR_LOCAL_COMBINATION = 'ABNT NBR 10084:2020 §9.1.4: sigma_cx = sigma_x + 0.75 sigma_0x; local sigma_y unreduced'


def _number(v, name, positive=False, nonnegative=False):
    if isinstance(v, bool) or not isinstance(v, (int, float)) or not isfinite(v):
        raise ValueError(name + ' must be finite real')
    if positive and v <= 0 or nonnegative and v < 0:
        raise ValueError(name + ' outside positive/nonnegative domain')
    return float(v)


@dataclass(frozen=True)
class ISection:
    d_mm: float
    bf_mm: float
    tf_mm: float
    tw_mm: float
    bottom_bf_mm: float | None = None
    bottom_tf_mm: float | None = None
    construction: str = 'welded'
    bottom_root_radius_mm: float = 0.0
    bottom_weld_throat_mm: float = 0.0

    def __post_init__(self):
        for k in ('d_mm','bf_mm','tf_mm','tw_mm'):
            _number(getattr(self,k),k,positive=True)
        for k in ('bottom_bf_mm','bottom_tf_mm'):
            if getattr(self,k) is not None: _number(getattr(self,k),k,positive=True)
        for k in ('bottom_root_radius_mm','bottom_weld_throat_mm'):
            _number(getattr(self,k),k,nonnegative=True)
        if self.d_mm <= self.tf_mm+self.bottom_thickness or min(self.bf_mm,self.bottom_width)<=self.tw_mm:
            raise ValueError('Invalid parallel I geometry')
        if self.construction not in ('rolled','welded'): raise ValueError('Choose rolled or welded')
        if self.construction=='rolled' and self.bottom_weld_throat_mm:
            raise ValueError('Rolled geometry cannot include welded throat')
        if self.construction=='welded' and self.bottom_root_radius_mm:
            raise ValueError('Welded geometry cannot include rolled root radius')
        if self.root_extent >= (self.bottom_width-self.tw_mm)/2:
            raise ValueError('Bottom root consumes the entire outstand')

    @property
    def bottom_width(self): return self.bf_mm if self.bottom_bf_mm is None else self.bottom_bf_mm
    @property
    def bottom_thickness(self): return self.tf_mm if self.bottom_tf_mm is None else self.bottom_tf_mm
    @property
    def root_extent(self):
        return self.bottom_root_radius_mm if self.construction=='rolled' else sqrt(2)*self.bottom_weld_throat_mm
    @property
    def doubly_symmetric(self):
        return isclose(self.bf_mm,self.bottom_width,rel_tol=1e-12) and isclose(self.tf_mm,self.bottom_thickness,rel_tol=1e-12)
    @cached_property
    def signature(self):
        return sha256(json.dumps(asdict(self),sort_keys=True,separators=(',',':')).encode()).hexdigest()


def geometric_properties(s: ISection):
    """Computed properties, never imported catalog/Robot stresses or constants.

    A/I are exact for three nonoverlapping rectangles; roots/weld metal omitted.
    J and omega/Cw are a declared open thin-wall approximation. The normalized
    sectorial coordinate is orthogonal to 1,y,z in this rectangle model.
    """
    if not isinstance(s,ISection): raise ValueError('ISection required')
    # Numeric dataclass equality equates int/float and signed zeros. Include the
    # exact serialized input signature so cached public identity stays identical.
    return dict(_geometric_properties_cached(s.signature,s))


@lru_cache(maxsize=256)
def _geometric_properties_cached(section_signature,s):
    d,bt,tt,tw,bb,tb=s.d_mm,s.bf_mm,s.tf_mm,s.tw_mm,s.bottom_width,s.bottom_thickness
    hw=d-tt-tb
    rects=((bb,tb,tb/2),(tw,hw,tb+hw/2),(bt,tt,d-tt/2))
    A=sum(b*t for b,t,z in rects)
    zc=sum(b*t*z for b,t,z in rects)/A
    Iy=sum(b*t**3/12+b*t*(z-zc)**2 for b,t,z in rects)
    Iz=sum(t*b**3/12 for b,t,z in rects)
    ib=tb*bb**3/12; it=tt*bt**3/12
    zb=tb/2-zc; zt=d-tt/2-zc
    zsc=(ib*zb+it*zt)/(ib+it)
    J=(bt*tt**3+bb*tb**3+hw*tw**3)/3
    Cw=it*ib/(it+ib)*(zt-zb)**2
    values=dict(A_mm2=A,Iy_mm4=Iy,Iz_mm4=Iz,J_mm4=J,Cw_mm6=Cw,
        centroid_from_bottom_mm=zc,z_sc_mm=zsc,bottom_z_mid_mm=zb,
        bottom_contact_z_mm=tb-zc,top_z_mid_mm=zt,web_height_mm=hw,
        bottom_flange_Iz_mm4=ib,top_flange_Iz_mm4=it)
    if not all(isfinite(v) for v in values.values()) or min(A,Iy,Iz,J,Cw)<=0:
        raise ValueError('Nonfinite or degenerate derived section properties')
    return tuple(dict(values,doubly_symmetric=s.doubly_symmetric,section_signature=s.signature,
                model=MODEL,root_and_weld_metal_in_stiffness=False,
                shear_center_reference='z from area centroid; thin-wall flange shear centre').items())


def section_properties(s: ISection, E_mpa: float, nu: float):
    E=_number(E_mpa,'E_mpa',positive=True); nu=_number(nu,'nu')
    if not -1<nu<.5: raise ValueError('Isotropic elastic Poisson ratio must be between -1 and 0.5')
    p=geometric_properties(s); G=E/(2*(1+nu))
    p.update(E_mpa=E,nu=nu,G_mpa=G,EA_N=E*p['A_mm2'],
             EIy_Nmm2=E*p['Iy_mm4'],EIz_Nmm2=E*p['Iz_mm4'],
             GJ_Nmm2=G*p['J_mm4'],ECw_Nmm4=E*p['Cw_mm6'])
    if not all(isfinite(p[k]) for k in ('G_mpa','EA_N','EIy_Nmm2','EIz_Nmm2','GJ_Nmm2','ECw_Nmm4')):
        raise ValueError('Nonfinite derived stiffness')
    p['frame_section']={k:p[v] for k,v in [('EA','EA_N'),('EIy','EIy_Nmm2'),('EIz','EIz_Nmm2'),('GJ','GJ_Nmm2'),('ECw','ECw_Nmm4')]}
    return p


@dataclass(frozen=True)
class MaterialPoint:
    id: str
    point: int
    outstand_side: str
    face: str
    y_mm: float
    z_mm: float
    omega_mm2: float
    section_signature: str


def bottom_contact(s: ISection, edge_to_contact_n_mm: float, outstand_side: str):
    n=_number(edge_to_contact_n_mm,'edge_to_contact_n_mm',positive=True)
    if outstand_side not in ('left','right'): raise ValueError('Physical outstand left/right required')
    a=s.bottom_width/2; y=a-n
    if y<=s.tw_mm/2+s.root_extent: raise ValueError('Contact centre must lie outside physical root/toe')
    p=geometric_properties(s); y*=(-1 if outstand_side=='left' else 1)
    return dict(y_mm=y,z_mm=p['bottom_contact_z_mm'],
                omega_mm2=-y*(p['bottom_z_mid_mm']-p['z_sc_mm']),
                outstand_side=outstand_side,section_signature=s.signature)


def bottom_flange_points(s: ISection, edge_to_contact_n_mm: float):
    """Fig5.6 nominal root tangent/toe, wheel centreline, free edge; 12 points.

    Point0 is nominal at the physical root-to-horizontal-flange transition, not
    a calculated fillet/weld hot spot. Root radius is NOT multiplied by ULS 0.8.
    """
    if not isinstance(s,ISection): raise ValueError('ISection required')
    n=_number(edge_to_contact_n_mm,'edge_to_contact_n_mm',positive=True)
    return _bottom_flange_points_cached(s.signature,s,n)


@lru_cache(maxsize=512)
def _bottom_flange_points_cached(section_signature,s,edge_to_contact_n_mm):
    p=geometric_properties(s); a=s.bottom_width/2
    contact=bottom_contact(s,edge_to_contact_n_mm,'right')
    ys=(s.tw_mm/2+s.root_extent,contact['y_mm'],a)
    out=[]
    for side,sign in (('left',-1),('right',1)):
        for i,y0 in enumerate(ys):
            y=sign*y0
            for face,z in (('bottom',-p['centroid_from_bottom_mm']),('top',p['bottom_contact_z_mm'])):
                out.append(MaterialPoint(f'bottom_flange/{side}/P{i}/{face}',i,side,face,y,z,
                    -y*(p['bottom_z_mid_mm']-p['z_sc_mm']),s.signature))
    return tuple(out)


@dataclass(frozen=True)
class Resultants:
    """Physical +x-face convention; every component required, including zero.

    My'=Fz, Mz'=-Fy, B'=Tw. Normal stress N/A+My*z/Iy-Mz*y/Iz+B*omega/Cw.
    Identity binds one x, one longitudinal cut side and one moving-load state.
    """
    N: float
    My: float
    Mz: float
    Fy: float
    Fz: float
    B: float
    Tsv: float
    Tw: float
    x: float
    side: str
    combination_id: str
    wheel_translation_mm: float
    section_signature: str
    torsion_recovery: str

    def __post_init__(self):
        for k in ('N','My','Mz','Fy','Fz','B','Tsv','Tw','x','wheel_translation_mm'):
            _number(getattr(self,k),k)
        if self.x<0 or self.side not in ('left','right'): raise ValueError('Physical section coordinate and cut side required')
        for k in ('combination_id','section_signature','torsion_recovery'):
            if not isinstance(getattr(self,k),str) or not getattr(self,k).strip(): raise ValueError(k+' required')


def resultants_from_frame(s, frame_state, *, combination_id, wheel_translation_mm, torsion_recovery):
    """No missing-component zero defaults and no raw/equilibrated field mixing."""
    if torsion_recovery not in ('raw','equilibrated'): raise ValueError('Explicit raw/equilibrated torsion recovery required')
    keys={k:k for k in ('N','My','Mz','Fy','Fz','Tsv','x','side')}
    keys.update(B='B' if torsion_recovery=='raw' else 'B_equilibrated',
                Tw='Tw' if torsion_recovery=='raw' else 'Tw_equilibrated')
    missing=[v for v in keys.values() if v not in frame_state]
    if missing: raise ValueError('Missing computed frame components: '+', '.join(missing))
    return Resultants(**{k:frame_state[v] for k,v in keys.items()},combination_id=combination_id,
        wheel_translation_mm=wheel_translation_mm,section_signature=s.signature,torsion_recovery=torsion_recovery)


def flange_shear_components(s: ISection, r: Resultants, y_mm: float, z_mm: float):
    """Signed nominal field on the clear BOTTOM outstand, including thickness.

    Vz field is pointwise compatible with finite-z longitudinal equilibrium:
    d(tau_xy)/dy+d(tau_xz)/dz = -Fz*z/Iy. Do not add the old overlapping
    magnitude idealizations. SV is the thin-strip nominal surface field only.
    At exact free edge use traction boundary tau_xy=0; no contact claim follows.
    """
    if not isinstance(r,Resultants) or r.section_signature!=s.signature:
        raise ValueError('Resultants must belong to this exact section')
    p=geometric_properties(s); y=_number(y_mm,'y');z=_number(z_mm,'z')
    a=s.bottom_width/2;t=s.bottom_thickness;zm=p['bottom_z_mid_mm'];eta=z-zm
    tol=1e-10*max(1,s.d_mm)
    if not s.tw_mm/2<=abs(y)<=a or abs(eta)>t/2+tol:
        raise ValueError('Point outside bottom-flange outstand')
    qshape=max(0.,a*a-y*y)/2
    lateral=r.Fy*qshape/p['Iz_mm4']
    vertical=r.Fz*zm*copysign(1,y)*(a-abs(y))/p['Iy_mm4']
    warp=-r.Tw*(zm-p['z_sc_mm'])*qshape/p['Cw_mm6']
    # Thin rectangular strip: tau_xy=-2G phi' eta. This is NOT a root peak.
    sv=-2*r.Tsv*eta/p['J_mm4']
    free_edge=abs(y)==a
    if free_edge: sv=0. # sigma_xy n_y = 0 on unloaded free lateral edge.
    transverse=r.Fz*max(0.,t*t/4-eta*eta)/(2*p['Iy_mm4'])
    return dict(tau_xy_lateral_mpa=lateral,tau_xy_vertical_mpa=vertical,
                tau_xy_warping_mpa=warp,tau_xy_saint_venant_nominal_mpa=sv,
                tau_xy_mpa=lateral+vertical+warp+sv,tau_xz_vertical_mpa=transverse,
                tau_xy_component_bound_mpa=abs(lateral)+abs(vertical)+abs(warp)+abs(sv),
                saint_venant_field='free_edge_traction_zero' if free_edge else 'thin_strip_nominal_not_root_or_edge_boundary_layer_solution')


def recover_bottom_flange(s: ISection, r: Resultants, edge_to_contact_n_mm: float):
    if not isinstance(r,Resultants) or r.section_signature!=s.signature:
        raise ValueError('Resultants must belong to this exact section')
    p=geometric_properties(s); rows=[]
    for pt in bottom_flange_points(s,edge_to_contact_n_mm):
        axial=r.N/p['A_mm2']; major=r.My*pt.z_mm/p['Iy_mm4'];minor=-r.Mz*pt.y_mm/p['Iz_mm4'];warp=r.B*pt.omega_mm2/p['Cw_mm6']
        shear=flange_shear_components(s,r,pt.y_mm,pt.z_mm)
        notes=[]
        if pt.point==0: notes.append('Root transition is a nominal section point; fillet/weld/local load-transfer concentration not resolved.')
        if pt.point==1 and pt.face=='top': notes.append('Wheel contact normal pressure and tangential tractions are not a plane-stress state; contact assessment remains separate.')
        if pt.point==2: notes.append('Exact free-edge xy traction is zero; finite tread/edge contact must be checked separately.')
        sx=axial+major+minor+warp
        row=dict(asdict(pt),global_sigma_x_mpa=sx,global_sigma_y_mpa=0.,
                 sigma_x_components_mpa=dict(axial=axial,major=major,minor=minor,warping=warp),
                 **shear,state_identity=dict(combination_id=r.combination_id,section_x_mm=r.x,
                 section_cut_side=r.side,wheel_translation_mm=r.wheel_translation_mm,section_signature=s.signature,
                 torsion_recovery=r.torsion_recovery),nominal_model=MODEL,
                 transverse_normal_zero_basis='1-D undistorted beam hypothesis only; local plate bending added separately',
                 actual_3d_tensor_complete=False,point_limitations=notes)
        if not all(isfinite(v) for v in (sx,*row['sigma_x_components_mpa'].values(),shear['tau_xy_mpa'],shear['tau_xy_component_bound_mpa'])):
            raise ValueError('Nonfinite recovered stress')
        rows.append(row)
    return rows


def recover_from_frame(s, solution, *, E_mpa, nu, x_mm, side, combination_id,
                       wheel_translation_mm, edge_to_contact_n_mm, torsion_recovery):
    """Direct automatic source binding; no external stress/resultant table needed."""
    props=section_properties(s,E_mpa,nu)
    if not s.doubly_symmetric:
        raise ValueError('Current frame reference axis is centroid=shear centre: unequal-I coupled frame remains unsupported')
    for k,v in props['frame_section'].items():
        if k not in solution.model.section or not isclose(solution.model.section[k],v,rel_tol=1e-10):
            raise ValueError('Frame/recovery stiffness mismatch: '+k)
    r=resultants_from_frame(s,solution.at(x_mm,side),combination_id=combination_id,
        wheel_translation_mm=wheel_translation_mm,torsion_recovery=torsion_recovery)
    return recover_bottom_flange(s,r,edge_to_contact_n_mm)


def combine_local(s, r, edge_to_contact_n_mm, *, individual_wheel_N, wheel_station_mm,
                  distance_to_nearest_end_mm, symmetric_opposite_wheels_confirmed,
                  nearest_longitudinal_spacing_mm=None, isolated_longitudinal_station_confirmed=False,
                  local_longitudinal_multiplier=1.0):
    """Same-state isolated prescribed-point normal stresses plus automatic global fields.

    Forces are already final individual wheel actions; this applies NO action factors
    or pair split. The explicit NBR combination multiplies local X by 0.75 only;
    the default unreduced mechanical/EN combination remains 1.0. Close-wheel superposition is deliberately not guessed here.
    Both physical outstands get one wheel stress, not the sum of opposed wheels.
    Returns nominal mechanical stresses/bounds, not NBR/EN resistance or PASS.
    """
    from ..local_flange.kernel import Geometry,Action,local_stresses
    factor=_number(local_longitudinal_multiplier,'local_longitudinal_multiplier')
    if factor not in (0.75,1.0):
        raise ValueError('Choose source NBR local-X combination 0.75 or unreduced mechanical/EN 1.0')
    station=_number(wheel_station_mm,'wheel_station_mm',nonnegative=True)
    if station != r.x:
        raise ValueError('Table5.2 stress and global resultants must be at the same physical wheel station')
    geometry=Geometry(s.bottom_width,s.tw_mm,s.bottom_thickness,edge_to_contact_n_mm,
                      s.construction,s.bottom_root_radius_mm,s.bottom_weld_throat_mm)
    action=Action(individual_wheel_N,'mechanical','mechanical',r.combination_id)
    local=local_stresses(geometry,action,distance_to_nearest_end_mm=distance_to_nearest_end_mm,
        symmetric_opposite_wheels_confirmed=symmetric_opposite_wheels_confirmed,
        nearest_longitudinal_spacing_mm=nearest_longitudinal_spacing_mm,
        isolated_longitudinal_station_confirmed=isolated_longitudinal_station_confirmed)
    rows=recover_bottom_flange(s,r,edge_to_contact_n_mm)
    for row in rows:
        sign=1 if row['face']=='bottom' else -1
        lx,ly=(sign*v for v in local[row['point']])
        sx=row['global_sigma_x_mpa']+factor*lx;sy=row['global_sigma_y_mpa']+ly;tau=row['tau_xy_mpa'];bound=row['tau_xy_component_bound_mpa']
        vm=sqrt(sx*sx+sy*sy-sx*sy+3*tau*tau)
        vmb=sqrt(sx*sx+sy*sy-sx*sy+3*bound*bound)
        row.update(local_sigma_x_mpa=lx,local_sigma_y_mpa=ly,sigma_x_mpa=sx,sigma_y_mpa=sy,
                   local_individual_wheel_N=individual_wheel_N,local_wheel_station_mm=station,
                   local_longitudinal_multiplier=factor,local_transverse_multiplier=1.0,
                   local_combination_source=NBR_LOCAL_COMBINATION if factor==0.75 else 'Unreduced mechanical/EN nominal local normal-stress superposition',
                   von_mises_nominal_mpa=vm,von_mises_component_bound_mpa=vmb,
                   source=SOURCE,local_mode='isolated_NBR10084_Table2_nominal' if factor==0.75 else 'isolated_EN_Table5.2_nominal',
                   local_shear_basis='EN §7.5(3) nominal superposition specifies local normal stresses plus global shear; not a complete local contact tensor',
                   status='MECHANICAL_NOMINAL_RESULT_NOT_DESIGN_APPROVAL')
    return rows
