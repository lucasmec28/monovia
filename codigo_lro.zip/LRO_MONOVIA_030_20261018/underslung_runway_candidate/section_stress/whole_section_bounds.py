"""Whole nominal I-section shear-vector envelope, N/mm/MPa.

This covers the web, BOTH flanges and a finite-width rectangular web/flange
transfer strip. It is not a bound on real rolled-root/contact concentrations.
Doubly symmetric parallel rolled I only, using exactly the same computed A/I,
J/Cw approximations as recovery.py. No catalog or external stress is imported.

Mechanical construction (b=bf, t=tf, w=tw, h=d-2t, c=(d-t)/2):
  Web: tau_xy=Fy(w²/4-y²)/(2Iz),
       tau_xz=Fz[bt*c+w(h²/8-z²/2)]/(Iy*w).
  Clear flange outstand: tau_xy,Fy=Fy(b²/4-y²)/(2Iz),
       tau_xy,Fz=Fz*zm*sign(y)*(b/2-|y|)/Iy,
       tau_xy,Tw=-Tw*zm*(b²/4-y²)/(2Cw),
       tau_xz,Fz=Fz[(t/2)²-(z-zm)²]/(2Iy), with zm=+/-c.

A finite nominal transfer strip |y|<=w/2 is INCLUDED, not mistaken for a free
flange face. Continue tau_xy,Fz linearly there as
  Fz*zm*(b-w)*y/(Iy*w).
For top flange z in [h/2,d/2], longitudinal equilibrium and its free outer face
then give
  tau_xz,Fz = Fz/Iy * [(d²/4-z²)/2 + c*(b-w)/w*(d/2-z)].
The bottom is reflected. At the web junction the magnitude is
  |Fz|*bt*c/(Iy*w), matching the web's junction value. All flange-thickness
positions are bounded by this value; it also exceeds the outstand parabola's
|Fz|t²/(8Iy). This nominal piecewise field balances the full rectangle normal
stress derivative, and integrating tau_xz across web+flanges returns Fz exactly.
It is an equilibrium-compatible nominal field, not a 3-D elasticity solution.

Warping: equal left/right flange junction flows pass through each other; their
net flux into the web is zero, because integral(omega*dA) over each full flange
is zero. With no closed shear-flow loop, the web's warping shear is zero in this
specific open-I model. This conclusion is NOT inferred from omega_web=0 alone.
The opposite flange forces cancel and their torque is Tw, since Cw=2*(t*b³/12)*c².

Saint-Venant: adopt the SCI thin-strip nominal wall magnitude |Tsv|*thickness/J.
Treat it as a vector of unspecified direction for this bound, so no favorable
component alignment or omitted perpendicular component is assumed. Add it to
the force+warping norm by the vector triangle inequality. Finite-width end and
re-entrant rolled-junction corrections are not resolved or invented. Thus this
is a whole NOMINAL model bound, never a universal bound on actual root peaks.

Sources: SCI P385 (2011), Design of steel beams in torsion, §§2.1–2.2 and
Appendix B.2.1–B.2.2: thin-strip shear, warping shear, open-section J and explicit
end/junction corrections for rolled sections. Force shear is independently
derived by longitudinal equilibrium/Jourawski and integrated rectangle moments.
The input absolute resultants must bound the SAME case and spatial/moving domain;
their peaks need not occur together. This box bound is not a signed fatigue state.
"""
from math import isfinite, hypot
from .recovery import ISection, geometric_properties

SOURCE='SCI P385 (2011), §§2.1–2.2, Appendix B.2.1–B.2.2; explicit whole-rectangle longitudinal-equilibrium and vector-triangle derivation'


def _magnitude(value,name):
    message=name+' must be a finite nonnegative same-case upper magnitude'
    if isinstance(value,bool) or not isinstance(value,(int,float)):raise ValueError(message)
    try:value=float(value)
    except (ValueError,OverflowError) as exc:raise ValueError(message) from exc
    if not isfinite(value) or value<0:raise ValueError(message)
    return value


def whole_section_shear_bound(section: ISection, *, abs_Fy_N, abs_Fz_N,
                              abs_Tsv_Nmm, abs_Tw_Nmm):
    """Nonconcurrent same-case absolute action bounds -> whole nominal |tau| bound.

    Returns plain serializable values. Both flange regions have the same upper
    bound; the larger of web/flange bounds covers every modeled material point.
    """
    if not isinstance(section,ISection):raise ValueError('Computed ISection geometry required')
    if not section.doubly_symmetric or section.construction!='rolled':
        raise ValueError('Whole-section bound currently qualified only for a doubly symmetric parallel rolled I nominal model')
    inputs={name:_magnitude(value,name) for name,value in
            (('abs_Fy_N',abs_Fy_N),('abs_Fz_N',abs_Fz_N),('abs_Tsv_Nmm',abs_Tsv_Nmm),('abs_Tw_Nmm',abs_Tw_Nmm))}
    Fy,Fz,Ts,Tw=(inputs[k] for k in ('abs_Fy_N','abs_Fz_N','abs_Tsv_Nmm','abs_Tw_Nmm'))
    p=geometric_properties(section);b=section.bf_mm;t=section.tf_mm;w=section.tw_mm
    h=section.d_mm-2*t;c=(section.d_mm-t)/2;Iy=p['Iy_mm4'];Iz=p['Iz_mm4'];J=p['J_mm4'];Cw=p['Cw_mm6']
    Qjunction=b*t*c;Qwebmax=Qjunction+w*h*h/8
    web=dict(tau_xy_Fy_bound_mpa=Fy*w*w/(8*Iz),tau_xz_Fz_bound_mpa=Fz*Qwebmax/(Iy*w),
             tau_warping_bound_mpa=0.,tau_saint_venant_vector_bound_mpa=Ts*w/J)
    web['force_warping_vector_bound_mpa']=hypot(web['tau_xy_Fy_bound_mpa'],web['tau_xz_Fz_bound_mpa'])
    web['vector_bound_mpa']=web['force_warping_vector_bound_mpa']+web['tau_saint_venant_vector_bound_mpa']
    flange=dict(tau_xy_Fy_bound_mpa=Fy*b*b/(8*Iz),tau_xy_Fz_bound_mpa=Fz*c*(b-w)/(2*Iy),
                tau_xy_Tw_bound_mpa=Tw*c*b*b/(8*Cw),
                tau_xz_Fz_transfer_strip_bound_mpa=Fz*Qjunction/(Iy*w),
                tau_xz_Fz_clear_outstand_bound_mpa=Fz*t*t/(8*Iy),
                tau_saint_venant_vector_bound_mpa=Ts*t/J)
    flange['tau_xy_force_warping_bound_mpa']=sum(flange[k] for k in ('tau_xy_Fy_bound_mpa','tau_xy_Fz_bound_mpa','tau_xy_Tw_bound_mpa'))
    flange['force_warping_vector_bound_mpa']=hypot(flange['tau_xy_force_warping_bound_mpa'],flange['tau_xz_Fz_transfer_strip_bound_mpa'])
    flange['vector_bound_mpa']=flange['force_warping_vector_bound_mpa']+flange['tau_saint_venant_vector_bound_mpa']
    if not all(isfinite(v) for region in (web,flange) for v in region.values()):raise ValueError('Whole-section shear bound overflow')
    bound=max(web['vector_bound_mpa'],flange['vector_bound_mpa'])
    return dict(tau_bound_mpa=bound,vector_norm_bound_mpa=bound,
        web_bound_mpa=web['vector_bound_mpa'],flange_bound_mpa=flange['vector_bound_mpa'],
        governing_nominal_region='web' if web['vector_bound_mpa']>=flange['vector_bound_mpa'] else 'both_flange_bounds',
        components=dict(web=web,top_flange=dict(flange),bottom_flange=dict(flange)),input_upper_magnitudes=inputs,
        properties=dict(Iy_mm4=Iy,Iz_mm4=Iz,J_mm4=J,Cw_mm6=Cw,Q_web_max_mm3=Qwebmax,Q_junction_mm3=Qjunction),
        section_signature=section.signature,complete_nominal_section_coverage=True,
        actual_3d_tensor_complete=False,actual_fillets_covered=False,contact_complete=False,design_approval=False,
        root_concentration_factor=None,thin_wall_ratios=dict(flange=t/b,web=w/h),
        same_case_requirement='All four supplied absolute upper magnitudes must cover the same case and chosen spatial/moving domain; independent peaks form a conservative nominal box.',
        source=SOURCE,
        assumptions=[
            'Straight parallel doubly symmetric rolled I, represented by three nominal rectangles; actual fillet metal and notch peaks are not included.',
            'Computed frame stiffness uses the same rectangular Iy/Iz and open thin-wall J/Cw; no catalog-property substitution.',
            'Nominal finite web-to-flange transfer strip is covered; no bottom-only, face-only or zero-shear substitution.',
            'Thin-wall Saint-Venant wall magnitude is a vector bound within the adopted nominal model, not a resolved root/edge boundary-layer solution.',
            'Warping web shear is zero only after balancing both opposed flange branch flows in this open-I model.',
            'No force/action factor, material resistance, instability factor or fatigue-history qualification is supplied.'])
