"""Portuguese evidence exports for the separate nominal NBR fatigue route.

Editorial only: no action factors, resistance equations or approval are changed.
The signed calculation is checked before and after every export. JSON contains
all evidence; Word deliberately summarizes the same nominal scope.
"""
from __future__ import annotations
from hashlib import sha256
from io import BytesIO
from pathlib import Path
import json
import math

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from monorail.analysis import digest
from matplotlib.patches import Circle, Polygon, Rectangle

EVIDENCE_FORMAT = 'LRO_MONORAIL_NBR_FATIGUE_EVIDENCE'
STATUS = {'PASS': 'Limite suficiente satisfeito', 'BOUND_EXCEEDED': 'Majorante excedido',
          'PENDING': 'Pendente', 'NOT_CALCULATED': 'Não calculado',
          'OUT_OF_SCOPE': 'Fora do escopo', 'OUT_OF_DOMAIN': 'Fora do domínio'}
REGIONS = {'ordinary_global_top_flange': 'Mesa superior global',
           'ordinary_global_bottom_flange': 'Mesa inferior global',
           'ordinary_global_web': 'Alma global',
           'ordinary_lower_flange_source_prescribed_detail': 'Mesa inferior local',
           'lower_local_domain': 'Domínio local inferior',
           'complete_declared_action_domain': 'Domínio completo das ações declaradas'}
CLASSIFICATION = {'manual_code_selection': 'Seleção manual de grupo',
                  'documented_component_classification': 'Classificação documentada do componente',
                  'adopted_conservative_E8': 'Adoção conservadora explícita de E8'}
FABRICATION = {'specified_h6': 'Requisito h6 especificado',
               'specified_h6_qc': 'Requisito h6 e controle de qualidade especificados',
               'não informado': 'Não informado'}
DETAIL = {'W0_plain_rolled_unnotched': 'W0 material-base laminado sem entalhes',
          'não selecionado': 'Não selecionado'}
BLUE, ORANGE = '#24556b', '#b46a18'


def number(value, digits=4):
    if value is None:
        return 'n/d'
    if type(value) not in (int, float) or not math.isfinite(value):
        raise ValueError('Número de relatório deve ser finito')
    return ('0' if value == 0 else format(value, '.'+str(digits)+'g')).replace('.', ',')


def status_label(value):
    return STATUS.get(value, 'Situação não reconhecida ('+str(value)+')')


def region_label(value):
    return REGIONS.get(value, 'Região nominal ('+str(value or 'não identificada')+')')


def point_label(value):
    text = str(value or 'Não identificado')
    for key, label in (('top_flange_uniform_nominal_wall_face_bound', 'Mesa superior'),
                       ('bottom_flange_uniform_nominal_wall_face_bound', 'Mesa inferior'),
                       ('web_uniform_nominal_wall_face_bound', 'Alma')):
        if text == key:
            return label
    if text.startswith('bottom_flange/'):
        parts = text.split('/')
        return parts[2]+' '+{'left': 'esq.', 'right': 'dir.'}.get(parts[1], parts[1])
    return text.replace('left', 'esq.').replace('right', 'dir.')


def face_label(value):
    return {'both_nominal_wall_faces': 'Ambas as faces nominais', 'top': 'Superior',
            'bottom': 'Inferior', 'upper': 'Superior', 'lower': 'Inferior'}.get(value, str(value or 'n/d'))


def reason_pt(reason):
    """Translate the preserved consumer's reasons without altering its result."""
    text = str(reason)
    known = (
        ('Annex D.5 is planar; nonzero out-of-plane nominal terms remain:',
         'A Equação D.5 é planar; a alma conserva componentes nominais não nulas fora do plano:'),
        ('NBR10084 isolated-station spacing >= 1.5 flange widths required; close-wheel source applicability remains pending',
         'A NBR 10084 exige espaçamento entre eixos isolados de pelo menos 1,5 vezes a largura da mesa; a aplicabilidade para rodas próximas permanece pendente.'),
        ('Initial canonical recovery domain is rolled parallel I',
         'A recuperação canônica atual exige perfil I laminado de mesas paralelas.'),
        ('Actual end fork premise must be explicitly adopted',
         'A hipótese física de garfos extremos deve ser adotada explicitamente.'),
        ('Doubly symmetric plain rolled section required',
         'É exigida seção laminada sem entalhes, duplamente simétrica.'),
        ('Source local model requires equal opposed physical wheels; no inferred averaging',
         'O modelo local exige rodas físicas opostas iguais; não se presume média de reações desiguais.'),
        ('Nonnegative compression-only contact domain not established',
         'Não foi estabelecido o domínio de contato somente à compressão não negativa.'),
        ('Unresolved nominal tensor component', 'Componente do tensor nominal não resolvida'),
        (' is not a zero', ' não equivale a zero'),
        ('Table D.1/5.6.5 material domain requires S235/S275/A36/S355/A572 GR50 and 370 <= fu <= 520 MPa; no inferred equivalence',
         'O material deve pertencer ao domínio da Tabela D.1 e de 5.6.5: S235, S275, A36, S355 ou A572 GR50, com 370 ≤ fu ≤ 520 MPa. Não se presume equivalência.'),
        ('Explicit sourced COMPONENT group E1–E8 required; no E8 default or CMAA/equipment/mechanism mapping',
         'Falta grupo E1 a E8 do componente com fonte explícita. Não há E8 automático nem conversão de classe CMAA ou de grupo do equipamento.'),
        ('Identify a manual component-group selection, documented component classification or explicitly adopted conservative E8',
         'Identifique a seleção manual, a classificação documentada do componente ou a adoção conservadora explícita de E8.'),
        ('Only W0 plain rolled unnotched base material is qualified here; weld metal, notches, holes and rolling-contact zones need their own detail',
         'Somente o detalhe W0 de material-base laminado sem entalhes pertence a esta rota. Soldas, entalhes, furos e contato rolante exigem detalhe próprio.'),
        ('Explicit applicable fabrication/inspection requirement required; this is not an as-built inspection',
         'Falta requisito explícito de fabricação e inspeção aplicável. Uma especificação não comprova inspeção realizada.'),
        ('Explicit conservative kappa=-1 resistance adoption required; exact positive-kappa Eq. D.3 is unresolved',
         'Falta adoção conservadora explícita de κ = −1. O ramo exato de κ positivo da Equação D.3 não está implementado.'),
        ('Lower-flange nominal fatigue domain unresolved:', 'Domínio nominal local da mesa inferior não resolvido:'),
        ('NBR10084 nominal interior local model requires physical end distance > flange width',
         'O modelo local interior da NBR 10084 exige distância física à extremidade maior que a largura da mesa.'),
        ('numerical translation refinement is not converged', 'o refinamento numérico da translação não convergiu'),
        ('numerical tolerance exceeds the declared engineering acceptance', 'a tolerância numérica excede a aceitação de engenharia declarada'),
        ('at least two stable nested passes required', 'são necessários pelo menos dois passes aninhados estáveis'),
        ('Hx requires explicit equal opposed contacts and axial restraint at shear centre; transport is not omitted',
         'Hs exige adoção explícita de contatos opostos iguais e vínculo axial no centro de cisalhamento; o transporte da força não é omitido.'),
        ('High fy/fu reference-material route requires explicit project adoption',
         'O ramo de material com fy/fu alto exige adoção explícita no projeto.'),
        ('Case I fatigue actions without Mx/omega required; EN/CMAA/ULS actions are not relabeled',
         'São exigidas ações de fadiga do caso I, sem o coeficiente de grupo Mₓ e sem ω. Não se renomeiam ações EN, CMAA ou ELU.'),
        ('Explicit member xy flange or xz web material plane required',
         'Informe plano material nominal xy para mesa ou xz para alma.'),
        ('Conservative unclassified group adoption is limited to explicitly selected E8; it does not represent manual selection of a different group',
         'A adoção conservadora de grupo não classificado limita-se ao E8 explícito; não equivale à seleção manual de outro grupo.'),
    )
    for source, target in known:
        text = text.replace(source, target)
    return text.replace('txy', 'τxy').replace('txz', 'τxz').replace('tyz', 'τyz')


def _guard_start(bundle, result):
    from nbr_fatigue_analysis import assert_current_nbr_fatigue_result
    assert_current_nbr_fatigue_result(bundle, result)
    return bundle.signature(), digest(result), sha256(Path(__file__).read_bytes()).hexdigest()


def _guard_end(bundle, result, guard):
    if _guard_start(bundle, result) != guard:
        raise ValueError('Entradas, resultado ou relatório NBR alterados durante a exportação; exporte novamente.')


def export_nbr_fatigue_json(bundle, result):
    """Evidence only, deliberately rejected by the input-project importer."""
    guard = _guard_start(bundle, result)
    payload = dict(format=EVIDENCE_FORMAT, schema_version=1,
        purpose='Evidência de fadiga nominal NBR delimitada; não importar como entrada de projeto.',
        whole_design_approved=False, report_source_sha256=guard[2],
        input_snapshot=bundle.to_dict(), calculation=result)
    payload['evidence_signature'] = digest(payload)
    raw = json.dumps(payload, ensure_ascii=False, indent=2, allow_nan=False).encode('utf-8')
    _guard_end(bundle, result, guard)
    return raw


def schematic_nbr_fatigue(bundle, format='png'):
    """Physical NBR inputs with editorial offsets independent of bf/d and tf.

    Section dimensions are never clamped for display. Thin walls may appear as
    lines at print scale; the numerical dimensions remain explicitly displayed.
    """
    if format not in ('png', 'svg'):
        raise ValueError('Figuras NBR aceitam somente png ou svg.')
    bundle.validate()
    p, sec = bundle.project, bundle.project.section
    fig, (ax, cs) = plt.subplots(1, 2, figsize=(11, 4.5),
        gridspec_kw={'width_ratios': [1.65, 1.]}, layout='constrained')
    L = p.span_m
    a = (p.travel_min_m+p.travel_max_m)/2
    ax.add_patch(Rectangle((0, 0), L, .32, fc='#eff4f6', ec=BLUE, lw=.8))
    ax.plot([0, L], [0, 0], color=BLUE, lw=4, solid_capstyle='butt')
    ax.plot([0, L], [.32, .32], color=BLUE, lw=3, solid_capstyle='butt')
    sx = L*.016
    for x in (0, L):
        ax.add_patch(Polygon([[x, 0], [x-sx, -.18], [x+sx, -.18]], fc='#d3e1e7', ec=BLUE))
    for station in p.stations:
        x = a+station.offset_m
        ax.add_patch(Circle((x, .055), .055, fc=ORANGE, ec='black', lw=.7))
        ax.plot([x, x], [0, -.30], color=ORANGE, lw=1.4)
        ax.text(x, .44, station.id, ha='center', fontsize=8)
    left, right = a+p.stations[0].offset_m, a+p.stations[-1].offset_m
    hook = (left+right)/2
    ax.plot([left, right], [-.30, -.30], color=ORANGE, lw=1.8)
    hw = L*.05
    ax.add_patch(Rectangle((hook-hw/2, -.62), hw, .27, fc='#f2e1ca', ec=ORANGE, lw=1.1))
    ax.plot([hook, hook], [-.30, -.35], color=ORANGE, lw=1.4)
    ax.plot([hook, hook, hook+hw*.22, hook+hw*.32], [-.62, -.84, -.89, -.82], color=ORANGE, lw=1.4)
    ax.text(hook+hw*.7, -.47, 'Talha suspensa', fontsize=8, va='center')
    ax.annotate('', xy=(0, -1.12), xytext=(L, -1.12), arrowprops=dict(arrowstyle='<->', lw=.8))
    ax.text(L/2, -1.10, 'L = '+number(L)+' m', ha='center', va='bottom', fontsize=9)
    ax.annotate('', xy=(p.travel_min_m, .77), xytext=(p.travel_max_m, .77),
                arrowprops=dict(arrowstyle='<->', color=BLUE))
    ax.text((p.travel_min_m+p.travel_max_m)/2, .83,
            'a = '+number(p.travel_min_m)+' a '+number(p.travel_max_m)+' m', ha='center', fontsize=9)
    ax.text(0, -1.38, 'Carga útil nominal / operacional: '+number(p.capacity_t)+' / '+number(p.operating_payload_t)+' t\n'
            'Talha/trole: '+number(p.trolley_hoist_mass_kg)+' kg; massa retida: '+number(p.retained_suspended_mass_kg)+' kg\n'
            'Dois contatos opostos por eixo; offsets: '+', '.join(st.id+' = '+number(st.offset_m)+' m' for st in p.stations),
            fontsize=8, va='top', linespacing=1.35)
    ax.text(L, -.34, 's →', fontsize=10, ha='right')
    ax.set_title('Elevação esquemática  |  a = '+number(a)+' m', loc='left', fontsize=11)
    ax.set_xlim(-L*.06, L*1.06)
    ax.set_ylim(-2.02, 1.12)
    ax.axis('off')

    d, b, tf, tw = sec.d_mm, sec.bf_mm, sec.tf_mm, sec.tw_mm
    D = max(b, d)
    zbot, ztop = -d/2, d/2
    for rect in ((-b/2, zbot, b, tf), (-tw/2, zbot+tf, tw, d-2*tf), (-b/2, ztop-tf, b, tf)):
        cs.add_patch(Rectangle(rect[:2], rect[2], rect[3], fc='#d3e1e7', ec=BLUE, lw=1.0))
    contact, zcontact = b/2-p.edge_to_contact_mm, zbot+tf
    root = sec.root_radius_mm if sec.fabrication == 'rolled' else math.sqrt(2)*p.weld_throat_mm
    clearance = contact-(tw/2+root)
    radius = min(D*.03, p.edge_to_contact_mm*.35, clearance*.35)
    for sign in (-1, 1):
        y = sign*contact
        cs.add_patch(Circle((y, zcontact+radius), radius, fc=ORANGE, ec='black', lw=.7))
        cs.plot(y, zcontact, 'o', color='black', ms=2)
        cs.annotate('', xy=(y, zcontact), xytext=(y, zcontact+2*radius+D*.10),
                    arrowprops=dict(arrowstyle='->', color=ORANGE))
    # Dimension text and notes are spaced by the largest physical dimension,
    # rather than by a fixed number of millimetres or the flange thickness.
    cs.annotate('', xy=(-b/2, ztop+D*.12), xytext=(b/2, ztop+D*.12), arrowprops=dict(arrowstyle='<->', lw=.7))
    cs.text(0, ztop+D*.17, 'bf = '+number(b)+' mm', ha='center', fontsize=8)
    cs.annotate('', xy=(-b/2-D*.12, zbot), xytext=(-b/2-D*.12, ztop), arrowprops=dict(arrowstyle='<->', lw=.7))
    cs.text(-b/2-D*.16, 0, 'd = '+number(d)+' mm', rotation=90, ha='right', va='center', fontsize=8)
    cs.text(b/2+D*.05, ztop-D*.05, 'tf = '+number(tf)+'\ntw = '+number(tw)+'\nmm', fontsize=8, va='top')
    cs.annotate('', xy=(contact, zbot-D*.10), xytext=(b/2, zbot-D*.10), arrowprops=dict(arrowstyle='<->', lw=.7, mutation_scale=5, shrinkA=0, shrinkB=0))
    cs.text(b/2+D*.04, zbot-D*.10, 'n = '+number(p.edge_to_contact_mm)+' mm', fontsize=8, va='center')
    cs.annotate('', xy=(tw/2, zbot-D*.23), xytext=(contact, zbot-D*.23), arrowprops=dict(arrowstyle='<->', lw=.7))
    cs.text((contact+tw/2)/2, zbot-D*.29, 'à face da alma = '+number(contact-tw/2)+' mm', ha='center', fontsize=8)
    cs.annotate('', xy=(b/2+D*.10, 0), xytext=(0, 0), arrowprops=dict(arrowstyle='->', lw=.8))
    cs.text(b/2+D*.12, 0, 'y', fontsize=9, va='center')
    cs.annotate('', xy=(0, d*.23), xytext=(0, 0), arrowprops=dict(arrowstyle='->', lw=.8))
    cs.text(D*.025, d*.23, 'z', fontsize=9)
    cs.text(0, zbot-D*.43, 'Rodas simbólicas; contato na face superior da mesa inferior.\n'
            's sai do plano; espessuras físicas sem ampliação.', ha='center', fontsize=7.4, linespacing=1.35)
    cs.set_title('Seção e contatos físicos', loc='left', fontsize=11)
    cs.set_aspect('equal')
    cs.set_xlim(-b/2-D*.27, b/2+D*.35)
    cs.set_ylim(zbot-D*.53, ztop+D*.30)
    cs.axis('off')
    stream = BytesIO()
    with matplotlib.rc_context({'svg.fonttype': 'none', 'svg.hashsalt': 'LRO-NBR-fatigue-schematic-v2'}):
        fig.savefig(stream, format=format, dpi=180, bbox_inches='tight', facecolor='white',
                    metadata={'Date': None, 'Creator': 'LRO Monovia NBR'} if format == 'svg'
                    else {'Software': 'LRO Monovia NBR'})
    plt.close(fig)
    return stream.getvalue()


def diagram_figure(data, format='png'):
    """NBR physical s/y/z right-hand plots; no EN factor or resistance import."""
    if format not in ('png', 'svg'):
        raise ValueError('Figuras NBR aceitam somente png ou svg.')
    keys = ('N_kN', 'My_kNm', 'Mz_kNm', 'Vy_kN', 'Vz_kN', 'T_kNm', 'Tsv_kNm', 'Tw_kNm', 'B_kNm2')
    if not isinstance(data, dict) or not data.get('rows') or data.get('family') != 'FAT8400':
        raise ValueError('Diagrama físico genuíno FAT8400 com linhas não vazias obrigatório.')
    for row in data['rows']:
        for key in ('s_m',)+keys:
            if type(row.get(key)) not in (int, float) or not math.isfinite(row[key]):
                raise ValueError('Componente física ausente ou não finita: '+key)
    rows = data['rows']
    fig, axes = plt.subplots(4, 2, figsize=(10, 8.5), layout='constrained')
    specs = [('My_kNm', 'My forte (kN m)'), ('Mz_kNm', 'Mz fraco (kN m)'),
             ('Vz_kN', 'Vz vertical (kN)'), ('Vy_kN', 'Vy lateral (kN)'),
             ('N_kN', 'N axial (kN), tração positiva'), ('T_kNm', 'T total (kN m)'),
             ('B_kNm2', 'B bimomento (kN m²)'), ('Tsv_kNm', 'Parcelas de torção (kN m)')]
    for ax, (key, title) in zip(axes.flat, specs):
        ax.plot([r['s_m'] for r in rows], [r[key] for r in rows], color=BLUE, lw=1.4,
                label='Saint-Venant' if key == 'Tsv_kNm' else None)
        ax.set_title(title, loc='left', fontsize=9.5)
        ax.set_xlabel('s (m)', fontsize=9)
        ax.grid(alpha=.2)
        ax.axhline(0, color='#888888', lw=.6)
        ax.tick_params(labelsize=8)
        ax.ticklabel_format(axis='y', style='sci', scilimits=(-3, 4), useOffset=False)
        ax.yaxis.get_offset_text().set_fontsize(8)
    ax = axes.flat[-1]
    ax.plot([r['s_m'] for r in rows], [r['Tw_kNm'] for r in rows], color=ORANGE, lw=1.4, label='Empenamento')
    ax.legend(fontsize=8)
    fig.suptitle('Estado concomitante  |  Fadiga NBR 8400  |  a = '+number(data['translation_m'], 5)+' m\n'
                 'Eixos físicos s, y, z; z para cima; mão direita em +s', fontsize=11)
    stream = BytesIO()
    with matplotlib.rc_context({'svg.fonttype': 'none', 'svg.hashsalt': 'LRO-NBR-fatigue-diagram-v1'}):
        fig.savefig(stream, format=format, dpi=180, bbox_inches='tight', facecolor='white',
                    metadata={'Date': None, 'Creator': 'LRO Monovia NBR'} if format == 'svg'
                    else {'Software': 'LRO Monovia NBR'})
    plt.close(fig)
    return stream.getvalue()


def _table(doc, headers, rows, widths, size=8.5):
    table = doc.add_table(rows=1, cols=len(headers))
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = False
    for i, width in enumerate(widths):
        table.columns[i].width = Inches(width)
    for cell, value in zip(table.rows[0].cells, headers):
        cell.text = str(value)
    for values in rows:
        for cell, value in zip(table.add_row().cells, values):
            cell.text = str(value)
    for ri, row in enumerate(table.rows):
        props = row._tr.get_or_add_trPr()
        props.append(OxmlElement('w:cantSplit'))
        if ri == 0:
            props.append(OxmlElement('w:tblHeader'))
        for ci, cell in enumerate(row.cells):
            cell.width = Inches(widths[ci])
            cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
            tc = cell._tc.get_or_add_tcPr()
            borders = OxmlElement('w:tcBorders')
            for edge in ('top', 'left', 'bottom', 'right'):
                el = OxmlElement('w:'+edge)
                for k, v in (('val', 'single'), ('sz', '4'), ('color', 'D9D9D9')):
                    el.set(qn('w:'+k), v)
                borders.append(el)
            tc.append(borders)
            shade = OxmlElement('w:shd')
            shade.set(qn('w:fill'), '1F4D60' if ri == 0 else 'F2F5F7' if ri % 2 == 0 else 'FFFFFF')
            tc.append(shade)
            margins = OxmlElement('w:tcMar')
            for edge in ('top', 'left', 'bottom', 'right'):
                el = OxmlElement('w:'+edge)
                el.set(qn('w:w'), '65')
                el.set(qn('w:type'), 'dxa')
                margins.append(el)
            tc.append(margins)
            for para in cell.paragraphs:
                para.paragraph_format.space_after = Pt(1.3)
                para.paragraph_format.space_before = Pt(1.3)
                para.paragraph_format.line_spacing = 1.02
                if ci > 0 and len(cell.text) < 22:
                    para.alignment = WD_ALIGN_PARAGRAPH.CENTER
                for run in para.runs:
                    run.font.size = Pt(size)
                    if ri == 0:
                        run.font.bold = True
                        run.font.color.rgb = RGBColor(255, 255, 255)
    gap = doc.add_paragraph()
    gap.paragraph_format.space_before = gap.paragraph_format.space_after = Pt(0)
    gap.paragraph_format.line_spacing = Pt(3)
    gap.add_run().font.size = Pt(1)
    return table


def _document():
    doc = Document()
    sec = doc.sections[0]
    sec.page_width, sec.page_height = Inches(8.5), Inches(11)
    sec.top_margin = sec.bottom_margin = Inches(.65)
    sec.left_margin = sec.right_margin = Inches(.7)
    for name in ('Normal', 'Title', 'Subtitle', 'Heading 1', 'Heading 2'):
        style = doc.styles[name]
        style.font.name = 'Arial'
        style.font.color.rgb = RGBColor(0, 0, 0)
        ppr = style.element.find(qn('w:pPr'))
        if ppr is not None:
            for border in list(ppr.findall(qn('w:pBdr'))):
                ppr.remove(border)
    doc.styles['Normal'].font.size = Pt(10)
    doc.styles['Normal'].paragraph_format.space_after = Pt(5)
    doc.styles['Normal'].paragraph_format.line_spacing = 1.05
    doc.styles['Title'].font.size = Pt(21)
    doc.styles['Heading 1'].font.size = Pt(13)
    doc.styles['Heading 2'].font.size = Pt(11)
    for name in ('Heading 1', 'Heading 2'):
        doc.styles[name].paragraph_format.space_before = Pt(10)
        doc.styles[name].paragraph_format.space_after = Pt(5)
    footer = sec.footer.paragraphs[0]
    footer.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    footer.add_run('Fadiga nominal NBR  |  ')
    fld = OxmlElement('w:fldSimple')
    fld.set(qn('w:instr'), 'PAGE')
    footer._p.append(fld)
    for run in footer.runs:
        run.font.size = Pt(8)
    return doc


def _conclusion(summary):
    counts = summary['counts']
    if not summary.get('calculated_cases'):
        lead = 'Nenhuma resposta mecânica foi calculada; não há conclusão nominal de fadiga.'
    elif counts.get('BOUND_EXCEEDED', 0):
        lead = 'Há majorante conservador excedido; é necessária análise adicional, sem demonstração automática de falha física.'
    elif counts.get('PASS', 0):
        lead = 'Os limites suficientes efetivamente concluídos foram satisfeitos nos pontos e planos nominais indicados.'
    else:
        lead = 'A avaliação nominal de fadiga permanece pendente.'
    pending = sum(counts.get(k, 0) for k in ('PENDING', 'NOT_CALCULATED', 'OUT_OF_SCOPE', 'OUT_OF_DOMAIN'))
    if pending:
        lead += ' Há '+str(pending)+' registro(s) pendente(s), não calculado(s) ou fora do domínio.'
    return lead+' Este relatório não aprova integralmente a monovia.'


def _report_reasons(checks, cases):
    grouped = {}
    for check in checks:
        if check['status'] == 'PASS':
            continue
        reasons = check.get('reasons') or ([] if check['status'] != 'BOUND_EXCEEDED' else [
            'O majorante da caixa de intervalos excedeu o limite suficiente. A caixa não é um estado físico concomitante.'])
        for reason in reasons:
            grouped.setdefault(reason_pt(reason), set()).add(region_label(check.get('region')))
    for case in cases:
        if case.get('error'):
            grouped.setdefault(reason_pt(case['error']), set()).add(case.get('title') or case['id'])
    return grouped


def export_nbr_fatigue_word(bundle, result):
    """Concise engineering record, including pending and exceeded-bound results."""
    guard = _guard_start(bundle, result)
    p, s, m = bundle.project, bundle.project.section, bundle.project.material
    summary, cases, checks = result['summary'], result['cases'], result['checks']
    nominal = result.get('nominal') or {}
    doc = _document()
    sources = {}
    def source(text):
        if not text or not str(text).strip():
            return 'Não informada'
        text = str(text).strip()
        if text not in sources:
            sources[text] = 'F'+str(len(sources)+1).zfill(2)
        return sources[text]
    def para(text, style=None):
        return doc.add_paragraph(str(text), style)
    doc.core_properties.title = 'Fadiga nominal NBR de monovia reta'
    doc.core_properties.author = p.responsible or 'LRO Monovia'
    para('Fadiga nominal NBR de monovia reta', 'Title')
    title = p.project_name
    prefix = 'Exemplo sintético de fadiga nominal NBR · '
    modes = {'horizontal': 'ações horizontais', 'combined': 'ações combinadas',
             'bound_exceeded': 'majorante excedido', 'missing_axial': 'vínculo axial ausente',
             'missing_data': 'dados incompletos', 'vertical': 'ações verticais'}
    if title.startswith(prefix) and title[len(prefix):] in modes:
        title = prefix+modes[title[len(prefix):]]
    para(title+' | '+p.member_name, 'Subtitle')
    if bundle.demonstration:
        para('EXEMPLO SINTÉTICO. As entradas não representam equipamento real, catálogo ou certificado. Substituir e verificar as fontes antes do uso em projeto.')
    para(_conclusion(summary))
    para('Responsável informado: '+(p.responsible or 'não informado')+'. Cálculo UTC: '+str(result['created_utc'])[:19]+'. Revisão '+str(result['version'])+'.')
    para('Domínio e alcance', 'Heading 1')
    para('Domínio admitido: viga I reta, prismática, duplamente simétrica, laminada e de mesas paralelas; um vão, garfos extremos e empenamento livre. Ações genuínas FAT8400 do caso I, sem o coeficiente de majoração de grupo Mₓ e sem o coeficiente de flambagem ω. Mₓ de grupo não é momento fletor.')
    para('A rota contempla três regiões globais nominais e, quando o domínio local é válido, doze faces P0/P1/P2 em dois lados. Quinze registros parciais não demonstram cobertura física completa da seção. Contato rolante, desgaste, raízes reais, soldas, furos, entalhes, ligações, estabilidade, segunda ordem e cobertura integral das ações do equipamento permanecem fora desta conclusão. Não se calcula vida ilimitada nem ciclos até ruptura.')
    fig = para('')
    fig.paragraph_format.keep_with_next = True
    fig.add_run().add_picture(BytesIO(schematic_nbr_fatigue(bundle)), width=Inches(7.05))
    caption = para('Esquema das entradas físicas. Rodas simbólicas; o desenho não dimensiona contato ou ligação.')
    for run in caption.runs:
        run.font.size = Pt(8.5)

    para('Entradas físicas e fontes', 'Heading 1')
    rows = [
        ('Vão e percurso', 'L = '+number(p.span_m)+' m; a = '+number(p.travel_min_m)+' a '+number(p.travel_max_m)+' m', source(p.travel_source)),
        ('Seção '+s.name, 'd / bf / tw / tf / r = '+ ' / '.join(number(x) for x in (s.d_mm, s.bf_mm, s.tw_mm, s.tf_mm, s.root_radius_mm))+' mm', source(s.property_source)),
        ('Material físico', 'fy / fu = '+number(m.fy_mpa)+' / '+number(m.fu_mpa)+' MPa; E / G = '+number(m.E_mpa)+' / '+number(m.G_mpa)+' MPa', source(m.specification)),
        ('Carga útil', 'Nominal / operacional = '+number(p.capacity_t)+' / '+number(p.operating_payload_t)+' t', source(p.equipment_source)),
        ('Massas móveis', 'Talha e trole = '+number(p.trolley_hoist_mass_kg)+' kg; suspensa retida = '+number(p.retained_suspended_mass_kg)+' kg', source(p.equipment_source)),
        ('Contato e repartição', 'Borda ao contato n = '+number(p.edge_to_contact_mm)+' mm; pares opostos iguais', source(p.wheel_distribution_source)),
        ('Ações horizontais', 'Hs longitudinal e Hy transversal por eixo, com sinais dos casos gerados', source(p.horizontal_action_source)),
        ('Vínculos', 'Garfos extremos; empenamento livre; contenções nominais não criam apoios físicos', source(p.restraint_source)),
        ('Peso adicional', number(p.extra_dead_kn_per_m)+' kN/m', source(p.extra_dead_source)),
        ('Dinâmica', 'HC / HD = '+p.hoist_class+' / '+p.drive_class+'; velocidade = '+number(p.hoist_speed_m_s)+' m/s; ψ = '+number(p.dynamics()['psi']), source(p.classification_source+' '+p.dynamic_source)),
    ]
    if p.section_mass_kg_per_m is not None:
        rows.append(('Massa linear informada', number(p.section_mass_kg_per_m)+' kg/m', source(p.section_mass_source)))
    else:
        rows.append(('Massa linear', 'Calculada pela geometria física, incluindo concordâncias; rigidez por três retângulos', source(s.property_source)))
    _table(doc, ['Entrada', 'Valor ou hipótese', 'Fonte'], rows, [1.6, 4.8, .7])
    _table(doc, ['Eixo', 'Posição relativa m', 'Fração talha', 'Fração suspensa', 'Hs kN', 'Hy kN'],
           [(st.id, number(st.offset_m), number(st.equipment_share), number(st.suspended_share), number(st.longitudinal_kn), number(st.transverse_kn)) for st in p.stations],
           [.7, 1.3, 1.2, 1.3, 1.3, 1.3])
    if bundle.axial_transfer is not None:
        para('Transferência axial adotada: forças longitudinais iguais nos contatos opostos, vínculo axial esquerdo no centro de cisalhamento e extremidade direita livre. N e Hs·z são conservados; somente transportes fisicamente opostos de Mz e B se cancelam. Fonte '+source(bundle.axial_transfer.source)+'.')
    else:
        para('Transferência axial especial não declarada. Hs não nulo exige essa premissa antes do cálculo mecânico.' if any(st.longitudinal_kn for st in p.stations) else 'Hs = 0 explicitamente em todos os eixos. Não se requer transferência axial especial neste caso.')

    para('Parâmetros de fadiga e admissíveis', 'Heading 1')
    _table(doc, ['Parâmetro', 'Adoção', 'Fonte'], [
        ('Grau do material', bundle.material_grade+'; fy/fu = '+number(m.fy_mpa/m.fu_mpa), source(bundle.material_source)),
        ('Grupo do componente', bundle.component_group+'; '+CLASSIFICATION.get(bundle.classification_kind, bundle.classification_kind), source(bundle.classification_source)),
        ('Detalhe', DETAIL.get(bundle.construction_detail, bundle.construction_detail), source(bundle.detail_source)),
        ('Fabricação e inspeção', FABRICATION.get(bundle.fabrication_requirement, bundle.fabrication_requirement)+'; especificação não é inspeção realizada', source(bundle.fabrication_source)),
        ('Resistência reversa', 'κ = −1 adotado conservadoramente' if bundle.kappa_minus_one_adopted else 'κ = −1 não adotado', source(bundle.kappa_source)),
        ('Aceitação numérica', 'Tolerância relativa máxima = '+number(bundle.numerical_tolerance)+'; dois passes estáveis', source(bundle.numerical_source)),
    ], [1.6, 4.8, .7])
    if m.fy_mpa/m.fu_mpa >= .70:
        para('Ramo material fy/fu ≥ 0,70: '+('a igualdade permanece pendente nesta camada.' if m.fy_mpa/m.fu_mpa == .70 else 'admissão depende da adoção explícita do projeto.')+' Fonte '+source(bundle.high_ratio_material_source)+'.')
    para('A espessura é física: tf nas mesas e tw na alma. O grupo E não é inferido da capacidade, de ciclos isolados, de classes CMAA ou do grupo A. κ = −1 é redução conservadora de resistência, não história temporal reconstruída. O fator 4/3 já incorporado às admissíveis não é reaplicado.')
    admissibles = []
    seen = set()
    for check in checks:
        kernel = check.get('kernel_result') or {}
        capacity = kernel.get('capacity')
        material = kernel.get('input', {}).get('material', {})
        if not capacity:
            continue
        row = (number(material.get('thickness_mm')), number(capacity.get('sigma_w_mpa')),
               number(capacity.get('normal_x_capacity_mpa')), number(capacity.get('normal_y_capacity_mpa')),
               number(capacity.get('shear_capacity_mpa')))
        if row not in seen:
            seen.add(row)
            admissibles.append(row)
    if admissibles:
        _table(doc, ['Espessura mm', 'σw MPa', 'Ax MPa', 'Ay MPa', 'T MPa'], admissibles, [1.35, 1.35, 1.45, 1.45, 1.5])
    else:
        para('Não há admissíveis qualificadas disponíveis nesta execução.')
    para('A combinação nominal adotada é σN + σM + σB + 0,75σlocal,x, com parcela local transversal integral. Trata-se de interpretação conjunta das prescrições publicadas da NBR 10084, 9.1.1 a 9.1.4, e NBR 8400-2, seção 4, 5.6 e D.2.3; não é fórmula literal que escreva N e B na NBR 10084 nem novo fator independente de fadiga.')
    para('Mantém-se a Equação (D.5), com admissíveis de fadiga próprias: Q = (σx/Ax)² + (σy/Ay)² − σxσy/(|Ax| |Ay|) + (τ/T)² ≤ 1. No plano xz, a segunda tensão normal e o cisalhamento são os do plano xz. A utilização apresentada é √Qmax da caixa assinada; os limites individuais também são verificados.')

    para('Resultados por ponto face e plano', 'Heading 1')
    counts = summary['counts']
    para('Casos gerados / calculados / convergidos: '+str(summary.get('generated_cases', len(cases)))+' / '+str(summary.get('calculated_cases', 0))+' / '+str(summary.get('converged_cases', 0))+'. '+ '; '.join(status_label(key)+': '+str(value) for key, value in counts.items() if value)+'.')
    _table(doc, ['Ponto ou região', 'Face', 'Plano', 'Utilização', 'Situação'], [
        (point_label(c.get('point_id')) if c.get('point_id') else region_label(c.get('region')), face_label(c.get('face')),
         c.get('plane') or 'n/d', number(c.get('utilization')), status_label(c['status'])) for c in checks],
        [2.1, 1.45, .5, .75, 2.3], size=8.2)
    para('Os resultados locais P0/P1/P2 pertencem à mesa inferior; esq. e dir. identificam os lados físicos. A utilização é majorante suficiente, não estado concomitante nem fração de vida consumida. A ausência de valor não equivale a tensão nula.')
    reasons = _report_reasons(checks, cases)
    if reasons:
        para('Pendências e majorantes excedidos', 'Heading 2')
        all_case_titles = {c.get('title') or c['id'] for c in cases}
        for reason, affected in reasons.items():
            label = 'Todos os casos mecânicos' if affected == all_case_titles else ', '.join(sorted(affected))
            item = para(label+': '+reason)
            item.paragraph_format.keep_together = True

    para('Casos ações e evidência numérica', 'Heading 1')
    _table(doc, ['Caso', 'Carga útil', 'Sinais Hy Hs', 'Fatores G Qc Qt R H Gx', 'Cálculo'], [
        ('C'+str(i+1).zfill(2), 'Carregado' if c['case'].get('loaded') else 'Vazio',
         str(c['case'].get('transverse_sign'))+' / '+str(c['case'].get('longitudinal_sign')),
         ' / '.join(number(c['case'].get(k)) for k in ('support_factor', 'equipment_factor', 'payload_factor', 'retained_factor', 'horizontal_factor', 'extra_factor')),
         'Convergido' if (c.get('scan') or {}).get('numerical_converged') else 'Sem convergência' if c.get('calculated') else 'Não calculado') for i, c in enumerate(cases)],
        [1.8, .8, .8, 2.4, 1.3], size=8)
    para('G = peso próprio; Gx = peso adicional; Qc = talha/trole; Qt = carga útil; R = massa suspensa retida; H = ações horizontais. Os fatores acima vêm de cada caso FAT8400 gerado e são aplicados uma vez. Todos os casos gerados devem integrar a avaliação; isso não prova que todas as ações físicas do equipamento foram informadas.')
    valid_scans = [c['scan'] for c in cases if c.get('scan')]
    if valid_scans:
        scan = valid_scans[0]
        props = scan['metadata']['properties']
        prop_rows = [(label, number(props.get(key))) for key, label in (
            ('A_mm2', 'Área A mm²'), ('Ix_mm4', 'Inércia forte mm⁴'), ('Iy_mm4', 'Inércia fraca mm⁴'),
            ('J_mm4', 'Torção uniforme J mm⁴'), ('Cw_mm6', 'Empenamento Cw mm⁶'))]
        _table(doc, ['Propriedade canônica', 'Valor'], prop_rows, [4.4, 2.7])
        para('J e Cw canônicos foram escolhidos antes da solução; Cw é o modelo setorial das mesas, intencionalmente distinto da aproximação da base que incorpora a inércia total. Eixos físicos s longitudinal, y lateral e z para cima; torção pela mão direita. A convenção Green é convertida pelo produtor assinado.')
        para('Extremos espaciais analíticos e refinamento aninhado da translação fornecem convergência numérica de engenharia, não fechamento matemático de todo o contínuo. Históricos por caso, tolerâncias, balanço, forças por roda, intervalos dos seis componentes do tensor e identidades integrais constam do JSON de evidência.')
    else:
        para('Sem recibos mecânicos disponíveis: não se apresentam propriedades ou respostas como se tivessem sido calculadas.')
    if nominal.get('resultant_intervals'):
        para('Intervalos assinados dos esforços', 'Heading 2')
        factors = {'N': (1e-3, 'N kN'), 'My': (1e-6, 'My kN m'), 'Mz': (1e-6, 'Mz kN m'),
                   'B_equilibrated': (1e-9, 'B kN m²'), 'Fy': (1e-3, 'Fy kN'), 'Fz': (1e-3, 'Fz kN'),
                   'Tsv': (1e-6, 'Tsv kN m'), 'Tw_equilibrated': (1e-6, 'Tw kN m')}
        _table(doc, ['Componente física', 'Mínimo', 'Máximo'],
               [(label, number(nominal['resultant_intervals'][key]['lower']*factor),
                 number(nominal['resultant_intervals'][key]['upper']*factor))
                for key, (factor, label) in factors.items()], [3.1, 2., 2.])
        para('União conservadora dos intervalos de todos os casos FAT8400. Os extremos das componentes não são necessariamente concomitantes.')
    if nominal.get('physical_wheel_intervals'):
        _table(doc, ['Roda física', 'Força vertical mínima kN', 'Força vertical máxima kN'],
               [(row['id'].replace('left', 'esq.').replace('right', 'dir.'),
                 number(row['downward_N']['lower']/1000), number(row['downward_N']['upper']/1000))
                for row in nominal['physical_wheel_intervals']], [3.1, 2., 2.])
    references_start = len(doc.paragraphs)
    para('Referências por mecanismo e fontes declaradas', 'Heading 1')
    para('Ações de fadiga: ABNT NBR 8400-2:2019, corrigida em 2022, 5.6.1 a 5.6.5. Recuperação nominal elástica: seção 4 dessa norma; ABNT NBR 10084:2020, 9.1.2 b e c; torção e empenamento pela mecânica de Vlasov, SCI P385, seção 2.')
    para('Grupo e resistência W0: NBR 8400-2, D.1, D.2 e Tabela D.1. Cisalhamento: D.2.2. Interação planar: Anexo D, D.2.3, Equação (D.5). Combinação global/local: interpretação conjunta indicada nesta memória, mantendo 0,75 somente na parcela local longitudinal.')
    for text, key in sources.items():
        para(key+'  '+text)
    if bundle.notes:
        para('Notas do responsável', 'Heading 2')
        para(bundle.notes)
    para('Rastreabilidade: o JSON de evidência preserva o snapshot das entradas, fontes, casos, recibos, tensores e assinaturas completas. Alterar entradas, fontes, resultado ou dependências invalida esta execução; a exportação não recalcula nem revalida fisicamente documentos declarados.')
    # Keep a short reference/source register coherent instead of leaving a
    # last page containing only a few notes. Long real registers still flow.
    register = doc.paragraphs[references_start:]
    if summary.get('calculated_cases') and sum(len(item.text) for item in register) <= 4000 and len(register) <= 22:
        for item in register[:-1]:
            item.paragraph_format.keep_with_next = True
    stream = BytesIO()
    doc.save(stream)
    _guard_end(bundle, result, guard)
    return stream.getvalue()
