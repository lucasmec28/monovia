"""Illustrative input fixtures, not catalog or manufacturer data.

Complete means every input needed by the implemented numerical mechanisms is
supplied. It never means all equipment events, EN fatigue/contact/connections or
national conformity are covered. Generated partial G6 reference cases remain
visible separately from the fully supplied action variants.
"""
from dataclasses import replace
from en_project import demo_en_project,synchronize_beam_gravity
from en_actions import ENTestRequest

SOURCE='EXEMPLO SINTÉTICO DE VERIFICAÇÃO DO APLICATIVO. Não representa equipamento, fabricante, catálogo ou certificado real.'


def complete_en_example():
    b=demo_en_project();a=b.actions
    fractions=tuple(w.payload_fraction for w in a.wheels)
    tests=(ENTestRequest('SYNTHETIC_STATIC','static',1.25*a.nominal_qh_kn,fractions,SOURCE+' Ensaio estático ilustrativo, QT completo incluindo acessórios/cabos.'),
           ENTestRequest('SYNTHETIC_DYNAMIC','dynamic',1.10*a.nominal_qh_kn,fractions,SOURCE+' Ensaio dinâmico ilustrativo, QT completo incluindo acessórios/cabos.'))
    b.project.project_name='Exemplo sintético EN com dados preenchidos e ensaios'
    b.actions=replace(a,project_name=b.project.project_name,tests=tests,
        notes=SOURCE+' Conjuntos de forças são estados característicos distintos definidos para testar cada mecanismo, não uma alegação de cobertura de um equipamento comercial. O subconjunto vertical G6 é referência incompleta, não substitui os conjuntos completos.')
    b.notes=SOURCE+' Dados preenchidos para os mecanismos implementados; permanecem as exclusões de contato/raiz tridimensional, fadiga EN, ligações, vibração, eventos e aplicabilidade nacional.'
    return b.validate()


def failed_en_example():
    b=complete_en_example();a=b.actions
    payload=500.;qh=payload+a.retained_lifting_accessories_kn+a.moving_suspended_ropes_kn
    wheels=tuple(replace(w,maximum_static_vertical_kn=a.qc_kn*w.qc_fraction+payload*w.payload_fraction+
        a.retained_lifting_accessories_kn*w.retained_fraction+a.moving_suspended_ropes_kn*w.ropes_fraction,
        maximum_static_vertical_source=SOURCE+' Máximo estático calculado deste próprio cenário ilustrativo.') for w in a.wheels)
    tests=tuple(replace(t,total_hoist_test_kn=(1.25 if t.kind=='static' else 1.10)*qh) for t in a.tests)
    b.project.project_name='Exemplo sintético EN com critérios não atendidos'
    b.actions=replace(a,project_name=b.project.project_name,nominal_payload_kn=payload,operating_payload_kn=payload,wheels=wheels,tests=tests)
    b.notes=SOURCE+' Carga deliberadamente elevada para testar falhas nominais testemunhadas, majorantes excedidos e exportação. Não corresponde a uma capacidade real aprovada.'
    return b.validate()


def out_of_domain_en_example():
    b=complete_en_example();b.project.section.tw_mm=4.
    b.project.section.name='Seção sintética de alma esbelta fora da classe 1–3 do consumidor global'
    b.project.project_name='Exemplo sintético EN fora do domínio resistente global'
    b.actions=replace(b.actions,project_name=b.project.project_name)
    b.notes=SOURCE+' Alma delgada proposital: a resposta elástica pode ser calculada, mas não se deve declarar atendida a resistência global quando a rota de classe 1–3 não se aplica.'
    synchronize_beam_gravity(b)
    return b.validate()
