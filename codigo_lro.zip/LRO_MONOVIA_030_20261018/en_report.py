"""Delimited EN evidence exports and deterministic physical-coordinate figures.

This reporting layer never manufactures a structural approval, an uncalculated
result, or a new resistance equation. Action values come only from ENActionInput
and its owned receipt. Plot inputs are the physical (s,y,z) diagram_en API.
"""
from __future__ import annotations

from hashlib import sha256
from io import BytesIO
from pathlib import Path
import json
import math

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Circle, Polygon, Rectangle
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH

from en_analysis import assert_current_en_result, diagram_en
from monorail.analysis import digest
from underslung_runway_candidate.section_stress.recovery import ISection, geometric_properties

EVIDENCE_FORMAT = 'LRO_MONORAIL_EN_EVIDENCE'
STATUS = {'PASS':'Passa no domínio', 'FAIL':'Falha no critério',
          'BOUND_EXCEEDED':'Majorante excedido', 'PENDING':'Pendente',
          'OUT_OF_SCOPE':'Fora do escopo', 'OUT_OF_DOMAIN':'Fora do domínio',
          'NOT_CALCULATED':'Não calculado'}
FAMILY = {'EN_ULS_STR':'ELU estrutural', 'EN_SLS_STRESS':'ELS tensões',
          'EN_TEST_ULS':'ELU ensaio', 'EN_TEST_SLS':'ELS ensaio',
          'EN_SLS_DEFLECTION':'ELS flecha'}
BLUE = '#24556b'
ORANGE = '#b46a18'


def number(value, digits=4, signed=False):
    if value is None:
        return 'n/a'
    if type(value) not in (float, int) or not math.isfinite(value):
        raise ValueError('A report number must be finite')
    if value == 0:
        return '0'
    return format(value, ('+' if signed else '') + '.' + str(digits) + 'g')


def _origin_label(origin_id):
    return {'G_beam': 'Peso próprio da viga'}.get(origin_id, origin_id)


def _reference_text_pt(text):
    """Translate explanatory labels only; keep reference clauses and symbols."""
    translations = (
        ('Derived combination, not a transcribed equation', 'Combinação derivada, não transcrição de uma equação'),
        ('5% maximum static vertical wheel load without dynamic factor', '5% da força vertical estática máxima por roda, sem fator dinâmico'),
        ('payload-only criterion adopted as independently identified route', 'critério da carga útil isolada adotado como rota identificada separadamente'),
        ('explicit zero precamber in this implementation', 'contraflecha zero explícita nesta implementação'),
        ('total characteristic vertical deflection', 'flecha vertical característica total'),
        ('monorail hoist-load increment', 'incremento da carga de içamento da monovia'),
        ('SLS stress and ULS checks required', 'verificações de tensões ELS e ELU requeridas'),
        ('No 1.35 times 1.1 on the crane group.', 'Sem produto adicional de 1,35 por 1,1 no grupo do equipamento.'),
        ('with whole-group correlation', 'com correlação de todo o grupo'),
        ('characteristic combination', 'combinação característica'),
        ('fixed monorail', 'monovia fixa'),
        ('without dynamics', 'sem dinâmica'),
        ('less precamber', 'menos contraflecha'),
        ('correlated group', 'grupo correlacionado'),
        ('action factors', 'fatores das ações'),
        ('printed pp.', 'páginas impressas '),
        ('corrected Table', 'Tabela corrigida'),
        ('dynamic QT', 'dinâmico QT'),
        ('static QT', 'estático QT'),
        ('recommended', 'recomendado'),
        ('separately', 'separadamente'),
        ('expression', 'expressão'),
        ('group8', 'grupo 8'),
        ('Tables', 'Tabelas'),
        ('Table', 'Tabela'),
        ('sections', 'seções '),
        (' and ', ' e '),
    )
    for source, target in translations:
        text = text.replace(source, target)
    return text


def _report_hash():
    return sha256(Path(__file__).read_bytes()).hexdigest()


def _guard_start(bundle, result):
    assert_current_en_result(bundle, result)
    return bundle.signature(), digest(result), _report_hash()


def _guard_end(bundle, result, guard):
    assert_current_en_result(bundle, result)
    if guard != (bundle.signature(), digest(result), _report_hash()):
        raise ValueError('EN inputs, results or reporting code changed during export; export again')


def export_en_json(bundle, result):
    """Return evidence, deliberately not a project-input format."""
    guard = _guard_start(bundle, result)
    payload = dict(format=EVIDENCE_FORMAT, schema_version=1,
                   purpose='Evidência de cálculo delimitado; não importar como entrada de projeto.',
                   whole_design_approved=False, report_source_sha256=guard[2],
                   input_snapshot=bundle.to_dict(), calculation=result)
    payload['evidence_signature'] = digest(payload)
    data = json.dumps(payload, ensure_ascii=False, indent=2, allow_nan=False).encode('utf-8')
    _guard_end(bundle, result, guard)
    return data


def _figure_bytes(fig, format='png'):
    if format not in ('png', 'svg'):
        plt.close(fig)
        raise ValueError('EN figures support png or svg')
    data = BytesIO()
    with matplotlib.rc_context({'svg.fonttype':'none', 'svg.hashsalt':'LRO-EN-physical-v1'}):
        fig.savefig(data, format=format, dpi=180, bbox_inches='tight', facecolor='white',
                    metadata={'Date':None, 'Creator':'LRO Monovia EN'} if format == 'svg'
                    else {'Software':'LRO Monovia EN'})
    plt.close(fig)
    return data.getvalue()


def schematic_en(bundle, format='png'):
    """Use EN components, never the inert legacy carrier's load fields."""
    bundle.validate()
    p, a = bundle.project, bundle.actions
    s = p.section
    fig, (ax, cs) = plt.subplots(1, 2, figsize=(11, 4.5),
                                 gridspec_kw={'width_ratios':[1.65, 1.]}, layout='constrained')
    L = p.span_m
    translation = (a.travel_min_m+a.travel_max_m)/2
    # Elevation is schematic, not to scale in the vertical direction.
    ax.add_patch(Rectangle((0, 0), L, .32, fc='#eff4f6', ec=BLUE, lw=.8))
    ax.plot([0, L], [0, 0], color=BLUE, lw=4, solid_capstyle='butt')
    ax.plot([0, L], [.32, .32], color=BLUE, lw=3, solid_capstyle='butt')
    sx = max(L*.016, .03)
    for x in (0, L):
        ax.add_patch(Polygon([[x, 0], [x-sx, -.18], [x+sx, -.18]], fc='#d3e1e7', ec=BLUE))
    offsets = sorted({w.offset_m for w in a.wheels})
    cart_left, cart_right = translation+min(offsets), translation+max(offsets)
    for i, offset in enumerate(offsets):
        x = translation+offset
        ax.add_patch(Circle((x, .055), .055, fc=ORANGE, ec='black', lw=.7))
        ax.plot([x, x], [-.015, -.30], color=ORANGE, lw=1.5)
        ax.text(x, .44, f'E{i+1}\n2 rodas', ha='center', fontsize=8)
    ax.plot([cart_left, cart_right], [-.30, -.30], color=ORANGE, lw=2)
    hook = translation+a.hook_offset_m
    # A suspended hoist and hook are explicit, not arrows floating below the rail.
    hw = max(L*.045, .09)
    ax.add_patch(Rectangle((hook-hw/2, -.62), hw, .27, fc='#f2e1ca', ec=ORANGE, lw=1.1))
    ax.plot([hook, hook], [-.30, -.35], color=ORANGE, lw=1.5)
    ax.plot([hook, hook], [-.62, -.90], color=ORANGE, lw=1.4)
    ax.plot([hook, hook+hw*.22, hook+hw*.32], [-.90, -.95, -.88], color=ORANGE, lw=1.4)
    ax.text(hook+hw*.7, -.47, 'Talha suspensa', fontsize=8, va='center')
    ax.annotate('', xy=(hook, -1.14), xytext=(hook, -.98),
                arrowprops=dict(arrowstyle='->', color=ORANGE, lw=1.4))
    ax.annotate('', xy=(0, -1.31), xytext=(L, -1.31), arrowprops=dict(arrowstyle='<->', lw=.8))
    ax.text(L/2, -1.30, f'L = {L:g} m', ha='center', va='bottom', fontsize=9)
    ax.annotate('', xy=(a.travel_min_m, .84), xytext=(a.travel_max_m, .84),
                arrowprops=dict(arrowstyle='<->', color=BLUE))
    ax.text((a.travel_min_m+a.travel_max_m)/2, .90,
            f'a = {a.travel_min_m:g} a {a.travel_max_m:g} m', ha='center', fontsize=9)
    ax.text(0, -1.53,
            f'Qc talha/trole = {number(a.qc_kn)} kN (ação variável móvel)\n'
            f'Útil nominal = {number(a.nominal_payload_kn)} kN; operante = {number(a.operating_payload_kn)} kN\n'
            f'Acessórios retidos = {number(a.retained_lifting_accessories_kn)} kN; cabos = {number(a.moving_suspended_ropes_kn)} kN',
            fontsize=8.2, va='top', linespacing=1.35)
    ax.text(L, -.35, 's →', fontsize=10, ha='right')
    ax.set_title(f'Elevação esquemática  |  a = {translation:g} m', loc='left', fontsize=11)
    ax.set_xlim(-.06*L, 1.06*L)
    ax.set_ylim(-2.03, 1.15)
    ax.axis('off')

    b, d, tf, tw = s.bf_mm, s.d_mm, s.tf_mm, s.tw_mm
    # Wide sections retain physical proportions. Reserve real drawing space for
    # annotations instead of compressing fixed-height text into a shallow axis.
    wide = b > d
    n_line_z = -d/2-.08*b if wide else -d*.57
    n_text_z = -d/2-.20*b if wide else -d*.62
    bf_line_z = d/2+.08*b if wide else d*.58
    bf_text_z = d/2+.15*b if wide else d*.61
    for rect in ((-b/2, -d/2, b, tf), (-tw/2, -d/2+tf, tw, d-2*tf), (-b/2, d/2-tf, b, tf)):
        cs.add_patch(Rectangle(rect[:2], rect[2], rect[3], fc='#d3e1e7', ec=BLUE, lw=1.1))
    contact = b/2-p.edge_to_contact_mm
    z = tf-d/2
    clearance = max(1., contact-tw/2-s.root_radius_mm)
    radius = max(1., min(b*.055, p.edge_to_contact_mm*.4, clearance*.4))
    for sign in (-1, 1):
        y = sign*contact
        cs.add_patch(Circle((y, z+radius), radius, fc=ORANGE, ec='black', lw=.7))
        cs.plot(y, z, 'o', color='black', ms=2)
        cs.annotate('', xy=(y, z), xytext=(y, z+radius*2+d*.12),
                    arrowprops=dict(arrowstyle='->', color=ORANGE))
    if wide:
        cs.plot([contact, b/2], [n_line_z, n_line_z], color='black', lw=.7)
        for y in (contact, b/2):
            cs.plot([y, y], [n_line_z-.015*b, n_line_z+.015*b], color='black', lw=.7)
    else:
        cs.annotate('', xy=(contact, n_line_z), xytext=(b/2, n_line_z),
                    arrowprops=dict(arrowstyle='<->', lw=.7))
    cs.text((contact+b/2)/2, n_text_z, f'n={p.edge_to_contact_mm:g} mm', ha='center', fontsize=8)
    cs.annotate('', xy=(-b/2, bf_line_z), xytext=(b/2, bf_line_z), arrowprops=dict(arrowstyle='<->', lw=.7))
    cs.text(0, bf_text_z, f'bf={b:g} mm', ha='center', fontsize=8)
    cs.annotate('', xy=(-b*.67, -d/2), xytext=(-b*.67, d/2), arrowprops=dict(arrowstyle='<->', lw=.7))
    cs.text(-b*.70, 0, f'd={d:g} mm', rotation=90, ha='right', va='center', fontsize=8)
    cs.text(b*.62, d/2+.35*b if wide else d*.36, f'tf={tf:g}\ntw={tw:g}\nmm', fontsize=8, va='top')
    cs.annotate('', xy=(b*.8, 0), xytext=(0, 0), arrowprops=dict(arrowstyle='->', lw=.8))
    cs.text(b*.82, 0, 'y', fontsize=9)
    cs.annotate('', xy=(0, d*.25), xytext=(0, 0), arrowprops=dict(arrowstyle='->', lw=.8))
    cs.text(b*.04, d*.25, 'z', fontsize=9)
    cs.text(0, -d/2-.44*b if wide else -d*.77,
            'Contato na face superior da mesa inferior\nRodas simbólicas, sem diâmetro de catálogo\ns sai do plano; torção pela mão direita',
            ha='center', fontsize=7.8, linespacing=1.35)
    cs.set_title('Seção e contatos físicos', loc='left', fontsize=11)
    cs.set_aspect('equal')
    cs.set_xlim(-b*.85, b*.98)
    cs.set_ylim((-d/2-.75*b, d/2+.50*b) if wide else (-d*.91, d*.75))
    cs.axis('off')
    return _figure_bytes(fig, format)


def _plot_data(data, required):
    if type(data) is not dict or not data.get('rows'):
        raise ValueError('A physical diagram_en result with nonempty rows is required')
    for row in data['rows']:
        for key in ('s_m',)+tuple(required):
            value = row.get(key)
            if type(value) not in (int, float) or not math.isfinite(value):
                raise ValueError('Missing or nonfinite physical diagram component '+key)
    return data['rows']


def _axis(ax, rows, key, title, color=BLUE, label=None):
    ax.plot([r['s_m'] for r in rows], [r[key] for r in rows], color=color, lw=1.5, label=label)
    ax.set_title(title, loc='left', fontsize=9.5)
    ax.set_xlabel('s (m)', fontsize=9)
    ax.grid(alpha=.2)
    ax.axhline(0, color='#888888', lw=.6)
    ax.tick_params(labelsize=8)
    ax.ticklabel_format(axis='y', style='sci', scilimits=(-3,4), useOffset=False)
    ax.yaxis.get_offset_text().set_fontsize(8)


def _figure_title(data):
    return f"Estado concomitante  |  {FAMILY.get(data.get('family'), 'EN')}  |  a = {number(data['translation_m'], 5)} m"


def diagram_figure(data, format='png'):
    """Signed physical efforts; no envelope or legacy-axis conversion here."""
    keys = ('N_kN','My_kNm','Mz_kNm','Vy_kN','Vz_kN','T_kNm','Tsv_kNm','Tw_kNm','B_kNm2')
    rows = _plot_data(data, keys)
    fig, axes = plt.subplots(4, 2, figsize=(10, 8.5), layout='constrained')
    specs = [('My_kNm','My forte (kN m)'), ('Mz_kNm','Mz fraco (kN m)'),
             ('Vz_kN','Vz vertical (kN)'), ('Vy_kN','Vy lateral (kN)'),
             ('N_kN','N axial (kN), tração positiva'), ('T_kNm','T total (kN m)'),
             ('B_kNm2','B bimomento (kN m²)')]
    for ax, (key, title) in zip(axes.flat, specs):
        _axis(ax, rows, key, title)
    ax = axes.flat[-1]
    _axis(ax, rows, 'Tsv_kNm', 'Parcelas de torção (kN m)', label='Saint-Venant')
    ax.plot([r['s_m'] for r in rows], [r['Tw_kNm'] for r in rows], color=ORANGE, lw=1.4, label='Empenamento')
    ax.legend(fontsize=8)
    fig.suptitle(_figure_title(data)+'\nEixos físicos s, y, z; z para cima; mão direita em +s', fontsize=11)
    return _figure_bytes(fig, format)


def displacement_figure(data, format='png'):
    keys = ('uy_mm','uz_mm','phi_mrad','contact_uy_mm','contact_left_uz_mm','contact_right_uz_mm')
    rows = _plot_data(data, keys)
    fig, axes = plt.subplots(2, 2, figsize=(10, 4.4), layout='constrained')
    _axis(axes[0,0], rows, 'uz_mm', 'uz centroide (mm), positivo para cima')
    _axis(axes[0,1], rows, 'uy_mm', 'uy lateral (mm)', label='Centroide')
    axes[0,1].plot([r['s_m'] for r in rows], [r['contact_uy_mm'] for r in rows], color=ORANGE, lw=1.3, ls='--', label='Nível de contato')
    axes[0,1].legend(fontsize=8)
    _axis(axes[1,0], rows, 'phi_mrad', 'Rotação em +s (mrad), mão direita')
    _axis(axes[1,1], rows, 'contact_left_uz_mm', 'uz nos contatos (mm), positivo para cima', label='Contato y < 0')
    axes[1,1].plot([r['s_m'] for r in rows], [r['contact_right_uz_mm'] for r in rows], color=ORANGE, lw=1.3, ls='--', label='Contato y > 0')
    axes[1,1].legend(fontsize=8)
    fig.suptitle(_figure_title(data), fontsize=11)
    return _figure_bytes(fig, format)


def _table(doc, headers, rows, widths, size=8.5):
    table = doc.add_table(rows=1, cols=len(headers))
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = False
    for i, width in enumerate(widths):
        table.columns[i].width = Inches(width)
    for cell, value in zip(table.rows[0].cells, headers):
        cell.text = str(value)
    for row in rows:
        for cell, value in zip(table.add_row().cells, row):
            cell.text = str(value)
    for ri, row in enumerate(table.rows):
        tr = row._tr.get_or_add_trPr()
        if ri == 0:
            tr.append(OxmlElement('w:tblHeader'))
        tr.append(OxmlElement('w:cantSplit'))
        for ci, cell in enumerate(row.cells):
            cell.width = Inches(widths[ci])
            cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
            props = cell._tc.get_or_add_tcPr()
            borders = OxmlElement('w:tcBorders')
            for edge in ('top','left','bottom','right'):
                item = OxmlElement('w:'+edge)
                for name, value in (('val','single'), ('sz','4'), ('color','D9D9D9')):
                    item.set(qn('w:'+name), value)
                borders.append(item)
            props.append(borders)
            shade = OxmlElement('w:shd')
            shade.set(qn('w:fill'), '1F4D60' if ri == 0 else 'F2F5F7' if ri % 2 == 0 else 'FFFFFF')
            props.append(shade)
            margins = OxmlElement('w:tcMar')
            for edge in ('top','left','bottom','right'):
                item = OxmlElement('w:'+edge)
                item.set(qn('w:w'), '75')
                item.set(qn('w:type'), 'dxa')
                margins.append(item)
            props.append(margins)
            for paragraph in cell.paragraphs:
                paragraph.paragraph_format.space_after = Pt(1.5)
                paragraph.paragraph_format.space_before = Pt(1.5)
                paragraph.paragraph_format.line_spacing = 1.03
                if ci > 0 and len(str(cell.text)) < 22:
                    paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
                for run in paragraph.runs:
                    run.font.size = Pt(size)
                    if ri == 0:
                        run.font.bold = True
                        run.font.color.rgb = RGBColor(255,255,255)
    doc.add_paragraph().paragraph_format.space_after = Pt(1)
    return table


def _paragraph(doc, text, style=None):
    return doc.add_paragraph(str(text), style)


def _figure(doc, raw, caption, width=7.05):
    p = doc.add_paragraph()
    p.paragraph_format.keep_with_next = True
    p.add_run().add_picture(BytesIO(raw), width=Inches(width))
    p = doc.add_paragraph(caption)
    p.paragraph_format.space_after = Pt(8)
    for run in p.runs:
        run.font.size = Pt(8.5)


def _reason_summary(result):
    """One record per distinct unresolved reason, retaining affected mechanisms."""
    grouped = {}
    for row in result['cases']:
        for check in row['checks']:
            if check['status'] in ('PASS',):
                continue
            reasons = check.get('reasons') or ([check['reason']] if check.get('reason') else [])
            if not reasons and check['status'] == 'BOUND_EXCEEDED':
                reasons = ['O majorante conservador excedeu a capacidade; isso não demonstra falha física.']
            if not reasons and check['status'] == 'FAIL':
                reasons = ['Um estado nominal testemunhado excedeu o limite do critério identificado.']
            for reason in reasons:
                grouped.setdefault(_short_reason(reason), set()).add(check.get('mechanism_label', check.get('mechanism','Resposta')))
    return grouped


def _short_reason(reason):
    translations = (
        ('The global-stress bound exceeds fy/gammaM0', 'O majorante da tensão global excede fy/γM0. Truncar a capacidade em zero não restabelece o domínio da expressão de origem, mesmo para força de roda nula.'),
        ('Compression plus arbitrary biaxial moving moments', 'A compressão com flexão biaxial móvel arbitrária não tem qualificação geral dos fatores Cm nesta rota. C.2 permanece pendente; a seção nominal é avaliada separadamente.'),
        ('Actual per-contact transverse dead-force radial work is adverse', 'O trabalho radial das forças transversais nos contatos é desestabilizante. A referência de rigidez torsional retida não está qualificada para este caso.'),
        ('Whole physical passage is not in xe > bf', 'O percurso contém posição fora do ramo interior xe > bf. Não foi inventada interpolação para a transição de extremidade.'),
        ('Remote branch requires', 'O percurso não satisfaz o domínio remoto exigido pela resistência local da mesa inferior. O ramo de extremidade não é substituído automaticamente.'),
        ('First-order non-sway axial gate', 'Não foi demonstrada a condição suficiente Ncomp ≤ min(Ncr,y,Ncr,z)/25 para primeira ordem sem deslocabilidade. Isso não dispensa a estabilidade lateral.'),
        ('Conservative class1–3 flange gate', 'A condição suficiente conservadora de classe 1 a 3 da mesa não foi satisfeita. Não é prova de falha física do perfil.'),
        ('Conservative uniform-compression class1–3 web gate', 'A condição conservadora de classe 1 a 3 da alma em compressão uniforme não foi satisfeita. É necessária uma rota por gradiente ou seção efetiva.'),
        ('Required components of this EN action group are missing', 'Faltam componentes do grupo EN completo. O subconjunto diagnóstico não substitui uma variante com todas as ações exigidas.'),
        ('Components of this complete EN action group are missing.', 'Faltam componentes do grupo EN completo. O subconjunto diagnóstico não substitui uma variante com todas as ações exigidas.'),
        ('G6_horizontal_characteristic_component_not_provided', 'A componente horizontal de G6 não está fornecida neste subconjunto vertical de referência; outras variantes completas são avaliadas separadamente.'),
        ('EN action group is incomplete', 'O grupo de ações está incompleto. A resposta de um subconjunto não substitui as componentes ausentes.'),
    )
    for prefix, translated in translations:
        if prefix in reason:
            return translated
    return reason


def _conclusion(summary):
    counts = summary['counts']
    fail = counts.get('FAIL',0)
    bound = counts.get('BOUND_EXCEEDED',0)
    pending = sum(counts.get(key,0) for key in ('PENDING','NOT_CALCULATED','OUT_OF_SCOPE','OUT_OF_DOMAIN'))
    if not summary.get('calculated_cases'):
        lead = 'Nenhuma resposta mecânica foi calculada nesta execução; não há conclusão resistente.'
    elif not (counts.get('PASS',0) or fail or bound):
        lead = 'Não há critério resistente ou de serviço concluído nesta execução.'
    elif fail:
        lead = f'{fail} verificação(ões) com falha no critério nominal calculado.'
    elif bound:
        lead = f'{bound} verificação(ões) com majorante conservador excedido, sem demonstração automática de falha física.'
    else:
        lead = 'Não foi identificada falha nos critérios efetivamente calculados e concluídos.'
    if pending:
        lead += f' Há {pending} registro(s) pendente(s), não calculado(s) ou fora do domínio/escopo.'
    lead += ' A síntese considera as variantes com todas as componentes de ação exigidas; subconjuntos diagnósticos incompletos são mostrados separadamente.'
    return lead+' O resultado é delimitado e não aprova integralmente a monovia, o equipamento ou sua instalação.'


def _document():
    doc = Document()
    sec = doc.sections[0]
    sec.page_width, sec.page_height = Inches(8.5), Inches(11)
    sec.top_margin = sec.bottom_margin = Inches(.65)
    sec.left_margin = sec.right_margin = Inches(.7)
    for name in ('Normal','Title','Subtitle','Heading 1','Heading 2','Heading 3'):
        style = doc.styles[name]
        style.font.name = 'Arial'
        style.font.color.rgb = RGBColor(0,0,0)
        ppr = style.element.find(qn('w:pPr'))
        if ppr is not None:
            for border in list(ppr.findall(qn('w:pBdr'))):
                ppr.remove(border)
    doc.styles['Normal'].font.size = Pt(10)
    doc.styles['Normal'].paragraph_format.space_after = Pt(6)
    doc.styles['Normal'].paragraph_format.line_spacing = 1.06
    doc.styles['Title'].font.size = Pt(21)
    doc.styles['Heading 1'].font.size = Pt(14)
    doc.styles['Heading 2'].font.size = Pt(11)
    for name in ('Heading 1','Heading 2'):
        doc.styles[name].paragraph_format.space_before = Pt(11)
        doc.styles[name].paragraph_format.space_after = Pt(5)
    footer = sec.footer.paragraphs[0]
    footer.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    footer.add_run('Memória EN delimitada  |  ')
    field = OxmlElement('w:fldSimple')
    field.set(qn('w:instr'), 'PAGE')
    footer._p.append(field)
    for run in footer.runs:
        run.font.size = Pt(8)
    return doc


def export_en_word(bundle, result):
    """Create a concise Portuguese technical report, including pending outcomes."""
    guard = _guard_start(bundle, result)
    p, a, b, r = bundle.project, bundle.actions, bundle.resistance, result
    summary, receipt = r['summary'], r['action_receipt']
    rows = r['cases']
    cases = {row['id']:row for row in rows}
    case_labels = {row['id']:f'C{i+1:02d}' for i,row in enumerate(rows)}
    group_labels = {g['id']:f'A{i+1:02d}' for i,g in enumerate(receipt['groups'])}
    doc = _document()
    declarations = {}
    def declared(source):
        if not source:
            return 'Não informada'
        if source not in declarations:
            declarations[source] = f'D{len(declarations)+1:02d}'
        return declarations[source]
    doc.core_properties.title = 'Memória de cálculo EN de monovia reta'
    doc.core_properties.author = p.responsible or 'LRO Monovia'
    _paragraph(doc, 'Memória de cálculo EN de monovia reta', 'Title')
    _paragraph(doc, a.project_name+' | '+p.member_name, 'Subtitle')
    if bundle.demonstration:
        _paragraph(doc, 'EXEMPLO SINTÉTICO. Não representa catálogo, equipamento real ou certificado de material. As fontes e premissas declaradas devem ser substituídas e verificadas no projeto real.')
    _paragraph(doc, _conclusion(summary))
    _paragraph(doc, f"Responsável informado: {p.responsible or 'não informado'}. Cálculo UTC: {r['created_utc'][:19]}. Revisão {r['version']}.")
    _paragraph(doc, 'Síntese dos mecanismos', 'Heading 1')
    _table(doc, ['Mecanismo','Situação','Utilização governante','Caso'],
           [(m['title'], STATUS.get(m['status'],m['status']), number(m.get('governing_utilization')),
             case_labels.get(m.get('governing_case_id'),'n/a')) for m in summary['mechanisms']],
           [2.75,1.7,1.35,1.25])
    count_rows = [('Variantes completas', summary['counts'])]
    if summary.get('diagnostic_partial_cases'):
        count_rows.append(('Subconjuntos diagnósticos',summary['diagnostic_partial_counts']))
        count_rows.append(('Todos os registros',summary['all_case_counts']))
    _table(doc, ['Base','Passa','Falha','Majorante excedido','Pendente','Não calculado','Fora do domínio ou escopo'],
           [(label,counts.get('PASS',0),counts.get('FAIL',0),counts.get('BOUND_EXCEEDED',0),
             counts.get('PENDING',0),counts.get('NOT_CALCULATED',0),counts.get('OUT_OF_SCOPE',0)+counts.get('OUT_OF_DOMAIN',0))
            for label,counts in count_rows],
           [1.55,.6,.55,1.15,.85,1.05,1.3],size=8)
    if summary.get('diagnostic_partial_cases'):
        _paragraph(doc, f"A síntese por mecanismo cobre {summary['qualified_action_variant_cases']} variantes completas de ação. Os {len(summary['diagnostic_partial_cases'])} casos de subconjuntos parciais são diagnósticos, não convertidos em passa nem apagados do resultado. Essa separação não demonstra cobertura global do equipamento ou conformidade nacional.")
    _paragraph(doc, f"Foram gerados {summary['generated_cases']} casos, calculados {summary['calculated_cases']} e convergidos numericamente {summary['converged_cases']}. As contagens acima são de verificações, não de perfis ou casos independentes; a linha total reúne ambas as bases quando houver diagnósticos. Falta de cálculo não é reprovação do perfil.")
    _paragraph(doc, 'Passa significa apenas que o critério identificado foi satisfeito no domínio indicado. Majorante excedido exige avaliação adicional; falha significa excedência testemunhada do critério nominal, não comprovação de falha física tridimensional.')

    _paragraph(doc, 'Modelo físico e propriedades', 'Heading 1')
    try:
        _figure(doc, schematic_en(bundle), 'Figura 1  Geometria e componentes EN. A altura da elevação é esquemática; a seção identifica os contatos reais em y e z.')
    except (ValueError, ArithmeticError) as exc:
        _paragraph(doc, 'Esquema não disponível para estas entradas no domínio de representação: '+str(exc)+'. Nenhuma figura foi fabricada.')
    s = p.section
    try:
        section = ISection(s.d_mm,s.bf_mm,s.tf_mm,s.tw_mm,construction=s.fabrication,
                           bottom_root_radius_mm=s.root_radius_mm if s.fabrication=='rolled' else 0.,
                           bottom_weld_throat_mm=p.weld_throat_mm if s.fabrication=='welded' else 0.)
        props = geometric_properties(section)
    except (ValueError, ArithmeticError) as exc:
        props = {key:None for key in ('A_mm2','Iy_mm4','Iz_mm4','J_mm4','Cw_mm6')}
        _paragraph(doc, 'Propriedades geométricas não disponíveis no domínio numérico destas entradas: '+str(exc)+'. Os campos n/a não são valores zero nem conclusão resistente.')
    _table(doc, ['Entrada','Valor adotado'], [
        ('Perfil e dimensões', f'{s.name}; d={s.d_mm:g}; bf={s.bf_mm:g}; tf={s.tf_mm:g}; tw={s.tw_mm:g}; r={s.root_radius_mm:g} mm'),
        ('Vão e percurso da referência móvel', f'L={p.span_m:g} m; a={a.travel_min_m:g} a {a.travel_max_m:g} m'),
        ('Contato da roda', f'n={p.edge_to_contact_mm:g} mm da borda; y=±{number((s.bf_mm/2-p.edge_to_contact_mm)/1000)} m; z={number((s.tf_mm-s.d_mm/2)/1000,signed=True)} m'),
        ('Área e inércias físicas', f"A={number(props['A_mm2'],6)} mm²; Iy forte={number(props['Iy_mm4'],6)} mm⁴; Iz fraco={number(props['Iz_mm4'],6)} mm⁴"),
        ('Torção de Saint Venant e empenamento', f"J={number(props['J_mm4'],6)} mm⁴; Cw={number(props['Cw_mm6'],6)} mm⁶"),
        ('Vínculos do modelo', 'Viga de um vão com garfos extremos, empenamento livre e sem crédito de travamento intermediário.'),
        ('Transferência axial', 'Esquerda restrita no centro de cisalhamento; direita livre; forças longitudinais iguais no par.' if bundle.axial_transfer else 'Não declarada; casos que a exigirem permanecem sem cálculo qualificado.')], [2.0,5.05])
    _paragraph(doc, 'Propriedades do modelo de três retângulos e empenamento setorial de mesas, sem crédito de raios/soldas na rigidez nominal. Os eixos deste relatório são físicos: s longitudinal, y transversal e z para cima. My é forte e Mz fraco; N é positivo em tração; torção e rotação seguem a mão direita em +s.')
    _paragraph(doc, 'Fonte da geometria: '+declared(s.property_source)+'; fontes declaradas reunidas ao final desta memória.')
    _paragraph(doc, 'Fonte dos apoios: '+declared(p.restraint_source)+'. Fonte do percurso: '+declared(p.travel_source)+'.')
    if bundle.axial_transfer:
        _paragraph(doc, 'Fonte da transferência axial: '+declared(bundle.axial_transfer.source)+'.')

    _paragraph(doc, 'Material e base resistente', 'Heading 2')
    _table(doc, ['Parâmetro','Valor','Base declarada'], [
        ('Aço e produto', b.material_grade, b.product_standard),
        ('Resistência', f'fy={number(b.fy_mpa)}; fu={number(b.fu_mpa)} MPa', declared(b.strength_thickness_source)),
        ('Elasticidade', f'E={number(b.E_mpa,6)}; G={number(b.G_mpa,6)} MPa', declared(b.elasticity_source)),
        ('Fatores de resistência', f'γM0={number(b.gamma_M0)}; γM1={number(b.gamma_M1)}', declared(b.partial_factor_source)),
        ('Ductilidade', ('Alongamento '+number(b.elongation_percent)+'%' if b.elongation_percent is not None else 'Presunção por produto listado'), declared(b.ductility_source)),
        ('Tenacidade', 'Documentação declarada', declared(b.toughness_source))], [1.35,1.75,3.95])
    _paragraph(doc, 'Fontes de fabricante e material são declarações de entrada. O aplicativo não certifica sua autenticidade nem presume certificado ou adequação de espessura a partir do nome do aço.')

    _paragraph(doc, 'Componentes e grupos de ações', 'Heading 1')
    _paragraph(doc, 'Qc é o peso próprio móvel da talha/trole e permanece ação variável do grupo do equipamento, não G permanente. Qh separa carga útil, acessórios retidos e cabos suspensos móveis, cada parcela ocorrendo uma vez. G contém apenas as origens fixas declaradas da estrutura de apoio.')
    _table(doc, ['Componente EN','Valor','Categoria'], [
        ('Qc talha e trole',number(a.qc_kn)+' kN','Variável móvel'),
        ('Carga útil nominal',number(a.nominal_payload_kn)+' kN','Referência nominal'),
        ('Carga útil operante',number(a.operating_payload_kn)+' kN','Qh variável móvel'),
        ('Acessórios retidos',number(a.retained_lifting_accessories_kn)+' kN','Qh variável móvel'),
        ('Cabos suspensos móveis',number(a.moving_suspended_ropes_kn)+' kN','Qh variável móvel'),
        *[(_origin_label(q.origin_id),number(q.downward_kn_per_m,6)+' kN/m','G fixo') for q in a.fixed_gravity]], [2.7,1.65,2.7])
    _paragraph(doc, 'Fonte dos componentes: '+declared(a.component_source)+'.')
    for load in a.fixed_gravity:
        _paragraph(doc, 'Fonte de '+_origin_label(load.origin_id)+': '+declared(load.source)+'.')
    _table(doc, ['Roda','Offset s m','y m','z m','Fração Qc','Fração útil','Retida e cabos'],
           [(w.wheel_id,number(w.offset_m),number(w.y_m,signed=True),number(w.z_m,signed=True),
             number(w.qc_fraction),number(w.payload_fraction),number(w.retained_fraction)+' / '+number(w.ropes_fraction)) for w in a.wheels],
           [1.1,.85,.8,.8,1.,1.,1.5])
    _paragraph(doc, 'Fonte da distribuição de rodas: '+declared(a.wheel_distribution_source)+'.')
    _paragraph(doc, f'Gancho declarado: offset s={number(a.hook_offset_m)} m; y={number(a.hook_y_m,signed=True)} m; z={number(a.hook_z_m,signed=True)} m. As forças da viga são aplicadas nos contatos das rodas, não duplicadas no gancho.')
    _paragraph(doc, f'Dinâmica de içamento: {a.hoist_dynamics.hoist_class}, velocidade estável {number(a.hoist_dynamics.steady_speed_m_s)} m/s. Fontes: {declared(a.hoist_dynamics.classification_source)} e {declared(a.hoist_dynamics.speed_source)}. Translação: {dict(class1_documented='Classe 1 documentada',manufacturer='valor de fabricante',unresolved='não resolvida').get(a.travel_dynamics.basis,a.travel_dynamics.basis)}; fonte: {declared(a.travel_dynamics.source)}.')
    _table(doc, ['Grupo','Descrição','φ1','φ2','φ4','φ6','η','Geração'],
           [(group_labels[g['id']]+' '+({'PAYLOAD_ONLY_SLS':'ELS útil','TOTAL_GRAVITY_SLS':'ELS total'}.get(g['group_code'],g['group_code'])),g['title'].replace('Ensaio static','Ensaio estático').replace('Ensaio dynamic','Ensaio dinâmico')+(' | '+g['horizontal_set_id'] if g.get('horizontal_set_id') else ''),*[number(g.get(k)) for k in ('phi1','phi2','phi4','phi6','eta')],
             'Gerado' if g['generation_status']=='ACTIONS_GENERATED' else 'Pendente') for g in receipt['groups']],
           [.8,2.4,.5,.55,.5,.5,.75,1.05],size=8)
    _paragraph(doc, 'Cada linha é um grupo correlacionado. Não se escolhem fatores favoráveis roda a roda. “Gerado” significa aritmética disponível, não cobertura completa de todas as ações. Os grupos sem entrada suficiente são preservados como pendência no recibo, mesmo quando não produzem caso numérico.')
    combinations = {}
    for row in rows:
        c = row['action_case']
        key = (row['family'],c['gamma_g'],c['gamma_q'],c['psi'])
        combinations.setdefault(key, []).append(group_labels[row['group_id']])
    _table(doc, ['Família','γG','γQ','ψ','Grupos'],
           [(FAMILY.get(k[0],k[0]),number(k[1]),number(k[2]),number(k[3]),', '.join(dict.fromkeys(v))) for k,v in combinations.items()],
           [1.65,.6,.6,.6,3.6])
    _paragraph(doc, 'G fixo recebe γG; todo o grupo variável, incluindo Qc e horizontais, recebe o mesmo γQ e ψ. O ledger JSON conserva por origem: valor de referência, fator dinâmico, valor característico, fatores parciais/de combinação, força final, posição e fonte. Valores n/a não são substituídos por 1.')
    _paragraph(doc, 'Fallback longitudinal: ±5% da força estática máxima individual documentada, sem fator dinâmico adicional. Não é somado automaticamente aos conjuntos horizontais de fabricante. Cada conjunto fornecido preserva sua direção e simultaneidade, sem reversão automática.')
    if a.manufacturer_horizontal_sets:
        for horizontal in a.manufacturer_horizontal_sets:
            _paragraph(doc, f'Conjunto horizontal {horizontal.set_id}: {horizontal.direction_description} Fonte: {declared(horizontal.source)}. Simultaneidade: {declared(horizontal.simultaneity_source)}. Geometria: {declared(horizontal.application_geometry_source)}.')
        horizontal_rows = []
        for horizontal in a.manufacturer_horizontal_sets:
            by_force = {}
            for force in horizontal.wheel_forces:
                by_force.setdefault((force.fs_kn,force.fy_kn),[]).append(force.wheel_id)
            for (fs,fy),wheels in by_force.items():
                horizontal_rows.append((horizontal.set_id,', '.join(wheels),number(fs,signed=True),number(fy,signed=True)))
        _table(doc, ['Conjunto fornecido','Rodas com a mesma força','Fs por roda kN','Fy por roda kN'], horizontal_rows,[2.1,2.35,1.3,1.3])
        _paragraph(doc, 'Forças horizontais características já incluem a dinâmica declarada; não se aplica φ5 adicional. Sinais físicos nas rodas: +s longitudinal e +y transversal. As posições são as da tabela de rodas.')
    else:
        _paragraph(doc, 'Não há conjunto horizontal de fabricante declarado. Isso não equivale a adotar ações horizontais nulas no equipamento real.')
    _table(doc, ['Roda','Máximo estático kN','Fonte do máximo'],
           [(w.wheel_id,number(w.maximum_static_vertical_kn),declared(w.maximum_static_vertical_source)) for w in a.wheels], [1.1,1.4,4.55])
    if a.tests:
        _table(doc, ['Ensaio','Tipo','QT total kN','Fonte'],
               [(t.test_id,{'static':'Estático','dynamic':'Dinâmico'}[t.kind],number(t.total_hoist_test_kn),declared(t.source)) for t in a.tests], [2.6,1.,1.3,2.15])
        _paragraph(doc, 'QT substitui Qh completo, sem duplicar acessórios ou cabos. Ensaio dinâmico usa φ6=(1+φ2)/2 e o estático φ6=1. A combinação de ensaio adota γF,test=1,1 no grupo, sem multiplicá-lo adicionalmente por 1,35; G fixo permanece separado. Posições e horizontais exigem o plano específico.')
    else:
        _paragraph(doc, 'Nenhum ensaio foi solicitado. Ensaios, batentes, liberação brusca, clima e demais eventos não fornecidos não são inferidos a partir dos grupos calculados.')
    _paragraph(doc, 'Fonte do domínio de ações declarado: '+declared(a.domain_source)+'.')

    _paragraph(doc, 'Resultados governantes e evidência numérica', 'Heading 1')
    governed = list(dict.fromkeys(m['governing_case_id'] for m in summary['mechanisms'] if m.get('governing_case_id')))
    _table(doc, ['Caso','Grupo','Família','γG / γQ / ψ','Resultado agregado'],
           [(case_labels[cid],group_labels[cases[cid]['group_id']],FAMILY.get(cases[cid]['family'],cases[cid]['family']),
             ' / '.join(number(cases[cid]['action_case'][k]) for k in ('gamma_g','gamma_q','psi')),
             STATUS.get(cases[cid]['status'],cases[cid]['status'])) for cid in governed],
           [.55,.65,1.4,1.6,2.85])
    _paragraph(doc, 'Entre as variantes completas de ação, o caso governante da síntese é aquele com maior utilização numérica disponível no mecanismo; a situação agregada também considera pendências de outros casos dessa base. A lista integral de casos, verificações e testemunhos está no JSON, sem exclusão de casos não calculados.')
    numerical = [row for row in rows if row['calculated'] and row.get('scan')]
    selected = next((cases[m['governing_case_id']] for m in summary['mechanisms']
                     if m['id']=='global_section' and m.get('governing_case_id') and cases[m['governing_case_id']]['calculated']),
                    next((row for row in rows if row['calculated']), None))
    if selected:
        data = diagram_en(bundle, r, selected['id'])
        _figure(doc, diagram_figure(data), f"Figura 2  Esforços físicos do caso {case_labels[selected['id']]} em a={number(data['translation_m'],6)} m. É um estado concomitante, não união de máximos independentes.")
        _paragraph(doc, 'A posição desta figura é a testemunha de maior módulo do momento forte do caso selecionado; não se afirma que governe cada mecanismo. Nos pontos de aplicação, as duas faces da descontinuidade são conservadas.')
        if numerical:
            _paragraph(doc, f"Tolerância relativa adotada: {number(b.maximum_accepted_numerical_relative_tolerance*100)}%. Fonte: {declared(b.numerical_acceptance_source)}. A varredura usa raízes espaciais analíticas e refinamento de translação com duas comparações estáveis. Convergência é evidência numérica de engenharia, não majorante matemático certificado do percurso contínuo.")
            _paragraph(doc, f"Maior resíduo escalar registrado de equilíbrio: {number(max(row['scan']['max_equilibrium_residual'] for row in numerical),5)} nas unidades originais N ou N mm do componente. Não é indicador de resistência nem percentual adimensional.")
        _paragraph(doc, 'Reações físicas concomitantes', 'Heading 2')
        reaction_rows = []
        for side, side_label in (('left','Esquerdo'),('right','Direito')):
            for key, description in (('support_on_beam','Apoio sobre viga'),('beam_on_support','Viga sobre apoio')):
                pr = data[key]
                reaction_rows.append((side_label,description,*[number(pr[f'{axis}_{side}_N']/1000,5,signed=True) for axis in ('Rs','Ry','Rz')],number(pr[f'Ms_{side}_Nmm']/1e6,5,signed=True)))
        _table(doc, ['Apoio','Ação','Rs kN','Ry kN','Rz kN','Ms kN m'],reaction_rows,[.9,1.75,1.1,1.1,1.1,1.1])
        _paragraph(doc, 'As cargas na estrutura receptora são exatamente o negativo das reações do apoio sobre a viga. Cada linha pertence ao mesmo caso e à mesma translação da figura; não combinar componentes governantes de posições distintas.')
        _table(doc, ['Grandeza física','Mínimo no estado','Máximo no estado','Unidade'],
               [(label,number(min(v[key] for v in data['rows']),5,signed=True),number(max(v[key] for v in data['rows']),5,signed=True),unit)
                for key,label,unit in [('N_kN','N','kN'),('My_kNm','My forte','kN m'),('Mz_kNm','Mz fraco','kN m'),('Vz_kN','Vz vertical','kN'),('Vy_kN','Vy lateral','kN'),('T_kNm','T total','kN m'),('B_kNm2','B','kN m²')]], [2.15,1.65,1.65,1.6])
        _paragraph(doc, 'Os mínimos e máximos da tabela são ordenadas do diagrama amostrado deste único estado, não um novo fechamento analítico de extremos nem um vetor de esforços concomitantes entre si.')
    else:
        _paragraph(doc, 'Não há caso com resposta calculada íntegra para apresentar diagramas ou reações. As pendências foram preservadas; nenhum esforço zero é fabricado.')

    _paragraph(doc, 'Serviço vertical e deslocamentos', 'Heading 1')
    service_rows = [row for row in rows if row['family']=='EN_SLS_DEFLECTION']
    service_checks = [(row,c) for row in service_rows for c in (row.get('service') or {}).get('checks',[])]
    _table(doc, ['Critério','Demanda mm','Limite mm','Utilização','Situação'],
           [('Útil nominal isolada L/500' if 'payload_only' in check['id'] else 'Total sem dinâmica min L/600 e 25 mm',
             number(check['demand_mm']),number(check['limit_mm']),number(check['utilization']),STATUS.get(check['status'],check['status']))
            for _,check in service_checks], [2.65,.95,.95,.9,1.6])
    _paragraph(doc, f'A flecha incremental da carga útil nominal isolada limita-se a L/500={number(p.span_m*1000/500)} mm; exclui G, Qc, acessórios, cabos e dinâmica. A flecha total inclui G fixo, Qc e Qh nominal, todos sem dinâmica, com contraflecha zero explicitamente adotada, e limita-se a min(L/600, 25 mm)={number(min(p.span_m*1000/600,25.))} mm. São critérios independentes, medidos no centroide em relação aos apoios, sem recalques.')
    service_selected = next((row for row in reversed(service_rows) if row['calculated'] and row.get('service') and row['service'].get('checks')), None)
    if service_selected:
        check = service_selected['service']['checks'][0]
        ddata = diagram_en(bundle,r,service_selected['id'],check['witness']['translation_m'])
        _figure(doc, displacement_figure(ddata), f"Figura 3  Caso {case_labels[service_selected['id']]} na posição que governa sua flecha vertical centroidal. Deslocamentos nos contatos e rotação são informativos; não há limite local ou de vibração inventado.")
    if not service_checks:
        _paragraph(doc, 'Não há verificação de flecha calculada nesta execução; os critérios acima identificam a base prevista, sem declarar atendimento.')

    _paragraph(doc, 'Critérios resistentes e limites de interpretação', 'Heading 1')
    _paragraph(doc, 'Seção nominal global', 'Heading 2')
    _paragraph(doc, 'Recuperação elástica de N, My, Mz, B e cisalhamento nominal em toda a seção. Extremos de componentes do mesmo caso formam uma caixa conservadora de tensões; não são um estado físico concomitante. O denominador resistente é fy/γM0 no ELU. As condições suficientes de classe 1 a 3 e de primeira ordem axial limitam o domínio. Exceder a caixa ou uma condição suficiente não prova falha real do perfil.')
    _paragraph(doc, 'Estabilidade da barra', 'Heading 2')
    _paragraph(doc, 'O complemento de barra usa EN 1993-1-1:2022 adotada via DIN EN 1993-1-1:2025-04 e Anexo C.2, com γM1, viga de um vão, garfos extremos e empenamento livre. A referência de momento crítico é a solução clássica uniforme com C1=1 conservador, sem crédito estabilizante da altura de aplicação inferior. Não se calcula C1 específico do diagrama móvel. As ações reais entram na guarda de trabalho radial, que deve ser não desestabilizante para qualificar essa referência. Coeficientes conservadores adotados não são apresentados como transcrição literal de todos os coeficientes normativos. Compressão com biflexão arbitrária pode permanecer pendente sem impedir a avaliação separada da seção nominal.')
    _paragraph(doc, 'Mesa inferior no estado limite último', 'Heading 2')
    _paragraph(doc, 'A avaliação publicada de EN 1993-6 §6.7, Eq. 6.2 a 6.4 e Tabela 6.2 conserva a tensão de flexão global na Eq. 6.2 literal. A avaliação adicional com N/M/B é um complemento conservador de engenharia adotado: não é prescrição normativa literal, generalização da equação ou prova completa de toda interação. Não se aumenta a capacidade publicada por cancelamento entre tensões. Ramos de extremidade e transição não são substituídos pelo ramo remoto fora de seu domínio.')
    _paragraph(doc, 'Tensões de serviço', 'Heading 2')
    _paragraph(doc, 'EN 1993-6 §7.5, Eq. 7.2, combina tensões locais nominais não reduzidas com recuperação global no mesmo ponto e face. A superposição de rodas próximas é uma caixa conservadora, não um campo concomitante. Uma falha só é declarada quando há testemunho nominal no mesmo estado; contato e raiz tridimensionais continuam fora desta conclusão. O fator recomendado γM,ser=1,0 é adotado sem Anexo Nacional verificado. A checagem nominal global de serviço não equivale a aprovação de estabilidade C.2 em serviço.')
    reasons = _reason_summary(r)
    if reasons:
        _paragraph(doc, 'Pendências e excedências consolidadas', 'Heading 2')
        for reason, mechanisms in reasons.items():
            _paragraph(doc, _short_reason(reason)+' Mecanismos afetados: '+', '.join(sorted(mechanisms))+'.', 'List Bullet')
    incomplete_groups = [g for g in receipt['groups'] if g['generation_status']!='ACTIONS_GENERATED' or any(req['category']=='missing_input' for req in g.get('requirements',[]))]
    if incomplete_groups:
        _paragraph(doc, 'Grupos com entradas de ação incompletas: '+', '.join(group_labels[g['id']]+' '+g['id'] for g in incomplete_groups)+'. Eles não demonstram cobertura de aceleração/frenagem apenas por haver parcela vertical calculável.')
    _paragraph(doc, 'Limites não fechados nesta memória', 'Heading 2')
    for text in r['limitations']:
        _paragraph(doc, text, 'List Bullet')
    _paragraph(doc, 'A cobertura EN não é apresentada como integral nem equivalente à classificação CMAA. Ações e resistências desta rota são independentes; campos de carga e classe do portador geométrico legado não são reutilizados como fatores EN.')

    _paragraph(doc, 'Referências adotadas e rastreabilidade', 'Heading 1')
    _paragraph(doc, 'Edições: EN 1991-3:2006 + AC:2012 para ações; EN 1990:2002 + A1:2005 para combinações; EN 1993-6:2007 + AC:2009 para estrutura de apoio; EN 1993-1-1:2022 adotada via DIN EN 1993-1-1:2025-04 para o complemento de barra. Valores recomendados foram adotados, sem seleção ou verificação de Anexo Nacional. Edições posteriores não são reivindicadas como implementadas.')
    used_sources = list(dict.fromkeys(key for g in receipt['groups'] for key in g['sources']))
    used_sources += [key for key in dict.fromkeys(key for row in rows for key in row['action_case']['sources']) if key not in used_sources]
    references = {}
    for key in used_sources:
        source = receipt['source_register'][key]
        references.setdefault((source['edition'],source['url']),[]).append(_reference_text_pt(source['clause']))
    for (edition,url),clauses in references.items():
        _paragraph(doc, edition+'; '+('; '.join(dict.fromkeys(clauses)))+'. '+url)
    _paragraph(doc, 'Fonte de adoção do método: '+declared(b.method_adoption_source)+'. Fonte do modelo físico: '+declared(b.physical_model_source)+'.')
    member_sources = list(dict.fromkeys(source for row in rows if row.get('member') for source in row['member'].get('Mcr_reference_sources',[])))
    for source in member_sources:
        _paragraph(doc, _reference_text_pt(source))
    for source in dict.fromkeys(row['member']['source'] for row in rows if row.get('member')):
        _paragraph(doc, 'Referência documental do núcleo EN 1993-1-1: '+source)
    if a.notes:
        _paragraph(doc, 'Notas das ações: '+a.notes)
    if bundle.notes:
        _paragraph(doc, 'Notas do projeto EN: '+bundle.notes)
    _paragraph(doc, 'Fontes declaradas nas entradas', 'Heading 2')
    for source,reference in declarations.items():
        prefixes = [other for other in declarations if other != source and len(other)>=60 and source.startswith(other)]
        base = max(prefixes,key=len,default=None)
        displayed = ('Mesma declaração de '+declarations[base]+'. Complemento: '+source[len(base):].strip()) if base else source
        _paragraph(doc, reference+'  '+displayed)
    p_trace = _paragraph(doc, 'O JSON de evidência contém o snapshot completo, todas as origens, grupos, casos e resultados, inclusive diagnósticos e pendências. Não é arquivo de entrada. A integridade é conferida antes e depois da exportação; hashes identificam conteúdo, não certificam validade de engenharia.')
    p_trace.paragraph_format.keep_with_next = True
    p_hash = _paragraph(doc, 'Prefixos SHA 256, com valores integrais no JSON: entradas '+r['input_signature'][:16]+'; núcleo '+r['sources']['fingerprint'][:16]+'; resultado '+r['result_signature'][:16]+'; relatório '+guard[2][:16]+'.')
    for run in p_hash.runs:
        run.font.size = Pt(8)
    data = BytesIO()
    doc.save(data)
    _guard_end(bundle, result, guard)
    return data.getvalue()
